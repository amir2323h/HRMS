// ============================================================
// کاتالوگ مجوزها + نقش‌های پیش‌فرض سیستم (RBAC داینامیک)
// هر مجوز یک کلید «ماژول:عمل» است؛ نقش SUPER_ADMIN با «*» همه‌چیز را می‌گیرد
// ============================================================

export interface PermissionDef {
  key: string;
  label: string;
}

export interface PermissionGroup {
  group: string;
  items: PermissionDef[];
}

export const PERMISSION_CATALOG: PermissionGroup[] = [
  {
    group: "عمومی",
    items: [
      { key: "dashboard:view", label: "مشاهده داشبورد مدیریتی" },
      { key: "portal:view", label: "پرتال خودخدماتی کارمند" },
      { key: "docs:view", label: "مستندات فنی سامانه" },
    ],
  },
  {
    group: "کارکنان و ساختار سازمانی",
    items: [
      { key: "employees:view", label: "مشاهده کارکنان" },
      { key: "employees:edit", label: "ثبت و ویرایش کارکنان" },
      { key: "departments:view", label: "مشاهده دپارتمان‌ها" },
      { key: "departments:manage", label: "مدیریت دپارتمان‌ها و مدیر واحد" },
      { key: "grades:view", label: "مشاهده طبقه‌بندی مشاغل" },
      { key: "grades:manage", label: "ویرایش طبقه‌بندی مشاغل" },
    ],
  },
  {
    group: "حضور و غیب",
    items: [
      { key: "attendance:view", label: "مشاهده حضور و غیب (تردد و کارکرد)" },
      { key: "attendance:manage", label: "ثبت و ویرایش تردد و کارکرد" },
    ],
  },
  {
    group: "قراردادها و نامه‌ها",
    items: [
      { key: "contracts:view", label: "مشاهده قراردادها" },
      { key: "contracts:manage", label: "صدور و مدیریت قراردادها" },
      { key: "letters:create", label: "ثبت درخواست‌نامه" },
      { key: "letters:approve", label: "تأیید درخواست‌نامه‌ها" },
      { key: "letters:templates", label: "مدیریت قالب نامه‌ها" },
      { key: "letters:manual", label: "ثبت نامه دستی (بدون قالب)" },
    ],
  },
  {
    group: "حقوق، مالی و پاداش",
    items: [
      { key: "payroll:view", label: "مشاهده لیست‌های حقوق" },
      { key: "payroll:manage", label: "محاسبه و مدیریت دوره‌های حقوق" },
      { key: "reverse:use", label: "محاسبه معکوس حقوق" },
      { key: "reports:view", label: "گزارش‌ها و خروجی‌های قانونی" },
      { key: "bonus:view", label: "مشاهده طرح‌های پاداش" },
      { key: "bonus:manage", label: "مدیریت طرح‌های پاداش" },
    ],
  },
  {
    group: "درخواست‌ها و تأییدها",
    items: [
      { key: "requests:create", label: "ثبت درخواست مرخصی/مساعده" },
      { key: "requests:approve_dept", label: "تأیید مرحله مدیر واحد" },
      { key: "requests:approve_hr", label: "تأیید مرحله منابع انسانی" },
    ],
  },
  {
    group: "مدیریت سامانه",
    items: [
      { key: "audit:view", label: "لاگ حسابرسی" },
      { key: "settings:view", label: "مشاهده تنظیمات" },
      { key: "settings:manage", label: "ویرایش پارامترها و برندینگ" },
      { key: "jobs:manage", label: "مدیریت مشاغل و عناوین شغلی" },
      { key: "welfare:manage", label: "مدیریت آیتم‌های رفاهی" },
      { key: "users:view", label: "مشاهده کاربران" },
      { key: "users:manage", label: "مدیریت کاربران و رمزها" },
      { key: "roles:manage", label: "مدیریت نقش‌ها و مجوزها" },
    ],
  },
];

export const ALL_PERMISSIONS: string[] = PERMISSION_CATALOG.flatMap((g) => g.items.map((i) => i.key));

export function permissionLabel(key: string): string {
  for (const g of PERMISSION_CATALOG) {
    const f = g.items.find((i) => i.key === key);
    if (f) return f.label;
  }
  return key;
}

/** نقش‌های پیش‌فرض سیستمی — معادل رفتار قبلی پنج‌نقشی */
export const DEFAULT_ROLES: {
  key: string;
  name: string;
  description: string;
  permissions: string[];
}[] = [
  {
    key: "SUPER_ADMIN",
    name: "مدیر کل سیستم",
    description: "دسترسی کامل به همه بخش‌های سامانه",
    permissions: ["*"],
  },
  {
    key: "HR_MANAGER",
    name: "مدیر منابع انسانی",
    description: "کارکنان، قراردادها، درخواست‌ها، نامه‌ها، تنظیمات",
    permissions: [
      "dashboard:view", "portal:view", "docs:view",
      "employees:view", "employees:edit",
      "departments:view", "departments:manage",
      "grades:view", "grades:manage",
      "attendance:view", "attendance:manage",
      "contracts:view", "contracts:manage",
      "letters:create", "letters:approve", "letters:templates", "letters:manual",
      "reports:view", "bonus:view", "bonus:manage",
      "requests:create", "requests:approve_hr", "requests:approve_dept",
      "audit:view", "settings:view", "settings:manage", "jobs:manage", "welfare:manage", "users:view",
    ],
  },
  {
    key: "ADMIN_EXPERT",
    name: "کارشناس اداری",
    description: "صدور نامه‌های اداری، ثبت نامه دستی و صدور نسخه رسمی",
    permissions: [
      "portal:view", "docs:view",
      "employees:view",
      "letters:create", "letters:approve", "letters:manual",
    ],
  },
  {
    key: "PAYROLL_OFFICER",
    name: "کارشناس حقوق و دستمزد",
    description: "حقوق، محاسبه معکوس، گزارش‌ها، قراردادها",
    permissions: [
      "dashboard:view", "portal:view", "docs:view",
      "employees:view",
      "attendance:view", "attendance:manage",
      "contracts:view", "contracts:manage",
      "payroll:view", "payroll:manage", "reverse:use", "reports:view",
      "bonus:view", "bonus:manage",
      "audit:view", "settings:view",
    ],
  },
  {
    key: "DEPT_MANAGER",
    name: "مدیر دپارتمان",
    description: "مشاهده کارکنان واحد + تأیید مرحله اول درخواست‌ها",
    permissions: [
      "dashboard:view", "portal:view", "docs:view",
      "employees:view", "departments:view", "reports:view", "attendance:view",
      "requests:create", "requests:approve_dept", "letters:create",
    ],
  },
  {
    key: "EMPLOYEE",
    name: "کارمند",
    description: "پرتال خودخدماتی، درخواست‌ها و درخواست‌نامه",
    permissions: ["portal:view", "docs:view", "requests:create", "letters:create"],
  },
];

/** بررسی مجوز — «*» دسترسی کامل */
export function hasPerm(perms: string[] | undefined | null, key: string): boolean {
  if (!perms) return false;
  return perms.includes("*") || perms.includes(key);
}

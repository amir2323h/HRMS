#!/usr/bin/env bash
# ================================================================
#   نصب‌کننده تمام‌خودکار — سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵
#   تک‌فایل (سورس داخل همین اسکریپت) — بدون نیاز به هیچ کار دستی
#   اجرا:  sudo bash install-hrms.sh [--port 3000] [--dir /opt/hrms] [--no-demo] [--domain hrms.example.com]
#   سازگار: Ubuntu 20.04+ / Debian 11+ / RHEL 9+ / Rocky / Alma (amd64 و arm64)
#   آپدیت: اجرای مجدد روی نصب موجود = به‌روزرسانی امن (داده‌ها و کلید نشست حفظ می‌شوند)
# ================================================================
set -euo pipefail

# ---------- نسخه بسته ----------
APP_VERSION="1.6.0"
APP_VERSION_FA="۱.۶.۰"

# ---------- رنگ‌ها ----------
if command -v tput >/dev/null 2>&1 && [ -t 1 ]; then
  B=$(tput bold); R=$(tput setaf 1); G=$(tput setaf 2); Y=$(tput setaf 3); C=$(tput setaf 6); N=$(tput sgr0)
else
  B=""; R=""; G=""; Y=""; C=""; N=""
fi
info()  { echo -e "${C}◈${N} $*"; }
ok()    { echo -e "${G}✓${N} $*"; }
warn()  { echo -e "${Y}⚠${N} $*"; }
fail()  { echo -e "${R}✗${N} $*" >&2; exit 1; }

# ---------- پارامترها ----------
PORT=3000
APP_DIR=/opt/hrms
DEMO=1
DOMAIN=""
while [ $# -gt 0 ]; do
  case "$1" in
    --port)     PORT="$2"; shift 2 ;;
    --dir)      APP_DIR="$2"; shift 2 ;;
    --no-demo)  DEMO=0; shift ;;
    --domain)   DOMAIN="$2"; shift 2 ;;
    -h|--help)
      sed -n '2,9p' "$0"; exit 0 ;;
    *) fail "آرگومان ناشناخته: $1 (برای راهنما: --help)" ;;
  esac
done
# اعتبارسنجی دامنه — فقط حروف/عدد/نقطه/خط تیره
if [ -n "$DOMAIN" ]; then
  echo "$DOMAIN" | grep -Eq '^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$' \
    || fail "دامنه نامعتبر است: $DOMAIN (نمونه صحیح: hrms.example.com)"
fi

echo -e "${B}${C}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   نصب خودکار سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵   ║"
echo "║        HRMS 1405 — نسخه ${APP_VERSION} — نصب یک‌مرحله‌ای        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${N}"
info "نسخه: ${B}${APP_VERSION}${N} | پوشه نصب: ${B}${APP_DIR}${N} | پورت: ${B}${PORT}${N} | داده نمونه: $([ $DEMO -eq 1 ] && echo 'بله' || echo 'خیر')${DOMAIN:+ | دامنه: ${B}${DOMAIN}${N}}"

# ================================================================
# ۱) بررسی ریشه و سیستم‌عامل
# ================================================================
[ "$(id -u)" -eq 0 ] || fail "این اسکریپت باید با ریشه اجرا شود: sudo bash $0"
OS_ID=$(. /etc/os-release 2>/dev/null && echo "${ID:-}" || echo "")
OS_VER=$(. /etc/os-release 2>/dev/null && echo "${VERSION_ID:-}" || echo "")
info "سیستم‌عامل تشخیص داده شد: ${OS_ID:-نامشخص} ${OS_VER}"

PKG=""
if command -v apt-get >/dev/null 2>&1; then PKG="apt"
elif command -v dnf >/dev/null 2>&1; then PKG="dnf"
else fail "پکیج‌منیجر پشتیبانی‌نشده — فقط apt/dnf (Ubuntu/Debian/RHEL) پشتیبانی می‌شود."
fi

# ================================================================
# ۲) نصب پیش‌نیازهای سیستمی (خودکار)
# ================================================================
info "نصب پیش‌نیازهای سیستمی (curl, sqlite3, openssl, tar)…"
export DEBIAN_FRONTEND=noninteractive
if [ "$PKG" = "apt" ]; then
  apt-get update -qq || warn "apt update با هشدار ادامه یافت"
  apt-get install -y -qq curl ca-certificates sqlite3 openssl tar gzip >/dev/null 2>&1 || \
    apt-get install -y curl ca-certificates sqlite3 openssl tar gzip
elif [ "$PKG" = "dnf" ]; then
  dnf install -y -q curl ca-certificates sqlite openssl tar gzip || \
    dnf install -y curl sqlite openssl tar gzip
fi
ok "پیش‌نیازهای سیستمی نصب شدند"

# ================================================================
# ۳) نصب Node.js ≥ 20 (خودکار)
# ================================================================
NODE_MAJOR=0
if command -v node >/dev/null 2>&1; then
  NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)
fi
if [ "$NODE_MAJOR" -lt 20 ]; then
  info "Node.js ≥ ۲۰ یافت نشد (نسخه فعلی: ${NODE_MAJOR:-ندارد}) — نصب Node 22 از مخزن رسمی…"
  if [ "$PKG" = "apt" ]; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null 2>&1 || true
    apt-get install -y -qq nodejs >/dev/null 2>&1 || apt-get install -y nodejs
  else
    curl -fsSL https://rpm.nodesource.com/setup_22.x | bash - >/dev/null 2>&1 || true
    dnf install -y -q nodejs || dnf module install -y nodejs:22 || fail "نصب Node.js ناموفق بود"
  fi
  NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)
fi
[ "$NODE_MAJOR" -ge 20 ] || fail "Node.js ≥ ۲۰ در دسترس نیست — لطفاً دستی نصب کنید و دوباره اجرا کنید"
ok "Node.js $(node --version) آماده است"

# ================================================================
# ۴) حافظه کم؟ swap خودکار (ساخت Next.js به ≥۱GB نیاز دارد)
# ================================================================
MEM_MB=$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 2048)
SWAP_MB=$(awk '/SwapTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 0)
if [ "$MEM_MB" -lt 900 ] && [ "$SWAP_MB" -lt 500 ]; then
  info "حافظه کم (${MEM_MB}MB) — ساخت ۲GB swap برای موفقیت بیلد…"
  if ! swapon --show 2>/dev/null | grep -q . && [ ! -f /swapfile ]; then
    fallocate -l 2G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
    chmod 600 /swapfile && mkswap -q /swapfile && swapon /swapfile
    grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
    ok "swap فعال شد"
  else
    warn "swap از قبل موجود است — ادامه"
  fi
fi

# ================================================================
# ۵) استخراج سورس از داخل همین فایل (خودکار — بدون اکسترکت دستی)
# ================================================================
info "استخراج سورس سامانه در ${APP_DIR}…"
mkdir -p "$APP_DIR"

# ---------- تشخیص حالت به‌روزرسانی: نصب موجود با کاربر واقعی؟ ----------
# دیتابیس جزو بسته نیست → نصب مجدد سورس آن را حذف نمی‌کند؛
# اگر کاربر وجود دارد، این اجرا «به‌روزرسانی» است: داده/کلید نشست حفظ و seed اجرا نمی‌شود.
UPDATE_MODE=0
DB_FILE="${APP_DIR}/db/custom.db"
if [ -s "$DB_FILE" ]; then
  USERS_N=$(sqlite3 "$DB_FILE" "SELECT COUNT(*) FROM users;" 2>/dev/null || echo 0)
  if [ "${USERS_N:-0}" -gt 0 ] 2>/dev/null; then
    UPDATE_MODE=1
    info "نصب موجود تشخیص داده شد (${USERS_N} کاربر) — به‌روزرسانی امن: داده‌ها حفظ می‌شوند"
  fi
fi

MARKER='__PAYLOAD_B64__'
if ! grep -q "^${MARKER}$" "$0"; then
  fail "بسته سورس داخل اسکریپت یافت نشد — فایل نصب‌کننده را دوباره دانلود کنید"
fi
awk "f{print} /^${MARKER}$/{f=1}" "$0" | base64 -d | tar -xzf - -C "$APP_DIR"
[ -f "$APP_DIR/package.json" ] || fail "استخراج سورس ناموفق بود"
ok "سورس استخراج شد"

# ================================================================
# ۶) پیکربندی محیط (کلید امنیتی تصادفی + مسیر دیتابیس)
#    در حالت به‌روزرسانی: کلید نشست قبلی حفظ می‌شود (نشست‌های باز معتبر می‌مانند)
# ================================================================
info "تولید پیکربندی امن…"
OLD_SECRET=""
if [ "$UPDATE_MODE" -eq 1 ] && [ -f "$APP_DIR/.env" ]; then
  OLD_SECRET=$(grep -E '^AUTH_SECRET=' "$APP_DIR/.env" | head -1 | cut -d= -f2- || true)
  [ -n "$OLD_SECRET" ] && ok "کلید نشست موجود حفظ شد"
fi
AUTH_SECRET="${OLD_SECRET:-$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')}"
mkdir -p "$APP_DIR/db"
cat > "$APP_DIR/.env" <<ENVEOF
DATABASE_URL=file:${APP_DIR}/db/custom.db
AUTH_SECRET=${AUTH_SECRET}
NODE_ENV=production
PORT=${PORT}
HOSTNAME=0.0.0.0
ENVEOF
chmod 600 "$APP_DIR/.env"
ok ".env تولید شد (کلید نشست ۶۴ نویسه تصادفی)"

# ================================================================
# ۷) نصب بسته‌های npm + آماده‌سازی دیتابیس
# ================================================================
cd "$APP_DIR"
info "نصب بسته‌ها از npm (چند دقیقه صبر کنید)…"
npm install --no-audit --no-fund --loglevel=error >/dev/null 2>&1 || npm install --no-audit --no-fund
ok "بسته‌ها نصب شدند"

info "آماده‌سازی دیتابیس SQLite (پرایسما)…"
# متغیر محیطی صریح — اولویت بر .env (در برابر DATABASE_URL والد/غیرمنتظره مقاوم است)
DB_URL="file:${APP_DIR}/db/custom.db"
DATABASE_URL="$DB_URL" npx --yes prisma generate >/dev/null 2>&1 || DATABASE_URL="$DB_URL" npx prisma generate
DATABASE_URL="$DB_URL" npx --yes prisma db push --accept-data-loss >/dev/null 2>&1 || DATABASE_URL="$DB_URL" npx prisma db push --accept-data-loss
[ -s "$APP_DIR/db/custom.db" ] || fail "ساخت دیتابیس ناموفق بود"
ok "دیتابیس ساخته شد: ${APP_DIR}/db/custom.db"

# ================================================================
# ۸) داده اولیه — اجرات TS با bun یا tsx (خودکار)
# ================================================================
RUNTS=""
if command -v bun >/dev/null 2>&1; then
  RUNTS="bun"
elif npm install -g bun >/dev/null 2>&1 && command -v bun >/dev/null 2>&1; then
  RUNTS="bun"
fi
if [ -z "$RUNTS" ]; then
  info "bun در دسترس نیست — استفاده از tsx…"
  RUNTS="npx --yes tsx"
fi

if [ "$UPDATE_MODE" -eq 1 ]; then
  info "به‌روزرسانی: داده‌های موجود و کاربران حفظ می‌شوند (seed اجرا نمی‌شود)…"
  ok "داده‌های فعلی بدون تغییر ماند"
elif [ "$DEMO" -eq 1 ]; then
  info "بارگذاری داده نمونه (کارکنان/نقش‌ها/دوره‌های حقوق)…"
  DATABASE_URL="$DB_URL" $RUNTS prisma/seed.ts >/dev/null 2>&1 || DATABASE_URL="$DB_URL" $RUNTS prisma/seed.ts
  # نقش‌های سیستمی + رفاهیات + قالب نامه‌ها + مدیر واحدها
  if [ -f scripts/backfill-v4.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v4.ts >/dev/null 2>&1 || true
  fi
  # کارشناس اداری + تنظیمات شماره‌گذاری نامه‌ها (ZDX_AD_0507019)
  if [ -f scripts/backfill-v5.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v5.ts >/dev/null 2>&1 || true
  fi
  ok "داده نمونه کامل بارگذاری شد"
else
  info "نصب تمیز (بدون داده نمونه) — ساخت مدیر اولیه…"
  cat > "$APP_DIR/bootstrap.mjs" <<'BOOTEOF'
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
const db = new PrismaClient();
const salt = randomBytes(16).toString("hex");
const hash = scryptSync("admin123", salt, 64).toString("hex");
const role = await db.role.upsert({
  where: { key: "SUPER_ADMIN" },
  update: {},
  create: { key: "SUPER_ADMIN", name: "مدیر کل سیستم", description: "دسترسی کامل", permissions: "[\"*\"]" },
});
await db.user.upsert({
  where: { username: "admin" },
  update: { roleId: role.id },
  create: { username: "admin", passwordHash: `${salt}:${hash}`, fullName: "مدیر کل سیستم", role: "SUPER_ADMIN", roleId: role.id, isActive: true },
});
await db.systemSetting.upsert({
  where: { key: "display" },
  update: {},
  create: { key: "display", value: "{\"unit\":\"TOMAN\"}" },
});
await db.$disconnect();
console.log("bootstrap-ok");
BOOTEOF
  DATABASE_URL="$DB_URL" node "$APP_DIR/bootstrap.mjs" >/dev/null 2>&1 || DATABASE_URL="$DB_URL" node "$APP_DIR/bootstrap.mjs"
  rm -f "$APP_DIR/bootstrap.mjs"
  ok "کاربر مدیر ساخته شد: admin / admin123"
fi

# ================================================================
# ۹) بیلد نسخه تولیدی (standalone)
# ================================================================
info "بیلد نسخه تولیدی Next.js (طولانی‌ترین مرحله)…"
export DATABASE_URL="${DB_URL}"
export AUTH_SECRET="$AUTH_SECRET"
export NEXT_TELEMETRY_DISABLED=1
npm run build >/dev/null 2>&1 || npm run build
[ -f "$APP_DIR/.next/standalone/server.js" ] || fail "بیلد ناموفق بود — لاگ: cd $APP_DIR && npm run build"
ok "بیلد standalone آماده شد"

# ================================================================
# ۱۰) سرویس systemd (اجرای دائمی + راه‌اندازی خودکار پس از ریبوت)
# ================================================================
SERVICE=hrms
# آیا systemd واقعاً در حال اجراست؟ (نه فقط نصب — مثلاً WSL بدون systemd)
SYSTEMD_RUNNING=0
if command -v systemctl >/dev/null 2>&1; then
  if [ -d /run/systemd/system ] || systemctl is-system-running >/dev/null 2>&1; then
    SYSTEMD_RUNNING=1
  fi
fi
if [ "$SYSTEMD_RUNNING" -eq 1 ]; then
  info "نصب سرویس systemd…"
  cat > /etc/systemd/system/${SERVICE}.service <<UNITEOF
[Unit]
Description=HRMS 1405 — سامانه جامع منابع انسانی و حقوق و دستمزد
After=network.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
Environment=NODE_ENV=production
Environment=PORT=${PORT}
Environment=HOSTNAME=0.0.0.0
Environment=DATABASE_URL=${DB_URL}
Environment=AUTH_SECRET=${AUTH_SECRET}
ExecStart=$(command -v node) ${APP_DIR}/.next/standalone/server.js
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNITEOF
  systemctl daemon-reload
  systemctl enable ${SERVICE} >/dev/null 2>&1 || true
  systemctl restart ${SERVICE}
  ok "سرویس ${SERVICE} فعال شد (راه‌اندازی خودکار پس از ریبوت)"
else
  warn "systemd فعال نیست — اجرای مستقیم با nohup…"
  ( cd "$APP_DIR" && DATABASE_URL="${DB_URL}" AUTH_SECRET="$AUTH_SECRET" PORT="$PORT" HOSTNAME=0.0.0.0 nohup node .next/standalone/server.js > server.log 2>&1 & )
fi

# فایروال: باز کردن پورت (اگر ufw فعال است) — با دامنه، ۸۰/۴۴۳ برای HTTPS هم باز می‌شود
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PORT}/tcp" >/dev/null 2>&1 || true
  if [ -n "$DOMAIN" ]; then
    ufw allow 80/tcp >/dev/null 2>&1 || true
    ufw allow 443/tcp >/dev/null 2>&1 || true
    ok "پورت‌های ${PORT} و 80/443 (HTTPS) در فایروال (ufw) باز شدند"
  else
    ok "پورت ${PORT} در فایروال (ufw) باز شد"
  fi
fi

# ================================================================
# ۱۱) بررسی سلامت — انتظار برای پاسخ HTTP
# ================================================================
info "بررسی سلامت سامانه (حداکثر ۶۰ ثانیه)…"
HEALTHY=0
for i in $(seq 1 30); do
  if curl -fs -o /dev/null --max-time 3 "http://127.0.0.1:${PORT}/api/branding" 2>/dev/null; then
    HEALTHY=1; break
  fi
  sleep 2
done
[ "$HEALTHY" -eq 1 ] || fail "سامانه پاسخ نداد — لاگ: journalctl -u ${SERVICE} -n 50"

# ================================================================
# ۱۱.۵) دامنه + HTTPS خودکار (Caddy) — فقط با پرچم --domain
#   پیش‌نیازها: رکورد A دامنه ← آی‌پی عمومی سرور + باز بودن 80/443 از اینترنت
#   گواهی Let's Encrypt به‌طور خودکار صادر و تمدید می‌شود
# ================================================================
if [ -n "$DOMAIN" ]; then
  info "پیکربندی دامنه ${DOMAIN} با Caddy (HTTPS خودکار)…"
  if ! command -v caddy >/dev/null 2>&1; then
    if [ "$PKG" = "apt" ]; then
      apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https >/dev/null 2>&1 || true
      curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null || true
      curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.sh' | bash >/dev/null 2>&1 || true
      apt-get install -y -qq caddy >/dev/null 2>&1 || apt-get install -y caddy
    else
      dnf install -y -q 'dnf-command(copr)' >/dev/null 2>&1 || true
      dnf copr enable -y @caddy/caddy >/dev/null 2>&1 || true
      dnf install -y -q caddy || dnf install -y caddy
    fi
  fi
  if command -v caddy >/dev/null 2>&1; then
    mkdir -p /etc/caddy
    cat > /etc/caddy/Caddyfile <<CADDYEOF
# HRMS 1405 — reverse proxy to local service
${DOMAIN} {
    encode zstd gzip
    reverse_proxy 127.0.0.1:${PORT}
}
CADDYEOF
    systemctl enable caddy >/dev/null 2>&1 || true
    systemctl restart caddy >/dev/null 2>&1 || systemctl restart caddy || true
    ok "Caddy فعال شد — سامانه روی ${C}https://${DOMAIN}${N} با گواهی خودکار در دسترس است"
    warn "اگر دامنه هنوز به این سرور اشاره نکرده باشد، صدور گواهی کمی بعد (پس از تنظیم DNS) خودکار انجام می‌شود — لاگ: journalctl -u caddy -f"
  else
    warn "نصب Caddy ناموفق بود — پیکربندی دستی: هر وب‌سروری که به 127.0.0.1:${PORT} پروکسی کند + گواهی SSL"
  fi
fi

# ================================================================
# ۱۲) خلاصه نهایی
# ================================================================
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
[ -n "$IP" ] || IP="آدرس-سرور"
echo -e "${B}${G}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    ${N}${B}نصب با موفقیت کامل شد ✓${G}                        ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  نسخه نصب‌شده:  HRMS 1405 — v${APP_VERSION} (نسخه ${APP_VERSION_FA})"
if [ -n "$DOMAIN" ]; then
  echo "║  نشانی سامانه:   ${C}https://${DOMAIN}${G}  (و http://${IP}:${PORT})"
else
  echo "║  نشانی سامانه:   ${C}http://${IP}:${PORT}${G}"
fi
if [ "$UPDATE_MODE" -eq 1 ]; then
  echo "║  حالت:           به‌روزرسانی نصب موجود — داده‌ها/کاربران/کلید نشست حفظ شد"
fi
echo "║  کاربران نمونه:  admin/admin123  •  hr/hr123  •  emp/emp123  •  edari/edari123 (کارشناس اداری)"
echo "║  دیتابیس:        ${APP_DIR}/db/custom.db"
echo "║  سورس:           ${APP_DIR}"
echo "╠══════════════════════════════════════════════════════════════╣${N}"
echo "  دستورات مدیریتی:"
echo "    وضعیت سرویس:   systemctl status ${SERVICE}"
echo "    ری‌استارت:      systemctl restart ${SERVICE}"
echo "    لاگ زنده:       journalctl -u ${SERVICE} -f"
echo "    پشتیبان‌گیری:    cp ${APP_DIR}/db/custom.db ~/hrms-backup-\$(date +%F).db"
if [ "$DEMO" -eq 1 ]; then
  echo ""
  echo "  حذف داده نمونه (برای شروع بهره‌برداری واقعی):"
  echo "    از سامانه:      تنظیمات ← تب «داده نمونه» ← دکمه حذف"
  echo "    از خط فرمان:    cd ${APP_DIR} && DATABASE_URL='file:${APP_DIR}/db/custom.db' npx --yes tsx scripts/purge-demo.ts"
  echo "    حالت کامل:      همین دستور با پرچم --full (فقط تنظیمات + نقش‌ها + admin باقی می‌ماند)"
fi
echo ""
echo -e "  ${Y}⚠ امنیت:${N} بلافاصله وارد شوید و رمز admin را از «تنظیمات ← کاربران» تغییر دهید."
echo -e "  ${Y}⚠ امنیت:${N} فایل ${APP_DIR}/.env حاوی کلید نشست است — آن را افشا نکنید."
echo ""
[ "$DEMO" -eq 1 ] && echo -e "  ${Y}نکته:${N} با --no-demo می‌توانستید نصب تمیز (فقط کاربر admin) داشته باشید — یا هر زمان داده نمونه را با دستور بالا/تب «داده نمونه» پاک کنید."
echo ""
ok "سامانه جامع منابع انسانی ۱۴۰۵ آماده بهره‌برداری است"
exit 0

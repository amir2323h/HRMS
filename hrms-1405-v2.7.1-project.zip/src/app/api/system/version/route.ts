import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";

// ============================================================
// نسخه نصب‌شده و آخرین نسخه گیت‌هاب — مبنای «دکمه آپدیت پنل»
//  GET /api/system/version         → وضعیت کش‌شده (چک هر ۲ روز)
//  GET /api/system/version?force=1 → چک همین حالا (دکمه «بررسی مجدد»)
//
// نسخه جاری: env APP_VERSION (نصب‌کننده در .env/systemd می‌نویسد)
// آخرین نسخه — سه منبع موازی (مثل دستور hrms؛ مقاوم در برابر
// محدودیت نرخ ۶۰درخواست/ساعت api.github.com و حذف release ها):
//   A) api.github.com/repos/amir2323h/HRMS/releases → نسخه+تاریخ+یادداشت
//   B) github.com/amir2323h/HRMS/releases.atom      → نسخه+تاریخ
//   C) صفحه مخزن → نام زیپ‌های hrms-1405-vX.Y.Z-project.zip → نسخه
// برنده = بیشترین نسخه بین منابع موفق؛ داده غنی از منبع همان نسخه
// کش در SystemSetting «update_check» با TTL ۲ روز؛ آفلاین = آخرین کش
// ============================================================

const GITHUB_REPO = "amir2323h/HRMS";
const GITHUB_RELEASES_API = `https://api.github.com/repos/${GITHUB_REPO}/releases?per_page=15`;
const GITHUB_ATOM = `https://github.com/${GITHUB_REPO}/releases.atom`;
const GITHUB_REPO_PAGE = `https://github.com/${GITHUB_REPO}/`;
const CHECK_TTL_MS = 2 * 24 * 60 * 60 * 1000; // ۲ روز
const FAIL_RETRY_MS = 30 * 60 * 1000; // ۳۰ دقیقه — کش منفی خطای شبکه
const FETCH_TIMEOUT_MS = 8000;

interface UpdateCheckCache {
  checkedAt: string; // ISO
  latest: string;
  latestAt: string; // ISO تاریخ انتشار
  notes: string; // متن یادداشت انتشار (خلاصه)
  url: string; // نشانی انتشار
  source?: "release" | "atom" | "zip"; // منبع نسخه برنده
  error?: string; // آخرین خطا (اگر latest خالی نباشد نادیده گرفته می‌شود)
  failUntil?: string; // ISO — تا این لحظه به‌خاطر خطای شبکه دوباره تلاش نکن
}

/** مقایسه نسخه‌های x.y.z — درست نسبت به عددی هر جزء */
function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

/** فراخوانی HTTP با مهلت — بدون پرتاب (خطا = null) */
async function fetchText(url: string, headers: Record<string, string>): Promise<{ ok: boolean; status: number; text: string; rateLimited: boolean } | null> {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT_MS);
    const res = await fetch(url, { headers, signal: ctrl.signal, cache: "no-store" });
    clearTimeout(timer);
    const text = res.ok ? await res.text() : "";
    // محدودیت نرخ گیت‌هاب: ۴۰۳ + سرآیند x-ratelimit-remaining=0
    const remaining = res.headers.get("x-ratelimit-remaining");
    const rateLimited = (res.status === 403 || res.status === 429) && remaining === "0";
    return { ok: res.ok, status: res.status, text, rateLimited };
  } catch {
    return null; // شبکه قطع/مهلت پایان
  }
}

interface Candidate {
  latest: string;
  latestAt?: string;
  notes?: string;
  url?: string;
  source: "release" | "atom" | "zip";
}

/** A) API رسمی releases — کامل‌ترین داده (تاریخ/یادداشت/نشانی) */
async function fromReleasesApi(): Promise<{ cand: Candidate | null; rateLimited: boolean; hadReleases: boolean }> {
  const res = await fetchText(GITHUB_RELEASES_API, {
    Accept: "application/vnd.github+json",
    "User-Agent": "hrms-update-check",
  });
  if (!res) return { cand: null, rateLimited: false, hadReleases: false };
  if (!res.ok) return { cand: null, rateLimited: res.rateLimited, hadReleases: false };
  try {
    const releases = JSON.parse(res.text) as {
      tag_name?: string; name?: string; draft?: boolean; prerelease?: boolean;
      published_at?: string; html_url?: string; body?: string;
    }[];
    const stable = releases.find((r) => !r.draft && !r.prerelease) || releases[0];
    const ver = String(stable?.tag_name || stable?.name || "").replace(/^[vV]/, "").trim();
    if (!stable || !/^\d+(\.\d+)*$/.test(ver)) return { cand: null, rateLimited: false, hadReleases: releases.length > 0 };
    const notes = String(stable.body || "")
      .replace(/\r\n/g, "\n")
      // خلاصه‌سازی: ۱۲۰۰ نویسه + حذف مارک‌داون سنگین
      .replace(/#{1,6}\s*/g, "")
      .replace(/\*\*/g, "")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .slice(0, 30)
      .join("\n")
      .slice(0, 1200);
    return {
      cand: { latest: ver, latestAt: stable.published_at || "", notes, url: stable.html_url || "", source: "release" },
      rateLimited: false,
      hadReleases: true,
    };
  } catch {
    return { cand: null, rateLimited: false, hadReleases: false };
  }
}

/** B) فید Atom انتشارها — بدون محدودیت نرخ API */
async function fromAtomFeed(): Promise<Candidate | null> {
  const res = await fetchText(GITHUB_ATOM, { "User-Agent": "Mozilla/5.0 (compatible; hrms-update-check)" });
  if (!res || !res.ok || !res.text) return null;
  try {
    // هر entry: <link href="…/releases/tag/vX.Y.Z"/> + <updated>…</updated>
    const entries = res.text.split(/<entry[\s>]/).slice(1);
    let best: Candidate | null = null;
    for (const e of entries) {
      // نسخه از پیوند tag (اولویت) یا عنوان عددی
      const ver = e.match(/releases\/tag\/v?(\d+(?:\.\d+)*)/)?.[1] || e.match(/<title>v?(\d+(?:\.\d+)*)<\/title>/)?.[1];
      if (!ver) continue;
      const upd = e.match(/<updated>([^<]+)<\/updated>/)?.[1] || "";
      const c: Candidate = { latest: ver, latestAt: upd, source: "atom" };
      if (!best || cmpVersion(c.latest, best.latest) > 0) best = c;
    }
    return best;
  } catch {
    return null;
  }
}

/** C) زیپ‌های ریشه مخزن — همان مسیر کشف نسخه دستور hrms update */
async function fromRepoZips(): Promise<Candidate | null> {
  const res = await fetchText(GITHUB_REPO_PAGE, { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64)" });
  if (!res || !res.ok || !res.text) return null;
  const vers = Array.from(new Set(res.text.match(/hrms-1405-v(\d+(?:\.\d+)*)-project\.zip/g) || [])).map((m) =>
    m.replace(/^hrms-1405-v/, "").replace(/-project\.zip$/, "")
  );
  let best = "";
  for (const v of vers) if (cmpVersion(v, best) > 0) best = v;
  return best ? { latest: best, source: "zip" } : null;
}

async function readCache(): Promise<UpdateCheckCache | null> {
  const row = await db.systemSetting.findUnique({ where: { key: "update_check" } });
  if (!row) return null;
  try {
    return JSON.parse(row.value) as UpdateCheckCache;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req); // هر کاربر واردشده — برای فوتر/نشان نسخه جدید
    const force = new URL(req.url).searchParams.get("force") === "1";
    const current = (process.env.APP_VERSION || "").trim();

    let cache = await readCache();
    const age = cache ? Date.now() - new Date(cache.checkedAt).getTime() : Infinity;
    // کش منفی: بعد از خطای کامل شبکه تا ۳۰ دقیقه تلاش مجدد نشود (جز با force)
    const negHold = !!cache?.failUntil && !cache.latest && new Date(cache.failUntil).getTime() > Date.now();
    // چک خودکار هر ۲ روز (یا با force) — خطای شبکه = حفظ آخرین کش معتبر
    if (force || !cache || (age > CHECK_TTL_MS && !negHold)) {
      // سه منبع به‌صورت موازی — مقاوم در برابر rate-limit و حذف release ها
      const [apiRes, atomCand, zipCand] = await Promise.all([fromReleasesApi(), fromAtomFeed(), fromRepoZips()]);
      const cands = [apiRes.cand, atomCand, zipCand].filter(Boolean) as Candidate[];
      let fresh: UpdateCheckCache | null = null;
      if (cands.length > 0) {
        // برنده = بیشترین نسخه؛ داده غنی از همه منابعی که همان نسخه را داده‌اند
        let winner = cands[0];
        for (const c of cands.slice(1)) if (cmpVersion(c.latest, winner.latest) > 0) winner = c;
        const rich = cands.filter((c) => cmpVersion(c.latest, winner.latest) === 0);
        const withDate = rich.find((c) => c.latestAt);
        const withNotes = rich.find((c) => c.notes);
        fresh = {
          checkedAt: new Date().toISOString(),
          latest: winner.latest,
          latestAt: withDate?.latestAt || "",
          notes: withNotes?.notes || "",
          url: withNotes?.url || "",
          source: withDate?.source || winner.source,
        };
      } else {
        // همه منابع ناموفق — پیام دقیق‌تر بر اساس علت + تعویق تلاش مجدد (۳۰ دقیقه)
        const why = apiRes.rateLimited
          ? "محدودیت تعداد درخواست به گیت‌هاب (۶۰ در ساعت) — چند دقیقه بعد دوباره بررسی کنید"
          : "دریافت نسخه‌ها از گیت‌هاب ممکن نشد — اتصال اینترنت سرور را بررسی کنید";
        if (cache?.latest) {
          // آخرین نسخه معتبر را نگه می‌داریم (آفلاین = آخرین کش معتبر)؛ فقط زمان تازه می‌شود
          fresh = { ...cache, checkedAt: new Date().toISOString(), failUntil: new Date(Date.now() + FAIL_RETRY_MS).toISOString() };
        } else {
          fresh = {
            checkedAt: new Date().toISOString(),
            latest: "",
            latestAt: "",
            notes: "",
            url: "",
            error: why,
            failUntil: new Date(Date.now() + FAIL_RETRY_MS).toISOString(),
          };
        }
      }
      if (fresh) {
        cache = fresh;
        await db.systemSetting.upsert({
          where: { key: "update_check" },
          update: { value: JSON.stringify(fresh) },
          create: { key: "update_check", value: JSON.stringify(fresh) },
        });
      }
    }

    const latest = cache?.latest || "";
    const updateAvailable = !!(latest && current && cmpVersion(latest, current) > 0);
    return {
      current,
      latest: latest || null,
      updateAvailable,
      checkedAt: cache?.checkedAt || null,
      latestAt: cache?.latestAt || null,
      notes: cache?.notes || "",
      url: cache?.url || "",
      checkError: !latest ? cache?.error || "نسخه‌ای در گیت‌هاب یافت نشد" : null,
      checkedJustNow: force || age === Infinity,
    };
  });
}

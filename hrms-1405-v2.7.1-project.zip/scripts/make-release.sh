#!/usr/bin/env bash
# ================================================================
# سازنده بسته انتشار نسخه‌دار — HRMS 1405
#  ۱) نصب‌کننده تک‌فایل: download/install-hrms-v{V}.sh (+ کپی install-hrms.sh)
#  ۲) آرشیو کامل پروژه:  download/hrms-1405-v{V}-project.zip  (+ کپی بدون نسخه)
#  ۳) راستی‌آزمایی هر دو خروجی
# ================================================================
set -euo pipefail
cd "$(dirname "$0")/.."   # ریشه پروژه

VERSION="${1:-1.5.0}"
OUT_DIR="download"
TMP_TAR="$(mktemp /tmp/hrms-src-XXXXXX.tar.gz)"
TMP_B64="$(mktemp /tmp/hrms-payload-XXXXXX.b64)"
PROBE="$(mktemp -d)"
trap 'rm -rf "$TMP_TAR" "$TMP_B64" "$PROBE"' EXIT

info() { echo "◈ $*"; }
ok()   { echo "✓ $*"; }

mkdir -p "$OUT_DIR"

# ---------- ۱) نصب‌کننده تک‌فایل ----------
info "ساخت نصب‌کننده نسخه ${VERSION}…"
WHITELIST=(
  ./src
  ./public
  ./prisma
  ./scripts/backfill-v4.ts
  ./scripts/backfill-v5.ts
  ./scripts/backfill-v8.ts
  ./scripts/backfill-v9.ts
  ./scripts/backfill-v10.ts
  ./scripts/backfill-v27.ts
  ./scripts/backfill-v271.ts
  ./scripts/purge-demo.ts
  ./package.json
  ./bun.lock
  ./next.config.ts
  ./tsconfig.json
  ./tailwind.config.ts
  ./postcss.config.mjs
  ./components.json
  ./next-env.d.ts
)
for item in "${WHITELIST[@]}"; do
  [ -e "$item" ] || { echo "✗ مورد فهرست سفید یافت نشد: $item"; exit 1; }
done
tar -czf "$TMP_TAR" "${WHITELIST[@]}"

info "کدگذاری بسته (base64)…"
base64 -w 76 "$TMP_TAR" > "$TMP_B64"
SRC_KB=$(( $(du -k "$TMP_TAR" | cut -f1) ))

TEMPLATE="scripts/installer-template.sh"
[ -f "$TEMPLATE" ] || { echo "✗ قالب نصب‌کننده یافت نشد"; exit 1; }

INSTALLER_V="${OUT_DIR}/install-hrms-v${VERSION}.sh"
{
  # نسخه را در قالب تزریق می‌کنیم (اگر قالب مقدار پیش‌فرض دارد، همان می‌ماند)
  sed "s/^APP_VERSION=\".*\"/APP_VERSION=\"${VERSION}\"/; s/^APP_VERSION_FA=\".*\"/APP_VERSION_FA=\"$(echo "$VERSION" | sed 's/0/۰/g; s/1/۱/g; s/2/۲/g; s/3/۳/g; s/4/۴/g; s/5/۵/g; s/6/۶/g; s/7/۷/g; s/8/۸/g; s/9/۹/g; s/\\./\\./g')\"/" "$TEMPLATE"
  echo ""
  echo "# ================== پی‌لود بسته (سورس، base64) =================="
  echo "# این بخش توسط اسکریپت استخراج می‌شود — دستکاری نکنید"
  echo "__PAYLOAD_B64__"
  cat "$TMP_B64"
} > "$INSTALLER_V"
chmod +x "$INSTALLER_V"

# راستی‌آزمایی نصب‌کننده
bash -n "$INSTALLER_V" || { echo "✗ خطای سینتکس"; exit 1; }
grep -q '^__PAYLOAD_B64__$' "$INSTALLER_V" || { echo "✗ مارکر پی‌لود گم شد"; exit 1; }
awk 'f{print} /^__PAYLOAD_B64__$/{f=1}' "$INSTALLER_V" | base64 -d | tar -xzf - -C "$PROBE" 2>/dev/null
[ -f "$PROBE/package.json" ] && [ -f "$PROBE/prisma/schema.prisma" ] && [ -f "$PROBE/public/fonts/BNazanin.woff2" ] \
  || { echo "✗ راستی‌آزمایی استخراج نصب‌کننده ناموفق"; exit 1; }
COUNT_INSTALLER=$(find "$PROBE" -type f | wc -l)
cp "$INSTALLER_V" "${OUT_DIR}/install-hrms.sh"
ok "نصب‌کننده: ${INSTALLER_V} ($(( $(du -k "$INSTALLER_V" | cut -f1) ))KB، ${COUNT_INSTALLER} فایل سورس)"

# ---------- ۲) آرشیو کامل پروژه ----------
info "ساخت آرشیو کامل پروژه نسخه ${VERSION}…"
rm -rf "$PROBE"; PROBE="$(mktemp -d)"
ZIP_V="${OUT_DIR}/hrms-1405-v${VERSION}-project.zip"

zip -r -q "$ZIP_V" \
  src public prisma scripts/backfill-v4.ts scripts/backfill-v5.ts scripts/backfill-v8.ts scripts/backfill-v9.ts scripts/backfill-v10.ts scripts/backfill-v27.ts scripts/backfill-v271.ts scripts/purge-demo.ts \
  scripts/make-installer.sh scripts/make-release.sh scripts/installer-template.sh scripts/build-letter-fonts.py \
  db/custom.db \
  package.json bun.lock next.config.ts tsconfig.json tailwind.config.ts postcss.config.mjs components.json \
  Caddyfile \
  -x "*/node_modules/*" "*/.next/*" "*/tool-results/*"
# فایل .env.example برای توسعه‌دهنده
cat > "$PROBE/.env.example" <<'ENVEOF'
# محیط توسعه — برای استقرار واقعی AUTH_SECRET جدید تولید کنید
DATABASE_URL=file:./db/custom.db
AUTH_SECRET=change-me-to-a-64-char-random-hex
# نسخه نصب‌شده — نمایش در فوتر/صفحه ورود + مبنای چک آپدیت پنل
APP_VERSION=2.7.1
ENVEOF
zip -q "$ZIP_V" -j "$PROBE/.env.example"

# راستی‌آزمایی زیپ (فهرست را یک‌بار می‌گیریم؛ grep با herestring تا pipefail/SIGPIPE خطای کاذب ندهد)
unzip -t -q "$ZIP_V" >/dev/null || { echo "✗ زیپ خراب است"; exit 1; }
ZIP_LISTING="$(unzip -l "$ZIP_V")"
for must in "src/app/page.tsx" "prisma/schema.prisma" "public/fonts/BNazanin.woff2" "public/fonts/NotoNastaliqUrdu.woff2" "db/custom.db" "package.json" ".env.example"; do
  grep -q "$must" <<<"$ZIP_LISTING" || { echo "✗ فایل الزامی در زیپ نیست: $must"; exit 1; }
done
COUNT_ZIP=$(unzip -l "$ZIP_V" | tail -1 | awk '{print $2}')
cp "$ZIP_V" "${OUT_DIR}/hrms-1405-project.zip"
ok "آرشیو: ${ZIP_V} ($(( $(du -k "$ZIP_V" | cut -f1) ))KB، ${COUNT_ZIP} فایل)"

echo ""
echo "✓ بسته انتشار نسخه ${VERSION} آماده شد:"
echo "   نصب‌کننده تک‌فایل: download/install-hrms-v${VERSION}.sh"
echo "   آرشیو کامل:        download/hrms-1405-v${VERSION}-project.zip"

"use client";

// ============================================================
// سند چاپی نامه — مطابق قالب مکاتبات رسمی مرجع کاربر
// (نمونه: نامه ZDX_AD_0507019 — سربرگ زودکس‌گونه)
//
//  ساختار صفحه (مطابق الگو):
//   ┌──────────────────────────────────────────────────────┐
//   │ [تاریخ/شماره]      بِسمِهِ تَعالی      [خطوط+نام+لوگو] │
//   │ موضوع: … (توپیر)                                     │
//   │ [گیرنده] (توپیر)                                      │
//   │ با سلام و احترام + متن بدنه (تراز دوطرفه)             │
//   │ [جدول پیوست: کد/شناسه | شرح | ردیف]                   │
//   │ [مهر امضای دیجیتال]        با تشکر / امضاکننده / سمت │
//   │ پابرگ: نشانی (راست) — تماس‌ها (چپ) به‌رنگ آبی        │
//   └──────────────────────────────────────────────────────┘
//
//  سه حالت سربرگ:
//   ۱) تصویر سربرگ رسمی شرکت (PNG آپلودی A4/A5) — پس‌زمینه صفحه؛
//      گرافیک سربرگ/پابرگ دیجیتال حذف می‌شود (همه در تصویر است) و
//      فقط تاریخ/شماره (بالا-چپ) + محتوا + امضاها چاپ می‌شوند.
//   ۲) سربرگ دیجیتال — لوگو/خطوط طلایی+آبی/پابرگ از برندینگ
//   ۳) بدون سربرگ — برای چاپ روی کاغذ سربرگ‌دار پیش‌چاپ
//  سایز کاغذ: A4 (۲۱۰×۲۹۷) و A5 (۱۴۸×۲۱۰) — @page هماهنگ.
//  تاریخ/شماره/کدها با ارقام لاتین (مطابق نامه مرجع).
// ============================================================

import { isoToJalaliStr, toFaDigits } from "@/lib/jalali";
import { sanitizeLetterHtml } from "@/lib/rich-html";
import { qrCodeSvg } from "@/lib/qrcode";

export interface LetterPrintItem {
  title: string;
  code: string;
}

export interface LetterPrintData {
  number: string;
  title: string;
  body: string;
  bodyHtml?: string | null; // متن غنی (جدول/قالب‌بندی) — نامه دستی
  status: string; // PENDING | APPROVED | REJECTED
  source?: string; // REQUEST | MANUAL
  recipient?: string;
  decidedBy?: string;
  decidedAt?: string | null; // ISO
  decisionNote?: string;
  signatureCode?: string | null;
  employeeName: string;
  personnelCode?: string;
  department?: string;
  signerName?: string;
  signerTitle?: string;
  items?: LetterPrintItem[];
  createdAt?: string; // ISO
}

export interface LetterPrintCompany {
  name: string;
  nationalId?: string;
  address?: string;
  logo?: string; // data URL
  phone?: string;
  mobile?: string;
  website?: string;
  email?: string;
}

export type LetterPaperSize = "A4" | "A5";

export interface LetterPrintOptions {
  letterhead: boolean; // سربرگ رسمی (تصویر) یا دیجیتال — false = بدون سربرگ
  paperSize?: LetterPaperSize; // اندازه کاغذ (پیش‌فرض A4)
  letterheadImage?: string; // data URL تصویر سربرگ رسمی (حالت letterhead:true)
  letterheadTopMm?: number; // فاصله محتوا از بالا وقتی تصویر سربرگ فعال است
  letterheadBottomMm?: number; // فاصله محتوا از پایین
  signerSignature?: string; // تصویر امضای دست‌نویس امضاکننده (data URL) — فقط با سربرگ چاپ می‌شود
  sealImage?: string; // تصویر مهر سازمان/شخص (data URL) — فقط با سربرگ چاپ می‌شود
  signatureSizeMm?: number; // قد تصویر امضا در چاپ (mm) — پیش‌فرض ۱۱ — کنترل از تنظیمات
  sealSizeMm?: number; // قد تصویر مهر در چاپ (mm) — پیش‌فرض ۱۳ — کنترل از تنظیمات
  showDigitalSignature?: boolean; // نمایش مهر امضای دیجیتال (پیش‌فرض true — کنترل از اطلاعات پایه)
  baseUrl?: string; // برای فایل دانلودی (آدرس مطلق سرور برای فونت/راستی‌آزمایی)
  embeddedFonts?: Record<string, string>; // فونت‌های base64 (فایل خودکفا)
}

/** ابعاد کاغذ (میلی‌متر) + حاشیه‌های جانبی */
const PAGE_GEO: Record<LetterPaperSize, { w: number; h: number; side: number; label: string }> = {
  A4: { w: 210, h: 297, side: 16, label: "A4" },
  A5: { w: 148, h: 210, side: 12, label: "A5" },
};

const STATUS_LABELS: Record<string, string> = {
  PENDING: "در انتظار تأیید",
  APPROVED: "تأییدشده",
  REJECTED: "ردشده",
};

/** رنگ سازمانی قالب مرجع: طلایی + آبی */
const GOLD = "#F0B010";
const BLUE = "#3050A0";

function esc(s: string): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** تاریخ جلالی با ارقام لاتین (مطابق الگو: 1405/07/12) */
function letterDateLatin(iso?: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  return isNaN(d.getTime()) ? "" : isoToJalaliStr(d);
}

/** تبدیل ارقام فارسی/عربی به لاتین — شماره نامه همیشه با ارقام لاتین چاپ می‌شود */
function toEnDigits(s: string): string {
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  const ar = "٠١٢٣٤٥٦٧٨٩";
  return String(s ?? "").replace(/[۰-۹٠-٩]/g, (d) => {
    const i = fa.indexOf(d);
    return String(i >= 0 ? i : ar.indexOf(d));
  });
}

/** تاریخ رسمی نامه: تاریخ صدور/تأیید وگرنه تاریخ ثبت — با ارقام فارسی (۱۴۰۵/۰۷/۱۲) */
function letterDate(l: LetterPrintData): string {
  const iso = l.status === "APPROVED" && l.decidedAt ? l.decidedAt : l.createdAt;
  return toFaDigits(letterDateLatin(iso));
}

/** تاریخ + ساعت جلالی با ارقام فارسی — ۱۴۰۵/۰۷/۱۳ — ۱۴:۳۰ */
function faDateTimeFa(iso?: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return toFaDigits(`${isoToJalaliStr(d)} — ${hh}:${mm}`);
}

function fontFaces(baseUrl?: string, embedded?: Record<string, string>): string {
  // embedded: نام فایل → data URL (فایل دانلودی خودکفا — فونت داخل فایل)
  // LetterLatin: جفت لاتین B Nazanin (سریف) با size-adjust — حروف لاتین متن ۱۰pt وقتی فارسی ۱۲pt است
  const spec: { file: string; family: string; weight: number; adjust?: number }[] = [
    { file: "Vazirmatn-Regular.woff2", family: "Vazirmatn", weight: 400 },
    { file: "Vazirmatn-Medium.woff2", family: "Vazirmatn", weight: 500 },
    { file: "Vazirmatn-SemiBold.woff2", family: "Vazirmatn", weight: 600 },
    { file: "Vazirmatn-Bold.woff2", family: "Vazirmatn", weight: 700 },
    { file: "NotoNastaliqUrdu.woff2", family: "NotoNastaliq", weight: 400 },
    { file: "BNazanin.woff2", family: "B Nazanin", weight: 400 },
    { file: "BTitr.woff2", family: "B Titr", weight: 700 },
    { file: "LetterLatin-Regular.woff2", family: "LetterLatin", weight: 400, adjust: 83.33 },
    { file: "LetterLatin-Bold.woff2", family: "LetterLatin", weight: 700, adjust: 83.33 },
  ];
  return spec
    .map(({ file, family, weight, adjust }) => {
      const src = embedded && embedded[file]
        ? `url('${embedded[file]}')`
        : `url('${(baseUrl || "").replace(/\/$/, "")}/fonts/${file}')`;
      return `@font-face { font-family: '${family}'; src: ${src} format('woff2'); font-weight: ${weight};${adjust ? ` size-adjust: ${adjust}%;` : ""} font-display: block; }`;
    })
    .join("\n");
}

const FONT_FILES = [
  "Vazirmatn-Regular.woff2",
  "Vazirmatn-Medium.woff2",
  "Vazirmatn-SemiBold.woff2",
  "Vazirmatn-Bold.woff2",
  "NotoNastaliqUrdu.woff2",
  "BNazanin.woff2",
  "BTitr.woff2",
  "LetterLatin-Regular.woff2",
  "LetterLatin-Bold.woff2",
];

/** خانواده متن نامه — فارسی B Nazanin 12pt، حروف لاتین خودکار به LetterLatin (۱۰pt با size-adjust)
 *  (B Nazanin گلیف حروف لاتین ندارد → مرورگر نویسه‌های لاتین را از LetterLatin می‌گیرد) */
const LETTER_BODY_FONT = "'B Nazanin', 'LetterLatin', 'Vazirmatn', serif";

/** فونت تیتر نامه — موضوع/گیرنده/«با سلام و احترام» با B Titr چاپ می‌شوند
 *  (فونت تیتر استاندارد مکاتبات رسمی — فقط وزن Bold دارد؛ لاتین از LetterLatin) */
const LETTER_TITLE_FONT = "'B Titr', 'LetterLatin', 'Vazirmatn', serif";

/** عبارت احترام ابتدای نامه — «با سلام و احترام» با فاصله‌گذاری آزاد (باسلام/با سلام و…)
 *  این عبارت در ابتدای متن (ساده یا غنی) با فونت تیتر چاپ می‌شود */
const GREETING_RE = /^(با\s*سلام(?:\s*و\s*احترام)?[،,؛;:]?)/;

/** درج <span class="greet"> دور عبارت احترام در ابتدای متن ساده (پیش از escape) */
function bodyTextHtml(body: string): string {
  const m = body.match(/^\s*/) || [""];
  const lead = m[0];
  const rest = body.slice(lead.length);
  const g = rest.match(GREETING_RE);
  if (!g) return esc(body);
  return `${esc(lead)}<span class="greet">${esc(g[1])}</span>${esc(rest.slice(g[1].length))}`;
}

/** درج <span class="greet"> دور عبارت احترام در ابتدای متن غنی (پس از پاک‌سازی)
 *  از روی تگ‌های آغازین (p/b/div و…) رد می‌شود تا به نخستین متن برسد */
function wrapGreetingInHtml(html: string): string {
  const lead = html.match(/^(?:\s|<[^>]+>)*/);
  const idx = lead ? lead[0].length : 0;
  const rest = html.slice(idx);
  const g = rest.match(GREETING_RE);
  if (!g) return html;
  return `${html.slice(0, idx)}<span class="greet">${g[1]}</span>${rest.slice(g[1].length)}`;
}

/** فونت‌های سرور را به data URL تبدیل می‌کند — برای فایل دانلودی خودکفا (بدون وابستگی به سرور/CORS) */
async function fetchEmbeddedFonts(baseUrl: string): Promise<Record<string, string> | undefined> {
  try {
    const out: Record<string, string> = {};
    await Promise.all(
      FONT_FILES.map(async (f) => {
        const res = await fetch(`${baseUrl.replace(/\/$/, "")}/fonts/${f}`);
        if (!res.ok) throw new Error(`font ${f}: ${res.status}`);
        const buf = await res.arrayBuffer();
        const bytes = new Uint8Array(buf);
        let bin = "";
        const CHUNK = 0x8000;
        for (let i = 0; i < bytes.length; i += CHUNK) {
          bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
        }
        out[f] = `data:font/woff2;base64,${btoa(bin)}`;
      })
    );
    return out;
  } catch {
    return undefined; // fallback: آدرس مطلق سرور
  }
}

// ---------- بلوک‌های سند ----------

/** خطوط تاریخ/شماره — مشترک هر سه حالت سربرگ
 *  تاریخ: ارقام فارسی (۱۴۰۵/۰۷/۱۳) • شماره نامه: ارقام لاتین • فونت B Nazanin */
function refLines(l: LetterPrintData): string {
  return `
      <p class="ref-line"><span class="ref-label">تاریخ:</span> <b class="ref-value">${esc(letterDate(l) || "—")}</b></p>
      <p class="ref-line"><span class="ref-label">شماره نامه:</span> <b class="ref-value" dir="ltr">${esc(toEnDigits(l.number))}</b></p>`;
}

/** سربرگ دیجیتال مطابق الگو: لوگو+نام+خطوط (راست)، بِسمِهِ تَعالی (وسط)، تاریخ/شماره (چپ) */
function letterheadHtml(c: LetterPrintCompany, l: LetterPrintData): string {
  const logo = c.logo
    ? `<img src="${esc(c.logo)}" alt="لوگو" class="lh-logo" />`
    : `<div class="lh-logo lh-logo-fallback">${esc((c.name || "س").trim().charAt(0))}</div>`;
  return `
  <header class="letterhead">
    <div class="lh-brand">
      <div class="lh-lines" aria-hidden="true"><span class="line-gold"></span><span class="line-blue"></span></div>
      <p class="lh-company">${esc(c.name || "")}</p>
      ${logo}
    </div>
    <p class="besm">بِسمِهِ تَعالی</p>
    <div class="lh-refs">
      ${refLines(l)}
    </div>
  </header>`;
}

/** بلوک تاریخ/شماره برای حالت بدون سربرگ (چاپ روی کاغذ پیش‌چاپ) — همان جایگاه چپ */
function refsPlainHtml(l: LetterPrintData): string {
  return `
  <header class="letterhead plain">
    <div class="lh-brand-plain"></div>
    <p class="besm">بِسمِهِ تَعالی</p>
    <div class="lh-refs">
      ${refLines(l)}
    </div>
  </header>`;
}

/** تاریخ/شماره در حالت تصویر سربرگ رسمی — لایه شناور بالا-چپ روی تصویر (مطابق الگو)
 *  + «بِسمِهِ تَعالی» نستعلیق وسط — ۳ اینتر پایین‌تر از لبه صفحه (زیر نوار گرافیک سربرگ)
 *  تصویر سربرگ این متن را ندارد، پس همیشه چاپ می‌شود */
function refsOverlayHtml(l: LetterPrintData): string {
  return `
  <p class="besm besm-overlay">بِسمِهِ تَعالی</p>
  <div class="refs-overlay">
      ${refLines(l)}
  </div>`;
}

/** بلوک موضوع/گیرنده — مطابق الگو: موضوع و گیرنده توپیر، راست‌چین */
function subjectHtml(l: LetterPrintData): string {
  const recipient = (l.recipient || "").trim();
  return `
  <div class="subject-block">
    <p class="subject">موضوع: <span>${esc(l.title)}</span></p>
    ${recipient ? `<p class="recipient">${esc(recipient)}</p>` : ""}
  </div>`;
}

/** جدول پیوست نامه — ستون‌ها مطابق الگو: کد/شناسه | شرح | ردیف (سربرگ خاکستری) */
function itemsTableHtml(items: LetterPrintItem[]): string {
  if (!items || items.length === 0) return "";
  const rows = items
    .map(
      (it, i) => `
      <tr>
        <td class="it-code">${it.code ? `<span dir="ltr">${esc(it.code)}</span>` : "—"}</td>
        <td class="it-title">${esc(it.title || "—")}</td>
        <td class="it-row">${i + 1}</td>
      </tr>`
    )
    .join("");
  return `
  <table class="items-table">
    <thead>
      <tr><th>کد/شناسه</th><th class="th-title">شرح</th><th>ردیف</th></tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>`;
}

/** مهر امضای دیجیتال — فشرده و کم‌ارتفاع — سمت راست صفحه
 *  نامه دستی: امضاکننده ثبت‌شده (signerName/signerTitle)؛ نامه قالبی: مرجع تأییدکننده
 *  راستی‌آزمایی: QR درون‌خطی (مولد بومی — بدون CDN) به‌جای لینک متنی */
function digitalSignatureHtml(l: LetterPrintData, baseUrl: string): string {
  const code = (l.signatureCode || "").toUpperCase();
  const manual = l.source === "MANUAL";
  const name = manual ? l.signerName || l.decidedBy || "—" : l.decidedBy || "—";
  const roleLabel = manual
    ? l.signerTitle || "امضاکننده"
    : `مرجع تأییدکننده — ${STATUS_LABELS[l.status] || l.status}`;
  const when = faDateTimeFa(l.decidedAt);
  const verifyUrl = `${baseUrl}/api/letters/verify?code=${code.replace(/-/g, "")}`;
  let qr = "";
  try {
    qr = qrCodeSvg(verifyUrl, { dark: "#0f172a" });
  } catch {
    qr = ""; // متن بیش‌ازحد بلند — بازگشت به لینک متنی
  }
  return `
  <div class="digi-sig">
    <div class="ds-head">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="ds-icon"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
      <span>امضای دیجیتال</span>
    </div>
    <div class="ds-flex">
      ${qr ? `<div class="ds-qr">${qr}</div>` : ""}
      <div class="ds-info">
        <p class="ds-name">${esc(name)}</p>
        <p class="ds-role">${esc(roleLabel)}${when ? ` — <span>${esc(when)}</span>` : ""}</p>
        <p class="ds-code" dir="ltr">${esc(code)}</p>
      </div>
    </div>
    ${
      qr
        ? `<p class="ds-verify">اسکن برای راستی‌آزمایی امضای دیجیتال</p>`
        : `<p class="ds-verify">راستی‌آزمایی: <span dir="ltr">${esc(verifyUrl)}</span></p>`
    }
  </div>`;
}

/** ناحیه امضا — مطابق الگو: امضای دست‌نویس/امضاکننده پایین-چپ، مهر امضای دیجیتال سمت راست
 *  تصویر امضای دست‌نویس و تصویر مهر سازمان/شخص فقط در نسخه «با سربرگ» چاپ می‌شوند —
 *  در نسخه «بدون سربرگ» (چاپ روی کاغذ پیش‌چاپ) فقط نام (و سمت) امضاکننده درج می‌شود */
function signaturesHtml(l: LetterPrintData, baseUrl: string, signerSignature: string | undefined, sealImage: string | undefined, letterhead: boolean, showDigitalSignature = true): string {
  const approved = l.status === "APPROVED" && !!l.signatureCode;
  const manual = l.source === "MANUAL";
  // امضاکننده نامه: نامه دستی → امضاکننده ثبت‌شده؛ نامه قالبی تأییدشده → تأییدکننده صدور
  const signerName = approved
    ? manual
      ? l.signerName || l.decidedBy || "—"
      : l.decidedBy || "—"
    : l.employeeName || "—";
  const signerTitle = approved && manual ? l.signerTitle || "" : "";
  const pendingLabel = approved ? "" : "امضای درخواست‌کننده";
  // تصاویر امضا/مهر فقط با سربرگ (طبق قواعد مکاتبات رسمی)
  const sigImg = letterhead && signerSignature
    ? `<img src="${esc(signerSignature)}" alt="امضا" class="sg-sig" />`
    : "";
  const sealImg = letterhead && sealImage
    ? `<img src="${esc(sealImage)}" alt="مهر" class="sg-seal" />`
    : "";

  return `
  <div class="sign-area">
    ${approved && showDigitalSignature ? digitalSignatureHtml(l, baseUrl) : ""}
    <div class="sign-spacer"></div>
    <div class="signer">
      <p class="sg-thanks">با تشکر</p>
      <div class="sg-flex">
        ${sigImg}
        <div class="sg-text">
          ${!approved ? `<div class="sg-line"></div>` : ""}
          <p class="sg-name">${esc(signerName)}</p>
          ${signerTitle ? `<p class="sg-title">${esc(signerTitle)}</p>` : ""}
        </div>
        ${sealImg}
      </div>
      ${pendingLabel ? `<p class="sg-pending">${esc(pendingLabel)}</p>` : ""}
      ${!approved && l.personnelCode ? `<p class="sg-meta">کد پرسنلی <span dir="ltr">${esc(toEnDigits(l.personnelCode))}</span></p>` : ""}
    </div>
  </div>`;
}

/** اعلان وضعیت برای نامه‌های تعیین‌تکلیف‌نشده/ردشده */
function statusNoticeHtml(l: LetterPrintData): string {
  if (l.status === "PENDING") {
    return `<div class="notice notice-pending">این نامه هنوز تأیید نشده است و نسخه رسمی محسوب نمی‌شود — صرفاً جهت بازبینی/پیش‌نمایش است.</div>`;
  }
  if (l.status === "REJECTED") {
    return `<div class="notice notice-rejected">این نامه توسط مرجع تأییدکننده رد شده است${l.decisionNote ? ` — دلیل: ${esc(l.decisionNote)}` : ""}.</div>`;
  }
  return "";
}

/** پابرگ مطابق الگو: نشانی (راست) — لوگوی کوچک + تماس‌ها (چپ) همه به‌رنگ آبی */
function footerHtml(c: LetterPrintCompany): string {
  const iconPin = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="f-icon"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>`;
  const iconMobile = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="f-icon"><rect width="14" height="20" x="5" y="2" rx="2" ry="2"/><path d="M12 18h.01"/></svg>`;
  const iconPhone = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="f-icon"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>`;
  const iconGlobe = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="f-icon"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`;
  const iconMail = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="f-icon"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>`;

  // لوگوی کوچک پابرگ — مطابق الگو کنار تماس‌ها (لوگو یا حرف اول نام شرکت)
  const miniLogo = c.logo
    ? `<img src="${esc(c.logo)}" alt="" class="f-logo" />`
    : `<span class="f-logo f-logo-text">${esc((c.name || "س").trim().charAt(0))}</span>`;

  const contacts: string[] = [];
  if (c.mobile) contacts.push(`${iconMobile}<span dir="ltr">${esc(c.mobile)}</span>`);
  if (c.phone) contacts.push(`${iconPhone}<span dir="ltr">${esc(c.phone)}</span>`);
  if (c.website) contacts.push(`${iconGlobe}<span dir="ltr">${esc(c.website)}</span>`);
  if (c.email) contacts.push(`${iconMail}<span dir="ltr">${esc(c.email)}</span>`);
  const nid = c.nationalId ? `<span class="f-nid">شناسه ملی <span dir="ltr">${esc(c.nationalId)}</span></span>` : "";

  return `
  <footer class="lh-footer">
    <div class="f-address">${iconPin}<span>${esc(c.address || "")}</span>${nid}</div>
    <div class="f-contact-side">
      ${contacts.length ? `<div class="f-contacts">${contacts.map((x) => `<span class="f-item">${x}</span>`).join("")}</div>` : ""}
    </div>
    ${miniLogo}
  </footer>`;
}

// ---------- سند کامل ----------

/** ساخت سند HTML کامل RTL — A4/A5 با فونت‌های لوکال (وزیرمتن + نستعلیق) */
export function buildLetterDocument(letter: LetterPrintData, company: LetterPrintCompany, opts: LetterPrintOptions): string {
  const baseUrl = (opts.baseUrl || "").replace(/\/$/, "");
  const size: LetterPaperSize = opts.paperSize === "A5" ? "A5" : "A4";
  const geo = PAGE_GEO[size];
  // شماره نامه همیشه با ارقام لاتین (عنوان/نوار ابزار/خطوط ارجاع) — یکجا نرمال‌سازی می‌شود
  const letterNumber = toEnDigits(letter.number || "");
  // حالت تصویر سربرگ رسمی — فقط وقتی letterhead فعال و تصویر موجود است
  const bgImage = opts.letterhead ? (opts.letterheadImage || "").trim() : "";
  const useBg = !!bgImage;
  const bgTop = Math.max(5, Math.round(opts.letterheadTopMm ?? 42));
  const bgBottom = Math.max(5, Math.round(opts.letterheadBottomMm ?? 16));

  const head = useBg ? refsOverlayHtml(letter) : opts.letterhead ? letterheadHtml(company, letter) : refsPlainHtml(letter);
  const subject = subjectHtml(letter);
  const table = itemsTableHtml(letter.items || []);
  const notices = statusNoticeHtml(letter);
  const sigs = signaturesHtml(letter, baseUrl, opts.signerSignature, opts.sealImage, opts.letterhead, opts.showDigitalSignature !== false);
  // متن غنی (جدول/قالب‌بندی نامه دستی) — پاک‌سازی مجدد سمت چاپ؛ در غیاب آن متن ساده
  // عبارت احترام ابتدای متن («با سلام و احترام») با فونت تیتر (B Titr) چاپ می‌شود
  const richBody = sanitizeLetterHtml(letter.bodyHtml || "");
  const bodyBlock = richBody
    ? `<div class="body-rich">${wrapGreetingInHtml(richBody)}</div>`
    : `<div class="body-text">${bodyTextHtml(letter.body)}</div>`;
  // در حالت تصویر سربرگ، پابرگ دیجیتال حذف می‌شود (پابرگ در خود تصویر است)
  const footer = useBg ? "" : opts.letterhead ? footerHtml(company) : "";
  const modeLabel = useBg ? "روی سربرگ رسمی شرکت" : opts.letterhead ? "با سربرگ دیجیتال" : "بدون سربرگ";
  const kindLabel = letter.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه";

  // استایل صفحه بر اساس حالت/سایز
  const pageBg = useBg
    ? `background: #fff url('${bgImage}') top center / 100% 100% no-repeat; padding: ${bgTop}mm ${geo.side}mm ${bgBottom}mm; -webkit-print-color-adjust: exact; print-color-adjust: exact;`
    : size === "A5"
      ? "padding: 8mm 12mm 6mm;"
      : "padding: 10mm 16mm 8mm;";
  const printPadding = useBg
    ? `padding: ${bgTop}mm ${geo.side}mm ${bgBottom}mm;`
    : size === "A5"
      ? "padding: 8mm 12mm 6mm;"
      : "padding: 10mm 14mm;";
  const refsPos = size === "A5" ? "top: 5mm; left: 12mm;" : "top: 6mm; left: 16mm;";

  // سایز تصویر امضا/مهر — تنظیم از «امضاکنندگان» تنظیمات (mm)
  // A4 مستقیم؛ A5 به‌میزان متناسب کوچک‌تر (۸۲٪ — هم‌ساز با مقیاس فونت A5)
  const sigMm = Math.min(40, Math.max(6, Math.round(opts.signatureSizeMm ?? 11)));
  const sealMm = Math.min(40, Math.max(6, Math.round(opts.sealSizeMm ?? 13)));
  const sigMm5 = Math.max(6, Math.round(sigMm * 0.82));
  const sealMm5 = Math.max(6, Math.round(sealMm * 0.82));
  const sizeCss = `
/* ---------- سایز چاپ امضا/مهر (تنظیمات) — قد به میلی‌متر ---------- */
.sg-sig { height: ${sigMm}mm; max-width: ${Math.round(sigMm * 3.1)}mm; }
.sg-seal { height: ${sealMm}mm; max-width: ${Math.round(sealMm * 1.25)}mm; }
.a5 .sg-sig { height: ${sigMm5}mm; max-width: ${Math.round(sigMm5 * 3.1)}mm; }
.a5 .sg-seal { height: ${sealMm5}mm; max-width: ${Math.round(sealMm5 * 1.25)}mm; }
`;

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>${esc(letter.title)} — ${esc(letterNumber)}</title>
<style>
${fontFaces(baseUrl, opts.embeddedFonts)}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { background: #eef2f5; }
body { font-family: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif; direction: rtl; }
@page { size: ${size}; margin: 0; }
.page { background: #fff; width: ${geo.w}mm; min-height: ${geo.h}mm; margin: 8mm auto; box-shadow: 0 2px 14px rgba(0,0,0,.14); display: flex; flex-direction: column; position: relative; ${pageBg} }
/* حالت تصویر سربرگ رسمی: تا آماده‌شدن کامل تصویر پس‌زمینه صفحه مخفی می‌ماند
   (حذف نمایش لحظه‌ای «صفحه سفید بدون سربرگ» پیش از لود کامل بکگراند نامه) */
.page.img-bg { visibility: hidden; }
.page.img-bg.bg-ready { visibility: visible; }

/* ---------- سربرگ مطابق الگو: لوگو/نام/خطوط راست — بِسمِه‌تعالی وسط — تاریخ/شماره چپ ---------- */
.letterhead { display: flex; align-items: flex-start; justify-content: space-between; gap: 4mm; min-height: 22mm; position: relative; }
.lh-brand { display: flex; align-items: center; gap: 3mm; width: 38%; max-width: 40%; }
.lh-brand-plain { width: 34%; }
.lh-lines { width: 16mm; flex-shrink: 0; display: flex; flex-direction: column; gap: 1.2mm; }
.line-gold { height: 2.2pt; background: ${GOLD}; border-radius: 1pt; }
.line-blue { height: 1.1pt; background: ${BLUE}; border-radius: .5pt; }
.lh-company { flex: 1; font-size: 12pt; font-weight: 700; color: #0f172a; line-height: 1.55; text-align: right; }
.lh-logo { width: 14mm; height: 14mm; object-fit: contain; border-radius: 2mm; flex-shrink: 0; }
.lh-logo-fallback { background: ${GOLD}; color: #fff; font-size: 18pt; font-weight: 700; display: flex; align-items: center; justify-content: center; border-radius: 2mm; }
.besm { position: absolute; left: 50%; top: 1mm; transform: translateX(-50%); white-space: nowrap; font-family: 'NotoNastaliq', 'Vazirmatn', serif; font-size: 14.5pt; line-height: 2.4; color: #1e293b; }
/* روی تصویر سربرگ رسمی — نستعلیق وسط، ۳ اینتر پایین‌تر از لبه صفحه
   (هر اینتر = یک سطر متن نامه ≈ ۸.۷mm → ۲.۵mm + ۳×۸.۷mm ≈ ۲۸.۵mm — زیر نوار گرافیک سربرگ) */
.besm-overlay { position: absolute; left: 50%; top: 28.5mm; transform: translateX(-50%); z-index: 2; }
.lh-refs { width: 34%; padding-top: 1mm; text-align: right; }
.ref-line { font-family: 'B Nazanin', 'LetterLatin', 'Vazirmatn', serif; font-size: 11.5pt; line-height: 2; color: #111; text-align: right; }
.ref-label { font-weight: 700; }
.ref-value { font-weight: 700; }

/* ---------- لایه تاریخ/شماره روی تصویر سربرگ رسمی (بالا-چپ مطابق الگو) ---------- */
.refs-overlay { position: absolute; ${refsPos} z-index: 2; text-align: right; }

/* ---------- موضوع/گیرنده (B Titr — فونت تیتر مکاتبات رسمی) ----------
    فاصله بین دو خط موضوع/گیرنده فشرده است (درخواست کاربر) */
.subject-block { margin-top: 7mm; text-align: right; }
.subject { font-family: ${LETTER_TITLE_FONT}; font-size: 12pt; font-weight: 700; color: #0f172a; line-height: 1.6; }
.subject span { font-weight: 700; }
.recipient { font-family: ${LETTER_TITLE_FONT}; font-size: 12pt; font-weight: 700; color: #1e293b; margin-top: 1mm; line-height: 1.6; }

/* ---------- متن بدنه — B Nazanin 12 (لاتین ۱۰ با size-adjust LetterLatin) ----------
    عبارت احترام ابتدای متن («با سلام و احترام») با فونت تیتر B Titr */
.body-text { margin-top: 5mm; font-family: ${LETTER_BODY_FONT}; font-size: 12pt; line-height: 2.05; font-weight: 400; color: #1f2937; white-space: pre-wrap; text-align: justify; flex: 1; }
.greet { font-family: ${LETTER_TITLE_FONT}; font-weight: 700; }

/* ---------- متن غنی (جدول/قالب‌بندی نامه دستی) — B Nazanin ---------- */
.body-rich { margin-top: 5mm; font-family: ${LETTER_BODY_FONT}; font-size: 12pt; line-height: 2; font-weight: 400; color: #1f2937; text-align: justify; flex: 1; }
.body-rich p { margin: 0 0 3.5mm; }
.body-rich ul, .body-rich ol { margin: 2mm 7mm 4mm 0; padding-right: 7mm; }
.body-rich li { margin-bottom: 1mm; }
.body-rich blockquote { border-right: 1pt solid #cbd5e1; margin: 2mm 0 3mm; padding: 1mm 4mm 1mm 0; color: #475569; }
.body-rich h3, .body-rich h4 { font-weight: 700; margin: 3mm 0 2mm; }
.body-rich b, .body-rich strong { font-weight: 700; }
.body-rich table { direction: rtl; width: 100%; border-collapse: collapse; margin: 3mm 0 5mm; border: .6pt solid #c6c6c6; }
.body-rich thead th { background: #dcdcdc; font-family: ${LETTER_BODY_FONT}; font-size: 11pt; font-weight: 700; color: #111; padding: 1.8mm 2.6mm; border: .6pt solid #bfbfbf; text-align: center; }
.body-rich td { font-family: ${LETTER_BODY_FONT}; font-size: 11pt; padding: 1.6mm 2.6mm; border: .6pt solid #cccccc; vertical-align: middle; }
.body-rich td:empty::after, .body-rich th:empty::after { content: "\\2003"; }

/* ---------- جدول پیوست (مطابق الگو: خطوط ظریف خاکستری + سربرگ خاکستری روشن) ---------- */
.items-table { width: 100%; border-collapse: collapse; margin-top: 4mm; border: .6pt solid #c6c6c6; }
.items-table th { background: #dcdcdc; font-family: ${LETTER_BODY_FONT}; font-size: 11pt; font-weight: 700; color: #111; padding: 2mm 3mm; border: .6pt solid #bfbfbf; text-align: center; }
.items-table td { font-family: ${LETTER_BODY_FONT}; font-size: 11pt; padding: 1.9mm 3mm; border: .6pt solid #cccccc; color: #1f2937; vertical-align: middle; }
.it-code { width: 26%; text-align: center; font-weight: 600; }
.it-title { text-align: right; }
.th-title { width: 58%; }
.it-row { width: 11%; text-align: center; color: #333; font-weight: 600; }

/* ---------- اعلان وضعیت ---------- */
.notice { margin-top: 5mm; padding: 2.5mm 4mm; border-radius: 1.5mm; font-size: 9.5pt; line-height: 1.9; }
.notice-pending { background: #fefce866; border: 1pt dashed #d97706aa; color: #92400e; }
.notice-rejected { background: #fef2f266; border: 1pt dashed #dc2626aa; color: #991b1b; }

/* ---------- ناحیه امضا — مهر دیجیتال سمت راست، امضای دست‌نویس پایین-چپ ----------
    مشخصات امضاکننده: فاصله بین خطوط ۱.۱۵ (درخواست کاربر)
    تصویر امضای دست‌نویس: کنار نام امضاکننده (ردیف افقی)
    تصویر مهر سازمان/شخص: سمت چپ نام — فقط در نسخه با سربرگ */
.sign-area { margin-top: 10mm; margin-bottom: 9mm; display: flex; align-items: flex-end; gap: 6mm; }
.sign-spacer { flex: 1; }
.signer { text-align: center; min-width: 40mm; padding-bottom: 1mm; font-family: ${LETTER_BODY_FONT}; }
.signer p { line-height: 1.15; }
.sg-flex { display: flex; align-items: center; justify-content: center; gap: 3mm; }
.sg-text { text-align: center; }
.sg-sig { height: 11mm; max-width: 34mm; object-fit: contain; flex-shrink: 0; }
.sg-seal { height: 13mm; max-width: 16mm; object-fit: contain; flex-shrink: 0; opacity: .96; }
.sg-thanks { font-size: 11pt; font-weight: 700; color: #0f172a; }
.sg-line { border-top: 1pt dotted #64748b; margin: 12mm 4mm 1.5mm; }
.sg-name { font-size: 11pt; font-weight: 700; color: #1e293b; margin-top: 1.2mm; }
.sg-title { font-size: 10pt; color: #475569; margin-top: .4mm; }
.sg-pending { font-size: 8.5pt; color: #64748b; margin-top: .4mm; }
.sg-meta { font-size: 8pt; color: #94a3b8; margin-top: .3mm; }

/* ---------- مهر امضای دیجیتال (QR راستی‌آزمایی + مشخصات — کم‌ارتفاع) ---------- */
.digi-sig { border: 1pt double ${BLUE}; border-radius: 1.6mm; padding: .8mm 1.5mm; background: #f5f7fd80; text-align: center; max-width: 42mm; line-height: 1.45; }
.ds-head { display: flex; align-items: center; justify-content: center; gap: 1.1mm; color: ${BLUE}; font-size: 7pt; font-weight: 700; }
.ds-icon { width: 2.6mm; height: 2.6mm; }
.ds-flex { display: flex; align-items: center; justify-content: center; gap: 1.6mm; margin-top: .5mm; }
.ds-qr { width: 17mm; height: 17mm; flex-shrink: 0; background: #fff; border: .4pt solid #cbd5e1; border-radius: 1mm; padding: .4mm; }
.ds-qr svg { display: block; width: 100%; height: 100%; }
.ds-info { text-align: center; flex: 1; min-width: 0; }
.ds-name { font-size: 8pt; color: #0f172a; font-weight: 700; margin-top: .3mm; }
.ds-role { font-size: 6pt; color: #64748b; margin-top: .1mm; }
.ds-code { font-family: ui-monospace, 'Courier New', monospace; font-size: 7.5pt; font-weight: 700; color: ${BLUE}; letter-spacing: .7px; margin-top: .4mm; direction: ltr; }
.ds-verify { font-size: 6pt; color: #64748b; margin-top: .4mm; }
.ds-verify span { font-family: ui-monospace, monospace; direction: ltr; unicode-bidi: embed; }

/* ---------- پابرگ (نشانی راست — تماس‌ها چپ + لوگوی کوچک، آبی مطابق الگو) ---------- */
.lh-footer { margin-top: 16mm; border-top: .8pt solid ${BLUE}44; padding-top: 2.5mm; display: flex; justify-content: space-between; align-items: center; gap: 6mm; font-size: 8.5pt; color: ${BLUE}; flex-wrap: wrap; }
.f-address { display: flex; align-items: center; gap: 1.8mm; font-weight: 600; max-width: 52%; }
.f-contact-side { display: flex; align-items: center; gap: 4mm; }
.f-contacts { display: flex; align-items: center; gap: 4mm; flex-wrap: wrap; }
.f-item { display: inline-flex; align-items: center; gap: 1.5mm; }
.f-icon { width: 3.6mm; height: 3.6mm; flex-shrink: 0; }
.f-nid { font-size: 8pt; opacity: .85; }
.f-logo { width: 9mm; height: 9mm; object-fit: contain; flex-shrink: 0; }
.f-logo-text { display: inline-flex; align-items: center; justify-content: center; background: ${BLUE}; color: #fff; font-weight: 700; font-size: 10pt; border-radius: 1.5mm; }

/* ---------- تنظیم A5 (کاغذ کوچک‌تر — فونت/حاشیه متناسب) ---------- */
.a5 .lh-company { font-size: 10.5pt; }
.a5 .lh-logo { width: 11mm; height: 11mm; }
.a5 .lh-logo-fallback { font-size: 15pt; }
.a5 .besm { font-size: 12pt; }
.a5 .besm-overlay { top: 23.7mm; }
.a5 .lh-lines { width: 12mm; }
.a5 .ref-line { font-size: 10pt; }
.a5 .subject { font-size: 10.5pt; }
.a5 .recipient { font-size: 10.5pt; }
.a5 .body-text { font-size: 10.5pt; line-height: 2; }
.a5 .items-table th, .a5 .items-table td { font-size: 10pt; padding: 1.6mm 2.4mm; }
.a5 .notice { font-size: 8.5pt; }
.a5 .sg-thanks { font-size: 10pt; }
.a5 .sg-name { font-size: 10pt; }
.a5 .sg-title { font-size: 9pt; }
.a5 .signer { min-width: 34mm; }
.a5 .sg-sig { height: 9mm; max-width: 27mm; }
.a5 .sg-seal { height: 10.5mm; max-width: 13mm; }
.a5 .digi-sig { max-width: 36mm; }
.a5 .ds-name { font-size: 7pt; }
.a5 .ds-code { font-size: 6.5pt; }
.a5 .ds-qr { width: 13mm; height: 13mm; }
.a5 .body-rich { font-size: 10.5pt; line-height: 2; }
.a5 .body-rich table { margin: 2.4mm 0 4mm; }
.a5 .body-rich thead th, .a5 .body-rich td { font-size: 9.5pt; padding: 1.3mm 2mm; }
.a5 .lh-footer { font-size: 7.5pt; }
.a5 .f-logo { width: 7mm; height: 7mm; }
${sizeCss}

/* ---------- نوار ابزار (غیرچاپی) ---------- */
.toolbar { position: fixed; top: 0; right: 0; left: 0; background: #0f172aee; color: #fff; display: flex; align-items: center; gap: 10px; padding: 8px 14px; font-family: 'Vazirmatn', sans-serif; z-index: 99; }
.toolbar button { font-family: inherit; font-size: 12px; padding: 6px 14px; border: 0; border-radius: 8px; cursor: pointer; }
.toolbar .btn-print { background: ${BLUE}; color: #fff; }
.toolbar .btn-close { background: #475569; color: #fff; }
.toolbar .hint { font-size: 11px; opacity: .75; margin-right: auto; }

@media print {
  html, body { background: #fff; }
  .toolbar { display: none !important; }
  /* ایمنی: چاپ دستی (Ctrl+P) هرگز صفحه مخیف چاپ نکند — حتی اگر اسکریپت اجرا نشده باشد */
  .page.img-bg { visibility: visible !important; }
  .page { width: ${geo.w}mm; min-height: ${geo.h}mm; margin: 0; box-shadow: none; ${printPadding} }
  .page + .page { page-break-before: always; }
}
</style>
</head>
<body>
<div class="toolbar">
  <button class="btn-print" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
  <button class="btn-close" onclick="window.close()">بستن</button>
  <span class="hint">${esc(letterNumber)} — ${esc(kindLabel)} — ${esc(modeLabel)} — ${size}${letter.status === "APPROVED" && letter.signatureCode ? " + امضای دیجیتال" : ""}</span>
</div>
<section class="page${size === "A5" ? " a5" : ""}${useBg ? " img-bg" : ""}">
  ${head}
  ${subject}
  ${bodyBlock}
  ${table}
  ${notices}
  ${sigs}
  ${footer}
</section>
${
  useBg
    ? `<noscript><style>.page.img-bg { visibility: visible !important; }</style></noscript>
<script>
(function () {
  var p = document.querySelector('.page.img-bg');
  if (!p) return;
  function ready() {
    if (window.__bgReady) return;
    window.__bgReady = true;
    p.className += ' bg-ready';
    try { window.dispatchEvent(new Event('letterbgready')); } catch (e) {}
  }
  try {
    var bg = (window.getComputedStyle ? getComputedStyle(p) : {}).backgroundImage || '';
    var m = /^url\\((['\"]?)(.*?)\\1\\)$/.exec(String(bg).trim());
    if (!m || !m[2] || m[2] === 'none') { ready(); return; }
    var done = false;
    var fin = function () { if (!done) { done = true; ready(); } };
    var img = new Image();
    img.onload = function () { if (img.decode) { img.decode().then(fin, fin); } else { fin(); } };
    img.onerror = fin;
    img.src = m[2];
    setTimeout(fin, 2500);
  } catch (e) { ready(); }
})();
</script>`
    : ""
}
</body>
</html>`;
}

/** چاپ نامه در پنجره مستقل (اندازه پنجره متناسب کاغذ) — fallback: iframe مخفی
 *  حالت تصویر سربرگ: چاپ فقط پس از آماده‌شدن کامل تصویر پس‌زمینه (پرچم __bgReady)
 *  آغاز می‌شود تا پیش‌نمایش چاپ هرگز بدون سربرگ/با بکگراند ناقص بیفتد. */
export function printLetter(letter: LetterPrintData, company: LetterPrintCompany, opts: LetterPrintOptions): void {
  // آدرس مطلق سرور: فونت‌ها و QR راستی‌آزمایی در پنجره چاپ به‌درستی resolve شوند
  const baseUrl = opts.baseUrl || window.location.origin;
  const html = buildLetterDocument(letter, company, { ...opts, baseUrl });
  const useBg = !!(opts.letterhead && (opts.letterheadImage || "").trim());
  const winSize = opts.paperSize === "A5" ? "width=700,height=760" : "width=920,height=760";
  const w = window.open("", "_blank", winSize);
  if (w) {
    w.document.open();
    w.document.write(html);
    w.document.close();
    w.focus();
    let fired = false;
    const fire = () => {
      if (fired) return;
      fired = true;
      setTimeout(() => {
        try {
          w.focus();
          w.print();
        } catch {
          /* کاربر خودش دکمه چاپ را می‌زند */
        }
      }, useBg ? 120 : 400);
    };
    if (useBg) {
      // اسکریپت سند پس از دکود کامل تصویر سربرگ پرچم __bgReady را ست می‌کند
      const t0 = Date.now();
      const poll = () => {
        let ok = false;
        try {
          ok = !!(w as unknown as { __bgReady?: boolean }).__bgReady;
        } catch {
          ok = true;
        }
        if (ok || Date.now() - t0 > 3400) {
          fire();
          return;
        }
        setTimeout(poll, 40);
      };
      w.addEventListener("load", poll);
      setTimeout(poll, 700); // پشتیبان: اگر رویداد load به هر دلیل اجرا نشد
    } else {
      w.addEventListener("load", fire);
    }
    return;
  }
  const f = document.createElement("iframe");
  f.style.cssText = "position:fixed;left:200%;bottom:200%;width:0;height:0;border:0;visibility:hidden;";
  document.body.appendChild(f);
  f.onload = () => {
    setTimeout(() => {
      try { f.contentWindow?.focus(); f.contentWindow?.print(); } catch { /* noop */ }
      setTimeout(() => f.remove(), 60_000);
    }, 500);
  };
  f.srcdoc = html;
}

/** دانلود نامه به‌صورت فایل HTML خودکفا — فونت‌ها base64 داخل فایل (بدون نیاز به سرور) */
export async function downloadLetter(letter: LetterPrintData, company: LetterPrintCompany, opts: LetterPrintOptions): Promise<void> {
  const baseUrl = (opts.baseUrl || window.location.origin).replace(/\/$/, "");
  const embeddedFonts = await fetchEmbeddedFonts(baseUrl);
  const html = buildLetterDocument(letter, company, { ...opts, baseUrl, embeddedFonts });
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  // نام فایل مطابق الگوی کاربر: نامه_ZDX_AD_0507019.html (+ _A5 برای کاغذ A5)
  const safe = toEnDigits(letter.number || "").replace(/[^A-Za-z0-9_-]/g, "") || "letter";
  a.download = `نامه_${safe}${opts.paperSize === "A5" ? "_A5" : ""}${opts.letterhead ? "" : "_بدون-سربرگ"}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

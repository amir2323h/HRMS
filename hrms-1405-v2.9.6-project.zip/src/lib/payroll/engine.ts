// ============================================================
// موتور محاسبه حقوق و دستمزد ۱۴۰۵ — محاسبه مستقیم
// منطق: حقوق و مزایا → مشمول بیمه → بیمه ۷٪/۲۳٪ → درآمد مشمول مالیات
//       → مالیات پلکانی (ماده ۸۵ بودجه ۱۴۰۵) → خالص پرداختی
// واحد: ریال (integer)
// ============================================================

export interface TaxBracket {
  sortOrder: number;
  lowerLimit: number; // شامل — ریال/ماه
  upperLimit: number | null; // خالی = بی‌نهایت
  rate: number; // 0.10
  label?: string;
}

export interface LegalParams {
  year: number;
  employeeSsoRate: number; // 0.07
  employerSsoRate: number; // 0.20
  unemploymentRate: number; // 0.03
  minWage: number; // حداقل دستمزد ماهانه — ریال
  insurableCap: number | null; // سقف مشمول بیمه — ریال (null = نامحدود)
  housing: number; // حق مسکن — ریال
  grocery: number; // بن کارگری — ریال
  childPerChild: number; // حق اولاد به ازای هر فرزند — ریال
  maxChildrenForAllowance: number; // حداکثر فرزند مشمول حق اولاد
  marriageAllowance: number; // حق تاهل ماهانه (کارکنان متاهل) — ریال
  // ---- پایه سنوات (بخشنامه مزد — جدول تجمیعی رسمی) ----
  seniorityMode: "LEGAL" | "GRADE"; // LEGAL = جدول رسمی تجمیعی | GRADE = پایه هر سال از طبقه شغلی (کارگاه‌های دارای طبقه‌بندی)
  seniorityDailyByYear: number[]; // نرخ روزانه «تجمیعی» به ازای ۱ تا ۳۰ سال خدمت — ریال (حالت LEGAL)
  monthlyWorkHours: number; // ساعت کار ماهانه (مبنای اضافه‌کاری)
  overtimeMultiplier: number; // 1.4 — ماده ۵۹ قانون کار
  // ---- ضرایب شیفت/شب/تعطیل (قابل ویرایش از تنظیمات) ----
  nightPremium: number; // 0.35 — فوق‌العاده شب‌کاری ماده ۵۸ (۲۲–۶)
  fridayMultiplier: number; // 1.4 — جمعه‌کاری ماده ۶۲ (علاوه بر مزد روز)
  holidayMultiplier: number; // 1.4 — تعطیل‌کاری رسمی (مواد ۵۱/۶۲/۶۳)
  shiftTwoRate: number; // 0.225 — حق شیفت صبح/عصر — تبصره ۱ ماده ۵۶
  shiftThreeRate: number; // 0.45 — حق شیفت صبح/عصر/شب — تبصره ۱ ماده ۵۶
  missionMultiplier: number; // 1 — ضریب حق مأموریت روزانه نسبت به مزد روزانه (پایه ÷ ۳۰)
  groceryTaxable: boolean; // بن کارگری مشمول مالیات؟ (ماده ۹۱ بند ۱۴ ق.م.م: معاف)
  taxBrackets: TaxBracket[];
}

// جدول پایه سنوات تجمیعی ۱۴۰۵ — بخشنامه مزد / جدول احتساب مزد سنوات اداره کل روابط کار
// (ویژه کارگاه‌های فاقد طبقه‌بندی مشاغل و گروه ۱ طبقه‌بندی) — نرخ «روزانه» تجمیعی ریال
// ایندکس i = سابقه (i+1) سال؛ مازاد بر ۳۰ سال همان سقف آخر.
// سنوات ماهانه = نرخ روزانه × ۳۰. پلکانی و نامنظم است چون هر سال خدمت به نرخ همان سال اعتبار گرفته است.
export const LEGAL_SENIORITY_DAILY_1405: number[] = [
  166_667, 302_967, 436_949, 600_404, 798_186, 980_142, 1_143_903, 1_275_730, // ۱–۸ سال
  1_384_261, 1_504_079, 1_583_016, 1_673_007, 1_725_652, 1_761_029, 1_793_460, 1_821_216, // ۹–۱۶
  1_850_642, 1_870_320, 1_890_983, 1_912_677, 1_912_677, 1_912_677, 1_912_677, 1_912_677, // ۱۷–۲۴
  1_912_677, 1_912_677, 1_919_514, 1_925_108, 1_929_905, 1_929_905, // ۲۵–۳۰ (سقف)
];

/** نرخ روزانه تجمیعی سنوات برای N سال خدمت (حالت قانونی) — ریال/روز */
export function legalSeniorityDaily(params: LegalParams, years: number): number {
  const table = params.seniorityDailyByYear;
  if (!Array.isArray(table) || table.length === 0) return 0;
  const y = Math.max(0, Math.floor(years || 0));
  if (y <= 0) return 0; // سنوات از ابتدای سال دوم (پس از یک سال کامل) تعلق می‌گیرد
  const idx = Math.min(y, table.length) - 1;
  return Math.max(0, Math.round(table[idx] || 0));
}

// پارامترهای پیش‌فرض ۱۴۰۵ (قابل ویرایش از تنظیمات)
export const LEGAL_DEFAULTS_1405: LegalParams = {
  year: 1405,
  employeeSsoRate: 0.07,
  employerSsoRate: 0.2,
  unemploymentRate: 0.03,
  minWage: 166_255_500,
  insurableCap: null,
  housing: 30_000_000,
  grocery: 22_000_000,
  childPerChild: 16_625_550,
  maxChildrenForAllowance: 2,
  marriageAllowance: 5_000_000, // حق تاهل ۱۴۰۵ — مصوبه شورای عالی کار
  seniorityMode: "LEGAL",
  seniorityDailyByYear: LEGAL_SENIORITY_DAILY_1405,
  monthlyWorkHours: 220,
  overtimeMultiplier: 1.4,
  nightPremium: 0.35,
  fridayMultiplier: 1.4,
  holidayMultiplier: 1.4,
  shiftTwoRate: 0.225,
  shiftThreeRate: 0.45,
  missionMultiplier: 1,
  groceryTaxable: false,
  taxBrackets: [
    { sortOrder: 1, lowerLimit: 0, upperLimit: 400_000_000, rate: 0, label: "تا ۴۰ میلیون تومان — معاف" },
    { sortOrder: 2, lowerLimit: 400_000_000, upperLimit: 800_000_000, rate: 0.1, label: "۴۰ تا ۸۰ میلیون تومان" },
    { sortOrder: 3, lowerLimit: 800_000_000, upperLimit: 1_000_000_000, rate: 0.15, label: "۸۰ تا ۱۰۰ میلیون تومان" },
    { sortOrder: 4, lowerLimit: 1_000_000_000, upperLimit: 1_200_000_000, rate: 0.2, label: "۱۰۰ تا ۱۲۰ میلیون تومان" },
    { sortOrder: 5, lowerLimit: 1_200_000_000, upperLimit: 1_400_000_000, rate: 0.25, label: "۱۲۰ تا ۱۴۰ میلیون تومان" },
    { sortOrder: 6, lowerLimit: 1_400_000_000, upperLimit: null, rate: 0.3, label: "مازاد بر ۱۴۰ میلیون تومان" },
  ],
};

// ------------------- ورودی محاسبه -------------------
export interface PayrollContext {
  // مشخصات مؤثر بر مزایا
  childCount: number; // تعداد فرزند مشمول
  married?: boolean; // متاهل → حق تاهل قانونی تعلق می‌گیرد
  housingEnabled: boolean; // مشمول حق مسکن
  groceryEnabled: boolean; // مشمول بن کارگری
  seniorityYears: number; // سال خدمت (برای سنوات)
  seniorityBase: number; // پایه سنوات هر سال — ریال (فقط حالت «طبقه‌ای»)
  attraction: number; // حق جذب — ریال
  overtimeHours: number; // ساعت اضافه‌کاری
  otherAllowance: number; // سایر مزایا
  otherDeduction: number; // سایر کسورات
  // ---- تفکیک حقوق ماهانه طبق درصد سطح (جمع = ۱۰۰٪) ----
  // حقوق پایه مبنای اضافه‌کاری/مأموریت/شب‌کاری/جمعه‌کاری/تعطیل‌کاری/غیبت است؛
  // حق مسولیت و شایستگی مشمول بیمه و مالیات‌اند اما مبنای فوق‌العاده‌ها نیستند.
  // خالی/صفر = بدون تفکیک (رفتار پیش‌فرض — تمام حقوق = پایه)
  respPercent?: number; // درصد حق مسولیت
  meritPercent?: number; // درصد پاداش شایستگی
  // ---- کارکرد ماهانه (حضور و غیاب) + شیفت ----
  nightHours?: number; // ساعت شب‌کاری (۲۲–۶) — ماده ۵۸
  fridayHours?: number; // ساعت جمعه‌کاری — ماده ۶۲
  holidayHours?: number; // ساعت تعطیل‌کاری (تعطیل رسمی)
  absentDays?: number; // روز غیبت غیرموجه (کسر مزد)
  missionDays?: number; // روزهای مأموریت — حق مأموریت از مزد روزانه با ضریب
  shiftRate?: number; // نرخ حق شیفت (۰/۲۲.۵/۴۵٪) — از نوع اشتغال کارمند
}

export const EMPTY_CONTEXT: PayrollContext = {
  childCount: 0,
  housingEnabled: true,
  groceryEnabled: true,
  seniorityYears: 0,
  seniorityBase: 0,
  attraction: 0,
  overtimeHours: 0,
  otherAllowance: 0,
  otherDeduction: 0,
};

// ------------------- خروجی محاسبه -------------------
export interface PaysheetItem {
  code: string;
  title: string;
  amount: number;
  insurable: boolean;
  taxable: boolean;
  kind: "EARNING" | "DEDUCTION";
}

export interface PaysheetResult {
  // اجزا
  baseSalary: number; // حقوق ماهانه کل (پایه + مسولیت + شایستگی)
  baseCore: number; // حقوق پایه — مبنای فوق‌العاده‌ها (سهم تفکیک)
  responsibility: number; // حق مسولیت — سهم تفکیک سطح
  merit: number; // پاداش شایستگی — سهم تفکیک سطح
  respPercent: number; // درصد تفکیک لحاظ‌شده در این محاسبه
  meritPercent: number;
  seniority: number;
  seniorityDaily: number; // نرخ روزانه تجمیعی لحاظ‌شده (حالت قانونی) — ریال
  seniorityMode: "LEGAL" | "GRADE";
  marriageAllowance: number;
  housing: number;
  grocery: number;
  childAllowance: number;
  attraction: number;
  overtimeHours: number;
  overtimeAmount: number;
  // ---- شیفت/شب/تعطیل/غیبت/مأموریت ----
  nightHours: number;
  nightAmount: number;
  fridayHours: number;
  fridayAmount: number;
  holidayHours: number;
  holidayAmount: number;
  shiftAllowance: number;
  absentDays: number;
  absenceDeduction: number;
  missionDays: number;
  missionAmount: number;
  otherAllowance: number;
  // جمع‌ها
  gross: number; // جمع حقوق و مزایا
  insurableBase: number; // مشمول بیمه
  employeeSso: number; // بیمه سهم کارگر ۷٪
  employerSso20: number; // بیمه سهم کارفرما ۲۰٪
  unemploymentSso3: number; // بیمه بیکاری ۳٪
  employerTotalSso: number; // جمع سهم کارفرما ۲۳٪
  taxableIncome: number; // درآمد مشمول مالیات
  incomeTax: number; // مالیات حقوق
  otherDeduction: number;
  totalDeductions: number;
  netPay: number; // خالص پرداختی
  employerTotalCost: number; // کل هزینه کارفرما (ناخالص + ۲۳٪)
  // جزئیات
  items: PaysheetItem[];
  warnings: string[];
}

/** مالیات پلکانی — درآمد ماهانه (ریال) */
export function progressiveTax(income: number, brackets: TaxBracket[]): number {
  if (income <= 0) return 0;
  const sorted = [...brackets].sort((a, b) => a.lowerLimit - b.lowerLimit);
  let tax = 0;
  for (const b of sorted) {
    if (income <= b.lowerLimit) break;
    const upper = b.upperLimit === null ? Infinity : b.upperLimit;
    const taxableInBracket = Math.min(income, upper) - b.lowerLimit;
    if (taxableInBracket > 0) tax += taxableInBracket * b.rate;
  }
  return Math.round(tax);
}

/** اجرای هر پله (برای نمایش جزئیات مالیات) */
export function taxBracketBreakdown(income: number, brackets: TaxBracket[]) {
  const sorted = [...brackets].sort((a, b) => a.lowerLimit - b.lowerLimit);
  return sorted.map((b) => {
    const upper = b.upperLimit === null ? Infinity : b.upperLimit;
    const inBracket = income > b.lowerLimit ? Math.max(0, Math.min(income, upper) - b.lowerLimit) : 0;
    return { ...b, taxableInBracket: inBracket, tax: Math.round(inBracket * b.rate) };
  });
}

// ------------------- محاسبه مستقیم -------------------
export function computePaysheet(baseSalary: number, ctx: PayrollContext, params: LegalParams): PaysheetResult {
  const warnings: string[] = [];
  const total = Math.max(0, Math.round(baseSalary));

  // ----- تفکیک حقوق ماهانه طبق درصد سطح (پایه / حق مسولیت / شایستگی) -----
  // جمع درصد = ۱۰۰؛ حقوق پایه (B) مبنای اضافه‌کاری/مأموریت/شب/جمعه/تعطیل/غیبت/شیفت است.
  // بدون تفکیک (۰/۰) → تمام حقوق = پایه — رفتار پیش‌فرض و سازگار با داده قدیمی.
  const respP = Math.min(100, Math.max(0, ctx.respPercent ?? 0));
  const meritP = Math.min(100 - respP, Math.max(0, ctx.meritPercent ?? 0));
  const baseP = 100 - respP - meritP;
  const B = Math.round((total * baseP) / 100);
  const responsibility = Math.round((total * respP) / 100);
  const merit = total - B - responsibility; // باقیمانده — جمع دقیق = حقوق ماهانه

  // ----- مزایا -----
  // پایه سنوات: حالت LEGAL = جدول تجمیعی رسمی ۱۴۰۵ (نرخ روزانه × ۳۰)؛
  // حالت GRADE = پایه هر سال از طبقه شغلی × سال‌های خدمت (کارگاه‌های دارای طبقه‌بندی مشاغل).
  const seniorityYears = Math.max(0, Math.floor(ctx.seniorityYears || 0));
  const seniorityMode: "LEGAL" | "GRADE" = params.seniorityMode === "GRADE" ? "GRADE" : "LEGAL";
  const seniorityDaily = seniorityMode === "LEGAL" ? legalSeniorityDaily(params, seniorityYears) : 0;
  const seniority = seniorityMode === "LEGAL" ? seniorityDaily * 30 : Math.round(ctx.seniorityBase * seniorityYears);
  const marriageAllowance = ctx.married ? Math.round(params.marriageAllowance || 0) : 0;
  const housing = ctx.housingEnabled ? params.housing : 0;
  const grocery = ctx.groceryEnabled ? params.grocery : 0;
  const childAllowance = Math.round(params.childPerChild * Math.min(ctx.childCount, params.maxChildrenForAllowance));
  const attraction = Math.round(ctx.attraction);
  // مزد ساعتی — پایه همه فوق‌العاده‌ها
  const hourly = params.monthlyWorkHours > 0 ? B / params.monthlyWorkHours : 0;
  // اضافه‌کاری: (پایه ÷ ساعت کاری ماهانه) × ۱.۴ × ساعت — ساعات مازاد بر ۲۲۰ ساعت ماه
  const overtimeHours = Math.max(0, ctx.overtimeHours || 0);
  const overtimeAmount = Math.round(hourly * params.overtimeMultiplier * overtimeHours);
  // شب‌کاری (ماده ۵۸): فوق‌العاده ۳۵٪ مزد ساعتی — مزد پایه آن ساعات در حقوق ماهانه پرداخت شده
  const nightHours = Math.max(0, ctx.nightHours || 0);
  const nightAmount = Math.round(hourly * params.nightPremium * nightHours);
  // جمعه‌کاری (ماده ۶۲) و تعطیل‌کاری: مزد کار انجام‌شده با افزایش — علاوه بر مزد مقرر آن روز
  const fridayHours = Math.max(0, ctx.fridayHours || 0);
  const fridayAmount = Math.round(hourly * params.fridayMultiplier * fridayHours);
  const holidayHours = Math.max(0, ctx.holidayHours || 0);
  const holidayAmount = Math.round(hourly * params.holidayMultiplier * holidayHours);
  // حق شیفت (نوبتی‌کاری — تبصره ۱ ماده ۵۶): درصدی از حقوق پایه
  const shiftAllowance = Math.round(B * Math.max(0, ctx.shiftRate || 0));
  // غیبت غیرموجه: کسر مزد روزانه (پایه ÷ ۳۰)
  const absentDays = Math.max(0, ctx.absentDays || 0);
  const absenceDeduction = Math.round((B / 30) * absentDays);
  // حق مأموریت: مزد روزانه × ضریب × روزهای مأموریت — مشمول بیمه و مالیات
  const missionDays = Math.max(0, ctx.missionDays || 0);
  const missionAmount = Math.round((B / 30) * Math.max(0, params.missionMultiplier || 0) * missionDays);
  const otherAllowance = Math.round(ctx.otherAllowance);

  // ----- جمع حقوق و مزایا -----
  const gross =
    B + responsibility + merit + seniority + marriageAllowance + housing + grocery + childAllowance + attraction +
    overtimeAmount + nightAmount + fridayAmount + holidayAmount + shiftAllowance + missionAmount + otherAllowance;

  // ----- مشمول بیمه -----
  // بیمه‌پذیر: پایه + حق مسولیت + شایستگی (مزایای مشابه حقوق) + اضافه‌کاری + شب‌کاری +
  // جمعه‌کاری + تعطیل‌کاری + حق شیفت + مأموریت
  // غیر بیمه‌پذیر: مسکن، بن، اولاد، سنوات، جذب
  const insurableRaw = B + responsibility + merit + overtimeAmount + nightAmount + fridayAmount + holidayAmount + shiftAllowance + missionAmount;
  let insurableBase = Math.max(insurableRaw, params.minWage);
  if (params.insurableCap !== null) insurableBase = Math.min(insurableBase, params.insurableCap);
  if (insurableRaw > 0 && insurableRaw < params.minWage) {
    warnings.push("مزد مشمول بیمه کمتر از حداقل دستمزد است؛ مبنا به حداقل دستمزد تعدیل شد.");
  }

  // ----- بیمه -----
  const employeeSso = Math.round(insurableBase * params.employeeSsoRate);
  const employerSso20 = Math.round(insurableBase * params.employerSsoRate);
  const unemploymentSso3 = Math.round(insurableBase * params.unemploymentRate);
  const employerTotalSso = employerSso20 + unemploymentSso3;

  // ----- درآمد مشمول مالیات -----
  // مشمول مالیات: همه اقلام مشمول مالیات − حق بیمه سهم کارگر (ماده ۹۲ ق.م.م)
  const taxableEarnings =
    B + responsibility + merit + seniority + marriageAllowance + housing + (params.groceryTaxable ? grocery : 0) + childAllowance + attraction +
    overtimeAmount + nightAmount + fridayAmount + holidayAmount + shiftAllowance + missionAmount + otherAllowance;
  const taxableIncome = Math.max(0, taxableEarnings - employeeSso);
  const incomeTax = progressiveTax(taxableIncome, params.taxBrackets);

  // ----- خالص -----
  const otherDeduction = Math.round(ctx.otherDeduction);
  const totalDeductions = employeeSso + incomeTax + otherDeduction + absenceDeduction;
  const netPay = gross - totalDeductions;
  const employerTotalCost = gross + employerTotalSso;

  if (total > 0 && total < params.minWage) {
    warnings.push("حقوق ماهانه (پایه + مسولیت + شایستگی) کمتر از حداقل دستمزد مصوب ۱۴۰۵ است.");
  }
  if (respP + meritP > 0 && B <= 0 && (nightHours + fridayHours + holidayHours > 0 || ctx.overtimeHours || 0 > 0)) {
    warnings.push("سهم حقوق پایه صفر است — فوق‌العاده‌ها/اضافه‌کاری بر مبنای صفر محاسبه شد.");
  } else if (nightHours + fridayHours + holidayHours > 0 && B <= 0) {
    warnings.push("حقوق پایه صفر است — فوق‌العاده شب/جمعه/تعطیل بر مبنای صفر محاسبه شد.");
  }

  const items: PaysheetItem[] = [
    { code: "BASE", title: "حقوق پایه", amount: B, insurable: true, taxable: true, kind: "EARNING" },
  ];
  if (responsibility > 0) items.push({ code: "RESP", title: `حق مسولیت (${respP}٪ حقوق ماهانه)`, amount: responsibility, insurable: true, taxable: true, kind: "EARNING" });
  if (merit > 0) items.push({ code: "MERIT", title: `پاداش شایستگی (${meritP}٪ حقوق ماهانه)`, amount: merit, insurable: true, taxable: true, kind: "EARNING" });
  if (seniority > 0) items.push({ code: "SENIORITY", title: seniorityMode === "LEGAL" ? `حق سنوات قانونی (${seniorityYears} سال — جدول تجمیعی ۱۴۰۵ × ۳۰)` : `حق سنوات (${seniorityYears} سال × پایه طبقه)`, amount: seniority, insurable: false, taxable: true, kind: "EARNING" });
  if (marriageAllowance > 0) items.push({ code: "MARRIAGE", title: "حق تاهل (کارمند متاهل)", amount: marriageAllowance, insurable: false, taxable: true, kind: "EARNING" });
  if (housing > 0) items.push({ code: "HOUSING", title: "حق مسکن", amount: housing, insurable: false, taxable: true, kind: "EARNING" });
  if (grocery > 0) items.push({ code: "GROCERY", title: "بن کارگری (کمک‌هزینه اقلام مصرفی)", amount: grocery, insurable: false, taxable: params.groceryTaxable, kind: "EARNING" });
  if (childAllowance > 0) items.push({ code: "CHILD", title: "حق اولاد", amount: childAllowance, insurable: false, taxable: true, kind: "EARNING" });
  if (attraction > 0) items.push({ code: "ATTRACTION", title: "حق جذب", amount: attraction, insurable: false, taxable: true, kind: "EARNING" });
  if (shiftAllowance > 0) items.push({ code: "SHIFT", title: `حق شیفت (نوبتی‌کاری ${ctx.shiftRate && ctx.shiftRate >= 0.4 ? "۳ شیفت" : "۲ شیفت"} — ${Math.round((ctx.shiftRate || 0) * 100)}٪)`, amount: shiftAllowance, insurable: true, taxable: true, kind: "EARNING" });
  if (overtimeAmount > 0) items.push({ code: "OVERTIME", title: `اضافه‌کاری (${overtimeHours} ساعت × ${params.overtimeMultiplier} مزد)`, amount: overtimeAmount, insurable: true, taxable: true, kind: "EARNING" });
  if (nightAmount > 0) items.push({ code: "NIGHT", title: `فوق‌العاده شب‌کاری (${nightHours} ساعت — ماده ۵۸)`, amount: nightAmount, insurable: true, taxable: true, kind: "EARNING" });
  if (fridayAmount > 0) items.push({ code: "FRIDAY", title: `فوق‌العاده جمعه‌کاری (${fridayHours} ساعت — ماده ۶۲)`, amount: fridayAmount, insurable: true, taxable: true, kind: "EARNING" });
  if (holidayAmount > 0) items.push({ code: "HOLIDAY", title: `فوق‌العاده تعطیل‌کاری (${holidayHours} ساعت)`, amount: holidayAmount, insurable: true, taxable: true, kind: "EARNING" });
  if (missionAmount > 0) items.push({ code: "MISSION", title: `حق مأموریت (${missionDays} روز × ضریب ${params.missionMultiplier})`, amount: missionAmount, insurable: true, taxable: true, kind: "EARNING" });
  if (otherAllowance > 0) items.push({ code: "OTHER_ALW", title: "سایر مزایا", amount: otherAllowance, insurable: false, taxable: true, kind: "EARNING" });
  if (employeeSso > 0) items.push({ code: "SSO_EMP", title: `حق بیمه سهم کارمند (${params.employeeSsoRate * 100}٪)`, amount: employeeSso, insurable: false, taxable: false, kind: "DEDUCTION" });
  if (incomeTax > 0) items.push({ code: "TAX", title: "مالیات حقوق (پلکانی ۱۴۰۵)", amount: incomeTax, insurable: false, taxable: false, kind: "DEDUCTION" });
  if (absenceDeduction > 0) items.push({ code: "ABSENCE", title: `کسر مزد غیبت (${absentDays} روز)`, amount: absenceDeduction, insurable: false, taxable: false, kind: "DEDUCTION" });
  if (otherDeduction > 0) items.push({ code: "OTHER_DED", title: "سایر کسورات", amount: otherDeduction, insurable: false, taxable: false, kind: "DEDUCTION" });

  return {
    baseSalary: total,
    baseCore: B,
    responsibility,
    merit,
    respPercent: respP,
    meritPercent: meritP,
    seniority,
    seniorityDaily,
    seniorityMode,
    marriageAllowance,
    housing,
    grocery,
    childAllowance,
    attraction,
    overtimeHours,
    overtimeAmount,
    nightHours,
    nightAmount,
    fridayHours,
    fridayAmount,
    holidayHours,
    holidayAmount,
    shiftAllowance,
    absentDays,
    absenceDeduction,
    missionDays,
    missionAmount,
    otherAllowance,
    gross,
    insurableBase,
    employeeSso,
    employerSso20,
    unemploymentSso3,
    employerTotalSso,
    taxableIncome,
    incomeTax,
    otherDeduction,
    totalDeductions,
    netPay,
    employerTotalCost,
    items,
    warnings,
  };
}

export interface EmployeeLike {
  baseSalary: number | bigint;
  childCount: number;
  maritalStatus: string;
  overtimeHours: number;
  hireDateJ: string;
  employmentType?: string; // DAILY | SHIFT
  shiftPattern?: string; // "" | TWO_SHIFT | THREE_SHIFT
}

export interface GradeLike {
  seniorityBase: number | bigint;
  attraction: number | bigint;
  // ---- تفکیک حقوق ماهانه سطح (اختیاری — خالی = بدون تفکیک) ----
  basePercent?: number | null;
  respPercent?: number | null;
  meritPercent?: number | null;
}

export interface LegalLike {
  shiftTwoRate: number;
  shiftThreeRate: number;
}

/** نرخ حق شیفت از نوع اشتغال/الگوی شیفت کارمند — تبصره ۱ ماده ۵۶ */
export function shiftRateOf(
  employmentType: string | undefined,
  shiftPattern: string | undefined,
  params: LegalLike
): number {
  if (employmentType !== "SHIFT") return 0;
  if (shiftPattern === "THREE_SHIFT") return params.shiftThreeRate;
  return params.shiftTwoRate; // پیش‌فرض شیفت دوگانه صبح/عصر
}

/** ساخت context محاسبه از مشخصات کارمند + طبقه */
export function contextFromEmployee(
  emp: EmployeeLike,
  grade: GradeLike | null,
  atDateJ: string,
  overrides?: Partial<PayrollContext>
): PayrollContext {
  const ctx: PayrollContext = {
    childCount: emp.childCount || 0,
    married: emp.maritalStatus === "MARRIED",
    housingEnabled: true,
    groceryEnabled: true,
    seniorityYears: 0,
    seniorityBase: grade ? Number(grade.seniorityBase) : 0,
    attraction: grade ? Number(grade.attraction) : 0,
    overtimeHours: emp.overtimeHours || 0,
    otherAllowance: 0,
    otherDeduction: 0,
    // تفکیک حقوق ماهانه طبق درصد سطح (فقط اگر سطح درصد تعریف‌شده داشته باشد)
    respPercent: grade && Number(grade.respPercent) > 0 ? Number(grade.respPercent) : undefined,
    meritPercent: grade && Number(grade.meritPercent) > 0 ? Number(grade.meritPercent) : undefined,
  };
  if (emp.hireDateJ) {
    const [y, m, d] = emp.hireDateJ.split("/").map(Number);
    const [ty, tm, td] = atDateJ.split("/").map(Number);
    if (!isNaN(y) && !isNaN(ty)) {
      const years = ty - y - (tm < m || (tm === m && td < d) ? 1 : 0);
      ctx.seniorityYears = Math.max(0, years);
    }
  }
  return { ...ctx, ...overrides };
}

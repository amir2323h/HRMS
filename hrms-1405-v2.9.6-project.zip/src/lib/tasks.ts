import type { Task, TaskTransfer, User } from "@prisma/client";
import { todayJalaliStr, diffJalaliDays, isValidJalali } from "./jalali";

// ============================================================
// مدیریت کار — منطق مشترک ماتریس آیزنهاور + زنجیره واگذاری
//  • هر وظیفه با دو پرچم «مهم» (isImportant) و «فوری» (isUrgent)
//    در یکی از ۴ ربع ماتریس می‌نشیند
//  • زنجیره واگذاری: transfers (فرستنده → گیرنده) + مسئول فعلی
// ============================================================

export const TASK_STATUSES = ["OPEN", "IN_PROGRESS", "DONE", "CANCELLED"] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const TASK_STATUS_LABELS: Record<TaskStatus, string> = {
  OPEN: "باز",
  IN_PROGRESS: "در حال انجام",
  DONE: "انجام‌شده",
  CANCELLED: "لغو‌شده",
};

export const TASK_STATUS_COLORS: Record<TaskStatus, string> = {
  OPEN: "bg-amber-100 text-amber-800 border-amber-200",
  IN_PROGRESS: "bg-blue-100 text-blue-800 border-blue-200",
  DONE: "bg-green-100 text-green-800 border-green-200",
  CANCELLED: "bg-gray-100 text-gray-600 border-gray-200",
};

/** دامنه دید وظایف */
export const TASK_SCOPES = ["mine", "created", "all"] as const;
export type TaskScope = (typeof TASK_SCOPES)[number];

// ---------- ماتریس آیزنهاور ----------

export interface QuadrantDef {
  key: "Q1" | "Q2" | "Q3" | "Q4";
  title: string;
  action: string;
  hint: string;
  isUrgent: boolean;
  isImportant: boolean;
  /** رنگ‌های ربع — سرِ ربع (عنوان/نوار) */
  headClass: string;
  /** قاب ربع */
  boxClass: string;
}

export const QUADRANTS: QuadrantDef[] = [
  {
    key: "Q1",
    title: "فوری و مهم",
    action: "همین حالا انجام بده",
    hint: "بحران‌ها و موعدِ رسیده — اول همین‌ها",
    isUrgent: true,
    isImportant: true,
    headClass: "bg-red-600",
    boxClass: "border-red-300",
  },
  {
    key: "Q2",
    title: "مهم و غیرفوری",
    action: "زمان‌بندی کن",
    hint: "رشد و برنامه‌ریزی — وقت این‌ها را جدا کن",
    isUrgent: false,
    isImportant: true,
    headClass: "bg-blue-600",
    boxClass: "border-blue-300",
  },
  {
    key: "Q3",
    title: "فوری و غیرمهم",
    action: "واگذار کن",
    hint: "وسط‌بریده‌ها — به دیگری بسپار",
    isUrgent: true,
    isImportant: false,
    headClass: "bg-amber-500",
    boxClass: "border-amber-300",
  },
  {
    key: "Q4",
    title: "غیرفوری و غیرمهم",
    action: "حذف کن",
    hint: "حواس‌پرتی — کمتر نگه دار",
    isUrgent: false,
    isImportant: false,
    headClass: "bg-gray-400",
    boxClass: "border-gray-300",
  },
];

export function quadrantOf(isUrgent: boolean, isImportant: boolean): QuadrantDef {
  return QUADRANTS.find((q) => q.isUrgent === isUrgent && q.isImportant === isImportant) || QUADRANTS[3];
}

// ---------- سریال‌سازی ----------

type TaskWithUsers = Task & {
  createdBy: Pick<User, "id" | "username" | "fullName"> | null;
  assignedTo: Pick<User, "id" | "username" | "fullName"> | null;
  transfers?: TaskTransfer[];
};

export interface SerializedTask {
  id: string;
  title: string;
  description: string;
  status: TaskStatus;
  isUrgent: boolean;
  isImportant: boolean;
  dueDateJ: string;
  isOverdue: boolean;
  quadrant: "Q1" | "Q2" | "Q3" | "Q4";
  createdById: string;
  createdByName: string;
  createdByUsername: string;
  assignedToId: string;
  assignedToName: string;
  assignedToUsername: string;
  transferCount: number;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
}

/** آیا وظیفه عقب‌افتاده است؟ (باز/در حال انجام + موعد گذشته) */
export function taskIsOverdue(t: { status: string; dueDateJ: string }): boolean {
  if (t.status === "DONE" || t.status === "CANCELLED") return false;
  if (!t.dueDateJ || !isValidJalali(t.dueDateJ)) return false;
  return diffJalaliDays(todayJalaliStr(), t.dueDateJ) < 0;
}

export function serializeTask(t: TaskWithUsers): SerializedTask {
  const isOverdue = taskIsOverdue(t);
  const q = quadrantOf(t.isUrgent, t.isImportant);
  return {
    id: t.id,
    title: t.title,
    description: t.description || "",
    status: (TASK_STATUSES as readonly string[]).includes(t.status) ? (t.status as TaskStatus) : "OPEN",
    isUrgent: t.isUrgent,
    isImportant: t.isImportant,
    dueDateJ: t.dueDateJ || "",
    isOverdue,
    quadrant: q.key,
    createdById: t.createdById,
    createdByName: t.createdBy?.fullName || "",
    createdByUsername: t.createdBy?.username || "",
    assignedToId: t.assignedToId,
    assignedToName: t.assignedTo?.fullName || "",
    assignedToUsername: t.assignedTo?.username || "",
    transferCount: t.transfers?.length ?? 0,
    createdAt: t.createdAt.toISOString(),
    updatedAt: t.updatedAt.toISOString(),
    completedAt: t.completedAt?.toISOString() || null,
  };
}

/** اعتبارسنجی موعد شمسی — «1405/7/15» یا «1405/07/15» یا خالی */
export function normalizeDueDate(v: unknown): string {
  const s = String(v ?? "").trim();
  if (!s) return "";
  const p = s.split("/").map((x) => x.trim());
  if (p.length !== 3) return "";
  const norm = `${p[0]}/${String(+p[1]).padStart(2, "0")}/${String(+p[2]).padStart(2, "0")}`;
  return isValidJalali(norm) ? norm : "";
}

// ---------- گراف زنجیره واگذاری ----------

export interface GraphNode {
  id: string;
  name: string;
  username: string;
  isRoot: boolean; // ریشه زنجیره (من / ایجادکننده)
  depth: number;
  /** شمار وظایفی که الان نزد این کاربر است */
  openCount: number;
  inProgressCount: number;
  doneCount: number;
}

export interface GraphEdge {
  fromId: string;
  toId: string;
  count: number;
  openCount: number;
  inProgressCount: number;
  doneCount: number;
  /** عناوین وظایف این یال (برای راهنمای هاور — حداکثر ۵) */
  sampleTitles: string[];
}

export interface GraphTaskLite {
  id: string;
  title: string;
  status: TaskStatus;
  isOverdue: boolean;
  dueDateJ: string;
  assignedToId: string;
  assignedToName: string;
  createdByName: string;
  transferCount: number;
}

/** ساخت گراف واگذاری از وظایف + انتقال‌ها — RTL-friendly */
export function buildDelegationGraph(
  tasks: (Task & { assignedTo: Pick<User, "id" | "username" | "fullName"> | null; transfers: TaskTransfer[] })[],
  rootId: string,
  rootName: string,
  rootUsername: string
): { nodes: GraphNode[]; edges: GraphEdge[] } {
  const nodeMap = new Map<string, GraphNode>();
  const ensureNode = (id: string, name: string, username: string) => {
    if (!nodeMap.has(id)) {
      nodeMap.set(id, {
        id, name, username, isRoot: id === rootId, depth: 0,
        openCount: 0, inProgressCount: 0, doneCount: 0,
      });
    }
    return nodeMap.get(id)!;
  };
  ensureNode(rootId, rootName, rootUsername);

  // یال‌ها: هر واگذاری یک جابه‌جایی فرستنده → گیرنده
  // وظیفه‌ای که هیچ واگذاری ندارد: یال ایجادکننده → مسئول فعلی
  const edgeMap = new Map<string, GraphEdge>();
  const ensureEdge = (fromId: string, toId: string) => {
    const k = `${fromId}>${toId}`;
    if (!edgeMap.has(k)) {
      edgeMap.set(k, {
        fromId, toId, count: 0, openCount: 0, inProgressCount: 0, doneCount: 0, sampleTitles: [],
      });
    }
    return edgeMap.get(k)!;
  };

  for (const t of tasks) {
    const statusBucket = t.status === "OPEN" ? "openCount" : t.status === "IN_PROGRESS" ? "inProgressCount" : "doneCount";
    const holder = ensureNode(t.assignedToId, t.assignedTo?.fullName || "—", t.assignedTo?.username || "");
    if (t.status !== "CANCELLED") holder[statusBucket]++;

    if (t.transfers.length === 0) {
      // بدون واگذاری: ایجادکننده → مسئول
      if (t.createdById !== t.assignedToId) {
        const e = ensureEdge(t.createdById, t.assignedToId);
        e.count++;
        if (t.status !== "CANCELLED") e[statusBucket]++;
        if (e.sampleTitles.length < 5) e.sampleTitles.push(t.title);
      }
    } else {
      // زنجیره واگذاری + حلقه آخر به مسئول فعلی
      let prevId = t.createdById;
      for (const tr of t.transfers) {
        ensureNode(tr.fromId, tr.fromName || "—", "");
        ensureNode(tr.toId, tr.toName || "—", "");
        if (tr.fromId !== prevId && nodeMap.has(prevId)) {
          // انتقال با مبدأ ناهم‌خوان (نظری) — باز هم رسم می‌کنیم
        }
        if (tr.fromId !== tr.toId) {
          const e = ensureEdge(tr.fromId, tr.toId);
          e.count++;
          if (t.status !== "CANCELLED") e[statusBucket]++;
          if (e.sampleTitles.length < 5) e.sampleTitles.push(t.title);
        }
        prevId = tr.toId;
      }
      // اگر مسئول فعلی با آخرین گیرنده زنجیره فرق دارد (ویرایش مستقیم میدان مسئول)
      if (prevId !== t.assignedToId) {
        const e = ensureEdge(prevId, t.assignedToId);
        e.count++;
        if (t.status !== "CANCELLED") e[statusBucket]++;
        if (e.sampleTitles.length < 5) e.sampleTitles.push(t.title);
      }
    }
  }

  // عمق‌ها با BFS از ریشه
  const adj = new Map<string, string[]>();
  for (const e of edgeMap.values()) {
    if (!adj.has(e.fromId)) adj.set(e.fromId, []);
    adj.get(e.fromId)!.push(e.toId);
  }
  const queue = [rootId];
  const seen = new Set([rootId]);
  while (queue.length) {
    const cur = queue.shift()!;
    for (const nxt of adj.get(cur) || []) {
      if (!seen.has(nxt)) {
        seen.add(nxt);
        const n = nodeMap.get(nxt);
        if (n) n.depth = (nodeMap.get(cur)?.depth ?? 0) + 1;
        queue.push(nxt);
      }
    }
  }
  // نودهای وصل‌نشده به ریشه (مثلاً مسئولِ بدون زنجیره) — عمق ۱
  for (const n of nodeMap.values()) {
    if (!seen.has(n.id) && n.id !== rootId) {
      n.depth = 1;
      seen.add(n.id);
    }
  }

  return { nodes: [...nodeMap.values()], edges: [...edgeMap.values()] };
}

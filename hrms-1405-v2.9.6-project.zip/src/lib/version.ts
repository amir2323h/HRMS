import { db } from "@/lib/db";

// ============================================================
// نسخه نصب‌شده — منبع حقیقت با اولویت:
//  ۱) env APP_VERSION (نصب‌کننده VPS در .env / ENV داکر / env پنل)
//  ۲) مهر دیتابیس — SystemSetting «app_version» که در بیلد/بوت نوشته می‌شود
//     (docker-bootstrap در Nixpacks/داکپلوی، dbprep داکر، بک‌فیل‌های ارتقا)
// fallback دیتابیس برای استقرارهای PaaS حیاتی است که .env آن‌ها APP_VERSION
// ندارد (داکپلوی/کولیفای/ریلوی) — بدون آن فوتر و پنل آپدیت نسخه‌ای نشان
// نمی‌دادند (باگ v2.9.5).
// ۳۰ ثانیه کش درون‌حافظه‌ای — درخواست‌های پرتکرار (فوتر/صفحه ورود) به
// دیتابیس نمی‌رسند.
// ============================================================

const TTL_MS = 30_000;
let cached: { v: string; t: number } | null = null;

export async function getAppVersion(): Promise<string> {
  const env = (process.env.APP_VERSION || "").trim();
  if (env) return env;
  if (cached && Date.now() - cached.t < TTL_MS) return cached.v;
  try {
    const row = await db.systemSetting.findUnique({ where: { key: "app_version" } });
    // مقدار ممکن است رشته ساده یا JSON-quoted باشد — هر دو پشتیبانی می‌شوند
    const v = String(row?.value ?? "")
      .trim()
      .replace(/^"(.*)"$/, "$1")
      .trim();
    cached = { v, t: Date.now() };
    return v;
  } catch {
    // دیتابیس در دسترس نیست (مثلاً بیلد‌تایم) — خالی برمی‌گردد
    return "";
  }
}

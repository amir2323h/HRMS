import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getLegalParams, saveLegalParams, getDisplaySettings, getCompanyInfo } from "@/lib/settings";
import { getLetterSettings, saveLetterSettings, stripLetterImages } from "@/lib/letters";
import { getChangelog, saveChangelog, type ChangelogItem, type ChangelogConfig } from "@/lib/changelog";
import { getAppVersion } from "@/lib/version";

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "settings:view");
    const [params, display, company, letters, roles, changelog, users] = await Promise.all([
      getLegalParams(true),
      getDisplaySettings(),
      getCompanyInfo(),
      getLetterSettings(),
      db.role.findMany({ orderBy: { key: "asc" }, select: { key: true, name: true } }),
      getChangelog(),
      // گزینه‌های دراپ‌داون امضاکنندگان — کاربران فعال با عنوان شغلی کارمند متصل
      db.user.findMany({
        where: { isActive: true },
        orderBy: { fullName: "asc" },
        select: { id: true, username: true, fullName: true, role: true, employee: { select: { jobTitle: true } } },
      }),
    ]);
    // تصاویر سربرگ از این پاسخ حذف می‌شوند (حجم بالا) — از /api/letters/letterhead
    return {
      params,
      display,
      company,
      letters: stripLetterImages(letters),
      roles: roles.map((r) => ({ key: r.key, name: r.name })),
      changelog,
      appVersion: await getAppVersion(),
      signerCandidates: users.map((u) => ({
        id: u.id,
        username: u.username,
        fullName: u.fullName,
        role: u.role,
        jobTitle: u.employee?.jobTitle || "",
      })),
    };
  });
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:manage");
    const b = await req.json();
    const before = await getLegalParams(true);

    // اعتبارسنجی و ذخیره پارامترهای قانونی — فقط وقتی params ارسال شده
    // (ذخیره مستقل تنظیمات نامه/شرکت بدون ارسال params مجاز است)
    if (b.params) {
      const brackets = (b.params.taxBrackets || []) as {
        sortOrder: number; lowerLimit: number; upperLimit: number | null; rate: number;
      }[];
      if (brackets.length === 0) return Response.json({ error: "حداقل یک پله مالیاتی لازم است." }, { status: 400 });
      const sorted = [...brackets].sort((x, y) => x.lowerLimit - y.lowerLimit);
      for (let i = 0; i < sorted.length; i++) {
        const br = sorted[i];
        if (br.rate < 0 || br.rate > 1) return Response.json({ error: "نرخ مالیات باید بین ۰ و ۱ باشد." }, { status: 400 });
        if (br.upperLimit !== null && br.upperLimit <= br.lowerLimit) {
          return Response.json({ error: `سقف پله ${i + 1} باید بزرگ‌تر از کف آن باشد.` }, { status: 400 });
        }
        if (i > 0 && Math.round(br.lowerLimit) !== Math.round(sorted[i - 1].upperLimit ?? -1)) {
          return Response.json({ error: "پله‌های مالیاتی باید پیوسته باشند (کف هر پله = سقف پله قبل)." }, { status: 400 });
        }
      }
      if (sorted[sorted.length - 1].upperLimit !== null) {
        return Response.json({ error: "آخرین پله باید بدون سقف (بی‌نهایت) باشد." }, { status: 400 });
      }

      const p = b.params;
      const next = {
        year: 1405,
        employeeSsoRate: clampRate(p.employeeSsoRate, before.employeeSsoRate),
        employerSsoRate: clampRate(p.employerSsoRate, before.employerSsoRate),
        unemploymentRate: clampRate(p.unemploymentRate, before.unemploymentRate),
        minWage: Math.round(+p.minWage || before.minWage),
        insurableCap: p.insurableCap === null || p.insurableCap === undefined || !+p.insurableCap ? null : Math.round(+p.insurableCap),
        housing: Math.round(+p.housing || 0),
        grocery: Math.round(+p.grocery || 0),
        childPerChild: Math.round(+p.childPerChild || 0),
        maxChildrenForAllowance: Math.max(0, Math.round(+p.maxChildrenForAllowance ?? 2)),
        // حق تاهل ۱۴۰۵ — کارکنان متاهل (مصوبه شورای عالی کار)
        marriageAllowance: Number.isFinite(+p.marriageAllowance) ? Math.max(0, Math.round(+p.marriageAllowance)) : before.marriageAllowance,
        // پایه سنوات — LEGAL = جدول تجمیعی رسمی | GRADE = پایه هر سال از طبقه شغلی
        seniorityMode: (p.seniorityMode === "GRADE" ? "GRADE" : "LEGAL") as "LEGAL" | "GRADE",
        seniorityDailyByYear: Array.isArray(p.seniorityDailyByYear) && p.seniorityDailyByYear.length > 0
          ? p.seniorityDailyByYear.slice(0, 40).map((v: number) => Math.max(0, Math.round(+v || 0)))
          : (before.seniorityDailyByYear || []),
        monthlyWorkHours: Math.max(100, Math.round(+p.monthlyWorkHours || 220)),
        overtimeMultiplier: +p.overtimeMultiplier > 1 ? +p.overtimeMultiplier : before.overtimeMultiplier,
        // ---- ضرایب شیفت/شب/تعطیل (ماده ۵۶/۵۸/۶۲ قانون کار — قابل ویرایش) ----
        nightPremium: +p.nightPremium > 0 && +p.nightPremium <= 2 ? +p.nightPremium : before.nightPremium,
        fridayMultiplier: +p.fridayMultiplier > 1 && +p.fridayMultiplier <= 3 ? +p.fridayMultiplier : before.fridayMultiplier,
        holidayMultiplier: +p.holidayMultiplier > 1 && +p.holidayMultiplier <= 3 ? +p.holidayMultiplier : before.holidayMultiplier,
        shiftTwoRate: +p.shiftTwoRate >= 0 && +p.shiftTwoRate <= 1 ? +p.shiftTwoRate : before.shiftTwoRate,
        shiftThreeRate: +p.shiftThreeRate >= 0 && +p.shiftThreeRate <= 1 ? +p.shiftThreeRate : before.shiftThreeRate,
        missionMultiplier: +p.missionMultiplier >= 0 && +p.missionMultiplier <= 10 ? +p.missionMultiplier : before.missionMultiplier,
        groceryTaxable: !!p.groceryTaxable,
        taxBrackets: sorted.map((br, i) => ({
          sortOrder: i + 1,
          lowerLimit: Math.round(br.lowerLimit),
          upperLimit: br.upperLimit === null ? null : Math.round(br.upperLimit),
          rate: br.rate,
        })),
      };
      if (next.minWage < 1000) return Response.json({ error: "حداقل دستمزد نامعتبر است." }, { status: 400 });

      await saveLegalParams(next);
      await audit(
        session,
        "UPDATE",
        "SETTINGS",
        "legal_params",
        "به‌روزرسانی پارامترهای قانونی و پله‌های مالیاتی",
        { minWage: before.minWage, housing: before.housing, grocery: before.grocery, childPerChild: before.childPerChild, brackets: before.taxBrackets.length },
        { minWage: next.minWage, housing: next.housing, grocery: next.grocery, childPerChild: next.childPerChild, brackets: next.taxBrackets.length }
      );
    }

    // سایر تنظیمات
    if (b.display?.unit === "RIAL" || b.display?.unit === "TOMAN") {
      await db.systemSetting.upsert({
        where: { key: "display" },
        update: { value: JSON.stringify({ unit: b.display.unit }) },
        create: { key: "display", value: JSON.stringify({ unit: b.display.unit }) },
      });
    }
    if (b.company && b.company.name?.trim()) {
      const c = b.company;
      const clean = {
        name: String(c.name).trim(),
        nationalId: String(c.nationalId || "").trim().slice(0, 20),
        ssoCode: String(c.ssoCode || "").trim().slice(0, 30),
        taxId: String(c.taxId || "").trim().slice(0, 30),
        address: String(c.address || "").trim().slice(0, 200),
        // اطلاعات تماس پابرگ نامه‌ها
        phone: String(c.phone || "").trim().slice(0, 30),
        mobile: String(c.mobile || "").trim().slice(0, 30),
        website: String(c.website || "").trim().slice(0, 100),
        email: String(c.email || "").trim().slice(0, 100),
      };
      await db.systemSetting.upsert({
        where: { key: "company" },
        update: { value: JSON.stringify(clean) },
        create: { key: "company", value: JSON.stringify(clean) },
      });
    }

    // تنظیمات نامه‌ها (پیش‌شماره شماره‌گذاری + امضاکننده پیش‌فرض + امضاکنندگان مجاز
    // + سیاست دانلود کارمند + روال‌های تأیید داینامیک)
    // فیلد غایب = undefined = بدون تغییر (ذخیره مستقل هر کارت)
    if (b.letters && typeof b.letters === "object") {
      const beforeLetters = await getLetterSettings();
      const isFlows = b.letters.approvalFlows !== undefined;
      const isPolicy = b.letters.downloadPolicy !== undefined;
      const saved = await saveLetterSettings({
        numberingPrefix: b.letters.numberingPrefix !== undefined ? String(b.letters.numberingPrefix).trim() : undefined,
        signerName: b.letters.signerName !== undefined ? String(b.letters.signerName).trim() : undefined,
        signerTitle: b.letters.signerTitle !== undefined ? String(b.letters.signerTitle).trim() : undefined,
        signers: b.letters.signers !== undefined ? b.letters.signers : undefined,
        downloadPolicy: isPolicy ? b.letters.downloadPolicy : undefined,
        approvalFlows: isFlows ? b.letters.approvalFlows : undefined,
        categoryFlows: b.letters.categoryFlows !== undefined ? b.letters.categoryFlows : undefined,
        // نمایش/عدم نمایش مهر امضای دیجیتال در چاپ — از تب «اطلاعات پایه»
        showDigitalSignature: b.letters.showDigitalSignature !== undefined ? !!b.letters.showDigitalSignature : undefined,
      });
      const summary = b.letters.signers !== undefined
        ? "به‌روزرسانی امضاکنندگان مجاز نامه‌ها"
        : isFlows
          ? `به‌روزرسانی روال‌های تأیید نامه‌ها (${saved.approvalFlows.length} روال)`
          : isPolicy
            ? `سیاست دانلود نامه کارکنان ${saved.downloadPolicy.employeeCanDownload ? "فعال" : "غیرفعال"} شد`
            : "به‌روزرسانی تنظیمات نامه‌ها (شماره‌گذاری/امضاکننده)";
      await audit(
        session,
        "UPDATE",
        "SETTINGS",
        "letters",
        summary,
        {
          numberingPrefix: beforeLetters.numberingPrefix, signerTitle: beforeLetters.signerTitle,
          signers: beforeLetters.signers.map((s) => `${s.name} (${s.title})`),
          downloadPolicy: beforeLetters.downloadPolicy,
          approvalFlows: beforeLetters.approvalFlows.map((f) => `${f.name} [${f.steps.length} مرحله]`),
        },
        {
          numberingPrefix: saved.numberingPrefix, signerTitle: saved.signerTitle,
          signers: saved.signers.map((s) => `${s.name} (${s.title})`),
          downloadPolicy: saved.downloadPolicy,
          approvalFlows: saved.approvalFlows.map((f) => `${f.name} [${f.steps.length} مرحله]`),
        }
      );
    }

    // اطلاعیه تغییرات محصول (پاپ‌آپ «تازه‌های نسخه») — هدف‌گیری نقش/کاربر
    if (b.changelog && typeof b.changelog === "object") {
      const before = await getChangelog();
      const c = b.changelog as Partial<ChangelogConfig>;
      const saved = await saveChangelog({
        version: c.version !== undefined ? String(c.version) : undefined,
        title: c.title !== undefined ? String(c.title) : undefined,
        items: c.items !== undefined ? (c.items as ChangelogItem[]) : undefined,
        enabled: c.enabled !== undefined ? !!c.enabled : undefined,
        targetAll: c.targetAll !== undefined ? !!c.targetAll : undefined,
        roles: c.roles !== undefined ? (c.roles as string[]) : undefined,
        usernames: c.usernames !== undefined ? (c.usernames as string[]) : undefined,
      });
      await audit(
        session,
        "UPDATE",
        "SETTINGS",
        "changelog",
        `اطلاعیه تغییرات محصول ${saved.enabled ? "فعال" : "غیرفعال"} شد — نسخه ${saved.version || "—"} (${saved.items.length} آیتم، ${saved.targetAll ? "همه کاربران" : `${saved.roles.length} نقش + ${saved.usernames.length} کاربر`})`,
        { version: before.version, enabled: before.enabled, items: before.items.length, targetAll: before.targetAll },
        { version: saved.version, enabled: saved.enabled, items: saved.items.length, targetAll: saved.targetAll }
      );
    }

    const params = await getLegalParams(true);
    return { params };
  });
}

function clampRate(v: unknown, fallback: number): number {
  const n = +v;
  if (isNaN(n) || n <= 0 || n > 1) return fallback;
  return n;
}

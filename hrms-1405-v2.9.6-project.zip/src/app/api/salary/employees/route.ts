import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import { estimateNet, type EmployeeSalaryLike } from "@/lib/salary";
import { todayJalaliStr } from "@/lib/jalali";

/**
 * GET /api/salary/employees — کارکنان فعال + خالص ماهانه تخمینی + پارامترهای قانونی
 * مبنای فرم «محاسبه معکوس گروهی» و «تغییرات گروهی» (محاسبات جزئی سمت کلاینت با همین داده‌ها)
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "salary:manage");
    const params = await getLegalParams();
    const atDateJ = todayJalaliStr();

    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      include: {
        jobGrade: true,
        departments: { include: { department: true } },
      },
      orderBy: [{ lastName: "asc" }, { firstName: "asc" }],
    });

    const list = employees.map((e) => {
      const sheet = estimateNet(e as unknown as EmployeeSalaryLike, params, atDateJ);
      const dep = (e as unknown as { departments?: { department: { name: string } }[] }).departments?.[0]?.department?.name || "";
      return {
        id: e.id,
        personnelCode: e.personnelCode,
        fullName: `${e.firstName} ${e.lastName}`,
        department: dep,
        jobTitle: e.jobTitle || "",
        gradeId: e.jobGradeId || null,
        gradeLevel: e.jobGrade?.level || null,
        gradeTitle: e.jobGrade?.title || "",
        baseSalary: Number(e.baseSalary),
        overtimeHours: e.overtimeHours,
        childCount: e.childCount,
        maritalStatus: e.maritalStatus,
        hireDateJ: e.hireDateJ,
        employmentType: e.employmentType || "DAILY",
        shiftPattern: e.shiftPattern || "",
        // برای محاسبه معکوس سمت کلاینت (متناسب با موتور سرور)
        gradeSeniorityBase: e.jobGrade ? Number(e.jobGrade.seniorityBase) : 0,
        gradeAttraction: e.jobGrade ? Number(e.jobGrade.attraction) : 0,
        // درصدهای تفکیک حقوق ماهانه سطح (پایه/مسولیت/شایستگی) — برای محاسبه معکوس/پیش‌نمایش کلاینت
        gradeRespPercent: e.jobGrade ? Number(e.jobGrade.respPercent) : 0,
        gradeMeritPercent: e.jobGrade ? Number(e.jobGrade.meritPercent) : 0,
        gradeMin: e.jobGrade ? Number(e.jobGrade.minBaseSalary) : null,
        gradeMax: e.jobGrade ? Number(e.jobGrade.maxBaseSalary) : null,
        // خلاصه فیش تخمینی فعلی
        net: sheet.netPay,
        gross: sheet.gross,
        employeeSso: sheet.employeeSso,
        incomeTax: sheet.incomeTax,
        warnings: sheet.warnings,
      };
    });

    const departments = await db.department.findMany({ orderBy: { name: "asc" }, select: { id: true, name: true } });
    // فهرست کامل طبقه‌ها با درصدهای تفکیک — برای پیش‌نمایش تغییر طبقه سمت کلاینت
    const grades = await db.jobGrade.findMany({
      orderBy: { level: "asc" },
      select: { id: true, level: true, title: true, seniorityBase: true, attraction: true, respPercent: true, meritPercent: true },
    });

    return {
      employees: list,
      departments,
      grades: grades.map((g) => ({
        id: g.id,
        level: g.level,
        title: g.title,
        seniorityBase: Number(g.seniorityBase),
        attraction: Number(g.attraction),
        respPercent: Number(g.respPercent),
        meritPercent: Number(g.meritPercent),
      })),
      legal: params,
      today: atDateJ,
    };
  });
}

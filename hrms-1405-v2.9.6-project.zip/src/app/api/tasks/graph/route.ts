import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, sessionHasPerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { buildDelegationGraph, serializeTask, type GraphTaskLite } from "@/lib/tasks";

// ============================================================
// نمای زنجیره واگذاری (نمای نودی مدیران)
//  GET ?scope=created|all
//   • created (پیش‌فرض): زنجیره وظایفی که «من» ایجاد/واگذار کرده‌ام —
//     از من شروع می‌شود و تا مسئول فعلی هر وظیفه ادامه دارد
//   • all (نیازمند users:view): کل گراف واگذاری سازمان
//  خروجی: nodes (کاربران) + edges (جریان کار با شمار وضعیت) + tasks (جزئیات هر نود)
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "tasks:use");
    const url = new URL(req.url);
    const scope = url.searchParams.get("scope") === "all" && sessionHasPerm(session, "users:view") ? "all" : "created";

    const where = scope === "all" ? {} : { createdById: session.uid };
    const rows = await db.task.findMany({
      where,
      include: {
        createdBy: { select: { id: true, username: true, fullName: true } },
        assignedTo: { select: { id: true, username: true, fullName: true } },
        transfers: { orderBy: { createdAt: "asc" } },
      },
      orderBy: [{ updatedAt: "desc" }],
    });

    // نام کاربرانِ زنجیره که در assignedTo نیستند (اسنپ‌شات transfer ممکن است خالی باشد)
    const graph = buildDelegationGraph(rows, session.uid, session.fullName, session.username);

    // وظایف سبک برای پنل جزئیات هر نود
    const tasks: GraphTaskLite[] = rows
      .filter((t) => t.status !== "CANCELLED")
      .map((t) => {
        const s = serializeTask(t);
        return {
          id: s.id,
          title: s.title,
          status: s.status,
          isOverdue: s.isOverdue,
          dueDateJ: s.dueDateJ,
          assignedToId: s.assignedToId,
          assignedToName: s.assignedToName,
          createdByName: s.createdByName,
          transferCount: s.transferCount,
        };
      });

    return {
      scope,
      rootId: session.uid,
      rootName: session.fullName,
      nodes: graph.nodes,
      edges: graph.edges,
      tasks,
      canSeeAll: sessionHasPerm(session, "users:view"),
      totals: {
        tasks: tasks.length,
        open: tasks.filter((t) => t.status === "OPEN").length,
        inProgress: tasks.filter((t) => t.status === "IN_PROGRESS").length,
        done: tasks.filter((t) => t.status === "DONE").length,
        overdue: tasks.filter((t) => t.isOverdue).length,
      },
    };
  });
}

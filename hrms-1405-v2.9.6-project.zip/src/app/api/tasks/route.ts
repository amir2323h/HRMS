import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, ApiError, sessionHasPerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeTask, normalizeDueDate, quadrantOf } from "@/lib/tasks";

// ============================================================
// مدیریت کار — ماتریس آیزنهاور
//  GET  ?scope=mine|created|all   → وظایف در دید کاربر + آمار ربع‌ها
//  POST (tasks:use)               → ایجاد وظیفه جدید (برای خود یا واگذاری به دیگری)
// ============================================================

const taskInclude = {
  createdBy: { select: { id: true, username: true, fullName: true } },
  assignedTo: { select: { id: true, username: true, fullName: true } },
  transfers: { orderBy: { createdAt: "asc" as const } },
} as const;

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "tasks:use");
    const url = new URL(req.url);
    const scopeRaw = url.searchParams.get("scope") || "mine";
    const scope = ["mine", "created", "all"].includes(scopeRaw) ? scopeRaw : "mine";

    // دامنه «همه» فقط برای دارندگان users:view (مدیر کل / مدیر HR)
    const where =
      scope === "all"
        ? sessionHasPerm(session, "users:view")
          ? {}
          : { OR: [{ assignedToId: session.uid }, { createdById: session.uid }] }
        : scope === "created"
          ? { createdById: session.uid }
          : { assignedToId: session.uid };

    const rows = await db.task.findMany({ where, include: taskInclude, orderBy: [{ updatedAt: "desc" }] });
    const tasks = rows.map(serializeTask);

    // آمار ربع‌ها (فقط وظایف باز/در حال انجام — کارهای تمام‌شده ربع نمی‌خواهند)
    const active = tasks.filter((t) => t.status === "OPEN" || t.status === "IN_PROGRESS");
    const counts = { Q1: 0, Q2: 0, Q3: 0, Q4: 0 } as Record<"Q1" | "Q2" | "Q3" | "Q4", number>;
    for (const t of active) counts[t.quadrant]++;
    const doneCount = tasks.filter((t) => t.status === "DONE").length;
    const overdueCount = active.filter((t) => t.isOverdue).length;

    return { tasks, counts, doneCount, overdueCount, scope, canSeeAll: sessionHasPerm(session, "users:view") };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "tasks:use");
    const b = await req.json();

    const title = String(b.title || "").trim();
    if (!title) throw new ApiError("عنوان وظیفه الزامی است.", 400);
    if (title.length > 200) throw new ApiError("عنوان وظیفه حداکثر ۲۰۰ نویسه است.", 400);
    const description = String(b.description || "").trim().slice(0, 2000);

    const isUrgent = Boolean(b.isUrgent);
    const isImportant = Boolean(b.isImportant);
    const status = ["OPEN", "IN_PROGRESS"].includes(String(b.status)) ? String(b.status) : "OPEN";
    const dueDateJ = normalizeDueDate(b.dueDateJ);
    if (b.dueDateJ && String(b.dueDateJ).trim() && !dueDateJ) {
      throw new ApiError("تاریخ سررسید نامعتبر است — نمونه درست: 1405/07/15", 400);
    }

    // مسئول: خودم (پیش‌فرض) یا واگذاری به کاربر فعال دیگر
    let assignedToId = session.uid;
    if (b.assignedToId && String(b.assignedToId) !== session.uid) {
      const target = await db.user.findUnique({ where: { id: String(b.assignedToId) }, select: { id: true, isActive: true, fullName: true } });
      if (!target || !target.isActive) throw new ApiError("کاربر مقصد یافت نشد یا غیرفعال است.", 400);
      assignedToId = target.id;
    }

    const created = await db.task.create({
      data: {
        title,
        description,
        status,
        isUrgent,
        isImportant,
        dueDateJ,
        createdById: session.uid,
        assignedToId,
        ...(assignedToId !== session.uid
          ? {
              transfers: {
                create: {
                  fromId: session.uid,
                  fromName: session.fullName,
                  toId: assignedToId,
                  toName: (await db.user.findUnique({ where: { id: assignedToId }, select: { fullName: true } }))?.fullName || "",
                  note: String(b.note || "").trim().slice(0, 500),
                },
              },
            }
          : {}),
      },
      include: taskInclude,
    });

    await audit(session, "CREATE", "TASK", created.id, `ایجاد وظیفه «${title}» (${quadrantOf(isUrgent, isImportant).title})`, null, {
      title, status, isUrgent, isImportant, dueDateJ, assignedToId,
    });
    return { task: serializeTask(created) };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, ApiError, sessionHasPerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeTask, normalizeDueDate, quadrantOf, TASK_STATUS_LABELS, type TaskStatus } from "@/lib/tasks";

// ============================================================
// مدیریت کار — یک وظیفه
//  GET    (tasks:use — عضو زنجیره)  → جزئیات + خط زمانی واگذاری
//  PATCH  (tasks:use — ایجادکننده/مسئول فعلی/مدیر)
//         • ویرایش فیلدها (عنوان/توضیح/فوری/مهم/موعد/وضعیت)
//         • action:"forward" → واگذاری به کاربر دیگر (حلقه زنجیره ثبت می‌شود)
//  DELETE (tasks:use — ایجادکننده/مدیر) → حذف
// ============================================================

const taskInclude = {
  createdBy: { select: { id: true, username: true, fullName: true } },
  assignedTo: { select: { id: true, username: true, fullName: true } },
  transfers: { orderBy: { createdAt: "asc" as const } },
} as const;

/** مجوز دسترسی به وظیفه: مدیر، ایجادکننده یا مسئول فعلی (یا کسی که در زنجیره واگذاری بوده) */
function canTouch(task: { createdById: string; assignedToId: string; transfers: { fromId: string; toId: string }[] }, uid: string, isAdmin: boolean): boolean {
  if (isAdmin) return true;
  if (task.createdById === uid || task.assignedToId === uid) return true;
  return task.transfers.some((t) => t.fromId === uid || t.toId === uid);
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "tasks:use");
    const { id } = await params;
    const task = await db.task.findUnique({ where: { id }, include: taskInclude });
    if (!task) throw new ApiError("وظیفه یافت نشد.", 404);
    if (!canTouch(task, session.uid, sessionHasPerm(session, "users:manage"))) {
      throw new ApiError("این وظیفه در دسترس شما نیست.", 403);
    }
    return {
      task: serializeTask(task),
      chain: task.transfers.map((t) => ({
        id: t.id,
        fromName: t.fromName || "",
        toName: t.toName || "",
        note: t.note || "",
        createdAt: t.createdAt.toISOString(),
      })),
    };
  });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "tasks:use");
    const { id } = await params;
    const b = await req.json();
    const task = await db.task.findUnique({ where: { id }, include: taskInclude });
    if (!task) throw new ApiError("وظیفه یافت نشد.", 404);
    const isAdmin = sessionHasPerm(session, "users:manage");
    if (!canTouch(task, session.uid, isAdmin)) throw new ApiError("این وظیفه در دسترس شما نیست.", 403);

    const before = serializeTask(task);

    // ---------- واگذاری به کاربر دیگر ----------
    if (b.action === "forward") {
      const toId = String(b.toUserId || "");
      const target = await db.user.findUnique({ where: { id: toId }, select: { id: true, isActive: true, fullName: true } });
      if (!target || !target.isActive) throw new ApiError("کاربر مقصد یافت نشد یا غیرفعال است.", 400);
      if (toId === task.assignedToId) throw new ApiError("این وظیفه هم‌اکنون نزد همان کاربر است.", 400);
      const note = String(b.note || "").trim().slice(0, 500);

      const updated = await db.task.update({
        where: { id },
        data: {
          assignedToId: toId,
          transfers: {
            create: {
              fromId: session.uid,
              fromName: session.fullName,
              toId,
              toName: target.fullName,
              note,
            },
          },
        },
        include: taskInclude,
      });
      await audit(session, "UPDATE", "TASK", id, `واگذاری «${task.title}» به ${target.fullName}`, before, { assignedToId: toId });
      return { task: serializeTask(updated) };
    }

    // ---------- ویرایش فیلدها ----------
    const data: Record<string, unknown> = {};
    if (b.title !== undefined) {
      const title = String(b.title).trim();
      if (!title) throw new ApiError("عنوان وظیفه نمی‌تواند خالی باشد.", 400);
      if (title.length > 200) throw new ApiError("عنوان وظیفه حداکثر ۲۰۰ نویسه است.", 400);
      data.title = title;
    }
    if (b.description !== undefined) data.description = String(b.description).trim().slice(0, 2000);
    if (b.isUrgent !== undefined) data.isUrgent = Boolean(b.isUrgent);
    if (b.isImportant !== undefined) data.isImportant = Boolean(b.isImportant);
    if (b.dueDateJ !== undefined) {
      const due = normalizeDueDate(b.dueDateJ);
      if (String(b.dueDateJ).trim() && !due) throw new ApiError("تاریخ سررسید نامعتبر است — نمونه درست: 1405/07/15", 400);
      data.dueDateJ = due;
    }
    if (b.status !== undefined) {
      const st = String(b.status);
      if (!["OPEN", "IN_PROGRESS", "DONE", "CANCELLED"].includes(st)) throw new ApiError("وضعیت نامعتبر است.", 400);
      data.status = st;
      data.completedAt = st === "DONE" ? new Date() : null;
    }
    if (!Object.keys(data).length) throw new ApiError("چیزی برای به‌روزرسانی ارسال نشد.", 400);

    const updated = await db.task.update({ where: { id }, data, include: taskInclude });
    const after = serializeTask(updated);
    const parts: string[] = [];
    if (b.status !== undefined) parts.push(`وضعیت → ${TASK_STATUS_LABELS[after.status as TaskStatus]}`);
    if (b.isUrgent !== undefined || b.isImportant !== undefined) {
      parts.push(`ربع → ${quadrantOf(after.isUrgent, after.isImportant).title}`);
    }
    await audit(session, "UPDATE", "TASK", id, `ویرایش وظیفه «${after.title}»${parts.length ? " — " + parts.join("، ") : ""}`, before, after);
    return { task: after };
  });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "tasks:use");
    const { id } = await params;
    const task = await db.task.findUnique({ where: { id }, include: taskInclude });
    if (!task) throw new ApiError("وظیفه یافت نشد.", 404);
    const isAdmin = sessionHasPerm(session, "users:manage");
    if (task.createdById !== session.uid && !isAdmin) {
      throw new ApiError("حذف وظیفه فقط توسط ایجادکننده یا مدیر سامانه ممکن است.", 403);
    }
    await db.task.delete({ where: { id } });
    await audit(session, "DELETE", "TASK", id, `حذف وظیفه «${task.title}»`, serializeTask(task), null);
    return { ok: true };
  });
}

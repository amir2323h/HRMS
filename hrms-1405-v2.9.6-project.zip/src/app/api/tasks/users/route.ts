import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";

// ============================================================
// فهرست کاربران قابل واگذاری — برای همه دارندگان tasks:use
// فقط فیلدهای حداقلی (نام + نام کاربری + نقش) — برای انتخاب «واگذار به»
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "tasks:use");
    const [users, roles] = await Promise.all([
      db.user.findMany({
        where: { isActive: true },
        select: { id: true, username: true, fullName: true, roleId: true },
        orderBy: { fullName: "asc" },
      }),
      db.role.findMany({ select: { id: true, name: true } }),
    ]);
    const roleMap = new Map(roles.map((r) => [r.id, r.name]));
    return {
      users: users.map((u) => ({
        id: u.id,
        username: u.username,
        fullName: u.fullName,
        roleName: u.roleId ? roleMap.get(u.roleId) || "" : "",
        isMe: u.id === session.uid,
      })),
    };
  });
}

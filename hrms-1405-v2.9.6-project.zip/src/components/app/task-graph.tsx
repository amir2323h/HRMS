"use client";

// ============================================================
// نمای زنجیره واگذاری — گراف نودی (SVG بومی، بدون هیچ CDN)
//  • ریشه: «من» (ایجادکننده وظایف) — شاخه‌ها: گیرنده‌های واگذاری
//  • هر نود = یک کاربر با شمار وظایف باز/در حال انجام/انجام‌شده
//  • هر یال = جریان کار بین دو کاربر (شمار + وضعیت)
//  • کلیک نود → پنل «این نفر الان چه کارهایی دارد»
//  • زوم + جابه‌جایی افقی (scroll) — سازگار با لمس و ماوس
// ============================================================
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Network, ZoomIn, ZoomOut, Maximize, Users, ArrowLeftRight } from "lucide-react";
import { toFaDigits, formatDateJ } from "@/lib/jalali";
import { TASK_STATUS_LABELS, type GraphNode, type GraphEdge, type GraphTaskLite, type TaskStatus } from "@/lib/tasks";

export interface GraphData {
  scope: string;
  rootId: string;
  rootName: string;
  nodes: GraphNode[];
  edges: GraphEdge[];
  tasks: GraphTaskLite[];
  canSeeAll: boolean;
  totals: { tasks: number; open: number; inProgress: number; done: number; overdue: number };
}

const NODE_W = 200;
const NODE_H = 84;
const ROW_GAP = 120;
const COL_GAP = 36;
const PAD = 30;

interface Pos {
  x: number;
  y: number;
}

/** چینش سطری درختی — هر «عمق» یک ردیف؛ نودهای ردیف وسط‌چین افقی */
function layout(nodes: GraphNode[]): { pos: Map<string, Pos>; width: number; height: number } {
  const rows = new Map<number, GraphNode[]>();
  for (const n of nodes) {
    if (!rows.has(n.depth)) rows.set(n.depth, []);
    rows.get(n.depth)!.push(n);
  }
  const depths = [...rows.keys()].sort((a, b) => a - b);
  const rowCounts = depths.map((d) => rows.get(d)!.length);
  const maxCount = Math.max(1, ...rowCounts);
  const width = Math.max(maxCount * (NODE_W + COL_GAP) - COL_GAP + PAD * 2, 640);
  const pos = new Map<string, Pos>();
  for (const d of depths) {
    const row = rows.get(d)!;
    const rowW = row.length * (NODE_W + COL_GAP) - COL_GAP;
    let x = (width - rowW) / 2;
    const y = PAD + d * (NODE_H + ROW_GAP);
    // ترتیب پایدار: نام
    row.sort((a, b) => a.name.localeCompare(b.name, "fa"));
    for (const n of row) {
      pos.set(n.id, { x, y });
      x += NODE_W + COL_GAP;
    }
  }
  const height = PAD * 2 + Math.max(1, depths.length) * (NODE_H + ROW_GAP) - ROW_GAP;
  return { pos, width, height };
}

function statusChipClass(status: TaskStatus, overdue: boolean): string {
  if (overdue && (status === "OPEN" || status === "IN_PROGRESS")) return "bg-red-100 text-red-800 border-red-200";
  if (status === "OPEN") return "bg-amber-100 text-amber-800 border-amber-200";
  if (status === "IN_PROGRESS") return "bg-blue-100 text-blue-800 border-blue-200";
  return "bg-green-100 text-green-800 border-green-200";
}

export function TaskGraph({ data }: { data: GraphData }) {
  const [zoom, setZoom] = useState(1);
  const [selected, setSelected] = useState<string | null>(null);

  const { pos, width, height } = useMemo(() => layout(data.nodes), [data.nodes]);

  /** یال‌ها به‌صورت منحنی بزیه از پایین نود مبدأ به بالای نود مقصد */
  const edgePaths = useMemo(() => {
    return data.edges
      .map((e) => {
        const a = pos.get(e.fromId);
        const b = pos.get(e.toId);
        if (!a || !b) return null;
        const x1 = a.x + NODE_W / 2;
        const y1 = a.y + NODE_H;
        const x2 = b.x + NODE_W / 2;
        const y2 = b.y;
        const my = (y1 + y2) / 2;
        return {
          key: `${e.fromId}>${e.toId}`,
          d: `M ${x1} ${y1} C ${x1} ${my}, ${x2} ${my}, ${x2} ${y2}`,
          mx: (x1 + x2) / 2,
          my,
          edge: e,
        };
      })
      .filter(Boolean) as { key: string; d: string; mx: number; my: number; edge: GraphEdge }[];
  }, [data.edges, pos]);

  const selectedNode = selected ? data.nodes.find((n) => n.id === selected) : null;
  const selectedTasks = selected ? data.tasks.filter((t) => t.assignedToId === selected) : [];

  if (!data.nodes.length || (data.nodes.length === 1 && !data.totals.tasks)) {
    return (
      <Card className="border-dashed">
        <CardContent className="flex flex-col items-center justify-center gap-3 py-16 text-center">
          <Network className="h-12 w-12 text-muted-foreground/40" />
          <div className="text-base font-medium">هنوز زنجیره‌ای برای نمایش نیست</div>
          <p className="max-w-md text-sm text-muted-foreground leading-6">
            وقتی وظیفه‌ای بسازید یا کاری به همکاران واگذار کنید، اینجا نقشهٔ زنجیرهٔ واگذاری
            رسم می‌شود: از شما شروع می‌شود و نشان می‌دهد هر کار الان نزد کیست و چه وضعیتی دارد.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* نوار ابزار */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <Badge variant="outline" className="gap-1 border-indigo-200 bg-indigo-50 text-indigo-700">
            <Users className="h-3 w-3" /> ریشه: {data.rootName}
          </Badge>
          <Badge variant="outline" className="border-amber-200 bg-amber-50 text-amber-700">
            باز: {toFaDigits(data.totals.open)}
          </Badge>
          <Badge variant="outline" className="border-blue-200 bg-blue-50 text-blue-700">
            در حال انجام: {toFaDigits(data.totals.inProgress)}
          </Badge>
          <Badge variant="outline" className="border-green-200 bg-green-50 text-green-700">
            انجام‌شده: {toFaDigits(data.totals.done)}
          </Badge>
          {data.totals.overdue > 0 && (
            <Badge variant="outline" className="border-red-200 bg-red-50 text-red-700">
              عقب‌افتاده: {toFaDigits(data.totals.overdue)}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))} title="کوچک‌نمایی">
            <ZoomOut className="h-4 w-4" />
          </Button>
          <span className="w-12 text-center text-xs text-muted-foreground">{toFaDigits(Math.round(zoom * 100))}٪</span>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom((z) => Math.min(1.6, +(z + 0.1).toFixed(2)))} title="بزرگ‌نمایی">
            <ZoomIn className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8" onClick={() => setZoom(1)} title="بازنشانی">
            <Maximize className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-[1fr_360px]">
        {/* بوم گراف */}
        <Card className="overflow-hidden">
          <CardContent className="overflow-auto p-0" dir="ltr">
            <svg
              width={width * zoom}
              height={height * zoom}
              viewBox={`0 0 ${width} ${height}`}
              className="block select-none"
              style={{ direction: "ltr" }}
            >
              {/* یال‌ها */}
              {edgePaths.map(({ key, d, mx, my, edge }) => (
                <g key={key}>
                  <path d={d} fill="none" stroke="#cbd5e1" strokeWidth={1.8 + Math.min(edge.count, 6) * 0.5} strokeDasharray={edge.openCount + edge.inProgressCount === 0 ? "6 4" : undefined} />
                  {/* برچسب یال — شمار کار */}
                  <g>
                    <rect x={mx - 26} y={my - 11} width={52} height={22} rx={11} fill="#f8fafc" stroke="#e2e8f0" />
                    <text x={mx} y={my + 4} textAnchor="middle" fontSize={11} fill="#475569" style={{ direction: "rtl" }}>
                      {toFaDigits(edge.count)} کار
                    </text>
                  </g>
                  {/* نقطه‌های وضعیت */}
                  <g>
                    <circle cx={mx - 34} cy={my} r={4} fill="#f59e0b" opacity={edge.openCount ? 1 : 0.15} />
                    <circle cx={mx + 34} cy={my} r={4} fill="#3b82f6" opacity={edge.inProgressCount ? 1 : 0.15} />
                  </g>
                </g>
              ))}

              {/* نودها */}
              {[...data.nodes]
                .sort((a, b) => a.depth - b.depth)
                .map((n) => {
                  const p = pos.get(n.id);
                  if (!p) return null;
                  const isActive = n.openCount + n.inProgressCount > 0;
                  const isSelected = selected === n.id;
                  return (
                    <g
                      key={n.id}
                      transform={`translate(${p.x}, ${p.y})`}
                      className="cursor-pointer"
                      onClick={() => setSelected(isSelected ? null : n.id)}
                    >
                      <rect
                        width={NODE_W}
                        height={NODE_H}
                        rx={14}
                        fill={n.isRoot ? "#eef2ff" : "#ffffff"}
                        stroke={isSelected ? "#4f46e5" : n.isRoot ? "#6366f1" : isActive ? "#94a3b8" : "#cbd5e1"}
                        strokeWidth={isSelected || n.isRoot ? 2.2 : 1.4}
                      />
                      {/* نام + شناسه */}
                      <text x={NODE_W / 2} y={28} textAnchor="middle" fontSize={13} fontWeight={700} fill="#1e293b" style={{ direction: "rtl" }}>
                        {n.isRoot ? `${n.name} (من)` : n.name}
                      </text>
                      <text x={NODE_W / 2} y={46} textAnchor="middle" fontSize={10.5} fill="#64748b" style={{ direction: "rtl" }}>
                        {n.isRoot ? "ریشه زنجیره" : n.username ? `@${n.username}` : "کاربر"}
                      </text>
                      {/* شمار وضعیت‌ها */}
                      <g>
                        <rect x={14} y={56} width={50} height={19} rx={9.5} fill="#fef3c7">
                          <title>باز</title>
                        </rect>
                        <text x={39} y={69.5} textAnchor="middle" fontSize={10} fill="#b45309">{toFaDigits(n.openCount)}</text>
                        <rect x={74} y={56} width={50} height={19} rx={9.5} fill="#dbeafe">
                          <title>در حال انجام</title>
                        </rect>
                        <text x={99} y={69.5} textAnchor="middle" fontSize={10} fill="#1d4ed8">{toFaDigits(n.inProgressCount)}</text>
                        <rect x={134} y={56} width={52} height={19} rx={9.5} fill="#dcfce7">
                          <title>انجام‌شده</title>
                        </rect>
                        <text x={160} y={69.5} textAnchor="middle" fontSize={10} fill="#15803d">{toFaDigits(n.doneCount)}</text>
                      </g>
                    </g>
                  );
                })}
            </svg>
          </CardContent>
        </Card>

        {/* پنل جزئیات نود انتخابی */}
        <Card className={selectedNode ? "" : "border-dashed"}>
          <CardHeader className="pb-2 pt-4">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold">
              <ArrowLeftRight className="h-4 w-4 text-muted-foreground" />
              {selectedNode ? `کارهای نزد ${selectedNode.name}` : "یک نود را انتخاب کنید"}
            </CardTitle>
          </CardHeader>
          <CardContent className="max-h-[520px] space-y-2 overflow-y-auto pt-0 text-sm">
            {!selectedNode ? (
              <p className="py-8 text-center text-xs leading-6 text-muted-foreground">
                روی هر کاربر در نقشه کلیک کنید تا ببینید چه کارهایی الان نزد اوست،
                وضعیت هر کدام چیست و از کی به او رسیده.
              </p>
            ) : selectedTasks.length === 0 ? (
              <p className="py-8 text-center text-xs text-muted-foreground">کار فعالی نزد این کاربر نیست.</p>
            ) : (
              selectedTasks.map((t) => (
                <div key={t.id} className="rounded-lg border p-3 leading-5">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-medium">{t.title}</span>
                    <span className={`shrink-0 rounded-full border px-2 py-0.5 text-[10px] ${statusChipClass(t.status, t.isOverdue)}`}>
                      {t.isOverdue && t.status !== "DONE" ? "عقب‌افتاده" : TASK_STATUS_LABELS[t.status]}
                    </span>
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-muted-foreground">
                    {t.dueDateJ && <span>موعد: {formatDateJ(t.dueDateJ)}</span>}
                    {t.transferCount > 0 && <span>{toFaDigits(t.transferCount)} واگذاری</span>}
                    <span>از: {t.createdByName || "—"}</span>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

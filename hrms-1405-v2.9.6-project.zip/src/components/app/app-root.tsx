"use client";

import { useEffect, useMemo, useState, useCallback } from "react";
import {
  LayoutDashboard, Users, Building2, Layers, Wallet, Calculator, ClipboardList,
  FileBarChart, ScrollText, Settings, BookOpen, UserCircle,
  LogOut, Bell, Menu, X, ChevronLeft, FileSignature, Gift, Inbox, CalendarClock,
  KanbanSquare,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { api, useApi, clearAuthToken, notifyAuthChanged } from "@/lib/client";
import { formatDateJ, todayJalaliStr, toFaDigits } from "@/lib/jalali";
import { ROLE_LABELS } from "@/lib/format";
import { useBranding } from "./use-branding";

import { DashboardView } from "./views/dashboard-view";
import { EmployeesView } from "./views/employees-view";
import { DepartmentsView } from "./views/departments-view";
import { GradesView } from "./views/grades-view";
import { PayrollView } from "./views/payroll-view";
import { ReverseView } from "./views/reverse-view";
import { SalaryView } from "./views/salary-view";
import { ReportsView } from "./views/reports-view";
import { AuditView } from "./views/audit-view";
import { SettingsView } from "./views/settings-view";
import { PortalView } from "./views/portal-view";
import { DocsView } from "./views/docs-view";
import { ContractsView } from "./views/contracts-view";
import { BonusView } from "./views/bonus-view";
import { TasksView } from "./views/tasks-view";
import { ApprovalsView } from "./views/approvals-view";
import { AttendanceView } from "./views/attendance-view";
import { UpdateButton } from "./update-button";
import { WhatsNewDialog } from "./whats-new-dialog";

export interface SessionInfo {
  uid: string;
  username: string;
  fullName: string;
  role: string;
  roleName?: string;
  perms?: string[];
  employeeId?: string | null;
}

interface NavItem {
  key: string;
  label: string;
  icon: typeof LayoutDashboard;
  perm: string; // مجوز لازم برای نمایش
  permAny?: string[]; // اگر هرکدام از این مجوزها باشد نمایش داده می‌شود
}

const NAV_ITEMS: NavItem[] = [
  { key: "dashboard", label: "داشبورد", icon: LayoutDashboard, perm: "dashboard:view" },
  { key: "approvals", label: "درخواست‌ها و تأییدها", icon: Inbox, perm: "requests:approve_dept", permAny: ["requests:approve_dept", "requests:approve_hr", "letters:approve", "letters:manual", "letters:sign"] },
  { key: "tasks", label: "مدیریت کار (آیزنهاور)", icon: KanbanSquare, perm: "tasks:use" },
  { key: "employees", label: "کارکنان", icon: Users, perm: "employees:view" },
  { key: "attendance", label: "حضور و غیب (تردد و کارکرد)", icon: CalendarClock, perm: "attendance:view" },
  { key: "departments", label: "دپارتمان‌ها و مراکز هزینه", icon: Building2, perm: "departments:view" },
  { key: "grades", label: "طبقه‌بندی مشاغل (۷ سطح)", icon: Layers, perm: "grades:view" },
  { key: "contracts", label: "قراردادها", icon: FileSignature, perm: "contracts:view" },
  { key: "bonus", label: "پاداش و سود سالانه", icon: Gift, perm: "bonus:view" },
  { key: "payroll", label: "لیست‌های حقوق", icon: Wallet, perm: "payroll:view" },
  { key: "salary", label: "مدیریت تغییرات حقوق", icon: ClipboardList, perm: "salary:view" },
  { key: "reverse", label: "محاسبه معکوس حقوق", icon: Calculator, perm: "reverse:use" },
  { key: "reports", label: "گزارش‌ها و خروجی‌های قانونی", icon: FileBarChart, perm: "reports:view" },
  { key: "portal", label: "پرتال کارمند", icon: UserCircle, perm: "portal:view" },
  { key: "audit", label: "لاگ حسابرسی", icon: ScrollText, perm: "audit:view" },
  { key: "settings", label: "تنظیمات و پارامترهای قانونی", icon: Settings, perm: "settings:view" },
  { key: "docs", label: "مستندات فنی", icon: BookOpen, perm: "docs:view" },
];

const VIEW_TITLES: Record<string, string> = {
  dashboard: "داشبورد مدیریتی",
  approvals: "درخواست‌ها و تأییدها (مدیر واحد ← منابع انسانی)",
  tasks: "مدیریت کار — ماتریس آیزنهاور و زنجیره واگذاری",
  employees: "مدیریت کارکنان",
  "employee-detail": "پرونده کارمند",
  attendance: "حضور و غیب — تردد و کارکرد",
  departments: "دپارتمان‌ها و مراکز هزینه",
  grades: "طبقه‌بندی مشاغل — ۷ سطح",
  contracts: "صدور و مدیریت قراردادها",
  bonus: "پاداش و سود سالانه (لِول‌بندی)",
  payroll: "لیست‌های حقوق و دستمزد",
  "payroll-detail": "جزئیات دوره حقوق",
  salary: "مدیریت تغییرات حقوق (پیش‌نویس / معکوس / گروهی / آرشیو)",
  reverse: "موتور محاسبه معکوس حقوق",
  reports: "گزارش‌ها و خروجی‌های قانونی",
  portal: "پرتال خودخدماتی کارمند",
  audit: "لاگ حسابرسی",
  settings: "تنظیمات و پارامترهای قانونی",
  docs: "مستندات فنی سامانه",
};

export function AppRoot({ user }: { user: SessionInfo }) {
  const { toast } = useToast();
  const [route, setRoute] = useState<string>("dashboard");
  const [routeParam, setRouteParam] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  // برندینگ پویا (عنوان/لوگو/نام شرکت/متن فوتر) از تنظیمات — با کش آنی
  const { brand } = useBranding();

  // مجوزها — «*» = دسترسی کامل
  const perms = user.perms || [];
  const can = useCallback(
    (perm: string) => perms.includes("*") || perms.includes(perm),
    [perms],
  );

  // مسیریابی هش
  useEffect(() => {
    function applyHash() {
      const h = window.location.hash.replace(/^#\/?/, "");
      // مسیر پیش‌فرض بعد از ورود: داشبورد (اگر مجوز دارد) وگرنه پرتال کارمند
      const fallback = () => setRoute(can("dashboard:view") ? "dashboard" : "portal");
      if (!h) {
        fallback();
        return;
      }
      const [view, param] = h.split("/");
      // گارد مجوز مسیر — بدون دسترسی به نما، به مسیر پیش‌فرض برمی‌گردد
      const PERM_BY_VIEW: Record<string, string[]> = {
        dashboard: ["dashboard:view"],
        approvals: ["requests:approve_dept", "requests:approve_hr", "letters:approve", "letters:manual", "letters:sign"],
        tasks: ["tasks:use"],
        employees: ["employees:view"],
        "employee-detail": ["employees:view"],
        attendance: ["attendance:view"],
        departments: ["departments:view"],
        grades: ["grades:view"],
        contracts: ["contracts:view"],
        bonus: ["bonus:view"],
        payroll: ["payroll:view"],
        "payroll-detail": ["payroll:view"],
        salary: ["salary:view"],
        reverse: ["reverse:use"],
        reports: ["reports:view"],
        audit: ["audit:view"],
        settings: ["settings:view"],
        docs: ["docs:view"],
      };
      const needed = PERM_BY_VIEW[view];
      if (needed && !needed.some((p) => can(p))) {
        fallback();
        return;
      }
      setRoute(view);
      setRouteParam(param || null);
    }
    applyHash();
    window.addEventListener("hashchange", applyHash);
    return () => window.removeEventListener("hashchange", applyHash);
  }, [can]);

  const navigate = useCallback((view: string, param?: string) => {
    window.location.hash = `/${view}${param ? `/${param}` : ""}`;
    setSidebarOpen(false);
  }, []);

  const alertsApi = useApi<{ alerts: { id: string; title: string; message: string; severity: string }[]; counts: { high: number; medium: number; low: number } }>(
    can("dashboard:view") ? "/api/alerts" : null
  );
  const alertCount = alertsApi.data?.counts ? alertsApi.data.counts.high + alertsApi.data.counts.medium : 0;

  // شمارش درخواست‌های در انتظار تأیید (برای نشان منوی تأییدها)
  const approvalsApi = useApi<{ counts: { pendingDm: number; pendingHr: number } }>(
    can("requests:approve_dept") || can("requests:approve_hr") ? "/api/requests" : null
  );
  const pendingApprovals = (approvalsApi.data?.counts?.pendingDm || 0) + (approvalsApi.data?.counts?.pendingHr || 0);

  // شمارش نامه‌های در انتظار — نشان منوی «درخواست‌ها و تأییدها» (letters:approve/manual/sign)
  const lettersCountsApi = useApi<{ pending: number; issued: number; pendingSign: number }>(
    can("letters:approve") || can("letters:manual") || can("letters:sign") ? "/api/letters/counts" : null
  );
  // برای امضاکننده (بدون مجوز تأیید): فقط نامه‌های کارتابل خودش شمارش می‌شود
  const pendingLetters = can("letters:approve") || can("letters:manual")
    ? (lettersCountsApi.data?.pending || 0)
    : (lettersCountsApi.data?.pendingSign || 0);

  // شمارش پیش‌نویس‌های تغییر حقوق در انتظار تأیید — نشان منوی «مدیریت تغییرات حقوق»
  const salaryDraftsApi = useApi<{ counts: { pending: number } }>(
    can("salary:view") ? "/api/salary/drafts" : null
  );
  const pendingSalaryDrafts = salaryDraftsApi.data?.counts?.pending || 0;

  async function logout() {
    try {
      await api("/api/auth/logout", { method: "POST" });
    } catch { /* noop */ }
    clearAuthToken();
    notifyAuthChanged("logout"); // AuthGate به صفحه ورود برمی‌گردد
  }

  // اطلاع‌رسانی نسخه جدید — یک بار در هر نشست (چک خودکار سرور هر ۲ روز)
  const [updateNotified, setUpdateNotified] = useState(false);
  useEffect(() => {
    if (updateNotified) return;
    void (async () => {
      try {
        const d = await api<{ updateAvailable: boolean; latest: string | null; current: string }>("/api/system/version");
        if (d.updateAvailable && d.latest) {
          setUpdateNotified(true);
          toast({
            title: `نسخه جدید ${toFaDigits(d.latest)} منتشر شده است`,
            description: can("settings:manage")
              ? "برای ارتقای سامانه، دکمه به‌روزرسانی در نوار بالا را بزنید."
              : "برای ارتقای سامانه با مدیر سامانه هماهنگ کنید.",
            duration: 10000,
          });
        }
      } catch { /* آفلاین/خطا — بی‌صدا */ }
    })();
  }, [updateNotified, toast, can]);

  const navItems = useMemo(
    () => NAV_ITEMS.filter((n) => can(n.perm) || (n.permAny || []).some((p) => can(p))),
    [can]
  );

  const title = VIEW_TITLES[route] || "سامانه منابع انسانی";

  const activeAlerts = alertsApi.data?.alerts || [];

  function renderView() {
    switch (route) {
      case "dashboard":
        return <DashboardView user={user} onNavigate={navigate} />;
      case "approvals":
        return (
          <ApprovalsView
            canApproveDept={can("requests:approve_dept")}
            canApproveHr={can("requests:approve_hr")}
            canSeeLetters={can("letters:approve") || can("letters:manual") || can("letters:sign")}
            canDecideLetters={can("letters:approve")}
            canManualLetters={can("letters:manual")}
            canSignLetters={can("letters:sign")}
            initialTab={routeParam === "letters" ? "letters" : undefined}
            user={user}
          />
        );
      case "tasks":
        return <TasksView user={user} />;
      case "employees":
        return <EmployeesView onNavigate={navigate} canEdit={can("employees:edit")} />;
      case "employee-detail":
        return <EmployeesView onNavigate={navigate} detailId={routeParam} canEdit={can("employees:edit")} />;
      case "attendance":
        return <AttendanceView user={user} canManage={can("attendance:manage")} />;
      case "departments":
        return <DepartmentsView />;
      case "grades":
        return <GradesView />;
      case "payroll":
        return <PayrollView onNavigate={navigate} />;
      case "payroll-detail":
        return <PayrollView onNavigate={navigate} detailId={routeParam} />;
      case "reverse":
        return <ReverseView />;
      case "salary":
        return <SalaryView canManage={can("salary:manage")} />;
      case "reports":
        return <ReportsView />;
      case "portal":
        return <PortalView user={user} onNavigate={navigate} />;
      case "audit":
        return <AuditView />;
      case "settings":
        return <SettingsView user={user} />;
      case "contracts":
        return <ContractsView canEdit={can("contracts:manage")} />;
      case "bonus":
        return <BonusView canManage={can("bonus:manage")} />;
      case "docs":
        return <DocsView />;
      default:
        return can("dashboard:view") ? <DashboardView user={user} onNavigate={navigate} /> : <PortalView user={user} onNavigate={navigate} />;
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* ================= سایدبار (راست) ================= */}
      <aside
        className={`fixed inset-y-0 right-0 z-50 w-72 lg:w-64 bg-[var(--sidebar)] text-[var(--sidebar-foreground)] flex flex-col transition-transform duration-300 lg:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* لوگو */}
        <div className="flex items-center gap-3 px-5 h-16 shrink-0 border-b border-white/10">
          {brand?.logo ? (
             
            <img src={brand.logo} alt="لوگو" className="w-10 h-10 rounded-xl object-contain bg-white/10 p-1 shrink-0" />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-lg shadow-teal-500/20 shrink-0">
              <svg viewBox="0 0 24 24" className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M12 2L20 6v5c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V6l8-4z" strokeLinejoin="round" />
                <path d="M12 8v4l3 2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          )}
          <div className="min-w-0">
            <p className="font-bold text-sm leading-tight text-white truncate">{brand?.title || "منابع انسانی ۱۴۰۵"}</p>
            {brand?.companyName && <p className="text-[11px] text-teal-200/60 truncate">{brand.companyName}</p>}
          </div>
          <button className="lg:hidden mr-auto text-white/60 hover:text-white" onClick={() => setSidebarOpen(false)} aria-label="بستن منو">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* منو */}
        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1" aria-label="منوی اصلی">
          {navItems.map((item) => {
            const isActive = route === item.key || (item.key === "employees" && route === "employee-detail") || (item.key === "payroll" && route === "payroll-detail");
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                onClick={() => navigate(item.key)}
                className={`w-full flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm transition-all ${
                  isActive
                    ? "bg-teal-500/20 text-white font-medium shadow-inner border border-teal-400/30"
                    : "text-slate-300/80 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Icon className={`w-[18px] h-[18px] shrink-0 ${isActive ? "text-teal-300" : "text-slate-400"}`} />
                <span className="truncate text-right">{item.label}</span>
                {item.key === "reverse" && (
                  <Badge className="mr-auto bg-amber-400/90 text-amber-950 text-[10px] px-1.5 py-0 font-bold hover:bg-amber-400/90">ویژه</Badge>
                )}
                {item.key === "approvals" && (pendingApprovals + pendingLetters) > 0 && (
                  <Badge className="mr-auto bg-rose-500 text-white text-[10px] px-1.5 py-0 font-bold hover:bg-rose-500" title={`${pendingApprovals} درخواست + ${pendingLetters} نامه در انتظار`}>
                    {toFaDigits(pendingApprovals + pendingLetters)}
                  </Badge>
                )}
                {item.key === "salary" && pendingSalaryDrafts > 0 && (
                  <Badge className="mr-auto bg-amber-500 text-white text-[10px] px-1.5 py-0 font-bold hover:bg-amber-500" title={`${toFaDigits(pendingSalaryDrafts)} پیش‌نویس تغییر حقوق در انتظار تأیید`}>
                    {toFaDigits(pendingSalaryDrafts)}
                  </Badge>
                )}
              </button>
            );
          })}
        </nav>

        {/* کاربر */}
        <div className="shrink-0 border-t border-white/10 p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-teal-500/25 border border-teal-400/40 flex items-center justify-center text-teal-200 font-bold text-sm shrink-0">
              {user.fullName.trim().charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-white truncate">{user.fullName}</p>
              <p className="text-[11px] text-teal-200/60 truncate">{user.roleName || ROLE_LABELS[user.role] || user.role}</p>
            </div>
            <button
              onClick={logout}
              className="text-slate-400 hover:text-rose-400 transition-colors p-2 rounded-lg hover:bg-white/5"
              title="خروج از سامانه"
              aria-label="خروج از سامانه"
            >
              <LogOut className="w-4 h-4 rtl-flip" />
            </button>
          </div>
        </div>
      </aside>

      {/* پس‌زمینه موبایل */}
      {sidebarOpen && <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} aria-hidden="true" />}

      {/* ================= محتوا ================= */}
      <div className="lg:mr-64 flex flex-col min-h-screen">
        {/* نوار بالا */}
        <header className="sticky top-0 z-30 bg-white/85 backdrop-blur border-b border-border h-16 flex items-center gap-3 px-4 lg:px-6">
          <button className="lg:hidden text-slate-500 hover:text-slate-800" onClick={() => setSidebarOpen(true)} aria-label="باز کردن منو">
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2 text-sm text-muted-foreground min-w-0">
            <span className="hidden sm:inline">سامانه منابع انسانی</span>
            <ChevronLeft className="w-4 h-4 hidden sm:inline" />
            <span className="font-semibold text-foreground truncate">{title}</span>
          </div>
          <div className="mr-auto flex items-center gap-2 sm:gap-4">
            <span className="hidden md:block text-xs text-muted-foreground tabular-nums">{formatDateJ(todayJalaliStr(), true)}</span>
            {/* وضعیت نسخه / به‌روزرسانی — فقط مدیر کل سیستم (SUPER_ADMIN) */}
            {(user.role === "SUPER_ADMIN" || perms.includes("*")) && <UpdateButton canManage />}
            {/* اعلان‌ها */}
            <div className="relative">
              <button
                className="relative p-2 rounded-lg text-slate-500 hover:text-teal-700 hover:bg-teal-50 transition-colors"
                onClick={() => setNotifOpen((v) => !v)}
                aria-label={`اعلان‌ها (${toFaDigits(alertCount)} مورد)`}
              >
                <Bell className="w-5 h-5" />
                {alertCount > 0 && (
                  <span className="absolute -top-0.5 -left-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                    {toFaDigits(alertCount)}
                  </span>
                )}
              </button>
              {notifOpen && (
                <div className="absolute left-0 mt-2 w-80 sm:w-96 rounded-xl border bg-white shadow-xl z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b bg-slate-50 flex items-center justify-between">
                    <p className="text-sm font-bold">هشدارهای سامانه</p>
                    <div className="flex gap-1.5 text-[10px]">
                      <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100">فوری: {toFaDigits(alertsApi.data?.counts.high || 0)}</Badge>
                      <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">متوسط: {toFaDigits(alertsApi.data?.counts.medium || 0)}</Badge>
                    </div>
                  </div>
                  <div className="max-h-96 overflow-y-auto divide-y">
                    {activeAlerts.length === 0 && <p className="p-4 text-sm text-muted-foreground text-center">هشداری وجود ندارد ✓</p>}
                    {activeAlerts.map((a) => (
                      <div key={a.id} className="px-4 py-3 flex gap-3 hover:bg-slate-50">
                        <span className={`mt-1 w-2 h-2 rounded-full shrink-0 ${a.severity === "high" ? "bg-rose-500" : a.severity === "medium" ? "bg-amber-500" : "bg-slate-300"}`} />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-800">{a.title}</p>
                          <p className="text-xs text-muted-foreground mt-0.5 leading-5">{a.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  {(can("employees:edit")) && activeAlerts.length > 0 && (
                    <button
                      className="w-full px-4 py-2.5 text-xs font-medium text-teal-700 hover:bg-teal-50 border-t"
                      onClick={() => {
                        setNotifOpen(false);
                        navigate("employees");
                      }}
                    >
                      مشاهده کارکنان مرتبط ←
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </header>

        {/* بدنه */}
        <main className="flex-1 p-4 lg:p-6 view-enter" key={route + (routeParam || "")}>
          {renderView()}
        </main>

        {/* پابرگ — متن قابل تنظیم از تنظیمات → برندینگ + نسخه نصب‌شده */}
        <footer className="mt-auto border-t bg-white/60 py-3 px-6 text-center text-[11px] text-muted-foreground">
          {brand?.footerText || "سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵ • مطابق ماده ۸۵ قانون بودجه ۱۴۰۵ و مقررات تأمین اجتماعی"}
          {brand?.version && <span className="mx-1.5">•</span>}
          {brand?.version && (
            <span className="tabular-nums" title={`نسخه ${brand.version}`}>نسخه {toFaDigits(brand.version)}</span>
          )}
        </footer>
      </div>

      {/* پاپ‌آپ «تازه‌های نسخه» — نمایش هدف‌مند برای کاربران منتخب مدیریت */}
      <WhatsNewDialog />
    </div>
  );
}

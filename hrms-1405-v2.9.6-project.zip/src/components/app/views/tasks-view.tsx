"use client";

// ============================================================
// مدیریت کار — ماتریس آیزنهاور + نمای زنجیره واگذاری
//  تب ۱ «ماتریس آیزنهاور»: وظایف در ۴ ربع (فوری/مهم) — همه کاربران
//    • جابه‌جایی کارت بین ربع‌ها با کشیدن‌ورهاکردن (dnd-kit) یا دکمه‌ها
//    • ایجاد / ویرایش / واگذاری / وضعیت / حذف
//  تب ۲ «نمای زنجیره واگذاری»: گراف نودی مدیران (task-graph.tsx)
// ============================================================
import { useMemo, useState, useCallback } from "react";
import { DndContext, useDraggable, useDroppable, useSensor, useSensors, PointerSensor, type DragEndEvent } from "@dnd-kit/core";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { LayoutGrid, Network, Plus, CheckCircle2, PlayCircle, RotateCcw, Pencil, Trash2, SendHorizontal, GripVertical, Clock, AlertTriangle, CheckCircle } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits, formatDateJ } from "@/lib/jalali";
import { QUADRANTS, TASK_STATUS_LABELS, type SerializedTask, type TaskStatus } from "@/lib/tasks";
import { TaskGraph, type GraphData } from "../task-graph";

export interface SessionInfo {
  uid: string;
  username: string;
  fullName: string;
  role: string;
  roleName?: string;
  perms?: string[];
  employeeId?: string | null;
}

interface TasksPayload {
  tasks: SerializedTask[];
  counts: Record<"Q1" | "Q2" | "Q3" | "Q4", number>;
  doneCount: number;
  overdueCount: number;
  scope: string;
  canSeeAll: boolean;
}

interface UsersPayload {
  users: { id: string; username: string; fullName: string; roleName: string; isMe: boolean }[];
}

type TaskScope = "mine" | "created" | "all";

// ---------- کارت وظیفه (کشیدنی) ----------
function TaskCard({ task, onEdit, onForward, onStatus, onDelete, canForward }: {
  task: SerializedTask;
  onEdit: () => void;
  onForward: () => void;
  onStatus: (s: TaskStatus) => void;
  onDelete: () => void;
  canForward: boolean;
}) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({ id: task.id });
  const done = task.status === "DONE";
  const cancelled = task.status === "CANCELLED";
  return (
    <div
      ref={setNodeRef}
      className={`group relative rounded-lg border bg-card p-3 shadow-sm transition-shadow hover:shadow-md ${isDragging ? "opacity-40" : ""} ${task.isOverdue && !done && !cancelled ? "border-red-300" : ""}`}
    >
      <div className="flex items-start gap-2">
        {/* دستگیره مخصوص درگ — شنونده‌ها فقط اینجاست تا کلیک دکمه‌های کارت قفل نشود */}
        <button
          type="button"
          {...attributes}
          {...listeners}
          aria-label="جابه‌جایی کارت بین ربع‌ها"
          title="برای جابه‌جایی، این دستگیره را بکشید"
          className="mt-0.5 shrink-0 cursor-grab touch-none rounded text-muted-foreground/50 transition-colors hover:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring active:cursor-grabbing"
        >
          <GripVertical className="h-4 w-4" />
        </button>
        <div className="min-w-0 flex-1">
          <div className={`text-sm font-medium leading-6 ${done || cancelled ? "text-muted-foreground line-through" : ""}`}>
            {task.title}
          </div>
          {task.description && <p className="mt-1 line-clamp-2 text-xs leading-5 text-muted-foreground">{task.description}</p>}
          <div className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-muted-foreground">
            {task.dueDateJ && (
              <span className={`inline-flex items-center gap-1 ${task.isOverdue && !done && !cancelled ? "font-medium text-red-600" : ""}`}>
                {task.isOverdue && !done && !cancelled ? <AlertTriangle className="h-3 w-3" /> : <Clock className="h-3 w-3" />}
                {formatDateJ(task.dueDateJ)}
              </span>
            )}
            {task.assignedToUsername && task.assignedToId !== task.createdById && (
              <span className="inline-flex items-center gap-1">
                <SendHorizontal className="h-3 w-3" />
                نزد {task.assignedToName || task.assignedToUsername}
              </span>
            )}
            {task.transferCount > 0 && <span>{toFaDigits(task.transferCount)} واگذاری</span>}
          </div>
          <div className="mt-2 flex flex-wrap items-center gap-1">
            <span className={`rounded-full border px-2 py-0.5 text-[10px] ${done ? "border-green-200 bg-green-50 text-green-700" : cancelled ? "border-gray-200 bg-gray-50 text-gray-500" : task.status === "IN_PROGRESS" ? "border-blue-200 bg-blue-50 text-blue-700" : "border-amber-200 bg-amber-50 text-amber-700"}`}>
              {TASK_STATUS_LABELS[task.status]}
            </span>
            {task.isOverdue && !done && !cancelled && (
              <span className="rounded-full border border-red-200 bg-red-50 px-2 py-0.5 text-[10px] text-red-700">عقب‌افتاده</span>
            )}
          </div>
        </div>
      </div>
      {/* عملیات — روی هاور ظاهر می‌شود (لمس: همیشه) */}
      <div className="mt-2 flex flex-wrap gap-1 opacity-100 md:opacity-0 md:transition-opacity md:group-hover:opacity-100">
        {!done && !cancelled && (
          <Button variant="ghost" size="icon" className="h-7 w-7" title={task.status === "IN_PROGRESS" ? "علامت باز" : "شروع انجام"} onClick={() => onStatus(task.status === "IN_PROGRESS" ? "OPEN" : "IN_PROGRESS")}>
            {task.status === "IN_PROGRESS" ? <RotateCcw className="h-3.5 w-3.5" /> : <PlayCircle className="h-3.5 w-3.5" />}
          </Button>
        )}
        {!done && (
          <Button variant="ghost" size="icon" className="h-7 w-7 text-green-600" title="انجام شد" onClick={() => onStatus("DONE")}>
            <CheckCircle2 className="h-3.5 w-3.5" />
          </Button>
        )}
        {done && (
          <Button variant="ghost" size="icon" className="h-7 w-7" title="بازگشایی" onClick={() => onStatus("OPEN")}>
            <RotateCcw className="h-3.5 w-3.5" />
          </Button>
        )}
        {canForward && (
          <Button variant="ghost" size="icon" className="h-7 w-7 text-indigo-600" title="واگذاری به…" onClick={onForward}>
            <SendHorizontal className="h-3.5 w-3.5" />
          </Button>
        )}
        <Button variant="ghost" size="icon" className="h-7 w-7" title="ویرایش" onClick={onEdit}>
          <Pencil className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7 text-red-600" title="حذف" onClick={onDelete}>
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );
}

// ---------- یک ربع ماتریس (حامل رهاکردن) ----------
function Quadrant({ q, tasks, children }: { q: typeof QUADRANTS[number]; tasks: SerializedTask[]; children: React.ReactNode }) {
  const { setNodeRef, isOver } = useDroppable({ id: q.key });
  return (
    <div
      ref={setNodeRef}
      className={`flex min-h-[220px] flex-col rounded-xl border-2 bg-muted/30 ${q.boxClass} ${isOver ? "ring-2 ring-primary/40 bg-primary/5" : ""}`}
    >
      <div className={`flex items-center justify-between gap-2 rounded-t-[10px] px-3 py-2 text-white ${q.headClass}`}>
        <div className="flex flex-col">
          <span className="text-xs font-bold">{q.title}</span>
          <span className="text-[10px] opacity-90">{q.action}</span>
        </div>
        <span className="rounded-full bg-white/25 px-2 py-0.5 text-[11px] font-bold">{toFaDigits(tasks.length)}</span>
      </div>
      <div className="flex-1 space-y-2 p-2.5">
        {children}
        {tasks.length === 0 && <p className="py-6 text-center text-[11px] text-muted-foreground/70">{q.hint}</p>}
      </div>
    </div>
  );
}

// ---------- نمای اصلی ----------
export function TasksView({ user }: { user: SessionInfo }) {
  const { toast } = useToast();
  const [scope, setScope] = useState<TaskScope>("mine");
  const [showDone, setShowDone] = useState(true);
  const [tab, setTab] = useState<string>("matrix");

  const tasksApi = useApi<TasksPayload>(`/api/tasks?scope=${scope}`, [scope]);
  const graphApi = useApi<GraphData>(tab === "graph" ? `/api/tasks/graph?scope=${scope === "all" ? "all" : "created"}` : null, [tab, scope]);
  const usersApi = useApi<UsersPayload>("/api/tasks/users");

  // دیالوگ ایجاد/ویرایش
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<SerializedTask | null>(null);
  const [fTitle, setFTitle] = useState("");
  const [fDesc, setFDesc] = useState("");
  const [fUrgent, setFUrgent] = useState(false);
  const [fImportant, setFImportant] = useState(false);
  const [fDue, setFDue] = useState("");
  const [fAssignee, setFAssignee] = useState("me");
  const [fNote, setFNote] = useState("");
  const [saving, setSaving] = useState(false);

  // دیالوگ واگذاری
  const [forwardTask, setForwardTask] = useState<SerializedTask | null>(null);
  const [fwdUser, setFwdUser] = useState("");
  const [fwdNote, setFwdNote] = useState("");

  // حذف
  const [deleteTask, setDeleteTask] = useState<SerializedTask | null>(null);

  const tasks = useMemo(() => {
    const all = tasksApi.data?.tasks || [];
    return showDone ? all : all.filter((t) => t.status !== "DONE" && t.status !== "CANCELLED");
  }, [tasksApi.data, showDone]);

  const byQuadrant = useMemo(() => {
    const map: Record<string, SerializedTask[]> = { Q1: [], Q2: [], Q3: [], Q4: [] };
    for (const t of tasks) {
      if (t.status === "DONE" || t.status === "CANCELLED") continue; // کارهای بسته ربع نمی‌خواهند
      map[t.quadrant]?.push(t);
    }
    return map;
  }, [tasks]);

  const closed = useMemo(() => tasks.filter((t) => t.status === "DONE" || t.status === "CANCELLED"), [tasks]);

  const reload = useCallback(() => {
    void tasksApi.refetch();
    if (tab === "graph") void graphApi.refetch();
  }, [tasksApi, graphApi, tab]);

  function openCreate() {
    setEditing(null);
    setFTitle("");
    setFDesc("");
    setFUrgent(false);
    setFImportant(true);
    setFDue("");
    setFAssignee("me");
    setFNote("");
    setFormOpen(true);
  }

  function openEdit(t: SerializedTask) {
    setEditing(t);
    setFTitle(t.title);
    setFDesc(t.description);
    setFUrgent(t.isUrgent);
    setFImportant(t.isImportant);
    setFDue(t.dueDateJ);
    setFAssignee("me");
    setFNote("");
    setFormOpen(true);
  }

  async function saveForm() {
    if (!fTitle.trim()) {
      toast({ title: "خطا", description: "عنوان وظیفه الزامی است.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        await api(`/api/tasks/${editing.id}`, {
          method: "PATCH",
          json: { title: fTitle.trim(), description: fDesc.trim(), isUrgent: fUrgent, isImportant: fImportant, dueDateJ: fDue },
        });
        toast({ title: "وظیفه به‌روزرسانی شد" });
      } else {
        await api("/api/tasks", {
          method: "POST",
          json: {
            title: fTitle.trim(),
            description: fDesc.trim(),
            isUrgent: fUrgent,
            isImportant: fImportant,
            dueDateJ: fDue,
            assignedToId: fAssignee === "me" ? undefined : fAssignee,
            note: fNote.trim() || undefined,
          },
        });
        toast({ title: "وظیفه جدید ثبت شد", description: fAssignee !== "me" ? "و به کاربر انتخاب‌شده واگذار شد." : undefined });
      }
      setFormOpen(false);
      reload();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "ثبت ناموفق بود", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function moveQuadrant(taskId: string, qKey: string) {
    const q = QUADRANTS.find((x) => x.key === qKey);
    if (!q) return;
    try {
      await api(`/api/tasks/${taskId}`, { method: "PATCH", json: { isUrgent: q.isUrgent, isImportant: q.isImportant } });
      reload();
    } catch (e) {
      toast({ title: "خطا در جابه‌جایی", description: e instanceof Error ? e.message : undefined, variant: "destructive" });
    }
  }

  async function setStatus(taskId: string, status: TaskStatus) {
    try {
      await api(`/api/tasks/${taskId}`, { method: "PATCH", json: { status } });
      reload();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : undefined, variant: "destructive" });
    }
  }

  async function doForward() {
    if (!forwardTask || !fwdUser) return;
    try {
      await api(`/api/tasks/${forwardTask.id}`, {
        method: "PATCH",
        json: { action: "forward", toUserId: fwdUser, note: fwdNote.trim() },
      });
      toast({ title: "واگذاری ثبت شد", description: `«${forwardTask.title}» به کاربر انتخاب‌شده سپرده شد.` });
      setForwardTask(null);
      setFwdUser("");
      setFwdNote("");
      reload();
    } catch (e) {
      toast({ title: "خطا در واگذاری", description: e instanceof Error ? e.message : undefined, variant: "destructive" });
    }
  }

  async function doDelete() {
    if (!deleteTask) return;
    try {
      await api(`/api/tasks/${deleteTask.id}`, { method: "DELETE" });
      toast({ title: "وظیفه حذف شد" });
      setDeleteTask(null);
      reload();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : undefined, variant: "destructive" });
    }
  }

  function onDragEnd(e: DragEndEvent) {
    const { active, over } = e;
    if (!over) return;
    const taskId = String(active.id);
    const qKey = String(over.id);
    const task = tasks.find((t) => t.id === taskId);
    if (!task) return;
    const q = QUADRANTS.find((x) => x.key === qKey);
    if (!q || (q.isUrgent === task.isUrgent && q.isImportant === task.isImportant)) return;
    void moveQuadrant(taskId, qKey);
  }

  // قید فاصله: کلیک ساده (بدون حرکت) هرگز درگ نمی‌شود — دکمه‌ها همیشه کلیک‌پذیر می‌مانند
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 6 } })
  );

  const canSeeAll = tasksApi.data?.canSeeAll || false;
  const users = usersApi.data?.users || [];

  return (
    <div className="space-y-4">
      <Tabs value={tab} onValueChange={setTab} dir="rtl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <TabsList>
            <TabsTrigger value="matrix" className="gap-1.5"><LayoutGrid className="h-4 w-4" /> ماتریس آیزنهاور</TabsTrigger>
            <TabsTrigger value="graph" className="gap-1.5"><Network className="h-4 w-4" /> نمای زنجیره واگذاری</TabsTrigger>
          </TabsList>
          <div className="flex flex-wrap items-center gap-2">
            {tab === "matrix" && (
              <Select value={scope} onValueChange={(v) => setScope(v as TaskScope)}>
                <SelectTrigger className="h-9 w-[190px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mine">کارهای رسیده به من</SelectItem>
                  <SelectItem value="created">کارهایی که ساخته/واگذار کردم</SelectItem>
                  {canSeeAll && <SelectItem value="all">همه کارهای سامانه</SelectItem>}
                </SelectContent>
              </Select>
            )}
            <Button onClick={openCreate} className="gap-1.5">
              <Plus className="h-4 w-4" /> وظیفه جدید
            </Button>
          </div>
        </div>

        {/* ------------------- تب ماتریس ------------------- */}
        <TabsContent value="matrix" className="mt-4 space-y-4">
          {/* نوار آمار */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {tasksApi.data && (
              <>
                <Badge variant="outline" className="border-red-200 bg-red-50 text-red-700">بحران: {toFaDigits(tasksApi.data.counts.Q1)}</Badge>
                <Badge variant="outline" className="border-blue-200 bg-blue-50 text-blue-700">زمان‌بندی: {toFaDigits(tasksApi.data.counts.Q2)}</Badge>
                <Badge variant="outline" className="border-amber-200 bg-amber-50 text-amber-700">واگذاری: {toFaDigits(tasksApi.data.counts.Q3)}</Badge>
                <Badge variant="outline" className="border-gray-200 bg-gray-50 text-gray-600">حذف: {toFaDigits(tasksApi.data.counts.Q4)}</Badge>
                {tasksApi.data.overdueCount > 0 && (
                  <Badge variant="outline" className="border-red-300 bg-red-100 text-red-800">عقب‌افتاده: {toFaDigits(tasksApi.data.overdueCount)}</Badge>
                )}
                <Badge variant="outline" className="border-green-200 bg-green-50 text-green-700">انجام‌شده: {toFaDigits(tasksApi.data.doneCount)}</Badge>
                <label className="ms-auto flex cursor-pointer items-center gap-1.5 text-muted-foreground">
                  <Switch checked={showDone} onCheckedChange={setShowDone} className="scale-90" />
                  نمایش انجام‌شده‌ها
                </label>
              </>
            )}
          </div>

          {tasksApi.loading && !tasksApi.data ? (
            <div className="grid gap-3 md:grid-cols-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-56" />)}</div>
          ) : tasksApi.error ? (
            <Card><CardContent className="py-10 text-center text-sm text-red-600">{tasksApi.error}</CardContent></Card>
          ) : (
            <DndContext sensors={sensors} onDragEnd={onDragEnd}>
              <div className="grid gap-3 md:grid-cols-2">
                {QUADRANTS.map((q) => (
                  <Quadrant key={q.key} q={q} tasks={byQuadrant[q.key] || []}>
                    {(byQuadrant[q.key] || []).map((t) => (
                      <TaskCard
                        key={t.id}
                        task={t}
                        onEdit={() => openEdit(t)}
                        onForward={() => { setForwardTask(t); setFwdUser(""); setFwdNote(""); }}
                        onStatus={(s) => void setStatus(t.id, s)}
                        onDelete={() => setDeleteTask(t)}
                        canForward
                      />
                    ))}
                  </Quadrant>
                ))}
              </div>
            </DndContext>
          )}

          {/* کارهای بسته‌شده */}
          {showDone && closed.length > 0 && (
            <Card>
              <CardContent className="pt-4">
                <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                  <CheckCircle className="h-4 w-4 text-green-600" /> انجام‌شده و لغو‌شده ({toFaDigits(closed.length)})
                </div>
                <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">
                  {closed.map((t) => (
                    <div key={t.id} className="rounded-lg border bg-muted/20 p-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-xs font-medium text-muted-foreground line-through">{t.title}</span>
                        <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" title="بازگشایی" onClick={() => void setStatus(t.id, "OPEN")}>
                          <RotateCcw className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ------------------- تب گراف ------------------- */}
        <TabsContent value="graph" className="mt-4">
          {graphApi.loading && !graphApi.data ? (
            <Skeleton className="h-96" />
          ) : graphApi.error ? (
            <Card><CardContent className="py-10 text-center text-sm text-red-600">{graphApi.error}</CardContent></Card>
          ) : graphApi.data ? (
            <TaskGraph data={graphApi.data} />
          ) : null}
        </TabsContent>
      </Tabs>

      {/* ------------------- دیالوگ ایجاد/ویرایش ------------------- */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-lg" dir="rtl">
          <DialogHeader>
            <DialogTitle>{editing ? "ویرایش وظیفه" : "وظیفه جدید"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="t-title">عنوان *</Label>
              <Input id="t-title" value={fTitle} onChange={(e) => setFTitle(e.target.value)} placeholder="مثلاً: تهیه گزارش حقوق مرداد" maxLength={200} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="t-desc">توضیح</Label>
              <Textarea id="t-desc" value={fDesc} onChange={(e) => setFDesc(e.target.value)} rows={2} placeholder="اختیاری — جزئیات، خروجی مورد انتظار و…" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <Label htmlFor="t-urgent" className="text-xs">فوری</Label>
                  <p className="text-[10px] text-muted-foreground">موعد نزدیک / همین الان</p>
                </div>
                <Switch id="t-urgent" checked={fUrgent} onCheckedChange={setFUrgent} />
              </div>
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <Label htmlFor="t-imp" className="text-xs">مهم</Label>
                  <p className="text-[10px] text-muted-foreground">اثر واقعی بر نتیجه</p>
                </div>
                <Switch id="t-imp" checked={fImportant} onCheckedChange={setFImportant} />
              </div>
            </div>
            {/* پیش‌نمایش ربع */}
            <div className="rounded-lg bg-muted/40 px-3 py-2 text-xs">
              ربع انتخابی: <b>{QUADRANTS.find((q) => q.isUrgent === fUrgent && q.isImportant === fImportant)?.title}</b> — «{QUADRANTS.find((q) => q.isUrgent === fUrgent && q.isImportant === fImportant)?.action}»
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="t-due">موعد (شمسی)</Label>
              <Input id="t-due" dir="ltr" value={fDue} onChange={(e) => setFDue(e.target.value)} placeholder="1405/07/15 — خالی = بدون موعد" />
            </div>
            {!editing && (
              <>
                <div className="space-y-1.5">
                  <Label>مسئول</Label>
                  <Select value={fAssignee} onValueChange={setFAssignee}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="me">خودم ({user.fullName})</SelectItem>
                      {users.filter((u) => !u.isMe).map((u) => (
                        <SelectItem key={u.id} value={u.id}>
                          {u.fullName}{u.roleName ? ` — ${u.roleName}` : ""}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {fAssignee !== "me" && (
                  <div className="space-y-1.5">
                    <Label htmlFor="t-note">یادداشت واگذاری</Label>
                    <Input id="t-note" value={fNote} onChange={(e) => setFNote(e.target.value)} placeholder="اختیاری — توضیح برای گیرنده" />
                  </div>
                )}
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setFormOpen(false)}>انصراف</Button>
            <Button onClick={() => void saveForm()} disabled={saving}>{saving ? "در حال ثبت…" : editing ? "ذخیره" : "ثبت وظیفه"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ------------------- دیالوگ واگذاری ------------------- */}
      <Dialog open={!!forwardTask} onOpenChange={(o) => !o && setForwardTask(null)}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <SendHorizontal className="h-4 w-4 text-indigo-600" />
              واگذاری «{forwardTask?.title}»
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>واگذار به</Label>
              <Select value={fwdUser} onValueChange={setFwdUser}>
                <SelectTrigger><SelectValue placeholder="کاربر را انتخاب کنید" /></SelectTrigger>
                <SelectContent>
                  {users.filter((u) => u.id !== forwardTask?.assignedToId).map((u) => (
                    <SelectItem key={u.id} value={u.id}>
                      {u.fullName}{u.roleName ? ` — ${u.roleName}` : ""}{u.isMe ? " (من)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="fwd-note">یادداشت</Label>
              <Textarea id="fwd-note" rows={2} value={fwdNote} onChange={(e) => setFwdNote(e.target.value)} placeholder="اختیاری — چه انتظاری می‌رود" />
            </div>
            <p className="rounded-lg bg-muted/40 px-3 py-2 text-[11px] leading-5 text-muted-foreground">
              با واگذاری، این کار در ماتریس «کارهای رسیده به من» گیرنده می‌نشیند و در
              «نمای زنجیره واگذاری» شما، زنجیره تا او دنبال می‌شود.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setForwardTask(null)}>انصراف</Button>
            <Button onClick={() => void doForward()} disabled={!fwdUser}>
              <SendHorizontal className="h-4 w-4" /> واگذاری
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ------------------- تأیید حذف ------------------- */}
      <AlertDialog open={!!deleteTask} onOpenChange={(o) => !o && setDeleteTask(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف وظیفه</AlertDialogTitle>
            <AlertDialogDescription>
              «{deleteTask?.title}» و سابقه واگذاری آن برای همیشه حذف می‌شود. مطمئنید؟
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={() => void doDelete()}>حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

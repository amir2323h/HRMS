"use client"

import * as React from "react"
import * as SwitchPrimitive from "@radix-ui/react-switch"

import { cn } from "@/lib/utils"

function Switch({
  className,
  ...props
}: React.ComponentProps<typeof SwitchPrimitive.Root>) {
  return (
    <SwitchPrimitive.Root
      data-slot="switch"
      className={cn(
        "peer data-[state=checked]:bg-primary data-[state=unchecked]:bg-input focus-visible:border-ring focus-visible:ring-ring/50 dark:data-[state=unchecked]:bg-input/80 inline-flex h-[1.15rem] w-8 shrink-0 items-center rounded-full border border-transparent shadow-xs transition-all outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50",
        className
      )}
      {...props}
    >
      <SwitchPrimitive.Thumb
        data-slot="switch-thumb"
        // RTL-SAFE: جای translate‌ی فیزیکی (که با variantهای rtl:/ltr: در جزیره‌های dir
        // تودرتو هر دو قانون همزمان مچ می‌شوند و قانون غلط برنده می‌شود ← دسته بیرون
        // می‌پرد)، از margin-inline-start منطقی استفاده می‌کنیم که جهت را از «نزدیک‌ترین
        // اجداد dir» خودِ عنصر می‌گیرد — در RTL به چپ و در LTR به راست، همیشه درست.
        className={cn(
          "bg-background dark:data-[state=unchecked]:bg-foreground dark:data-[state=checked]:bg-primary-foreground pointer-events-none block size-4 rounded-full ring-0 transition-all",
          "data-[state=unchecked]:ms-0 data-[state=checked]:ms-[calc(100%_-_16px)]"
        )}
      />
    </SwitchPrimitive.Root>
  )
}

export { Switch }

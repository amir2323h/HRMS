// ============================================================
// Backfill v2.9.1 — رفع شکست بیلد در به‌روزرسانی ۲.۹.۰
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱
//  ۲) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v291.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_291 = {
  version: "2.9.1",
  title: "تازه‌های نسخه ۲.۹.۱",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "رفع خطای پایان به‌روزرسانی ۲.۹.۰",
      desc: "در نسخه ۲.۹.۰ فرایند به‌روزرسانی همه مراحل را با موفقیت طی می‌کرد اما در مرحله ساخت نسخه تولیدی (بیلد) با خطای داخلی Turbopack متوقف می‌شد و نسخه قبلی به‌صورت خودکار بازگردانی می‌شد. ریشه خطا (تحلیل ایستای دسترسی فایل سیستم + ناسازگاری نمایش کاراکترهای فارسی) برطرف شد؛ همه قابلیت‌های ۲.۹.۰ (ماتریس آیزنهاور، نمای زنجیره واگذاری و…) پس از این به‌روزرسانی فعال خواهند بود.",
    },
    {
      tag: "SEC",
      title: "قفل نسخه بسته‌های ساخت",
      desc: "نسخه Next.js و ابزارهای بیلد از این نسخه به‌صورت دقیق (exact) قفل شده‌اند تا نصب و به‌روزرسانی روی سرور دقیقاً همان محیطی را بسازد که پیش از انتشار تست شده است — دیگر نسخه‌های شناور (caret) علت اختلاف محیط سرور و توسعه نمی‌شوند.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_291) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.1") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      // ارتقای اطلاعیه پیش‌فرض → ۲.۹.۱ (پاپ‌آپ یک‌باره برای کاربران)
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_291) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۲. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.4 — اعمال تفکیک حقوق (پایه/مسولیت/شایستگی) در محاسبه معکوس + بهبود Docker

//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۴
// ۲) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v294.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_294 = {
  version: "2.9.4",
  title: "تازه‌های نسخه ۲.۹.۴",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "اعمال تفکیک حقوق ماهانه (پایه / مسولیت / شایستگی) در موتور محاسبه معکوس",
      desc: "در «محاسبه معکوس حقوق»، درصدهای تفکیک سطح شغلی (حق مسولیت و پاداش شایستگی) نادیده گرفته می‌شد و کل حقوق به‌عنوان پایه محاسبه می‌شد. اکنون تفکیک طبقه انتخاب‌شده در معادله معکوس، پیش‌نمایش و ثبت پیش‌نویس/تاریخچه تغییرات حقوق اعمال می‌شود و اقلام فیش معکوس (حقوق پایه، حق مسولیت، پاداش شایستگی) با همان درصدهای سطح تفکیک می‌گردد. ضمناً پشتیبانی Docker در شبکه‌های با دسترسی محدود به Docker Hub بهبود یافت (قابلیت تعویض ایمیج پایه با آینه جایگزین).",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_294) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۴» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.4") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      // ارتقای اطلاعیه پیش‌فرض → ۲.۹.۴ (پاپ‌آپ یک‌باره برای کاربران)
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_294) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۴» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۲. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.6 — اصلاحات استقرار PaaS (داکپلوی/Nixpacks)
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version») — fallback فوتر/پنل آپدیت
// ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۶
// ۳) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v296.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_296 = {
  version: "2.9.6",
  title: "تازه‌های نسخه ۲.۹.۶",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIXED",
      title: "نمایش نسخه محصول در فوتر و پنل به‌روزرسانی (استقرار ابری)",
      desc: "روی استقرارهای PaaS (داکپلوی و…) شماره نسخه در فوتر و بخش به‌روزرسانی نمایش داده نمی‌شد. اکنون نسخه نصب‌شده علاوه بر متغیر محیطی، در خود دیتابیس نیز مهر می‌خورد و در همه مسیرها — VPS، داکر و ابر — در فوتر، صفحه ورود و پنل وضعیت نسخه دیده می‌شود.",
    },
    {
      tag: "FIXED",
      title: "داده‌های پایه در استقرار ابری (تعطیلات، قالب‌نامه‌ها و…) خودکار بارگذاری می‌شود",
      desc: "در بیلد Nixpacks، زنجیره کامل داده‌های پایه — تعطیلات رسمی ۱۴۰۵، شیفت‌ها و ساعت استاندارد، قالب‌نامه‌های آماده، اطلاعیه نسخه و مجوزهای نقش‌ها — حالا هم‌زمان با بیلد روی دیتابیس اعمال می‌شود. پیش از این فقط مدیر اولیه ساخته می‌شد و بخش تعطیلات ماه و داده‌های پایه خالی می‌ماند.",
    },
    {
      tag: "SECURITY",
      title: "کلید امضای نشست‌ها در استقرار ابری تصادفی و پایدار است",
      desc: "AUTH_SECRET یکتا در زمان بیلد تولید و در فایل .env سرور standalone همراه می‌شود — نشست‌های ورود دیگر با کلید پیش‌فرض عمومی امضا نمی‌شوند. برای امنیت بیشتر می‌توانید AUTH_SECRET اختصاصی را از پنل پلتفرم به‌عنوان متغیر محیطی تعیین کنید.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_296) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۶» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.6") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_296) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۶» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

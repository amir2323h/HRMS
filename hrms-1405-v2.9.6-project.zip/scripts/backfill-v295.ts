// ============================================================
// Backfill v2.9.5 — سنوات قانونی (جدول تجمیعی ۱۴۰۵) + حق تاهل + دیپلوی Nixpacks
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۵
// ۲) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v295.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// (پارامترهای جدید legal_params — seniorityMode/seniorityDailyByYear/marriageAllowance —
//  به‌صورت خودکار از پیش‌فرض‌های موتور اعمال می‌شوند؛ نیازی به ردیف DB نیست)
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_295 = {
  version: "2.9.5",
  title: "تازه‌های نسخه ۲.۹.۵",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "قانونی",
      title: "پایه سنوات مطابق جدول تجمیعی رسمی ۱۴۰۵ محاسبه می‌شود",
      desc: "سنوات ماهانه کارکنان از «جدول احتساب مزد سنوات» (بخشنامه مزد ۱۴۰۵ — اداره کل روابط کار) خوانده می‌شود: نرخ روزانه تجمیعی × ۳۰، از ابتدای سال دوم (پس از یک سال کامل خدمت). جدول کامل ۱ تا ۳۰ سال در «تنظیمات ← پایه سنوات» قابل مشاهده و ویرایش است و برای کارگاه‌های دارای طبقه‌بندی مشاغل، حالت «طبقه‌ای» (پایه هر سال از طبقه شغلی) نیز در دسترس است. این سنوات در همه مسیرها — فیش حقوقی دوره، محاسبه معکوس، پیش‌نمایش تغییر حقوق — اعمال می‌شود.",
    },
    {
      tag: "قانونی",
      title: "حق تاهل ۵,۰۰۰,۰۰۰ ریال (مصوبه ۱۴۰۵) برای کارکنان متاهل",
      desc: "مطابق مصوبه شورای عالی کار ۱۴۰۵، به کارکنان متاهل ماهانه ۵۰۰ هزار تومان حق تاهل تعلق می‌گیرد — به‌طور خودکار بر اساس وضعیت تأهل پرونده کارمند و قابل ویرایش از «تنظیمات ← مزایای قانونی». این عنوان مشمول مالیات است و مشمول بیمه نیست.",
    },
    {
      tag: "DEPLOY",
      title: "پشتیبانی رسمی از Build Type = Nixpacks (داکپلوی و…)",
      desc: "خطای «Node.js 18.x has reached End-Of-Life» و خطای 403 دانلود ایمیج Docker Hub رفع شد: نسخه Node روی ۲۲ قفل شد (فایل .nvmrc)، اسکریپت آماده‌سازی دیتابیس و بیلد خودکار Nixpacks اضافه شد و راهنمای گام‌به‌گام استقرار در فایل DOCPLOY-GUIDE.md بسته ارائه شده است.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_295) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۵» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.5") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_295) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۵» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۲. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// nixpacks-prebuild — آماده‌سازی محیط برای بیلدرهای Nixpacks
// (داکپلوی / Coolify / Railway و…)
//
// اجرا در گام build (nixpacks.toml) — قبل از «npm run build»:
//  ۱) تعیین DATABASE_URL — اولویت: متغیر محیطی پنل > مسیر پیش‌فرض پروژه
//  ۲) نوشتن .env (DATABASE_URL + AUTH_SECRET + APP_VERSION) برای اجرای
//     runtime سرور standalone (next build آن را داخل standalone کپی می‌کند)
//  ۳) ساخت/همگام‌سازی دیتابیس SQLite (prisma db push)
//  ۴) bootstrap مدیر اولیه (admin / admin123) + مهر نسخه — idempotent
//  ۵) زنجیره بک‌فیل‌های داده پایه — همان دنباله نصب تمیز VPS/داکر:
//     قالب‌نامه‌ها، تعطیلات رسمی ۱۴۰۵، شیفت‌ها، اطلاعیه نسخه و…
//     (رفع باگ v2.9.5: در داکپلوی تعطیلات/مالیات/قالب‌ها خالی می‌ماندند
//      چون هیچ بک‌فیلی اجرا نمی‌شد — همه idempotent و بی‌دست‌زدن به داده‌ها)
//  ۶) AUTH_SECRET تصادفی در صورت نبود (ورود یکپارچه/امنیت)
//
// ⚠ داده‌های دیتابیس روی PaaS معمولاً «موقتی»اند — با هر دیپلوی جدید
//   دیتابیس ممکن است از نو ساخته شود. برای داده ماندگار از نصب VPS یا
//   Docker+والیوم استفاده کنید.
// ============================================================
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import { execSync } from "child_process";
import { randomBytes } from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dbDir = path.join(root, "db");
const dbFile = path.join(dbDir, "custom.db");

// همان دنباله نصب تمیز داکر/VPS — همیشه idempotent
const BACKFILLS = [
  "backfill-v8.ts", // قالب‌نامه‌های آماده
  "backfill-v28.ts", // تعطیلات رسمی ۱۴۰۵ + شیفت‌ها و ساعت استاندارد
  "backfill-v281.ts", // اطلاعیه ۲.۸.۱ (پشتیبان‌گیری/بازیابی)
  "backfill-v29.ts", // مجوز مدیریت کار + اطلاعیه ۲.۹.۰
  "backfill-v291.ts",
  "backfill-v292.ts",
  "backfill-v293.ts",
  "backfill-v294.ts",
  "backfill-v295.ts",
  "backfill-v296.ts", // اطلاعیه ۲.۹.۶ + مهر نسخه در دیتابیس
];

// ---------- ۱) DATABASE_URL ----------
let dbUrl = (process.env.DATABASE_URL || "").trim();
if (dbUrl.startsWith("file:") && !path.isAbsolute(dbUrl.slice(5).replace(/\?.*$/, ""))) {
  // مسیر نسبی SQLite نسبت به prisma/schema.prisma حل می‌شود → مطلق می‌کنیم
  dbUrl = "file:" + path.join(root, "prisma", dbUrl.slice(5));
}
if (!dbUrl.startsWith("file:")) {
  if (dbUrl) {
    console.warn(`⚠ DATABASE_URL پنل (${dbUrl.slice(0, 40)}…) پایگاه غیر-SQLite است — این سامانه SQLite است؛ از دیتابیس لوکال پروژه استفاده می‌شود.`);
  }
  dbUrl = `file:${dbFile}`;
}
console.log(`▪ DATABASE_URL = ${dbUrl}`);
mkdirSync(dbDir, { recursive: true });

// ---------- ۲) .env برای runtime ----------
// next build این فایل را داخل .next/standalone کپی می‌کند و سرور standalone
// همان‌جا لودش می‌کند — پس هرچه اینجا بنویسیم در runtime در دسترس است.
// متغیرهای واقعی محیط (پنل پلتفرم) همیشه بر .env اولویت دارند (loadEnvConfig بازنویسی نمی‌کند)
const pkg = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8"));
const authSecret = (process.env.AUTH_SECRET || "").trim() || randomBytes(32).toString("hex");
const envPath = path.join(root, ".env");
const existingEnv = existsSync(envPath) ? readFileSync(envPath, "utf8") : "";
let envContent = existingEnv;
const setVar = (name, val) => {
  const re = new RegExp(`^${name}=.*$`, "m");
  if (re.test(envContent)) envContent = envContent.replace(re, `${name}=${val}`);
  else {
    if (envContent && !envContent.endsWith("\n")) envContent += "\n";
    envContent += `${name}=${val}\n`;
  }
};
setVar("DATABASE_URL", dbUrl);
setVar("AUTH_SECRET", authSecret);
// نسخه محصول — رفع باگ v2.9.5: بدون این خط فوتر/پنل آپدیت در PaaS نسخه نمی‌نمود
setVar("APP_VERSION", pkg.version);
writeFileSync(envPath, envContent);
console.log(`✓ .env آماده شد (DATABASE_URL + AUTH_SECRET + APP_VERSION=${pkg.version})`);

// ---------- ۳) دیتابیس ----------
try {
  execSync("npx prisma db push --skip-generate --accept-data-loss", {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, DATABASE_URL: dbUrl },
  });
  console.log(existsSync(dbFile) ? "✓ دیتابیس SQLite آماده شد" : "• دیتابیس خارجی (متغیر محیطی) استفاده می‌شود");
} catch (e) {
  console.error("✗ همگام‌سازی اسکیمای دیتابیس شکست خورد:", e.message);
  process.exit(1);
}

// ---------- ۴) bootstrap مدیر اولیه + مهر نسخه ----------
try {
  execSync("node scripts/docker-bootstrap.mjs", {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, DATABASE_URL: dbUrl },
  });
} catch (e) {
  console.error("✗ ساخت مدیر اولیه شکست خورد:", e.message);
  process.exit(1);
}

// ---------- ۵) زنجیره بک‌فیل‌های داده پایه ----------
// شکست هر بک‌فیل بیلد را متوقف نمی‌کند (داده مهم‌تر از بیلد نیست) اما
// با صدای بلند لاگ می‌شود تا در لاگ دیپلوی دیده شود.
// tsx با نسخه قفل‌شده (همان Dockerfile) — از npm registry دانلود می‌شود.
let failed = 0;
for (const bf of BACKFILLS) {
  const p = path.join(root, "scripts", bf);
  if (!existsSync(p)) continue;
  try {
    execSync(`npx --yes tsx@4.19.2 scripts/${bf}`, {
      cwd: root,
      stdio: "inherit",
      env: { ...process.env, DATABASE_URL: dbUrl },
    });
  } catch (e) {
    failed++;
    console.warn(`⚠ بک‌فیل ${bf} ناموفق بود (ادامه می‌دهیم): ${String(e.message || "").split("\n")[0]}`);
  }
}
if (failed > 0) {
  console.warn(`⚠ جمع‌بندی: ${failed} بک‌فیل ناموفق — داده پایه ممکن است ناقص باشد (لاگ بالا را ببینید)`);
} else {
  console.log("✓ داده پایه (تعطیلات ۱۴۰۵، قالب‌نامه‌ها، اطلاعیه نسخه و…) بارگذاری شد");
}

console.log(`▪ HRMS ${pkg.version} — آمادهٔ بیلد Nixpacks (ورود پیش‌فرض: admin / admin123)`);

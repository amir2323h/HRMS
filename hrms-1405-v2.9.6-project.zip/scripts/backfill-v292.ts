// ============================================================
// Backfill v2.9.2 — رفع باگ سوئیچ (دسته بیرون‌زده) در RTL
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲
// ۲) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v292.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_292 = {
  version: "2.9.2",
  title: "تازه‌های نسخه ۲.۹.۲",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "رفع باگ دکمه بولین (سوئیچ) در نمای آیزنهاور",
      desc: "در نمای «مدیریت کار (آیزنهاور)»، دسته‌ی سوئیچ در حالت فعال بیرون از کادر می‌افتاد. ریشه: کامپوننت تب‌ها به‌صورت پیش‌فرض جهت چیدمان را LTR فرض می‌کرد و در صفحه‌ی RTL جزیره‌ی جهت‌دار می‌ساخت. اصلاح در سه لایه: جهت RTL سراسری برای همه کامپوننت‌های رادیکس، جهت صریح تب‌های مدیریت کار و مدیریت تغییرات حقوق، و بازنویسی حرکت دسته با ویژگی منطقی margin-inline که در هر جهت و هر جای صفحه همیشه درست کار می‌کند — این اصلاح روی همه‌ی سوئیچ‌های سامانه (تنظیمات، پورتال، حقوق و…) اعمال شده است.",
    },
    {
      tag: "OPS",
      title: "پشتیبانی رسمی از نصب با Docker",
      desc: "از این نسخه، بسته Docker سامانه (Dockerfile + docker-compose) همراه راهنمای گام‌به‌گام فارسی ارائه می‌شود — نصب و راه‌اندازی روی هر سروری با فقط دو فرمان docker compose up -d و بدون نیاز به نصب Node.js یا هر ابزار دیگری روی میزبان.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_292) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.2") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      // ارتقای اطلاعیه پیش‌فرض → ۲.۹.۲ (پاپ‌آپ یک‌باره برای کاربران)
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_292) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۲. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

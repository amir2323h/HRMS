// ============================================================
// Backfill v2.9.0 — مدیریت کار (ماتریس آیزنهاور + زنجیره واگذاری)
//  ۱) مجوز tasks:use به «همه نقش‌ها» (مدیریت کار برای همه کاربران)
//  ۲) اطلاعیه «تازه‌های نسخه ۲.۹.۰»
//  ۳) پاکسازی کش چک آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v29.ts
// idempotent — مجوز تکراری اضافه نمی‌شود؛ اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_29 = {
  version: "2.9.0",
  title: "تازه‌های نسخه ۲.۹.۰",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    { tag: "NEW", title: "مدیریت کار — ماتریس آیزنهاور برای همه", desc: "منوی جدید «مدیریت کار (آیزنهاور)»: کارهایتان را در ۴ ربع بچینید — فوری و مهم (همین حالا انجام بده)، مهم و غیرفوری (زمان‌بندی کن)، فوری و غیرمهم (واگذار کن) و غیرفوری و غیرمهم (حذف کن). کارت‌ها را با کشیدن بین ربع‌ها جابه‌جا کنید؛ موعد شمسی، وضعیت و عقب‌افتادگی هر کار مشخص است." },
    { tag: "NEW", title: "واگذاری کار به همکاران", desc: "هر وظیفه را موقع ساخت یا بعداً به همکاران بسپارید — با یادداشت. گیرنده کار را در ماتریس «کارهای رسیده به من» می‌بیند و می‌تواند انجام‌اش را شروع یا کامل کند." },
    { tag: "NEW", title: "نمای زنجیره واگذاری (نود)", desc: "نقشه گرافی کارهای واگذارشده: از شما شروع می‌شود و نشان می‌دهد هر کار الان نزد کیست، از کدام مسیر رسیده و چه وضعیتی دارد — با کلیک روی هر نفر، کارهای فعلی او را ببینید." },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مجوز tasks:use برای همه نقش‌ها ----------
  const roles = await db.role.findMany();
  let touched = 0;
  for (const r of roles) {
    let perms: string[] = [];
    try {
      perms = JSON.parse(r.permissions || "[]");
    } catch {
      perms = [];
    }
    if (!Array.isArray(perms)) perms = [];
    if (perms.includes("*") || perms.includes("tasks:use")) continue; // مدیر کل یا از قبل دارد
    perms.push("tasks:use");
    await db.role.update({ where: { id: r.id }, data: { permissions: JSON.stringify(perms) } });
    touched++;
    console.log(`  ✓ نقش «${r.name}» (${r.key}) → tasks:use`);
  }
  console.log(touched ? `✓ مجوز مدیریت کار به ${touched} نقش اضافه شد` : "• همه نقش‌ها از قبل مجوز داشتند");

  // کاربران بدون roleId → اتصال به نقش متناظر (سلامت داده)
  const users = await db.user.findMany({ where: { roleId: null } });
  for (const u of users) {
    const role = await db.role.findUnique({ where: { key: u.role } });
    if (role) await db.user.update({ where: { id: u.id }, data: { roleId: role.id } });
  }

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_29) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۰» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.0") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      // ارتقای اطلاعیه پیش‌فرض → ۲.۹.۰ (پاپ‌آپ یک‌باره برای کاربران)
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_29) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۰» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

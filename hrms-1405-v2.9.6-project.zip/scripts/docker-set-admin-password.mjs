// ============================================================
// Docker — تغییر رمز مدیر در اولین بالا آمدن (اختیاری)
// اجرا: HRMS_ADMIN_PASSWORD=... DATABASE_URL=file:/data/custom.db node scripts/docker-set-admin-password.mjs
// idempotent — فقط اگر HRMS_ADMIN_PASSWORD تنظیم شده باشد معنا دارد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";

const db = new PrismaClient();
const salt = randomBytes(16).toString("hex");
const hash = scryptSync(process.env.HRMS_ADMIN_PASSWORD, salt, 64).toString("hex");
const r = await db.user.updateMany({
  where: { username: "admin" },
  data: { passwordHash: `${salt}:${hash}` },
});
await db.$disconnect();
console.log(`admin-password-set: ${r.count} کاربر به‌روزرسانی شد`);

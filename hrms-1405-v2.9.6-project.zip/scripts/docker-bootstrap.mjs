// ============================================================
// Docker/PaaS bootstrap — نصب تمیز: ساخت مدیر اولیه + تنظیمات پایه + مهر نسخه
// معادل bootstrap.mjs داخل نصب‌کننده VPS (حالت نصب تمیز)
// اجرا: DATABASE_URL=file:/data/custom.db node scripts/docker-bootstrap.mjs
// idempotent — برای نصب تازه داکر و بیلد Nixpacks (داکپلوی و…)
// مهر «app_version» منبع fallback نسخه در فوتر/پنل آپدیت است وقتی
// env APP_VERSION وجود ندارد (استقرارهای PaaS).
// ============================================================
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();
const salt = randomBytes(16).toString("hex");
const hash = scryptSync(process.env.HRMS_ADMIN_PASSWORD || "admin123", salt, 64).toString("hex");
const role = await db.role.upsert({
  where: { key: "SUPER_ADMIN" },
  update: {},
  create: { key: "SUPER_ADMIN", name: "مدیر کل سیستم", description: "دسترسی کامل", permissions: "[\"*\"]" },
});
await db.user.upsert({
  where: { username: "admin" },
  update: { roleId: role.id },
  create: { username: "admin", passwordHash: `${salt}:${hash}`, fullName: "مدیر کل سیستم", role: "SUPER_ADMIN", roleId: role.id, isActive: true },
});
await db.systemSetting.upsert({
  where: { key: "display" },
  update: {},
  create: { key: "display", value: "{\"unit\":\"TOMAN\"}" },
});
// مهر نسخه نصب‌شده — همیشه تازه می‌شود (update فعال) تا بعد از هر بیلد/بوت
// با نسخه همان بیلد هم‌گام بماند؛ در VPS/داکر env APP_VERSION بر آن اولویت دارد
await db.systemSetting.upsert({
  where: { key: "app_version" },
  update: { value: pkgVersion },
  create: { key: "app_version", value: pkgVersion },
});
await db.$disconnect();
console.log(`bootstrap-ok: admin / ${process.env.HRMS_ADMIN_PASSWORD ? "(از HRMS_ADMIN_PASSWORD)" : "admin123"} — app_version=${pkgVersion}`);

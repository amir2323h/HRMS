// ============================================================
// Backfill v2.9.3 — رفع باگ دکمه‌های کارت وظیفه در ماتریس آیزنهاور
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۳
// ۲) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v293.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_293 = {
  version: "2.9.3",
  title: "تازه‌های نسخه ۲.۹.۳",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "رفع باگ قفل‌شدن دکمه‌های کارت وظیفه در ماتریس آیزنهاور",
      desc: "در ماتریس آیزنهاور، دکمه‌های روی کارت وظیفه (شروع انجام، انجام شد، واگذاری، ویرایش و حذف) به کلیک پاسخ نمی‌دادند. ریشه: شنونده‌های «کشیدن‌ورهاکردن» روی کل کارت فعال بود و هر کلیک را پیش از رسیدن به دکمه، به‌عنوان شروع درگ تفسیر می‌کرد. اصلاح: جابه‌جایی کارت حالا فقط از دستگیره اختصاصی کنار کارت انجام می‌شود و کلیک ساده (بدون حرکت ماوس) هرگز درگ نمی‌شود — همه دکمه‌ها در دسکتاپ و موبایل کاملاً فعال و پاسخگو هستند.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_293) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۳» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.3") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      // ارتقای اطلاعیه پیش‌فرض → ۲.۹.۳ (پاپ‌آپ یک‌باره برای کاربران)
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_293) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۳» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۲. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.11 — مدیریت پرسنل + خالص پرداختی طبقه‌بندی
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version») — fallback فوتر/پنل آپدیت
// ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱۱
// ۳) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2911.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ستون leaveDateJ از طریق prisma db push (prebuild/entrypoint) اضافه می‌شود
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2911 = {
  version: "2.9.11",
  title: "تازه‌های نسخه ۲.۹.۱۱",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "انتخاب چندتایی پرسنل + عملیات گروهی",
      desc: "در لیست کارکنان ستون چک‌باکس و «انتخاب همه» اضافه شد؛ با انتخاب چند نفر، نوار عملیات گروهی ظاهر می‌شود: ترک کار (غیرفعال‌سازی با تاریخ)، فعال‌سازی مجدد و حذف گروهی (فقط مدیر) + فیلتر وضعیت (فعال/غیرفعال/قطع همکاری).",
    },
    {
      tag: "NEW",
      title: "حذف قرارداد و پرسنل — فقط مدیر",
      desc: "مجوزهای جدید «employees:delete» و «contracts:delete» فقط به مدیر کل سیستم تعلق دارد. حذف کارمند تمام سوابق وابسته را آبشاری برمی‌دارد (با تأیید دو مرحله‌ای) و حذف قرارداد برای هر وضعیت (نه فقط پیش‌نویس) برای مدیر فعال شد — همه عملیات در لاگ حسابرسی ثبت می‌شوند.",
    },
    {
      tag: "NEW",
      title: "ترک کار + تاریخ ترک کار در پرونده پرسنل",
      desc: "دیالوگ «ثبت ترک کار» با تاریخ جلالی و دلیل اختیاری؛ تاریخ ترک کار در پرونده کامل کارمند، ستون وضعیت لیست و سابقه تغییرات ثبت و نمایش می‌یابد. با فعال‌سازی مجدد، تاریخ به‌صورت خودکار پاک می‌شود.",
    },
    {
      tag: "NEW",
      title: "خالص پرداختی کف/سقف در طبقه‌بندی مشاغل",
      desc: "روی کارت هر سطح (۱ تا ۷) کادر «خالص پرداختی (۱۴۰۵)» اضافه شد: خالص پرداختی ماهانه برای کف و سقف حقوق سطح بر اساس پارامترهای قانونی سال جاری (بیمه ۷٪ + مالیات پلکانی ماده ۸۵ + مزایای استاندارد) محاسبه و نمایش می‌یابد.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2911) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱۱» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.11") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2911) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱۱» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

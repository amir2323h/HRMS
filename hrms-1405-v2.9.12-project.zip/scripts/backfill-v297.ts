// ============================================================
// Backfill v2.9.7 — ماندگاری داده روی داکپلوی (PaaS) + آپدیت بدون پاک شدن داده‌ها
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version») — fallback فوتر/پنل آپدیت
// ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۷
// ۳) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v297.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_297 = {
  version: "2.9.7",
  title: "تازه‌های نسخه ۲.۹.۷",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIXED",
      title: "ماندگاری داده‌ها روی داکپلوی — دیگر هیچ داده‌ای با آپدیت پاک نمی‌شود",
      desc: "با هر ری‌دیپلوی، دیتابیس موقتیِ داخل کانتینر از نو ساخته می‌شد و همه کارکنان، فیش‌ها و تنظیمات پاک می‌شدند. اکنون با «والیوم ماندگار» (داکپلوی ← Advanced ← Volumes/Mounts ← مسیر /data) دیتابیس خارج از کانتینر نگه داشته می‌شود و آپدیت نسخه فقط کد را عوض می‌کند، نه داده‌ها را. راهنمای گام‌به‌گام در فایل DOCPLOY-GUIDE.md بخش «ماندگاری داده‌ها با والیوم» آمده است.",
    },
    {
      tag: "NEW",
      title: "به‌روزرسانی هوشمند در زمان اجرا — بدون نصب از ابتدا",
      desc: "در هر بار راه‌اندازی، نسخهٔ دیتابیس با نسخهٔ ایمیج مقایسه می‌شود: اگر یکسان باشند سامانه فوراً بالا می‌آید (شروع سریع)؛ اگر نسخه جدید باشد فقط همگام‌سازی اسکیما و داده‌های پایهٔ نسخهٔ جدید اعمال می‌شود و همه کاربران، نقش‌ها و داده‌ها دست‌نخورده باقی می‌مانند — معادل رفتار «حالت به‌روزرسانی» نصب‌کنندهٔ VPS.",
    },
    {
      tag: "NEW",
      title: "بکاپ خودکار پیش از هر به‌روزرسانی",
      desc: "قبل از اعمال هر به‌روزرسانی روی دیتابیس، یک نسخهٔ پشتیبان با نام hrms-backup-auto-preupdate-… ذخیره می‌شود که در «تنظیمات ← پشتیبان‌گیری» قابل مشاهده، دانلود و بازیابی است (۵ نسخهٔ آخر نگه داشته می‌شود). کلید امضای نشست‌ها هم روی والیوم ذخیره می‌شود تا با هر ری‌دیپلوی، ورود کاربران بی‌اعتبار نشود.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_297) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۷» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.7") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_297) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۷» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

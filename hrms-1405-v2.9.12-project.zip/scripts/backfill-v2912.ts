// ============================================================
// Backfill v2.9.12 — رفع محاسبه خالص پرداختی طبقه‌بندی + افزایش قانونی مزد ۱۴۰۵
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version») — fallback فوتر/پنل آپدیت
// ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱۲
// ۳) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2912.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// پارامترهای افزایش قانونی (۴۵٪ + ثابت ماهانه) به‌صورت خودکار از پیش‌فرض
// موتور محاسبه خوانده می‌شوند — بدون تغییر داده یا مهاجرت اسکیما.
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2912 = {
  version: "2.9.12",
  title: "تازه‌های نسخه ۲.۹.۱۲",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIXED",
      title: "رفع محاسبه خالص پرداختی طبقه‌بندی — افزایش قانونی مزد ۱۴۰۵ لحاظ شد",
      desc: "در کارت «خالص پرداختی (۱۴۰۵)» هر سطح، بازه حقوق ثبت‌شده (مبنای سال قبل) اکنون ابتدا با فرمول رسمی بخشنامه مزد ۱۴۰۵ شورای عالی کار — ۴۵٪ مزد مبنا + مبلغ ثابت ماهانه ۱۵,۵۸۶,۴۷۰ ریال (روزانه ۵۱۹,۵۴۹ ریال) با کف حداقل دستمزد جدید — به معادل ۱۴۰۵ تبدیل و سپس پس از بیمه ۷٪ و مالیات پلکانی ماده ۸۵ محاسبه می‌شود. مبنای ۱۴۰۵ هر سطح روی کارت نمایش می‌یابد و درصد/مبلغ ثابت و فعال/غیرفعال بودن افزایش از «تنظیمات ← اطلاعات پایه» قابل تنظیم است (اگر جدول شما از ابتدا با ارقام ۱۴۰۵ ثبت شده، افزایش را خاموش کنید).",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2912) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱۲» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.12") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2912) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱۲» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

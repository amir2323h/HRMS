// ============================================================
// Backfill v2.9.8 — رفع کرش صفحه نقش‌ها و مجوزها (RoleEditor)
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version») — fallback فوتر/پنل آپدیت
// ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۸
// ۳) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v298.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_298 = {
  version: "2.9.8",
  title: "تازه‌های نسخه ۲.۹.۸",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIXED",
      title: "رفع خطای صفحه «نقش‌ها و مجوزهای دسترسی» هنگام ساخت یا ویرایش مجوز",
      desc: "در تنظیمات ← نقش‌ها و مجوزها، با کلیک روی «نقش جدید» یا «مجوزها» صفحه با خطای «Cannot read properties of undefined (reading 'map')» مواجه می‌شد. علت، ناسازگاری ساختار فهرست مجوزها بین سرور و رابط کاربری بود که اصلاح شد؛ اکنون ماتریس مجوزها (۷ گروه / ۳۸ مجوز) به‌درستی نمایش داده می‌شود و ساخت، ویرایش و حذف نقش بدون خطا کار می‌کند.",
    },
    {
      tag: "FIXED",
      title: "مقاوم‌سازی رابط در برابر داده ناقص + پارس امن مجوزهای نقش",
      desc: "حتی اگر پاسخ سرور ناقص یا کش‌شده قدیمی باشد، دیالوگ ویرایش نقش دیگر هرگز کل صفحه را کرش نمی‌کند و در بدترین حالت پیام راهنما نمایش می‌دهد. رکوردهای نقش با مقدار خراب نیز باعث خطای سرور نمی‌شوند.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_298) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۸» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.8") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_298) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۸» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

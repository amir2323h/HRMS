// ============================================================
// Backfill v2.9.9 — مدل دوم پاداش: برآورد بودجه بر اساس توزیع نفرات
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version») — fallback فوتر/پنل آپدیت
// ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۹
// ۳) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v299.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_299 = {
  version: "2.9.9",
  title: "تازه‌های نسخه ۲.۹.۹",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "مدل دوم پاداش — برآورد بودجه بر اساس توزیع نفرات در چهار وضعیت تارگت",
      desc: "در ماژول «پاداش و سود سالانه» دکمهٔ «برآورد بودجه پاداش» اضافه شد: تعداد نفراتی را که پیش‌بینی می‌کنید در هر یک از چهار وضعیت (نرسیده به تارگت، ۸۰٪، ۱۰۰٪ و ۱۲۰٪+) قرار بگیرند وارد کنید تا بر اساس «تعداد بونس» ثبت‌شدهٔ هر طبقه در اطلاعات پایه و حقوق پایه/ماه حضور کارکنان فعال، بودجهٔ لازم پاداش به‌صورت زنده برآورد شود. شامل میانگین و بازهٔ پاداش هر نفر در هر وضعیت، سناریوی «همهٔ سازمان در یک وضعیت» و جدول مبنا به تفکیک طبقه. چیزی ذخیره نمی‌شود — صرفاً برنامه‌ریزی بودجه.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_299) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۹» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.9") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_299) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۹» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

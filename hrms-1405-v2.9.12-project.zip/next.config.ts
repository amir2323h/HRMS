import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  // Next 16 درخواست‌های بین‌مبدأ به منابع dev (HMR و…) را به‌طور پیش‌فرض می‌بندد
  // — بدون این فهرست، مرورگر در حلقه ریلود می‌افتد و صفحه هرگز hydrate نمی‌شود
  // (لاگ: «Blocked cross-origin request to Next.js dev resource /_next/hmr»)
  allowedDevOrigins: ["127.0.0.1", "localhost", "*.space-z.ai"],
};

export default nextConfig;

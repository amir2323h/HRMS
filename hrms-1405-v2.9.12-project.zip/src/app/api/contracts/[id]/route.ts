import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAnyPerm, sessionHasPerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeContract } from "@/lib/serializers";
import { canTransition, CONTRACT_STATUSES } from "@/lib/contracts";
import { isValidJalali, todayJalaliStr } from "@/lib/jalali";

/** جزئیات کامل قرارداد (متن رندرشده) */
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(req, "contracts:view");
    const { id } = await ctx.params;
    const contract = await db.contract.findUnique({
      where: { id },
      include: { employee: { select: { firstName: true, lastName: true } } },
    });
    if (!contract) return Response.json({ error: "قرارداد یافت نشد." }, { status: 404 });
    return { contract: serializeContract(contract as never) };
  });
}

/** تغییر وضعیت چرخه قرارداد (گردش کار استاندارد) + تاریخ امضا/فسخ */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "contracts:manage");
    const { id } = await ctx.params;
    const before = await db.contract.findUnique({ where: { id } });
    if (!before) return Response.json({ error: "قرارداد یافت نشد." }, { status: 404 });
    const b = await req.json();

    const data: Record<string, unknown> = {};

    if (b.status !== undefined) {
      const to = String(b.status);
      if (!CONTRACT_STATUSES.includes(to as never)) return Response.json({ error: "وضعیت نامعتبر است." }, { status: 400 });
      if (!canTransition(before.status, to)) {
        return Response.json({ error: `گذار از وضعیت «${before.status}» به «${to}» مجاز نیست.` }, { status: 400 });
      }
      data.status = to;
      // تاریخ‌های خودکار گذار
      if (to === "SIGNED") data.signedDateJ = String(b.signedDateJ || todayJalaliStr());
      if (to === "TERMINATED") {
        data.terminateDateJ = String(b.terminateDateJ || todayJalaliStr());
        data.terminateReason = String(b.terminateReason || "").slice(0, 500);
      }
    }
    if (b.signedDateJ !== undefined) {
      if (b.signedDateJ && !isValidJalali(b.signedDateJ)) return Response.json({ error: "تاریخ امضا نامعتبر است." }, { status: 400 });
      data.signedDateJ = String(b.signedDateJ);
    }
    if (b.terminateReason !== undefined) data.terminateReason = String(b.terminateReason).slice(0, 500);

    if (Object.keys(data).length === 0) return Response.json({ error: "تغییری ارسال نشده است." }, { status: 400 });

    const after = await db.contract.update({
      where: { id },
      data,
      include: { employee: { select: { firstName: true, lastName: true } } },
    });
    await audit(
      session,
      "UPDATE",
      "CONTRACT",
      id,
      `تغییر وضعیت قرارداد ${before.contractNumber} از «${before.status}» به «${after.status}»`,
      { status: before.status },
      { status: after.status }
    );
    return { contract: serializeContract(after as never) };
  });
}

/** حذف قرارداد — دو سطح دسترسی:
 *  • contracts:manage → فقط پیش‌نویس‌ها (استاندارد ردپای صندوق اسناد)
 *  • contracts:delete (مدیر) → هر وضعیتی — حذف کامل رکورد
 *  قراردادهای صادرشده غیرمدیریتی باید «ابطال» شوند */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requireAnyPerm(req, ["contracts:manage", "contracts:delete"]);
    const isAdmin = sessionHasPerm(session, "contracts:delete");
    const { id } = await ctx.params;
    const contract = await db.contract.findUnique({ where: { id } });
    if (!contract) return Response.json({ error: "قرارداد یافت نشد." }, { status: 404 });
    if (contract.status !== "DRAFT" && !isAdmin) {
      return Response.json({ error: "فقط قراردادهای پیش‌نویس قابل حذف‌اند — برای قرارداد صادرشده از «ابطال» استفاده کنید. حذف کامل قرارداد صادرشده فقط با مجوز مدیر (contracts:delete) ممکن است." }, { status: 400 });
    }
    await db.contract.delete({ where: { id } });
    await audit(
      session,
      "DELETE",
      "CONTRACT",
      id,
      `حذف قرارداد ${contract.contractNumber} (${contract.employeeName}) — وضعیت ${contract.status}`,
      { status: contract.status, contractNumber: contract.contractNumber, employeeName: contract.employeeName },
      null
    );
    return { ok: true };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// حذف گروهی قراردادها — فقط مدیر (مجوز contracts:delete)
// هر وضعیت قراردادی قابل حذف است؛ رکوردها به‌صورت کامل برداشته می‌شوند
// ============================================================

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "contracts:delete");
    const b = await req.json();
    const ids = Array.isArray(b?.ids) ? b.ids.map(String).filter(Boolean) : [];
    if (ids.length === 0) return Response.json({ error: "هیچ قراردادی انتخاب نشده است." }, { status: 400 });
    if (ids.length > 500) return Response.json({ error: "حداکثر ۵۰۰ قرارداد در هر عملیات گروهی." }, { status: 400 });

    const contracts = await db.contract.findMany({ where: { id: { in: ids } } });
    if (contracts.length === 0) return Response.json({ error: "هیچ قرارداد معتبری یافت نشد." }, { status: 404 });

    await db.contract.deleteMany({ where: { id: { in: contracts.map((c) => c.id) } } });

    const byStatus: Record<string, number> = {};
    for (const c of contracts) byStatus[c.status] = (byStatus[c.status] || 0) + 1;

    await audit(
      session,
      "DELETE",
      "CONTRACT",
      contracts[0].id,
      `حذف گروهی ${contracts.length} قرارداد — ${contracts.map((c) => c.contractNumber).slice(0, 10).join(", ")}${contracts.length > 10 ? " و…" : ""}`,
      { ids: ids.length, byStatus },
      { deleted: contracts.length }
    );

    return { ok: true, action: "delete", count: contracts.length, byStatus };
  });
}

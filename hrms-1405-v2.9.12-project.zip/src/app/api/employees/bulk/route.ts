import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { isValidJalali, todayJalaliStr } from "@/lib/jalali";
import { snapshotFromEmployee, diffEmployee, logEmployeeChange } from "@/lib/employee-changelog";

// ============================================================
// عملیات گروهی کارکنان (انتخاب چندتایی در لیست)
//  action=deactivate → غیرفعال‌سازی به دلیل ترک کار (status=INACTIVE + leaveDateJ)
//  action=activate   → فعال‌سازی مجدد (status=ACTIVE + پاک شدن تاریخ ترک کار)
//  action=delete     → حذف کامل پرونده‌ها — فقط مدیر (مجوز employees:delete)
// ============================================================

interface BulkBody {
  action?: string;
  ids?: unknown;
  leaveDateJ?: string;
  reason?: string;
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const b = (await req.json()) as BulkBody;
    const action = String(b.action || "");
    const ids = Array.isArray(b.ids) ? b.ids.map(String).filter(Boolean) : [];

    if (!["deactivate", "activate", "delete"].includes(action)) {
      return Response.json({ error: "عملیات نامعتبر است." }, { status: 400 });
    }
    if (ids.length === 0) return Response.json({ error: "هیچ کارمندی انتخاب نشده است." }, { status: 400 });
    if (ids.length > 500) return Response.json({ error: "حداکثر ۵۰۰ کارمند در هر عملیات گروهی." }, { status: 400 });

    // تاریخ ترک کار (اگر ارسال شده) باید جلالی معتبر باشد — پیش‌فرض: امروز
    let leaveDateJ = "";
    if (action === "deactivate") {
      leaveDateJ = String(b.leaveDateJ || "").trim() || todayJalaliStr();
      if (!isValidJalali(leaveDateJ)) {
        return Response.json({ error: "قالب تاریخ ترک کار نامعتبر است (مثال: 1405/03/15)." }, { status: 400 });
      }
    }

    // مجوز: حذف فقط با employees:delete؛ تغییر وضعیت با employees:edit
    const session = action === "delete"
      ? requirePerm(req, "employees:delete")
      : requirePerm(req, "employees:edit");

    const reason = String(b.reason || "").slice(0, 500);
    const employees = await db.employee.findMany({
      where: { id: { in: ids } },
      include: { jobGrade: true, departments: { include: { department: true } } },
    });
    if (employees.length === 0) return Response.json({ error: "هیچ کارمند معتبری یافت نشد." }, { status: 404 });

    const skipped: string[] = [];
    const done: string[] = [];
    let deletedRecords = 0;

    for (const emp of employees) {
      if (action === "delete") {
        const c = await db.employee.findUnique({
          where: { id: emp.id },
          select: { _count: { select: { payslips: true, contracts: true, documents: true, attendance: true, leaveRequests: true, advanceRequests: true, bonusLines: true } } },
        });
        deletedRecords += c
          ? c._count.payslips + c._count.contracts + c._count.documents + c._count.attendance +
            c._count.leaveRequests + c._count.advanceRequests + c._count.bonusLines
          : 0;
        await db.employee.delete({ where: { id: emp.id } });
        done.push(`${emp.firstName} ${emp.lastName}`);
        continue;
      }

      // تغییر وضعیت
      const nextStatus = action === "deactivate" ? "INACTIVE" : "ACTIVE";
      if (emp.status === nextStatus) {
        skipped.push(`${emp.firstName} ${emp.lastName} (${emp.personnelCode})`);
        continue;
      }

      const beforeSnap = snapshotFromEmployee(emp as unknown as Record<string, unknown>);
      await db.employee.update({
        where: { id: emp.id },
        data: action === "deactivate"
          ? { status: "INACTIVE", leaveDateJ }
          : { status: "ACTIVE", leaveDateJ: "" },
      });
      const after = await db.employee.findUnique({
        where: { id: emp.id },
        include: { jobGrade: true, departments: { include: { department: true } } },
      });
      const changes = diffEmployee(
        beforeSnap,
        snapshotFromEmployee(after as unknown as Record<string, unknown>)
      );
      await logEmployeeChange(
        session,
        emp.id,
        changes,
        "EDIT",
        action === "deactivate"
          ? `غیرفعال‌سازی به دلیل ترک کار${reason ? ` — ${reason}` : ""}`
          : "فعال‌سازی مجدد پس از ترک کار"
      );
      done.push(`${emp.firstName} ${emp.lastName}`);
    }

    await audit(
      session,
      action === "delete" ? "DELETE" : "UPDATE",
      "EMPLOYEE",
      done[0] || "bulk",
      action === "delete"
        ? `حذف گروهی ${done.length} پرونده کارمند — ${deletedRecords} رکورد وابسته آبشاری`
        : action === "deactivate"
          ? `غیرفعال‌سازی گروهی ${done.length} کارمند به دلیل ترک کار (تاریخ ${leaveDateJ})`
          : `فعال‌سازی گروهی ${done.length} کارمند`,
      { ids: ids.length, action },
      { done: done.length, skipped: skipped.length, deletedRecords: action === "delete" ? deletedRecords : undefined }
    );

    return {
      ok: true,
      action,
      count: done.length,
      deletedRecords: action === "delete" ? deletedRecords : undefined,
      leaveDateJ: action === "deactivate" ? leaveDateJ : undefined,
      skipped,
    };
  });
}

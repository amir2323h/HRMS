import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeGrade } from "@/lib/serializers";
import { getLegalParams } from "@/lib/settings";
import { computePaysheet, EMPTY_CONTEXT, applyLegalIncrease } from "@/lib/payroll/engine";

/** نرمال‌سازی درصدهای تفکیک حقوق سطح — جمع باید دقیقاً ۱۰۰ باشد
 *  پایه: مبنای اضافه‌کاری/مأموریت/فوق‌العاده‌ها | مسولیت/شایستگی: فقط بیمه+مالیات */
function parseSplitPercents(b: Record<string, unknown>): { basePercent: number; respPercent: number; meritPercent: number } | { error: string } {
  const resp = Math.round((Number(b.respPercent) || 0) * 10) / 10;
  const merit = Math.round((Number(b.meritPercent) || 0) * 10) / 10;
  if (resp < 0 || merit < 0) return { error: "درصد حق مسولیت/شایستگی نمی‌تواند منفی باشد." };
  if (resp + merit > 100) return { error: "جمع درصد حق مسولیت و شایستگی نباید بیش از ۱۰۰ باشد." };
  return { basePercent: Math.round((100 - resp - merit) * 10) / 10, respPercent: resp, meritPercent: merit };
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "grades:view");
    const grades = await db.jobGrade.findMany({ orderBy: { level: "asc" } });
    const counts = await db.employee.groupBy({
      by: ["jobGradeId"],
      where: { status: "ACTIVE" },
      _count: { id: true },
    });
    const countMap: Record<string, number> = {};
    for (const c of counts) if (c.jobGradeId) countMap[c.jobGradeId] = c._count.id;

    // ——— خالص پرداختی کف/سقف هر سطح — بر اساس پارامترهای قانونی سال جاری ———
    // فرض‌ها: کارمند مجرد بدون فرزند، بدون سنوات/اضافه‌کاری، با حق مسکن و بن؛
    // تفکیک درصدی و حق جذب همان سطح — نتیجه پس از بیمه ۷٪ و مالیات پلکانی ماده ۸۵
    // ⚠️ افزایش قانونی مزد ۱۴۰۵ (بخشنامه شورای عالی کار — سایر سطوح مزدی):
    // بازه حقوق ثبت‌شده سطح (مبنای سال قبل) ابتدا با فرمول «۴۵٪ + مبلغ ثابت ماهانه»
    // به معادل سال جاری تبدیل و سپس خالص آن محاسبه می‌شود (کف: حداقل دستمزد جدید).
    const params = await getLegalParams();
    const gradeRows = grades.map((g) => {
      const ctx = {
        ...EMPTY_CONTEXT,
        seniorityBase: Number(g.seniorityBase),
        attraction: Number(g.attraction),
        respPercent: Number(g.respPercent) > 0 ? Number(g.respPercent) : undefined,
        meritPercent: Number(g.meritPercent) > 0 ? Number(g.meritPercent) : undefined,
      };
      const rawMin = Number(g.minBaseSalary);
      const rawMax = Number(g.maxBaseSalary);
      const effMin = applyLegalIncrease(rawMin, params);
      const effMax = applyLegalIncrease(rawMax, params);
      return {
        ...serializeGrade(g, countMap[g.id] || 0),
        net: {
          year: params.year,
          min: rawMin > 0 ? computePaysheet(effMin.base, ctx, params).netPay : 0,
          max: rawMax > 0 ? computePaysheet(effMax.base, ctx, params).netPay : 0,
          // مبنای سال جاری پس از افزایش قانونی (برای نمایش شفاف روی کارت)
          baseMin: rawMin > 0 ? effMin.base : 0,
          baseMax: rawMax > 0 ? effMax.base : 0,
          increase: effMin.applied || effMax.applied
            ? { percent: params.legalIncreasePercent, fixedMonthly: params.legalIncreaseFixedMonthly }
            : null,
        },
      };
    });
    return { grades: gradeRows };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "grades:manage");
    const b = await req.json();
    if (!b.title?.trim() || !b.level) return Response.json({ error: "عنوان و سطح الزامی است." }, { status: 400 });
    const dup = await db.jobGrade.findUnique({ where: { level: +b.level } });
    if (dup) return Response.json({ error: "این سطح قبلاً تعریف شده است." }, { status: 400 });
    const split = parseSplitPercents(b);
    if ("error" in split) return Response.json({ error: split.error }, { status: 400 });
    const grade = await db.jobGrade.create({
      data: {
        level: +b.level,
        code: String(b.code || `L${b.level}`),
        title: String(b.title).trim(),
        description: String(b.description || ""),
        minBaseSalary: BigInt(Math.round(+b.minBaseSalary || 0)),
        maxBaseSalary: BigInt(Math.round(+b.maxBaseSalary || 0)),
        seniorityBase: BigInt(Math.round(+b.seniorityBase || 0)),
        attraction: BigInt(Math.round(+b.attraction || 0)),
        basePercent: split.basePercent,
        respPercent: split.respPercent,
        meritPercent: split.meritPercent,
      },
    });
    await audit(session, "CREATE", "GRADE", grade.id, `ایجاد سطح ${b.level}: ${b.title}`);
    return { grade: serializeGrade(grade, 0) };
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "grades:manage");
    const b = await req.json();
    if (!b.id) return Response.json({ error: "شناسه الزامی است." }, { status: 400 });
    const before = await db.jobGrade.findUnique({ where: { id: b.id } });
    if (!before) return Response.json({ error: "سطح یافت نشد." }, { status: 404 });
    const data: Record<string, unknown> = {};
    for (const f of ["title", "code", "description"]) if (b[f] !== undefined) data[f] = String(b[f]).trim();
    for (const f of ["minBaseSalary", "maxBaseSalary", "seniorityBase", "attraction"]) {
      if (b[f] !== undefined) data[f] = BigInt(Math.round(+b[f] || 0));
    }
    // درصدهای تفکیک — فقط وقتی هرکدام ارسال شده باشد (ارسال یکی = بازتعریف کل تفکیک)
    if (b.respPercent !== undefined || b.meritPercent !== undefined || b.basePercent !== undefined) {
      const split = parseSplitPercents(b);
      if ("error" in split) return Response.json({ error: split.error }, { status: 400 });
      data.basePercent = split.basePercent;
      data.respPercent = split.respPercent;
      data.meritPercent = split.meritPercent;
    }
    await db.jobGrade.update({ where: { id: b.id }, data });
    const after = await db.jobGrade.findUnique({ where: { id: b.id } });
    await audit(
      session,
      "UPDATE",
      "GRADE",
      b.id,
      `ویرایش سطح ${after?.level} (${after?.title})`,
      before ? { min: Number(before.minBaseSalary), max: Number(before.maxBaseSalary), sen: Number(before.seniorityBase), att: Number(before.attraction) } : null,
      { min: Number(after?.minBaseSalary), max: Number(after?.maxBaseSalary), sen: Number(after?.seniorityBase), att: Number(after?.attraction) }
    );
    return { grade: serializeGrade(after!, 0) };
  });
}

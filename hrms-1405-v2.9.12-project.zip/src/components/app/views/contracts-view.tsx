"use client";

// ============================================================
// ماژول قراردادها — قالب‌سازی با متغیرها + صدور با شماره سیستمی
// استانداردها: نسخه‌بندی قالب، اسنپ‌شات متن، چرخه وضعیت، چاپ A4
// ============================================================
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { FileSignature, Plus, Pencil, Trash2, Eye, Printer, Search, BookMarked, Sparkles, CheckCircle2, XCircle, Download, Layers } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { CONTRACT_DOC_TYPE_LABELS, CONTRACT_STATUS_LABELS, groupFa } from "@/lib/format";
import { toFaDigits, todayJalaliStr } from "@/lib/jalali";
import { printSections, downloadPrintDocument, type PrintSection } from "@/lib/print";
import { JalaliDatePicker } from "../jalali-datepicker";
import { NativeSelect } from "../native-select";

interface TemplateRow {
  id: string; title: string; contractType: string; body: string; notes: string;
  isActive: boolean; version: number; issuedCount: number; createdAt: string;
}
interface ContractRow {
  id: string; contractNumber: string; templateTitle: string; templateVersion: number;
  employeeId: string; employeeName: string; personnelCode: string; title: string;
  contractType: string; status: string; issueDateJ: string; startDateJ: string;
  endDateJ: string; signedDateJ: string; terminateDateJ: string; terminateReason: string;
  createdBy: string; createdAt: string; body: string;
}
interface EmployeeOption { id: string; fullName: string; personnelCode: string; contractStartJ: string }

const STATUS_BADGE: Record<string, string> = {
  DRAFT: "bg-slate-100 text-slate-600 hover:bg-slate-100",
  ISSUED: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  SIGNED: "bg-teal-100 text-teal-700 hover:bg-teal-100",
  ACTIVE: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  EXPIRED: "bg-slate-100 text-slate-500 hover:bg-slate-100",
  TERMINATED: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  VOIDED: "bg-slate-200 text-slate-500 hover:bg-slate-200",
};

const VARIABLE_CATALOG: { group: string; vars: { name: string; desc: string }[] }[] = [
  {
    group: "کارفرما",
    vars: [
      { name: "company_name", desc: "نام شرکت" },
      { name: "company_national_id", desc: "شناسه ملی" },
      { name: "company_sso_code", desc: "کد کارگاه" },
      { name: "company_tax_id", desc: "شناسه مالیاتی" },
      { name: "company_address", desc: "نشانی" },
    ],
  },
  {
    group: "کارمند",
    vars: [
      { name: "employee_name", desc: "نام کامل" },
      { name: "employee_father_name", desc: "نام پدر" },
      { name: "employee_national_id", desc: "کد ملی" },
      { name: "employee_personnel_code", desc: "کد پرسنلی" },
      { name: "employee_sso_number", desc: "شماره بیمه" },
      { name: "employee_birth_date", desc: "تاریخ تولد" },
      { name: "employee_job_title", desc: "عنوان شغل" },
      { name: "employee_grade", desc: "طبقه شغلی" },
      { name: "employee_marital_status", desc: "وضعیت تأهل" },
      { name: "employee_child_count", desc: "تعداد فرزند" },
      { name: "employee_mobile", desc: "موبایل" },
      { name: "employee_address", desc: "نشانی" },
      { name: "employee_hire_date", desc: "تاریخ استخدام" },
    ],
  },
  {
    group: "حقوق",
    vars: [
      { name: "base_salary_toman", desc: "حقوق پایه (تومان)" },
      { name: "base_salary_toman_words", desc: "حقوق پایه به حروف (تومان)" },
      { name: "base_salary_rial", desc: "حقوق پایه (ریال)" },
      { name: "base_salary_rial_words", desc: "حقوق پایه به حروف (ریال)" },
      { name: "overtime_hours", desc: "ساعت اضافه‌کاری" },
    ],
  },
  {
    group: "بیمه",
    vars: [
      { name: "supp_insurance_type", desc: "نوع بیمه تکمیلی" },
      { name: "supp_insured_count", desc: "افراد تحت پوشش" },
    ],
  },
  {
    group: "قرارداد",
    vars: [
      { name: "contract_number", desc: "شماره سیستمی" },
      { name: "contract_date", desc: "تاریخ صدور" },
      { name: "contract_start_date", desc: "شروع قرارداد" },
      { name: "contract_end_date", desc: "پایان قرارداد" },
      { name: "today_date", desc: "امروز" },
    ],
  },
];

export function ContractsView({ canEdit, canDelete }: { canEdit: boolean; canDelete?: boolean }) {
  const [tab, setTab] = useState("contracts");

  return (
    <div className="space-y-4">
      <Tabs value={tab} onValueChange={setTab} dir="rtl">
        <TabsList className="w-full max-w-md mb-4">
          <TabsTrigger value="contracts" className="flex-1 gap-1.5"><FileSignature className="w-4 h-4" /> قراردادها</TabsTrigger>
          <TabsTrigger value="templates" className="flex-1 gap-1.5"><BookMarked className="w-4 h-4" /> قالب‌ها</TabsTrigger>
        </TabsList>
        <TabsContent value="contracts">
          <ContractsList canEdit={canEdit} canDelete={canDelete} onGoTemplates={() => setTab("templates")} />
        </TabsContent>
        <TabsContent value="templates">
          <TemplatesList canEdit={canEdit} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ================= لیست قراردادها =================
function ContractsList({ canEdit, canDelete, onGoTemplates }: { canEdit: boolean; canDelete?: boolean; onGoTemplates: () => void }) {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [issueOpen, setIssueOpen] = useState(false);
  const [viewing, setViewing] = useState<ContractRow | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  // تأیید حذف (تک‌نفری یا گروهی)
  const [deleteDialog, setDeleteDialog] = useState<{ ids: string[]; labels: string[] } | null>(null);
  const { toast } = useToast();

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (status !== "all") p.set("status", status);
    return `/api/contracts?${p.toString()}`;
  }, [q, status]);

  const list = useApi<{ contracts: ContractRow[] }>(query, [q, status]);
  const templates = useApi<{ templates: TemplateRow[] }>("/api/contracts/templates");
  const employees = useApi<{ employees: EmployeeOption[] }>("/api/employees");

  const contracts = list.data?.contracts || [];

  // انتخاب گروهی
  const allSelected = contracts.length > 0 && contracts.every((c) => selected.has(c.id));
  const companyApi = useApi<{ company: { name: string } }>("/api/settings");
  const companyName = companyApi.data?.company?.name || "";
  function toggleAll() {
    setSelected(allSelected ? new Set() : new Set(contracts.map((c) => c.id)));
  }
  function toggleOne(id: string) {
    const next = new Set(selected);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelected(next);
  }
  const selectedContracts = contracts.filter((c) => selected.has(c.id));

  // ساخت بخش چاپی هر قرارداد (A4)
  function toPrintSection(c: ContractRow, companyName: string): PrintSection {
    return {
      docTitle: c.title,
      headerTitle: companyName || undefined,
      metaLtr: `شماره: ${c.contractNumber} — تاریخ: ${toFaDigits(c.issueDateJ)}`,
      body: c.body,
      signatures: [
        { title: "امضای کارفرما", name: companyName || "" },
        { title: "امضای کارمند", name: c.employeeName },
      ],
    };
  }

  function groupPrint() {
    if (selectedContracts.length === 0) {
      toast({ title: "حداقل یک قرارداد انتخاب کنید", variant: "destructive" });
      return;
    }
    printSections(
      selectedContracts.map((c) => toPrintSection(c, companyName)),
      `چاپ گروهی ${toFaDigits(selectedContracts.length)} قرارداد`,
    );
  }

  async function groupDownload() {
    if (selectedContracts.length === 0) {
      toast({ title: "حداقل یک قرارداد انتخاب کنید", variant: "destructive" });
      return;
    }
    await downloadPrintDocument(
      selectedContracts.map((c) => toPrintSection(c, companyName)),
      `قراردادهای صادرشده (${toFaDigits(selectedContracts.length)} مورد)`,
      `contracts-${todayJalaliStr().replace(/\//g, "-")}`,
    );
    toast({ title: "فایل دانلود شد", description: "سند چاپی A4 همه قراردادهای انتخاب‌شده در یک فایل HTML با فونت B Nazanin — قابل چاپ و ذخیره PDF." });
  }

  async function changeStatus(c: ContractRow, to: string) {
    try {
      await api(`/api/contracts/${c.id}`, { method: "PATCH", json: { status: to } });
      await list.refetch();
      toast({ title: `وضعیت قرارداد ${c.contractNumber} تغییر کرد`, description: `وضعیت جدید: ${CONTRACT_STATUS_LABELS[to]}` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input className="pr-9" placeholder="جستجو: شماره قرارداد، نام کارمند، عنوان..." value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-[170px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            {Object.entries(CONTRACT_STATUS_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
          </SelectContent>
        </Select>
        {selectedContracts.length > 0 && (
          <div className="flex items-center gap-2">
            <Badge className="bg-teal-100 text-teal-800 hover:bg-teal-100 h-9 px-3 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" /> {toFaDigits(selectedContracts.length)} قرارداد انتخاب‌شده
            </Badge>
            <Button variant="outline" className="gap-1.5" onClick={groupPrint}>
              <Printer className="w-4 h-4" /> چاپ گروهی
            </Button>
            <Button variant="outline" className="gap-1.5" onClick={groupDownload}>
              <Download className="w-4 h-4" /> دانلود گروهی
            </Button>
            {canDelete && (
              <Button variant="destructive" className="gap-1.5" onClick={() => setDeleteDialog({ ids: selectedContracts.map((c) => c.id), labels: selectedContracts.map((c) => c.contractNumber) })}>
                <Trash2 className="w-4 h-4" /> حذف گروهی
              </Button>
            )}
          </div>
        )}
        {canEdit && (
          <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => setIssueOpen(true)} disabled={(templates.data?.templates || []).length === 0}>
            <Plus className="w-4 h-4" /> صدور قرارداد
          </Button>
        )}
        {canEdit && (templates.data?.templates || []).length === 0 && (
          <Button variant="outline" className="gap-1.5" onClick={onGoTemplates}>
            <BookMarked className="w-4 h-4" /> ابتدا قالب بسازید
          </Button>
        )}
      </div>

      <Card className="rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          {list.loading ? (
            <div className="p-4 space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-12" />)}</div>
          ) : contracts.length === 0 ? (
            <div className="py-16 text-center">
              <FileSignature className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">قراردادی یافت نشد — با «صدور قرارداد» از قالب‌ها شروع کنید.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    <TableHead className="w-10 text-center">
                      <Checkbox checked={allSelected} onCheckedChange={toggleAll} aria-label="انتخاب همه" />
                    </TableHead>
                    <TableHead className="text-right">شماره سیستمی</TableHead>
                    <TableHead className="text-right">کارمند</TableHead>
                    <TableHead className="text-right">قالب / نسخه</TableHead>
                    <TableHead className="text-right">نوع</TableHead>
                    <TableHead className="text-center">تاریخ صدور</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    <TableHead className="text-center">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contracts.map((c) => (
                    <TableRow key={c.id} className={`hover:bg-teal-50/40 ${selected.has(c.id) ? "bg-teal-50/30" : ""}`}>
                      <TableCell className="text-center">
                        <Checkbox checked={selected.has(c.id)} onCheckedChange={() => toggleOne(c.id)} aria-label={`انتخاب ${c.contractNumber}`} />
                      </TableCell>
                      <TableCell className="tabular-nums text-xs font-mono" dir="ltr">{c.contractNumber}</TableCell>
                      <TableCell className="font-medium text-sm">
                        {c.employeeName}
                        <span className="block text-[11px] text-muted-foreground tabular-nums" dir="ltr">{c.personnelCode}</span>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {c.templateTitle || "—"}
                        <span className="block text-[10px]">نسخه {toFaDigits(c.templateVersion)}</span>
                      </TableCell>
                      <TableCell className="text-xs">{CONTRACT_DOC_TYPE_LABELS[c.contractType] || c.contractType}</TableCell>
                      <TableCell className="text-xs tabular-nums text-center">{toFaDigits(c.issueDateJ) || "—"}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={STATUS_BADGE[c.status] || ""}>{CONTRACT_STATUS_LABELS[c.status] || c.status}</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center gap-1">
                          <button className="p-1.5 rounded-lg hover:bg-teal-100 text-teal-600" title="مشاهده و چاپ" onClick={() => setViewing(c)}>
                            <Eye className="w-4 h-4" />
                          </button>
                          {canEdit && c.status === "ISSUED" && (
                            <button className="p-1.5 rounded-lg hover:bg-emerald-100 text-emerald-600" title="ثبت امضا" onClick={() => changeStatus(c, "SIGNED")}>
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                          )}
                          {canEdit && c.status === "SIGNED" && (
                            <button className="p-1.5 rounded-lg hover:bg-emerald-100 text-emerald-600" title="اجرایی کردن" onClick={() => changeStatus(c, "ACTIVE")}>
                              <CheckCircle2 className="w-4 h-4" />
                            </button>
                          )}
                          {canEdit && ["ISSUED", "SIGNED", "ACTIVE"].includes(c.status) && (
                            <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title="ابطال" onClick={() => changeStatus(c, "VOIDED")}>
                              <XCircle className="w-4 h-4" />
                            </button>
                          )}
                          {canDelete && (
                            <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title={`حذف قرارداد (فقط مدیر) — وضعیت: ${CONTRACT_STATUS_LABELS[c.status] || c.status}`} onClick={() => setDeleteDialog({ ids: [c.id], labels: [`${c.contractNumber} — ${c.employeeName}`] })}>
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {canEdit && (
        <IssueContractDialog
          open={issueOpen}
          onOpenChange={setIssueOpen}
          templates={templates.data?.templates || []}
          employees={employees.data?.employees || []}
          onIssued={() => { list.refetch(); toast({ title: "قرارداد صادر شد", description: "شماره سیستمی اختصاص یافت و در لاگ حسابرسی ثبت شد." }); }}
        />
      )}

      <ContractViewDialog contract={viewing} onClose={() => setViewing(null)} />

      {/* تأیید حذف قرارداد — فقط مدیر */}
      <DeleteContractsDialog
        target={deleteDialog}
        onClose={() => setDeleteDialog(null)}
        onDone={(count) => {
          setDeleteDialog(null);
          setSelected(new Set());
          list.refetch();
          toast({ title: `${toFaDigits(count)} قرارداد حذف شد`, description: "حذف کامل رکورد قرارداد — در لاگ حسابرسی ثبت گردید." });
        }}
      />
    </div>
  );
}

// ================= تأیید حذف قرارداد (فقط مدیر) =================
function DeleteContractsDialog({ target, onClose, onDone }: {
  target: { ids: string[]; labels: string[] } | null;
  onClose: () => void;
  onDone: (count: number) => void;
}) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);

  async function apply() {
    if (!target) return;
    setBusy(true);
    try {
      const d = await api<{ count: number }>("/api/contracts/bulk", {
        method: "POST",
        json: { action: "delete", ids: target.ids },
      });
      onDone(d.count);
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={!!target} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[30rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-rose-700">
            <Trash2 className="w-5 h-5" />
            حذف {target && target.ids.length > 1 ? `${toFaDigits(target.ids.length)} قرارداد` : "قرارداد"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs leading-5 text-rose-900">
            {target && (target.ids.length === 1
              ? <b dir="ltr">{target.labels[0]}</b>
              : <>{toFaDigits(target.ids.length)} قرارداد: <span dir="ltr">{target.labels.slice(0, 5).join(", ")}</span>{target.labels.length > 5 ? " و…" : ""}</>)}
            <p className="mt-1.5 font-medium">این عملیات غیرقابل بازگشت است!</p>
            <p className="mt-1">رکورد قرارداد با متن رندرشدهٔ آن برای همیشه حذف می‌شود. اگر ردپای رسمی مدنظرتان است، به‌جای حذف از «ابطال» استفاده کنید؛ حذف کامل هر وضعیت فقط برای مدیر سامانه فعال است.</p>
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={onClose} disabled={busy}>انصراف</Button>
          <Button variant="destructive" onClick={apply} disabled={busy} className="gap-1.5">
            {busy ? "..." : <><Trash2 className="w-4 h-4" /> حذف قطعی</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= صدور قرارداد =================
function IssueContractDialog({ open, onOpenChange, templates, employees, onIssued }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  templates: TemplateRow[];
  employees: EmployeeOption[];
  onIssued: () => void;
}) {
  const { toast } = useToast();
  const [templateId, setTemplateId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [issueDateJ, setIssueDateJ] = useState(todayJalaliStr());
  const [startDateJ, setStartDateJ] = useState("");
  const [endDateJ, setEndDateJ] = useState("");
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const selectedTemplate = templates.find((t) => t.id === templateId);
  const selectedEmployee = employees.find((e) => e.id === employeeId);

  async function makePreview() {
    if (!templateId || !employeeId) {
      toast({ title: "قالب و کارمند را انتخاب کنید", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const d = await api<{ preview: string }>("/api/contracts/preview", {
        method: "POST",
        json: { templateId, employeeId, issueDateJ, startDateJ, endDateJ },
      });
      setPreview(d.preview);
    } catch (e) {
      toast({ title: "خطا در پیش‌نمایش", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  async function issue() {
    setBusy(true);
    try {
      await api("/api/contracts", {
        method: "POST",
        json: { templateId, employeeId, issueDateJ, startDateJ, endDateJ },
      });
      onOpenChange(false);
      setPreview(null);
      setTemplateId("");
      setEmployeeId("");
      onIssued();
    } catch (e) {
      toast({ title: "خطا در صدور", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) setPreview(null); }}>
      <DialogContent className="sm:max-w-[67.2rem] max-h-[88vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-teal-600" /> صدور قرارداد از قالب
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">قالب / نوع قرارداد</Label>
            {/* سلکت بومی — ریشه‌کار باگ RTL رادیکس (پرش فوکوس بعد از انتخاب) */}
            <NativeSelect
              ariaLabel="قالب قرارداد"
              value={templateId}
              placeholder="— انتخاب قالب —"
              onChange={(v) => { setTemplateId(v); setPreview(null); }}
            >
              {templates.filter((t) => t.isActive).map((t) => (
                <option key={t.id} value={t.id}>{t.title} (نسخه {toFaDigits(t.version)})</option>
              ))}
            </NativeSelect>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">کارمند</Label>
            <NativeSelect
              ariaLabel="کارمند"
              value={employeeId}
              placeholder="— انتخاب کارمند —"
              onChange={(v) => { setEmployeeId(v); setPreview(null); }}
            >
              {employees.map((e) => (
                <option key={e.id} value={e.id}>{e.fullName} — {e.personnelCode}</option>
              ))}
            </NativeSelect>
            {employees.length === 0 && (
              <p className="text-[11px] text-rose-600">فهرست کارکنان خالی است — خطای سرویس کارکنان را بررسی کنید.</p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تاریخ صدور</Label>
            <JalaliDatePicker value={issueDateJ} onChange={(v) => { setIssueDateJ(v); setPreview(null); }} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">شروع قرارداد</Label>
              <JalaliDatePicker value={startDateJ || selectedEmployee?.contractStartJ || ""} onChange={(v) => { setStartDateJ(v); setPreview(null); }} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">پایان (اختیاری)</Label>
              <JalaliDatePicker value={endDateJ} onChange={(v) => { setEndDateJ(v); setPreview(null); }} />
            </div>
          </div>
        </div>

        {selectedTemplate && (
          <p className="text-[11px] text-muted-foreground bg-slate-50 rounded-lg p-3 leading-5">
            پس از صدور، شماره سیستمی یکتا (مثل CT-1405-00001) اختصاص می‌یابد، متن با داده‌های لحظه صدور اسنپ‌شات می‌شود
            (ویرایش بعدی قالب در متن قرارداد اثری ندارد) و رویداد در لاگ حسابرسی ثبت می‌گردد.
          </p>
        )}

        {preview !== null && (
          <div className="rounded-xl border border-teal-200 bg-teal-50/30">
            <p className="text-xs font-bold text-teal-800 px-4 pt-3">پیش‌نمایش متن رندرشده:</p>
            <div className="max-h-72 overflow-y-auto p-4 text-sm leading-7 whitespace-pre-wrap text-slate-800">{preview}</div>
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={makePreview} disabled={busy || !templateId || !employeeId} className="gap-1.5">
            <Eye className="w-4 h-4" /> پیش‌نمایش
          </Button>
          <Button onClick={issue} disabled={busy || !preview || !templateId || !employeeId} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            <FileSignature className="w-4 h-4" /> {busy ? "در حال صدور..." : "صدور نهایی"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= مشاهده/چاپ قرارداد =================
function ContractViewDialog({ contract, onClose }: { contract: ContractRow | null; onClose: () => void }) {
  const company = useApi<{ company: { name: string; nationalId: string; address: string } }>("/api/settings");
  if (!contract) return null;
  const companyName = company.data?.company?.name || "";

  return (
    <Dialog open={!!contract} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[67.2rem] max-h-[88vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap text-base">
            {contract.title}
            <Badge className={STATUS_BADGE[contract.status]}>{CONTRACT_STATUS_LABELS[contract.status]}</Badge>
            <span className="font-mono text-xs text-muted-foreground" dir="ltr">{contract.contractNumber}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs rounded-xl bg-slate-50 border border-slate-200 p-3">
          <KV label="کارمند" value={contract.employeeName} />
          <KV label="کد پرسنلی" value={toFaDigits(contract.personnelCode)} />
          <KV label="تاریخ صدور" value={toFaDigits(contract.issueDateJ) || "—"} />
          <KV label="قالب" value={`${contract.templateTitle || "—"} (نسخه ${toFaDigits(contract.templateVersion)})`} />
          <KV label="شروع" value={toFaDigits(contract.startDateJ) || "—"} />
          <KV label="پایان" value={contract.endDateJ ? toFaDigits(contract.endDateJ) : "نامحدود"} />
          <KV label="امضا" value={toFaDigits(contract.signedDateJ) || "—"} />
          <KV label="صادرکننده" value={contract.createdBy || "—"} />
        </div>

        {/* بدنه A4 — پیش‌نمایش داخل دیالوگ با همان استایل چاپ (B Nazanin ۱۲ / فاصله سطر ۱.۱۵) */}
        <div className="letter-body-font rounded-xl border border-slate-200 bg-white p-6 sm:p-8 text-[12pt] leading-[1.15] text-slate-800 whitespace-pre-wrap max-h-[46vh] overflow-y-auto">
          <div className="text-center border-b pb-4 mb-5">
            {companyName && <p className="font-bold text-teal-800">{companyName}</p>}
            <p className="font-bold mt-1">{contract.title}</p>
            <p className="text-[10pt] text-muted-foreground mt-1 tabular-nums" dir="ltr">شماره: {contract.contractNumber} — تاریخ: {toFaDigits(contract.issueDateJ)}</p>
          </div>
          {contract.body}
          <div className="border-t pt-6 mt-8 grid grid-cols-2 gap-8 text-center text-[11pt]">
            <div>
              <p className="mb-10 text-muted-foreground font-bold">امضای کارفرما</p>
              <p className="border-t border-dotted pt-1 text-muted-foreground">{companyName}</p>
            </div>
            <div>
              <p className="mb-10 text-muted-foreground font-bold">امضای کارمند</p>
              <p className="border-t border-dotted pt-1 text-muted-foreground">{contract.employeeName}</p>
            </div>
          </div>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>بستن</Button>
          <Button
            variant="outline"
            className="gap-1.5"
            onClick={() =>
              void downloadPrintDocument(
                [{
                  docTitle: contract.title,
                  headerTitle: companyName || undefined,
                  metaLtr: `شماره: ${contract.contractNumber} — تاریخ: ${toFaDigits(contract.issueDateJ)}`,
                  body: contract.body,
                  signatures: [
                    { title: "امضای کارفرما", name: companyName || "" },
                    { title: "امضای کارمند", name: contract.employeeName },
                  ],
                }],
                contract.title,
                `contract-${contract.contractNumber}`,
              )
            }
          >
            <Download className="w-4 h-4" /> دانلود
          </Button>
          <Button
            className="bg-teal-600 hover:bg-teal-700 gap-1.5"
            onClick={() =>
              printSections(
                [{
                  docTitle: contract.title,
                  headerTitle: companyName || undefined,
                  metaLtr: `شماره: ${contract.contractNumber} — تاریخ: ${toFaDigits(contract.issueDateJ)}`,
                  body: contract.body,
                  signatures: [
                    { title: "امضای کارفرما", name: companyName || "" },
                    { title: "امضای کارمند", name: contract.employeeName },
                  ],
                }],
                contract.title,
              )
            }
          >
            <Printer className="w-4 h-4" /> چاپ / PDF
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function KV({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className="font-medium mt-0.5 truncate">{value}</p>
    </div>
  );
}

// ================= مدیریت قالب‌ها =================
function TemplatesList({ canEdit }: { canEdit: boolean }) {
  const list = useApi<{ templates: TemplateRow[] }>("/api/contracts/templates");
  const [editing, setEditing] = useState<TemplateRow | null>(null);
  const [creating, setCreating] = useState(false);
  const { toast } = useToast();

  const templates = list.data?.templates || [];

  async function remove(t: TemplateRow) {
    try {
      await api(`/api/contracts/templates/${t.id}`, { method: "DELETE" });
      await list.refetch();
      toast({ title: "قالب حذف شد" });
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function toggleActive(t: TemplateRow) {
    try {
      await api(`/api/contracts/templates/${t.id}`, { method: "PATCH", json: { isActive: !t.isActive } });
      await list.refetch();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <p className="text-sm text-muted-foreground">
          قالب‌ها با متغیرهای <code className="bg-slate-100 rounded px-1 text-[11px]" dir="ltr">{"{{نام_متغیر}}"}</code> نوشته می‌شوند — هنگام صدور با داده کارمند پر می‌شوند.
        </p>
        {canEdit && (
          <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => setCreating(true)}>
            <Plus className="w-4 h-4" /> قالب جدید
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {list.loading && [0, 1, 2].map((i) => <Skeleton key={i} className="h-44 rounded-2xl" />)}
        {templates.map((t) => (
          <Card key={t.id} className="rounded-2xl flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2 flex-wrap">
                <BookMarked className="w-4 h-4 text-teal-600" />
                <span className="truncate">{t.title}</span>
                <Badge variant="outline" className="text-[10px]">نسخه {toFaDigits(t.version)}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex-1 space-y-3">
              <div className="flex gap-2 flex-wrap">
                <Badge className="bg-teal-50 text-teal-700 hover:bg-teal-50">{CONTRACT_DOC_TYPE_LABELS[t.contractType]}</Badge>
                <Badge className={t.isActive ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                  {t.isActive ? "فعال" : "غیرفعال"}
                </Badge>
                <Badge variant="outline">{toFaDigits(t.issuedCount)} صدور</Badge>
              </div>
              <p className="text-[11px] text-muted-foreground leading-5 line-clamp-3">{t.body.slice(0, 160)}…</p>
              {canEdit && (
                <div className="flex gap-1.5 pt-1">
                  <Button size="sm" variant="outline" className="gap-1 h-8" onClick={() => setEditing(t)}><Pencil className="w-3.5 h-3.5" /> ویرایش</Button>
                  <Button size="sm" variant="outline" className="gap-1 h-8" onClick={() => toggleActive(t)}>{t.isActive ? "غیرفعال" : "فعال"}</Button>
                  <Button size="sm" variant="destructive" className="gap-1 h-8" onClick={() => remove(t)} disabled={t.issuedCount > 0}><Trash2 className="w-3.5 h-3.5" /></Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {(canEdit && (creating || editing)) && (
        <TemplateEditor
          template={editing}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={() => { list.refetch(); setCreating(false); setEditing(null); toast({ title: editing ? "قالب به‌روزرسانی شد" : "قالب جدید ساخته شد", description: editing ? "نسخه قالب یک واحد افزایش یافت." : "آماده صدور قرارداد است." }); }}
        />
      )}
    </div>
  );
}

// ================= ویرایشگر قالب =================
function TemplateEditor({ template, onClose, onSaved }: {
  template: TemplateRow | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [title, setTitle] = useState(template?.title || "");
  const [contractType, setContractType] = useState(template?.contractType || "EMPLOYMENT");
  const [body, setBody] = useState(template?.body || DEFAULT_TEMPLATE);
  const [notes, setNotes] = useState(template?.notes || "");
  const [saving, setSaving] = useState(false);
  const [cursor, setCursor] = useState(0);

  function insertVar(name: string) {
    const tag = `{{${name}}}`;
    const next = body.slice(0, cursor) + tag + body.slice(cursor);
    setBody(next);
  }

  async function save() {
    if (!title.trim()) {
      toast({ title: "عنوان قالب الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (template) {
        await api(`/api/contracts/templates/${template.id}`, { method: "PATCH", json: { title, contractType, body, notes } });
      } else {
        await api("/api/contracts/templates", { method: "POST", json: { title, contractType, body, notes } });
      }
      onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[78.4rem] max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>{template ? `ویرایش قالب — ${template.title}` : "قالب قرارداد جدید"}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان قالب</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="قرارداد استخدام رسمی" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نوع قرارداد</Label>
            <Select value={contractType} onValueChange={setContractType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(CONTRACT_DOC_TYPE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* متغیرها */}
        <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3">
          <p className="text-xs font-bold text-slate-700 mb-2">متغیرها — کلیک = درج در محل نشانگر متن:</p>
          <div className="max-h-36 overflow-y-auto space-y-2">
            {VARIABLE_CATALOG.map((g) => (
              <div key={g.group}>
                <p className="text-[10px] text-muted-foreground mb-1">{g.group}:</p>
                <div className="flex flex-wrap gap-1.5">
                  {g.vars.map((v) => (
                    <button
                      key={v.name}
                      type="button"
                      title={v.desc}
                      onClick={() => insertVar(v.name)}
                      className="text-[10px] font-mono bg-white border border-slate-200 hover:border-teal-400 hover:bg-teal-50 rounded-md px-1.5 py-0.5 transition-colors"
                      dir="ltr"
                    >
                      {v.name}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs">متن قالب (جاهای خالی با متغیرها پر می‌شوند)</Label>
          <Textarea
            dir="rtl"
            className="min-h-[300px] text-[13px] leading-8 font-normal"
            value={body}
            onChange={(e) => setBody(e.target.value)}
            onSelect={(e) => setCursor((e.target as HTMLTextAreaElement).selectionStart || 0)}
            placeholder="متن قرارداد..."
          />
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs">یادداشت داخلی (اختیاری)</Label>
          <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="مثلاً: بازبینی حقوقی شده توسط ..." />
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">
            {saving ? "در حال ذخیره..." : template ? "ذخیره (نسخه جدید)" : "ایجاد قالب"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

const DEFAULT_TEMPLATE = `قرارداد استخدام

این قرارداد به موجب مواد ۲ تا ۱۵ قانون کار جمهوری اسلامی ایران و به استناد ماده ۱۰ همان قانون، بین شرکت {{company_name}} (شناسه ملی: {{company_national_id}}) به نشانی {{company_address}} به‌عنوان کارفرما و خانم/آقای {{employee_name}} فرزند {{employee_father_name}} به شماره ملی {{employee_national_id}} به‌عنوان کارکنان در تاریخ {{contract_date}} منعقد گردید و مشروط به مفاد ذیل است:

ماده ۱ — موضوع قرارداد
انجام وظایف شغلی «{{employee_job_title}}» در طبقه {{employee_grade}} طبق شرح شغل مصوب و دستورالعمل‌های سازمانی.

ماده ۲ — مدت قرارداد
قرارداد از تاریخ {{contract_start_date}} لغایت {{contract_end_date}} برقرار است و دوره آزمایشی آن مطابق ماده ۱۱ قانون کار حداکثر یک ماه از تاریخ شروع می‌باشد.

ماده ۳ — حقوق و مزایا
حقوق پایه ماهانه مبلغ {{base_salary_toman}} تومان به حروف {{base_salary_toman_words}} به‌علاوه مزایای قانونی شامل حق مسکن، بن کارگری، حق اولاد و حق سنوات طبق بخشنامه مزد سالانه خواهد بود. اضافه‌کاری مطابق ماده ۵۹ قانون کار با ۴۰٪ اضافه بر مزد ساعتی محاسبه و پرداخت می‌شود.

ماده ۴ — بیمه
کارفرما موظف است کارکنان را از تاریخ شروع به کار نزد تأمین اجتماعی (شماره بیمه: {{employee_sso_number}}) بیمه نماید. بیمه تکمیلی: {{supp_insurance_type}} شامل {{supp_insured_count}} نفر تحت پوشش.

ماده ۵ — تعهدات طرفین
کارکنان متعهد به رعایت انضباط سازمانی، محرمانگی اطلاعات و مقررات ایمنی می‌باشد و کارفرما متعهد به پرداخت به‌موقع حقوق و ارائه شرایط امن کاری است.

ماده ۶ — فسخ قرارداد
فسخ این قرارداد مطابق مواد ۲۱ و ۲۷ قانون کار و با رعایت مواعد قانونی امکان‌پذیر است.

این قرارداد در ۶ ماده و ۲ نسخه تنظیم و پس از قرائت به امضای طرفین رسید.

شماره سیستمی: {{contract_number}}
تاریخ صدور: {{contract_date}}`;

// ============================================================
// Seed — داده‌های پایه سامانه منابع انسانی ۱۴۰۵
// اجرا: bun prisma/seed.ts
//
// از نسخه ۲.۱.۰: **هیچ داده پرسنلی نمونه ایجاد نمی‌شود**
//   (کارمند، فیش حقوقی، قرارداد، نامه، درخواست، سند — هیچ‌کدام).
// آنچه ایجاد می‌شود فقط پایه قابل استفاده سامانه است:
//   • پارامترهای قانونی ۱۴۰۵ (پله‌های مالیاتی، بیمه، مزایا)
//   • دپارتمان‌های نمونه سازمانی (بدون مدیر/عضو)
//   • طبقه‌بندی ۷ سطحی مشاغل
//   • کاربران نقش‌محور برای آزمایش دسترسی‌ها (بدون پرونده پرسنلی)
//   • یک رکورد راه‌اندازی در لاگ حسابرسی
// کارکنان واقعی از «کارکنان ← افزودن» یا ایمپورت اکسل وارد می‌شوند.
// ============================================================
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
import { LEGAL_DEFAULTS_1405 } from "../src/lib/payroll/engine";

const db = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

const R = (toman: number) => BigInt(Math.round(toman * 10)); // تومان → ریال

async function main() {
  console.log("🚿 پاک‌سازی دیتابیس...");
  await db.auditLog.deleteMany();
  await db.payslip.deleteMany();
  await db.payrollPeriod.deleteMany();
  await db.document.deleteMany();
  await db.leaveRequest.deleteMany();
  await db.advanceRequest.deleteMany();
  await db.user.deleteMany();
  await db.employeeDepartment.deleteMany();
  await db.employee.deleteMany();
  await db.jobGrade.deleteMany();
  await db.department.deleteMany();
  await db.taxBracket.deleteMany();
  await db.systemSetting.deleteMany();

  // ================= پارامترهای قانونی =================
  console.log("⚙️ پارامترهای قانونی ۱۴۰۵...");
  for (const b of LEGAL_DEFAULTS_1405.taxBrackets) {
    await db.taxBracket.create({
      data: {
        year: 1405,
        sortOrder: b.sortOrder,
        lowerLimit: BigInt(b.lowerLimit),
        upperLimit: b.upperLimit === null ? null : BigInt(b.upperLimit),
        rate: b.rate,
      },
    });
  }
  const { taxBrackets: _tb, ...legalRest } = LEGAL_DEFAULTS_1405;
  await db.systemSetting.create({ data: { key: "legal_params", value: JSON.stringify(legalRest) } });
  await db.systemSetting.create({ data: { key: "display", value: JSON.stringify({ unit: "TOMAN" }) } });
  await db.systemSetting.create({
    data: {
      key: "company",
      value: JSON.stringify({
        name: "شرکت فناوران داده پارس",
        nationalId: "10101234567",
        ssoCode: "22-104578-0",
        taxId: "41111234567890",
        address: "تهران، خیابان ولیعصر، برج فناوری، طبقه ۱۲",
      }),
    },
  });

  // ================= دپارتمان‌ها =================
  console.log("🏢 دپارتمان‌های نمونه سازمانی...");
  const deptData = [
    { code: "D100", name: "مدیریت ارشد", costCenter: "CC-100", parent: null, desc: "هیئت‌مدیره و مدیرعامل" },
    { code: "D200", name: "منابع انسانی", costCenter: "CC-210", parent: null, desc: "جذب، آموزش و رفاه کارکنان" },
    { code: "D300", name: "مالی و حسابداری", costCenter: "CC-310", parent: null, desc: "حسابداری، خزانه و حقوق و دستمزد" },
    { code: "D400", name: "فناوری اطلاعات", costCenter: "CC-410", parent: null, desc: "توسعه محصول و زیرساخت فنی" },
    { code: "D410", name: "توسعه نرم‌افزار", costCenter: "CC-411", parent: "D400", desc: "تیم مهندسی نرم‌افزار" },
    { code: "D420", name: "زیرساخت و شبکه", costCenter: "CC-412", parent: "D400", desc: "عملیات و امنیت شبکه" },
    { code: "D500", name: "فروش و بازاریابی", costCenter: "CC-510", parent: null, desc: "توسعه بازار و فروش سازمانی" },
  ];
  const deptIds: Record<string, string> = {};
  for (const d of deptData) {
    const row = await db.department.create({
      data: {
        code: d.code,
        name: d.name,
        costCenterCode: d.costCenter,
        description: d.desc,
        parentId: d.parent ? deptIds[d.parent] : null,
      },
    });
    deptIds[d.code] = row.id;
  }

  // ================= طبقه‌بندی ۷ سطحی =================
  console.log("📊 طبقه‌بندی مشاغل (۷ سطح)...");
  const gradesData = [
    { level: 1, code: "L1", title: "تازه‌کار / کارآموز", min: R(17_000_000), max: R(25_000_000), sen: R(500_001), att: R(0), desc: "شروع مسیر حرفه‌ای — زیر نظر منتور" },
    { level: 2, code: "L2", title: "جونیور (کارشناس کمکی)", min: R(25_000_000), max: R(40_000_000), sen: R(600_000), att: R(2_000_000), desc: "اجرای مستقل کارهای استاندارد" },
    { level: 3, code: "L3", title: "میان‌رده (کارشناس)", min: R(40_000_000), max: R(60_000_000), sen: R(800_000), att: R(3_000_000), desc: "کارشناس تمام‌عیار با مالکیت وظایف" },
    { level: 4, code: "L4", title: "ارشد (کارشناس ارشد)", min: R(60_000_000), max: R(90_000_000), sen: R(1_000_000), att: R(4_000_000), desc: "راهبری فنی و منتورینگ" },
    { level: 5, code: "L5", title: "سرپرست / متخصص ارشد", min: R(90_000_000), max: R(130_000_000), sen: R(1_200_000), att: R(5_000_000), desc: "رهبری تیم کوچک / تخصص کمیاب" },
    { level: 6, code: "L6", title: "مدیر (دپارتمان)", min: R(130_000_000), max: R(200_000_000), sen: R(1_500_000), att: R(8_000_000), desc: "مدیریت دپارتمان و بودجه" },
    { level: 7, code: "L7", title: "مدیر ارشد سازمانی", min: R(200_000_000), max: R(400_000_000), sen: R(2_000_000), att: R(15_000_000), desc: "معاون / مدیرعامل" },
  ];
  for (const g of gradesData) {
    await db.jobGrade.create({
      data: {
        level: g.level, code: g.code, title: g.title,
        minBaseSalary: g.min, maxBaseSalary: g.max,
        seniorityBase: g.sen, attraction: g.att, description: g.desc,
      },
    });
  }

  // ================= کاربران نقش‌محور =================
  // حساب‌های آزمایشی برای بررسی دسترسی نقش‌ها — بدون پرونده پرسنلی.
  // نام‌ها عمومی‌اند تا هیچ اطلاعات پرسنلی وارد دیتابیس نشود.
  console.log("🔑 کاربران نقش‌محور (بدون پرونده پرسنلی)...");
  const usersData = [
    { username: "admin", password: "admin123", fullName: "مدیر کل سیستم", role: "SUPER_ADMIN" },
    { username: "hr", password: "hr123", fullName: "کارشناس منابع انسانی", role: "HR_MANAGER" },
    { username: "payroll", password: "pay123", fullName: "کارشناس حقوق و دستمزد", role: "PAYROLL_OFFICER" },
    { username: "dept", password: "dept123", fullName: "مدیر دپارتمان", role: "DEPT_MANAGER" },
    { username: "emp", password: "emp123", fullName: "کارمند پورتال", role: "EMPLOYEE" },
    { username: "edari", password: "edari123", fullName: "کارشناس اداری", role: "ADMIN_EXPERT" },
  ];
  for (const u of usersData) {
    await db.user.create({
      data: { username: u.username, passwordHash: hashPassword(u.password), fullName: u.fullName, role: u.role },
    });
  }

  // ================= اطلاعیه «تازه‌های نسخه» (پاپ‌آپ اولین ورود) =================
  // نسخه ۲.۷.۰ — برای همه کاربران فعال؛ هر کاربر پس از «متوجه شدم» دیگر نمی‌بیند
  await db.systemSetting.upsert({
    where: { key: "changelog" },
    update: {},
    create: {
      key: "changelog",
      value: JSON.stringify({
        version: "2.7.0",
        title: "تازه‌های نسخه ۲.۷.۰",
        enabled: true,
        targetAll: true,
        roles: [],
        usernames: [],
        updatedAt: new Date().toISOString(),
        items: [
          { tag: "NEW", title: "تفکیک حقوق هر سطح", desc: "در «طبقه‌بندی مشاغل» تعیین کنید چند درصد حقوق ماهانه هر سطح به حقوق پایه، حق مسولیت و شایستگی برود — اضافه‌کاری، مأموریت و فوق‌العاده‌ها فقط از حقوق پایه محاسبه می‌شوند." },
          { tag: "NEW", title: "امضای نامه در کارتابل امضاکننده", desc: "امضاکنندگان مجاز را از فهرست نفرات (کاربران) انتخاب کنید؛ نامه دستی پس از مراحل تأیید به کارتابل خود امضاکننده می‌رود و خودش امضای دیجیتال را صادر می‌کند." },
          { tag: "NEW", title: "پاپ‌آپ «تازه‌های نسخه»", desc: "همین پنجره! آخرین تغییرات محصول را از «تنظیمات ← اطلاعیه نسخه» مدیریت کنید و تعیین کنید کدام نقش‌ها/کاربران آن را ببینند." },
          { tag: "IMPROVED", title: "دکمه آپدیت در پنل", desc: "نشان وضعیت نسخه در نوار بالا — بررسی خودکار نسخه جدید از گیت‌هاب هر ۲ روز + ارتقای یک‌کلیکی با پایش لاگ زنده." },
          { tag: "IMPROVED", title: "نسخه نرم‌افزار در فوتر و صفحه ورود", desc: "نسخه نصب‌شده همیشه جلوی چشم است." },
        ],
      }),
    },
  });

  // ================= لاگ راه‌اندازی =================
  await db.auditLog.create({
    data: {
      userName: "system",
      action: "CREATE",
      entity: "SYSTEM",
      summary: "راه‌اندازی اولیه سامانه و پارامترهای قانونی ۱۴۰۵ — بدون داده پرسنلی",
      after: JSON.stringify({ version: "2.1.0", personnelFree: true }),
    },
  });

  const counts = {
    employees: await db.employee.count(),
    departments: await db.department.count(),
    grades: await db.jobGrade.count(),
    periods: await db.payrollPeriod.count(),
    payslips: await db.payslip.count(),
    documents: await db.document.count(),
    users: await db.user.count(),
    auditLogs: await db.auditLog.count(),
  };
  console.log("✅ Seed پایه کامل شد (بدون داده پرسنلی):", counts);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

"use client";

// ============================================================
// دکمه آپدیت پنل — وضعیت نسخه + اجرای به‌روزرسانی
//  • وضعیت خودکار: هر ورود /api/system/version (کش سرور ۲ روز) صدا زده می‌شود
//  • نشان کهربایی وقتی نسخه جدیدی از گیت‌هاب موجود باشد — همه کاربران می‌بینند
//  • اجرای به‌روزرسانی: settings:manage → hrms update --latest --yes (جدا از سرویس)
//    با پایش لاگ زنده و بازگشت خودکار وقتی سرویس با نسخه جدید بالا آمد
// ============================================================
import { useCallback, useEffect, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Download, ArrowUpCircle, CheckCircle2, AlertTriangle, Terminal, ExternalLink } from "lucide-react";
import { api } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";
import { formatDateJ } from "@/lib/jalali";

interface VersionInfo {
  current: string;
  latest: string | null;
  updateAvailable: boolean;
  checkedAt: string | null;
  notes: string;
  url: string;
  checkError: string | null;
}

interface UpdateState {
  state: { startedAt: string; targetVersion: string; startedBy: string; running: boolean; finishedAt?: string } | null;
  log: string;
}

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

export function UpdateButton({ canManage }: { canManage: boolean }) {
  const [open, setOpen] = useState(false);
  const [info, setInfo] = useState<VersionInfo | null>(null);
  const [checking, setChecking] = useState(false);
  const [starting, setStarting] = useState(false);
  const [running, setRunning] = useState(false);
  const [log, setLog] = useState("");
  const [done, setDone] = useState<null | { from: string; to: string }>(null);
  const [error, setError] = useState("");
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const logRef = useRef<HTMLPreElement | null>(null);

  const load = useCallback(async (force = false) => {
    setChecking(true);
    try {
      const d = await api<VersionInfo>(`/api/system/version${force ? "?force=1" : ""}`);
      setInfo(d);
      setError(d.checkError && !d.latest ? d.checkError : "");
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در دریافت وضعیت نسخه");
    } finally {
      setChecking(false);
    }
  }, []);

  // چک اولیه هنگام مانت شدن — وضعیت کش‌شده سرور (TTL ۲ روز)
  useEffect(() => {
    void load();
  }, [load]);

  // اسکرول لاگ به پایین
  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [log]);

  const stopPoll = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }, []);
  useEffect(() => stopPoll, [stopPoll]);

  // پایش پیشرفت: لاگ زنده + وقتی نسخه سرور عوض شد → موفق
  const startPolling = useCallback(
    (fromVersion: string) => {
      setRunning(true);
      let ticks = 0;
      stopPoll();
      pollRef.current = setInterval(async () => {
        ticks += 1;
        try {
          const st = await api<UpdateState>("/api/system/update");
          setLog(st.log || "");
          const v = await api<VersionInfo>("/api/system/version");
          if (v.current && fromVersion && cmpVersion(v.current, fromVersion) > 0) {
            // سرویس با نسخه جدید بالا آمده است
            setDone({ from: fromVersion, to: v.current });
            setInfo(v);
            setRunning(false);
            stopPoll();
            return;
          }
          setInfo(v);
        } catch {
          /* سرویس ری‌استارت است — ادامه پایش */
        }
        // سقف پایش: ۱۵ دقیقه
        if (ticks > 150) {
          setRunning(false);
          stopPoll();
          setError("پایش به‌روزرسانی متوقف شد — وضعیت را با «بررسی مجدد» چک کنید یا لاگ سرور را ببینید.");
        }
      }, 6000);
    },
    [stopPoll]
  );

  async function runUpdate() {
    if (!info?.latest) return;
    if (!confirm(`به‌روزرسانی به نسخه ${info.latest} شروع شود؟\n\n• از دیتابیس به‌صورت خودکار پشتیبان گرفته می‌شود\n• عملیات چند دقیقه طول می‌کشد\n• سرویس در پایان خودکار ری‌استارت می‌شود و صفحه از نو بارگذاری می‌شود`)) return;
    setStarting(true);
    setError("");
    setDone(null);
    try {
      await api("/api/system/update", { method: "POST", json: { version: info.latest } });
      setRunning(true);
      startPolling(info.current || "");
      // لاگ اولیه را فوراً بخوان
      try {
        const st = await api<UpdateState>("/api/system/update");
        setLog(st.log || "در حال شروع به‌روزرسانی…");
      } catch { /* noop */ }
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در شروع به‌روزرسانی");
      setRunning(false);
    } finally {
      setStarting(false);
    }
  }

  const hasUpdate = !!info?.updateAvailable;
  const vFa = (v?: string | null) => toFaDigits(v || "—");

  return (
    <>
      <button
        className={`relative p-2 rounded-lg transition-colors ${hasUpdate ? "text-amber-600 hover:text-amber-700 hover:bg-amber-50 animate-none" : "text-slate-500 hover:text-teal-700 hover:bg-teal-50"}`}
        onClick={() => { setOpen(true); if (!running && !done) void load(true); }}
        title={hasUpdate ? `نسخه جدید ${vFa(info?.latest)} موجود است — برای جزئیات کلیک کنید` : "وضعیت نسخه و به‌روزرسانی"}
        aria-label="وضعیت نسخه و به‌روزرسانی"
      >
        <RefreshCw className={`w-5 h-5 ${checking || running ? "animate-spin" : ""}`} />
        {hasUpdate && !done && (
          <span className="absolute -top-0.5 -left-0.5 w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" aria-hidden="true" />
        )}
      </button>

      <Dialog open={open} onOpenChange={(v) => !v && setOpen(v)}>
        <DialogContent className="sm:max-w-[36rem] max-h-[88vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-base">
              <ArrowUpCircle className="w-5 h-5 text-teal-600" />
              وضعیت نسخه و به‌روزرسانی سامانه
            </DialogTitle>
          </DialogHeader>

          {done ? (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/70 p-4 text-sm text-emerald-800 space-y-2">
              <p className="font-bold flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" /> به‌روزرسانی کامل شد
              </p>
              <p className="leading-6">
                نسخه سامانه از <b>{vFa(done.from)}</b> به <b>{vFa(done.to)}</b> ارتقا یافت و سرویس با نسخه جدید بالا آمد.
              </p>
              <Button onClick={() => window.location.reload()} className="bg-emerald-600 hover:bg-emerald-700 gap-1.5">
                بارگذاری مجدد سامانه
              </Button>
            </div>
          ) : (
            <>
              {/* وضعیت فعلی */}
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl border bg-slate-50/60 p-3.5">
                  <p className="text-[11px] text-muted-foreground">نسخه نصب‌شده</p>
                  <p className="text-lg font-black tabular-nums text-slate-800 mt-1" dir="ltr">{info?.current || "—"}</p>
                  {info?.current && <p className="text-[10px] text-muted-foreground mt-0.5">{vFa(info.current)}</p>}
                </div>
                <div className={`rounded-xl border p-3.5 ${hasUpdate ? "border-amber-200 bg-amber-50/60" : "border-emerald-200 bg-emerald-50/50"}`}>
                  <p className="text-[11px] text-muted-foreground flex items-center gap-1">آخرین نسخه گیت‌هاب {info?.checkedAt && <span className="text-[9px]">({formatDateJ(info.checkedAt.slice(0, 10).replace(/-/g, "/"), true)})</span>}</p>
                  {info?.latest ? (
                    <>
                      <p className={`text-lg font-black tabular-nums mt-1 ${hasUpdate ? "text-amber-700" : "text-emerald-700"}`} dir="ltr">{info.latest}</p>
                      {hasUpdate ? (
                        <Badge className="bg-amber-500 text-white hover:bg-amber-500 text-[10px] mt-1">نسخه جدید موجود است</Badge>
                      ) : (
                        <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 text-[10px] mt-1">به‌روز هستید ✓</Badge>
                      )}
                    </>
                  ) : (
                    <p className="text-sm text-muted-foreground mt-2">{checking ? "در حال بررسی…" : "دریافت نشد"}</p>
                  )}
                </div>
              </div>

              {/* یادداشت انتشار */}
              {hasUpdate && info?.notes && (
                <div className="rounded-xl border bg-white p-3.5">
                  <p className="text-xs font-bold text-slate-700 mb-2">تازه‌های نسخه {vFa(info.latest)}</p>
                  <pre className="text-[11px] text-muted-foreground leading-6 whitespace-pre-wrap font-sans max-h-40 overflow-y-auto" dir="rtl">{info.notes}</pre>
                  {info.url && (
                    <a href={info.url} target="_blank" rel="noreferrer" className="text-[11px] text-teal-700 hover:underline inline-flex items-center gap-1 mt-2">
                      <ExternalLink className="w-3 h-3" /> صفحه انتشار در گیت‌هاب
                    </a>
                  )}
                </div>
              )}

              {/* اجرای به‌روزرسانی */}
              {running && (
                <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-3.5 space-y-2">
                  <p className="text-xs font-bold text-sky-800 flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 animate-spin" /> به‌روزرسانی در حال اجراست…
                  </p>
                  <p className="text-[11px] text-sky-700 leading-5">
                    بسته‌ها نصب و سامانه بیلد می‌شود؛ در پایان سرویس خودکار ری‌استارت می‌شود و این پنجره وضعیت را به‌روز می‌کند. صفحه را نبندید.
                  </p>
                  {log && (
                    <pre ref={logRef} className="text-[10px] leading-5 bg-slate-900 text-teal-200 rounded-lg p-3 max-h-44 overflow-y-auto whitespace-pre-wrap" dir="ltr">{log}</pre>
                  )}
                </div>
              )}

              {error && (
                <p className="text-xs text-rose-700 flex gap-2 items-start leading-6 rounded-lg border border-rose-200 bg-rose-50/60 p-3">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" /> {error}
                </p>
              )}

              {!running && (
                <div className="flex items-center gap-2 flex-wrap">
                  {canManage ? (
                    hasUpdate ? (
                      <Button onClick={runUpdate} disabled={starting} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
                        <Download className="w-4 h-4" /> {starting ? "در حال شروع…" : `به‌روزرسانی به نسخه ${vFa(info?.latest)}`}
                      </Button>
                    ) : (
                      <Button onClick={() => void load(true)} disabled={checking} variant="outline" className="gap-1.5">
                        <RefreshCw className={`w-4 h-4 ${checking ? "animate-spin" : ""}`} /> {checking ? "در حال بررسی…" : "بررسی مجدد از گیت‌هاب"}
                      </Button>
                    )
                  ) : hasUpdate ? (
                    <p className="text-xs text-muted-foreground leading-6">
                      نسخه جدید <b className="text-amber-700">{vFa(info?.latest)}</b> منتشر شده است — برای ارتقای سامانه با مدیر سامانه (تنظیمات ← به‌روزرسانی) هماهنگ کنید.
                    </p>
                  ) : null}
                  {!canManage && !hasUpdate && (
                    <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5" /> ارتقای سرور با فرمان <code className="font-mono bg-slate-100 rounded px-1" dir="ltr">hrms update</code>
                    </p>
                  )}
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

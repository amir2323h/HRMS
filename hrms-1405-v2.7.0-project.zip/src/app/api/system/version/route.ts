import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";

// ============================================================
// نسخه نصب‌شده و آخرین نسخه گیت‌هاب — مبنای «دکمه آپدیت پنل»
//  GET /api/system/version         → وضعیت کش‌شده (چک هر ۲ روز)
//  GET /api/system/version?force=1 → چک همین حالا (دکمه «بررسی مجدد»)
//
// نسخه جاری: env APP_VERSION (نصب‌کننده در .env/systemd می‌نویسد)
// آخرین نسخه: api.github.com/repos/amir2323h/HRMS/releases — کش در
// SystemSetting «update_check» با TTL ۲ روز؛ آفلاین = آخرین کش معتبر
// ============================================================

const GITHUB_API = "https://api.github.com/repos/amir2323h/HRMS/releases?per_page=15";
const CHECK_TTL_MS = 2 * 24 * 60 * 60 * 1000; // ۲ روز

interface UpdateCheckCache {
  checkedAt: string; // ISO
  latest: string;
  latestAt: string; // ISO تاریخ انتشار
  notes: string; // متن یادداشت انتشار (خلاصه)
  url: string; // نشانی انتشار
  error?: string; // آخرین خطای شبکه (اگر_latest خالی نباشد نادیده گرفته می‌شود)
}

/** مقایسه نسخه‌های x.y.z — درست نسبت به عددی هر جزء */
function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

/** فراخوانی گیت‌هاب با مهلت ۸ ثانیه — نسخه پایدار اول (غیر prerelease/draft) */
async function fetchLatestRelease(): Promise<UpdateCheckCache | null> {
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(GITHUB_API, {
      headers: { Accept: "application/vnd.github+json", "User-Agent": "hrms-update-check" },
      signal: ctrl.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (!res.ok) return null;
    const releases = (await res.json()) as {
      tag_name?: string; name?: string; draft?: boolean; prerelease?: boolean;
      published_at?: string; html_url?: string; body?: string;
    }[];
    const stable = releases.find((r) => !r.draft && !r.prerelease) || releases[0];
    if (!stable) return null;
    const ver = String(stable.tag_name || stable.name || "").replace(/^[vV]/, "").trim();
    if (!/^\d+(\.\d+)*$/.test(ver)) return null;
    const notes = String(stable.body || "")
      .replace(/\r\n/g, "\n")
      // خلاصه‌سازی: ۱۲۰۰ نویسه + حذف مارک‌داون سنگین
      .replace(/#{1,6}\s*/g, "")
      .replace(/\*\*/g, "")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean)
      .slice(0, 30)
      .join("\n")
      .slice(0, 1200);
    return {
      checkedAt: new Date().toISOString(),
      latest: ver,
      latestAt: stable.published_at || "",
      notes,
      url: stable.html_url || "",
    };
  } catch {
    return null;
  }
}

async function readCache(): Promise<UpdateCheckCache | null> {
  const row = await db.systemSetting.findUnique({ where: { key: "update_check" } });
  if (!row) return null;
  try {
    return JSON.parse(row.value) as UpdateCheckCache;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req); // هر کاربر واردشده — برای فوتر/نشان نسخه جدید
    const force = new URL(req.url).searchParams.get("force") === "1";
    const current = (process.env.APP_VERSION || "").trim();

    let cache = await readCache();
    const age = cache ? Date.now() - new Date(cache.checkedAt).getTime() : Infinity;
    // چک خودکار هر ۲ روز (یا با force) — خطای شبکه = حفظ آخرین کش معتبر
    if (force || !cache || age > CHECK_TTL_MS) {
      const fresh = await fetchLatestRelease();
      if (fresh) {
        cache = fresh;
        await db.systemSetting.upsert({
          where: { key: "update_check" },
          update: { value: JSON.stringify(fresh) },
          create: { key: "update_check", value: JSON.stringify(fresh) },
        });
      } else if (!cache) {
        const empty: UpdateCheckCache = { checkedAt: new Date().toISOString(), latest: "", latestAt: "", notes: "", url: "", error: "دریافت فهرست نسخه‌ها از گیت‌هاب ناموفق بود" };
        cache = empty;
      }
    }

    const latest = cache?.latest || "";
    const updateAvailable = !!(latest && current && cmpVersion(latest, current) > 0);
    return {
      current,
      latest: latest || null,
      updateAvailable,
      checkedAt: cache?.checkedAt || null,
      latestAt: cache?.latestAt || null,
      notes: cache?.notes || "",
      url: cache?.url || "",
      checkError: !latest ? cache?.error || "نسخه‌ای یافت نشد" : null,
      checkedJustNow: force || age === Infinity,
    };
  });
}

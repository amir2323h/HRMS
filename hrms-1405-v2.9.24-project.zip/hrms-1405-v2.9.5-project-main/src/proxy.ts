import { NextRequest, NextResponse } from "next/server";
import { getSessionFromRequest, isSessionCurrent, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";

// این مسیرها باید حتی با کوکی نشست قبلی، امکان ورود مجدد/خروج را فراهم کنند.
const SESSION_ENTRY_PATHS = new Set([
  "/api/auth/login",
  "/api/auth/logout",
  "/api/auth/google/url",
  "/api/auth/google/callback",
  "/api/auth/mattermost/url",
  "/api/auth/mattermost/callback",
]);

export async function proxy(req: NextRequest) {
  const path = req.nextUrl.pathname.replace(/\/+$/, "");
  if (SESSION_ENTRY_PATHS.has(path)) return NextResponse.next();

  // کنترل ورود و مجوز هر عملیات همچنان داخل خود API انجام می‌شود.
  const session = getSessionFromRequest(req);
  if (!session) return NextResponse.next();

  try {
    if (await isSessionCurrent(session)) return NextResponse.next();
    const response = NextResponse.json({
      error: "نقش یا دسترسی حساب شما تغییر کرده است. دوباره وارد سامانه شوید.",
      code: "SESSION_CHANGED",
    }, { status: 401 });
    response.cookies.set(SESSION_COOKIE, "", { ...sessionCookieOptions(req), maxAge: 0 });
    response.headers.set("Cache-Control", "no-store");
    return response;
  } catch (error) {
    // شکست خواندن دیتابیس نباید باعث قبول دسترسی قدیمی شود.
    console.error("[SESSION CHECK ERROR]", error);
    return NextResponse.json({ error: "بررسی دسترسی موقتاً ممکن نیست. دوباره تلاش کنید." }, { status: 503 });
  }
}

export const config = { matcher: "/api/:path*" };

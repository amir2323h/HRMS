"use client";

// ============================================================
// مدیریت کاربران سامانه — در تنظیمات
// CRUD + ایمپورت اکسل + اتصال به پرونده کارمند
// فقط مدیر کل دسترسی ویرایش دارد
// ============================================================
import { useEffect, useMemo, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, UserCog, Upload, Download, Trash2, Edit3, KeyRound , ShieldQuestion } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { ROLE_LABELS } from "@/lib/format";
import { formatDateJ, toFaDigits } from "@/lib/jalali";
import { ExcelImportDialog, type ImportOutcome } from "../excel-import-dialog";
import { downloadExcel, pick, cellStr, cellBool } from "@/lib/excel";

// تاریخ ISO آخرین ورود → نمایش جلالی خوانا
function lastLoginDisplay(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  const j = iso.slice(0, 10).replace(/-/g, "/");
  return `${formatDateJ(j)} — ${toFaDigits(String(d.getHours()).padStart(2, "0"))}:${toFaDigits(String(d.getMinutes()).padStart(2, "0"))}`;
}

export interface UserRow {
  id: string;
  username: string;
  fullName: string;
  role: string;
  roleId: string | null;
  roleLabel: string;
  employeeId: string | null;
  employeeName: string;
  personnelCode: string;
  oauthProvider: string;
  oauthEmail: string;
  isActive: boolean;
  lastLoginAt: string | null;
  twoFaEnrolled?: boolean;
  createdAt: string;
}

interface EmployeeLite { id: string; personnelCode: string; fullName: string }
const BULK_ROLE_LIMIT = 500;

const ROLE_BADGES: Record<string, string> = {
  SUPER_ADMIN: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  HR_MANAGER: "bg-teal-100 text-teal-700 hover:bg-teal-100",
  PAYROLL_OFFICER: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  DEPT_MANAGER: "bg-violet-100 text-violet-700 hover:bg-violet-100",
  EMPLOYEE: "bg-slate-100 text-slate-600 hover:bg-slate-100",
};

/** نقش اکسل: کد لاتین یا برچسب فارسی */
export function parseRoleCell(raw: unknown): string {
  const s = cellStr(raw).trim();
  if (!s) return "";
  const upper = s.toUpperCase().replace(/\s+/g, "_");
  const codes = ["SUPER_ADMIN", "HR_MANAGER", "PAYROLL_OFFICER", "DEPT_MANAGER", "EMPLOYEE"];
  if (codes.includes(upper)) return upper;
  for (const [code, label] of Object.entries(ROLE_LABELS)) {
    if (s === label || s.replace(/\s+/g, "_") === label.replace(/\s+/g, "_")) return code;
  }
  return "";
}

export function UsersManager({ canEdit, currentUsername, currentUid }: { canEdit: boolean; currentUsername?: string; currentUid: string }) {
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [bulkUsers, setBulkUsers] = useState<UserRow[] | null>(null);
  const [bulkRoleId, setBulkRoleId] = useState("");
  const [bulkSaving, setBulkSaving] = useState(false);
  const [bulkError, setBulkError] = useState("");
  const bulkSavingRef = useRef(false);
  const list = useApi<{ users: UserRow[]; roles: { id: string; key: string; name: string; isSystem: boolean }[] }>("/api/users");
  const employees = useApi<{ employees: EmployeeLite[] }>("/api/employees");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<UserRow | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const roles = list.data?.roles || [];

  const rows = useMemo(() => {
    const all = list.data?.users || [];
    const t = q.trim().toLowerCase();
    const filterRole = list.data?.roles.find((r) => r.id === roleFilter);
    return all.filter((u) => {
      const matchesRole = roleFilter === "all" || u.roleId === roleFilter || (!u.roleId && u.role === filterRole?.key);
      const matchesSearch = !t || u.username.toLowerCase().includes(t) || u.fullName.toLowerCase().includes(t) || (u.personnelCode || "").toLowerCase().includes(t);
      return matchesRole && matchesSearch;
    });
  }, [list.data, q, roleFilter]);

  const eligibleRows = useMemo(() => rows.filter((u) => u.id !== currentUid), [rows, currentUid]);
  const selectedUsers = useMemo(() => {
    const ids = new Set(selectedIds);
    return eligibleRows.filter((u) => ids.has(u.id));
  }, [eligibleRows, selectedIds]);
  const allSelected = eligibleRows.length > 0 && selectedUsers.length === eligibleRows.length;
  const overBulkLimit = eligibleRows.length > BULK_ROLE_LIMIT;
  const destinationRole = roles.find((r) => r.id === bulkRoleId);

  // Keep valid selections after a refresh, without carrying hidden/deleted accounts into an action.
  useEffect(() => {
    const eligible = new Set(canEdit ? eligibleRows.map((u) => u.id) : []);
    setSelectedIds((previous) => {
      const next = previous.filter((id) => eligible.has(id));
      return next.length === previous.length ? previous : next;
    });
  }, [eligibleRows, canEdit]);

  function selectUser(user: UserRow, checked: boolean) {
    if (!canEdit || user.id === currentUid || bulkSavingRef.current) return;
    if (checked && !selectedIds.includes(user.id) && selectedUsers.length >= BULK_ROLE_LIMIT) {
      toast({ title: "سقف انتخاب گروهی", description: "در هر عملیات حداکثر ۵۰۰ کاربر انتخاب کنید؛ با فیلتر یا جستجو گروه کوچک‌تری بسازید.", variant: "destructive" });
      return;
    }
    setSelectedIds((previous) => checked ? [...new Set([...previous, user.id])] : previous.filter((id) => id !== user.id));
  }

  function selectAll(checked: boolean) {
    if (!canEdit || bulkSavingRef.current) return;
    if (checked && overBulkLimit) {
      toast({ title: "تعداد نتایج بیش از سقف عملیات است", description: "برای انتخاب همه، نتایج را با جستجو یا فیلتر نقش به حداکثر ۵۰۰ کاربر محدود کنید.", variant: "destructive" });
      return;
    }
    setSelectedIds(checked ? eligibleRows.map((u) => u.id) : []);
  }

  function openBulkRole() {
    if (!canEdit || !selectedUsers.length || selectedUsers.length > BULK_ROLE_LIMIT || list.loading) return;
    setBulkUsers(selectedUsers.map((u) => ({ ...u })));
    setBulkRoleId("");
    setBulkError("");
  }

  async function saveBulkRole() {
    if (bulkSavingRef.current || !canEdit || !bulkUsers?.length) return;
    if (!destinationRole) {
      setBulkError("نقش مقصد را انتخاب کنید.");
      return;
    }
    bulkSavingRef.current = true;
    setBulkSaving(true);
    setBulkError("");
    try {
      const result = await api<{ updatedCount: number; unchangedCount: number; roleLabel: string }>("/api/users/bulk-role", {
        method: "PATCH",
        json: { ids: bulkUsers.map((u) => u.id), roleId: destinationRole.id },
      });
      setBulkUsers(null);
      setSelectedIds([]);
      setBulkRoleId("");
      await list.refetch();
      toast({
        title: "ویرایش گروهی نقش انجام شد",
        description: `${toFaDigits(result.updatedCount)} کاربر به «${result.roleLabel}» تغییر کرد؛ ${toFaDigits(result.unchangedCount)} کاربر از قبل همین نقش را داشت. کاربران با نقش تغییرکرده باید دوباره وارد شوند.`,
      });
    } catch (e) {
      setBulkError(e instanceof Error ? e.message : "تغییر نقش انجام نشد؛ دوباره تلاش کنید.");
    } finally {
      bulkSavingRef.current = false;
      setBulkSaving(false);
    }
  }

  async function toggleActive(user: UserRow) {
    try {
      await api(`/api/users/${user.id}`, { method: "PATCH", json: { isActive: !user.isActive } });
      list.refetch();
      toast({ title: user.isActive ? "کاربر غیرفعال شد" : "کاربر فعال شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function reset2fa(user: UserRow) {
    if (!confirm(`بازنشانی ورود دو مرحله‌ای «${user.fullName}»؟\nراز 2FA او پاک می‌شود و در ورود بعدی دوباره ثبت‌نام می‌کند (QR جدید).`)) return;
    try {
      await api(`/api/users/${user.id}`, { method: "PATCH", json: { reset2fa: true } });
      await list.refetch();
      toast({ title: "2FA بازنشانی شد", description: `${user.fullName} در ورود بعدی QR راه‌اندازی جدید می‌گیرد.` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function remove(user: UserRow) {
    try {
      await api(`/api/users/${user.id}`, { method: "DELETE" });
      list.refetch();
      toast({ title: `کاربر «${user.username}» حذف شد` });
    } catch (e) {
      toast({ title: "حذف ممکن نیست", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  function exportExcel() {
    const data = (list.data?.users || []).map((u) => ({
      "نام کاربری": u.username,
      "نام و نام خانوادگی": u.fullName,
      "رمز عبور": "",
      "نقش": u.roleLabel || ROLE_LABELS[u.role] || u.role,
      "کد پرسنلی": u.personnelCode,
      "فعال": u.isActive ? "بله" : "خیر",
    }));
    downloadExcel("کاربران.xlsx", "کاربران", data);
  }

  function parseUserRow(row: Record<string, unknown>): { data: { username: string; fullName: string; password: string; role: string; personnelCode: string; isActive: boolean }; errors: string[] } {
    const errors: string[] = [];
    const username = cellStr(pick(row, ["نام کاربری", "username"])).toLowerCase();
    const fullName = cellStr(pick(row, ["نام و نام خانوادگی", "نام", "fullName"]));
    const password = cellStr(pick(row, ["رمز عبور", "رمز", "password"]));
    const role = parseRoleCell(pick(row, ["نقش", "سمت", "نقش کاربری"]));
    const personnelCode = cellStr(pick(row, ["کد پرسنلی", "personnelCode"]));
    const isActive = cellBool(pick(row, ["فعال", "وضعیت"]), true);

    if (!username) errors.push("نام کاربری خالی است.");
    else if (!/^[a-z0-9._-]{3,30}$/.test(username)) errors.push("نام کاربری نامعتبر (۳ تا ۳۰ کاراکتر لاتین).");
    if (!fullName) errors.push("نام و نام خانوادگی خالی است.");
    if (password && password.length < 6) errors.push("رمز عبور کمتر از ۶ کاراکتر است.");
    if (!role) errors.push("نقش نامعتبر است (مدیر کل سیستم / مدیر منابع انسانی / کارشناس حقوق و دستمزد / مدیر دپارتمان / کارمند).");
    return { data: { username, fullName, password, role, personnelCode, isActive }, errors };
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <UserCog className="w-4 h-4 text-teal-600" /> کاربران و دسترسی‌ها
            <Badge variant="outline">{toFaDigits(rows.length)} کاربر</Badge>
            {!canEdit && <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">فقط مشاهده</Badge>}
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1 leading-5">
            کاربران سامانه با نقش‌های پنج‌گانه — با ایمپورت اکسل می‌توانید گروهی از کاربران را ساخت و هر کاربر را با «کد پرسنلی» به پرونده کارمند متصل کرد.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* نوار ابزار */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input aria-label="جستجوی کاربران" className="pr-9" placeholder="جستجو: نام کاربری، نام، کد پرسنلی..." value={q} disabled={bulkSaving} onChange={(e) => { setQ(e.target.value); setSelectedIds([]); }} />
            </div>
            <div className="w-full sm:w-48">
              <Select value={roleFilter} disabled={bulkSaving} onValueChange={(value) => { setRoleFilter(value); setSelectedIds([]); }}>
                <SelectTrigger className="w-full" aria-label="فیلتر نقش فعلی کاربران"><SelectValue placeholder="نقش فعلی" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه نقش‌ها</SelectItem>
                  {roles.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" className="gap-1.5" onClick={exportExcel}>
              <Download className="w-4 h-4" /> خروجی اکسل
            </Button>
            {canEdit && (
              <>
                <Button variant="outline" className="gap-1.5" onClick={() => setImportOpen(true)}>
                  <Upload className="w-4 h-4" /> ایمپورت اکسل
                </Button>
                <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
                  <Plus className="w-4 h-4" /> کاربر جدید
                </Button>
              </>
            )}
          </div>

          {canEdit && (
            <div className="rounded-xl border border-teal-200 bg-teal-50/50 p-3 space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-sm font-medium" role="status" aria-live="polite" aria-atomic="true">{toFaDigits(selectedUsers.length)} کاربر انتخاب شده</span>
                <Button size="sm" variant="outline" disabled={list.loading || !eligibleRows.length || overBulkLimit || bulkSaving} onClick={() => selectAll(!allSelected)}>
                  {allSelected ? "لغو انتخاب همه" : `انتخاب همه نتایج فیلتر (${toFaDigits(eligibleRows.length)})`}
                </Button>
                {selectedUsers.length > 0 && <Button size="sm" variant="ghost" disabled={bulkSaving} onClick={() => setSelectedIds([])}>پاک کردن انتخاب‌ها</Button>}
                <Button size="sm" className="bg-teal-600 hover:bg-teal-700 gap-1.5 sm:mr-auto" disabled={!selectedUsers.length || list.loading || bulkSaving || !roles.length} onClick={openBulkRole}>
                  <UserCog className="w-4 h-4" aria-hidden="true" /> تغییر گروهی نقش ({toFaDigits(selectedUsers.length)})
                </Button>
              </div>
              <p className="text-xs text-muted-foreground leading-5">انتخاب فقط شامل نتایج همین جستجو و فیلتر است؛ با تغییر فیلتر، انتخاب‌ها پاک می‌شوند. حساب خودتان قابل انتخاب نیست. سقف هر عملیات ۵۰۰ کاربر است.</p>
              {overBulkLimit && <p className="text-xs text-amber-800 leading-5" role="status">تعداد نتایج قابل انتخاب بیش از ۵۰۰ است؛ برای انتخاب همه، جستجو یا فیلتر نقش را محدود کنید، یا حداکثر ۵۰۰ نفر را دستی انتخاب کنید.</p>}
            </div>
          )}
          {list.error && <p className="text-sm text-destructive" role="alert">{list.error}</p>}

          {/* جدول */}
          {list.loading ? (
            <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-11" />)}</div>
          ) : rows.length === 0 ? (
            <div className="py-10 text-center">
              <UserCog className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">کاربری یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    {canEdit && (
                      <TableHead className="w-12 text-center">
                        <div className="flex min-h-11 min-w-11 items-center justify-center">
                          <Checkbox
                            className="size-6"
                            aria-label="انتخاب همه نتایج همین جستجو و فیلتر، به جز حساب خودتان"
                            title={overBulkLimit ? "برای انتخاب همه، نتایج را به حداکثر ۵۰۰ کاربر محدود کنید" : "انتخاب همه نتایج فیلتر"}
                            checked={allSelected ? true : selectedUsers.length > 0 ? "indeterminate" : false}
                            disabled={!eligibleRows.length || overBulkLimit || bulkSaving}
                            onCheckedChange={(checked) => selectAll(checked === true)}
                          />
                        </div>
                      </TableHead>
                    )}
                    <TableHead className="text-right">نام کاربری</TableHead>
                    <TableHead className="text-right">نام و نام خانوادگی</TableHead>
                    <TableHead className="text-center">نقش</TableHead>
                    <TableHead className="text-right">پرونده متصل</TableHead>
                    <TableHead className="text-center">آخرین ورود</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    {canEdit && <TableHead className="text-center">عملیات</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((u) => (
                    <TableRow key={u.id} className="hover:bg-teal-50/40" data-state={selectedIds.includes(u.id) && u.id !== currentUid ? "selected" : undefined}>
                      {canEdit && (
                        <TableCell className="text-center">
                          <div className="flex min-h-11 min-w-11 items-center justify-center">
                            <Checkbox
                              className="size-6"
                              aria-label={u.id === currentUid ? `حساب خودتان (${u.fullName}) قابل انتخاب نیست` : `انتخاب ${u.fullName} (${u.username})`}
                              title={u.id === currentUid ? "حساب خودتان قابل تغییر گروهی نیست" : `انتخاب ${u.fullName}`}
                              checked={u.id !== currentUid && selectedIds.includes(u.id)}
                              disabled={u.id === currentUid || bulkSaving}
                              onCheckedChange={(checked) => selectUser(u, checked === true)}
                            />
                          </div>
                        </TableCell>
                      )}
                      <TableCell className="tabular-nums text-sm font-medium" dir="ltr">
                        {u.username}
                        {(u.id === currentUid || u.username === currentUsername) && <Badge className="mr-1.5 bg-teal-100 text-teal-700 hover:bg-teal-100">شما</Badge>}
                      </TableCell>
                      <TableCell className="text-sm">{u.fullName}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={ROLE_BADGES[u.role] || ""}>{u.roleLabel}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {u.employeeName ? (
                          <span>{u.employeeName} <span className="text-[11px] text-muted-foreground tabular-nums" dir="ltr">({u.personnelCode})</span></span>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center text-xs text-muted-foreground tabular-nums">{lastLoginDisplay(u.lastLoginAt)}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={u.isActive ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                          {u.isActive ? "فعال" : "غیرفعال"}
                        </Badge>
                      </TableCell>
                      {canEdit && (
                        <TableCell className="text-center">
                          <div className="flex justify-center gap-1">
                            <button className="p-1.5 rounded-lg hover:bg-amber-100 text-amber-600" title="ویرایش" onClick={() => { setEditing(u); setFormOpen(true); }}>
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              className={`p-1.5 rounded-lg ${u.isActive ? "hover:bg-slate-100 text-slate-500" : "hover:bg-emerald-100 text-emerald-600"}`}
                              title={u.isActive ? "غیرفعال کردن" : "فعال کردن"}
                              onClick={() => toggleActive(u)}
                            >
                              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
                                {u.isActive ? <path d="M18.36 6.64A9 9 0 1 1 5.64 6.64M12 2v10" strokeLinecap="round" /> : <path d="M12 2v10m6.36-5.36A9 9 0 1 1 5.64 6.64" strokeLinecap="round" />}
                              </svg>
                            </button>
                            {u.twoFaEnrolled && (
                              <button
                                className="p-1.5 rounded-lg hover:bg-violet-100 text-violet-600"
                                title="بازنشانی ورود دو مرحله‌ای (اگر کاربر اپ احرازکننده را گم کرده)"
                                onClick={() => reset2fa(u)}
                              >
                                <ShieldQuestion className="w-4 h-4" />
                              </button>
                            )}
                            <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title="حذف" onClick={() => remove(u)}>
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {canEdit && (
        <Dialog open={bulkUsers !== null} onOpenChange={(open) => { if (!open && !bulkSavingRef.current) setBulkUsers(null); }}>
          <DialogContent
            className="sm:max-w-[39.2rem] max-h-[85vh] overflow-y-auto"
            dir="rtl"
            showCloseButton={!bulkSaving}
            onEscapeKeyDown={(event) => { if (bulkSavingRef.current) event.preventDefault(); }}
            onInteractOutside={(event) => { if (bulkSavingRef.current) event.preventDefault(); }}
          >
            <DialogHeader className="text-right sm:text-right">
              <DialogTitle>تغییر گروهی نقش کاربران</DialogTitle>
              <DialogDescription>نقش {toFaDigits(bulkUsers?.length || 0)} حساب زیر به نقش مقصد انتخاب‌شده تغییر می‌کند. پیش از تأیید، حساب‌ها و نقش مقصد را بررسی کنید.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4" aria-busy={bulkSaving}>
              <div className="max-h-40 overflow-y-auto rounded-xl border p-3" tabIndex={0} role="region" aria-label="فهرست حساب‌های انتخاب‌شده">
                <ul className="space-y-2 text-sm">
                  {(bulkUsers || []).map((u) => (
                    <li key={u.id} className="flex flex-wrap items-center justify-between gap-2">
                      <span>{u.fullName} <span className="text-muted-foreground" dir="ltr">({u.username})</span></span>
                      <Badge variant="outline">{u.roleLabel || ROLE_LABELS[u.role] || u.role}</Badge>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="bulk-role-destination">نقش مقصد <span className="text-rose-600">*</span></Label>
                <Select value={bulkRoleId} disabled={bulkSaving} onValueChange={(value) => { setBulkRoleId(value); setBulkError(""); }}>
                  <SelectTrigger id="bulk-role-destination" className="w-full" aria-describedby="bulk-role-notice bulk-role-error" aria-invalid={!!bulkError}>
                    <SelectValue placeholder="نقش مقصد را انتخاب کنید" />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}{r.isSystem ? " (سیستمی)" : ""}</SelectItem>)}
                  </SelectContent>
                </Select>
                {destinationRole && <p className="text-sm font-medium leading-6">با تأیید، نقش {toFaDigits(bulkUsers?.length || 0)} کاربر به «{destinationRole.name}» تنظیم می‌شود.</p>}
              </div>
              <p id="bulk-role-notice" className="rounded-xl bg-amber-50 p-3 text-xs text-amber-900 leading-6">کاربرانی که نقششان تغییر می‌کند، برای ادامه کار باید دوباره وارد سامانه شوند. این تغییر در لاگ حسابرسی ثبت می‌شود.</p>
              <p id="bulk-role-error" role="alert" className="text-sm text-destructive leading-6">{bulkError}</p>
            </div>
            <DialogFooter>
              <Button variant="outline" disabled={bulkSaving} onClick={() => setBulkUsers(null)}>انصراف</Button>
              <Button className="bg-teal-600 hover:bg-teal-700 whitespace-normal h-auto min-h-9" disabled={bulkSaving || !destinationRole || !bulkUsers?.length} onClick={saveBulkRole}>
                {bulkSaving ? "در حال تغییر نقش..." : destinationRole ? `تأیید تغییر به «${destinationRole.name}»` : "تأیید تغییر نقش"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* فرم کاربر */}
      <UserForm
        open={formOpen}
        onOpenChange={setFormOpen}
        editing={editing}
        roles={roles}
        employees={(employees.data?.employees || []).map((e) => ({ id: e.id, fullName: e.fullName, personnelCode: e.personnelCode }))}
        onSaved={() => { list.refetch(); toast({ title: editing ? "کاربر به‌روزرسانی شد" : "کاربر جدید ایجاد شد", description: "در لاگ حسابرسی ثبت گردید." }); }}
      />

      {/* ایمپورت اکسل */}
      {canEdit && (
        <ExcelImportDialog
          open={importOpen}
          onOpenChange={setImportOpen}
          title="ایمپورت کاربران از اکسل"
          description="فایل اکسل شامل کاربران را انتخاب کنید. کاربران موجود (بر اساس نام کاربری) به‌روزرسانی می‌شوند و کاربران جدید ایجاد می‌شوند. رمز عبور در خروجی اکسل خالی است — در فایل ایمپورت الزامی است."
          endpoint="/api/users/import"
          templateFilename="قالب-کاربران.xlsx"
          sheetName="کاربران"
          headers={["نام کاربری", "نام و نام خانوادگی", "رمز عبور", "نقش", "کد پرسنلی (اختیاری)", "فعال (بله/خیر)"]}
          sampleRows={[
            { "نام کاربری": "ali.rezaei", "نام و نام خانوادگی": "علی رضایی", "رمز عبور": "123456", "نقش": "کارمند", "کد پرسنلی": "EMP-1005", "فعال": "بله" },
            { "نام کاربری": "hr2", "نام و نام خانوادگی": "مریم احمدی", "رمز عبور": "pass1234", "نقش": "مدیر منابع انسانی", "کد پرسنلی": "", "فعال": "بله" },
          ]}
          parseRow={parseUserRow}
          onImported={(_outcome: ImportOutcome) => list.refetch()}
        />
      )}
    </div>
  );
}

// ================= فرم کاربر =================
function UserForm({ open, onOpenChange, editing, roles, employees, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: UserRow | null;
  roles: { id: string; key: string; name: string; isSystem: boolean }[];
  employees: { id: string; fullName: string; personnelCode: string }[];
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [f, setF] = useState(() => ({
    username: editing?.username || "",
    fullName: editing?.fullName || "",
    password: "",
    roleId: editing?.roleId || "",
    employeeId: editing?.employeeId || "none",
    isActive: editing?.isActive ?? true,
  }));
  const [lastKey, setLastKey] = useState(editing?.id || "new");
  const key = editing?.id || "new";
  if (lastKey !== key) {
    setLastKey(key);
    setF({
      username: editing?.username || "",
      fullName: editing?.fullName || "",
      password: "",
      roleId: editing?.roleId || "",
      employeeId: editing?.employeeId || "none",
      isActive: editing?.isActive ?? true,
    });
  }

  async function save() {
    const errors: string[] = [];
    if (!editing && !/^[a-z0-9._-]{3,30}$/.test(f.username.trim().toLowerCase())) errors.push("نام کاربری نامعتبر است (۳ تا ۳۰ کاراکتر لاتین).");
    if (!f.fullName.trim()) errors.push("نام و نام خانوادگی الزامی است.");
    if (!editing && f.password.length < 6) errors.push("رمز عبور باید حداقل ۶ کاراکتر باشد.");
    if (editing && f.password && f.password.length < 6) errors.push("رمز عبور باید حداقل ۶ کاراکتر باشد.");
    if (errors.length) {
      toast({ title: errors[0], variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        const payload: Record<string, unknown> = {
          fullName: f.fullName.trim(),
          roleId: f.roleId || undefined,
          employeeId: f.employeeId === "none" ? null : f.employeeId,
          isActive: f.isActive,
        };
        if (f.password) payload.password = f.password;
        await api(`/api/users/${editing.id}`, { method: "PATCH", json: payload });
      } else {
        await api("/api/users", {
          method: "POST",
          json: {
            username: f.username.trim().toLowerCase(),
            fullName: f.fullName.trim(),
            password: f.password,
            roleId: f.roleId || undefined,
            employeeId: f.employeeId === "none" ? null : f.employeeId,
            isActive: f.isActive,
          },
        });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? `ویرایش کاربر — ${editing.username}` : "ایجاد کاربر جدید"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">نام کاربری <span className="text-rose-600">*</span></Label>
            <Input dir="ltr" className="text-left" value={f.username} disabled={!!editing} onChange={(e) => setF({ ...f, username: e.target.value.toLowerCase() })} placeholder="مثلاً ali.rezaei" />
            {editing && <p className="text-[10px] text-muted-foreground">نام کاربری قابل تغییر نیست</p>}
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نام و نام خانوادگی <span className="text-rose-600">*</span></Label>
            <Input value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">
              {editing ? <>رمز عبور جدید <span className="text-muted-foreground">(خالی = بدون تغییر)</span></> : <>رمز عبور <span className="text-rose-600">*</span></>}
            </Label>
            <div className="relative">
              <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input dir="ltr" className="text-left pr-9" type="text" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} placeholder="حداقل ۶ کاراکتر" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs">نقش <span className="text-rose-600">*</span></Label>
              <Select value={f.roleId} onValueChange={(v) => setF({ ...f, roleId: v })}>
                <SelectTrigger><SelectValue placeholder="انتخاب نقش" /></SelectTrigger>
                <SelectContent>
                  {roles.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.name}{r.isSystem ? " (سیستمی)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[10px] text-muted-foreground">مجوزها از تعریف نقش می‌آیند — قابل تعریف در تب «نقش‌ها و مجوزها»</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">پرونده کارمند (اختیاری)</Label>
              <Select value={f.employeeId} onValueChange={(v) => setF({ ...f, employeeId: v })}>
                <SelectTrigger><SelectValue placeholder="بدون اتصال" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون اتصال</SelectItem>
                  {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName} ({e.personnelCode})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-xl border px-3.5 py-2.5">
            <div>
              <p className="text-sm font-medium">فعال</p>
              <p className="text-[11px] text-muted-foreground">کاربر غیرفعال نمی‌تواند وارد شود</p>
            </div>
            <Switch checked={f.isActive} onCheckedChange={(v) => setF({ ...f, isActive: v })} />
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">{saving ? "..." : "ذخیره"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

"use client";

import { useEffect, useRef, useState, type Dispatch, type SetStateAction } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Settings, Save, Scale, Percent, ShieldAlert, Info, Image as ImageIcon, Globe, Upload, X, Briefcase, UserCog, Trash2, CalendarDays, Stamp as StampIcon, DatabaseBackup, RotateCcw, History as HistoryIcon } from "lucide-react";
import { LEGAL_SENIORITY_DAILY_1405 } from "@/lib/payroll/engine";
import { api, useApi } from "@/lib/client";
import { groupFa } from "@/lib/format";
import { toFaDigits } from "@/lib/jalali";
import { MoneyInput } from "../money-input";
import { JobsManager } from "./settings-jobs";
import { UsersManager } from "./settings-users";
import { hasPerm } from "@/lib/permissions";
import { RolesManager } from "./settings-roles";
import { WelfareManager } from "./settings-welfare";
import { BonusConfigEditor } from "./settings-bonus";
import { MattermostSettings } from "./settings-mattermost";
import { LetterTemplatesManager, LetterDownloadPolicyCard, LetterApprovalFlowsCard } from "./settings-letters";
import { TwoFactorSettings, GoogleLoginSettings } from "./settings-auth";
import { PurgeDemoManager } from "./settings-purge";
import { HolidaysManager } from "./settings-holidays";
import { BackupManager } from "./settings-backup";
import type { SessionInfo } from "../app-root";
import { Gift, ShieldCheck, MessageSquare, FileText, Coins, KeyRound, Sparkles, Plus, Pencil } from "lucide-react";

interface LegalParams {
  year: number;
  employeeSsoRate: number;
  employerSsoRate: number;
  unemploymentRate: number;
  minWage: number;
  insurableCap: number | null;
  housing: number;
  grocery: number;
  childPerChild: number;
  maxChildrenForAllowance: number;
  marriageAllowance: number; // حق تاهل — ریال
  seniorityMode: "LEGAL" | "GRADE";
  seniorityDailyByYear: number[]; // نرخ روزانه تجمیعی ۱..۳۰ سال — ریال
  monthlyWorkHours: number;
  overtimeMultiplier: number;
  // ---- ضرایب شیفت/شب/تعطیل/مأموریت ----
  nightPremium: number;
  fridayMultiplier: number;
  holidayMultiplier: number;
  shiftTwoRate: number;
  shiftThreeRate: number;
  missionMultiplier: number;
  groceryTaxable: boolean;
  taxBrackets: { sortOrder: number; lowerLimit: number; upperLimit: number | null; rate: number }[];
}

interface CompanyForm {
  name: string; nationalId: string; ssoCode: string; taxId: string; address: string;
  phone: string; mobile: string; website: string; email: string;
}

const RATE_FIELDS: { key: keyof LegalParams; label: string; hint: string }[] = [
  { key: "employeeSsoRate", label: "نرخ بیمه سهم کارمند", hint: "۷٪ — کسر از حقوق کارمند" },
  { key: "employerSsoRate", label: "نرخ بیمه سهم کارفرما", hint: "۲۰٪ — هزینه کارفرما" },
  { key: "unemploymentRate", label: "نرخ بیمه بیکاری", hint: "۳٪ — هزینه کارفرما" },
];

export function SettingsView({ user }: { user: SessionInfo }) {
  const { data, loading, refetch } = useApi<{
    params: LegalParams; display: { unit: string }; company: CompanyForm;
    letters: { numberingPrefix: string; signerName: string; signerTitle: string; showDigitalSignature?: boolean; signers: { name: string; title: string; userId?: string; username?: string; signature?: string; seal?: string }[] };
    roles: { key: string; name: string }[];
    changelog: { version: string; title: string; enabled: boolean; targetAll: boolean; roles: string[]; usernames: string[]; updatedAt: string; items: { tag: string; title: string; desc: string }[] };
    appVersion: string;
    signerCandidates: { id: string; username: string; fullName: string; role: string; jobTitle: string }[];
  }>("/api/settings");
  const [f, setF] = useState<LegalParams | null>(null);
  const [company, setCompany] = useState<CompanyForm>({ name: "", nationalId: "", ssoCode: "", taxId: "", address: "", phone: "", mobile: "", website: "", email: "" });
  const [lettersCfg, setLettersCfg] = useState({ numberingPrefix: "ZDX", signerName: "", signerTitle: "مدیر عامل", showDigitalSignature: true });
  const [lettersSigners, setLettersSigners] = useState<{ name: string; title: string; userId?: string; username?: string; signature?: string; seal?: string }[]>([]);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const canEdit = user.role === "SUPER_ADMIN" || (user.perms || []).includes("settings:manage");
  const canManageUsers = hasPerm(user.perms, "users:manage");
  const canViewUsers = canManageUsers || hasPerm(user.perms, "users:view");
  const canHolidays = (user.perms || []).includes("*") || (user.perms || []).includes("attendance:manage") || (user.perms || []).includes("attendance:view");
  const canRoles = (user.perms || []).includes("*") || (user.perms || []).includes("roles:manage");
  const canWelfare = (user.perms || []).includes("*") || (user.perms || []).includes("welfare:manage");
  const canBonus = (user.perms || []).includes("*") || (user.perms || []).includes("bonus:manage");
  const canLetterTemplates = (user.perms || []).includes("*") || (user.perms || []).includes("letters:templates");
  const canPurge = (user.perms || []).includes("*"); // حذف داده نمونه — فقط مدیر کل
  const canBackup = (user.perms || []).includes("*"); // پشتیبان‌گیری/بازیابی — فقط مدیر کل
  // فهرست نقش‌ها برای فرم‌های انتخاب نقش
  const rolesApi = useApi<{ roles: { id: string; key: string; name: string }[] }>("/api/roles");
  const roles = rolesApi.data?.roles || [];
  // گزینه‌های دراپ‌داون امضاکنندگان — کاربران فعال (از تنظیمات)
  const signerCandidates = data?.signerCandidates || [];

  useEffect(() => {
    if (data?.params) {
      setF(data.params);
      setCompany({
        name: "", nationalId: "", ssoCode: "", taxId: "", address: "", phone: "", mobile: "", website: "", email: "",
        ...(data.company || {}),
      });
      if (data.letters) setLettersCfg({ ...lettersCfg, ...data.letters, showDigitalSignature: data.letters.showDigitalSignature !== false });
      setLettersSigners(Array.isArray(data.letters?.signers) ? data.letters.signers : []);
    }
  }, [data]);

  if (loading || !f) return <div className="space-y-3"><Skeleton className="h-40 rounded-2xl" /><Skeleton className="h-72 rounded-2xl" /></div>;

  function setBrackets(idx: number, field: "lowerLimit" | "upperLimit" | "rate", value: string) {
    const next = [...f.taxBrackets];
    const v = field === "rate" ? parseFloat(value) || 0 : value === "" ? 0 : parseInt(value.replace(/\D/g, ""), 10) || 0;
    next[idx] = { ...next[idx], [field]: field === "upperLimit" && value === "" ? null : v };
    setF({ ...f, taxBrackets: next });
  }

  /** ویرایش نرخ روزانه تجمیعی سال i-ام جدول سنوات (ورودی تومان → ذخیره ریال) */
  function setSeniorityRow(idx: number, toman: number) {
    const table = [...(f.seniorityDailyByYear || [])];
    table[idx] = Math.max(0, Math.round(toman * 10));
    setF({ ...f, seniorityDailyByYear: table });
  }

  async function save() {
    setSaving(true);
    try {
      await api("/api/settings", {
        method: "PUT",
        json: {
          params: {
            ...f,
            minWage: f.minWage,
            housing: f.housing,
            grocery: f.grocery,
            childPerChild: f.childPerChild,
            insurableCap: f.insurableCap,
          },
          company,
          letters: lettersCfg,
        },
      });
      toast({ title: "تنظیمات ذخیره شد", description: "پارامترهای قانونی، مشخصات کارفرما و تنظیمات نامه‌ها به‌روزرسانی شد." });
      refetch();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <Tabs defaultValue="legal" dir="rtl">
        <TabsList className="w-full h-auto flex-wrap justify-start gap-1 p-1">
          <TabsTrigger value="legal" className="gap-1.5 flex-1 sm:flex-none px-4"><Scale className="w-3.5 h-3.5" /> اطلاعات پایه</TabsTrigger>
          <TabsTrigger value="jobs" className="gap-1.5 flex-1 sm:flex-none px-4"><Briefcase className="w-3.5 h-3.5" /> مشاغل</TabsTrigger>
          {canHolidays && (
            <TabsTrigger value="holidays" className="gap-1.5 flex-1 sm:flex-none px-4"><CalendarDays className="w-3.5 h-3.5" /> تعطیلات و شیفت‌ها</TabsTrigger>
          )}
          <TabsTrigger value="welfare" className="gap-1.5 flex-1 sm:flex-none px-4"><Gift className="w-3.5 h-3.5" /> رفاهیات</TabsTrigger>
          <TabsTrigger value="bonus" className="gap-1.5 flex-1 sm:flex-none px-4"><Coins className="w-3.5 h-3.5" /> پاداش</TabsTrigger>
          {canViewUsers && (
            <TabsTrigger value="users" className="gap-1.5 flex-1 sm:flex-none px-4"><UserCog className="w-3.5 h-3.5" /> کاربران</TabsTrigger>
          )}
          {canRoles && (
            <TabsTrigger value="roles" className="gap-1.5 flex-1 sm:flex-none px-4"><ShieldCheck className="w-3.5 h-3.5" /> نقش‌ها و مجوزها</TabsTrigger>
          )}
          {canLetterTemplates && (
            <TabsTrigger value="letters" className="gap-1.5 flex-1 sm:flex-none px-4"><FileText className="w-3.5 h-3.5" /> قالب نامه‌ها</TabsTrigger>
          )}
          <TabsTrigger value="branding" className="gap-1.5 flex-1 sm:flex-none px-4"><Globe className="w-3.5 h-3.5" /> برندینگ</TabsTrigger>
          {canEdit && (
            <TabsTrigger value="changelog" className="gap-1.5 flex-1 sm:flex-none px-4"><Sparkles className="w-3.5 h-3.5" /> اطلاعیه نسخه</TabsTrigger>
          )}
          {canEdit && (
            <TabsTrigger value="auth" className="gap-1.5 flex-1 sm:flex-none px-4"><KeyRound className="w-3.5 h-3.5" /> ورود و امنیت</TabsTrigger>
          )}
          {canEdit && (
            <TabsTrigger value="mattermost" className="gap-1.5 flex-1 sm:flex-none px-4"><MessageSquare className="w-3.5 h-3.5" /> ورود Mattermost</TabsTrigger>
          )}
          {canPurge && (
            <TabsTrigger value="purge" className="gap-1.5 flex-1 sm:flex-none px-4 text-rose-700"><Trash2 className="w-3.5 h-3.5" /> داده نمونه</TabsTrigger>
          )}
          {canBackup && (
            <TabsTrigger value="backup" className="gap-1.5 flex-1 sm:flex-none px-4 text-teal-700"><DatabaseBackup className="w-3.5 h-3.5" /> پشتیبان‌گیری</TabsTrigger>
          )}
        </TabsList>

        {/* ————— تب پارامترهای قانونی ————— */}
        <TabsContent value="legal" className="space-y-4 mt-4">
      <Card className="rounded-2xl bg-gradient-to-l from-amber-50 to-white border-amber-200">
        <CardContent className="p-4 flex items-start gap-3">
          <ShieldAlert className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-sm text-slate-800">پارامترهای قانونی سال ۱۴۰۵</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              مقادیر پیش‌فرض مطابق قانون بودجه ۱۴۰۵ (ماده ۸۵)، مصوبات شورای عالی کار (بخشنامه مزد ۱۴۰۵) و مقررات تأمین اجتماعی تنظیم شده‌اند.
              در صورت تغییر مقررات، مقادیر را به‌روزرسانی کنید — همه محاسبات و محاسبه معکوس فوراً از مقادیر جدید استفاده می‌کنند.
            </p>
          </div>
          {!canEdit && <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">فقط مدیر کل می‌تواند ویرایش کند</Badge>}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* مزایای قانونی */}
        <Card className="rounded-2xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Scale className="w-4 h-4 text-teal-600" /> مزایای قانونی ماهانه ۱۴۰۵</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">حداقل دستمزد ماهانه</Label>
                <MoneyInput value={Math.round(f.minWage / 10)} onChange={(v) => setF({ ...f, minWage: v * 10 })} disabled={!canEdit} />
                <p className="text-[10px] text-muted-foreground">مصوبه شورای عالی کار — بخشنامه مزد ۱۴۰۵</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">حق مسکن</Label>
                <MoneyInput value={Math.round(f.housing / 10)} onChange={(v) => setF({ ...f, housing: v * 10 })} disabled={!canEdit} />
                <p className="text-[10px] text-muted-foreground">افزایش از ۹۰۰ هزار به ۳ میلیون تومان در ۱۴۰۵</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">بن کارگری</Label>
                <MoneyInput value={Math.round(f.grocery / 10)} onChange={(v) => setF({ ...f, grocery: v * 10 })} disabled={!canEdit} />
                <p className="text-[10px] text-muted-foreground">کمک‌هزینه اقلام مصرفی — معاف مالیاتی (ماده ۹۱ بند ۱۴)</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">حق اولاد (هر فرزند)</Label>
                <MoneyInput value={Math.round(f.childPerChild / 10)} onChange={(v) => setF({ ...f, childPerChild: v * 10 })} disabled={!canEdit} />
                <p className="text-[10px] text-muted-foreground">معادل ۱۰٪ حداقل دستمزد — حداکثر {toFaDigits(f.maxChildrenForAllowance)} فرزند</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">حق تاهل (کارکنان متاهل)</Label>
                <MoneyInput value={Math.round((f.marriageAllowance || 0) / 10)} onChange={(v) => setF({ ...f, marriageAllowance: v * 10 })} disabled={!canEdit} />
                <p className="text-[10px] text-muted-foreground">مصوبه ۱۴۰۵ شورای عالی کار — به کارکنان متاهل</p>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4 pt-2 border-t">
              <div className="space-y-1.5">
                <Label className="text-xs">ساعت کار ماهانه</Label>
                <Input type="number" className="tabular-nums" value={f.monthlyWorkHours} disabled={!canEdit} onChange={(e) => setF({ ...f, monthlyWorkHours: +e.target.value || 220 })} />
                <p className="text-[10px] text-muted-foreground">مبنای محاسبه نرخ ساعتی اضافه‌کاری</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">ضریب اضافه‌کاری</Label>
                <Input type="number" step="0.1" min="1" className="tabular-nums" value={f.overtimeMultiplier} disabled={!canEdit} onChange={(e) => setF({ ...f, overtimeMultiplier: +e.target.value || 1.4 })} />
                <p className="text-[10px] text-muted-foreground">ماده ۵۹ قانون کار: ۴۰٪ اضافه بر مزد ساعتی</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">سقف مشمول بیمه</Label>
                <MoneyInput value={f.insurableCap ? Math.round(f.insurableCap / 10) : 0} onChange={(v) => setF({ ...f, insurableCap: v > 0 ? v * 10 : null })} disabled={!canEdit} />
                <p className="text-[10px] text-muted-foreground">صفر = نامحدود</p>
              </div>
            </div>

            {/* ضرایب شیفت/شب/تعطیل/مأموریت — مبنای محاسبه فیش از کارکرد حضور و غیب */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 pt-2 border-t">
              <div className="space-y-1.5">
                <Label className="text-xs">فوق‌العاده شب‌کاری</Label>
                <Input type="number" step="0.01" min="0" className="tabular-nums" value={f.nightPremium} disabled={!canEdit} onChange={(e) => setF({ ...f, nightPremium: +e.target.value || 0 })} />
                <p className="text-[10px] text-muted-foreground">نرخ صرف (۰.۳۵) — ماده ۵۸: ساعت ۲۲–۶</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">ضریب جمعه‌کاری</Label>
                <Input type="number" step="0.1" min="1" className="tabular-nums" value={f.fridayMultiplier} disabled={!canEdit} onChange={(e) => setF({ ...f, fridayMultiplier: +e.target.value || 1.4 })} />
                <p className="text-[10px] text-muted-foreground">۱.۴ — ماده ۶۲: علاوه بر مزد روز</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">ضریب تعطیل‌کاری</Label>
                <Input type="number" step="0.1" min="1" className="tabular-nums" value={f.holidayMultiplier} disabled={!canEdit} onChange={(e) => setF({ ...f, holidayMultiplier: +e.target.value || 1.4 })} />
                <p className="text-[10px] text-muted-foreground">۱.۴ — تعطیلات رسمی</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">حق شیفت دوگانه</Label>
                <Input type="number" step="0.01" min="0" className="tabular-nums" value={f.shiftTwoRate} disabled={!canEdit} onChange={(e) => setF({ ...f, shiftTwoRate: +e.target.value || 0 })} />
                <p className="text-[10px] text-muted-foreground">۰.۲۲۵ — صبح/عصر (تبصره ۱ ماده ۵۶)</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">حق شیفت سه‌گانه</Label>
                <Input type="number" step="0.01" min="0" className="tabular-nums" value={f.shiftThreeRate} disabled={!canEdit} onChange={(e) => setF({ ...f, shiftThreeRate: +e.target.value || 0 })} />
                <p className="text-[10px] text-muted-foreground">۰.۴۵ — صبح/عصر/شب (تبصره ۱ ماده ۵۶)</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">ضریب مأموریت روزانه</Label>
                <Input type="number" step="0.05" min="0" className="tabular-nums" value={f.missionMultiplier} disabled={!canEdit} onChange={(e) => setF({ ...f, missionMultiplier: +e.target.value || 0 })} />
                <p className="text-[10px] text-muted-foreground">۱ = معادل مزد روزانه (پایه ÷ ۳۰) × روزهای مأموریت</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* نرخ‌های بیمه + مشخصات شرکت */}
        <div className="space-y-4">
          <Card className="rounded-2xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Percent className="w-4 h-4 text-teal-600" /> نرخ‌های بیمه تأمین اجتماعی</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                {RATE_FIELDS.map((r) => (
                  <div key={r.key} className="rounded-xl bg-slate-50 border border-slate-200/70 p-3.5">
                    <p className="text-xs text-muted-foreground">{r.label}</p>
                    <div className="flex items-center gap-1.5 mt-2">
                      <Input
                        dir="ltr"
                        className="text-left tabular-nums h-9"
                        value={Math.round((f[r.key] as number) * 1000) / 10}
                        disabled={!canEdit}
                        onChange={(e) => {
                          const v = parseFloat(e.target.value) || 0;
                          setF({ ...f, [r.key]: v / 100 });
                        }}
                      />
                      <span className="text-sm font-bold text-slate-600">٪</span>
                    </div>
                    <p className="text-[10px] text-muted-foreground mt-1.5">{r.hint}</p>
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                <Info className="w-3.5 h-3.5" />
                جمع نرخ بیمه: {toFaDigits(Math.round(((f.employeeSsoRate + f.employerSsoRate + f.unemploymentRate) * 1000)) / 10)}٪ (۷٪ کارمند + ۲۳٪ کارفرما)
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-2xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2"><Settings className="w-4 h-4 text-teal-600" /> مشخصات کارفرما</CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5 col-span-2">
                <Label className="text-xs">نام شرکت</Label>
                <Input value={company.name} disabled={!canEdit} onChange={(e) => setCompany({ ...company, name: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">شناسه ملی</Label>
                <Input dir="ltr" className="text-left tabular-nums" value={company.nationalId} disabled={!canEdit} onChange={(e) => setCompany({ ...company, nationalId: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">کد کارگاه بیمه</Label>
                <Input dir="ltr" className="text-left" value={company.ssoCode} disabled={!canEdit} onChange={(e) => setCompany({ ...company, ssoCode: e.target.value })} />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label className="text-xs">شناسه مالیاتی</Label>
                <Input dir="ltr" className="text-left tabular-nums" value={company.taxId} disabled={!canEdit} onChange={(e) => setCompany({ ...company, taxId: e.target.value })} />
              </div>
              <div className="space-y-1.5 col-span-2">
                <Label className="text-xs">نشانی</Label>
                <Input value={company.address} disabled={!canEdit} onChange={(e) => setCompany({ ...company, address: e.target.value })} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">تلفن (پابرگ نامه‌ها)</Label>
                <Input dir="ltr" className="text-left" value={company.phone} disabled={!canEdit} onChange={(e) => setCompany({ ...company, phone: e.target.value })} placeholder="021-91094030" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">موبایل (پابرگ نامه‌ها)</Label>
                <Input dir="ltr" className="text-left" value={company.mobile} disabled={!canEdit} onChange={(e) => setCompany({ ...company, mobile: e.target.value })} placeholder="0912 884 4262" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">وب‌سایت (پابرگ نامه‌ها)</Label>
                <Input dir="ltr" className="text-left" value={company.website} disabled={!canEdit} onChange={(e) => setCompany({ ...company, website: e.target.value })} placeholder="www.example.ir" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">ایمیل (پابرگ نامه‌ها)</Label>
                <Input dir="ltr" className="text-left" value={company.email} disabled={!canEdit} onChange={(e) => setCompany({ ...company, email: e.target.value })} placeholder="info@example.ir" />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* پایه سنوات — جدول تجمیعی رسمی ۱۴۰۵ */}
      <Card className="rounded-2xl border-teal-200/70">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <HistoryIcon className="w-4 h-4 text-teal-600" /> پایه سنوات (جدول تجمیعی رسمی)
            <Badge variant="outline" className="text-[10px]">سال اول: روزانه {groupFa(Math.round((f.seniorityDailyByYear?.[0] || 0) / 10))} تومان</Badge>
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1 leading-5">
            مطابق جدول احتساب مزد سنوات (بخشنامه مزد ۱۴۰۵): سنوات ماهانه = نرخ روزانه تجمیعی × ۳۰؛ از ابتدای سال دوم (پس از یک سال کامل خدمت) تعلق می‌گیرد.
            نرخ‌ها پلکانی و «تجمیعی»اند — هر سال خدمت به نرخ مصوب همان سال اعتبار گرفته است.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs">روش محاسبه سنوات</Label>
              <Select value={f.seniorityMode || "LEGAL"} onValueChange={(v) => setF({ ...f, seniorityMode: v as "LEGAL" | "GRADE" })} disabled={!canEdit}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="LEGAL">قانونی — جدول تجمیعی رسمی ۱۴۰۵ (پیش‌فرض)</SelectItem>
                  <SelectItem value="GRADE">طبقه‌ای — پایه هر سال از طبقه شغلی</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-[10px] text-muted-foreground leading-4">
                {f.seniorityMode === "GRADE"
                  ? "سنوات = «پایه سنوات هر سال» طبقه شغلی × سال‌های خدمت — مناسب کارگاه‌های دارای طبقه‌بندی مشاغل"
                  : "سنوات از جدول رسمی (ویژه کارگاه‌های فاقد طبقه‌بندی و گروه ۱) — مطابق بخشنامه مزد ۱۴۰۵"}
              </p>
            </div>
            <div className="flex items-end">
              <Button
                variant="outline" size="sm" disabled={!canEdit}
                className="gap-1.5"
                onClick={() => setF({ ...f, seniorityDailyByYear: [...LEGAL_SENIORITY_DAILY_1405] })}
              >
                <RotateCcw className="w-3.5 h-3.5" /> بازگردانی جدول رسمی ۱۴۰۵
              </Button>
            </div>
          </div>

          {f.seniorityMode === "GRADE" ? (
            <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800 leading-5">
              در حالت «طبقه‌ای»، مبلغ «پایه سنوات هر سال» از تنظیمات «طبقه‌بندی مشاغل» (مدیریت طبقات) خوانده می‌شود و در جدول زیر تغییری لازم نیست.
            </div>
          ) : (
            <div className="max-h-[420px] overflow-y-auto rounded-xl border">
              <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-5 gap-0 divide-x divide-y rtl:divide-x-reverse">
                {(f.seniorityDailyByYear || []).map((daily, i) => (
                  <div key={i} className="p-3 space-y-1.5 bg-white">
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] font-bold text-slate-700">{toFaDigits(i + 1)} سال خدمت</p>
                      <p className="text-[10px] text-muted-foreground tabular-nums">ماهانه {groupFa(Math.round((daily * 30) / 10))} ت</p>
                    </div>
                    <MoneyInput value={Math.round(daily / 10)} onChange={(v) => setSeniorityRow(i, v)} disabled={!canEdit} />
                    <p className="text-[10px] text-muted-foreground">نرخ روزانه تجمیعی (تومان)</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* پله‌های مالیاتی */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            پله‌های مالیاتی حقوق ۱۴۰۵ (ماده ۸۵ قانون بودجه)
            <Badge variant="outline">معافیت ماهانه: {groupFa(f.taxBrackets[0]?.upperLimit || 0)} ریال</Badge>
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">مبالغ ریالی و ماهانه‌اند. پله‌ها باید پیوسته باشند و پله آخر بدون سقف است.</p>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50/80">
                  <TableHead className="text-center">پله</TableHead>
                  <TableHead className="text-left">کف پله (تومان)</TableHead>
                  <TableHead className="text-left">سقف پله (تومان)</TableHead>
                  <TableHead className="text-center">نرخ</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {f.taxBrackets.map((b, i) => (
                  <TableRow key={b.sortOrder}>
                    <TableCell className="text-center font-bold tabular-nums">{toFaDigits(b.sortOrder)}</TableCell>
                    <TableCell className="text-left">
                      <Input
                        dir="ltr"
                        className="text-left tabular-nums h-9 w-44"
                        value={i === 0 ? "۰" : Math.round(b.lowerLimit / 10)}
                        disabled={i === 0 || !canEdit}
                        onChange={(e) => setBrackets(i, "lowerLimit", e.target.value)}
                      />
                    </TableCell>
                    <TableCell className="text-left">
                      {b.upperLimit === null ? (
                        <span className="text-sm text-muted-foreground">بدون سقف (مازاد بر {groupFa(Math.round(b.lowerLimit / 10))} تومان)</span>
                      ) : (
                        <Input
                          dir="ltr"
                          className="text-left tabular-nums h-9 w-44"
                          value={Math.round(b.upperLimit / 10)}
                          disabled={!canEdit}
                          onChange={(e) => setBrackets(i, "upperLimit", e.target.value)}
                        />
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <Input
                          dir="ltr"
                          className="text-center tabular-nums h-9 w-20"
                          value={Math.round(b.rate * 1000) / 10}
                          disabled={!canEdit}
                          onChange={(e) => setBrackets(i, "rate", e.target.value)}
                        />
                        <span className="text-sm font-bold text-slate-600">٪</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* تنظیمات چاپ — نمایش امضای دیجیتال (اطلاعات پایه) */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><StampIcon className="w-4 h-4 text-teal-600" /> تنظیمات چاپ نامه — امضای دیجیتال</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between rounded-xl border px-3.5 py-3">
            <div className="space-y-0.5">
              <p className="text-sm font-medium">نمایش مهر امضای دیجیتال در نامه‌های چاپی/دانلودی</p>
              <p className="text-[11px] text-muted-foreground leading-5">
                وقتی روشن است، نامه‌های تأییدشده با مهر امضای دیجیتال (QR راستی‌آزمایی + کد + نام تأییدکننده) صادر می‌شوند؛
                خاموش = نامه فقط با امضا/نام امضاکننده چاپ می‌شود. راستی‌آزمایی آنلاین کد همچنان از مسیر عمومی ممکن است.
              </p>
            </div>
            <Switch
              checked={lettersCfg.showDigitalSignature}
              onCheckedChange={(v) => setLettersCfg({ ...lettersCfg, showDigitalSignature: v })}
              disabled={!canEdit}
              aria-label="نمایش امضای دیجیتال در چاپ نامه"
            />
          </div>
        </CardContent>
      </Card>

      {canEdit && (
        <div className="flex justify-end sticky bottom-4 z-10">
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-2 shadow-lg px-8 h-11 font-bold">
            <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره اطلاعات پایه"}
          </Button>
        </div>
      )}
        </TabsContent>

        {/* ————— تب مشاغل ————— */}
        <TabsContent value="jobs" className="mt-4">
          <JobsManager canEdit={canEdit} />
        </TabsContent>

        {/* ————— تب تعطیلات و شیفت‌ها ————— */}
        {canHolidays && (
          <TabsContent value="holidays" className="mt-4">
            <HolidaysManager />
          </TabsContent>
        )}

        {/* ————— تب رفاهیات ————— */}
        <TabsContent value="welfare" className="mt-4">
          <WelfareManager canEdit={canWelfare} />
        </TabsContent>

        {/* ————— تب پاداش ————— */}
        <TabsContent value="bonus" className="mt-4">
          <BonusConfigEditor canEdit={canBonus} />
        </TabsContent>

        {/* ————— تب کاربران ————— */}
        {canViewUsers ? (
          <TabsContent value="users" className="mt-4">
            <UsersManager canEdit={canManageUsers} currentUsername={user.username} currentUid={user.uid} />
          </TabsContent>
        ) : null}

        {/* ————— تب نقش‌ها و مجوزها ————— */}
        {canRoles && (
          <TabsContent value="roles" className="mt-4">
            <RolesManager />
          </TabsContent>
        )}

        {/* ————— تب قالب نامه‌ها ————— */}
        {canLetterTemplates && (
          <TabsContent value="letters" className="mt-4 space-y-4">
            <LetterNumberingCard lettersCfg={lettersCfg} setLettersCfg={setLettersCfg} canEdit={canEdit} />
            <LetterSignersCard canEdit={canEdit} signers={lettersSigners} setSigners={setLettersSigners} candidates={signerCandidates} />
            <LetterheadCard canEdit={canEdit} />
            <LetterApprovalFlowsCard canEdit={canEdit} roles={roles} />
            <LetterDownloadPolicyCard canEdit={canEdit} />
            <LetterTemplatesManager canEdit={canLetterTemplates} roles={roles} />
          </TabsContent>
        )}

        {/* ————— تب اطلاعیه تغییرات محصول ————— */}
        {canEdit && (
          <TabsContent value="changelog" className="mt-4">
            <ChangelogCard canEdit={canEdit} roles={data?.roles || []} appVersion={data?.appVersion || ""} />
          </TabsContent>
        )}

        {/* ————— تب برندینگ ————— */}
        <TabsContent value="branding" className="mt-4">
          <BrandingCard canEdit={canEdit} />
        </TabsContent>

        {/* ————— تب ورود و امنیت ————— */}
        {canEdit && (
          <TabsContent value="auth" className="mt-4 space-y-4">
            <TwoFactorSettings canEdit={canEdit} />
            <GoogleLoginSettings canEdit={canEdit} roles={roles} />
          </TabsContent>
        )}

        {/* ————— تب ورود Mattermost ————— */}
        {canEdit && (
          <TabsContent value="mattermost" className="mt-4">
            <MattermostSettings canEdit={canEdit} roles={roles} />
          </TabsContent>
        )}

        {/* ————— تب حذف داده نمونه (فقط مدیر کل) ————— */}
        {canPurge && (
          <TabsContent value="purge" className="mt-4">
            <PurgeDemoManager />
          </TabsContent>
        )}

        {/* ————— تب پشتیبان‌گیری و بازیابی (فقط مدیر کل) ————— */}
        {canBackup && (
          <TabsContent value="backup" className="mt-4">
            <BackupManager />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}

// ================= تنظیمات شماره‌گذاری و امضاکننده نامه‌ها — الگوی ZDX_AD_0507019 =================
function LetterNumberingCard({
  lettersCfg,
  setLettersCfg,
  canEdit,
}: {
  lettersCfg: { numberingPrefix: string; signerName: string; signerTitle: string; showDigitalSignature: boolean };
  setLettersCfg: Dispatch<SetStateAction<{ numberingPrefix: string; signerName: string; signerTitle: string; showDigitalSignature: boolean }>>;
  canEdit: boolean;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    try {
      await api("/api/settings", { method: "PUT", json: { letters: { ...lettersCfg, numberingPrefix: lettersCfg.numberingPrefix.toUpperCase().replace(/[^A-Z0-9]/g, "") } } });
      toast({ title: "تنظیمات نامه‌ها ذخیره شد", description: "شماره‌گذاری نامه‌های جدید از الگوی جدید پیروی می‌کند." });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  const prefix = (lettersCfg.numberingPrefix || "ZDX").toUpperCase().replace(/[^A-Z0-9]/g, "");
  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><FileText className="w-4 h-4 text-blue-600" /> شماره‌گذاری و امضاکننده نامه‌ها</CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          شماره نامه‌های جدید مطابق الگوی مکاتبات رسمی صادر می‌شود:{" "}
          <span className="font-mono text-[10px] bg-slate-100 rounded px-1.5 py-0.5" dir="ltr">{prefix}_AD_YYMMNNN</span>{" "}
          (پیش‌شماره سازمان _ کد دسته _ سال/ماه دوعقمی _ دنباله سه‌رقمی).
        </p>
      </CardHeader>
      <CardContent className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="space-y-1.5">
          <Label className="text-xs">پیش‌شماره سازمان</Label>
          <Input
            dir="ltr"
            className="text-left font-mono uppercase"
            value={lettersCfg.numberingPrefix}
            disabled={!canEdit}
            onChange={(e) => setLettersCfg({ ...lettersCfg, numberingPrefix: e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 6) })}
            placeholder="ZDX"
          />
          <p className="text-[10px] text-muted-foreground">۲ تا ۶ نویسه لاتین/عدد — مثل ZDX</p>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">نام امضاکننده پیش‌فرض</Label>
          <Input value={lettersCfg.signerName} disabled={!canEdit} onChange={(e) => setLettersCfg({ ...lettersCfg, signerName: e.target.value })} placeholder="نام کامل مدیر عامل" />
          <p className="text-[10px] text-muted-foreground">پیش‌فرض فرم ثبت نامه دستی</p>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">سمت امضاکننده پیش‌فرض</Label>
          <Input value={lettersCfg.signerTitle} disabled={!canEdit} onChange={(e) => setLettersCfg({ ...lettersCfg, signerTitle: e.target.value })} placeholder="مدیر عامل" />
          <p className="text-[10px] text-muted-foreground">زیر نام در بلوک امضای نامه</p>
        </div>
        <div className="sm:col-span-3">
          <p className="text-[11px] text-muted-foreground leading-5">
            کد دسته: <b>AD</b> اداری • <b>HR</b> منابع انسانی • <b>FN</b> مالی • <b>GN</b> عمومی — دنباله هر ماه/دسته از ۰۰۱ شروع می‌شود.
          </p>
        </div>
        {canEdit && (
          <div className="sm:col-span-3 flex justify-start">
            <Button onClick={save} disabled={saving} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
              <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره تنظیمات نامه‌ها"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ================= امضاکنندگان مجاز نامه‌ها — دراپ‌داون فرم ثبت نامه دستی + تصویر امضا =================
/** کوچک‌سازی تصویر امضا در مرورگر — عرض حداکثر ۴۸۰px، PNG (حفظ شفافیت اسکن امضا) */
async function downscaleSignature(file: File): Promise<string> {
  if (!["image/png", "image/jpeg"].includes(file.type)) throw new Error("فرمت باید PNG یا JPG باشد");
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error("تصویر قابل خواندن نیست"));
      im.src = url;
    });
    const MAXW = 480;
    const scale = Math.min(1, MAXW / (img.width || 1));
    const w = Math.max(1, Math.round((img.width || 1) * scale));
    const h = Math.max(1, Math.round((img.height || 1) * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("پردازش تصویر ممکن نیست");
    ctx.drawImage(img, 0, 0, w, h);
    const dataUrl = canvas.toDataURL("image/png");
    const bytes = Math.floor((dataUrl.length * 3) / 4);
    if (bytes > 1024 * 1024) throw new Error("تصویر امضا پس از فشرده‌سازی همچنان بزرگ است");
    return dataUrl;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function LetterSignersCard({
  canEdit,
  signers,
  setSigners,
  candidates,
}: {
  canEdit: boolean;
  signers: { name: string; title: string; userId?: string; username?: string; signature?: string; seal?: string }[];
  setSigners: (v: { name: string; title: string; userId?: string; username?: string; signature?: string; seal?: string }[]) => void;
  candidates: { id: string; username: string; fullName: string; role: string; jobTitle: string }[];
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);

  function add() {
    setSigners([...signers, { name: "", title: "", userId: "", username: "", signature: "", seal: "" }]);
  }
  function upd(idx: number, patch: Partial<{ name: string; title: string; userId: string; username: string; signature: string; seal: string }>) {
    const next = [...signers];
    next[idx] = { ...next[idx], ...patch };
    setSigners(next);
  }
  /** انتخاب نفر از دراپ‌داون — نام از پروفایل، سمت از شغل کارمند (قابل ویرایش) */
  function pickUser(idx: number, userId: string) {
    const u = candidates.find((c) => c.id === userId);
    if (!u) {
      upd(idx, { userId: "", username: "" });
      return;
    }
    const current = signers[idx];
    upd(idx, {
      userId: u.id,
      username: u.username,
      name: u.fullName,
      title: current.title || u.jobTitle || "",
    });
  }
  function del(idx: number) {
    setSigners(signers.filter((_, i) => i !== idx));
  }

  function pickSignature(idx: number) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/png,image/jpeg";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const dataUrl = await downscaleSignature(file);
        upd(idx, { signature: dataUrl });
      } catch (e) {
        toast({ title: "خطا در تصویر امضا", description: e instanceof Error ? e.message : "", variant: "destructive" });
      }
    };
    input.click();
  }

  function pickSeal(idx: number) {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = "image/png,image/jpeg";
    input.onchange = async () => {
      const file = input.files?.[0];
      if (!file) return;
      try {
        const dataUrl = await downscaleSignature(file); // همان کوچک‌سازی (عرض ≤۴۸۰px)
        upd(idx, { seal: dataUrl });
      } catch (e) {
        toast({ title: "خطا در تصویر مهر", description: e instanceof Error ? e.message : "", variant: "destructive" });
      }
    };
    input.click();
  }

  async function save() {
    const cleaned = signers
      .map((s) => ({ name: s.name.trim(), title: s.title.trim(), userId: (s.userId || "").trim(), username: (s.username || "").trim(), signature: s.signature || "", seal: s.seal || "" }))
      .filter((s) => s.userId || s.name);
    if (signers.some((s) => (s.userId || s.name).trim() && !s.title.trim())) {
      toast({ title: "سمت هر امضاکننده را تکمیل کنید", variant: "destructive" });
      return;
    }
    const linked = cleaned.filter((s) => s.userId);
    const linkedIds = new Set<string>();
    for (const s of linked) {
      if (linkedIds.has(s.userId)) {
        toast({ title: "هر کاربر فقط یک‌بار می‌تواند امضاکننده باشد", description: "کاربر تکراری را حذف کنید.", variant: "destructive" });
        return;
      }
      linkedIds.add(s.userId);
    }
    setSaving(true);
    try {
      await api("/api/settings", { method: "PUT", json: { letters: { signers: cleaned } } });
      setSigners(cleaned);
      toast({
        title: "امضاکنندگان مجاز ذخیره شد",
        description: linked.length > 0
          ? `${toFaDigits(linked.length)} امضاکننده متصل به حساب کاربری — نامه دستی پس از مراحل تأیید به کارتابل خودشان می‌رود و خودشان امضا می‌کنند. تصویر امضا در چاپ/دانلود کنار نام چاپ می‌شود.`
          : "فهرست در فرم «ثبت نامه دستی» به‌عنوان دراپ‌داون نمایش داده می‌شود؛ تصویر امضا در چاپ/دانلود نامه کنار نام امضاکننده می‌آید.",
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><UserCog className="w-4 h-4 text-blue-600" /> امضاکنندگان مجاز نامه‌ها</CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          امضاکننده را حتماً از دراپ‌داون «نفرات سامانه» (کاربران فعال) انتخاب کنید — نام خودکار پر می‌شود و سمت از شغل کارمند پیشنهاد می‌شود (قابل ویرایش).
          امضاکننده متصل به حساب، نامه دستی را پس از مراحل تأیید در <b>کارتابل خودش</b> می‌بیند و <b>خودش امضا و تأیید نهایی</b> می‌کند.
          اگر «تصویر امضا» آپلود کنید، امضای دست‌نویس همان شخص کنار نامش در چاپ/دانلود نامه (هر سه حالت سربرگ) نمایش داده می‌شود.
        </p>
      </CardHeader>
      <CardContent className="space-y-2">
        {signers.length === 0 && (
          <p className="text-[11px] text-muted-foreground rounded-lg border border-dashed p-3 text-center">
            هنوز امضاکننده‌ای تعریف نشده — با دکمه «افزودن امضاکننده» و انتخاب نفر از فهرست شروع کنید (حداکثر ۲۰ نفر).
          </p>
        )}
        {signers.map((s, idx) => (
          <div key={idx} className="bg-slate-50/70 border rounded-xl p-2 space-y-2">
            <div className="grid grid-cols-12 gap-2 items-center">
              <div className="col-span-6 space-y-1">
                <Label className="text-[10px]">نفر امضاکننده (از فهرست کاربران) <span className="text-rose-500">*</span></Label>
                <select
                  className="w-full h-8 text-xs rounded-md border border-input bg-transparent px-2"
                  value={s.userId || ""}
                  disabled={!canEdit}
                  onChange={(e) => pickUser(idx, e.target.value)}
                  dir="rtl"
                >
                  <option value="">— انتخاب کنید —</option>
                  {candidates.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.fullName}{c.jobTitle ? ` (${c.jobTitle})` : ""}{c.username ? ` — ${c.username}` : ""}
                    </option>
                  ))}
                </select>
              </div>
              <div className="col-span-4 space-y-1">
                <Label className="text-[10px]">سمت در بلوک امضا</Label>
                <Input className="h-8 text-xs" value={s.title} disabled={!canEdit} onChange={(e) => upd(idx, { title: e.target.value })} placeholder={s.userId ? "سمت از پروفایل — قابل ویرایش" : "مدیر عامل / مدیر منابع انسانی"} />
              </div>
              <div className="col-span-2 flex justify-center">
                <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-rose-600" disabled={!canEdit} onClick={() => del(idx)} title="حذف">
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
            {s.userId ? (
              <p className="text-[10px] text-violet-700 bg-violet-50/70 border border-violet-100 rounded-lg px-2 py-1.5 leading-4 flex items-center gap-1">
                <UserCog className="w-3 h-3 shrink-0" /> متصل به حساب «{s.username}» — امضای نامه در کارتابل خود این نفر انجام می‌شود.
                {!s.name && <span className="text-rose-600">(نام از پروفایل پس از انتخاب پر می‌شود)</span>}
              </p>
            ) : s.name ? (
              <p className="text-[10px] text-amber-700 bg-amber-50/70 border border-amber-100 rounded-lg px-2 py-1.5 leading-4">
                امضاکننده آزاد (بدون اتصال به حساب) — تأیید نامه با روال نقشی کلاسیک انجام می‌شود؛ برای امضا در کارتابل خودش، از دراپ‌داون کاربر انتخاب کنید.
              </p>
            ) : null}
            <div className="flex items-center gap-2 flex-wrap border-t pt-2">
              <Button size="sm" variant="outline" className="h-7 gap-1 text-[11px]" disabled={!canEdit} onClick={() => pickSignature(idx)}>
                <ImageIcon className="w-3.5 h-3.5" /> {s.signature ? "تعویض تصویر امضا" : "آپلود تصویر امضا"}
              </Button>
              {s.signature ? (
                <>
                  <img src={s.signature} alt="امضا" className="h-9 max-w-[110px] object-contain border rounded bg-white px-1" />
                  <Button size="sm" variant="ghost" className="h-7 text-[10px] text-rose-600 gap-0.5" disabled={!canEdit} onClick={() => upd(idx, { signature: "" })}>
                    <Trash2 className="w-3 h-3" /> حذف امضا
                  </Button>
                </>
              ) : (
                <span className="text-[10px] text-muted-foreground">PNG/JPG امضای دست‌نویس (پس‌زمینه شفاف بهتر است) — اختیاری</span>
              )}
            </div>
            {/* مهر سازمان/شخص — فقط در نسخه «با سربرگ» چاپ می‌شود */}
            <div className="flex items-center gap-2 flex-wrap border-t pt-2 bg-amber-50/40 rounded-b-xl -mx-2 px-2 pb-1">
              <Button size="sm" variant="outline" className="h-7 gap-1 text-[11px] border-amber-300 text-amber-800 hover:bg-amber-50" disabled={!canEdit} onClick={() => pickSeal(idx)}>
                <StampIcon className="w-3.5 h-3.5" /> {s.seal ? "تعویض تصویر مهر" : "آپلود تصویر مهر"}
              </Button>
              {s.seal ? (
                <>
                  <img src={s.seal} alt="مهر" className="h-10 w-10 object-contain border rounded-full bg-white p-0.5" />
                  <Button size="sm" variant="ghost" className="h-7 text-[10px] text-rose-600 gap-0.5" disabled={!canEdit} onClick={() => upd(idx, { seal: "" })}>
                    <Trash2 className="w-3 h-3" /> حذف مهر
                  </Button>
                </>
              ) : (
                <span className="text-[10px] text-muted-foreground">PNG/JPG مهر سازمان یا مهر شخصی — فقط در نامه «با سربرگ» چاپ می‌شود (اختیاری)</span>
              )}
            </div>
          </div>
        ))}
        {canEdit && (
          <div className="flex gap-2 pt-1">
            <Button variant="outline" size="sm" className="gap-1" onClick={add} disabled={signers.length >= 20}>
              <UserCog className="w-3.5 h-3.5" /> افزودن امضاکننده
            </Button>
            <Button size="sm" onClick={save} disabled={saving} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
              <Save className="w-3.5 h-3.5" /> {saving ? "در حال ذخیره..." : "ذخیره امضاکنندگان"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ================= اطلاعیه تغییرات محصول — پاپ‌آپ «تازه‌های نسخه» با هدف‌گیری کاربران =================
const CHANGELOG_TAGS: { key: "NEW" | "IMPROVED" | "FIXED"; label: string }[] = [
  { key: "NEW", label: "جدید" },
  { key: "IMPROVED", label: "بهبود" },
  { key: "FIXED", label: "رفع اشکال" },
];

function ChangelogCard({ canEdit, roles, appVersion }: { canEdit: boolean; roles: { key: string; name: string }[]; appVersion: string }) {
  const { data, refetch } = useApi<{
    changelog: { version: string; title: string; enabled: boolean; targetAll: boolean; roles: string[]; usernames: string[]; updatedAt: string; items: { tag: string; title: string; desc: string }[] };
    appVersion: string;
  }>("/api/settings");
  const [f, setF] = useState<{ version: string; title: string; enabled: boolean; targetAll: boolean; roles: string[]; usernames: string[]; items: { tag: "NEW" | "IMPROVED" | "FIXED"; title: string; desc: string }[] } | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const [lastKey, setLastKey] = useState<string>("");

  // مقداردهی فرم از داده سرور — یک بار برای هر بارگذاری
  useEffect(() => {
    const c = data?.changelog;
    if (!c) return;
    const key = `${c.version}|${c.updatedAt}|${c.items.length}`;
    if (lastKey === key) return;
    setLastKey(key);
    setF({
      version: c.version || appVersion,
      title: c.title,
      enabled: c.enabled,
      targetAll: c.targetAll,
      roles: [...c.roles],
      usernames: [...c.usernames],
      items: (c.items.length > 0 ? c.items : []).map((it) => ({
        tag: (["NEW", "IMPROVED", "FIXED"].includes(it.tag) ? it.tag : "NEW") as "NEW" | "IMPROVED" | "FIXED",
        title: it.title,
        desc: it.desc,
      })),
    });
  }, [data, appVersion, lastKey]);

  if (!f) return <Skeleton className="h-72 rounded-2xl" />;
  const fc = f; // نام مستعار غیرنل — توابع پایین‌تر از این نگهبان تعریف می‌شوند

  function addItem() {
    setF({ ...fc, items: [...fc.items, { tag: "NEW", title: "", desc: "" }] });
  }
  function updItem(idx: number, patch: Partial<{ tag: "NEW" | "IMPROVED" | "FIXED"; title: string; desc: string }>) {
    const items = [...fc.items];
    items[idx] = { ...items[idx], ...patch };
    setF({ ...fc, items });
  }
  function delItem(idx: number) {
    setF({ ...fc, items: fc.items.filter((_, i) => i !== idx) });
  }
  function toggleRole(key: string) {
    setF({ ...fc, roles: fc.roles.includes(key) ? fc.roles.filter((r) => r !== key) : [...fc.roles, key] });
  }

  async function save() {
    if (fc.enabled && !fc.version.trim()) {
      toast({ title: "نسخه اطلاعیه را مشخص کنید", description: "معمولاً همان نسخه نصب‌شده — با تغییر آن، پاپ‌آپ دوباره برای همه مخاطبان نمایش داده می‌شود.", variant: "destructive" });
      return;
    }
    if (fc.enabled && fc.items.length === 0) {
      toast({ title: "حداقل یک آیتم تغییر وارد کنید", variant: "destructive" });
      return;
    }
    if (fc.enabled && fc.items.some((it) => !it.title.trim())) {
      toast({ title: "عنوان همه آیتم‌ها را تکمیل کنید", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/settings", {
        method: "PUT",
        json: {
          changelog: {
            version: fc.version.trim(),
            title: fc.title.trim(),
            enabled: fc.enabled,
            targetAll: fc.targetAll,
            roles: fc.targetAll ? [] : fc.roles,
            usernames: fc.targetAll ? [] : fc.usernames,
            items: fc.items.map((it) => ({ tag: it.tag, title: it.title.trim(), desc: it.desc.trim() })),
          },
        },
      });
      toast({
        title: `اطلاعیه ${fc.enabled ? "فعال" : "غیرفعال"} شد`,
        description: fc.enabled
          ? fc.targetAll
            ? "پاپ‌آپ «تازه‌های نسخه» برای همه کاربران (که این نسخه را ندیده‌اند) نمایش داده می‌شود."
            : `فقط برای نقش‌ها/کاربران منتخب (${toFaDigits(fc.roles.length)} نقش + ${toFaDigits(fc.usernames.length)} کاربر) نمایش داده می‌شود.`
          : "پاپ‌آپ برای هیچ کاربری نمایش داده نمی‌شود.",
      });
      refetch();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-teal-600" /> اطلاعیه تغییرات محصول (پاپ‌آپ «تازه‌های نسخه»)
          <Badge className={f.enabled ? "bg-teal-100 text-teal-700 hover:bg-teal-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
            {f.enabled ? "فعال" : "غیرفعال"}
          </Badge>
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          آخرین تغییرات محصول را اینجا بنویسید تا هنگام ورود، در یک پاپ‌آپ زیبا به کاربران نمایش داده شود.
          می‌توانید تعیین کنید اطلاعیه برای <b>همه کاربران</b> یا فقط <b>نقش‌ها/کاربران منتخب</b> (بر اساس دسترسی‌ها) نمایش داده شود؛
          هر کاربر فقط یک بار (تا تغییر نسخه اطلاعیه) آن را می‌بیند. نسخه نصب‌شده فعلی: {appVersion ? toFaDigits(appVersion) : "—"}
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* فعال/غیرفعال + نسخه + عنوان */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-end">
          <div className="sm:col-span-3 space-y-1">
            <Label className="text-xs">نمایش پاپ‌آپ</Label>
            <div className="flex items-center gap-2 h-9">
              <Switch checked={f.enabled} disabled={!canEdit} onCheckedChange={(v) => setF({ ...f, enabled: v })} />
              <span className="text-xs text-muted-foreground">{f.enabled ? "فعال" : "خاموش"}</span>
            </div>
          </div>
          <div className="sm:col-span-3 space-y-1">
            <Label className="text-xs">نسخه اطلاعیه</Label>
            <Input dir="ltr" className="text-left tabular-nums" value={f.version} disabled={!canEdit} onChange={(e) => setF({ ...f, version: e.target.value })} placeholder={appVersion || "2.7.0"} />
          </div>
          <div className="sm:col-span-6 space-y-1">
            <Label className="text-xs">عنوان اطلاعیه (خالی = «تازه‌های نسخه …»)</Label>
            <Input value={f.title} disabled={!canEdit} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="مثال: امکانات جدید سامانه منابع انسانی" />
          </div>
        </div>

        {/* هدف‌گیری */}
        <div className="rounded-xl border bg-slate-50/60 p-3 space-y-2">
          <div className="flex items-center gap-3 flex-wrap">
            <Label className="text-xs font-bold">نمایش برای چه کسانی؟</Label>
            <label className="flex items-center gap-1.5 text-xs cursor-pointer">
              <input type="radio" name="cl-target" checked={f.targetAll} disabled={!canEdit} onChange={() => setF({ ...f, targetAll: true })} />
              همه کاربران
            </label>
            <label className="flex items-center gap-1.5 text-xs cursor-pointer">
              <input type="radio" name="cl-target" checked={!f.targetAll} disabled={!canEdit} onChange={() => setF({ ...f, targetAll: false })} />
              نقش‌ها / کاربران منتخب
            </label>
          </div>
          {!f.targetAll && (
            <>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {roles.map((r) => (
                  <button
                    key={r.key}
                    type="button"
                    disabled={!canEdit}
                    onClick={() => toggleRole(r.key)}
                    className={`text-[10px] px-2 py-1 rounded-lg border transition-colors ${
                      f.roles.includes(r.key) ? "bg-teal-600 text-white border-teal-600" : "bg-white text-slate-600 border-slate-200 hover:border-teal-300"
                    }`}
                  >
                    {r.name}
                  </button>
                ))}
              </div>
              <div className="space-y-1">
                <Label className="text-[10px]">کاربران خاص (نام کاربری، جدا با ویرگول)</Label>
                <Input
                  dir="ltr"
                  className="text-left text-xs h-8"
                  value={f.usernames.join(", ")}
                  disabled={!canEdit}
                  onChange={(e) => setF({ ...f, usernames: e.target.value.split(",").map((u) => u.trim()).filter(Boolean) })}
                  placeholder="ceo, hr.manager"
                />
              </div>
            </>
          )}
        </div>

        {/* آیتم‌های تغییرات */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label className="text-xs font-bold">فهرست تغییرات ({toFaDigits(f.items.length)})</Label>
            {canEdit && (
              <Button variant="outline" size="sm" className="h-7 gap-1 text-[11px]" onClick={addItem} disabled={f.items.length >= 15}>
                <Plus className="w-3.5 h-3.5" /> افزودن آیتم
              </Button>
            )}
          </div>
          {f.items.length === 0 && (
            <p className="text-[11px] text-muted-foreground rounded-lg border border-dashed p-3 text-center">
              هنوز آیتمی ثبت نشده — مثال: «جدید» / «امضای نامه در کارتابل امضاکننده» / «نامه دستی پس از تأیید به کارتابل نفر منتخب می‌رود و خودش امضا می‌کند».
            </p>
          )}
          {f.items.map((it, idx) => (
            <div key={idx} className="rounded-xl border bg-white p-2.5 space-y-2">
              <div className="grid grid-cols-12 gap-2 items-center">
                <div className="col-span-3 sm:col-span-2">
                  <select
                    className="w-full h-8 text-xs rounded-md border border-input bg-transparent px-2"
                    value={it.tag}
                    disabled={!canEdit}
                    onChange={(e) => updItem(idx, { tag: e.target.value as "NEW" | "IMPROVED" | "FIXED" })}
                    dir="rtl"
                  >
                    {CHANGELOG_TAGS.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
                  </select>
                </div>
                <div className="col-span-8 sm:col-span-9">
                  <Input className="h-8 text-xs" value={it.title} disabled={!canEdit} onChange={(e) => updItem(idx, { title: e.target.value })} placeholder="عنوان کوتاه تغییر — مثال: تفکیک حقوق سطح به پایه/مسولیت/شایستگی" />
                </div>
                <div className="col-span-1 flex justify-end">
                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-rose-600" disabled={!canEdit} onClick={() => delItem(idx)} title="حذف">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
              <Input className="h-8 text-xs" value={it.desc} disabled={!canEdit} onChange={(e) => updItem(idx, { desc: e.target.value })} placeholder="توضیح (اختیاری) — در پاپ‌آپ زیر عنوان نمایش داده می‌شود" />
            </div>
          ))}
        </div>

        {canEdit && (
          <div className="flex items-center gap-2 pt-1 border-t">
            <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
              <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره اطلاعیه"}
            </Button>
            {data?.changelog?.updatedAt && (
              <span className="text-[10px] text-muted-foreground">آخرین ذخیره: {new Date(data.changelog.updatedAt).toLocaleString("fa-IR")}</span>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ================= تصویر سربرگ رسمی شرکت (PNG) — پس‌زمینه نامه‌های چاپی =================
const LETTERHEAD_MAX_MB = 3;

function LetterheadCard({ canEdit }: { canEdit: boolean }) {
  const { data, refetch } = useApi<{ a4: string; a5: string; a4TopMm: number; a4BottomMm: number; a5TopMm: number; a5BottomMm: number }>("/api/letters/letterhead");
  const [a4, setA4] = useState("");
  const [a5, setA5] = useState("");
  const [margins, setMargins] = useState({ a4TopMm: 42, a4BottomMm: 16, a5TopMm: 30, a5BottomMm: 12 });
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const initialized = useRef(false);

  useEffect(() => {
    if (data && !initialized.current) {
      initialized.current = true;
      setA4(data.a4 || "");
      setA5(data.a5 || "");
      setMargins({
        a4TopMm: data.a4TopMm ?? 42,
        a4BottomMm: data.a4BottomMm ?? 16,
        a5TopMm: data.a5TopMm ?? 30,
        a5BottomMm: data.a5BottomMm ?? 12,
      });
    }
  }, [data]);

  function pickImage(setter: (v: string) => void, what: string) {
    return (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      if (!["image/png", "image/jpeg"].includes(file.type)) {
        toast({ title: `فرمت ${what} باید PNG باشد`, variant: "destructive" });
        e.target.value = "";
        return;
      }
      if (file.size > LETTERHEAD_MAX_MB * 1024 * 1024) {
        toast({ title: `حجم ${what} بیش از حد مجاز است`, description: `حداکثر ${toFaDigits(LETTERHEAD_MAX_MB)} مگابایت.`, variant: "destructive" });
        e.target.value = "";
        return;
      }
      const reader = new FileReader();
      reader.onload = () => setter(String(reader.result || ""));
      reader.readAsDataURL(file);
    };
  }

  async function save() {
    setSaving(true);
    try {
      await api("/api/letters/letterhead", { method: "PUT", json: { a4, a5, ...margins } });
      await refetch();
      toast({
        title: "سربرگ رسمی ذخیره شد",
        description: (a4 || a5) ? "از این پس نامه‌ها روی این تصویر چاپ/دانلود می‌شوند." : "تصاویر سربرگ حذف شدند — سربرگ دیجیتال جایگزین می‌شود.",
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  const slot = (size: "A4" | "A5", img: string, setImg: (v: string) => void, topKey: "a4TopMm" | "a5TopMm", bottomKey: "a4BottomMm" | "a5BottomMm") => (
    <div className="rounded-xl border border-slate-200 p-4 space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-xs font-bold flex items-center gap-1.5">
          <ImageIcon className="w-3.5 h-3.5 text-blue-600" /> سربرگ {size}
          <span className="font-normal text-muted-foreground">{size === "A4" ? "(۲۱۰×۲۹۷ میلی‌متر)" : "(۱۴۸×۲۱۰ میلی‌متر)"}</span>
        </p>
        {img && canEdit && (
          <button className="text-[10px] text-rose-600 hover:text-rose-800 flex items-center gap-1" onClick={() => setImg("")}>
            <X className="w-3 h-3" /> حذف
          </button>
        )}
      </div>
      <div className="flex items-start gap-3">
        {/* پیش‌نمایش با نسبت واقعی کاغذ (۱:√۲) */}
        <div className="w-[84px] h-[119px] rounded-md border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden bg-slate-50 shrink-0 relative">
          {img ? (
            <img src={img} alt={`سربرگ ${size}`} className="w-full h-full object-fill" />
          ) : (
            <span className="text-[10px] text-muted-foreground text-center leading-4 px-1">آپلود نشده</span>
          )}
        </div>
        <div className="flex-1 space-y-2 min-w-0">
          {canEdit && (
            <label className="cursor-pointer block">
              <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-700 border border-blue-200 rounded-lg px-3 py-2 hover:bg-blue-50 transition-colors">
                <Upload className="w-3.5 h-3.5" /> انتخاب تصویر PNG
              </span>
              <input type="file" accept="image/png,image/jpeg" className="hidden" onChange={pickImage(setImg, `سربرگ ${size}`)} />
            </label>
          )}
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <Label className="text-[10px]">فاصله محتوا از بالا (mm)</Label>
              <Input
                dir="ltr"
                className="h-8 text-xs text-left"
                value={margins[topKey]}
                disabled={!canEdit}
                onChange={(e) => setMargins({ ...margins, [topKey]: parseInt(e.target.value.replace(/\D/g, ""), 10) || 0 })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-[10px]">فاصله از پایین (mm)</Label>
              <Input
                dir="ltr"
                className="h-8 text-xs text-left"
                value={margins[bottomKey]}
                disabled={!canEdit}
                onChange={(e) => setMargins({ ...margins, [bottomKey]: parseInt(e.target.value.replace(/\D/g, ""), 10) || 0 })}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2"><ImageIcon className="w-4 h-4 text-blue-600" /> سربرگ رسمی شرکت (تصویر)</CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          فایل PNG سربرگ رسمی را در دو سایز A4 و A5 بارگذاری کنید — در چاپ/دانلود نامه‌ها، این تصویر در پس‌زمینه صفحه قرار می‌گیرد
          (به‌جای سربرگ دیجیتال). تاریخ/شماره، متن و امضای دیجیتال روی همین تصویر چاپ می‌شوند؛ با تنظیم فاصله بالا/پایین،
          جای متن را با گرافیک سربرگ خود هماهنگ کنید.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {slot("A4", a4, setA4, "a4TopMm", "a4BottomMm")}
          {slot("A5", a5, setA5, "a5TopMm", "a5BottomMm")}
        </div>
        <p className="text-[11px] text-muted-foreground leading-5">
          PNG یا JPG — حداکثر {toFaDigits(LETTERHEAD_MAX_MB)} مگابایت — رزولوشن بالا (حداقل {toFaDigits(1240)}×{toFaDigits(1754)} پیکسل برای A4) پیشنهاد می‌شود.
          حالت «بدون سربرگ» (چاپ روی کاغذ پیش‌چاپ) از این تصویر استفاده نمی‌کند.
        </p>
        {canEdit && (
          <div className="flex justify-start pt-2 border-t">
            <Button onClick={save} disabled={saving} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
              <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره سربرگ رسمی"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ================= برندینگ (عنوان / نام شرکت / لوگو / فاوآیکون / متن فوتر) =================
function BrandingCard({ canEdit }: { canEdit: boolean }) {
  const { data, refetch } = useApi<{ branding: { title: string; subtitle: string; logo: string; favicon: string; companyName: string; footerText: string; demoMode?: boolean } }>('/api/branding');
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [footerText, setFooterText] = useState("");
  const [logo, setLogo] = useState("");
  const [favicon, setFavicon] = useState("");
  const [demoMode, setDemoMode] = useState(false);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const initialized = useRef(false);

  useEffect(() => {
    if (data?.branding && !initialized.current) {
      initialized.current = true;
      setTitle(data.branding.title || "");
      setSubtitle(data.branding.subtitle || "");
      setCompanyName(data.branding.companyName || "");
      setFooterText(data.branding.footerText || "");
      setLogo(data.branding.logo || "");
      setFavicon(data.branding.favicon || "");
      setDemoMode(!!data.branding.demoMode);
    }
  }, [data]);

  function pickFile(setter: (v: string) => void, what: string) {
    return (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      if (file.size > 200 * 1024) {
        toast({ title: `حجم ${what} بیش از حد مجاز است`, description: "حداکثر ۲۰۰ کیلوبایت.", variant: "destructive" });
        e.target.value = "";
        return;
      }
      const reader = new FileReader();
      reader.onload = () => setter(String(reader.result || ""));
      reader.readAsDataURL(file);
    };
  }

  async function save() {
    setSaving(true);
    try {
      await api("/api/branding", { method: "PUT", json: { title, subtitle, companyName, footerText, logo, favicon, demoMode } });
      await refetch();
      toast({ title: "برندینگ ذخیره شد", description: "عنوان، نام شرکت، فوتر، لوگو، فاوآیکون و حالت دمو به‌روزرسانی شد — برای اعمال کامل صفحه را رفرش کنید." });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  const b = data?.branding;

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2 flex-wrap">
          <Globe className="w-4 h-4 text-teal-600" /> برندینگ سامانه
          {!canEdit && <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">فقط مدیر کل می‌تواند ویرایش کند</Badge>}
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1">عنوان صفحه و منو، نام شرکت (سایدبار/فیش حقوقی/نامه‌ها)، لوگو، آیکون مرورگر و متن پابرگ — همه لوکال ذخیره می‌شوند.</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان سامانه</Label>
            <Input value={title} disabled={!canEdit} onChange={(e) => setTitle(e.target.value)} placeholder="سامانه جامع منابع انسانی" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نام شرکت <span className="text-rose-600">*</span></Label>
            <Input value={companyName} disabled={!canEdit} onChange={(e) => setCompanyName(e.target.value)} placeholder="نام رسمی شرکت — در سایدبار، فیش حقوقی و نامه‌ها" />
            <p className="text-[10px] text-muted-foreground">در «اطلاعات شرکت» (تب پارامترهای قانونی) نیز ذخیره می‌شود و همه خروجی‌های چاپی از آن استفاده می‌کنند.</p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">زیرعنوان (صفحه ورود)</Label>
            <Input value={subtitle} disabled={!canEdit} onChange={(e) => setSubtitle(e.target.value)} placeholder="مدیریت کارکنان، حقوق و دستمزد و محاسبه معکوس — سال ۱۴۰۵" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">متن پابرگ (فوتر)</Label>
            <Input value={footerText} disabled={!canEdit} onChange={(e) => setFooterText(e.target.value)} placeholder="سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵ • مطابق ماده ۸۵ قانون بودجه ۱۴۰۵…" />
            <p className="text-[10px] text-muted-foreground">متن پایین همه صفحات — خالی = متن پیش‌فرض سامانه.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* لوگو */}
          <div className="rounded-xl border border-slate-200 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold flex items-center gap-1.5"><ImageIcon className="w-3.5 h-3.5 text-teal-600" /> لوگو</p>
              {(logo || b?.logo) && canEdit && (
                <button className="text-[10px] text-rose-600 hover:text-rose-800 flex items-center gap-1" onClick={() => setLogo("")}>
                  <X className="w-3 h-3" /> حذف
                </button>
              )}
            </div>
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-xl border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden bg-slate-50 shrink-0">
                {(logo || b?.logo) ? (
                   
                  <img src={logo || b?.logo} alt="لوگو" className="w-full h-full object-contain p-1" />
                ) : (
                  <span className="text-[10px] text-muted-foreground">بدون لوگو</span>
                )}
              </div>
              {canEdit && (
                <label className="cursor-pointer">
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 border border-teal-200 rounded-lg px-3 py-2 hover:bg-teal-50 transition-colors">
                    <Upload className="w-3.5 h-3.5" /> انتخاب تصویر
                  </span>
                  <input type="file" accept="image/png,image/jpeg,image/svg+xml,image/webp" className="hidden" onChange={pickFile(setLogo, "لوگو")} />
                </label>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground">PNG/JPG/SVG/WebP — حداکثر ۲۰۰ کیلوبایت — مربعی پیشنهاد می‌شود</p>
          </div>

          {/* فاوآیکون */}
          <div className="rounded-xl border border-slate-200 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold flex items-center gap-1.5"><ImageIcon className="w-3.5 h-3.5 text-teal-600" /> فاوآیکون (آیکون مرورگر)</p>
              {(favicon || b?.favicon) && canEdit && (
                <button className="text-[10px] text-rose-600 hover:text-rose-800 flex items-center gap-1" onClick={() => setFavicon("")}>
                  <X className="w-3 h-3" /> حذف
                </button>
              )}
            </div>
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-xl border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden bg-slate-50 shrink-0">
                {(favicon || b?.favicon) ? (
                   
                  <img src={favicon || b?.favicon} alt="فاوآیکون" className="w-full h-full object-contain p-2" />
                ) : (
                  <span className="text-[10px] text-muted-foreground">پیش‌فرض</span>
                )}
              </div>
              {canEdit && (
                <label className="cursor-pointer">
                  <span className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 border border-teal-200 rounded-lg px-3 py-2 hover:bg-teal-50 transition-colors">
                    <Upload className="w-3.5 h-3.5" /> انتخاب آیکون
                  </span>
                  <input type="file" accept="image/png,image/svg+xml,image/x-icon,image/webp" className="hidden" onChange={pickFile(setFavicon, "فاوآیکون")} />
                </label>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground">ICO/PNG/SVG — ۳۲×۳۲ یا ۶۴×۶۴ پیکسل</p>
          </div>
        </div>

        {/* حالت دمو — نمایش حساب‌های نمونه در صفحه ورود */}
        <div className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 p-4">
          <div className="min-w-0">
            <p className="text-xs font-bold flex items-center gap-1.5"><Info className="w-3.5 h-3.5 text-amber-600" /> حالت دمو</p>
            <p className="text-[10px] text-muted-foreground mt-1 leading-5">
              نمایش دکمه‌های ورود سریع حساب‌های نمونه (مدیر، منابع انسانی، کارشناس حقوق و…) در صفحه ورود —
              در محیط واقعی خاموش نگه دارید تا اطلاعات ورود نمایش داده نشود.
            </p>
          </div>
          <Switch checked={demoMode} onCheckedChange={setDemoMode} disabled={!canEdit} id="demo-mode" dir="ltr" />
        </div>

        {canEdit && (
          <div className="flex justify-end pt-2 border-t">
            <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-2">
              <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره برندینگ"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

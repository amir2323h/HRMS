import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ApiError, requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { hasPerm } from "@/lib/permissions";
import { ROLE_ACCESS } from "@/lib/roles";

// تغییر گروهی نقش — اعتبارسنجی، حفظ آخرین مدیر فعال و حسابرسی در یک تراکنش
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = await requirePerm(req, "users:manage");
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      throw new ApiError("درخواست نامعتبر است.");
    }
    if (!body || typeof body !== "object" || Array.isArray(body)) {
      throw new ApiError("درخواست نامعتبر است.");
    }
    const { ids: rawIds, roleId: rawRoleId } = body as { ids?: unknown; roleId?: unknown };
    if (!Array.isArray(rawIds) || rawIds.length === 0) {
      throw new ApiError("هیچ کاربری انتخاب نشده است.");
    }
    if (rawIds.length > 500) {
      throw new ApiError("در هر نوبت حداکثر ۵۰۰ کاربر را انتخاب کنید.");
    }
    if (rawIds.some((id) => typeof id !== "string" || !id.trim())) {
      throw new ApiError("شناسه کاربران نامعتبر است.");
    }
    const ids = [...new Set((rawIds as string[]).map((id) => id.trim()))];
    if (ids.includes(session.uid)) {
      throw new ApiError("نقش حساب خودتان را نمی‌توانید با عملیات گروهی تغییر دهید؛ حساب خود را از انتخاب حذف کنید.");
    }
    if (typeof rawRoleId !== "string" || !rawRoleId.trim()) {
      throw new ApiError("انتخاب نقش الزامی است.");
    }
    const roleId = rawRoleId.trim();

    return db.$transaction(async (tx) => {
      // مجوز موجود در نشست ممکن است پیش از تغییر نقش صادر شده باشد.
      const operator = await tx.user.findUnique({
        where: { id: session.uid },
        select: { id: true, fullName: true, role: true, isActive: true, roleRef: { select: { permissions: true } } },
      });
      if (!operator?.isActive) throw new ApiError("نشست معتبر نیست؛ دوباره وارد سامانه شوید.", 401);
      let permissions: string[] = [];
      if (operator.roleRef) {
        try {
          const parsed: unknown = JSON.parse(operator.roleRef.permissions);
          if (Array.isArray(parsed) && parsed.every((item) => typeof item === "string")) permissions = parsed;
        } catch {
          // تعریف نامعتبر نقش هیچ مجوزی ایجاد نمی‌کند.
        }
      } else {
        permissions = (ROLE_ACCESS as Record<string, string[]>)[operator.role] || [];
      }
      if (!hasPerm(permissions, "users:manage")) {
        throw new ApiError("شما به مدیریت کاربران دسترسی ندارید.", 403);
      }

      const role = await tx.role.findUnique({ where: { id: roleId } });
      if (!role) throw new ApiError("نقش انتخاب‌شده یافت نشد.");
      const users = await tx.user.findMany({
        where: { id: { in: ids } },
        select: { id: true, username: true, role: true, roleId: true, isActive: true, roleRef: { select: { key: true, name: true } } },
      });
      if (users.length !== ids.length) {
        throw new ApiError("یک یا چند کاربر انتخاب‌شده یافت نشد؛ فهرست را تازه کنید و دوباره انتخاب کنید.", 404);
      }

      // roleRef مرجع نقش واقعی است؛ role قدیمی فقط برای کاربران فاقد رابطه استفاده می‌شود.
      const removesActiveSuper = role.key !== "SUPER_ADMIN" && users.some((user) =>
        user.isActive && (user.roleRef?.key || user.role) === "SUPER_ADMIN"
      );
      if (removesActiveSuper) {
        const remainingAdmins = await tx.user.count({
          where: {
            isActive: true,
            id: { notIn: ids },
            OR: [
              { roleRef: { is: { key: "SUPER_ADMIN" } } },
              { roleRef: { is: null }, role: "SUPER_ADMIN" },
            ],
          },
        });
        if (remainingAdmins === 0) {
          throw new ApiError("این تغییر نقش، سامانه را بدون مدیر کل فعال می‌گذارد؛ حداقل یک مدیر کل فعال باید باقی بماند.");
        }
      }

      const changed = users.filter((user) => user.role !== role.key || user.roleId !== role.id);
      if (changed.length > 0) {
        await tx.user.updateMany({ where: { id: { in: changed.map((user) => user.id) } }, data: { role: role.key, roleId: role.id } });
        await tx.auditLog.createMany({
          data: changed.map((user) => ({
            userId: operator.id,
            userName: operator.fullName,
            action: "UPDATE",
            entity: "USER",
            entityId: user.id,
            summary: `تغییر گروهی نقش کاربر «${user.username}» به «${role.name}»`,
            before: JSON.stringify({ role: user.role, roleId: user.roleId, roleLabel: user.roleRef?.name || user.role }),
            after: JSON.stringify({ role: role.key, roleId: role.id, roleLabel: role.name }),
          })),
        });
      }
      const unchangedCount = users.length - changed.length;
      await tx.auditLog.create({
        data: {
          userId: operator.id,
          userName: operator.fullName,
          action: "BULK",
          entity: "USER",
          entityId: "bulk",
          summary: `تغییر گروهی نقش به «${role.name}»: ${changed.length} تغییر، ${unchangedCount} بدون تغییر`,
          before: JSON.stringify({ ids }),
          after: JSON.stringify({ role: role.key, roleId: role.id, updatedCount: changed.length, unchangedCount }),
        },
      });
      return { updatedCount: changed.length, unchangedCount, roleLabel: role.name };
    });
  });
}

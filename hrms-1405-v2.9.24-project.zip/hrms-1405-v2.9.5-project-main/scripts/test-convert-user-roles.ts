// Run with: npx tsx scripts/test-convert-user-roles.ts
// All database writes use a newly created temporary SQLite database.
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { NextRequest } from "next/server";

async function main() {
  const tempRoot = path.resolve(tmpdir());
  const tempDir = mkdtempSync(path.join(tempRoot, "hrms-convert-role-"));
  const projectRoot = process.cwd();
  process.env.DATABASE_URL = `file:${path.join(tempDir, "test.db").replace(/\\/g, "/")}`;
  process.env.AUTH_SECRET = "hrms-isolated-conversion-test-secret";
  let disconnect: (() => Promise<void>) | undefined;
  let checked = 0;

  try {
    writeFileSync(path.join(tempDir, "test.db"), "");
    execFileSync(process.execPath, [
      path.join(projectRoot, "node_modules/prisma/build/index.js"),
      "db", "push", "--schema", path.join(projectRoot, "prisma/schema.prisma"), "--skip-generate",
    ], { cwd: projectRoot, env: process.env, stdio: "pipe", encoding: "utf8" });

    const { db } = await import("../src/lib/db");
    const { hashPassword, signSession } = await import("../src/lib/auth");
    const { POST } = await import("../src/app/api/users/from-employees/route");
    disconnect = () => db.$disconnect();

    // Administrator is deliberately inserted first: EMPLOYEE must never fall
    // back to the first role returned by a database query.
    const adminRole = await db.role.create({ data: { key: "SUPER_ADMIN", name: "مدیر کل سیستم", permissions: '["*"]', isSystem: true } });
    const employeeRole = await db.role.create({ data: { key: "EMPLOYEE", name: "کارمند", permissions: '["portal:view"]', isSystem: true } });
    const admin = await db.user.create({ data: { username: "test-admin", fullName: "Test admin", passwordHash: hashPassword("test-password"), role: adminRole.key, roleId: adminRole.id } });
    const token = signSession({ uid: admin.id, username: admin.username, fullName: admin.fullName, role: adminRole.key, perms: ["*"] });

    async function employee(n: number) {
      return db.employee.create({ data: { personnelCode: `test-${n}`, firstName: "Test", lastName: String(n), mobile: `0912${String(n).padStart(7, "0")}`, nationalId: String(n).padStart(10, "0") } });
    }

    async function convert(body: unknown) {
      return POST(new NextRequest("http://localhost/api/users/from-employees", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      }));
    }

    const first = await employee(1);
    const second = await employee(2);
    const response = await convert({ ids: [first.id, second.id], roleKey: "EMPLOYEE" });
    assert.equal(response.status, 200);
    const result = await response.json();
    assert.equal(result.createdCount, 2);
    assert.equal(result.roleKey, "EMPLOYEE");
    assert.equal(result.roleId, employeeRole.id);
    for (const created of result.created) {
      const stored = await db.user.findUniqueOrThrow({ where: { id: created.id }, include: { roleRef: true } });
      assert.equal(created.role, "EMPLOYEE");
      assert.equal(created.roleId, employeeRole.id);
      assert.equal(stored.role, "EMPLOYEE");
      assert.equal(stored.roleId, employeeRole.id);
      assert.equal(stored.roleRef?.key, stored.role);
    }
    const audit = await db.auditLog.findFirstOrThrow({ where: { action: "BULK", entity: "USER" }, orderBy: { createdAt: "desc" } });
    assert.equal(JSON.parse(audit.after || "{}").roleId, employeeRole.id);
    checked++;

    const third = await employee(3);
    const defaultResponse = await convert({ ids: [third.id] });
    assert.equal(defaultResponse.status, 200);
    assert.equal((await db.user.findUniqueOrThrow({ where: { employeeId: third.id } })).role, "EMPLOYEE");
    checked++;

    const fourth = await employee(4);
    for (const roleKey of ["", "   ", null, false, 0, [], {}, "MISSING_ROLE"]) {
      const beforeCount = await db.user.count();
      assert.equal((await convert({ ids: [fourth.id], roleKey })).status, 400);
      assert.equal(await db.user.count(), beforeCount);
      checked++;
    }

    // The intentionally selected administrator role remains supported.
    const intentionalAdmin = await convert({ ids: [fourth.id], roleKey: "SUPER_ADMIN" });
    assert.equal(intentionalAdmin.status, 200);
    const storedAdmin = await db.user.findUniqueOrThrow({ where: { employeeId: fourth.id }, include: { roleRef: true } });
    assert.equal(storedAdmin.role, "SUPER_ADMIN");
    assert.equal(storedAdmin.roleId, adminRole.id);
    assert.equal(storedAdmin.roleRef?.key, storedAdmin.role);
    checked++;

    // Missing EMPLOYEE cannot silently create administrators, including when
    // the role was omitted and the endpoint uses its documented default.
    await db.user.deleteMany({ where: { role: "EMPLOYEE" } });
    await db.role.delete({ where: { id: employeeRole.id } });
    const fifth = await employee(5);
    const beforeMissingCount = await db.user.count();
    assert.equal((await convert({ ids: [fifth.id], roleKey: "EMPLOYEE" })).status, 400);
    assert.equal((await convert({ ids: [fifth.id] })).status, 400);
    assert.equal(await db.user.count(), beforeMissingCount);
    checked += 2;

    console.log(`CONVERSION_ROLE_TEST_OK cases=${checked}`);
  } finally {
    try {
      await disconnect?.();
    } finally {
      const resolved = path.resolve(tempDir);
      if (path.dirname(resolved) === tempRoot && path.basename(resolved).startsWith("hrms-convert-role-")) {
        rmSync(resolved, { recursive: true, force: true });
      }
    }
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

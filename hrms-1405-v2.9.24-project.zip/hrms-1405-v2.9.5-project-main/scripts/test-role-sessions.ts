// Run: npx tsx scripts/test-role-sessions.ts
// This script writes only to its own temporary SQLite database.
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { NextRequest } from "next/server";

async function main() {
  const tempRoot = path.resolve(tmpdir());
  const tempDir = mkdtempSync(path.join(tempRoot, "hrms-session-role-"));
  const database = path.join(tempDir, "test.db");
  writeFileSync(database, "");
  process.env.DATABASE_URL = `file:${database.replace(/\\/g, "/")}`;
  process.env.AUTH_SECRET = "isolated-role-session-test-secret";
  let disconnect: (() => Promise<void>) | undefined;
  let cases = 0;
  try {
    execFileSync(process.execPath, ["node_modules/prisma/build/index.js", "db", "push", "--schema", "prisma/schema.prisma", "--skip-generate"], { env: process.env, stdio: "pipe" });
    const { db } = await import("../src/lib/db");
    const { buildSessionForUser, isSessionCurrent, signSession, verifySessionToken, SESSION_COOKIE } = await import("../src/lib/auth");
    const { proxy } = await import("../src/proxy");
    disconnect = () => db.$disconnect();
    const adminRole = await db.role.create({ data: { key: "SUPER_ADMIN", name: "مدیر کل", permissions: '["*"]', isSystem: true } });
    const employeeRole = await db.role.create({ data: { key: "EMPLOYEE", name: "کارمند", permissions: '["portal:view","docs:view"]', isSystem: true } });
    const admin = await db.user.create({ data: { username: "session-admin", fullName: "Session admin", passwordHash: "unused", role: adminRole.key, roleId: adminRole.id } });
    const token = signSession(await buildSessionForUser(admin));
    const session = verifySessionToken(token)!;
    assert.equal(await isSessionCurrent(session), true);
    const request = (url: string, mode: "bearer" | "cookie" = "bearer") => new NextRequest(`http://localhost${url}`, {
      headers: mode === "cookie" ? { Cookie: `${SESSION_COOKIE}=${token}` } : { Authorization: `Bearer ${token}` },
    });
    assert.equal((await proxy(request("/api/users"))).headers.get("x-middleware-next"), "1");
    cases++;

    // An existing role with empty/corrupt permissions must never regain legacy wildcard access.
    for (const permissions of ["[]", "invalid-json", '"*"', '{"permissions":["*"]}']) {
      await db.role.update({ where: { id: adminRole.id }, data: { permissions } });
      assert.deepEqual((await buildSessionForUser(admin)).perms, []);
      assert.equal(await isSessionCurrent(session), false);
      cases++;
    }
    await db.role.update({ where: { id: adminRole.id }, data: { permissions: '["*"]' } });

    // An already-issued admin token loses access on the very next request.
    await db.user.update({ where: { id: admin.id }, data: { role: employeeRole.key, roleId: employeeRole.id } });
    assert.equal(await isSessionCurrent(session), false);
    for (const mode of ["bearer", "cookie"] as const) {
      for (const url of ["/api/users", "/api/system/version", "/api/auth/me"]) {
        const response = await proxy(request(url, mode));
        assert.equal(response.status, 401);
        assert.equal((await response.json()).code, "SESSION_CHANGED");
        assert.match(response.headers.get("set-cookie") || "", /Max-Age=0/);
        cases++;
      }
    }
    // Stale cookies must not prevent recovery by logging in or out.
    for (const url of ["/api/auth/login", "/api/auth/logout", "/api/auth/google/callback", "/api/auth/mattermost/callback"]) {
      assert.equal((await proxy(request(url))).headers.get("x-middleware-next"), "1");
      cases++;
    }

    const freshUser = await db.user.findUniqueOrThrow({ where: { id: admin.id } });
    const fresh = verifySessionToken(signSession(await buildSessionForUser(freshUser)))!;
    assert.equal(fresh.role, "EMPLOYEE");
    assert.equal(await isSessionCurrent(fresh), true);
    // Permission order and a cosmetic label change do not revoke a valid session.
    await db.role.update({ where: { id: employeeRole.id }, data: { name: "Employee renamed", permissions: '["docs:view","portal:view"]' } });
    assert.equal(await isSessionCurrent(fresh), true);
    cases++;
    await db.role.update({ where: { id: employeeRole.id }, data: { permissions: '["portal:view"]' } });
    assert.equal(await isSessionCurrent(fresh), false);
    cases++;

    // A legacy field mismatch must not turn an employee into a role-only administrator.
    const mismatched = await db.user.update({ where: { id: admin.id }, data: { role: "SUPER_ADMIN", roleId: employeeRole.id } });
    const canonical = await buildSessionForUser(mismatched);
    assert.equal(canonical.role, "EMPLOYEE");
    assert.deepEqual(canonical.perms, ["portal:view"]);
    assert.equal(await isSessionCurrent(session), false);
    cases++;
    const canonicalSession = verifySessionToken(signSession(canonical))!;
    await db.user.update({ where: { id: admin.id }, data: { isActive: false } });
    assert.equal(await isSessionCurrent(canonicalSession), false);
    cases++;
    await db.user.delete({ where: { id: admin.id } });
    assert.equal(await isSessionCurrent(canonicalSession), false);
    cases++;

    assert.equal((await proxy(new NextRequest("http://localhost/api/auth/me"))).headers.get("x-middleware-next"), "1");
    assert.equal((await proxy(new NextRequest("http://localhost/api/users", { headers: { Authorization: "Bearer invalid" } }))).headers.get("x-middleware-next"), "1");
    cases++;
    console.log(`ROLE_SESSION_TEST_OK cases=${cases}`);
  } finally {
    await disconnect?.();
    const resolved = path.resolve(tempDir);
    if (path.dirname(resolved) === tempRoot && path.basename(resolved).startsWith("hrms-session-role-")) rmSync(resolved, { recursive: true, force: true });
  }
}

main().catch((error) => { console.error(error); process.exitCode = 1; });

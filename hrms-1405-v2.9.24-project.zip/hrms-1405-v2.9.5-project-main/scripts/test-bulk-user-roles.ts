// اجرا: npx tsx scripts/test-bulk-user-roles.ts
// فقط یک دیتابیس SQLite موقت و مستقل ساخته و در پایان حذف می‌شود.
import assert from "node:assert/strict";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

async function main() {
  const testDir = mkdtempSync(path.join(tmpdir(), "hrms-bulk-role-test-"));
  const root = process.cwd();
  const fixturePath = path.join(testDir, "fixture.db");
  writeFileSync(fixturePath, "");
  process.env.DATABASE_URL = `file:${fixturePath.replace(/\\/g, "/")}`;
  process.env.AUTH_SECRET = "bulk-role-isolated-fixture-secret";
  const init = spawnSync(process.execPath, [
    path.join(root, "node_modules/prisma/build/index.js"),
    "db", "push", "--skip-generate", "--schema", path.join(root, "prisma/schema.prisma"),
  ], { cwd: root, env: process.env, encoding: "utf8" });
  let disconnect: (() => Promise<void>) | undefined;

  try {
    assert.equal(init.status, 0, `${init.stdout}\n${init.stderr}`);
    const { db } = await import("../src/lib/db");
    disconnect = () => db.$disconnect();
    const { NextRequest } = await import("next/server");
    const { signSession } = await import("../src/lib/auth");
    const { PATCH } = await import("../src/app/api/users/bulk-role/route");
    let passed = 0;
    const operatorToken = signSession({
      uid: "operator", username: "fixture.operator", fullName: "مدیر آزمایشی", role: "BULK_MANAGER", perms: ["users:manage"], employeeId: null,
    });

    async function reset() {
      await db.auditLog.deleteMany();
      await db.user.deleteMany();
      await db.role.deleteMany();
      await db.role.createMany({ data: [
        { id: "super-role", key: "SUPER_ADMIN", name: "مدیر کل سیستم", permissions: JSON.stringify(["*"]), isSystem: true },
        { id: "employee-role", key: "EMPLOYEE", name: "کارمند", permissions: JSON.stringify(["portal:view"]), isSystem: true },
        { id: "manager-role", key: "BULK_MANAGER", name: "مدیر آزمایشی", permissions: JSON.stringify(["users:manage"]) },
      ] });
      await db.user.createMany({ data: [
        { id: "operator", username: "fixture.operator", fullName: "مدیر آزمایشی", role: "BULK_MANAGER", roleId: "manager-role", passwordHash: "fixture-unusable-password" },
        { id: "admin1", username: "fixture.admin1", fullName: "مدیر اول", role: "SUPER_ADMIN", roleId: "super-role", passwordHash: "fixture-unusable-password" },
        { id: "admin2", username: "fixture.admin2", fullName: "مدیر دوم", role: "SUPER_ADMIN", roleId: "super-role", passwordHash: "fixture-unusable-password" },
        { id: "user1", username: "fixture.user1", fullName: "کارمند اول", role: "EMPLOYEE", roleId: "employee-role", passwordHash: "fixture-unusable-password" },
        { id: "user2", username: "fixture.user2", fullName: "کارمند دوم", role: "EMPLOYEE", roleId: "employee-role", passwordHash: "fixture-unusable-password" },
      ] });
    }

    async function request(body: unknown, token: string | null = operatorToken) {
      const req = new NextRequest("http://localhost/api/users/bulk-role", {
        method: "PATCH",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify(body),
      });
      const response = await PATCH(req);
      return { status: response.status, body: await response.json() };
    }
    async function test(name: string, run: () => Promise<void>) {
      await reset();
      await run();
      passed++;
      console.log(`PASS ${name}`);
    }
    async function unchanged(ids: string[], expectedRole = "SUPER_ADMIN") {
      const users = await db.user.findMany({ where: { id: { in: ids } } });
      assert.equal(users.length, ids.length);
      assert.ok(users.every((user) => user.role === expectedRole));
      assert.equal(await db.auditLog.count(), 0);
    }

    await test("bulk role updates both columns and records per-user audit plus summary", async () => {
      const result = await request({ ids: ["user1", "user2"], roleId: "super-role" });
      assert.equal(result.status, 200);
      assert.deepEqual(result.body, { updatedCount: 2, unchangedCount: 0, roleLabel: "مدیر کل سیستم" });
      const users = await db.user.findMany({ where: { id: { in: ["user1", "user2"] } } });
      assert.ok(users.every((user) => user.role === "SUPER_ADMIN" && user.roleId === "super-role"));
      const logs = await db.auditLog.findMany();
      assert.equal(logs.length, 3);
      for (const log of logs.filter((entry) => entry.action === "UPDATE")) {
        assert.deepEqual(JSON.parse(log.before!), { role: "EMPLOYEE", roleId: "employee-role", roleLabel: "کارمند" });
        assert.deepEqual(JSON.parse(log.after!), { role: "SUPER_ADMIN", roleId: "super-role", roleLabel: "مدیر کل سیستم" });
        assert.equal(log.userId, "operator");
      }
    });

    await test("duplicate IDs deduplicate and mixed unchanged accounts are counted", async () => {
      const result = await request({ ids: ["admin1", "user1", "admin1"], roleId: "employee-role" });
      assert.equal(result.status, 200);
      assert.deepEqual(result.body, { updatedCount: 1, unchangedCount: 1, roleLabel: "کارمند" });
      assert.equal(await db.auditLog.count({ where: { action: "UPDATE" } }), 1);
      assert.equal(await db.auditLog.count(), 2);
    });

    await test("mismatched legacy roleId is repaired even when role key already matches", async () => {
      await db.user.update({ where: { id: "user1" }, data: { roleId: "super-role" } });
      const result = await request({ ids: ["user1"], roleId: "employee-role" });
      assert.equal(result.status, 200);
      assert.equal(result.body.updatedCount, 1);
      assert.equal((await db.user.findUniqueOrThrow({ where: { id: "user1" } })).roleId, "employee-role");
    });

    await test("unknown role and unknown users reject the entire batch", async () => {
      assert.equal((await request({ ids: ["admin1"], roleId: "missing-role" })).status, 400);
      assert.equal((await request({ ids: ["admin1", "missing-user"], roleId: "employee-role" })).status, 404);
      await unchanged(["admin1"]);
    });

    await test("invalid request shapes, ID types and empty values are rejected", async () => {
      for (const body of [null, [], {}, { ids: [], roleId: "employee-role" }, { ids: [42], roleId: "employee-role" },
        { ids: [" "], roleId: "employee-role" }, { ids: ["admin1"], roleId: 42 }, { ids: ["admin1"], roleId: " " }]) {
        assert.equal((await request(body)).status, 400);
      }
      const invalidJson = new NextRequest("http://localhost/api/users/bulk-role", {
        method: "PATCH", headers: { Authorization: `Bearer ${operatorToken}`, "Content-Type": "application/json" }, body: "{",
      });
      assert.equal((await PATCH(invalidJson)).status, 400);
      await unchanged(["admin1"]);
    });

    await test("batch limit is applied before duplicate removal", async () => {
      assert.equal((await request({ ids: Array(501).fill("admin1"), roleId: "employee-role" })).status, 400);
      await unchanged(["admin1"]);
    });

    await test("maximum 500-user batch updates and audits every affected account", async () => {
      const ids = Array.from({ length: 500 }, (_, index) => `batch${index}`);
      await db.user.createMany({ data: ids.map((id) => ({
        id, username: `fixture.${id}`, fullName: `آزمایشی ${id}`, role: "SUPER_ADMIN", roleId: "super-role", passwordHash: "fixture-unusable-password",
      })) });
      const result = await request({ ids, roleId: "employee-role" });
      assert.equal(result.status, 200);
      assert.equal(result.body.updatedCount, 500);
      assert.equal(await db.user.count({ where: { id: { in: ids }, role: "EMPLOYEE", roleId: "employee-role" } }), 500);
      assert.equal(await db.auditLog.count({ where: { action: "UPDATE" } }), 500);
      assert.equal(await db.auditLog.count(), 501);
    });

    await test("all unchanged selection records only its summary", async () => {
      const result = await request({ ids: ["user1", "user2"], roleId: "employee-role" });
      assert.equal(result.status, 200);
      assert.deepEqual(result.body, { updatedCount: 0, unchangedCount: 2, roleLabel: "کارمند" });
      assert.equal(await db.auditLog.count({ where: { action: "UPDATE" } }), 0);
      assert.equal(await db.auditLog.count({ where: { action: "BULK" } }), 1);
    });

    await test("current operator cannot be included in a bulk change", async () => {
      const result = await request({ ids: ["admin1", "operator"], roleId: "employee-role" });
      assert.equal(result.status, 400);
      assert.match(result.body.error, /خودتان/);
      await unchanged(["admin1"]);
    });

    await test("last active admin protection covers the entire batch", async () => {
      assert.equal((await request({ ids: ["admin1", "admin2"], roleId: "employee-role" })).status, 400);
      await unchanged(["admin1", "admin2"]);
    });

    await test("concurrent demotions cannot remove both remaining admins", async () => {
      const results = await Promise.all([
        request({ ids: ["admin1"], roleId: "employee-role" }),
        request({ ids: ["admin2"], roleId: "employee-role" }),
      ]);
      assert.deepEqual(results.map((result) => result.status).sort(), [200, 400]);
      assert.equal(await db.user.count({ where: { isActive: true, roleId: "super-role" } }), 1);
    });

    await test("inactive remaining admins cannot satisfy the last-admin guard", async () => {
      await db.user.update({ where: { id: "admin2" }, data: { isActive: false } });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 400);
      await unchanged(["admin1"]);
    });

    await test("role relation protects admin even when legacy key says employee", async () => {
      await db.user.update({ where: { id: "admin1" }, data: { role: "EMPLOYEE" } });
      await db.user.update({ where: { id: "admin2" }, data: { role: "EMPLOYEE", roleId: "employee-role" } });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 400);
      assert.equal((await db.user.findUniqueOrThrow({ where: { id: "admin1" } })).roleId, "super-role");
      assert.equal(await db.auditLog.count(), 0);
    });

    await test("phantom legacy admin does not conceal removal of last actual admin", async () => {
      await db.user.update({ where: { id: "admin2" }, data: { roleId: "employee-role" } });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 400);
      await unchanged(["admin1"]);
    });

    await test("legacy active admin without roleId still satisfies protection", async () => {
      await db.user.update({ where: { id: "admin2" }, data: { roleId: null } });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 200);
      assert.equal((await db.user.findUniqueOrThrow({ where: { id: "admin2" } })).role, "SUPER_ADMIN");
    });

    await test("unauthed and unprivileged tokens cannot change roles", async () => {
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" }, null)).status, 401);
      const token = signSession({ uid: "user1", username: "fixture.user1", fullName: "کارمند اول", role: "EMPLOYEE", perms: ["portal:view"] });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" }, token)).status, 403);
      await unchanged(["admin1"]);
    });

    await test("stale privileged token is rejected after operator demotion", async () => {
      await db.user.update({ where: { id: "operator" }, data: { role: "EMPLOYEE", roleId: "employee-role" } });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 403);
      await unchanged(["admin1"]);
    });

    await test("inactive or deleted operator with valid token is rejected", async () => {
      await db.user.update({ where: { id: "operator" }, data: { isActive: false } });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 401);
      await db.user.delete({ where: { id: "operator" } });
      assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 401);
      await unchanged(["admin1"]);
    });

    await test("empty or corrupt current DB permissions do not grant legacy admin fallback", async () => {
      await db.user.update({ where: { id: "operator" }, data: { role: "SUPER_ADMIN", roleId: "manager-role" } });
      for (const permissions of ["[]", "invalid-json", JSON.stringify([42]), JSON.stringify({ admin: "*" })]) {
        await db.role.update({ where: { id: "manager-role" }, data: { permissions } });
        assert.equal((await request({ ids: ["admin1"], roleId: "employee-role" })).status, 403);
      }
      await unchanged(["admin1"]);
    });

    await test("audit storage failure rolls back user changes", async () => {
      await db.$executeRawUnsafe("CREATE TRIGGER fixture_audit_failure BEFORE INSERT ON audit_logs BEGIN SELECT RAISE(ABORT, 'fixture audit failure'); END");
      try {
        assert.ok((await request({ ids: ["admin1"], roleId: "employee-role" })).status >= 400);
        await unchanged(["admin1"]);
      } finally {
        await db.$executeRawUnsafe("DROP TRIGGER fixture_audit_failure");
      }
    });

    console.log(`BULK_USER_ROLES_TEST_OK cases=${passed}`);
  } finally {
    if (disconnect) await disconnect();
    const expectedParent = path.resolve(tmpdir());
    if (path.dirname(path.resolve(testDir)) !== expectedParent || !path.basename(testDir).startsWith("hrms-bulk-role-test-")) {
      throw new Error("Refusing to remove unexpected fixture path");
    }
    rmSync(testDir, { recursive: true, force: true });
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

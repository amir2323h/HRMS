// ============================================================
// Seed — داده‌های نمونه سامانه منابع انسانی ۱۴۰۵
// اجرا: bun prisma/seed.ts
// ============================================================
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
import { computePaysheet, LEGAL_DEFAULTS_1405, type PayrollContext } from "../src/lib/payroll/engine";

const db = new PrismaClient();

// ---- RNG قطعی برای داده‌های تکرارپذیر ----
function mulberry32(a: number) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rng = mulberry32(1405);

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

// ---- تولید شبا معتبر ----
function makeIban(bankCode: string, accountBase: string): string {
  // BBAN: 3 رقم بانک + 19 رقم حساب/شعبه (مجموعاً ۲۲ رقم)
  const bban = (bankCode + accountBase).slice(0, 22).padEnd(22, "0");
  const s = bban + "1827" + "00"; // IR → 18,27
  let rem = 0;
  for (const ch of s) rem = (rem * 10 + +ch) % 97;
  const check = String(98 - rem).padStart(2, "0");
  return `IR${check}${bban}`;
}

const R = (toman: number) => BigInt(Math.round(toman * 10)); // تومان → ریال

async function main() {
  console.log("🚿 پاک‌سازی دیتابیس...");
  await db.auditLog.deleteMany();
  await db.payslip.deleteMany();
  await db.payrollPeriod.deleteMany();
  await db.document.deleteMany();
  await db.leaveRequest.deleteMany();
  await db.advanceRequest.deleteMany();
  await db.user.deleteMany();
  await db.employeeDepartment.deleteMany();
  await db.employee.deleteMany();
  await db.jobGrade.deleteMany();
  await db.department.deleteMany();
  await db.taxBracket.deleteMany();
  await db.systemSetting.deleteMany();

  // ================= پارامترهای قانونی =================
  console.log("⚙️ پارامترهای قانونی ۱۴۰۵...");
  for (const b of LEGAL_DEFAULTS_1405.taxBrackets) {
    await db.taxBracket.create({
      data: {
        year: 1405,
        sortOrder: b.sortOrder,
        lowerLimit: BigInt(b.lowerLimit),
        upperLimit: b.upperLimit === null ? null : BigInt(b.upperLimit),
        rate: b.rate,
      },
    });
  }
  const { taxBrackets: _tb, ...legalRest } = LEGAL_DEFAULTS_1405;
  await db.systemSetting.create({ data: { key: "legal_params", value: JSON.stringify(legalRest) } });
  await db.systemSetting.create({ data: { key: "display", value: JSON.stringify({ unit: "TOMAN" }) } });
  await db.systemSetting.create({
    data: {
      key: "company",
      value: JSON.stringify({
        name: "شرکت فناوران داده پارس",
        nationalId: "10101234567",
        ssoCode: "22-104578-0",
        taxId: "41111234567890",
        address: "تهران، خیابان ولیعصر، برج فناوری، طبقه ۱۲",
      }),
    },
  });

  // ================= دپارتمان‌ها =================
  console.log("🏢 دپارتمان‌ها...");
  const deptData = [
    { code: "D100", name: "مدیریت ارشد", costCenter: "CC-100", parent: null, desc: "هیئت‌مدیره و مدیرعامل" },
    { code: "D200", name: "منابع انسانی", costCenter: "CC-210", parent: null, desc: "جذب، آموزش و رفاه کارکنان" },
    { code: "D300", name: "مالی و حسابداری", costCenter: "CC-310", parent: null, desc: "حسابداری، خزانه و حقوق و دستمزد" },
    { code: "D400", name: "فناوری اطلاعات", costCenter: "CC-410", parent: null, desc: "توسعه محصول و زیرساخت فنی" },
    { code: "D410", name: "توسعه نرم‌افزار", costCenter: "CC-411", parent: "D400", desc: "تیم مهندسی نرم‌افزار" },
    { code: "D420", name: "زیرساخت و شبکه", costCenter: "CC-412", parent: "D400", desc: "عملیات و امنیت شبکه" },
    { code: "D500", name: "فروش و بازاریابی", costCenter: "CC-510", parent: null, desc: "توسعه بازار و فروش سازمانی" },
  ];
  const deptIds: Record<string, string> = {};
  for (const d of deptData) {
    const row = await db.department.create({
      data: {
        code: d.code,
        name: d.name,
        costCenterCode: d.costCenter,
        description: d.desc,
        parentId: d.parent ? deptIds[d.parent] : null,
      },
    });
    deptIds[d.code] = row.id;
  }

  // ================= طبقه‌بندی ۷ سطحی =================
  console.log("📊 طبقه‌بندی مشاغل (۷ سطح)...");
  const gradesData = [
    { level: 1, code: "L1", title: "تازه‌کار / کارآموز", min: R(17_000_000), max: R(25_000_000), sen: R(500_001), att: R(0), desc: "شروع مسیر حرفه‌ای — زیر نظر منتور" },
    { level: 2, code: "L2", title: "جونیور (کارشناس کمکی)", min: R(25_000_000), max: R(40_000_000), sen: R(600_000), att: R(2_000_000), desc: "اجرای مستقل کارهای استاندارد" },
    { level: 3, code: "L3", title: "میان‌رده (کارشناس)", min: R(40_000_000), max: R(60_000_000), sen: R(800_000), att: R(3_000_000), desc: "کارشناس تمام‌عیار با مالکیت وظایف" },
    { level: 4, code: "L4", title: "ارشد (کارشناس ارشد)", min: R(60_000_000), max: R(90_000_000), sen: R(1_000_000), att: R(4_000_000), desc: "راهبری فنی و منتورینگ" },
    { level: 5, code: "L5", title: "سرپرست / متخصص ارشد", min: R(90_000_000), max: R(130_000_000), sen: R(1_200_000), att: R(5_000_000), desc: "رهبری تیم کوچک / تخصص کمیاب" },
    { level: 6, code: "L6", title: "مدیر (دپارتمان)", min: R(130_000_000), max: R(200_000_000), sen: R(1_500_000), att: R(8_000_000), desc: "مدیریت دپارتمان و بودجه" },
    { level: 7, code: "L7", title: "مدیر ارشد سازمانی", min: R(200_000_000), max: R(400_000_000), sen: R(2_000_000), att: R(15_000_000), desc: "معاون / مدیرعامل" },
  ];
  const gradeIds: Record<number, string> = {};
  for (const g of gradesData) {
    const row = await db.jobGrade.create({
      data: {
        level: g.level, code: g.code, title: g.title,
        minBaseSalary: g.min, maxBaseSalary: g.max,
        seniorityBase: g.sen, attraction: g.att, description: g.desc,
      },
    });
    gradeIds[g.level] = row.id;
  }

  // ================= کارکنان =================
  // [نام، نام خانوادگی، کد ملی، شماره بیمه، سطح، دپارتمان، عنوان شغل، حقوق پایه(تومان)،
                                                   //  وضعیت تأهل، فرزند، تاریخ استخدام، نوع قرارداد، پایان آزمایشی، پایان قرارداد، بانک]
  console.log("👥 کارکنان...");
  type EmpSeed = {
    first: string; last: string; nid: string; sso: string; level: number; dept: string;
    title: string; base: number; marital: string; children: number; hire: string;
    contract: string; probationEnd?: string; contractEnd?: string; bank: string; iban: string;
    ot: number; mobile: string;
  };
  const employeesSeed: EmpSeed[] = [
    { first: "مهدی", last: "صادقی‌فر", nid: "0076458321", sso: "4578932104", level: 7, dept: "D100", title: "مدیرعامل", base: 320_000_000, marital: "MARRIED", children: 2, hire: "1394/01/15", contract: "PERMANENT", bank: "بانک پارسیان", iban: makeIban("054", "1122334455667788990"), ot: 0, mobile: "09121112233" },
    { first: "زهرا", last: "محمدی", nid: "0069871234", sso: "4389210576", level: 6, dept: "D200", title: "مدیر منابع انسانی", base: 185_000_000, marital: "MARRIED", children: 1, hire: "1396/05/01", contract: "PERMANENT", bank: "بانک پاسارگاد", iban: makeIban("055", "2233445566778899001"), ot: 0, mobile: "09122223344" },
    { first: "علی", last: "رضایی", nid: "1345678910", sso: "5210938475", level: 4, dept: "D300", title: "کارشناس ارشد مالی", base: 78_000_000, marital: "MARRIED", children: 2, hire: "1398/02/10", contract: "PERMANENT", bank: "بانک ملی", iban: makeIban("017", "3344556677889900112"), ot: 6, mobile: "09123334455" },
    { first: "فاطمه", last: "کریمی", nid: "1287634521", sso: "5187263940", level: 5, dept: "D300", title: "سرپرست حقوق و دستمزد", base: 105_000_000, marital: "SINGLE", children: 0, hire: "1397/07/15", contract: "PERMANENT", bank: "بانک سامان", iban: makeIban("056", "4455667788990011223"), ot: 8, mobile: "09124445566" },
    { first: "حسین", last: "احمدی", nid: "1198347652", sso: "5098123746", level: 6, dept: "D400", title: "مدیر فناوری اطلاعات (CTO)", base: 195_000_000, marital: "MARRIED", children: 3, hire: "1395/03/20", contract: "PERMANENT", bank: "بانک تجارت", iban: makeIban("020", "5566778899001122334"), ot: 0, mobile: "09125556677" },
    { first: "مریم", last: "حسینی", nid: "4023176598", sso: "6210938475", level: 5, dept: "D410", title: "سرپرست توسعه نرم‌افزار", base: 120_000_000, marital: "MARRIED", children: 1, hire: "1398/11/05", contract: "PERMANENT", bank: "بانک ملت", iban: makeIban("012", "6677889900112233445"), ot: 10, mobile: "09126667788" },
    { first: "رضا", last: "نوروزی", nid: "4156920347", sso: "6327891045", level: 4, dept: "D410", title: "مهندس ارشد نرم‌افزار", base: 88_000_000, marital: "SINGLE", children: 0, hire: "1400/04/12", contract: "PERMANENT", bank: "بانک صادرات", iban: makeIban("018", "7788990011223344556"), ot: 16, mobile: "09127778899" },
    { first: "سارا", last: "طاهری", nid: "4231980567", sso: "6438920156", level: 3, dept: "D410", title: "مهندس نرم‌افزار", base: 52_000_000, marital: "SINGLE", children: 0, hire: "1401/06/01", contract: "FIXED", contractEnd: "1405/09/10", bank: "بانک پاسارگاد", iban: makeIban("055", "8899001122334455667"), ot: 12, mobile: "09128889900" },
    { first: "امیر", last: "قاسمی", nid: "4312768905", sso: "6540928371", level: 3, dept: "D420", title: "مهندس شبکه", base: 48_000_000, marital: "MARRIED", children: 1, hire: "1400/09/15", contract: "PERMANENT", bank: "بانک ملی", iban: makeIban("017", "9900112233445566778"), ot: 20, mobile: "09129990011" },
    { first: "نگار", last: "شریفی", nid: "4409123786", sso: "6654092837", level: 2, dept: "D420", title: "کارشناس پشتیبانی زیرساخت", base: 34_000_000, marital: "SINGLE", children: 0, hire: "1402/02/20", contract: "FIXED", contractEnd: "1405/08/05", bank: "بانک سامان", iban: makeIban("056", "1011121314151617181"), ot: 8, mobile: "09121010022" },
    { first: "محمد", last: "عبادی", nid: "4487231096", sso: "6761283940", level: 4, dept: "D420", title: "کارشناس ارشد امنیت اطلاعات", base: 82_000_000, marital: "MARRIED", children: 2, hire: "1399/01/10", contract: "PERMANENT", bank: "بانک تجارت", iban: makeIban("020", "2021222324252627282"), ot: 6, mobile: "09122120033" },
    { first: "الهام", last: "رستمی", nid: "4551087234", sso: "6874109382", level: 3, dept: "D200", title: "کارشناس جذب و آموزش", base: 45_000_000, marital: "MARRIED", children: 1, hire: "1401/03/12", contract: "PERMANENT", bank: "بانک پارسیان", iban: makeIban("054", "3031323334353637383"), ot: 4, mobile: "09123220044" },
    { first: "کیان", last: "دلاوری", nid: "4612058734", sso: "6980517263", level: 2, dept: "D200", title: "کارشناس منابع انسانی", base: 30_000_000, marital: "SINGLE", children: 0, hire: "1403/05/01", contract: "PERMANENT", bank: "بانک ملت", iban: makeIban("012", "4041424344454647484"), ot: 2, mobile: "09124320055" },
    { first: "پریسا", last: "اسماعیلی", nid: "4683920157", sso: "7019384756", level: 5, dept: "D500", title: "مدیر فروش سازمانی", base: 115_000_000, marital: "MARRIED", children: 2, hire: "1397/02/14", contract: "PERMANENT", bank: "بانک صادرات", iban: makeIban("018", "5051525354555657585"), ot: 12, mobile: "09125420066" },
    { first: "بهزاد", last: "فرهادی", nid: "4758103926", sso: "7120648395", level: 3, dept: "D500", title: "کارشناس بازاریابی دیجیتال", base: 50_000_000, marital: "SINGLE", children: 0, hire: "1402/08/01", contract: "FIXED", contractEnd: "1405/11/30", bank: "بانک پاسارگاد", iban: makeIban("055", "6061626364656667686"), ot: 6, mobile: "09126520077" },
    { first: "شیما", last: "موسوی", nid: "4820964315", sso: "7234810596", level: 2, dept: "D500", title: "کارشناس فروش", base: 28_000_000, marital: "SINGLE", children: 0, hire: "1404/03/15", contract: "PROBATION", probationEnd: "1405/07/25", bank: "بانک سامان", iban: makeIban("056", "7071727374757677787"), ot: 10, mobile: "09127620088" },
    { first: "آرش", last: "کاظمی", nid: "4893471206", sso: "7340928165", level: 1, dept: "D410", title: "کارآموز توسعه نرم‌افزار", base: 19_000_000, marital: "SINGLE", children: 0, hire: "1405/06/15", contract: "PROBATION", probationEnd: "1405/09/13", bank: "", iban: "", ot: 4, mobile: "09128720099" },
    { first: "لیلا", last: "بهرامی", nid: "4967231058", sso: "7456920381", level: 2, dept: "D300", title: "کارشناس حسابداری", base: 33_000_000, marital: "MARRIED", children: 0, hire: "1403/10/05", contract: "PERMANENT", bank: "بانک ملی", iban: makeIban("017", "8081828384858687888"), ot: 5, mobile: "09129820100" },
    { first: "سینا", last: "مرادی", nid: "5031847296", sso: "7560394821", level: 1, dept: "D500", title: "کارآموز فروش", base: 18_000_000, marital: "SINGLE", children: 0, hire: "1405/05/10", contract: "PROBATION", probationEnd: "1405/08/09", bank: "", iban: "", ot: 2, mobile: "09120920111" },
  ];

  const empIds: string[] = [];
  let pc = 1001;
  for (const e of employeesSeed) {
    const grade = gradesData.find((g) => g.level === e.level)!;
    const hireYear = +e.hire.split("/")[0];
    const hireMonth = +e.hire.split("/")[1];
    const probationEnd = e.probationEnd || (e.contract === "PROBATION" ? "" : "");
    const row = await db.employee.create({
      data: {
        personnelCode: `EMP-${pc}`,
        firstName: e.first,
        lastName: e.last,
        nationalId: e.nid,
        ssoNumber: e.sso,
        fatherName: "—",
        birthDateJ: `${hireYear - 28}/03/15`,
        mobile: e.mobile,
        email: `${e.first}.${e.last}@parsdata.ir`,
        address: "تهران",
        maritalStatus: e.marital,
        childCount: e.children,
        hireDateJ: e.hire,
        probationEndDateJ: e.probationEnd || "",
        contractType: e.contract,
        contractStartJ: e.hire,
        contractEndJ: e.contractEnd || "",
        jobGradeId: gradeIds[e.level],
        jobTitle: e.title,
        baseSalary: R(e.base),
        overtimeHours: e.ot,
        status: "ACTIVE",
        bankName: e.bank,
        iban: e.iban,
      },
    });
    empIds.push(row.id);
    // انتساب دپارتمان
    await db.employeeDepartment.create({
      data: { employeeId: row.id, departmentId: deptIds[e.dept], allocationPercent: 100 },
    });
    // مدیر دپارتمان‌ها
    pc += 1;
    void hireYear; void hireMonth;
  }
  // تعیین مدیر دپارتمان‌ها
  await db.department.update({ where: { code: "D100" }, data: { managerEmployeeId: empIds[0] } });
  await db.department.update({ where: { code: "D200" }, data: { managerEmployeeId: empIds[1] } });
  await db.department.update({ where: { code: "D300" }, data: { managerEmployeeId: empIds[3] } });
  await db.department.update({ where: { code: "D400" }, data: { managerEmployeeId: empIds[4] } });
  await db.department.update({ where: { code: "D410" }, data: { managerEmployeeId: empIds[5] } });
  await db.department.update({ where: { code: "D500" }, data: { managerEmployeeId: empIds[13] } });

  // ================= کاربران =================
  console.log("🔑 کاربران و نقش‌ها...");
  await db.user.create({
    data: { username: "admin", passwordHash: hashPassword("admin123"), fullName: "مدیر کل سیستم", role: "SUPER_ADMIN" },
  });
  await db.user.create({
    data: { username: "hr", passwordHash: hashPassword("hr123"), fullName: "زهرا محمدی", role: "HR_MANAGER", employeeId: empIds[1] },
  });
  await db.user.create({
    data: { username: "payroll", passwordHash: hashPassword("pay123"), fullName: "فاطمه کریمی", role: "PAYROLL_OFFICER", employeeId: empIds[3] },
  });
  await db.user.create({
    data: { username: "dept", passwordHash: hashPassword("dept123"), fullName: "حسین احمدی", role: "DEPT_MANAGER", employeeId: empIds[4] },
  });
  await db.user.create({
    data: { username: "emp", passwordHash: hashPassword("emp123"), fullName: "علی رضایی", role: "EMPLOYEE", employeeId: empIds[2] },
  });
  // کارشناس اداری — صدور نامه‌های اداری و ثبت نامه دستی (بدون قالب)
  await db.user.create({
    data: { username: "edari", passwordHash: hashPassword("edari123"), fullName: "مریم اداری", role: "ADMIN_EXPERT" },
  });

  // ================= اسناد نمونه =================
  console.log("📄 اسناد کارکنان...");
  const contractText = (name: string) =>
    Buffer.from(
      `قرارداد کار\n\nاین قرارداد بین شرکت فناوران داده پارس و ${name} منعقد می‌شود.\nموضوع قرارداد: انجام وظایف شغلی مطابق شرح شغل.\nمدت: طبق مشخصات پرونده کارمند.\n\nامضا: ____________________\nتاریخ: ۱۴۰۵`,
      "utf8"
    );
  for (const idx of [0, 1, 2, 3, 5, 6, 13]) {
    const emp = employeesSeed[idx];
    await db.document.create({
      data: {
        employeeId: empIds[idx],
        type: "CONTRACT",
        title: `قرارداد کاری — ${emp.first} ${emp.last}`,
        fileName: `contract-${emp.last}.txt`,
        mimeType: "text/plain",
        size: contractText(`${emp.first} ${emp.last}`).length,
        data: contractText(`${emp.first} ${emp.last}`),
        uploadedBy: "hr",
      },
    });
    await db.document.create({
      data: {
        employeeId: empIds[idx],
        type: "NATIONAL_ID",
        title: `اسکن کارت ملی — ${emp.first} ${emp.last}`,
        fileName: `national-id-${emp.last}.txt`,
        mimeType: "text/plain",
        size: 64,
        data: Buffer.from(`کارت ملی ${emp.first} ${emp.last} — کد ملی ${emp.nid}`, "utf8"),
        uploadedBy: "hr",
      },
    });
  }

  // ================= دوره‌های حقوق (فروردین تا مهر ۱۴۰۵) =================
  console.log("💰 محاسبه لیست‌های حقوق ۱۴۰۵ (فروردین تا مهر)...");
  const todayJ = "1405/07/12";
  for (let month = 1; month <= 7; month++) {
    const period = await db.payrollPeriod.create({
      data: {
        year: 1405,
        month,
        status: month === 7 ? "CALCULATED" : "PAID",
        notes: month === 7 ? "در انتظار تأیید نهایی" : "",
      },
    });
    for (let i = 0; i < employeesSeed.length; i++) {
      const e = employeesSeed[i];
      const hireMonth = +e.hire.split("/")[1];
      const hireYear = +e.hire.split("/")[0];
      if (hireYear > 1405 || (hireYear === 1405 && hireMonth > month)) continue; // هنوز استخدام نشده

      const grade = gradesData.find((g) => g.level === e.level)!;
      // سنوات
      const [hy, hm, hd] = e.hire.split("/").map(Number);
      const years = 1405 - hy - (month < hm ? 1 : 0);
      const ctx: PayrollContext = {
        childCount: e.children,
        housingEnabled: true,
        groceryEnabled: true,
        seniorityYears: Math.max(0, years),
        seniorityBase: Number(grade.sen),
        attraction: Number(grade.att),
        overtimeHours: Math.round(e.ot * (0.5 + rng() * 1.0)), // نوسان اضافه‌کاری ماهانه
        otherAllowance: 0,
        otherDeduction: 0,
      };
      void hd;
      const sheet = computePaysheet(Number(R(e.base)), ctx, LEGAL_DEFAULTS_1405);
      await db.payslip.create({
        data: {
          periodId: period.id,
          employeeId: empIds[i],
          baseSalary: BigInt(sheet.baseSalary),
          seniority: BigInt(sheet.seniority),
          housing: BigInt(sheet.housing),
          grocery: BigInt(sheet.grocery),
          childAllowance: BigInt(sheet.childAllowance),
          attraction: BigInt(sheet.attraction),
          overtimeHours: ctx.overtimeHours,
          overtimeAmount: BigInt(sheet.overtimeAmount),
          otherAllowance: BigInt(sheet.otherAllowance),
          gross: BigInt(sheet.gross),
          insurableBase: BigInt(sheet.insurableBase),
          employeeSso: BigInt(sheet.employeeSso),
          employerSso20: BigInt(sheet.employerSso20),
          unemploymentSso3: BigInt(sheet.unemploymentSso3),
          taxableIncome: BigInt(sheet.taxableIncome),
          incomeTax: BigInt(sheet.incomeTax),
          otherDeduction: BigInt(sheet.otherDeduction),
          netPay: BigInt(sheet.netPay),
          isReverse: false,
        },
      });
    }
  }

  // ================= درخواست‌ها =================
  console.log("📝 درخواست‌های کارکنان...");
  await db.leaveRequest.createMany({
    data: [
      { employeeId: empIds[2], type: "ANNUAL", startDateJ: "1405/07/20", endDateJ: "1405/07/24", days: 5, reason: "سفر خانوادگی", status: "PENDING" },
      { employeeId: empIds[6], type: "SICK", startDateJ: "1405/07/10", endDateJ: "1405/07/12", days: 3, reason: "گواهی استعلاجی", status: "PENDING" },
      { employeeId: empIds[14], type: "ANNUAL", startDateJ: "1405/06/05", endDateJ: "1405/06/07", days: 3, reason: "امور شخصی", status: "APPROVED", decidedBy: "زهرا محمدی" },
      { employeeId: empIds[8], type: "UNPAID", startDateJ: "1405/05/18", endDateJ: "1405/05/22", days: 5, reason: "مراقبت از والدین", status: "REJECTED", decidedBy: "زهرا محمدی" },
    ],
  });
  await db.advanceRequest.createMany({
    data: [
      { employeeId: empIds[9], amount: R(5_000_000), installments: 4, reason: "تعمیرات منزل", status: "PENDING" },
      { employeeId: empIds[15], amount: R(3_000_000), installments: 3, reason: "هزینه درمان", status: "PENDING" },
      { employeeId: empIds[11], amount: R(8_000_000), installments: 8, reason: "قسط مسکن", status: "APPROVED", decidedBy: "زهرا محمدی" },
    ],
  });

  // ================= لاگ‌های حسابرسی نمونه =================
  console.log("🧾 لاگ‌های حسابرسی...");
  await db.auditLog.createMany({
    data: [
      { userName: "system", action: "CREATE", entity: "SYSTEM", summary: "راه‌اندازی اولیه سامانه و پارامترهای قانونی ۱۴۰۵", after: JSON.stringify({ version: "1.0.0" }) },
      { userName: "زهرا محمدی", action: "CREATE", entity: "EMPLOYEE", entityId: empIds[16], summary: "ثبت کارمند جدید: آرش کاظمی (سطح ۱ — کارآموز)" },
      { userName: "زهرا محمدی", action: "UPDATE", entity: "EMPLOYEE", entityId: empIds[6], summary: "افزایش حقوق پایه رضا نوروزی پس از ارزیابی عملکرد", before: JSON.stringify({ baseSalary: 820000000 }), after: JSON.stringify({ baseSalary: 880000000 }) },
      { userName: "فاطمه کریمی", action: "CALC", entity: "PERIOD", summary: "محاسبه لیست حقوق مهر ۱۴۰۵ برای ۱۹ کارمند" },
      { userName: "فاطمه کریمی", action: "REVERSE_CALC", entity: "PAYROLL", summary: "محاسبه معکوس: خالص هدف ۵۰,۰۰۰,۰۰۰ تومان" },
      { userName: "مدیر کل سیستم", action: "UPDATE", entity: "SETTINGS", summary: "به‌روزرسانی پله‌های مالیاتی مطابق ماده ۸۵ بودجه ۱۴۰۵" },
    ],
  });

  const counts = {
    employees: await db.employee.count(),
    departments: await db.department.count(),
    grades: await db.jobGrade.count(),
    periods: await db.payrollPeriod.count(),
    payslips: await db.payslip.count(),
    documents: await db.document.count(),
    users: await db.user.count(),
    auditLogs: await db.auditLog.count(),
  };
  console.log("✅ Seed کامل شد:", counts, "| امروز:", todayJ);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

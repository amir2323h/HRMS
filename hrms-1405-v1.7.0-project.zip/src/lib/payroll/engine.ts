// ============================================================
// موتور محاسبه حقوق و دستمزد ۱۴۰۵ — محاسبه مستقیم
// منطق: حقوق و مزایا → مشمول بیمه → بیمه ۷٪/۲۳٪ → درآمد مشمول مالیات
//       → مالیات پلکانی (ماده ۸۵ بودجه ۱۴۰۵) → خالص پرداختی
// واحد: ریال (integer)
// ============================================================

export interface TaxBracket {
  sortOrder: number;
  lowerLimit: number; // شامل — ریال/ماه
  upperLimit: number | null; // خالی = بی‌نهایت
  rate: number; // 0.10
  label?: string;
}

export interface LegalParams {
  year: number;
  employeeSsoRate: number; // 0.07
  employerSsoRate: number; // 0.20
  unemploymentRate: number; // 0.03
  minWage: number; // حداقل دستمزد ماهانه — ریال
  insurableCap: number | null; // سقف مشمول بیمه — ریال (null = نامحدود)
  housing: number; // حق مسکن — ریال
  grocery: number; // بن کارگری — ریال
  childPerChild: number; // حق اولاد به ازای هر فرزند — ریال
  maxChildrenForAllowance: number; // حداکثر فرزند مشمول حق اولاد
  monthlyWorkHours: number; // ساعت کار ماهانه (مبنای اضافه‌کاری)
  overtimeMultiplier: number; // 1.4 — ماده ۵۹ قانون کار
  groceryTaxable: boolean; // بن کارگری مشمول مالیات؟ (ماده ۹۱ بند ۱۴ ق.م.م: معاف)
  taxBrackets: TaxBracket[];
}

// پارامترهای پیش‌فرض ۱۴۰۵ (قابل ویرایش از تنظیمات)
export const LEGAL_DEFAULTS_1405: LegalParams = {
  year: 1405,
  employeeSsoRate: 0.07,
  employerSsoRate: 0.2,
  unemploymentRate: 0.03,
  minWage: 166_255_500,
  insurableCap: null,
  housing: 30_000_000,
  grocery: 22_000_000,
  childPerChild: 16_625_550,
  maxChildrenForAllowance: 2,
  monthlyWorkHours: 220,
  overtimeMultiplier: 1.4,
  groceryTaxable: false,
  taxBrackets: [
    { sortOrder: 1, lowerLimit: 0, upperLimit: 400_000_000, rate: 0, label: "تا ۴۰ میلیون تومان — معاف" },
    { sortOrder: 2, lowerLimit: 400_000_000, upperLimit: 800_000_000, rate: 0.1, label: "۴۰ تا ۸۰ میلیون تومان" },
    { sortOrder: 3, lowerLimit: 800_000_000, upperLimit: 1_000_000_000, rate: 0.15, label: "۸۰ تا ۱۰۰ میلیون تومان" },
    { sortOrder: 4, lowerLimit: 1_000_000_000, upperLimit: 1_200_000_000, rate: 0.2, label: "۱۰۰ تا ۱۲۰ میلیون تومان" },
    { sortOrder: 5, lowerLimit: 1_200_000_000, upperLimit: 1_400_000_000, rate: 0.25, label: "۱۲۰ تا ۱۴۰ میلیون تومان" },
    { sortOrder: 6, lowerLimit: 1_400_000_000, upperLimit: null, rate: 0.3, label: "مازاد بر ۱۴۰ میلیون تومان" },
  ],
};

// ------------------- ورودی محاسبه -------------------
export interface PayrollContext {
  // مشخصات مؤثر بر مزایا
  childCount: number; // تعداد فرزند مشمول
  housingEnabled: boolean; // مشمول حق مسکن
  groceryEnabled: boolean; // مشمول بن کارگری
  seniorityYears: number; // سال خدمت (برای سنوات)
  seniorityBase: number; // پایه سنوات هر سال — ریال
  attraction: number; // حق جذب — ریال
  overtimeHours: number; // ساعت اضافه‌کاری
  otherAllowance: number; // سایر مزایا
  otherDeduction: number; // سایر کسورات
}

export const EMPTY_CONTEXT: PayrollContext = {
  childCount: 0,
  housingEnabled: true,
  groceryEnabled: true,
  seniorityYears: 0,
  seniorityBase: 0,
  attraction: 0,
  overtimeHours: 0,
  otherAllowance: 0,
  otherDeduction: 0,
};

// ------------------- خروجی محاسبه -------------------
export interface PaysheetItem {
  code: string;
  title: string;
  amount: number;
  insurable: boolean;
  taxable: boolean;
  kind: "EARNING" | "DEDUCTION";
}

export interface PaysheetResult {
  // اجزا
  baseSalary: number;
  seniority: number;
  housing: number;
  grocery: number;
  childAllowance: number;
  attraction: number;
  overtimeHours: number;
  overtimeAmount: number;
  otherAllowance: number;
  // جمع‌ها
  gross: number; // جمع حقوق و مزایا
  insurableBase: number; // مشمول بیمه
  employeeSso: number; // بیمه سهم کارگر ۷٪
  employerSso20: number; // بیمه سهم کارفرما ۲۰٪
  unemploymentSso3: number; // بیمه بیکاری ۳٪
  employerTotalSso: number; // جمع سهم کارفرما ۲۳٪
  taxableIncome: number; // درآمد مشمول مالیات
  incomeTax: number; // مالیات حقوق
  otherDeduction: number;
  totalDeductions: number;
  netPay: number; // خالص پرداختی
  employerTotalCost: number; // کل هزینه کارفرما (ناخالص + ۲۳٪)
  // جزئیات
  items: PaysheetItem[];
  warnings: string[];
}

/** مالیات پلکانی — درآمد ماهانه (ریال) */
export function progressiveTax(income: number, brackets: TaxBracket[]): number {
  if (income <= 0) return 0;
  const sorted = [...brackets].sort((a, b) => a.lowerLimit - b.lowerLimit);
  let tax = 0;
  for (const b of sorted) {
    if (income <= b.lowerLimit) break;
    const upper = b.upperLimit === null ? Infinity : b.upperLimit;
    const taxableInBracket = Math.min(income, upper) - b.lowerLimit;
    if (taxableInBracket > 0) tax += taxableInBracket * b.rate;
  }
  return Math.round(tax);
}

/** اجرای هر پله (برای نمایش جزئیات مالیات) */
export function taxBracketBreakdown(income: number, brackets: TaxBracket[]) {
  const sorted = [...brackets].sort((a, b) => a.lowerLimit - b.lowerLimit);
  return sorted.map((b) => {
    const upper = b.upperLimit === null ? Infinity : b.upperLimit;
    const inBracket = income > b.lowerLimit ? Math.max(0, Math.min(income, upper) - b.lowerLimit) : 0;
    return { ...b, taxableInBracket: inBracket, tax: Math.round(inBracket * b.rate) };
  });
}

// ------------------- محاسبه مستقیم -------------------
export function computePaysheet(baseSalary: number, ctx: PayrollContext, params: LegalParams): PaysheetResult {
  const warnings: string[] = [];
  const B = Math.max(0, Math.round(baseSalary));

  // ----- مزایا -----
  const seniority = Math.round(ctx.seniorityBase * Math.max(0, ctx.seniorityYears));
  const housing = ctx.housingEnabled ? params.housing : 0;
  const grocery = ctx.groceryEnabled ? params.grocery : 0;
  const childAllowance = Math.round(params.childPerChild * Math.min(ctx.childCount, params.maxChildrenForAllowance));
  const attraction = Math.round(ctx.attraction);
  // اضافه‌کاری: (پایه ÷ ساعت کاری ماهانه) × ۱.۴ × ساعت
  const overtimeAmount = Math.round((B / params.monthlyWorkHours) * params.overtimeMultiplier * ctx.overtimeHours);
  const otherAllowance = Math.round(ctx.otherAllowance);

  // ----- جمع حقوق و مزایا -----
  const gross = B + seniority + housing + grocery + childAllowance + attraction + overtimeAmount + otherAllowance;

  // ----- مشمول بیمه -----
  // بیمه‌پذیر: پایه + اضافه‌کاری
  // غیر بیمه‌پذیر: مسکن، بن، اولاد، سنوات، جذب
  const insurableRaw = B + overtimeAmount;
  let insurableBase = Math.max(insurableRaw, params.minWage);
  if (params.insurableCap !== null) insurableBase = Math.min(insurableBase, params.insurableCap);
  if (insurableRaw > 0 && insurableRaw < params.minWage) {
    warnings.push("مزد مشمول بیمه کمتر از حداقل دستمزد است؛ مبنا به حداقل دستمزد تعدیل شد.");
  }

  // ----- بیمه -----
  const employeeSso = Math.round(insurableBase * params.employeeSsoRate);
  const employerSso20 = Math.round(insurableBase * params.employerSsoRate);
  const unemploymentSso3 = Math.round(insurableBase * params.unemploymentRate);
  const employerTotalSso = employerSso20 + unemploymentSso3;

  // ----- درآمد مشمول مالیات -----
  // مشمول مالیات: همه اقلام مشمول مالیات − حق بیمه سهم کارگر (ماده ۹۲ ق.م.م)
  const taxableEarnings =
    B + seniority + housing + (params.groceryTaxable ? grocery : 0) + childAllowance + attraction + overtimeAmount + otherAllowance;
  const taxableIncome = Math.max(0, taxableEarnings - employeeSso);
  const incomeTax = progressiveTax(taxableIncome, params.taxBrackets);

  // ----- خالص -----
  const otherDeduction = Math.round(ctx.otherDeduction);
  const totalDeductions = employeeSso + incomeTax + otherDeduction;
  const netPay = gross - totalDeductions;
  const employerTotalCost = gross + employerTotalSso;

  if (B > 0 && B < params.minWage) {
    warnings.push("حقوق پایه کمتر از حداقل دستمزد مصوب ۱۴۰۵ است.");
  }

  const items: PaysheetItem[] = [
    { code: "BASE", title: "حقوق پایه", amount: B, insurable: true, taxable: true, kind: "EARNING" },
  ];
  if (seniority > 0) items.push({ code: "SENIORITY", title: "حق سنوات (خرید خدمت)", amount: seniority, insurable: false, taxable: true, kind: "EARNING" });
  if (housing > 0) items.push({ code: "HOUSING", title: "حق مسکن", amount: housing, insurable: false, taxable: true, kind: "EARNING" });
  if (grocery > 0) items.push({ code: "GROCERY", title: "بن کارگری (کمک‌هزینه اقلام مصرفی)", amount: grocery, insurable: false, taxable: params.groceryTaxable, kind: "EARNING" });
  if (childAllowance > 0) items.push({ code: "CHILD", title: "حق اولاد", amount: childAllowance, insurable: false, taxable: true, kind: "EARNING" });
  if (attraction > 0) items.push({ code: "ATTRACTION", title: "حق جذب", amount: attraction, insurable: false, taxable: true, kind: "EARNING" });
  if (overtimeAmount > 0) items.push({ code: "OVERTIME", title: `اضافه‌کاری (${ctx.overtimeHours} ساعت × ${params.overtimeMultiplier} مزد)`, amount: overtimeAmount, insurable: true, taxable: true, kind: "EARNING" });
  if (otherAllowance > 0) items.push({ code: "OTHER_ALW", title: "سایر مزایا", amount: otherAllowance, insurable: false, taxable: true, kind: "EARNING" });
  if (employeeSso > 0) items.push({ code: "SSO_EMP", title: `حق بیمه سهم کارمند (${params.employeeSsoRate * 100}٪)`, amount: employeeSso, insurable: false, taxable: false, kind: "DEDUCTION" });
  if (incomeTax > 0) items.push({ code: "TAX", title: "مالیات حقوق (پلکانی ۱۴۰۵)", amount: incomeTax, insurable: false, taxable: false, kind: "DEDUCTION" });
  if (otherDeduction > 0) items.push({ code: "OTHER_DED", title: "سایر کسورات", amount: otherDeduction, insurable: false, taxable: false, kind: "DEDUCTION" });

  return {
    baseSalary: B,
    seniority,
    housing,
    grocery,
    childAllowance,
    attraction,
    overtimeHours: ctx.overtimeHours,
    overtimeAmount,
    otherAllowance,
    gross,
    insurableBase,
    employeeSso,
    employerSso20,
    unemploymentSso3,
    employerTotalSso,
    taxableIncome,
    incomeTax,
    otherDeduction,
    totalDeductions,
    netPay,
    employerTotalCost,
    items,
    warnings,
  };
}

export interface EmployeeLike {
  baseSalary: number | bigint;
  childCount: number;
  maritalStatus: string;
  overtimeHours: number;
  hireDateJ: string;
}

export interface GradeLike {
  seniorityBase: number | bigint;
  attraction: number | bigint;
}

/** ساخت context محاسبه از مشخصات کارمند + طبقه */
export function contextFromEmployee(
  emp: EmployeeLike,
  grade: GradeLike | null,
  atDateJ: string,
  overrides?: Partial<PayrollContext>
): PayrollContext {
  const ctx: PayrollContext = {
    childCount: emp.childCount || 0,
    housingEnabled: true,
    groceryEnabled: true,
    seniorityYears: 0,
    seniorityBase: grade ? Number(grade.seniorityBase) : 0,
    attraction: grade ? Number(grade.attraction) : 0,
    overtimeHours: emp.overtimeHours || 0,
    otherAllowance: 0,
    otherDeduction: 0,
  };
  // سنوات بر اساس سال خدمت
  if (emp.hireDateJ) {
    const [y, m, d] = emp.hireDateJ.split("/").map(Number);
    const [ty, tm, td] = atDateJ.split("/").map(Number);
    if (!isNaN(y) && !isNaN(ty)) {
      const years = ty - y - (tm < m || (tm === m && td < d) ? 1 : 0);
      ctx.seniorityYears = Math.max(0, years);
    }
  }
  return { ...ctx, ...overrides };
}

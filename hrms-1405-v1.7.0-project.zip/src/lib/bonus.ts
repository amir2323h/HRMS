// ============================================================
// موتور پاداش/سود سالانه — بر اساس لِول‌بندی ۷ طبقه
// قواعد در SystemSetting (bonus_config) ذخیره می‌شوند — بدون هارد‌کد
// فرمول هر نفر: حقوق پایه × ماه پاداش طبقه (+۱ اور تارگت) × (ماه حضور ÷ ۱۲) × درصد تیر
// ============================================================
import { db } from "@/lib/db";

export interface BonusTier {
  key: string; // BELOW_80 | AT_80 | AT_100 | OVER_120
  label: string;
  minRatio: number; // حداقل نسبت تحقق برای قرار گرفتن در این تیر
  paymentPercent: number; // درصد پرداخت
  extraMonths: number; // ماه پاداش اضافه (اور تارگت = +۱)
}

export interface BonusConfig {
  /** ماه پاداش هر طبقه (معادل حقوق پایه بدون اضافات قانونی) */
  levels: Record<string, number>; // "1".."7" → 0..N
  tiers: BonusTier[];
}

export const TIER_KEYS = ["BELOW_80", "AT_80", "AT_100", "OVER_120"] as const;
export type TierKey = (typeof TIER_KEYS)[number];

export const TIER_LABELS: Record<string, string> = {
  BELOW_80: "نرسیده به تارگت",
  AT_80: "تا ۸۰٪ تارگت",
  AT_100: "تحقق ۱۰۰٪ تارگت",
  OVER_120: "اور تارگت (≥۱۲۰٪)",
};

/** پیکربندی پیش‌فرض مطابق سیاست سازمان — قابل ویرایش در تنظیمات */
export const BONUS_CONFIG_DEFAULT: BonusConfig = {
  levels: { "1": 0, "2": 3, "3": 3, "4": 5, "5": 6, "6": 7, "7": 9 },
  tiers: [
    { key: "BELOW_80", label: "نرسیده به تارگت (کمتر از ۸۰٪)", minRatio: 0, paymentPercent: 0, extraMonths: 0 },
    { key: "AT_80", label: "تا ۸۰٪ تارگت (۸۰٪ تا ۱۰۰٪)", minRatio: 0.8, paymentPercent: 80, extraMonths: 0 },
    { key: "AT_100", label: "تحقق ۱۰۰٪ تارگت (۱۰۰٪ تا ۱۲۰٪)", minRatio: 1.0, paymentPercent: 100, extraMonths: 0 },
    { key: "OVER_120", label: "اور تارگت (۱۲۰٪ و بیشتر)", minRatio: 1.2, paymentPercent: 100, extraMonths: 1 },
  ],
};

export async function getBonusConfig(): Promise<BonusConfig> {
  const row = await db.systemSetting.findUnique({ where: { key: "bonus_config" } });
  if (!row) return structuredClone(BONUS_CONFIG_DEFAULT);
  try {
    const stored = JSON.parse(row.value) as Partial<BonusConfig>;
    const cfg = structuredClone(BONUS_CONFIG_DEFAULT);
    if (stored.levels && typeof stored.levels === "object") {
      // فقط مقادیر عددی معتبر طبقات ۱..۷
      for (const k of Object.keys(cfg.levels)) {
        const v = (stored.levels as Record<string, unknown>)[k];
        if (v !== undefined && v !== null && !isNaN(+v) && +v >= 0) cfg.levels[k] = +v;
      }
    }
    if (Array.isArray(stored.tiers) && stored.tiers.length === 4) {
      cfg.tiers = cfg.tiers.map((def, i) => {
        const s = stored.tiers![i];
        return {
          key: def.key,
          label: typeof s?.label === "string" && s.label ? s.label : def.label,
          minRatio: !isNaN(+s?.minRatio) ? +s.minRatio : def.minRatio,
          paymentPercent: !isNaN(+s?.paymentPercent) ? +s.paymentPercent : def.paymentPercent,
          extraMonths: !isNaN(+s?.extraMonths) ? +s.extraMonths : def.extraMonths,
        };
      });
    }
    return cfg;
  } catch {
    return structuredClone(BONUS_CONFIG_DEFAULT);
  }
}

export async function saveBonusConfig(cfg: BonusConfig): Promise<void> {
  await db.systemSetting.upsert({
    where: { key: "bonus_config" },
    update: { value: JSON.stringify(cfg) },
    create: { key: "bonus_config", value: JSON.stringify(cfg) },
  });
}

/** تعیین تیر از روی نسبت تحقق (مرتب‌شده نزولی — بالاترین تیرِ برخوردار) */
export function resolveTier(cfg: BonusConfig, ratio: number): BonusTier {
  const sorted = [...cfg.tiers].sort((a, b) => (b.minRatio || 0) - (a.minRatio || 0));
  for (const t of sorted) {
    if (ratio >= (t.minRatio || 0)) return t;
  }
  return sorted[sorted.length - 1];
}

export function tierByKey(cfg: BonusConfig, key: string): BonusTier {
  return cfg.tiers.find((t) => t.key === key) || cfg.tiers[cfg.tiers.length - 1];
}

/** ماه حضور در سال طرح — از تاریخ استخدام تا تاریخ مرجع (سقف ۱۲، دقت ۱ رقم اعشار) */
export function monthsPresent(hireDateJ: string, referenceDateJ: string): number {
  if (!/^\d{4}\/\d{2}\/\d{2}$/.test(hireDateJ || "") || !/^\d{4}\/\d{2}\/\d{2}$/.test(referenceDateJ || "")) return 0;
  const [hy, hm, hd] = hireDateJ.split("/").map(Number);
  const [ry, rm, rd] = referenceDateJ.split("/").map(Number);
  const months = (ry - hy) * 12 + (rm - hm) + (rd - hd) / 30.4375;
  return Math.max(0, Math.min(12, Math.round(months * 10) / 10));
}

export interface BonusEmployeeInput {
  id: string;
  firstName: string;
  lastName: string;
  personnelCode: string;
  baseSalary: bigint;
  jobGradeId: string | null;
  hireDateJ: string;
  status: string;
}

export interface BonusLineResult {
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  department: string;
  jobLevel: number;
  jobLevelTitle: string;
  baseSalary: bigint;
  bonusMonths: number;
  monthsPresent: number;
  paymentPercent: number;
  computedAmount: bigint;
  finalAmount: bigint;
}

/** محاسبه کامل خطوط طرح — همه مبالغ ریال */
export function computeSchemeLines(
  cfg: BonusConfig,
  tier: BonusTier,
  referenceDateJ: string,
  employees: BonusEmployeeInput[],
  deptNameOf: (employeeId: string) => string,
  gradeOf: (gradeId: string | null) => { level: number; title: string } | null,
): { lines: BonusLineResult[]; totalComputed: bigint; totalFinal: bigint } {
  const lines: BonusLineResult[] = [];
  for (const e of employees) {
    if (e.status === "TERMINATED") continue;
    const grade = gradeOf(e.jobGradeId);
    const level = grade?.level || 0;
    const levelMonths = level >= 1 && level <= 7 ? (cfg.levels[String(level)] ?? 0) : 0;
    const bonusMonths = levelMonths + (tier.extraMonths || 0);
    const present = monthsPresent(e.hireDateJ, referenceDateJ);
    const base = Number(e.baseSalary || 0n);
    const computed = Math.round(base * bonusMonths * (present / 12));
    const finalAmt = Math.round(computed * ((tier.paymentPercent || 0) / 100));
    lines.push({
      employeeId: e.id,
      employeeName: `${e.firstName} ${e.lastName}`.trim(),
      personnelCode: e.personnelCode,
      department: deptNameOf(e.id),
      jobLevel: level,
      jobLevelTitle: level > 0 ? `طبقه ${level}${grade ? ` — ${grade.title}` : ""}` : "بدون طبقه",
      baseSalary: e.baseSalary || 0n,
      bonusMonths,
      monthsPresent: present,
      paymentPercent: tier.paymentPercent || 0,
      computedAmount: BigInt(computed),
      finalAmount: BigInt(finalAmt),
    });
  }
  // مرتب‌سازی: طبقه نزولی، سپس نام
  lines.sort((a, b) => b.jobLevel - a.jobLevel || a.employeeName.localeCompare(b.employeeName, "fa"));
  let totalComputed = 0n;
  let totalFinal = 0n;
  for (const l of lines) {
    totalComputed += l.computedAmount;
    totalFinal += l.finalAmount;
  }
  return { lines, totalComputed, totalFinal };
}

/** مقیاس‌بندی خطی خطوط برای جا شدن در بودجه (final → final × budget/total) */
export function scaleLinesToBudget(lines: BonusLineResult[], budget: bigint): BonusLineResult[] {
  const total = lines.reduce((s, l) => s + l.finalAmount, 0n);
  if (budget <= 0n || total <= 0n || total <= budget) return lines;
  const factor = Number(budget) / Number(total);
  return lines.map((l) => ({ ...l, finalAmount: BigInt(Math.round(Number(l.finalAmount) * factor)) }));
}


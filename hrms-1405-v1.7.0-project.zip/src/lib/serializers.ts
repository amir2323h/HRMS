// ============================================================
// سریالایزرها — تبدیل رکوردهای Prisma (با BigInt/Bytes) به JSON امن
// ============================================================
import type { Prisma } from "@prisma/client";

type AnyRecord = Record<string, unknown>;

export function serializeEmployee(
  emp: AnyRecord & {
    jobGrade?: AnyRecord | null;
    departments?: { department: AnyRecord }[];
    insuranceDependents?: AnyRecord[];
    jobTitleRef?: AnyRecord | null;
  }
) {
  return {
    id: emp.id as string,
    personnelCode: emp.personnelCode as string,
    firstName: emp.firstName as string,
    lastName: emp.lastName as string,
    fullName: `${emp.firstName} ${emp.lastName}`,
    nationalId: emp.nationalId as string,
    ssoNumber: emp.ssoNumber as string,
    mobile: emp.mobile as string,
    email: emp.email as string,
    address: emp.address as string,
    maritalStatus: emp.maritalStatus as string,
    childCount: emp.childCount as number,
    hireDateJ: emp.hireDateJ as string,
    probationEndDateJ: emp.probationEndDateJ as string,
    contractType: emp.contractType as string,
    contractStartJ: emp.contractStartJ as string,
    contractEndJ: emp.contractEndJ as string,
    jobTitle: emp.jobTitle as string,
    jobTitleId: (emp.jobTitleId as string) || null,
    jobTitleCode: (emp.jobTitleRef?.code as string) || "",
    status: emp.status as string,
    bankName: emp.bankName as string,
    iban: emp.iban as string,
    notes: emp.notes as string,
    overtimeHours: emp.overtimeHours as number,
    baseSalary: Number(emp.baseSalary),
    suppInsurance: (emp.suppInsurance as string) || "NONE",
    suppCoveredCount: (emp.suppCoveredCount as number) || 0,
    suppInsurerName: (emp.suppInsurerName as string) || "",
    suppPolicyNumber: (emp.suppPolicyNumber as string) || "",
    suppDependents: (emp.insuranceDependents || []).map((d: AnyRecord) => ({
      id: d.id as string,
      firstName: d.firstName as string,
      lastName: d.lastName as string,
      nationalId: d.nationalId as string,
      relationship: d.relationship as string,
      birthDateJ: d.birthDateJ as string,
    })),
    welfare: (emp.welfare || []).map((w: { welfareItem?: AnyRecord } & AnyRecord) => ({
      id: (w.welfareItem?.id as string) || "",
      code: (w.welfareItem?.code as string) || "",
      title: (w.welfareItem?.title as string) || "",
    })),
    jobGradeId: (emp.jobGradeId as string) || null,
    grade: emp.jobGrade
      ? {
          id: emp.jobGrade.id as string,
          level: emp.jobGrade.level as number,
          title: emp.jobGrade.title as string,
          code: emp.jobGrade.code as string,
          minBaseSalary: Number(emp.jobGrade.minBaseSalary),
          maxBaseSalary: Number(emp.jobGrade.maxBaseSalary),
          seniorityBase: Number(emp.jobGrade.seniorityBase),
          attraction: Number(emp.jobGrade.attraction),
        }
      : null,
    departments: (emp.departments || []).map(
      (ed: { department: AnyRecord }) => ({
        id: ed.department.id as string,
        code: ed.department.code as string,
        name: ed.department.name as string,
        costCenterCode: ed.department.costCenterCode as string,
        parentId: ed.department.parentId as string | null,
      })
    ),
    primaryDepartment:
      (emp.departments && emp.departments[0]?.department) ?
        {
          id: (emp.departments[0].department as AnyRecord).id as string,
          code: (emp.departments[0].department as AnyRecord).code as string,
          name: (emp.departments[0].department as AnyRecord).name as string,
          costCenterCode: (emp.departments[0].department as AnyRecord).costCenterCode as string,
        }
      : null,
    createdAt: (emp.createdAt as Date)?.toISOString?.() ?? null,
  };
}

export function serializeGrade(g: AnyRecord, employeeCount?: number) {
  return {
    id: g.id as string,
    level: g.level as number,
    code: g.code as string,
    title: g.title as string,
    description: g.description as string,
    minBaseSalary: Number(g.minBaseSalary),
    maxBaseSalary: Number(g.maxBaseSalary),
    seniorityBase: Number(g.seniorityBase),
    attraction: Number(g.attraction),
    employeeCount: employeeCount ?? 0,
  };
}

export function serializeDepartment(d: AnyRecord) {
  return {
    id: d.id as string,
    code: d.code as string,
    name: d.name as string,
    description: d.description as string,
    costCenterCode: d.costCenterCode as string,
    parentId: d.parentId as string | null,
    managerEmployeeId: d.managerEmployeeId as string | null,
  };
}

export function serializePayslip(
  p: AnyRecord & {
    employee?: AnyRecord | null;
    period?: AnyRecord | null;
  }
) {
  return {
    id: p.id as string,
    periodId: p.periodId as string,
    employeeId: p.employeeId as string,
    employee: p.employee
      ? {
          id: p.employee.id as string,
          fullName: `${p.employee.firstName} ${p.employee.lastName}`,
          personnelCode: p.employee.personnelCode as string,
          nationalId: p.employee.nationalId as string,
          ssoNumber: p.employee.ssoNumber as string,
          iban: p.employee.iban as string,
          bankName: p.employee.bankName as string,
          jobTitle: p.employee.jobTitle as string,
          childCount: p.employee.childCount as number,
          maritalStatus: p.employee.maritalStatus as string,
          hireDateJ: p.employee.hireDateJ as string,
          baseSalary: Number(p.employee.baseSalary),
          // واحدهای سازمانی کارمند با درصد تخصیص (برای سهم واحدها از هزینه دوره)
          departments: ((p.employee as AnyRecord).departments || []).map(
            (ed: { department?: AnyRecord; allocationPercent?: number }) => ({
              id: (ed.department as AnyRecord)?.id as string,
              name: (ed.department as AnyRecord)?.name as string,
              allocationPercent: ed.allocationPercent ?? 100,
            })
          ),
        }
      : null,
    period: p.period ? { id: p.period.id as string, year: p.period.year as number, month: p.period.month as number, status: p.period.status as string } : null,
    baseSalary: Number(p.baseSalary),
    seniority: Number(p.seniority),
    housing: Number(p.housing),
    grocery: Number(p.grocery),
    childAllowance: Number(p.childAllowance),
    attraction: Number(p.attraction),
    overtimeHours: p.overtimeHours as number,
    overtimeAmount: Number(p.overtimeAmount),
    otherAllowance: Number(p.otherAllowance),
    gross: Number(p.gross),
    insurableBase: Number(p.insurableBase),
    employeeSso: Number(p.employeeSso),
    employerSso20: Number(p.employerSso20),
    unemploymentSso3: Number(p.unemploymentSso3),
    taxableIncome: Number(p.taxableIncome),
    incomeTax: Number(p.incomeTax),
    otherDeduction: Number(p.otherDeduction),
    netPay: Number(p.netPay),
    isReverse: p.isReverse as boolean,
    targetNet: p.targetNet === null ? null : Number(p.targetNet),
    createdAt: (p.createdAt as Date)?.toISOString?.() ?? null,
  };
}

export function serializePeriod(period: AnyRecord & { payslips?: AnyRecord[] }) {
  const slips = (period.payslips || []) as AnyRecord[];
  const sum = (key: string) => slips.reduce((acc, s) => acc + Number(s[key] || 0), 0);
  return {
    id: period.id as string,
    year: period.year as number,
    month: period.month as number,
    status: period.status as string,
    notes: period.notes as string,
    payslipCount: slips.length,
    totals: {
      gross: sum("gross"),
      netPay: sum("netPay"),
      employeeSso: sum("employeeSso"),
      employerSso20: sum("employerSso20"),
      unemploymentSso3: sum("unemploymentSso3"),
      incomeTax: sum("incomeTax"),
      childAllowance: sum("childAllowance"),
      housing: sum("housing"),
      grocery: sum("grocery"),
      overtimeAmount: sum("overtimeAmount"),
      seniority: sum("seniority"),
      attraction: sum("attraction"),
      employerTotalCost: sum("gross") + sum("employerSso20") + sum("unemploymentSso3"),
    },
  };
}

export function serializeContractTemplate(t: AnyRecord, issuedCount?: number) {
  return {
    id: t.id as string,
    title: t.title as string,
    contractType: t.contractType as string,
    body: t.body as string,
    notes: t.notes as string,
    isActive: t.isActive as boolean,
    version: t.version as number,
    issuedCount: issuedCount ?? 0,
    updatedAt: (t.updatedAt as Date)?.toISOString?.() ?? null,
    createdAt: (t.createdAt as Date)?.toISOString?.() ?? null,
  };
}

export function serializeContract(c: AnyRecord & { employee?: AnyRecord | null }) {
  return {
    id: c.id as string,
    contractNumber: c.contractNumber as string,
    templateId: (c.templateId as string) || null,
    templateTitle: c.templateTitle as string,
    templateVersion: c.templateVersion as number,
    employeeId: c.employeeId as string,
    employeeName: c.employeeName as string || (c.employee ? `${c.employee.firstName} ${c.employee.lastName}` : ""),
    personnelCode: c.personnelCode as string,
    title: c.title as string,
    contractType: c.contractType as string,
    status: c.status as string,
    issueDateJ: c.issueDateJ as string,
    startDateJ: c.startDateJ as string,
    endDateJ: c.endDateJ as string,
    signedDateJ: c.signedDateJ as string,
    terminateDateJ: c.terminateDateJ as string,
    terminateReason: c.terminateReason as string,
    createdBy: c.createdBy as string,
    createdAt: (c.createdAt as Date)?.toISOString?.() ?? null,
    body: c.body as string,
  };
}

export function serializeAudit(a: AnyRecord) {
  return {
    id: a.id as string,
    userName: a.userName as string,
    action: a.action as string,
    entity: a.entity as string,
    entityId: a.entityId as string,
    summary: a.summary as string,
    before: a.before ? safeJson(a.before as string) : null,
    after: a.after ? safeJson(a.after as string) : null,
    createdAt: (a.createdAt as Date)?.toISOString?.() ?? null,
  };
}

function safeJson(s: string): unknown {
  try {
    return JSON.parse(s);
  } catch {
    return s;
  }
}

export function serializeDocument(d: AnyRecord) {
  return {
    id: d.id as string,
    employeeId: d.employeeId as string,
    type: d.type as string,
    title: d.title as string,
    fileName: d.fileName as string,
    mimeType: d.mimeType as string,
    size: d.size as number,
    description: d.description as string,
    uploadedBy: d.uploadedBy as string,
    createdAt: (d.createdAt as Date)?.toISOString?.() ?? null,
  };
}

export type EmployeeInclude = Prisma.EmployeeInclude;

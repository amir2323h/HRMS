// ============================================================
// ماژول درخواست‌نامه — رندر قالب با فیلدهای داینامیک + شماره سیستمی + امضای دیجیتال
// + نامه دستی (بدون قالب — ثبت توسط کارشناس اداری)
// ============================================================
import { createHmac } from "crypto";
import { db } from "@/lib/db";
import { toFaDigits, todayJalaliStr } from "@/lib/jalali";
import { toEnDigits, groupFa } from "@/lib/format";
import { renderTemplate } from "@/lib/contracts";

export interface LetterFieldDef {
  key: string; // کلید (حروف لاتین/زیرخط) — در قالب: {{field_key}}
  label: string; // برچسب فارسی فرم
  type: "text" | "number" | "date" | "select" | "textarea";
  options?: string[]; // برای select
  required?: boolean;
  placeholder?: string;
}

export function parseLetterFields(fieldsJson: string): LetterFieldDef[] {
  try {
    const arr = JSON.parse(fieldsJson || "[]") as LetterFieldDef[];
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((f) => f && typeof f.key === "string" && /^[a-z][a-z0-9_]*$/i.test(f.key))
      .map((f) => ({
        key: f.key,
        label: String(f.label || f.key),
        type: (["text", "number", "date", "select", "textarea"].includes(f.type) ? f.type : "text") as LetterFieldDef["type"],
        options: Array.isArray(f.options) ? f.options.map(String) : undefined,
        required: !!f.required,
        placeholder: f.placeholder ? String(f.placeholder) : undefined,
      }));
  } catch {
    return [];
  }
}

export function validateLetterFields(fields: LetterFieldDef[], values: Record<string, string>): string[] {
  const errors: string[] = [];
  for (const f of fields) {
    const v = (values[f.key] || "").trim();
    if (f.required && !v) errors.push(`«${f.label}» الزامی است.`);
    if (v && f.type === "number") {
      const en = toEnDigits(v).replace(/[,٬،\s]/g, "");
      if (isNaN(Number(en))) errors.push(`«${f.label}» باید عدد باشد.`);
    }
    if (v && f.type === "date" && !/^\d{4}\/\d{2}\/\d{2}$/.test(toEnDigits(v))) {
      errors.push(`«${f.label}» باید تاریخ معتبر (۱۴۰۵/۰۱/۱۵) باشد.`);
    }
  }
  return errors;
}

/** متغیرهای رندر نامه: متغیرهای کارمند + مقادیر فیلدها + شماره/تاریخ نامه */
export function buildLetterVars(input: {
  employee: {
    firstName?: string; lastName?: string; fatherName?: string; nationalId?: string; personnelCode?: string;
    jobTitle?: string; mobile?: string; address?: string; hireDateJ?: string; baseSalary?: bigint | number;
    jobGrade?: { level: number; title: string } | null;
  };
  company: { name: string; nationalId: string; address: string };
  fields: LetterFieldDef[];
  values: Record<string, string>;
  letterNumber?: string;
}): Record<string, string> {
  const e = input.employee;
  const vars: Record<string, string> = {
    company_name: input.company.name,
    company_national_id: toFaDigits(input.company.nationalId || ""),
    company_address: input.company.address || "",
    employee_name: `${e.firstName || ""} ${e.lastName || ""}`.trim(),
    employee_first_name: e.firstName || "",
    employee_last_name: e.lastName || "",
    employee_father_name: e.fatherName || "",
    employee_national_id: toFaDigits(e.nationalId || ""),
    employee_personnel_code: toFaDigits(e.personnelCode || ""),
    employee_job_title: e.jobTitle || "",
    employee_grade: e.jobGrade ? `سطح ${toFaDigits(e.jobGrade.level)} — ${e.jobGrade.title}` : "",
    employee_mobile: toFaDigits(e.mobile || ""),
    employee_address: e.address || "",
    employee_hire_date: toFaDigits(e.hireDateJ || ""),
    base_salary_toman: groupFa(Math.round(Number(e.baseSalary || 0) / 10)),
    letter_number: input.letterNumber || "",
    today_date: toFaDigits(todayJalaliStr()),
  };
  // مقادیر فیلدهای داینامیک — {{field_key}} + {{key}} برای راحتی
  for (const f of input.fields) {
    const raw = (input.values[f.key] ?? "").toString();
    let shown = raw;
    if (f.type === "number" && raw) {
      const n = Number(toEnDigits(raw).replace(/[,٬،\s]/g, ""));
      if (!isNaN(n)) shown = groupFa(n);
    }
    vars[`field_${f.key}`] = shown;
    vars[f.key] = shown;
    vars[f.key + "_label"] = f.label;
  }
  return vars;
}

export function renderLetter(bodyTemplate: string, vars: Record<string, string>): string {
  return renderTemplate(bodyTemplate, vars);
}

/** شماره سیستمی نامه — الگوی مکاتبات رسمی: ZDX_AD_0507019
 *  ساختار: {پیش‌شماره سازمان}_{کد دسته}_{سال دو رقمی}{ماه دو رقمی}{دنباله سه رقمی}
 *  کد دسته: ADMIN→AD | HR→HR | FINANCE→FN | GENERAL→GN
 *  دنباله هر ماه از ۰۰۱ شروع می‌شود (تطبیق با الگوی نامه مرجع کاربر) */
export const LETTER_CATEGORY_CODES: Record<string, string> = {
  ADMIN: "AD",
  HR: "HR",
  FINANCE: "FN",
  GENERAL: "GN",
};

/** امضاکننده مجاز نامه — فهرست قابل مدیریت از تنظیمات (دراپ‌داون فرم نامه دستی)
 *  signature: تصویر امضای دست‌نویس (data URL PNG/JPG ≤ ۱MB) — کنار نام امضاکننده چاپ می‌شود */
export interface LetterSigner {
  name: string;
  title: string;
  signature?: string;
}

/** تنظیمات شماره‌گذاری/امضاکننده/سربرگ نامه — SystemSetting «letters» */
export interface LetterSettings {
  numberingPrefix: string;
  signerName: string;
  signerTitle: string;
  /** امضاکنندگان مجاز — انتخاب از دراپ‌داون در فرم ثبت نامه دستی */
  signers: LetterSigner[];
  /** تصویر PNG سربرگ رسمی شرکت (data URL) — پس‌زمینه نامه‌های چاپی */
  letterheadA4: string;
  letterheadA5: string;
  /** فاصله محتوا از لبه بالا/پایین (میلی‌متر) وقتی تصویر سربرگ فعال است */
  letterheadA4TopMm: number;
  letterheadA4BottomMm: number;
  letterheadA5TopMm: number;
  letterheadA5BottomMm: number;
}

export const LETTER_SETTINGS_DEFAULTS: LetterSettings = {
  numberingPrefix: "ZDX",
  signerName: "",
  signerTitle: "مدیر عامل",
  signers: [],
  letterheadA4: "",
  letterheadA5: "",
  letterheadA4TopMm: 42,
  letterheadA4BottomMm: 24, // پابرگ سربرگ رسمی معمولاً ۱۵–۲۲mm است — ۲۴mm فاصله امن
  letterheadA5TopMm: 30,
  letterheadA5BottomMm: 18,
};

/** محدودیت تصویر سربرگ — پس از base64 (۳ مگابایت) */
export const LETTERHEAD_MAX_BYTES = 3 * 1024 * 1024;

/** محدودیت تصویر امضای امضاکننده — پس از base64 (۱ مگابایت) */
export const SIGNER_SIGNATURE_MAX_BYTES = 1 * 1024 * 1024;

/** اعتبارسنجی تصویر امضا — data URL با فرمت مجاز و حجم ≤ ۱MB (خالی = بدون امضا) */
function sanitizeSignerSignature(v: unknown): string {
  const s = String(v ?? "").trim();
  if (!s) return "";
  const m = s.match(/^data:(image\/(?:png|jpeg));base64,(.+)$/);
  if (!m) return ""; // نامعتبر = حذف (نه خطا — سازگاری با داده قدیمی)
  const bytes = Math.floor((m[2].length * 3) / 4);
  if (bytes > SIGNER_SIGNATURE_MAX_BYTES) return "";
  return s;
}

function clampMm(v: unknown, fallback: number, max = 150): number {
  const n = Math.round(Number(v));
  if (isNaN(n) || n < 5) return fallback;
  return Math.min(n, max);
}

/** نرمال‌سازی فهرست امضاکنندگان مجاز — حداکثر ۲۰ نفر با نام/سمت تمیز + تصویر امضای معتبر */
export function parseLetterSigners(v: unknown): LetterSigner[] {
  if (!Array.isArray(v)) return [];
  return v
    .map((s) => ({
      name: String((s as LetterSigner)?.name ?? "").trim().slice(0, 80),
      title: String((s as LetterSigner)?.title ?? "").trim().slice(0, 80),
      signature: sanitizeSignerSignature((s as LetterSigner)?.signature),
    }))
    .filter((s) => s.name)
    .slice(0, 20);
}

export async function getLetterSettings(): Promise<LetterSettings> {
  const row = await db.systemSetting.findUnique({ where: { key: "letters" } });
  if (row) {
    try {
      const stored = JSON.parse(row.value) as Partial<LetterSettings>;
      const merged = { ...LETTER_SETTINGS_DEFAULTS, ...stored };
      // نرمال‌سازی فیلدهای عددی (داده قدیمی ممکن است این فیلدها را نداشته باشد)
      return {
        ...merged,
        signers: parseLetterSigners(merged.signers),
        letterheadA4: typeof merged.letterheadA4 === "string" ? merged.letterheadA4 : "",
        letterheadA5: typeof merged.letterheadA5 === "string" ? merged.letterheadA5 : "",
        letterheadA4TopMm: clampMm(merged.letterheadA4TopMm, LETTER_SETTINGS_DEFAULTS.letterheadA4TopMm),
        letterheadA4BottomMm: clampMm(merged.letterheadA4BottomMm, LETTER_SETTINGS_DEFAULTS.letterheadA4BottomMm),
        letterheadA5TopMm: clampMm(merged.letterheadA5TopMm, LETTER_SETTINGS_DEFAULTS.letterheadA5TopMm),
        letterheadA5BottomMm: clampMm(merged.letterheadA5BottomMm, LETTER_SETTINGS_DEFAULTS.letterheadA5BottomMm),
      };
    } catch {
      /* مقادیر پیش‌فرض */
    }
  }
  return { ...LETTER_SETTINGS_DEFAULTS };
}

export async function saveLetterSettings(patch: Partial<LetterSettings>): Promise<LetterSettings> {
  const current = await getLetterSettings();
  const next: LetterSettings = {
    numberingPrefix: (patch.numberingPrefix ?? current.numberingPrefix).trim().toUpperCase().replace(/[^A-Z0-9]/g, "") || "ZDX",
    signerName: (patch.signerName ?? current.signerName).trim().slice(0, 80),
    signerTitle: (patch.signerTitle ?? current.signerTitle).trim().slice(0, 80),
    signers: patch.signers !== undefined ? parseLetterSigners(patch.signers) : current.signers,
    // تصویر سربرگ — undefined = بدون تغییر، "" = حذف
    letterheadA4: patch.letterheadA4 !== undefined ? patch.letterheadA4 : current.letterheadA4,
    letterheadA5: patch.letterheadA5 !== undefined ? patch.letterheadA5 : current.letterheadA5,
    letterheadA4TopMm: patch.letterheadA4TopMm !== undefined ? clampMm(patch.letterheadA4TopMm, current.letterheadA4TopMm) : current.letterheadA4TopMm,
    letterheadA4BottomMm: patch.letterheadA4BottomMm !== undefined ? clampMm(patch.letterheadA4BottomMm, current.letterheadA4BottomMm) : current.letterheadA4BottomMm,
    letterheadA5TopMm: patch.letterheadA5TopMm !== undefined ? clampMm(patch.letterheadA5TopMm, current.letterheadA5TopMm) : current.letterheadA5TopMm,
    letterheadA5BottomMm: patch.letterheadA5BottomMm !== undefined ? clampMm(patch.letterheadA5BottomMm, current.letterheadA5BottomMm) : current.letterheadA5BottomMm,
  };
  await db.systemSetting.upsert({
    where: { key: "letters" },
    update: { value: JSON.stringify(next) },
    create: { key: "letters", value: JSON.stringify(next) },
  });
  return next;
}

/** نسخه سبک تنظیمات نامه برای پاسخ‌های API (بدون تصاویر سنگین base64) */
export function stripLetterImages(s: LetterSettings): Omit<LetterSettings, "letterheadA4" | "letterheadA5"> {
  const { letterheadA4: _a4, letterheadA5: _a5, ...rest } = s;
  return rest;
}

/** اعتبارسنجی تصویر سربرگ — data URL با فرمت مجاز و حجم ≤ ۳MB */
export function validateLetterheadImage(dataUrl: string, what: string): string | null {
  if (!dataUrl) return null; // خالی = حذف مجاز
  const m = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!m) return `فرمت ${what} نامعتبر است (باید data URL باشد).`;
  const mime = m[1];
  if (!["image/png", "image/jpeg"].includes(mime)) {
    return `فرمت ${what} باید PNG یا JPG باشد.`;
  }
  const bytes = Math.floor((m[2].length * 3) / 4);
  if (bytes > LETTERHEAD_MAX_BYTES) {
    return `حجم ${what} نباید بیش از ۳ مگابایت باشد.`;
  }
  return null;
}

/** شماره سیستمی نامه مطابق الگوی ZDX_AD_0507019 — دنباله یکتا در هر ماه/دسته */
export async function nextLetterNumber(category: string): Promise<string> {
  const { numberingPrefix } = await getLetterSettings();
  const code = LETTER_CATEGORY_CODES[category] || "GN";
  const j = todayJalaliStr(); // 1405/07/13
  const yy = j.slice(2, 4);
  const mm = j.slice(5, 7);
  const stem = `${numberingPrefix}_${code}_${yy}${mm}`; // ZDX_AD_0507
  const existing = await db.letterRequest.findMany({
    where: { number: { startsWith: stem } },
    select: { number: true },
  });
  let max = 0;
  for (const r of existing) {
    const n = parseInt(r.number.slice(stem.length), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  for (let i = max + 1; ; i++) {
    const candidate = `${stem}${String(i).padStart(3, "0")}`;
    const clash = await db.letterRequest.findUnique({ where: { number: candidate } });
    if (!clash) return candidate;
  }
}

// ---------- آیتم‌های جدول نامه دستی (مثل لیست اشخاص/کد ملی در نامه مرجع) ----------
export interface LetterItem {
  title: string; // شرح/نام
  code: string; // کد ملی/شناسه (اختیاری)
}

export function parseLetterItems(itemsJson: string): LetterItem[] {
  try {
    const arr = JSON.parse(itemsJson || "[]") as LetterItem[];
    if (!Array.isArray(arr)) return [];
    return arr
      .filter((it) => it && (typeof it.title === "string" || typeof it.code === "string"))
      .map((it) => ({ title: String(it.title || "").trim(), code: String(it.code || "").trim() }))
      .filter((it) => it.title || it.code);
  } catch {
    return [];
  }
}

// برچسب‌های وضعیت/دسته نامه در lib/format (ایمن برای کلاینت) تعریف شده‌اند

// ============================ امضای دیجیتال ============================
// کد امضای دیجیتال = HMAC-SHA256 روی محتوای تغییرناپذیر نامه (شماره، نام کارمند،
// کد پرسنلی، عنوان، متن کامل، تأییدکننده و زمان تأیید) با AUTH_SECRET.
// - هنگام «تأیید» محاسبه و در signatureCode قفل می‌شود.
// - راستی‌آزمایی: بازمحاسبه از داده فعلی و مقایسه با کد ذخیره‌شده —
//   هر دستکاری پس از تأیید (متن/نام/تاریخ) باعث نامعتبر شدن کد می‌شود.

const SIGN_SECRET = process.env.AUTH_SECRET || "hrms-1405-local-secret-key-change-in-production";

export interface LetterSignatureInput {
  number: string;
  employeeName: string;
  personnelCode: string;
  title: string;
  body: string;
  decidedBy: string;
  decidedAt: Date | string | null;
  recipient?: string; // گیرنده (نامه دستی)
  items?: string; // itemsJson خام (نامه دستی)
  signerName?: string; // امضاکننده (نامه دستی)
  signerTitle?: string; // سمت امضاکننده (نامه دستی)
  bodyHtml?: string | null; // متن غنی (نامه دستی — جدول/قالب‌بندی)
}

/** بارگذاری محتوای نامه برای امضا — ترتیب فیلدها نباید تغییر کند
 *  فیلدهای نامه دستی فقط وقتی «مقدار معنادار» دارند به انتهای payload اضافه می‌شوند —
 *  تا امضای نامه‌های قدیمی (این فیلدها خالی/پیش‌فرض) همچنان معتبر بماند.
 *  نکته: itemsJson پیش‌فرض «[]» است و باید مثل خالی رفتار شود. */
function letterSignaturePayload(l: LetterSignatureInput): string {
  const at = l.decidedAt instanceof Date ? l.decidedAt.toISOString() : String(l.decidedAt || "");
  let payload = [l.number, l.employeeName, l.personnelCode, l.title, l.body, l.decidedBy, at].join("\u0001");
  const itemsStr = (l.items || "").trim();
  const hasItems = !!itemsStr && itemsStr !== "[]";
  if ((l.recipient || "").trim() || hasItems || (l.signerName || "").trim() || (l.signerTitle || "").trim()) {
    payload +=
      "\u0001" +
      (l.recipient || "") +
      "\u0001" +
      (hasItems ? itemsStr : "") +
      "\u0001" +
      (l.signerName || "") +
      "\u0001" +
      (l.signerTitle || "");
  }
  // متن غنی — قطعه جدا با نشانگر «R2»: نامه‌های قدیمی (بدون bodyHtml) امضایشان
  // بدون این قطعه محاسبه شده و باید بدون آن بازمحاسبه شود (سازگاری).
  const bodyHtml = (l.bodyHtml || "").trim();
  if (bodyHtml) payload += "\u0001R2" + bodyHtml;
  return payload;
}

/** محاسبه کد امضای دیجیتال — ۱۶ نویسه hex با گروه‌بندی چهارتایی (XXXX-XXXX-XXXX-XXXX) */
export function computeLetterSignatureCode(l: LetterSignatureInput): string {
  const digest = createHmac("sha256", SIGN_SECRET).update(letterSignaturePayload(l), "utf8").digest("hex");
  const raw = digest.slice(0, 16).toUpperCase();
  return [raw.slice(0, 4), raw.slice(4, 8), raw.slice(8, 12), raw.slice(12, 16)].join("-");
}

/** راستی‌آزمایی: کد ذخیره‌شده هنگام تأیید با محتوای فعلی نامه مطابقت دارد؟ */
export function verifyLetterSignature(l: LetterSignatureInput & { signatureCode?: string | null }): boolean {
  if (!l.signatureCode) return false;
  const expected = computeLetterSignatureCode(l);
  return expected === l.signatureCode.trim().toUpperCase();
}

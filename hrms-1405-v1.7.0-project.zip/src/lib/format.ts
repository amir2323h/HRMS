// ============================================================
// قالب‌بندی اعداد و مبالغ — کاملاً فارسی
// واحد داخلی سیستم: ریال (integer)
// ============================================================
import { toFaDigits } from "./jalali";

const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

/** تبدیل ارقام لاتین به فارسی */
export function fa(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return "—";
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[+d]);
}

/** تبدیل ارقام فارسی/عربی به لاتین (برای پارس ورودی کاربر) */
export function toEnDigits(input: string | number | null | undefined): string {
  if (input === null || input === undefined) return "";
  return String(input)
    .replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)));
}

/** حذف صفرهای انتهایی اعشار: «7.0» → «7»، «7.50» → «7.5» */
function stripTrailingZeros(s: string): string {
  if (!s.includes(".")) return s;
  return s.replace(/0+$/, "").replace(/\.$/, "");
}

/** عدد اعشاری با یک رقم اعشار بدون «.0» اضافه: 7.0 → «7»، 7.5 → «7.5» */
function fixed1(n: number): string {
  return stripTrailingZeros(n.toFixed(1));
}

/** جداکننده هزارگان + ارقام فارسی — بدون «.0» برای اعداد صحیح و اعشار بی‌صفر */
export function groupFa(n: number | string): string {
  let s: string;
  if (typeof n === "number") {
    s = Number.isInteger(n) ? String(n) : String(Math.round(n * 100) / 100);
  } else {
    s = String(n);
  }
  const [intPart, decRaw] = s.split(".");
  const decPart = decRaw ? stripTrailingZeros(decRaw) : "";
  const negative = intPart.startsWith("-");
  const digits = negative ? intPart.slice(1) : intPart;
  const grouped = digits.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  const out = (negative ? "−" : "") + grouped + (decPart ? "." + decPart : "");
  return fa(out);
}

/** قالب‌بندی ریال: ۱۶۶,۲۵۵,۵۰۰ ریال */
export function fmtRial(amount: number | bigint | null | undefined): string {
  if (amount === null || amount === undefined) return "—";
  const n = typeof amount === "bigint" ? Number(amount) : amount;
  if (!isFinite(n)) return "—";
  return `${groupFa(Math.round(n))} ریال`;
}

/** قالب‌بندی تومان (ریال ÷ ۱۰): ۱۶,۶۲۵,۵۵۰ تومان */
export function fmtToman(amount: number | bigint | null | undefined): string {
  if (amount === null || amount === undefined) return "—";
  const n = typeof amount === "bigint" ? Number(amount) : amount;
  if (!isFinite(n)) return "—";
  return `${groupFa(Math.round(n / 10))} تومان`;
}

/** قالب‌بندی با واحد دلخواه */
export function fmtMoney(amount: number | bigint | null | undefined, unit: "RIAL" | "TOMAN" = "TOMAN"): string {
  return unit === "RIAL" ? fmtRial(amount) : fmtToman(amount);
}

/** خلاصه مبالغ بزرگ: ۱.۲ میلیارد تومان — بدون «.0» — ورودی به ریال */
export function fmtMoneyShort(amount: number | bigint | null | undefined, unit: "RIAL" | "TOMAN" = "RIAL"): string {
  if (amount === null || amount === undefined) return "—";
  let n = typeof amount === "bigint" ? Number(amount) : amount;
  if (!isFinite(n)) return "—";
  if (unit === "RIAL") n = n / 10; // تبدیل ریال به تومان
  const abs = Math.abs(n);
  if (abs >= 1_000_000_000) return fa(fixed1(n / 1_000_000_000)) + " میلیارد تومان";
  if (abs >= 1_000_000) return fa(fixed1(n / 1_000_000)) + " میلیون تومان";
  if (abs >= 1_000) return fa((n / 1_000).toFixed(0)) + " هزار تومان";
  return groupFa(n) + " تومان";
}

/** درصد فارسی: ۷٪ — بدون «.0» */
export function fmtPercent(rate: number, digits = 0): string {
  return fa(stripTrailingZeros((rate * 100).toFixed(digits))) + "٪";
}

/** تبدیل ورودی کاربر (ممکن است فارسی/با جداکننده/تومان) به عدد ریال */
export function parseMoneyInput(input: string, unit: "RIAL" | "TOMAN" = "TOMAN"): number {
  if (!input) return 0;
  const en = String(input)
    .replace(/[۰-۹]/g, (d) => String(FA_DIGITS.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/[,٬،\s]/g, "");
  const n = parseFloat(en);
  if (isNaN(n)) return 0;
  return unit === "RIAL" ? Math.round(n) : Math.round(n * 10);
}

/** اعتبارسنجی شماره شبا */
export function isValidIban(iban: string): boolean {
  if (!iban) return false;
  const s = iban.replace(/\s/g, "").toUpperCase();
  if (!/^IR\d{24}$/.test(s)) return false;
  // بررسی checksum IBAN (مبانی ۱۳۶ و ۲۶)
  const rearranged = s.slice(4) + s.slice(0, 4);
  let rem = 0;
  for (const ch of rearranged) {
    const v = ch >= "0" && ch <= "9" ? +ch : ch.charCodeAt(0) - 55; // A=10...
    rem = (rem * 10 + v) % 97;
  }
  return rem === 1;
}

/** اعتبارسنجی کد ملی ایران */
export function isValidNationalId(code: string): boolean {
  if (!/^\d{10}$/.test(code)) return false;
  const check = +code[9];
  const d = code.slice(0, 9).split("").map(Number);
  const s = d.reduce((acc, x, i) => acc + x * (10 - i), 0);
  const r = s % 11;
  return r < 2 ? check === r : check === 11 - r;
}

/** نام بانک از روی شبا (پیش‌شماره) */
const BANK_PREFIXES: Record<string, string> = {
  "017": "بانک ملی", "018": "بانک صادرات", "019": "بانک ملّی سابق", "015": "بانک سپه",
  "013": "بانک رفاه", "054": "بانک پارسیان", "055": "بانک پاسارگاد", "056": "بانک سامان",
  "057": "بانک پست", "058": "بانک توسعه صادرات", "052": "بانک قوامین", "051": "بانک توسعه تعاون",
  "062": "بانک توسعه کشاورزی", "060": "بانک کشاورزی", "020": "بانک تجارت", "021": "بانک صنعت و معدن",
  "022": "بانک مسکن", "053": "بانک کارآفرین", "059": "بانک سرمایه", "061": "بانک انصار؟",
  "014": "بانک پرداخت نوین؟", "016": "بانک قرض‌الحسنه؟", "065": "بانک انصار", "063": "بانک شهر",
  "064": "بانک آینده؟", "070": "بانک رسالت؟", "011": "بانک بازار؟",
};

export function bankNameFromIban(iban: string): string {
  if (!iban) return "";
  const s = iban.replace(/\s/g, "");
  const prefix = s.slice(4, 7);
  return BANK_PREFIXES[prefix] || "";
}

export const CONTRACT_TYPE_LABELS: Record<string, string> = {
  PERMANENT: "دائم",
  FIXED: "مدت‌دار (محدود)",
  TEMPORARY: "موقت",
  PROBATION: "آزمایشی",
  INTERN: "کارآموز",
};

export const MARITAL_LABELS: Record<string, string> = {
  SINGLE: "مجرد",
  MARRIED: "متأهل",
};

export const EMPLOYEE_STATUS_LABELS: Record<string, string> = {
  ACTIVE: "فعال",
  INACTIVE: "غیرفعال",
  TERMINATED: "قطع همکاری",
};

export const DOC_TYPE_LABELS: Record<string, string> = {
  NATIONAL_ID: "کارت ملی",
  CONTRACT: "قرارداد",
  PROMISSORY: "سفته",
  CHECK: "چک ضمانت",
  DIPLOMA: "مدرک تحصیلی",
  OTHER: "سایر",
};

export const LEAVE_TYPE_LABELS: Record<string, string> = {
  ANNUAL: "استحقاقی",
  SICK: "استعلاجی",
  UNPAID: "بدون حقوق",
  HOURLY: "ساعتی",
};

export const REQUEST_STATUS_LABELS: Record<string, string> = {
  PENDING: "در انتظار بررسی",
  PENDING_DM: "در انتظار تأیید مدیر واحد",
  PENDING_HR: "در انتظار تأیید منابع انسانی",
  APPROVED: "تأیید شده",
  REJECTED: "رد شده",
};

export const PERIOD_STATUS_LABELS: Record<string, string> = {
  CALCULATED: "محاسبه شده",
  APPROVED: "تأیید شده",
  PAID: "پرداخت شده",
};

export const ROLE_LABELS: Record<string, string> = {
  SUPER_ADMIN: "مدیر کل سیستم",
  HR_MANAGER: "مدیر منابع انسانی",
  PAYROLL_OFFICER: "کارشناس حقوق و دستمزد",
  DEPT_MANAGER: "مدیر دپارتمان",
  EMPLOYEE: "کارمند",
};

// ============================ پاداش (سود سالانه) ============================
export const BONUS_TIER_LABELS: Record<string, string> = {
  BELOW_80: "نرسیده به تارگت",
  AT_80: "تا ۸۰٪ تارگت",
  AT_100: "تحقق ۱۰۰٪ تارگت",
  OVER_120: "اور تارگت (≥۱۲۰٪)",
};

export const BONUS_SCHEME_STATUS_LABELS: Record<string, string> = {
  DRAFT: "پیش‌نویس",
  CONFIRMED: "تأییدشده",
  PAID: "پرداخت‌شده",
};

// ============================ رفاهیات ============================
export const WELFARE_CATEGORY_HINT = "مثلاً: زودکس پی (خرید سهام)، غذای سازمانی، بیمه تکمیلی، سرویس رفت‌وآمد، باشگاه، وام مسکن، دوره‌های آموزشی";

// ============================ درخواست‌نامه‌ها ============================
export const LETTER_STATUS_LABELS: Record<string, string> = {
  PENDING: "در انتظار تأیید",
  APPROVED: "تأیید شده",
  REJECTED: "رد شده",
};

export const LETTER_CATEGORY_LABELS: Record<string, string> = {
  GENERAL: "عمومی",
  HR: "منابع انسانی",
  FINANCE: "مالی و اداری",
  ADMIN: "اداری",
};

// ============================ نسبت‌های افراد تحت پوشش بیمه تکمیلی ============================
export const DEPENDENT_RELATION_LABELS: Record<string, string> = {
  SPOUSE: "همسر",
  SON: "پسر",
  DAUGHTER: "دختر",
  FATHER: "پدر",
  MOTHER: "مادر",
  FATHER_IN_LAW: "پدرزن/پدرشوهر",
  MOTHER_IN_LAW: "مادرزن/مادرشوهر",
  OTHER: "سایر",
};

// ============================ بیمه تکمیلی ============================
export const SUPP_INSURANCE_LABELS: Record<string, string> = {
  NONE: "فاقد بیمه تکمیلی",
  INDIVIDUAL: "فردی",
  FAMILY: "خانوادگی",
};

// ============================ قراردادها (ماژول صدور) ============================
export const CONTRACT_DOC_TYPE_LABELS: Record<string, string> = {
  EMPLOYMENT: "قرارداد استخدام",
  FIXED: "قرارداد مدت‌دار",
  PROBATION: "قرارداد آزمایشی",
  TEMPORARY: "قرارداد موقت",
  INTERN: "قرارداد کارآموزی",
  NDA: "قرارداد محرمانگی",
  OTHER: "سایر قراردادها",
};

export const CONTRACT_STATUS_LABELS: Record<string, string> = {
  DRAFT: "پیش‌نویس",
  ISSUED: "صادرشده",
  SIGNED: "امضاشده",
  ACTIVE: "اجرایی",
  EXPIRED: "منقضی‌شده",
  TERMINATED: "فسخ‌شده",
  VOIDED: "ابطال‌شده",
};

// ============================ عدد به حروف فارسی ============================
const ONES = ["", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه"];
const TEENS = ["ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده"];
const TENS = ["", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود"];
const HUNDREDS = ["", "صد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد"];
const SCALES = ["", " هزار", " میلیون", " میلیارد", " تریلیون"];

/** سه‌رقمی به حروف: ۱۲۳ → «صد و بیست و سه» */
function tripleToWords(n: number): string {
  const parts: string[] = [];
  const h = Math.floor(n / 100);
  const rest = n % 100;
  if (h > 0) parts.push(HUNDREDS[h]);
  if (rest >= 10 && rest < 20) {
    parts.push(TEENS[rest - 10]);
  } else {
    const t = Math.floor(rest / 10);
    const o = rest % 10;
    if (t > 0) parts.push(TENS[t]);
    if (o > 0) parts.push(ONES[o]);
  }
  return parts.join(" و ");
}

/** عدد صحیح به حروف فارسی: 1234567 → «یک میلیون و دویست و سی و چهار هزار و پانصد و شصت و هفت» */
export function numToFaWords(n: number): string {
  if (!isFinite(n)) return "";
  n = Math.round(Math.abs(n));
  if (n === 0) return "صفر";
  const triples: number[] = [];
  while (n > 0) {
    triples.push(n % 1000);
    n = Math.floor(n / 1000);
  }
  const chunks: string[] = [];
  for (let i = triples.length - 1; i >= 0; i--) {
    if (triples[i] === 0) continue;
    chunks.push(tripleToWords(triples[i]) + SCALES[i]);
  }
  return chunks.join(" و ");
}

/** مبلغ ریالی با حروف: numToFaWords(rial) + « ریال» */
export function rialToFaWords(rial: number): string {
  const w = numToFaWords(rial);
  return w ? `${w} ریال` : "";
}

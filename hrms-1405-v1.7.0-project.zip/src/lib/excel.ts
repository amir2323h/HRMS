"use client";

// ============================================================
// کتابخانه اکسل سمت کلاینت — خواندن و نوشتن فایل Excel (xlsx)
// کاملاً لوکال (بسته xlsx از node_modules) — بدون هیچ CDN
// ============================================================
import * as XLSX from "xlsx";
import { toEnDigits } from "@/lib/format";

/** خواندن اولین شیت فایل اکسل → آرایه‌ای از ردیف‌ها (کلید = سرستون) */
export async function readExcelRows(file: File): Promise<Record<string, unknown>[]> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array", codepage: 65001 });
  const sheetName = wb.SheetNames[0];
  if (!sheetName) return [];
  const ws = wb.Sheets[sheetName];
  return XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, { defval: "", raw: true });
}

/** ساخت و دانلود فایل اکسل از ردیف‌ها */
export function downloadExcel(filename: string, sheetName: string, rows: Record<string, unknown>[]): void {
  const ws = XLSX.utils.json_to_sheet(rows);
  // عرض ستون‌های مناسب برای فارسی
  ws["!cols"] = Object.keys(rows[0] || {}).map(() => ({ wch: 22 }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName);
  XLSX.writeFile(wb, filename);
}

/** دانلود فایل قالب خالی نمونه برای ایمپورت */
export function downloadTemplate(filename: string, sheetName: string, headers: string[], sampleRows: Record<string, unknown>[]): void {
  downloadExcel(filename, sheetName, [...sampleRows]);
  void headers;
}

/** نرمال‌سازی کلید ردیف: حذف فاصله‌های اضافی و کاراکترهای صفر-عرض */
export function normalizeKey(k: string): string {
  return String(k).replace(/[\u200c\u200f\u200e]/g, "").replace(/\s+/g, " ").trim();
}

/** استخراج مقدار ردیف با کلید فارسی/انگلیسی (تحمل جایگذاری ستون) */
export function pick(row: Record<string, unknown>, keys: string[]): unknown {
  for (const key of Object.keys(row)) {
    const nk = normalizeKey(key);
    if (keys.some((k) => normalizeKey(k) === nk)) {
      return row[key];
    }
  }
  return undefined;
}

/** تبدیل مقدار سلول به رشته پاک — ارقام فارسی → لاتین */
export function cellStr(v: unknown): string {
  if (v === null || v === undefined) return "";
  return toEnDigits(String(v).trim());
}

/** تبدیل مقدار سلول به بولین (بله/خیر/true/false/1/0) */
export function cellBool(v: unknown, fallback = true): boolean {
  const s = cellStr(v).toLowerCase();
  if (["بله", "true", "1", "yes", "فعال", "*"].includes(s)) return true;
  if (["خیر", "false", "0", "no", "غیرفعال", "-"].includes(s)) return false;
  return fallback;
}

/** تبدیل مقدار سلول به عدد صحیح (تحمل ارقام فارسی و جداکننده) */
export function cellInt(v: unknown): number {
  const s = cellStr(v).replace(/[,٬،\s]/g, "");
  const n = parseInt(s, 10);
  return isNaN(n) ? 0 : n;
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { serializeEmployee, serializePayslip } from "@/lib/serializers";
import { diffJalaliDays, todayJalaliStr } from "@/lib/jalali";

/** پرتال خودخدماتی کارمند — داده‌های کاربر لاگین‌کرده + نامه‌ها + رفاهیات */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    if (!session.employeeId) {
      return { employee: null, payslips: [], requests: { leaves: [], advances: [] }, letters: [], welfare: [], contract: null };
    }
    const employee = await db.employee.findUnique({
      where: { id: session.employeeId },
      include: {
        jobGrade: true,
        departments: { include: { department: true } },
        payslips: { include: { period: true }, orderBy: [{ period: { year: "desc" } }, { period: { month: "desc" } }] },
        leaveRequests: { orderBy: { createdAt: "desc" } },
        advanceRequests: { orderBy: { createdAt: "desc" } },
        welfare: { include: { welfareItem: true } },
        letterRequests: { orderBy: { createdAt: "desc" } },
      },
    });
    if (!employee) return { employee: null, payslips: [], requests: { leaves: [], advances: [] }, letters: [], welfare: [], contract: null };

    const today = todayJalaliStr();
    const contract: Record<string, unknown> = {
      type: employee.contractType,
      startJ: employee.contractStartJ,
      endJ: employee.contractEndJ,
      probationEndJ: employee.probationEndDateJ,
      daysToEnd: employee.contractEndJ ? diffJalaliDays(today, employee.contractEndJ) : null,
      daysToProbationEnd: employee.probationEndDateJ ? diffJalaliDays(today, employee.probationEndDateJ) : null,
      yearsOfService: Math.max(0, Math.floor(diffJalaliDays(employee.hireDateJ, today) / 365.25)),
    };

    return {
      employee: serializeEmployee(employee as never),
      payslips: (employee.payslips || []).map((p) => serializePayslip(p as never)),
      requests: {
        leaves: employee.leaveRequests,
        advances: employee.advanceRequests.map((a) => ({ ...a, amount: Number(a.amount) })),
      },
      letters: employee.letterRequests.map((l) => ({
        id: l.id,
        number: l.number,
        templateTitle: l.templateTitle,
        title: l.title,
        body: l.body,
        status: l.status,
        decidedBy: l.decidedBy,
        decidedAt: l.decidedAt,
        decisionNote: l.decisionNote,
        signatureCode: l.signatureCode,
        createdAt: l.createdAt,
      })),
      welfare: (employee.welfare || []).map((w) => ({
        id: w.welfareItem.id,
        title: w.welfareItem.title,
        code: w.welfareItem.code,
      })),
      contract,
      today,
    };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAnyPerm, hashPassword } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { hasPerm } from "@/lib/permissions";

// ============================================================
// مدیریت کاربران سامانه — RBAC داینامیک (roleId + مجوزها از جدول roles)
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAnyPerm(req, ["users:view", "users:manage"]);
    const [users, roles] = await Promise.all([
      db.user.findMany({
        include: { employee: { select: { id: true, firstName: true, lastName: true, personnelCode: true } } },
        orderBy: { username: "asc" },
      }),
      db.role.findMany({ orderBy: { createdAt: "asc" } }),
    ]);
    const roleMap = new Map(roles.map((r) => [r.id, r]));
    return {
      users: users.map((u) => ({
        id: u.id,
        username: u.username,
        fullName: u.fullName,
        role: u.role,
        roleId: u.roleId || null,
        roleLabel: (u.roleId ? roleMap.get(u.roleId)?.name : undefined) || u.role,
        permissions: u.roleId ? JSON.parse(roleMap.get(u.roleId)?.permissions || "[]") : [],
        oauthProvider: u.oauthProvider || "",
        oauthEmail: u.oauthEmail || "",
        employeeId: u.employeeId || null,
        employeeName: u.employee ? `${u.employee.firstName} ${u.employee.lastName}` : "",
        personnelCode: u.employee?.personnelCode || "",
        isActive: u.isActive,
        lastLoginAt: u.lastLoginAt?.toISOString() || null,
        createdAt: u.createdAt.toISOString(),
      })),
      roles: roles.map((r) => ({ id: r.id, key: r.key, name: r.name, isSystem: r.isSystem })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "users:manage");
    const b = await req.json();

    const username = String(b.username || "").trim().toLowerCase();
    const fullName = String(b.fullName || "").trim();
    const password = String(b.password || "");

    const errors: string[] = [];
    if (!username || !/^[a-z0-9._-]{3,30}$/.test(username)) errors.push("نام کاربری باید ۳ تا ۳۰ کاراکتر لاتین (حروف/رقم/نقطه/خط تیره) باشد.");
    if (!fullName) errors.push("نام و نام خانوادگی الزامی است.");
    if (password.length < 6) errors.push("رمز عبور باید حداقل ۶ کاراکتر باشد.");
    if (errors.length) return Response.json({ error: errors.join(" ") }, { status: 400 });

    // نقش: roleId (ترجیحی) یا role key
    let roleId: string | null = null;
    let roleKey = "";
    if (b.roleId) {
      const role = await db.role.findUnique({ where: { id: b.roleId } });
      if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 400 });
      roleId = role.id;
      roleKey = role.key;
    } else if (b.role) {
      const role = await db.role.findUnique({ where: { key: String(b.role) } });
      if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 400 });
      roleId = role.id;
      roleKey = role.key;
    } else {
      return Response.json({ error: "انتخاب نقش الزامی است." }, { status: 400 });
    }

    const dup = await db.user.findUnique({ where: { username } });
    if (dup) return Response.json({ error: `نام کاربری «${username}» قبلاً ثبت شده است.` }, { status: 400 });

    // اتصال اختیاری به پرونده کارمند
    let employeeId: string | null = null;
    if (b.employeeId) {
      const emp = await db.employee.findUnique({ where: { id: b.employeeId } });
      if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 400 });
      const linked = await db.user.findFirst({ where: { employeeId: b.employeeId } });
      if (linked) return Response.json({ error: `این پرونده قبلاً به کاربر «${linked.username}» متصل است.` }, { status: 400 });
      employeeId = emp.id;
    }

    const user = await db.user.create({
      data: {
        username,
        fullName,
        role: roleKey,
        roleId,
        passwordHash: hashPassword(password),
        employeeId,
        isActive: b.isActive === false ? false : true,
      },
    });
    await audit(session, "CREATE", "USER", user.id, `ایجاد کاربر «${username}» با نقش ${roleKey}`, null, { username, fullName, role: roleKey });
    return { user: { id: user.id, username: user.username, fullName: user.fullName, role: user.role, roleId: user.roleId } };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, hashPassword } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// ویرایش/حذف کاربر — users:manage + حفاظت آخرین مدیر کل
// ============================================================

/** شمارش مدیران کل فعال (برای حفاظت آخرین مدیر) */
async function activeSuperCount(excludeId?: string): Promise<number> {
  return db.user.count({ where: { role: "SUPER_ADMIN", isActive: true, ...(excludeId ? { id: { not: excludeId } } : {}) } });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "users:manage");
    const { id } = await ctx.params;
    const before = await db.user.findUnique({ where: { id } });
    if (!before) return Response.json({ error: "کاربر یافت نشد." }, { status: 404 });

    const b = await req.json();
    const data: Record<string, unknown> = {};

    if (b.fullName !== undefined) {
      const fullName = String(b.fullName).trim();
      if (!fullName) return Response.json({ error: "نام و نام خانوادگی الزامی است." }, { status: 400 });
      data.fullName = fullName;
    }
    // نقش: roleId جدید (RBAC داینامیک)
    if (b.roleId !== undefined) {
      if (b.roleId) {
        const role = await db.role.findUnique({ where: { id: b.roleId } });
        if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 400 });
        // حفاظت آخرین مدیر کل
        if (before.role === "SUPER_ADMIN" && role.key !== "SUPER_ADMIN" && (await activeSuperCount(id)) === 0) {
          return Response.json({ error: "آخرین مدیر کل فعال سامانه را نمی‌توان تغییر نقش داد." }, { status: 400 });
        }
        data.roleId = role.id;
        data.role = role.key;
      } else {
        return Response.json({ error: "کاربر باید نقش داشته باشد." }, { status: 400 });
      }
    } else if (b.role !== undefined) {
      // سازگاری: ارسال کلید نقش
      const role = await db.role.findUnique({ where: { key: String(b.role) } });
      if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 400 });
      if (before.role === "SUPER_ADMIN" && role.key !== "SUPER_ADMIN" && (await activeSuperCount(id)) === 0) {
        return Response.json({ error: "آخرین مدیر کل فعال سامانه را نمی‌توان تغییر نقش داد." }, { status: 400 });
      }
      data.roleId = role.id;
      data.role = role.key;
    }
    if (b.isActive !== undefined) {
      // غیرفعال‌سازی آخرین مدیر کل ممنوع
      if (!b.isActive && before.role === "SUPER_ADMIN" && before.isActive && (await activeSuperCount(id)) === 0) {
        return Response.json({ error: "آخرین مدیر کل فعال سامانه را نمی‌توان غیرفعال کرد." }, { status: 400 });
      }
      // کاربر خودش را غیرفعال نکند
      if (!b.isActive && before.id === session.uid) {
        return Response.json({ error: "نمی‌توانید حساب کاربری خودتان را غیرفعال کنید." }, { status: 400 });
      }
      data.isActive = !!b.isActive;
    }
    if (b.password !== undefined && b.password !== "") {
      const password = String(b.password);
      if (password.length < 6) return Response.json({ error: "رمز عبور باید حداقل ۶ کاراکتر باشد." }, { status: 400 });
      data.passwordHash = hashPassword(password);
    }
    if (b.employeeId !== undefined) {
      if (b.employeeId) {
        const emp = await db.employee.findUnique({ where: { id: b.employeeId } });
        if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 400 });
        const linked = await db.user.findFirst({ where: { employeeId: b.employeeId, id: { not: id } } });
        if (linked) return Response.json({ error: `این پرونده قبلاً به کاربر «${linked.username}» متصل است.` }, { status: 400 });
        data.employeeId = b.employeeId;
      } else {
        data.employeeId = null;
      }
    }

    await db.user.update({ where: { id }, data });
    const after = await db.user.findUnique({ where: { id } });
    await audit(
      session,
      "UPDATE",
      "USER",
      id,
      `ویرایش کاربر «${before.username}»${data.passwordHash ? " (بازنشانی رمز)" : ""}`,
      { role: before.role, isActive: before.isActive, fullName: before.fullName, roleId: before.roleId },
      { role: after?.role, isActive: after?.isActive, fullName: after?.fullName, roleId: after?.roleId }
    );
    return { ok: true };
  });
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "users:manage");
    const { id } = await ctx.params;
    const user = await db.user.findUnique({ where: { id } });
    if (!user) return Response.json({ error: "کاربر یافت نشد." }, { status: 404 });

    if (user.id === session.uid) {
      return Response.json({ error: "نمی‌توانید حساب کاربری خودتان را حذف کنید." }, { status: 400 });
    }
    if (user.role === "SUPER_ADMIN" && user.isActive && (await activeSuperCount(id)) === 0) {
      return Response.json({ error: "آخرین مدیر کل فعال سامانه را نمی‌توان حذف کرد." }, { status: 400 });
    }

    await db.user.delete({ where: { id } });
    await audit(session, "DELETE", "USER", id, `حذف کاربر «${user.username}» (${user.role})`);
    return { ok: true };
  });
}

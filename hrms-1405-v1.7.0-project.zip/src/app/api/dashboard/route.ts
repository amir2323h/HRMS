import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { periodTitle } from "@/lib/jalali";

/** داده‌های داشبورد: KPIها + روند ماهانه + هزینه دپارتمان‌ها + توزیع طبقات */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "dashboard:view");

    const periods = await db.payrollPeriod.findMany({
      orderBy: [{ year: "asc" }, { month: "asc" }],
      include: { payslips: true },
    });
    const activeCount = await db.employee.count({ where: { status: "ACTIVE" } });
    const gradeCounts = await db.employee.groupBy({
      by: ["jobGradeId"],
      where: { status: "ACTIVE" },
      _count: { id: true },
    });
    const grades = await db.jobGrade.findMany({ orderBy: { level: "asc" } });
    const gradeMap: Record<string, { level: number; title: string }> = {};
    for (const g of grades) gradeMap[g.id] = { level: g.level, title: g.title };

    // روند ماهانه (فروردین تا مهر)
    const trend = periods.map((p) => ({
      label: periodTitle(p.year, p.month),
      year: p.year,
      month: p.month,
      gross: p.payslips.reduce((a, s) => a + Number(s.gross), 0),
      netPay: p.payslips.reduce((a, s) => a + Number(s.netPay), 0),
      employeeSso: p.payslips.reduce((a, s) => a + Number(s.employeeSso), 0),
      employerSso: p.payslips.reduce((a, s) => a + Number(s.employerSso20) + Number(s.unemploymentSso3), 0),
      incomeTax: p.payslips.reduce((a, s) => a + Number(s.incomeTax), 0),
      totalCost: p.payslips.reduce((a, s) => a + Number(s.gross) + Number(s.employerSso20) + Number(s.unemploymentSso3), 0),
      count: p.payslips.length,
    }));

    // آخرین دوره
    const latest = periods.length ? periods[periods.length - 1] : null;
    const latestTotals = latest
      ? {
          gross: latest.payslips.reduce((a, s) => a + Number(s.gross), 0),
          netPay: latest.payslips.reduce((a, s) => a + Number(s.netPay), 0),
          employeeSso: latest.payslips.reduce((a, s) => a + Number(s.employeeSso), 0),
          employerSso: latest.payslips.reduce((a, s) => a + Number(s.employerSso20) + Number(s.unemploymentSso3), 0),
          incomeTax: latest.payslips.reduce((a, s) => a + Number(s.incomeTax), 0),
          totalCost: latest.payslips.reduce((a, s) => a + Number(s.gross) + Number(s.employerSso20) + Number(s.unemploymentSso3), 0),
          label: periodTitle(latest.year, latest.month),
          periodId: latest.id,
          count: latest.payslips.length,
        }
      : null;

    // هزینه به تفکیک دپارتمان (آخرین دوره)
    let deptCosts: { name: string; totalCost: number; headcount: number }[] = [];
    if (latest) {
      const links = await db.employeeDepartment.findMany({ include: { department: true } });
      const empDept: Record<string, string> = {};
      for (const l of links) empDept[l.employeeId] = l.departmentId;
      const agg: Record<string, { name: string; totalCost: number; headcount: number }> = {};
      for (const l of links) {
        if (!agg[l.departmentId]) agg[l.departmentId] = { name: l.department.name, totalCost: 0, headcount: 0 };
      }
      const slips = await db.payslip.findMany({ where: { periodId: latest.id } });
      for (const s of slips) {
        const d = empDept[s.employeeId];
        if (d && agg[d]) {
          agg[d].totalCost += Number(s.gross) + Number(s.employerSso20) + Number(s.unemploymentSso3);
          agg[d].headcount += 1;
        }
      }
      deptCosts = Object.values(agg)
        .filter((x) => x.headcount > 0)
        .sort((a, b) => b.totalCost - a.totalCost);
    }

    // توزیع طبقات
    const gradeDistribution = grades.map((g) => ({
      level: g.level,
      title: g.title,
      count: gradeCounts.find((c) => c.jobGradeId === g.id)?._count.id || 0,
    }));

    return {
      kpis: {
        activeEmployees: activeCount,
        latest: latestTotals,
        periodCount: periods.length,
      },
      trend,
      deptCosts,
      gradeDistribution,
    };
  });
}

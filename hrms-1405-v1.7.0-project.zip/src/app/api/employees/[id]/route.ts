import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeEmployee, serializePayslip, serializeDocument } from "@/lib/serializers";
import { isValidNationalId } from "@/lib/format";
import { isValidJalali } from "@/lib/jalali";
import { validateDependents, coveredCountFrom } from "@/lib/dependents";

const EMPLOYEE_INCLUDE = {
  jobGrade: true,
  jobTitleRef: true,
  departments: { include: { department: true } },
  insuranceDependents: { orderBy: { createdAt: "asc" } },
  welfare: { include: { welfareItem: true } },
} as const;

const CONTRACT_TYPES = ["PERMANENT", "FIXED", "TEMPORARY", "PROBATION", "INTERN"];

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(_req, "employees:view");
    const { id } = await ctx.params;
    const employee = await db.employee.findUnique({
      where: { id },
      include: {
        ...EMPLOYEE_INCLUDE,
        documents: { orderBy: { createdAt: "desc" } },
        payslips: { include: { period: true }, orderBy: [{ period: { year: "desc" } }, { period: { month: "desc" } }] },
        leaveRequests: { orderBy: { createdAt: "desc" } },
        advanceRequests: { orderBy: { createdAt: "desc" } },
        letterRequests: { orderBy: { createdAt: "desc" } },
      },
    });
    if (!employee) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });
    return {
      employee: serializeEmployee(employee as never),
      documents: (employee.documents || []).map((d) => serializeDocument(d as never)),
      payslips: (employee.payslips || []).map((p) => serializePayslip(p as never)),
      leaveRequests: employee.leaveRequests,
      advanceRequests: employee.advanceRequests.map((a) => ({ ...a, amount: Number(a.amount) })),
      letters: (employee.letterRequests || []).map((l) => ({
        id: l.id, number: l.number, templateTitle: l.templateTitle, title: l.title, status: l.status,
        decidedBy: l.decidedBy, decisionNote: l.decisionNote, createdAt: l.createdAt,
      })),
    };
  });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "employees:edit");
    const { id } = await ctx.params;
    const before = await db.employee.findUnique({ where: { id }, include: EMPLOYEE_INCLUDE });
    if (!before) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });

    const b = await req.json();
    const errors: string[] = [];
    // کد ملی الزامی در ویرایش نیز — اگر ارسال شده یا اگر موجود خالی است
    const currentNationalId = String(before.nationalId || "").replace(/\D/g, "");
    const nextNationalId = b.nationalId !== undefined ? String(b.nationalId).replace(/\D/g, "") : currentNationalId;
    if (!nextNationalId) errors.push("کد ملی الزامی است.");
    else if (!/^\d{10}$/.test(nextNationalId)) errors.push("کد ملی باید ۱۰ رقم باشد.");
    else if (!isValidNationalId(nextNationalId)) errors.push("رقم کنترل کد ملی نامعتبر است.");
    if (nextNationalId && nextNationalId !== currentNationalId) {
      const dup = await db.employee.findFirst({ where: { nationalId: nextNationalId, id: { not: id } } });
      if (dup) errors.push("کارمندی با این کد ملی قبلاً ثبت شده است.");
    }
    if (b.iban && !/^IR\d{24}$/i.test(String(b.iban).replace(/\s/g, ""))) errors.push("شماره شبا نامعتبر است.");
    for (const f of ["hireDateJ", "contractStartJ", "contractEndJ", "probationEndDateJ", "birthDateJ"]) {
      if (b[f] && !isValidJalali(b[f])) errors.push("قالب تاریخ جلالی نامعتبر است.");
    }
    // بیمه تکمیلی — افراد تحت پوشش (نسبت + مشخصات)
    const nextSuppInsurance = b.suppInsurance !== undefined
      ? (["NONE", "INDIVIDUAL", "FAMILY"].includes(b.suppInsurance) ? b.suppInsurance : "NONE")
      : before.suppInsurance;
    const dep = b.suppDependents !== undefined ? validateDependents(b.suppDependents, nextSuppInsurance) : null;
    if (dep) errors.push(...dep.errors);
    if (errors.length) return Response.json({ error: errors.join(" ") }, { status: 400 });

    const data: Record<string, unknown> = {};
    const strFields = ["firstName", "lastName", "nationalId", "ssoNumber", "mobile", "email", "address", "jobTitle", "bankName", "notes", "hireDateJ", "probationEndDateJ", "contractStartJ", "contractEndJ", "birthDateJ", "fatherName"];
    for (const f of strFields) if (b[f] !== undefined) data[f] = String(b[f]).trim();
    if (b.maritalStatus !== undefined) data.maritalStatus = b.maritalStatus === "MARRIED" ? "MARRIED" : "SINGLE";
    if (b.childCount !== undefined) data.childCount = Math.max(0, +b.childCount || 0);
    if (b.overtimeHours !== undefined) data.overtimeHours = Math.max(0, +b.overtimeHours || 0);
    if (b.contractType !== undefined && CONTRACT_TYPES.includes(b.contractType)) data.contractType = b.contractType;
    if (b.status !== undefined && ["ACTIVE", "INACTIVE", "TERMINATED"].includes(b.status)) data.status = b.status;
    if (b.jobGradeId !== undefined) data.jobGradeId = b.jobGradeId || null;
    // عنوان شغل: انتخاب از مشاغل تعریف‌شده در تنظیمات
    if (b.jobTitleId !== undefined) {
      if (b.jobTitleId) {
        const job = await db.jobTitle.findUnique({ where: { id: b.jobTitleId } });
        if (!job) return Response.json({ error: "عنوان شغلی انتخاب‌شده در تنظیمات یافت نشد." }, { status: 400 });
        data.jobTitleId = job.id;
        data.jobTitle = job.title; // اسنپ‌شات عنوان از دیتای مشاغل
      } else {
        data.jobTitleId = null;
      }
    }
    // بیمه تکمیلی
    if (b.suppInsurance !== undefined && ["NONE", "INDIVIDUAL", "FAMILY"].includes(b.suppInsurance)) data.suppInsurance = b.suppInsurance;
    if (b.suppCoveredCount !== undefined && !dep) data.suppCoveredCount = Math.max(0, Math.min(20, +b.suppCoveredCount || 0));
    if (b.suppInsurerName !== undefined) data.suppInsurerName = String(b.suppInsurerName).trim();
    if (b.suppPolicyNumber !== undefined) data.suppPolicyNumber = String(b.suppPolicyNumber).trim();
    if (b.baseSalary !== undefined) {
      const base = Number(b.baseSalary);
      if (!base || base <= 0) return Response.json({ error: "حقوق پایه نامعتبر است." }, { status: 400 });
      data.baseSalary = BigInt(Math.round(base));
    }
    if (b.iban !== undefined) data.iban = String(b.iban).replace(/\s/g, "").toUpperCase();

    await db.employee.update({ where: { id }, data });

    // جایگزینی کامل افراد تحت پوشش بیمه تکمیلی + همگام‌سازی تعداد
    if (dep) {
      await db.insuranceDependent.deleteMany({ where: { employeeId: id } });
      if (dep.list.length > 0) {
        await db.insuranceDependent.createMany({
          data: dep.list.map((d) => ({
            employeeId: id,
            firstName: d.firstName,
            lastName: d.lastName,
            nationalId: d.nationalId,
            relationship: d.relationship,
            birthDateJ: d.birthDateJ,
          })),
        });
      }
      await db.employee.update({
        where: { id },
        data: { suppCoveredCount: coveredCountFrom(nextSuppInsurance, dep.list.length) },
      });
    }

    if (b.departmentId !== undefined && b.departmentId) {
      await db.employeeDepartment.deleteMany({ where: { employeeId: id } });
      await db.employeeDepartment.create({ data: { employeeId: id, departmentId: b.departmentId, allocationPercent: 100 } });
    }

    // رفاهیات مورد استفاده — جایگزینی کامل (چک‌باکس‌ها)
    if (b.welfareIds !== undefined && Array.isArray(b.welfareIds)) {
      await db.employeeWelfare.deleteMany({ where: { employeeId: id } });
      const ids = b.welfareIds.map(String).filter(Boolean);
      if (ids.length > 0) {
        const items = await db.welfareItem.findMany({ where: { id: { in: ids } } });
        for (const it of items) {
          await db.employeeWelfare.create({ data: { employeeId: id, welfareItemId: it.id } });
        }
      }
    }

    const after = await db.employee.findUnique({ where: { id }, include: EMPLOYEE_INCLUDE });
    await audit(
      session,
      "UPDATE",
      "EMPLOYEE",
      id,
      `ویرایش پرونده ${before.firstName} ${before.lastName}`,
      { baseSalary: Number(before.baseSalary), jobTitle: before.jobTitle, contractType: before.contractType, status: before.status, suppInsurance: before.suppInsurance, suppCoveredCount: before.suppCoveredCount },
      { baseSalary: Number(after?.baseSalary), jobTitle: after?.jobTitle, contractType: after?.contractType, status: after?.status, suppInsurance: after?.suppInsurance, suppCoveredCount: after?.suppCoveredCount, suppDependents: dep ? dep.list.length : undefined }
    );
    return { employee: serializeEmployee(after as never) };
  });
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "employees:edit");
    const { id } = await ctx.params;
    const emp = await db.employee.findUnique({ where: { id } });
    if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });
    await db.employee.delete({ where: { id } });
    await audit(session, "DELETE", "EMPLOYEE", id, `حذف پرونده ${emp.firstName} ${emp.lastName} (${emp.personnelCode})`);
    return { ok: true };
  });
}

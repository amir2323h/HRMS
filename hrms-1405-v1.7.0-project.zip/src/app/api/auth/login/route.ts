import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { signSession, verifyPassword, SESSION_COOKIE, sessionCookieOptions, buildSessionForUser } from "@/lib/auth";
import { handle, audit, clientIp } from "@/lib/api-helpers";

export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await req.json().catch(() => ({}));
    const username = String(body.username || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!username || !password) {
      return NextResponse.json({ error: "نام کاربری و رمز عبور الزامی است." }, { status: 400 });
    }
    const user = await db.user.findUnique({ where: { username } });
    if (!user || !user.isActive || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: "نام کاربری یا رمز عبور نادرست است." }, { status: 401 });
    }
    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    const sessionData = await buildSessionForUser(user);
    const token = signSession(sessionData);
    const res = NextResponse.json({
      user: {
        username: sessionData.username,
        fullName: sessionData.fullName,
        role: sessionData.role,
        roleName: sessionData.roleName,
        perms: sessionData.perms,
        employeeId: sessionData.employeeId,
      },
      // توکن نشست در بدنه — برای ذخیره سمت کلاینت (حالت iframe که کوکی مسدود می‌شود)
      token,
    });
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(req));
    await audit(
      { ...sessionData, exp: 0 },
      "LOGIN",
      "USER",
      user.id,
      `ورود موفق کاربر ${user.fullName} (${user.username})`,
      undefined,
      undefined
    );
    void clientIp(req);
    return res;
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializePeriod, serializePayslip } from "@/lib/serializers";
import { getLegalParams } from "@/lib/settings";
import { computePaysheet, contextFromEmployee } from "@/lib/payroll/engine";
import { todayJalaliStr, parseJalali } from "@/lib/jalali";

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "payroll:view");
    const periods = await db.payrollPeriod.findMany({
      orderBy: [{ year: "desc" }, { month: "desc" }],
      include: { payslips: true },
    });
    return { periods: periods.map((p) => serializePeriod(p as never)) };
  });
}

/** ایجاد دوره جدید و محاسبه خودکار لیست حقوق */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "payroll:manage");
    const b = await req.json();
    const year = +b.year;
    const month = +b.month;
    if (!year || !month || month < 1 || month > 12) {
      return Response.json({ error: "سال و ماه دوره نامعتبر است." }, { status: 400 });
    }
    const dup = await db.payrollPeriod.findUnique({ where: { year_month: { year, month } } });
    if (dup) return Response.json({ error: "دوره انتخابی قبلاً ایجاد شده است." }, { status: 400 });

    const params = await getLegalParams();
    const atDateJ = `${year}/${String(month).padStart(2, "0")}/${String(month <= 6 ? 31 : 30).padStart(2, "0")}`;

    // کارکنان فعال که تا پایان ماه استخدام شده‌اند
    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      include: { jobGrade: true, departments: { include: { department: true } } },
    });
    const eligible = employees.filter((e) => {
      const h = parseJalali(e.hireDateJ || "");
      if (!h) return true;
      return h.jy < year || (h.jy === year && h.jm <= month);
    });

    const period = await db.payrollPeriod.create({
      data: { year, month, status: "CALCULATED", notes: `محاسبه خودکار — ${atDateJ}` },
    });

    for (const emp of eligible) {
      const ctx = contextFromEmployee(
        {
          baseSalary: emp.baseSalary,
          childCount: emp.childCount,
          maritalStatus: emp.maritalStatus,
          overtimeHours: emp.overtimeHours,
          hireDateJ: emp.hireDateJ,
        },
        emp.jobGrade,
        atDateJ
      );
      const sheet = computePaysheet(Number(emp.baseSalary), ctx, params);
      await db.payslip.create({
        data: {
          periodId: period.id,
          employeeId: emp.id,
          baseSalary: BigInt(sheet.baseSalary),
          seniority: BigInt(sheet.seniority),
          housing: BigInt(sheet.housing),
          grocery: BigInt(sheet.grocery),
          childAllowance: BigInt(sheet.childAllowance),
          attraction: BigInt(sheet.attraction),
          overtimeHours: ctx.overtimeHours,
          overtimeAmount: BigInt(sheet.overtimeAmount),
          otherAllowance: BigInt(sheet.otherAllowance),
          gross: BigInt(sheet.gross),
          insurableBase: BigInt(sheet.insurableBase),
          employeeSso: BigInt(sheet.employeeSso),
          employerSso20: BigInt(sheet.employerSso20),
          unemploymentSso3: BigInt(sheet.unemploymentSso3),
          taxableIncome: BigInt(sheet.taxableIncome),
          incomeTax: BigInt(sheet.incomeTax),
          otherDeduction: BigInt(sheet.otherDeduction),
          netPay: BigInt(sheet.netPay),
          isReverse: false,
        },
      });
    }

    await audit(session, "CALC", "PERIOD", period.id, `محاسبه لیست حقوق دوره ${month}/${year} برای ${eligible.length} کارمند`);
    const full = await db.payrollPeriod.findUnique({ where: { id: period.id }, include: { payslips: true } });
    return { period: serializePeriod(full as never) };
  });
}

export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "payroll:manage");
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "شناسه الزامی است." }, { status: 400 });
    const period = await db.payrollPeriod.findUnique({ where: { id }, include: { payslips: true } });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });
    if (period.status === "PAID") return Response.json({ error: "دوره پرداخت‌شده قابل حذف نیست." }, { status: 400 });
    await db.payrollPeriod.delete({ where: { id } });
    await audit(session, "DELETE", "PERIOD", id, `حذف دوره ${period.month}/${period.year} و ${period.payslips.length} فیش`);
    return { ok: true };
  });
}

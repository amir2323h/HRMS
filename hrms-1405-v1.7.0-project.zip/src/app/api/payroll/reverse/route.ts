import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import { computeReversePaysheet } from "@/lib/payroll/reverse";
import { taxBracketBreakdown } from "@/lib/payroll/engine";
import { todayJalaliStr } from "@/lib/jalali";

/**
 * محاسبه معکوس حقوق:
 * POST { targetNet (ریال), gradeId?, childCount?, housingEnabled?, groceryEnabled?,
 *        seniorityYears?, overtimeHours?, rounding?, save?{ periodId, employeeId } }
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "reverse:use");
    const b = await req.json();
    const targetNet = Math.round(+b.targetNet || 0);
    if (!targetNet || targetNet <= 0) {
      return Response.json({ error: "مبلغ خالص هدف نامعتبر است." }, { status: 400 });
    }

    const params = await getLegalParams(true);
    const grade = b.gradeId ? await db.jobGrade.findUnique({ where: { id: b.gradeId } }) : null;

    const result = computeReversePaysheet({
      targetNet,
      params,
      gradeMin: grade ? Number(grade.minBaseSalary) : undefined,
      gradeMax: grade ? Number(grade.maxBaseSalary) : undefined,
      rounding: b.rounding ? +b.rounding : null,
      context: {
        childCount: Math.max(0, +b.childCount || 0),
        housingEnabled: b.housingEnabled !== false,
        groceryEnabled: b.groceryEnabled !== false,
        seniorityYears: Math.max(0, +b.seniorityYears || 0),
        seniorityBase: grade ? Number(grade.seniorityBase) : 0,
        attraction: grade ? Number(grade.attraction) : 0,
        overtimeHours: 0,
        otherAllowance: Math.max(0, +b.otherAllowance || 0),
        otherDeduction: 0,
      },
    });

    await audit(
      session,
      "REVERSE_CALC",
      "PAYROLL",
      b.gradeId || "",
      `محاسبه معکوس — خالص هدف ${targetNet.toLocaleString("en-US")} ریال → حقوق پایه ${result.baseSalary.toLocaleString("en-US")} ریال`,
      { targetNet },
      { baseSalary: result.baseSalary, achievedNet: result.achievedNet, residual: result.residual }
    );

    // جزئیات پله‌های مالیات برای درآمد مشمول نتیجه
    const brackets = taxBracketBreakdown(result.paysheet.taxableIncome, params.taxBrackets);

    let saved = null;
    if (b.save && b.save.periodId && b.save.employeeId) {
      // ذخیره به‌عنوان فیش معکوس برای کارمند در دوره موردنظر (جایگزین فیش قبلی همان کارمند)
      const existing = await db.payslip.findFirst({
        where: { periodId: b.save.periodId, employeeId: b.save.employeeId },
      });
      const sheet = result.paysheet;
      const data = {
        baseSalary: BigInt(sheet.baseSalary),
        seniority: BigInt(sheet.seniority),
        housing: BigInt(sheet.housing),
        grocery: BigInt(sheet.grocery),
        childAllowance: BigInt(sheet.childAllowance),
        attraction: BigInt(sheet.attraction),
        overtimeHours: 0,
        overtimeAmount: BigInt(sheet.overtimeAmount),
        otherAllowance: BigInt(sheet.otherAllowance),
        gross: BigInt(sheet.gross),
        insurableBase: BigInt(sheet.insurableBase),
        employeeSso: BigInt(sheet.employeeSso),
        employerSso20: BigInt(sheet.employerSso20),
        unemploymentSso3: BigInt(sheet.unemploymentSso3),
        taxableIncome: BigInt(sheet.taxableIncome),
        incomeTax: BigInt(sheet.incomeTax),
        otherDeduction: BigInt(sheet.otherDeduction),
        netPay: BigInt(sheet.netPay),
        isReverse: true,
        targetNet: BigInt(targetNet),
      };
      if (existing) {
        await db.payslip.update({ where: { id: existing.id }, data });
        saved = existing.id;
      } else {
        const slip = await db.payslip.create({
          data: { ...data, periodId: b.save.periodId, employeeId: b.save.employeeId },
        });
        saved = slip.id;
      }
      await audit(
        session,
        "CREATE",
        "PAYSLIP",
        saved,
        `ثبت فیش معکوس — خالص هدف ${targetNet.toLocaleString("en-US")} ریال`,
        undefined,
        { isReverse: true, targetNet }
      );
    }

    return {
      result,
      brackets,
      legal: {
        year: params.year,
        minWage: params.minWage,
        housing: params.housing,
        grocery: params.grocery,
        childPerChild: params.childPerChild,
        employeeSsoRate: params.employeeSsoRate,
        employerSsoRate: params.employerSsoRate,
        unemploymentRate: params.unemploymentRate,
        taxBrackets: params.taxBrackets,
      },
      today: todayJalaliStr(),
      savedPayslipId: saved,
    };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { computeLetterSignatureCode } from "@/lib/letters";
import { hasPerm } from "@/lib/permissions";

/** تأیید/رد نامه — letters:approve
 *  نامه‌های قالبی: نقش تأییدکننده مطابق قالب (approverRole)
 *  نامه‌های دستی: ثبت توسط کارشناس اداری → تأیید/امضای دیجیتال توسط
 *  مرجع مجاز (پیش‌فرض مدیر منابع انسانی؛ مدیر کل همیشه مجاز) */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "letters:approve");
    const { id } = await params;
    const b = await req.json();
    const to = String(b.status || "");
    if (!["APPROVED", "REJECTED"].includes(to)) {
      return Response.json({ error: "وضعیت نامعتبر است (APPROVED/REJECTED)." }, { status: 400 });
    }
    const row = await db.letterRequest.findUnique({ where: { id }, include: { template: true } });
    if (!row) return Response.json({ error: "نامه یافت نشد." }, { status: 404 });
    if (row.status !== "PENDING") return Response.json({ error: "این نامه قبلاً تعیین تکلیف شده است." }, { status: 400 });

    // نقش تأییدکننده — نامه قالبی: مطابق قالب؛ نامه دستی: مدیر منابع انسانی
    const requiredRole = row.source === "MANUAL" ? "HR_MANAGER" : row.template?.approverRole || "HR_MANAGER";
    const isSuper = (session.perms || []).includes("*");
    if (!isSuper && requiredRole && session.role !== requiredRole) {
      return Response.json(
        { error: `این نامه باید توسط نقش «${requiredRole}» تأیید شود — کاربر فعلی نقش «${session.role}» دارد.` },
        { status: 403 }
      );
    }

    // امضای دیجیتال: هنگام تأیید روی محتوای نامه قفل می‌شود (HMAC-SHA256)
    const decidedAt = new Date();
    const signatureCode =
      to === "APPROVED"
        ? computeLetterSignatureCode({
            number: row.number,
            employeeName: row.employeeName,
            personnelCode: row.personnelCode,
            title: row.title,
            body: row.body,
            decidedBy: session.fullName,
            decidedAt,
            recipient: row.recipient,
            items: row.itemsJson,
            signerName: row.signerName,
            signerTitle: row.signerTitle,
            bodyHtml: row.bodyHtml,
          })
        : null;

    const updated = await db.letterRequest.update({
      where: { id },
      data: {
        status: to,
        decidedBy: session.fullName,
        decidedAt,
        decisionNote: String(b.note || ""),
        signatureCode,
      },
    });
    await audit(
      session,
      to === "APPROVED" ? "APPROVE" : "UPDATE",
      "LETTER_REQUEST",
      id,
      `${to === "APPROVED" ? "تأیید" : "رد"} ${row.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه"} «${row.title}» (${row.number})${row.employeeName ? ` — ${row.employeeName}` : ""}` +
        (signatureCode ? ` | امضای دیجیتال: ${signatureCode}` : ""),
      { status: row.status },
      { status: to, note: b.note || "", signatureCode }
    );
    return { letter: updated };
  });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "letters:approve");
    const { id } = await params;
    const row = await db.letterRequest.findUnique({ where: { id } });
    if (!row) return Response.json({ error: "نامه یافت نشد." }, { status: 404 });
    // درخواست‌نامه در انتظار: قابل حذف توسط تأییدکننده
    // نامه دستی صادرشده: قابل حذف فقط توسط دارنده مجوز ثبت نامه دستی (ابطال نامه ثبت‌شده اشتباه)
    if (row.status !== "PENDING" && !(row.source === "MANUAL" && hasPerm(session.perms, "letters:manual"))) {
      return Response.json({ error: "نامه تعیین‌تکلیف‌شده قابل حذف نیست." }, { status: 400 });
    }
    await db.letterRequest.delete({ where: { id } });
    await audit(
      session,
      "DELETE",
      "LETTER_REQUEST",
      id,
      `حذف ${row.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه"} «${row.title}» (${row.number})${row.signatureCode ? " — امضای دیجیتال باطل شد" : ""}`
    );
    return { ok: true };
  });
}

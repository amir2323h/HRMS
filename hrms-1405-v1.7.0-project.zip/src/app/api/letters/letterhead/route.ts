import { NextRequest } from "next/server";
import { requireAuth, requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import {
  getLetterSettings,
  saveLetterSettings,
  validateLetterheadImage,
} from "@/lib/letters";

// ============================================================
// تصویر سربرگ رسمی شرکت (PNG) — سایز A4 و A5
// تصویر به‌صورت data URL در SystemSetting «letters» ذخیره می‌شود و
// هنگام چاپ/دانلود نامه‌ها در پس‌زمینه صفحه قرار می‌گیرد.
//   GET  — هر کاربر واردشده (برای دکمه‌های چاپ نامه)
//   PUT  — settings:manage (آپلود/حذف/تنظیم حاشیه‌ها)
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req);
    const s = await getLetterSettings();
    return {
      a4: s.letterheadA4,
      a5: s.letterheadA5,
      a4TopMm: s.letterheadA4TopMm,
      a4BottomMm: s.letterheadA4BottomMm,
      a5TopMm: s.letterheadA5TopMm,
      a5BottomMm: s.letterheadA5BottomMm,
      // امضاکنندگان + تصویر امضای دست‌نویس — برای چاپ/دانلود نامه کنار نام امضاکننده
      signers: s.signers.map((x) => ({ name: x.name, title: x.title, signature: x.signature || "" })),
    };
  });
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:manage");
    const b = await req.json();
    const before = await getLetterSettings();

    const patch: Parameters<typeof saveLetterSettings>[0] = {};

    if (b.a4 !== undefined) {
      const v = String(b.a4 || "");
      if (v) {
        const err = validateLetterheadImage(v, "سربرگ A4");
        if (err) return Response.json({ error: err }, { status: 400 });
      }
      patch.letterheadA4 = v;
    }
    if (b.a5 !== undefined) {
      const v = String(b.a5 || "");
      if (v) {
        const err = validateLetterheadImage(v, "سربرگ A5");
        if (err) return Response.json({ error: err }, { status: 400 });
      }
      patch.letterheadA5 = v;
    }
    if (b.a4TopMm !== undefined) patch.letterheadA4TopMm = Math.round(+b.a4TopMm);
    if (b.a4BottomMm !== undefined) patch.letterheadA4BottomMm = Math.round(+b.a4BottomMm);
    if (b.a5TopMm !== undefined) patch.letterheadA5TopMm = Math.round(+b.a5TopMm);
    if (b.a5BottomMm !== undefined) patch.letterheadA5BottomMm = Math.round(+b.a5BottomMm);

    const saved = await saveLetterSettings(patch);
    await audit(
      session,
      "UPDATE",
      "SETTINGS",
      "letterhead",
      "به‌روزرسانی تصویر سربرگ رسمی نامه‌ها (A4/A5)",
      {
        hasA4: !!before.letterheadA4,
        hasA5: !!before.letterheadA5,
        a4TopMm: before.letterheadA4TopMm,
        a4BottomMm: before.letterheadA4BottomMm,
        a5TopMm: before.letterheadA5TopMm,
        a5BottomMm: before.letterheadA5BottomMm,
      },
      {
        hasA4: !!saved.letterheadA4,
        hasA5: !!saved.letterheadA5,
        a4TopMm: saved.letterheadA4TopMm,
        a4BottomMm: saved.letterheadA4BottomMm,
        a5TopMm: saved.letterheadA5TopMm,
        a5BottomMm: saved.letterheadA5BottomMm,
      }
    );

    return {
      a4: saved.letterheadA4,
      a5: saved.letterheadA5,
      a4TopMm: saved.letterheadA4TopMm,
      a4BottomMm: saved.letterheadA4BottomMm,
      a5TopMm: saved.letterheadA5TopMm,
      a5BottomMm: saved.letterheadA5BottomMm,
    };
  });
}

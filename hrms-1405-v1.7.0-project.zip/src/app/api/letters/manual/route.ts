import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { toEnDigits } from "@/lib/format";
import { todayJalaliStr, parseJalali, jalaliToGregorian, isValidJalali } from "@/lib/jalali";
import { nextLetterNumber, getLetterSettings, stripLetterImages } from "@/lib/letters";
import { sanitizeLetterHtml, htmlToPlainText } from "@/lib/rich-html";

// ============================================================
// ثبت نامه دستی — کارشناس اداری (مجوز letters:manual)
// نامه‌های خارج از قالب‌های سیستمی؛ با شماره سیستمی (ZDX_AD_0507019)
// ثبت می‌شوند و «در انتظار تأیید» می‌مانند — امضای دیجیتال فقط
// هنگام تأیید (letters:approve — PATCH /api/letters/[id]) صادر می‌شود.
// متن نامه می‌تواند «غنی» باشد: جدول راست‌به‌چپ با ستون‌های دلخواه
// (bodyHtml — پاک‌سازی‌شده با لیست سفید) یا متن ساده.
// ============================================================

const CATEGORIES = ["ADMIN", "HR", "FINANCE", "GENERAL"] as const;

function cleanStr(v: unknown, max: number): string {
  return String(v ?? "").trim().slice(0, max);
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "letters:manual");
    const b = await req.json();

    const title = cleanStr(b.title, 150);
    const recipient = cleanStr(b.recipient, 200);
    const category = CATEGORIES.includes(b.category) ? String(b.category) : "ADMIN";
    const dateJ = cleanStr(b.dateJ, 10); // 1405/07/13 — اختیاری، پیش‌فرض امروز

    // متن غنی (جدول/قالب‌بندی) + متن ساده — حداقل یکی باید مقدار داشته باشد
    const bodyHtml = sanitizeLetterHtml(String(b.bodyHtml ?? ""));
    let body = cleanStr(b.body, 8000);
    if (!body && bodyHtml) body = htmlToPlainText(bodyHtml).slice(0, 8000);

    if (!title) return Response.json({ error: "موضوع نامه الزامی است." }, { status: 400 });
    if (!body && !bodyHtml) return Response.json({ error: "متن نامه الزامی است." }, { status: 400 });
    if (dateJ && !isValidJalali(toEnDigits(dateJ))) {
      return Response.json({ error: "تاریخ نامه معتبر نیست (مثال درست: ۱۴۰۵/۰۷/۱۳)." }, { status: 400 });
    }

    // امضاکننده: از فرم، وگرنه پیش‌فرض تنظیمات نامه، وگرنه کاربر ثبت‌کننده
    const settings = await getLetterSettings();
    const signerName = cleanStr(b.signerName, 80) || settings.signerName || session.fullName;
    const signerTitle = cleanStr(b.signerTitle, 80) || settings.signerTitle;

    const number = await nextLetterNumber(category);
    // تاریخ نامه (اختیاری از فرم) — ظهر محلی همان روز تا نمایش در هر منطقه زمانی پایدار بماند
    const p = dateJ ? parseJalali(toEnDigits(dateJ)) : null;
    const g = p ? jalaliToGregorian(p.jy, p.jm, p.jd) : null;
    const letterDate = g ? new Date(g.gy, g.gm - 1, g.gd, 12, 0, 0) : new Date();

    // نامه دستی = در انتظار تأیید: شماره صادر می‌شود اما امضای دیجیتال
    // پس از تأیید مرجع مجاز (letters:approve) روی محتوا قفل خواهد شد.
    const row = await db.letterRequest.create({
      data: {
        number,
        source: "MANUAL",
        category,
        recipient,
        title,
        body,
        bodyHtml: bodyHtml || null,
        itemsJson: "[]",
        signerName,
        signerTitle,
        status: "PENDING",
        decisionNote: "",
        createdBy: session.fullName,
      },
    });
    await audit(
      session,
      "CREATE",
      "LETTER_REQUEST",
      row.id,
      `ثبت نامه دستی «${title}» (${number}) توسط ${session.fullName} — در انتظار تأیید`
    );
    return { letter: { ...row, items: [] } };
  });
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "letters:manual");
    const settings = await getLetterSettings();
    const manualCount = await db.letterRequest.count({ where: { source: "MANUAL" } });
    // تصاویر سربرگ حذف می‌شوند — فرم فقط پیش‌شماره/امضاکننده را می‌خواهد
    return { settings: stripLetterImages(settings), today: todayJalaliStr(), manualCount };
  });
}

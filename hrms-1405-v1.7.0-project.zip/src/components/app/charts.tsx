"use client";

// ============================================================
// نمودارهای SVG سفارشی — کاملاً RTL و فارسی، بدون کتابخانه خارجی
// ============================================================
import { useMemo, useState } from "react";
import { groupFa, fmtMoneyShort } from "@/lib/format";

export interface TrendPoint {
  label: string;
  value: number;
}

/** نمودار روند (خطی/سطحی) — محور عمودی سمت راست */
export function TrendChart({ data, height = 220, color = "#0d9488", formatter = (v: number) => fmtMoneyShort(v) }: {
  data: TrendPoint[];
  height?: number;
  color?: string;
  formatter?: (v: number) => string;
}) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 700;
  const H = height;
  const padR = 74;
  const padL = 16;
  const padT = 16;
  const padB = 34;

  const { points, maxV, minV } = useMemo(() => {
    if (data.length === 0) return { points: [], maxV: 1, minV: 0 };
    const vals = data.map((d) => d.value);
    const mx = Math.max(...vals);
    const mn = Math.min(...vals, 0);
    const range = mx - mn || mx || 1;
    const innerW = W - padR - padL;
    const innerH = H - padT - padB;
    const pts = data.map((d, i) => ({
      // RTL: اولین نقطه سمت راست
      x: padR + innerW - (data.length === 1 ? innerW / 2 : (i / (data.length - 1)) * innerW),
      y: padT + innerH - ((d.value - mn) / range) * innerH,
      ...d,
    }));
    return { points: pts, maxV: mx, minV: mn };
  }, [data, H]);

  if (points.length === 0) return <div className="h-[220px] flex items-center justify-center text-sm text-muted-foreground">داده‌ای موجود نیست</div>;

  const linePath = points.map((p, i) => `${i === 0 ? "M" : "L"}${p.x},${p.y}`).join(" ");
  const areaPath = `${linePath} L${points[points.length - 1].x},${H - padB} L${points[0].x},${H - padB} Z`;

  return (
    <div className="w-full overflow-hidden" dir="ltr">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height }} role="img" aria-label="نمودار روند">
        <defs>
          <linearGradient id={`grad-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.28" />
            <stop offset="100%" stopColor={color} stopOpacity="0.02" />
          </linearGradient>
        </defs>
        {/* خطوط راهنما */}
        {[0, 0.25, 0.5, 0.75, 1].map((f) => {
          const y = padT + (H - padT - padB) * f;
          const val = minV + (maxV - minV) * (1 - f);
          return (
            <g key={f}>
              <line x1={padL} x2={W - padR} y1={y} y2={y} stroke="#e2e8f0" strokeDasharray={f === 1 ? "0" : "4 4"} />
              <text x={W - padR + 6} y={y + 4} fontSize="10.5" fill="#64748b" textAnchor="start" fontFamily="Vazirmatn">
                {formatter(val)}
              </text>
            </g>
          );
        })}
        <path d={areaPath} fill={`url(#grad-${color.replace("#", "")})`} />
        <path d={linePath} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        {points.map((p, i) => (
          <g key={i}>
            <circle cx={p.x} cy={p.y} r={hover === i ? 5.5 : 3.5} fill="white" stroke={color} strokeWidth="2" />
            <text x={p.x} y={H - 12} fontSize="10.5" fill="#475569" textAnchor="middle" fontFamily="Vazirmatn">
              {p.label}
            </text>
            <rect x={p.x - (W - padR - padL) / (points.length * 2)} y={padT} width={(W - padR - padL) / points.length} height={H - padT - padB} fill="transparent" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} />
          </g>
        ))}
        {hover !== null && (
          <g>
            <rect x={points[hover].x - 62} y={points[hover].y - 44} width="124" height="28" rx="6" fill="#1e293b" opacity="0.92" />
            <text x={points[hover].x} y={points[hover].y - 25} fontSize="11" fill="white" textAnchor="middle" fontFamily="Vazirmatn" fontWeight="600">
              {formatter(points[hover].value)}
            </text>
          </g>
        )}
      </svg>
    </div>
  );
}

/** میله‌های افقی رتبه‌بندی (هزینه دپارتمان‌ها) — بزرگ‌ترین بالا */
export function BarList({ data, formatter = (v: number) => fmtMoneyShort(v), color = "#0d9488" }: {
  data: { label: string; value: number; sub?: string }[];
  formatter?: (v: number) => string;
  color?: string;
}) {
  const max = Math.max(...data.map((d) => d.value), 1);
  if (data.length === 0) return <div className="py-8 text-center text-sm text-muted-foreground">داده‌ای موجود نیست</div>;
  return (
    <div className="space-y-3">
      {data.map((d, i) => (
        <div key={i} className="group">
          <div className="flex items-baseline justify-between gap-3 mb-1">
            <span className="text-sm font-medium text-slate-700 truncate">{d.label}</span>
            <span className="text-xs text-muted-foreground tabular-nums shrink-0">{formatter(d.value)}{d.sub ? ` — ${d.sub}` : ""}</span>
          </div>
          <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500 group-hover:brightness-110"
              style={{ width: `${Math.max(3, (d.value / max) * 100)}%`, background: `linear-gradient(to left, ${color}, ${color}bb)` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

/** ستون‌های عمودی (توزیع طبقات) */
export function ColumnChart({ data, height = 200, color = "#0d9488" }: {
  data: { label: string; value: number; sub?: string }[];
  height?: number;
  color?: string;
}) {
  const max = Math.max(...data.map((d) => d.value), 1);
  if (data.length === 0) return <div className="py-8 text-center text-sm text-muted-foreground">داده‌ای موجود نیست</div>;
  return (
    <div className="flex items-end gap-2 sm:gap-3 justify-between" style={{ height }} dir="rtl">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1.5 group min-w-0">
          <span className="text-xs font-bold text-slate-700 tabular-nums">{groupFa(d.value)}</span>
          <div
            className="w-full rounded-t-lg transition-all duration-500 group-hover:brightness-110 relative"
            style={{
              height: `${Math.max(4, (d.value / max) * (height - 60))}px`,
              background: `linear-gradient(to top, ${color}, ${color}cc)`,
            }}
            title={d.sub}
          />
          <span className="text-[10px] text-muted-foreground text-center leading-3 truncate w-full">{d.label}</span>
        </div>
      ))}
    </div>
  );
}

/** نوار پشته‌ای ترکیب (ترکیب حقوق) */
export function StackBar({ parts, height = 26 }: {
  parts: { label: string; value: number; color: string }[];
  height?: number;
}) {
  const total = parts.reduce((a, p) => a + p.value, 0) || 1;
  return (
    <div>
      <div className="flex rounded-lg overflow-hidden" style={{ height }} dir="rtl">
        {parts.map((p, i) => (
          <div key={i} style={{ width: `${(p.value / total) * 100}%`, background: p.color }} className="transition-all duration-500" title={`${p.label}: ${groupFa(p.value)}`} />
        ))}
      </div>
      <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2.5">
        {parts.map((p, i) => (
          <span key={i} className="flex items-center gap-1.5 text-[11px] text-slate-600">
            <span className="w-2.5 h-2.5 rounded-sm" style={{ background: p.color }} />
            {p.label}
            <span className="text-muted-foreground tabular-nums">{groupFa(Math.round((p.value / total) * 100))}٪</span>
          </span>
        ))}
      </div>
    </div>
  );
}

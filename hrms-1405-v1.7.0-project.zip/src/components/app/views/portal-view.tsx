"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { UserCircle, Wallet, FileSignature, CalendarDays, HandCoins, Eye, Plus, FileText, Gift, CheckCircle2, XCircle, Clock, Info } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa, CONTRACT_TYPE_LABELS, LEAVE_TYPE_LABELS, REQUEST_STATUS_LABELS, LETTER_STATUS_LABELS } from "@/lib/format";
import { periodTitle, formatDateJ, toFaDigits, todayJalaliStr, isoToJalaliStr } from "@/lib/jalali";
import { JalaliDatePicker } from "../jalali-datepicker";
import { MoneyInput, Money } from "../money-input";
import { PayslipPrintDialog, type PayslipData } from "../payslip-print";
import { LetterSignatureBadge } from "../letter-print-buttons";
// نکته: LetterPrintButtons عمداً در پرتال کارمند استفاده نمی‌شود —
// طبق الزام: نامه درخواستی برای کاربر در هیچ حالتی قابل دانلود/چاپ نیست؛
// نسخه رسمی (سربرگ + امضای دیجیتال) صرفاً از سمت تأییدکننده (درخواست‌ها و تأییدها ← نامه‌ها) صادر می‌شود.
import type { SessionInfo } from "../app-root";

interface LetterTemplateOption {
  id: string; code: string; title: string; category: string; description: string;
  fields: { key: string; label: string; type: string; options?: string[]; required?: boolean }[];
}
interface LetterRow {
  id: string; number: string; templateTitle: string; title: string; body: string;
  status: string; decidedBy: string; decidedAt?: string | null; decisionNote: string;
  signatureCode?: string | null; createdAt: string;
}

interface PortalData {
  employee: {
    id: string; fullName: string; personnelCode: string; jobTitle: string; grade: { level: number; title: string } | null;
    hireDateJ: string; contractType: string; contractEndJ: string; bankName: string; iban: string; baseSalary: number;
    maritalStatus: string; childCount: number;
    welfare?: { id: string; title: string; code: string }[];
  } | null;
  payslips: PayslipData[];
  requests: {
    leaves: { id: string; type: string; startDateJ: string; endDateJ: string; days: number; status: string; reason: string; dmStatus?: string; dmBy?: string; hrStatus?: string; hrBy?: string; rejectReason?: string }[];
    advances: { id: string; amount: number; installments: number; status: string; reason: string; dmStatus?: string; dmBy?: string; hrStatus?: string; hrBy?: string; rejectReason?: string }[];
  };
  letters?: LetterRow[];
  contract: {
    type: string; startJ: string; endJ: string; probationEndJ: string;
    daysToEnd: number | null; daysToProbationEnd: number | null; yearsOfService: number;
  } | null;
}

export function PortalView({ user, onNavigate }: { user: SessionInfo; onNavigate: (v: string, p?: string) => void }) {
  const { data, loading, refetch } = useApi<PortalData>("/api/portal");
  const company = useApi<{ name: string; nationalId: string; ssoCode: string; taxId: string; address: string }>("/api/settings");
  const [printSlip, setPrintSlip] = useState<PayslipData | null>(null);
  const [leaveOpen, setLeaveOpen] = useState(false);
  const [advanceOpen, setAdvanceOpen] = useState(false);
  const [letterOpen, setLetterOpen] = useState(false);
  const [viewingLetter, setViewingLetter] = useState<LetterRow | null>(null);
  const { toast } = useToast();

  if (loading) return <div className="space-y-3"><Skeleton className="h-28 rounded-2xl" /><Skeleton className="h-72 rounded-2xl" /></div>;
  if (!data?.employee) {
    return (
      <Card className="rounded-2xl">
        <CardContent className="py-16 text-center">
          <UserCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="font-medium text-slate-600">حساب کاربری شما به پرونده کارمندی متصل نیست</p>
          <p className="text-xs text-muted-foreground mt-1">از مدیر منابع انسانی بخواهید حساب شما را به پرونده کارندی متصل کند.</p>
        </CardContent>
      </Card>
    );
  }

  const e = data.employee;
  const c = data.contract;
  const latestSlip = data.payslips[0];
  const myLetters = data.letters || [];

  return (
    <div className="space-y-4">
      {/* کارت پروفایل */}
      <Card className="rounded-2xl overflow-hidden">
        <div className="bg-gradient-to-l from-teal-600 to-teal-800 p-5 text-white flex flex-wrap items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-white/15 border border-white/30 flex items-center justify-center text-2xl font-bold">{e.fullName.charAt(0)}</div>
          <div className="flex-1 min-w-[200px]">
            <h2 className="text-xl font-bold">{e.fullName} عزیز، خوش آمدید 👋</h2>
            <p className="text-teal-100 text-sm mt-1">{e.jobTitle} — {e.grade ? `سطح ${toFaDigits(e.grade.level)} (${e.grade.title})` : "بدون طبقه"}</p>
            <p className="text-xs text-teal-200 mt-1 tabular-nums">کد پرسنلی: {e.personnelCode} • استخدام: {formatDateJ(e.hireDateJ)} • سابقه: {toFaDigits(c?.yearsOfService || 0)} سال</p>
          </div>
          {latestSlip && (
            <div className="text-left bg-white/10 rounded-xl p-3 border border-white/20">
              <p className="text-[11px] text-teal-100">خالص آخرین فیش ({latestSlip.period ? periodTitle(latestSlip.period.year, latestSlip.period.month) : "—"})</p>
              <p className="text-lg font-black tabular-nums mt-0.5">{groupFa(Math.round(latestSlip.netPay / 10))} <span className="text-xs font-normal">تومان</span></p>
              <Button size="sm" variant="outline" className="mt-1.5 h-7 text-xs bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white" onClick={() => setPrintSlip(latestSlip)}>
                <Eye className="w-3 h-3 ml-1" /> مشاهده فیش
              </Button>
            </div>
          )}
        </div>
        {/* رفاهیات */}
        {(e.welfare || []).length > 0 && (
          <div className="px-5 py-3 border-t bg-teal-50/40 flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-teal-800 flex items-center gap-1"><Gift className="w-3.5 h-3.5" /> رفاهیات مورد استفاده:</span>
            {e.welfare!.map((w) => (
              <Badge key={w.id} className="bg-teal-100 text-teal-800 hover:bg-teal-100 text-[11px]">{w.title}</Badge>
            ))}
          </div>
        )}
      </Card>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* وضعیت قرارداد */}
        <Card className="rounded-2xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><FileSignature className="w-4 h-4 text-teal-600" /> وضعیت قرارداد</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">نوع قرارداد</span>
              <Badge className={e.contractType === "PERMANENT" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}>
                {CONTRACT_TYPE_LABELS[e.contractType]}
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">شروع قرارداد</span>
              <span className="text-sm font-medium tabular-nums">{formatDateJ(c?.startJ)}</span>
            </div>
            {c?.endJ && (
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">پایان قرارداد</span>
                <span className="text-sm font-medium tabular-nums">{formatDateJ(c.endJ)}</span>
              </div>
            )}
            {c?.daysToEnd !== null && c?.daysToEnd !== undefined && c.daysToEnd >= 0 && (
              <div className={`rounded-xl p-3 text-xs leading-5 ${c.daysToEnd <= 30 ? "bg-rose-50 text-rose-700 border border-rose-100" : "bg-amber-50 text-amber-700 border border-amber-100"}`}>
                {c.daysToEnd} روز تا پایان قرارداد — برای تمدید با منابع انسانی هماهنگ کنید.
              </div>
            )}
            {c?.daysToProbationEnd !== null && c?.daysToProbationEnd !== undefined && c.daysToProbationEnd >= 0 && (
              <div className="rounded-xl bg-amber-50 border border-amber-100 p-3 text-xs text-amber-700 leading-5">
                {c.daysToProbationEnd} روز تا پایان دوره آزمایشی.
              </div>
            )}
            <div className="pt-2 border-t text-xs text-muted-foreground">
              <p><span className="inline-block w-24">وضعیت تأهل:</span> {e.maritalStatus === "MARRIED" ? "متأهل" : "مجرد"} — {toFaDigits(e.childCount)} فرزند</p>
              <p className="mt-1"><span className="inline-block w-24">بانک:</span> {e.bankName || "—"}</p>
            </div>
          </CardContent>
        </Card>

        {/* فیش‌های من */}
        <Card className="rounded-2xl xl:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2"><Wallet className="w-4 h-4 text-teal-600" /> فیش‌های حقوقی من</CardTitle>
          </CardHeader>
          <CardContent className="max-h-80 overflow-y-auto space-y-2 -mx-1 px-1">
            {data.payslips.length === 0 && <p className="text-sm text-muted-foreground py-8 text-center">هنوز فیشی صادر نشده است</p>}
            {data.payslips.map((p) => (
              <div key={p.id} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 hover:border-teal-300 transition-colors">
                <div className="flex-1">
                  <p className="text-sm font-medium">{p.period ? periodTitle(p.period.year, p.period.month) : "—"}</p>
                  <p className="text-[11px] text-muted-foreground tabular-nums">
                    ناخالص {groupFa(Math.round(p.gross / 10))} • بیمه {groupFa(Math.round(p.employeeSso / 10))} • مالیات {groupFa(Math.round(p.incomeTax / 10))}
                    {p.isReverse && <Badge className="mr-1.5 bg-amber-100 text-amber-700 hover:bg-amber-100">معکوس</Badge>}
                  </p>
                </div>
                <span className="text-sm font-bold text-emerald-700 tabular-nums">{groupFa(Math.round(p.netPay / 10))} <span className="text-[10px] font-normal">تومان</span></span>
                <Button size="sm" variant="outline" className="h-8 gap-1" onClick={() => setPrintSlip(p)}>
                  <Eye className="w-3.5 h-3.5" /> فیش
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* درخواست‌ها */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            درخواست‌های من
            <div className="mr-auto flex gap-2 flex-wrap">
              <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setLeaveOpen(true)}><CalendarDays className="w-3.5 h-3.5" /> درخواست مرخصی</Button>
              <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setAdvanceOpen(true)}><HandCoins className="w-3.5 h-3.5" /> درخواست مساعده</Button>
              <Button size="sm" className="gap-1.5 bg-teal-600 hover:bg-teal-700" onClick={() => setLetterOpen(true)}><FileText className="w-3.5 h-3.5" /> درخواست‌نامه</Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="leaves" dir="rtl">
            <TabsList className="flex-wrap">
              <TabsTrigger value="leaves">مرخصی‌ها ({toFaDigits(data.requests.leaves.length)})</TabsTrigger>
              <TabsTrigger value="advances">مساعدها ({toFaDigits(data.requests.advances.length)})</TabsTrigger>
              <TabsTrigger value="letters">نامه‌ها ({toFaDigits(myLetters.length)})</TabsTrigger>
            </TabsList>
            <TabsContent value="leaves" className="mt-3 space-y-2">
              {data.requests.leaves.length === 0 && <p className="text-sm text-muted-foreground py-4 text-center">درخواستی ثبت نشده است</p>}
              {data.requests.leaves.map((l) => (
                <div key={l.id} className="rounded-xl border p-3 flex flex-wrap items-center gap-3">
                  <Badge variant="outline">{LEAVE_TYPE_LABELS[l.type]}</Badge>
                  <span className="text-xs text-muted-foreground tabular-nums">{formatDateJ(l.startDateJ)} تا {formatDateJ(l.endDateJ)} ({toFaDigits(l.days)} روز)</span>
                  {l.reason && <span className="text-xs text-muted-foreground truncate flex-1">{l.reason}</span>}
                  <StageTrail status={l.status} dmStatus={l.dmStatus} dmBy={l.dmBy} hrStatus={l.hrStatus} hrBy={l.hrBy} rejectReason={l.rejectReason} />
                </div>
              ))}
            </TabsContent>
            <TabsContent value="advances" className="mt-3 space-y-2">
              {data.requests.advances.length === 0 && <p className="text-sm text-muted-foreground py-4 text-center">درخواستی ثبت نشده است</p>}
              {data.requests.advances.map((a) => (
                <div key={a.id} className="rounded-xl border p-3 flex flex-wrap items-center gap-3">
                  <span className="text-sm font-bold tabular-nums"><Money amount={a.amount} /></span>
                  <span className="text-xs text-muted-foreground">{toFaDigits(a.installments)} قسط {a.reason ? `• ${a.reason}` : ""}</span>
                  <StageTrail status={a.status} dmStatus={a.dmStatus} dmBy={a.dmBy} hrStatus={a.hrStatus} hrBy={a.hrBy} rejectReason={a.rejectReason} />
                </div>
              ))}
            </TabsContent>
            <TabsContent value="letters" className="mt-3 space-y-2">
              {myLetters.length === 0 && (
                <p className="text-sm text-muted-foreground py-4 text-center">
                  درخواست‌نامه‌ای ثبت نشده — با دکمه «درخواست‌نامه» از قالب‌های آماده شروع کنید.
                </p>
              )}
              {myLetters.map((l) => (
                <div key={l.id} className="rounded-xl border p-3 flex flex-wrap items-center gap-3">
                  <div className="flex-1 min-w-[160px]">
                    <p className="text-sm font-medium">{l.title}</p>
                    <p className="text-[10px] text-muted-foreground font-mono" dir="ltr">{l.number}</p>
                  </div>
                  <Badge className={l.status === "APPROVED" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : l.status === "REJECTED" ? "bg-rose-100 text-rose-700 hover:bg-rose-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}>
                    {LETTER_STATUS_LABELS[l.status]}
                  </Badge>
                  <Button size="sm" variant="outline" className="h-8 gap-1" onClick={() => setViewingLetter(l)}>
                    <Eye className="w-3.5 h-3.5" /> مشاهده
                  </Button>
                </div>
              ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <PayslipPrintDialog
        open={!!printSlip}
        onOpenChange={(v) => !v && setPrintSlip(null)}
        payslip={printSlip}
        company={company.data || { name: "", nationalId: "", ssoCode: "", taxId: "", address: "" }}
      />

      <LeaveRequestDialog open={leaveOpen} onOpenChange={setLeaveOpen} onSaved={refetch} />
      <AdvanceRequestDialog open={advanceOpen} onOpenChange={setAdvanceOpen} onSaved={refetch} />
      <LetterRequestDialog open={letterOpen} onOpenChange={setLetterOpen} onSaved={refetch} />

      <Dialog open={!!viewingLetter} onOpenChange={(v) => !v && setViewingLetter(null)}>
        <DialogContent className="sm:max-w-[58.8rem] max-h-[85vh] overflow-y-auto" dir="rtl">
          {viewingLetter && (
            <>
              <DialogHeader>
                <DialogTitle className="text-sm flex items-center gap-2 flex-wrap">
                  {viewingLetter.title}
                  <span className="font-mono text-[10px] text-muted-foreground" dir="ltr">{viewingLetter.number}</span>
                  <LetterSignatureBadge code={viewingLetter.signatureCode} decidedAt={viewingLetter.decidedAt} />
                </DialogTitle>
              </DialogHeader>
              <div className="rounded-xl border bg-white p-5 text-[13px] leading-8 whitespace-pre-wrap max-h-[50vh] overflow-y-auto">{viewingLetter.body}</div>
              {(viewingLetter.decidedBy || viewingLetter.decisionNote) && (
                <div className="rounded-lg bg-slate-50 border px-3 py-2 text-[11px] leading-5 text-slate-600 space-y-0.5">
                  {viewingLetter.decidedBy && (
                    <p>تعیین‌کنده: <span className="font-medium text-slate-800">{viewingLetter.decidedBy}</span>{viewingLetter.decidedAt ? ` — ${formatDateJ(isoToJalaliStr(new Date(viewingLetter.decidedAt)))}` : ""}</p>
                  )}
                  {viewingLetter.decisionNote && <p>یادداشت: {viewingLetter.decisionNote}</p>}
                </div>
              )}
              {/* الزام: نامه درخواستی برای کاربر در هیچ حالتی قابل دانلود/چاپ نیست — فقط مشاهده */}
              <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-[11px] leading-5 text-amber-800">
                  <p className="font-bold">نسخه رسمی این نامه برای کاربر قابل دانلود نیست.</p>
                  <p>
                    چاپ و دانلود نسخه رسمی (با سربرگ سازمان و امضای دیجیتال) صرفاً پس از تأیید، از سمت واحد سرمایه انسانی/اداری در بخش
                    «درخواست‌ها و تأییدها ← نامه‌ها» انجام می‌شود و نسخه چاپی به شما تحویل داده خواهد شد.
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setViewingLetter(null)}>بستن</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// نمایش مراحل تأیید برای کارمند
function StageTrail({ status, dmStatus, dmBy, hrStatus, hrBy, rejectReason }: {
  status: string; dmStatus?: string; dmBy?: string; hrStatus?: string; hrBy?: string; rejectReason?: string;
}) {
  if (!dmStatus && !hrStatus) {
    return (
      <Badge className={`mr-auto ${status === "APPROVED" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : status === "REJECTED" ? "bg-rose-100 text-rose-700 hover:bg-rose-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}`}>
        {REQUEST_STATUS_LABELS[status]}
      </Badge>
    );
  }
  const step = (label: string, st: string, by: string) => (
    <div className="flex items-center gap-1 text-[10px]">
      {st === "APPROVED" && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
      {st === "REJECTED" && <XCircle className="w-3 h-3 text-rose-600" />}
      {st === "PENDING" && <Clock className="w-3 h-3 text-slate-400" />}
      <span className={st === "PENDING" ? "text-muted-foreground" : "text-slate-700"}>{label}{by ? ` (${by})` : ""}</span>
    </div>
  );
  return (
    <div className="mr-auto flex flex-col gap-0.5 items-start">
      {step("۱. مدیر واحد", dmStatus || "PENDING", dmBy || "")}
      {step("۲. منابع انسانی", hrStatus || "PENDING", hrBy || "")}
      {rejectReason && <span className="text-[10px] text-rose-600">دلیل رد: {rejectReason}</span>}
    </div>
  );
}

function LeaveRequestDialog({ open, onOpenChange, onSaved }: { open: boolean; onOpenChange: (v: boolean) => void; onSaved: () => void }) {
  const { toast } = useToast();
  const [type, setType] = useState("ANNUAL");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!start || !end) {
      toast({ title: "تاریخ شروع و پایان الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/requests", { method: "POST", json: { kind: "LEAVE", type, startDateJ: start, endDateJ: end, reason } });
      onOpenChange(false);
      onSaved();
      toast({ title: "درخواست مرخصی ثبت شد", description: "برای تأیید به مدیر واحد شما ارسال شد." });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem]" dir="rtl">
        <DialogHeader><DialogTitle>درخواست مرخصی</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">نوع مرخصی</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(LEAVE_TYPE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">از تاریخ</Label>
              <JalaliDatePicker value={start} onChange={setStart} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">تا تاریخ</Label>
              <JalaliDatePicker value={end} onChange={setEnd} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">دلیل (اختیاری)</Label>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
          <p className="text-[11px] text-muted-foreground bg-amber-50 border border-amber-100 rounded-lg p-2.5 leading-5">
            گردش تأیید: ابتدا مدیر واحد شما بررسی می‌کند، سپس مدیر منابع انسانی تأیید نهایی می‌کند.
          </p>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5"><Plus className="w-4 h-4" /> {saving ? "..." : "ثبت درخواست"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function AdvanceRequestDialog({ open, onOpenChange, onSaved }: { open: boolean; onOpenChange: (v: boolean) => void; onSaved: () => void }) {
  const { toast } = useToast();
  const [amount, setAmount] = useState(5_000_000);
  const [installments, setInstallments] = useState(4);
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  async function save() {
    if (amount <= 0) {
      toast({ title: "مبلغ نامعتبر است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/requests", { method: "POST", json: { kind: "ADVANCE", amount: amount * 10, installments, reason } });
      onOpenChange(false);
      onSaved();
      toast({ title: "درخواست مساعده ثبت شد", description: `${groupFa(amount)} تومان در ${toFaDigits(installments)} قسط — در انتظار تأیید مدیر واحد.` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem]" dir="rtl">
        <DialogHeader><DialogTitle>درخواست مساعده (پیش‌پرداخت)</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">مبلغ درخواستی</Label>
            <MoneyInput value={amount} onChange={setAmount} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تعداد اقساط بازپرداخت</Label>
            <Select value={String(installments)} onValueChange={(v) => setInstallments(+v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {[2, 4, 6, 8, 10, 12].map((n) => <SelectItem key={n} value={String(n)}>{toFaDigits(n)} قسط</SelectItem>)}
              </SelectContent>
            </Select>
            <p className="text-[11px] text-muted-foreground">هر قسط: حدود {groupFa(Math.round(amount / installments))} تومان</p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">دلیل (اختیاری)</Label>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} />
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5"><Plus className="w-4 h-4" /> {saving ? "..." : "ثبت درخواست"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= درخواست‌نامه (تمپلیت‌محور) =================
function LetterRequestDialog({ open, onOpenChange, onSaved }: { open: boolean; onOpenChange: (v: boolean) => void; onSaved: () => void }) {
  const { toast } = useToast();
  const templates = useApi<{ templates: LetterTemplateOption[] }>(open ? "/api/letters/templates" : null);
  const [templateId, setTemplateId] = useState("");
  const [values, setValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const selected = (templates.data?.templates || []).find((t) => t.id === templateId);

  function pickTemplate(id: string) {
    setTemplateId(id);
    setValues({});
  }

  async function save() {
    if (!selected) {
      toast({ title: "یک قالب نامه انتخاب کنید", variant: "destructive" });
      return;
    }
    // اعتبارسنجی فیلدهای الزامی
    const missing = selected.fields.filter((f) => f.required && !(values[f.key] || "").trim());
    if (missing.length) {
      toast({ title: "فیلدهای الزامی را کامل کنید", description: missing.map((f) => f.label).join("، "), variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const r = await api<{ letter: { number: string } }>("/api/letters", { method: "POST", json: { templateId, values } });
      onOpenChange(false);
      onSaved();
      setTemplateId("");
      setValues({});
      toast({ title: "درخواست‌نامه ثبت شد", description: `شماره سیستمی ${r.letter.number} — در انتظار تأیید.` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) { setTemplateId(""); setValues({}); } }}>
      <DialogContent className="sm:max-w-[50.4rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><FileText className="w-5 h-5 text-teal-600" /> درخواست‌نامه جدید</DialogTitle>
        </DialogHeader>

        {templates.loading ? (
          <Skeleton className="h-10 rounded-lg" />
        ) : (
          <div className="space-y-1.5">
            <Label className="text-xs">نوع نامه (قالب)</Label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {(templates.data?.templates || []).map((t) => (
                <button
                  key={t.id}
                  onClick={() => pickTemplate(t.id)}
                  className={`text-right rounded-xl border p-3 transition-colors ${templateId === t.id ? "border-teal-400 bg-teal-50" : "border-slate-200 hover:border-teal-300"}`}
                >
                  <p className="text-sm font-medium">{t.title}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 leading-4">{t.description}</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* فرم داینامیک بر اساس فیلدهای قالب */}
        {selected && (
          <div className="rounded-xl border border-teal-200 bg-teal-50/30 p-4 space-y-4">
            <p className="text-xs font-bold text-teal-800">اطلاعات مورد نیاز نامه «{selected.title}»:</p>
            {selected.fields.map((f) => (
              <div key={f.key} className="space-y-1.5">
                <Label className="text-xs">
                  {f.label}
                  {f.required && <span className="text-rose-500 mr-0.5">*</span>}
                </Label>
                {f.type === "textarea" ? (
                  <Textarea value={values[f.key] || ""} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} className="min-h-20" placeholder={f.label} />
                ) : f.type === "select" ? (
                  <Select value={values[f.key] || ""} onValueChange={(v) => setValues({ ...values, [f.key]: v })}>
                    <SelectTrigger><SelectValue placeholder={`انتخاب ${f.label}`} /></SelectTrigger>
                    <SelectContent>
                      {(f.options || []).map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                    </SelectContent>
                  </Select>
                ) : f.type === "date" ? (
                  <JalaliDatePicker value={values[f.key] || ""} onChange={(v) => setValues({ ...values, [f.key]: v })} />
                ) : f.type === "number" ? (
                  <Input value={values[f.key] || ""} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} placeholder={f.label} inputMode="numeric" />
                ) : (
                  <Input value={values[f.key] || ""} onChange={(e) => setValues({ ...values, [f.key]: e.target.value })} placeholder={f.label} />
                )}
              </div>
            ))}
            <p className="text-[11px] text-muted-foreground leading-5">
              پس از ثبت، شماره سیستمی یکتا دریافت می‌کنید و نامه برای تأیید به مرجع مربوطه (منابع انسانی/اداری) ارسال می‌شود.
            </p>
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={!selected || saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            <Plus className="w-4 h-4" /> {saving ? "در حال ثبت..." : "ثبت نامه"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

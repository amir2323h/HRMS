"use client";

// ============================================================
// مدیریت قالب درخواست‌نامه — فیلدهای داینامیک + نقش تأییدکننده
// ============================================================
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { FileText, Plus, Pencil, Trash2, Braces } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";

interface FieldDef {
  key: string; label: string; type: "text" | "number" | "date" | "select" | "textarea";
  options?: string[]; required?: boolean;
}
interface TemplateRow {
  id: string; code: string; title: string; category: string; description: string;
  fields: FieldDef[]; bodyTemplate: string; approverRole: string; isActive: boolean;
  version: number; requestCount: number;
}

const CATEGORY_LABELS: Record<string, string> = { GENERAL: "عمومی", HR: "منابع انسانی", FINANCE: "مالی و اداری", ADMIN: "اداری" };

const EMPLOYEE_VARS = [
  { name: "employee_name", desc: "نام کامل کارمند" },
  { name: "employee_personnel_code", desc: "کد پرسنلی" },
  { name: "employee_national_id", desc: "کد ملی" },
  { name: "employee_job_title", desc: "عنوان شغل" },
  { name: "employee_grade", desc: "طبقه شغلی" },
  { name: "employee_hire_date", desc: "تاریخ استخدام" },
  { name: "employee_mobile", desc: "موبایل" },
  { name: "base_salary_toman", desc: "حقوق پایه (تومان)" },
  { name: "company_name", desc: "نام شرکت" },
  { name: "letter_number", desc: "شماره سیستمی نامه" },
  { name: "today_date", desc: "تاریخ امروز" },
];

export function LetterTemplatesManager({ canEdit, roles }: { canEdit: boolean; roles: { key: string; name: string }[] }) {
  const list = useApi<{ templates: TemplateRow[] }>("/api/letters/templates");
  const [editing, setEditing] = useState<TemplateRow | null>(null);
  const [creating, setCreating] = useState(false);
  const { toast } = useToast();
  const templates = list.data?.templates || [];

  async function remove(t: TemplateRow) {
    if (!confirm(`حذف قالب «${t.title}»؟`)) return;
    try {
      await api(`/api/letters/templates/${t.id}`, { method: "DELETE" });
      await list.refetch();
      toast({ title: "قالب حذف شد" });
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-cyan-50 to-white border-cyan-200">
        <CardContent className="p-4 flex items-start gap-3 flex-wrap">
          <FileText className="w-6 h-6 text-cyan-600 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-[200px]">
            <p className="font-bold text-sm text-slate-800">قالب درخواست‌نامه‌ها</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              هر قالب فیلدهای اختصاصی دارد که کارمند هنگام ثبت نامه پر می‌کند؛ متن با متغیرهای
              <code className="bg-slate-100 rounded px-1 mx-0.5 text-[10px]" dir="ltr">{"{{field_کلید}}"}</code>
              و متغیرهای کارمند پر می‌شود و برای تأیید به نقش مربوطه می‌رود.
            </p>
          </div>
          {canEdit && (
            <Button className="bg-cyan-600 hover:bg-cyan-700 gap-1.5 shrink-0" onClick={() => setCreating(true)}>
              <Plus className="w-4 h-4" /> قالب جدید
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {list.loading && [0, 1, 2].map((i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
        {templates.map((t) => (
          <Card key={t.id} className="rounded-2xl flex flex-col">
            <CardContent className="p-4 flex-1 space-y-2.5">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-bold text-sm flex-1">{t.title}</p>
                <Badge variant="outline" className="text-[10px] font-mono" dir="ltr">{t.code}</Badge>
              </div>
              <div className="flex flex-wrap gap-1">
                <Badge className="bg-cyan-50 text-cyan-700 hover:bg-cyan-50 text-[10px]">{CATEGORY_LABELS[t.category] || t.category}</Badge>
                <Badge variant="outline" className="text-[10px]">{toFaDigits(t.fields.length)} فیلد</Badge>
                <Badge variant="outline" className="text-[10px]">نسخه {toFaDigits(t.version)}</Badge>
                <Badge variant="outline" className="text-[10px]">{toFaDigits(t.requestCount)} صدور</Badge>
                <Badge className={t.isActive ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>{t.isActive ? "فعال" : "غیرفعال"}</Badge>
              </div>
              {t.description && <p className="text-xs text-muted-foreground leading-5 line-clamp-2">{t.description}</p>}
              <p className="text-[11px] text-muted-foreground">تأییدکننده: {roles.find((r) => r.key === t.approverRole)?.name || t.approverRole}</p>
              {canEdit && (
                <div className="flex gap-1.5 pt-1">
                  <Button size="sm" variant="outline" className="gap-1 h-8 flex-1" onClick={() => setEditing(t)}><Pencil className="w-3.5 h-3.5" /> ویرایش</Button>
                  <Button size="sm" variant="destructive" className="h-8 w-8 p-0" disabled={t.requestCount > 0} onClick={() => remove(t)} title={t.requestCount > 0 ? "پیش‌تر استفاده شده — غیرفعال کنید" : ""}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {(creating || editing) && (
        <LetterTemplateEditor
          template={editing}
          roles={roles}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={() => { list.refetch(); setCreating(false); setEditing(null); toast({ title: editing ? "قالب به‌روزرسانی شد (نسخه جدید)" : "قالب نامه ساخته شد" }); }}
        />
      )}
    </div>
  );
}

function LetterTemplateEditor({ template, roles, onClose, onSaved }: {
  template: TemplateRow | null;
  roles: { key: string; name: string }[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [title, setTitle] = useState(template?.title || "");
  const [category, setCategory] = useState(template?.category || "GENERAL");
  const [description, setDescription] = useState(template?.description || "");
  const [approverRole, setApproverRole] = useState(template?.approverRole || "HR_MANAGER");
  const [isActive, setIsActive] = useState(template?.isActive ?? true);
  const [body, setBody] = useState(template?.bodyTemplate || DEFAULT_LETTER_BODY);
  const [fields, setFields] = useState<FieldDef[]>(template?.fields || []);
  const [saving, setSaving] = useState(false);

  function addField() {
    setFields([...fields, { key: "", label: "", type: "text", required: false }]);
  }
  function updField(idx: number, patch: Partial<FieldDef>) {
    const next = [...fields];
    next[idx] = { ...next[idx], ...patch };
    setFields(next);
  }
  function delField(idx: number) {
    setFields(fields.filter((_, i) => i !== idx));
  }

  async function save() {
    if (!title.trim() || !body.trim()) {
      toast({ title: "عنوان و متن قالب الزامی است", variant: "destructive" });
      return;
    }
    const cleaned = fields.filter((f) => f.key.trim() && f.label.trim());
    for (const f of cleaned) {
      if (!/^[a-z][a-z0-9_]*$/i.test(f.key.trim())) {
        toast({ title: `کلید فیلد «${f.label}» نامعتبر است`, description: "باید با حرف شروع شود و فقط حروف/عدد/زیرخط داشته باشد.", variant: "destructive" });
        return;
      }
    }
    const dup = cleaned.map((f) => f.key).filter((k, i, a) => a.indexOf(k) !== i);
    if (dup.length) {
      toast({ title: `کلید فیلد تکراری: ${dup.join("، ")}`, variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: title.trim(), category, description, approverRole, isActive,
        bodyTemplate: body, fields: cleaned,
      };
      if (template) {
        await api(`/api/letters/templates/${template.id}`, { method: "PATCH", json: payload });
      } else {
        await api("/api/letters/templates", { method: "POST", json: payload });
      }
      onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[78.4rem] max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><FileText className="w-5 h-5 text-cyan-600" /> {template ? `ویرایش قالب — ${template.title}` : "قالب نامه جدید"}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان نامه</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="درخواست تمدید قرارداد" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">دسته</Label>
            <select className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm" value={category} onChange={(e) => setCategory(e.target.value)} dir="rtl">
              {Object.entries(CATEGORY_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نقش تأییدکننده (اداری یا سرمایه انسانی)</Label>
            <select className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm" value={approverRole} onChange={(e) => setApproverRole(e.target.value)} dir="rtl">
              {roles.map((r) => <option key={r.key} value={r.key}>{r.name}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">توضیح کوتاه (نمایش به کارمند)</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div className="flex items-center gap-2 sm:col-span-2 rounded-xl border p-3">
            <Switch checked={isActive} onCheckedChange={setIsActive} id="lt-active" />
            <label htmlFor="lt-active" className="text-xs cursor-pointer">فعال — قابل انتخاب توسط کارکنان</label>
          </div>
        </div>

        {/* فیلدهای داینامیک */}
        <div className="rounded-xl border bg-slate-50/60 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold">فیلدهای مورد نیاز نامه (فرم داینامیک کارمند)</p>
            <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={addField}><Plus className="w-3 h-3" /> افزودن فیلد</Button>
          </div>
          {fields.length === 0 && <p className="text-[11px] text-muted-foreground">فیلدی تعریف نشده — نامه فقط با متغیرهای کارمند پر می‌شود.</p>}
          {fields.map((f, idx) => (
            <div key={idx} className="grid grid-cols-12 gap-2 items-end bg-white border rounded-lg p-2">
              <div className="col-span-3 space-y-1">
                <Label className="text-[10px]">کلید (لاتین)</Label>
                <Input className="h-8 text-xs" dir="ltr" value={f.key} onChange={(e) => updField(idx, { key: e.target.value })} placeholder="amount" />
              </div>
              <div className="col-span-3 space-y-1">
                <Label className="text-[10px]">برچسب فارسی</Label>
                <Input className="h-8 text-xs" value={f.label} onChange={(e) => updField(idx, { label: e.target.value })} placeholder="مبلغ درخواستی" />
              </div>
              <div className="col-span-2 space-y-1">
                <Label className="text-[10px]">نوع</Label>
                <select className="w-full h-8 rounded-md border bg-transparent px-1.5 text-xs" value={f.type} onChange={(e) => updField(idx, { type: e.target.value as FieldDef["type"] })} dir="rtl">
                  <option value="text">متن</option>
                  <option value="number">عدد</option>
                  <option value="date">تاریخ</option>
                  <option value="select">انتخابی</option>
                  <option value="textarea">متن بلند</option>
                </select>
              </div>
              <div className="col-span-3 space-y-1">
                <Label className="text-[10px]">گزینه‌ها (با «،» جدا — برای انتخابی)</Label>
                <Input className="h-8 text-xs" value={(f.options || []).join("، ")} onChange={(e) => updField(idx, { options: e.target.value ? e.target.value.split(/[،,]/).map((s) => s.trim()).filter(Boolean) : undefined })} placeholder="۶، ۱۲، ۲۴" disabled={f.type !== "select"} />
              </div>
              <div className="col-span-1 flex flex-col items-center gap-1">
                <label className="text-[9px] text-center leading-3">اجباری</label>
                <input type="checkbox" className="accent-cyan-600 w-4 h-4" checked={!!f.required} onChange={(e) => updField(idx, { required: e.target.checked })} />
              </div>
              <div className="col-span-12 flex justify-start">
                <Button size="sm" variant="ghost" className="h-6 text-rose-600 text-[10px] gap-0.5" onClick={() => delField(idx)}><Trash2 className="w-3 h-3" /> حذف فیلد</Button>
              </div>
            </div>
          ))}
        </div>

        {/* متغیرها */}
        <div className="rounded-xl border bg-slate-50/60 p-3">
          <p className="text-xs font-bold mb-2 flex items-center gap-1"><Braces className="w-3.5 h-3.5" /> متغیرها — در متن قالب استفاده کنید:</p>
          <div className="flex flex-wrap gap-1.5">
            {EMPLOYEE_VARS.map((v) => (
              <button key={v.name} type="button" title={v.desc} onClick={() => setBody((b) => b + `{{${v.name}}}`)} className="text-[10px] font-mono bg-white border hover:border-cyan-400 hover:bg-cyan-50 rounded-md px-1.5 py-0.5" dir="ltr">
                {v.name}
              </button>
            ))}
            {fields.filter((f) => f.key.trim()).map((f) => (
              <button key={f.key} type="button" title={f.label} onClick={() => setBody((b) => b + `{{field_${f.key.trim()}}}`)} className="text-[10px] font-mono bg-cyan-50 border border-cyan-300 hover:bg-cyan-100 rounded-md px-1.5 py-0.5" dir="ltr">
                field_{f.key.trim()}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs">متن قالب نامه</Label>
          <Textarea dir="rtl" className="min-h-[240px] text-[13px] leading-8" value={body} onChange={(e) => setBody(e.target.value)} placeholder="متن نامه با متغیرها..." />
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-cyan-600 hover:bg-cyan-700">{saving ? "..." : template ? "ذخیره (نسخه جدید)" : "ایجاد قالب"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

const DEFAULT_LETTER_BODY = `خدمات مدیریت محترم شرکت {{company_name}},

اینجانب {{employee_name}} (کد پرسنلی {{employee_personnel_code}}) در سمت {{employee_job_title}}، به موجب این نامه درخواست زیر را دارم:

شرح درخواست:
{{field_reason}}

خواهشمند است بررسی و اعلام نتیجه فرمایید.

با تشکر — {{employee_name}}
شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`;

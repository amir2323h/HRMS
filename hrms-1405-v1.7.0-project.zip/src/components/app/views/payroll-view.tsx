"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Wallet, Plus, ArrowRight, CheckCircle2, Banknote, FileDown, Trash2, Eye, Building2 } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa } from "@/lib/format";
import { JALALI_MONTHS, periodTitle, toFaDigits } from "@/lib/jalali";
import { Money } from "../money-input";
import { PayslipPrintDialog, type PayslipData } from "../payslip-print";

interface PeriodRow {
  id: string; year: number; month: number; status: string; notes: string; payslipCount: number;
  totals: {
    gross: number; netPay: number; employeeSso: number; employerSso20: number;
    unemploymentSso3: number; incomeTax: number; employerTotalCost: number;
  };
}

const STATUS_BADGE: Record<string, { label: string; cls: string }> = {
  CALCULATED: { label: "محاسبه‌شده", cls: "bg-amber-100 text-amber-700 hover:bg-amber-100" },
  APPROVED: { label: "تأییدشده", cls: "bg-teal-100 text-teal-700 hover:bg-teal-100" },
  PAID: { label: "پرداخت‌شده", cls: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" },
};

export function PayrollView({ onNavigate, detailId }: { onNavigate: (v: string, p?: string) => void; detailId?: string | null }) {
  const [newOpen, setNewOpen] = useState(false);
  const { data, loading, refetch } = useApi<{ periods: PeriodRow[] }>("/api/payroll/periods");
  const { toast } = useToast();

  if (detailId) {
    return <PeriodDetail id={detailId} onBack={() => onNavigate("payroll")} onChanged={refetch} />;
  }

  const periods = data?.periods || [];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <p className="text-sm text-muted-foreground">دوره‌های حقوق و دستمزد سال ۱۴۰۵ — محاسبه خودکار با پارامترهای قانونی</p>
        <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => setNewOpen(true)}>
          <Plus className="w-4 h-4" /> ایجاد دوره جدید
        </Button>
      </div>

      {loading && <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}</div>}

      <div className="grid grid-cols-1 gap-3">
        {periods.map((p) => {
          const st = STATUS_BADGE[p.status] || STATUS_BADGE.CALCULATED;
          return (
            <Card key={p.id} className="rounded-2xl hover:shadow-md transition-all cursor-pointer" onClick={() => onNavigate("payroll-detail", p.id)}>
              <CardContent className="p-5">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-700 flex items-center justify-center shrink-0">
                    <Wallet className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-[180px]">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-slate-800">{periodTitle(p.year, p.month)}</h3>
                      <Badge className={st.cls}>{st.label}</Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{toFaDigits(p.payslipCount)} فیش حقوقی</p>
                  </div>
                  <div className="flex gap-6 flex-wrap text-sm">
                    <MiniStat label="جمع ناخالص" amount={p.totals.gross} />
                    <MiniStat label="جمع خالص" amount={p.totals.netPay} color="text-emerald-700" />
                    <MiniStat label="بیمه کارفرما (۲۳٪)" amount={p.totals.employerSso20 + p.totals.unemploymentSso3} color="text-amber-700" />
                    <MiniStat label="مالیات" amount={p.totals.incomeTax} color="text-rose-700" />
                  </div>
                  <ArrowRight className="w-5 h-5 text-teal-600 shrink-0" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <NewPeriodDialog open={newOpen} onOpenChange={setNewOpen} periods={periods} onCreated={(id) => { refetch(); onNavigate("payroll-detail", id); }} />
    </div>
  );
}

function MiniStat({ label, amount, color = "text-slate-700" }: { label: string; amount: number; color?: string }) {
  return (
    <div>
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className={`font-bold tabular-nums ${color}`}><Money amount={amount} short /></p>
    </div>
  );
}

function NewPeriodDialog({ open, onOpenChange, periods, onCreated }: {
  open: boolean; onOpenChange: (v: boolean) => void; periods: PeriodRow[]; onCreated: (id: string) => void;
}) {
  const { toast } = useToast();
  const [year, setYear] = useState("1405");
  const [month, setMonth] = useState(String(Math.max(...periods.map((p) => p.month), 0) + 1 || 8));
  const [creating, setCreating] = useState(false);

  async function create() {
    setCreating(true);
    try {
      const res = await api<{ period: PeriodRow }>("/api/payroll/periods", { method: "POST", json: { year: +year, month: +month } });
      onOpenChange(false);
      toast({ title: "دوره ایجاد و محاسبه شد", description: `${toFaDigits(res.period.payslipCount)} فیش حقوقی با پارامترهای ۱۴۰۵ محاسبه گردید.` });
      onCreated(res.period.id);
    } catch (e) {
      toast({ title: "خطا در ایجاد دوره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[33.6rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle>ایجاد دوره حقوق جدید</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground leading-5 bg-slate-50 rounded-lg p-3">
            لیست حقوق برای همه کارکنان فعالِ استخدام‌شده تا پایان ماه انتخابی، با مزایای قانونی ۱۴۰۵ (مسکن، بن، اولاد، سنوات، جذب، اضافه‌کاری)، بیمه ۷٪/۲۳٪ و مالیات پلکانی محاسبه می‌شود.
          </p>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs text-slate-600">سال</label>
              <Select value={year} onValueChange={setYear}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1405">۱۴۰۵</SelectItem>
                  <SelectItem value="1406">۱۴۰۶</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <label className="text-xs text-slate-600">ماه</label>
              <Select value={month} onValueChange={setMonth}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {JALALI_MONTHS.map((m, i) => {
                    const exists = periods.some((p) => p.year === +year && p.month === i + 1);
                    return <SelectItem key={m} value={String(i + 1)} disabled={exists}>{toFaDigits(String(i + 1).padStart(2, "0"))}{exists ? " (موجود)" : ""}</SelectItem>;
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={create} disabled={creating} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            {creating ? "در حال محاسبه..." : "ایجاد و محاسبه"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= جزئیات دوره =================
function PeriodDetail({ id, onBack, onChanged }: { id: string; onBack: () => void; onChanged: () => void }) {
  const detail = useApi<{
    period: PeriodRow;
    payslips: (PayslipData & { employee: { fullName: string; personnelCode: string; departments?: { id: string; name: string; allocationPercent: number }[] } | null })[];
    legal: { employeeSsoRate: number; employerSsoRate: number; unemploymentRate: number };
  }>(`/api/payroll/periods/${id}`);
  const company = useApi<{ name: string; nationalId: string; ssoCode: string; taxId: string; address: string }>("/api/settings");
  const [printSlip, setPrintSlip] = useState<PayslipData | null>(null);
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);

  if (detail.loading) return <div className="space-y-3"><Skeleton className="h-28 rounded-2xl" /><Skeleton className="h-96 rounded-2xl" /></div>;
  if (detail.error || !detail.data) return <div className="rounded-xl bg-rose-50 border border-rose-200 text-rose-700 p-4 text-sm">{detail.error}</div>;
  const { period, payslips } = detail.data;
  const st = STATUS_BADGE[period.status];

  async function setStatus(status: string) {
    setBusy(true);
    try {
      await api(`/api/payroll/periods/${id}`, { method: "PATCH", json: { status } });
      await detail.refetch();
      onChanged();
      toast({ title: status === "APPROVED" ? "دوره تأیید شد" : "دوره پرداخت‌شده علامت‌گذاری شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  async function removePeriod() {
    setBusy(true);
    try {
      await api(`/api/payroll/periods?id=${id}`, { method: "DELETE" });
      onBack();
      onChanged();
      toast({ title: "دوره حذف شد" });
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  // سهم هر واحد سازمانی از هزینه‌های دوره — بر مبنای درصد تخصیص هر کارمند
  // (محاسبه سبک در هر رندر — بدون hook تا بعد از return زودهنگام قرار نگیرد)
  const deptShares = (() => {
    const agg: Record<string, { name: string; employees: Set<string>; gross: number; employeeSso: number; employerSso: number; incomeTax: number; netPay: number; totalCost: number; share: number }> = {};
    let totalCostAll = 0;
    for (const p of payslips) {
      const depts = (p.employee?.departments || []).length
        ? (p.employee?.departments || [])
        : [{ id: "none", name: "بدون واحد سازمانی", allocationPercent: 100 }];
      const empCost = p.gross + p.employerSso20 + p.unemploymentSso3;
      totalCostAll += empCost;
      for (const d of depts) {
        if (!agg[d.id]) agg[d.id] = { name: d.name, employees: new Set(), gross: 0, employeeSso: 0, employerSso: 0, incomeTax: 0, netPay: 0, totalCost: 0, share: 0 };
        const a = agg[d.id];
        const w = (d.allocationPercent || 100) / 100;
        a.employees.add(p.employeeId);
        a.gross += p.gross * w;
        a.employeeSso += p.employeeSso * w;
        a.employerSso += (p.employerSso20 + p.unemploymentSso3) * w;
        a.incomeTax += p.incomeTax * w;
        a.netPay += p.netPay * w;
        a.totalCost += empCost * w;
      }
    }
    const rows = Object.values(agg).map((a) => ({
      ...a,
      employeeCount: a.employees.size,
      share: totalCostAll > 0 ? (a.totalCost / totalCostAll) * 100 : 0,
    }));
    rows.sort((x, y) => y.totalCost - x.totalCost);
    return { rows, totalCostAll };
  })();

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-teal-700 hover:text-teal-900 font-medium">
          <ArrowRight className="w-4 h-4" /> بازگشت به دوره‌ها
        </button>
        <div className="mr-auto flex gap-2 flex-wrap">
          {period.status === "CALCULATED" && (
            <Button size="sm" variant="outline" className="gap-1.5 bg-teal-50 border-teal-200 text-teal-700 hover:bg-teal-100" disabled={busy} onClick={() => setStatus("APPROVED")}>
              <CheckCircle2 className="w-4 h-4" /> تأیید دوره
            </Button>
          )}
          {period.status === "APPROVED" && (
            <Button size="sm" className="gap-1.5 bg-emerald-600 hover:bg-emerald-700" disabled={busy} onClick={() => setStatus("PAID")}>
              <Banknote className="w-4 h-4" /> علامت‌گذاری به‌عنوان پرداخت‌شده
            </Button>
          )}
          {period.status !== "PAID" && (
            <Button size="sm" variant="destructive" className="gap-1.5" disabled={busy} onClick={removePeriod}>
              <Trash2 className="w-4 h-4" /> حذف دوره
            </Button>
          )}
        </div>
      </div>

      {/* خلاصه دوره */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Wallet className="w-4 h-4 text-teal-600" />
            {periodTitle(period.year, period.month)}
            <Badge className={st.cls}>{st.label}</Badge>
            <span className="text-xs text-muted-foreground font-normal">— {toFaDigits(period.payslipCount)} فیش</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3">
            <TotalBox label="جمع حقوق و مزایا" amount={period.totals.gross} />
            <TotalBox label="بیمه سهم کارگر (۷٪)" amount={period.totals.employeeSso} color="text-amber-700" />
            <TotalBox label="بیمه کارفرما (۲۰٪)" amount={period.totals.employerSso20} color="text-amber-700" />
            <TotalBox label="بیمه بیکاری (۳٪)" amount={period.totals.unemploymentSso3} color="text-amber-700" />
            <TotalBox label="مالیات حقوق" amount={period.totals.incomeTax} color="text-rose-700" />
            <TotalBox label="خالص پرداختی" amount={period.totals.netPay} color="text-emerald-700" bg="bg-emerald-50" />
          </div>
          <div className="flex items-center gap-2 mt-4 pt-4 border-t flex-wrap">
            <span className="text-xs text-muted-foreground">خروجی‌های قانونی این دوره:</span>
            <a href={`/api/reports/sso?periodId=${id}`} className="text-xs font-medium text-teal-700 hover:text-teal-900 flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-teal-50">
              <FileDown className="w-3.5 h-3.5" /> دیسکت بیمه
            </a>
            <a href={`/api/reports/tax?periodId=${id}`} className="text-xs font-medium text-teal-700 hover:text-teal-900 flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-teal-50">
              <FileDown className="w-3.5 h-3.5" /> فایل مالیاتی
            </a>
            {["pasargad", "saman", "mellat", "tejarat"].map((b) => (
              <a key={b} href={`/api/reports/bank/${b}?periodId=${id}`} className="text-xs font-medium text-teal-700 hover:text-teal-900 flex items-center gap-1 px-2.5 py-1.5 rounded-lg hover:bg-teal-50">
                <FileDown className="w-3.5 h-3.5" /> {b === "pasargad" ? "پارسیان" : b === "saman" ? "سامان" : b === "mellat" ? "ملت" : "تجارت"}
              </a>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* جدول فیش‌ها */}
      <Card className="rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50/80">
                  <TableHead className="text-right">کارمند</TableHead>
                  <TableHead className="text-right">واحد سازمانی</TableHead>
                  <TableHead className="text-left">حقوق پایه</TableHead>
                  <TableHead className="text-left">جمع مزایا</TableHead>
                  <TableHead className="text-left">ناخالص</TableHead>
                  <TableHead className="text-left">بیمه ۷٪</TableHead>
                  <TableHead className="text-left">مالیات</TableHead>
                  <TableHead className="text-left">خالص</TableHead>
                  <TableHead className="text-center">فیش</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payslips.map((p) => {
                  const benefits = p.gross - p.baseSalary;
                  const depts = p.employee?.departments || [];
                  return (
                    <TableRow key={p.id} className="hover:bg-teal-50/40">
                      <TableCell className="font-medium">
                        {p.employee?.fullName}
                        {p.isReverse && <Badge className="mr-2 bg-amber-100 text-amber-700 hover:bg-amber-100">معکوس</Badge>}
                        <span className="block text-[11px] text-muted-foreground tabular-nums" dir="ltr">{p.employee?.personnelCode}</span>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {depts.length === 0 && <span>—</span>}
                        {depts.map((d, i) => (
                          <span key={d.id} className="block">
                            {d.name}
                            {depts.length > 1 && <span className="text-[10px] text-teal-700"> ({toFaDigits(Math.round(d.allocationPercent || 100))}٪)</span>}
                            {i === depts.length - 1 ? "" : ""}
                          </span>
                        ))}
                      </TableCell>
                      <TableCell className="text-left tabular-nums text-sm"><Money amount={p.baseSalary} short /></TableCell>
                      <TableCell className="text-left tabular-nums text-sm"><Money amount={benefits} short /></TableCell>
                      <TableCell className="text-left tabular-nums text-sm font-medium"><Money amount={p.gross} short /></TableCell>
                      <TableCell className="text-left tabular-nums text-sm text-amber-700"><Money amount={p.employeeSso} short /></TableCell>
                      <TableCell className="text-left tabular-nums text-sm text-rose-700"><Money amount={p.incomeTax} short /></TableCell>
                      <TableCell className="text-left tabular-nums text-sm font-bold text-emerald-700"><Money amount={p.netPay} short /></TableCell>
                      <TableCell className="text-center">
                        <button className="p-1.5 rounded-lg hover:bg-teal-100 text-teal-600" title="مشاهده فیش" onClick={() => setPrintSlip(p)}>
                          <Eye className="w-4 h-4" />
                        </button>
                      </TableCell>
                    </TableRow>
                  );
                })}
                <TableRow className="bg-slate-100 font-bold">
                  <TableCell>جمع کل ({toFaDigits(payslips.length)} فیش)</TableCell>
                  <TableCell />
                  <TableCell className="text-left tabular-nums"><Money amount={payslips.reduce((a, p) => a + p.baseSalary, 0)} short /></TableCell>
                  <TableCell className="text-left tabular-nums"><Money amount={payslips.reduce((a, p) => a + (p.gross - p.baseSalary), 0)} short /></TableCell>
                  <TableCell className="text-left tabular-nums"><Money amount={period.totals.gross} short /></TableCell>
                  <TableCell className="text-left tabular-nums text-amber-700"><Money amount={period.totals.employeeSso} short /></TableCell>
                  <TableCell className="text-left tabular-nums text-rose-700"><Money amount={period.totals.incomeTax} short /></TableCell>
                  <TableCell className="text-left tabular-nums text-emerald-700"><Money amount={period.totals.netPay} short /></TableCell>
                  <TableCell />
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* سهم هر واحد سازمانی از هزینه‌های دوره */}
      <Card className="rounded-2xl overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Building2 className="w-4 h-4 text-teal-600" />
            سهم واحدهای سازمانی از هزینه‌های دوره
            <Badge variant="outline">سهم بر مبنای درصد تخصیص</Badge>
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1">هزینه کل هر واحد = ناخالص + بیمه سهم کارفرما (۲۰٪ + ۳٪) — به نسبت درصد تخصیص هر کارمند به واحد</p>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50/80">
                  <TableHead className="text-right">واحد سازمانی</TableHead>
                  <TableHead className="text-center">افراد</TableHead>
                  <TableHead className="text-center">سهم از کل</TableHead>
                  <TableHead className="text-left">ناخالص</TableHead>
                  <TableHead className="text-left">بیمه کارگر</TableHead>
                  <TableHead className="text-left">بیمه کارفرما</TableHead>
                  <TableHead className="text-left">مالیات</TableHead>
                  <TableHead className="text-left">خالص</TableHead>
                  <TableHead className="text-left">هزینه کل</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {deptShares.rows.map((d) => (
                  <TableRow key={d.name} className="hover:bg-teal-50/40">
                    <TableCell className="font-medium text-sm">{d.name}</TableCell>
                    <TableCell className="text-center text-sm tabular-nums">{toFaDigits(d.employeeCount)}</TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center gap-2 justify-center">
                        <div className="w-16 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                          <div className="h-full bg-teal-500 rounded-full" style={{ width: `${Math.min(100, d.share)}%` }} />
                        </div>
                        <span className="text-xs tabular-nums font-medium text-teal-700">{toFaDigits(d.share.toFixed(1))}٪</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-left tabular-nums text-sm"><Money amount={Math.round(d.gross)} short /></TableCell>
                    <TableCell className="text-left tabular-nums text-sm text-amber-700"><Money amount={Math.round(d.employeeSso)} short /></TableCell>
                    <TableCell className="text-left tabular-nums text-sm text-amber-700"><Money amount={Math.round(d.employerSso)} short /></TableCell>
                    <TableCell className="text-left tabular-nums text-sm text-rose-700"><Money amount={Math.round(d.incomeTax)} short /></TableCell>
                    <TableCell className="text-left tabular-nums text-sm text-emerald-700"><Money amount={Math.round(d.netPay)} short /></TableCell>
                    <TableCell className="text-left tabular-nums text-sm font-bold"><Money amount={Math.round(d.totalCost)} short /></TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-slate-100 font-bold">
                  <TableCell>جمع کل</TableCell>
                  <TableCell className="text-center tabular-nums">{toFaDigits(payslips.length)}</TableCell>
                  <TableCell className="text-center text-xs">۱۰۰٪</TableCell>
                  <TableCell className="text-left tabular-nums"><Money amount={period.totals.gross} short /></TableCell>
                  <TableCell className="text-left tabular-nums text-amber-700"><Money amount={period.totals.employeeSso} short /></TableCell>
                  <TableCell className="text-left tabular-nums text-amber-700"><Money amount={period.totals.employerSso20 + period.totals.unemploymentSso3} short /></TableCell>
                  <TableCell className="text-left tabular-nums text-rose-700"><Money amount={period.totals.incomeTax} short /></TableCell>
                  <TableCell className="text-left tabular-nums text-emerald-700"><Money amount={period.totals.netPay} short /></TableCell>
                  <TableCell className="text-left tabular-nums"><Money amount={Math.round(deptShares.totalCostAll)} short /></TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <PayslipPrintDialog
        open={!!printSlip}
        onOpenChange={(v) => !v && setPrintSlip(null)}
        payslip={printSlip}
        company={company.data || { name: "", nationalId: "", ssoCode: "", taxId: "", address: "" }}
      />
    </div>
  );
}

function TotalBox({ label, amount, color = "text-slate-800", bg = "bg-slate-50" }: { label: string; amount: number; color?: string; bg?: string }) {
  return (
    <div className={`rounded-xl ${bg} border border-slate-200/70 p-3`}>
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className={`text-sm font-bold mt-1 tabular-nums ${color}`}><Money amount={amount} short /></p>
    </div>
  );
}

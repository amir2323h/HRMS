"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Users, Wallet, Landmark, Receipt, TrendingUp, AlertTriangle, ArrowLeft } from "lucide-react";
import { useApi } from "@/lib/client";
import { fmtMoneyShort, groupFa } from "@/lib/format";
import { toFaDigits } from "@/lib/jalali";
import { TrendChart, BarList, ColumnChart } from "../charts";
import type { SessionInfo } from "../app-root";

interface DashboardData {
  kpis: {
    activeEmployees: number;
    periodCount: number;
    latest: {
      gross: number; netPay: number; employeeSso: number; employerSso: number;
      incomeTax: number; totalCost: number; label: string; periodId: string; count: number;
    } | null;
  };
  trend: { label: string; gross: number; netPay: number; totalCost: number; employeeSso: number; employerSso: number; incomeTax: number; count: number }[];
  deptCosts: { name: string; totalCost: number; headcount: number }[];
  gradeDistribution: { level: number; title: string; count: number }[];
}

export function DashboardView({ user, onNavigate }: { user: SessionInfo; onNavigate: (v: string, p?: string) => void }) {
  const { data, loading, error } = useApi<DashboardData>("/api/dashboard");
  const alerts = useApi<{ alerts: { id: string; title: string; message: string; severity: string; employeeName: string; daysLeft?: number }[]; counts: { high: number; medium: number; low: number } }>("/api/alerts");

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}
        </div>
        <Skeleton className="h-72 rounded-2xl" />
      </div>
    );
  }
  if (error || !data) return <div className="rounded-xl bg-rose-50 border border-rose-200 text-rose-700 p-4 text-sm">{error || "خطا در دریافت داده"}</div>;

  const latest = data.kpis.latest;
  const kpis = [
    {
      title: "کارکنان فعال",
      value: `${groupFa(data.kpis.activeEmployees)} نفر`,
      icon: Users,
      color: "text-teal-600 bg-teal-50",
      sub: `${toFaDigits(data.kpis.periodCount)} دوره حقوق ثبت‌شده`,
    },
    {
      title: latest ? `جمع خالص پرداختی — ${latest.label}` : "جمع خالص پرداختی",
      value: latest ? fmtMoneyShort(latest.netPay) : "—",
      icon: Wallet,
      color: "text-emerald-600 bg-emerald-50",
      sub: latest ? `${groupFa(latest.count)} فیش حقوقی` : "",
    },
    {
      title: latest ? `سهم بیمه کارفرما — ${latest.label}` : "سهم بیمه کارفرما",
      value: latest ? fmtMoneyShort(latest.employerSso) : "—",
      icon: Landmark,
      color: "text-amber-600 bg-amber-50",
      sub: "۲۳٪ مشمول بیمه (۲۰٪ + ۳٪ بیکاری)",
    },
    {
      title: latest ? `مالیات پرداختی — ${latest.label}` : "مالیات پرداختی",
      value: latest ? fmtMoneyShort(latest.incomeTax) : "—",
      icon: Receipt,
      color: "text-rose-600 bg-rose-50",
      sub: "پلکانی ۶ گانه ماده ۸۵ بودجه ۱۴۰۵",
    },
  ];

  return (
    <div className="space-y-6">
      {/* KPIها */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {kpis.map((k) => {
          const Icon = k.icon;
          return (
            <Card key={k.title} className="rounded-2xl border-slate-200/80 hover:shadow-md transition-shadow">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="text-xs text-muted-foreground mb-1.5 truncate">{k.title}</p>
                    <p className="text-xl font-bold text-slate-800 tabular-nums leading-7">{k.value}</p>
                    {k.sub && <p className="text-[11px] text-muted-foreground mt-1.5 truncate">{k.sub}</p>}
                  </div>
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${k.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* نمودارها */}
      <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
        <Card className="xl:col-span-3 rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-teal-600" />
              روند هزینه کل نیروی کار (فروردین تا مهر ۱۴۰۵)
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">ناخالص حقوق + ۲۳٪ سهم بیمه کارفرما — ماهانه</p>
          </CardHeader>
          <CardContent>
            <TrendChart data={data.trend.map((t) => ({ label: t.label.split(" ")[0], value: t.totalCost }))} formatter={(v) => fmtMoneyShort(v)} />
          </CardContent>
        </Card>

        <Card className="xl:col-span-2 rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Wallet className="w-4 h-4 text-teal-600" />
              هزینه دپارتمان‌ها — {latest?.label || ""}
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">کل هزینه نیروی کار به تفکیک واحد سازمانی</p>
          </CardHeader>
          <CardContent>
            <BarList
              data={data.deptCosts.slice(0, 7).map((d) => ({ label: d.name, value: d.totalCost, sub: `${groupFa(d.headcount)} نفر` }))}
            />
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-5 gap-4">
        {/* توزیع طبقات */}
        <Card className="xl:col-span-2 rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Users className="w-4 h-4 text-teal-600" />
              توزیع کارکنان در طبقات ۷ گانه
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ColumnChart
              data={data.gradeDistribution.map((g) => ({ label: `سطح ${toFaDigits(g.level)}`, value: g.count }))}
              height={190}
            />
          </CardContent>
        </Card>

        {/* هشدارها */}
        <Card className="xl:col-span-3 rounded-2xl">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              هشدارهای منابع انسانی
              <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100 mr-auto">{toFaDigits(alerts.data?.counts.high || 0)} فوری</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="max-h-72 overflow-y-auto -mx-2">
            {alerts.loading && <div className="space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-14 rounded-xl mx-2" />)}</div>}
            {!alerts.loading && (alerts.data?.alerts || []).length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-8">هیچ هشداری وجود ندارد ✓</p>
            )}
            {(alerts.data?.alerts || []).slice(0, 8).map((a) => (
              <div key={a.id} className="flex items-center gap-3 mx-2 mb-2 rounded-xl border border-slate-200/80 px-3.5 py-2.5 hover:border-teal-300 hover:bg-teal-50/40 transition-colors">
                <span className={`w-2 h-2 rounded-full shrink-0 ${a.severity === "high" ? "bg-rose-500" : a.severity === "medium" ? "bg-amber-500" : "bg-slate-300"}`} />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-bold text-slate-800">
                    {a.title}
                    {a.daysLeft !== undefined && a.daysLeft !== null && (
                      <span className="text-[10px] font-normal text-amber-700 mr-1.5">({toFaDigits(a.daysLeft)} روز مانده)</span>
                    )}
                  </p>
                  <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{a.message}</p>
                </div>
                {(user.role === "HR_MANAGER" || user.role === "SUPER_ADMIN") && (
                  <button className="text-teal-600 hover:text-teal-800 shrink-0" onClick={() => onNavigate("employees")} title="مدیریت کارکنان">
                    <ArrowLeft className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* دسترسی سریع */}
      {(user.role === "SUPER_ADMIN" || user.role === "PAYROLL_OFFICER") && (
        <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
          <CardContent className="p-5 flex flex-wrap items-center gap-3">
            <div className="flex-1 min-w-[200px]">
              <p className="font-bold text-slate-800">محاسبه معکوس حقوق ۱۴۰۵</p>
              <p className="text-sm text-muted-foreground mt-1">مبلغ خالص موردنظر را وارد کنید؛ سامانه حقوق پایه، بیمه و مالیات را به‌صورت معکوس و دقیق محاسبه می‌کند.</p>
            </div>
            <button
              onClick={() => onNavigate("reverse")}
              className="rounded-xl bg-teal-600 hover:bg-teal-700 text-white px-5 py-2.5 text-sm font-semibold transition-colors shadow-lg shadow-teal-600/25"
            >
              شروع محاسبه معکوس ←
            </button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

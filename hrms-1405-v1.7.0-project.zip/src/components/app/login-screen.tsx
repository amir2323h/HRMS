"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { api, setAuthToken, notifyAuthChanged, useApi } from "@/lib/client";
import { useBranding } from "./use-branding";

const DEMO_USERS = [
  { username: "admin", password: "admin123", label: "مدیر کل سیستم", color: "bg-rose-500" },
  { username: "hr", password: "hr123", label: "مدیر منابع انسانی", color: "bg-teal-600" },
  { username: "payroll", password: "pay123", label: "کارشناس حقوق", color: "bg-amber-500" },
  { username: "dept", password: "dept123", label: "مدیر دپارتمان", color: "bg-emerald-600" },
  { username: "emp", password: "emp123", label: "کارمند (پرتال)", color: "bg-slate-500" },
];

export function LoginScreen() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  // برندینگ پویا (عنوان/لوگو از تنظیمات — با کش آنی بدون فلش)
  const { brand } = useBranding();
  // دکمه ورود Mattermost (OAuth 2.0)
  const mm = useApi<{ enabled: boolean; buttonLabel: string }>("/api/auth/mattermost/config");
  const mmEnabled = !!mm.data?.enabled;

  // خطای بازگشتی از callback ماترموست (localStorage — توسط صفحه callback ست می‌شود)
  // خواندن در اولین رندر (اینیشیالایزر lazy) — نه در effect
  const [error, setError] = useState<string | null>(() => {
    try {
      if (typeof window === "undefined") return null;
      const mmErr = window.localStorage.getItem("hrms_mm_error");
      if (mmErr) {
        window.localStorage.removeItem("hrms_mm_error");
        return `ورود با Mattermost ناموفق بود: ${mmErr}`;
      }
    } catch { /* private browsing */ }
    return null;
  });

  async function startMattermostLogin() {
    setError(null);
    try {
      const d = await api<{ url: string }>("/api/auth/mattermost/url");
      if (d?.url) window.location.href = d.url;
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در شروع ورود Mattermost");
    }
  }

  async function doLogin(u: string, p: string) {
    setLoading(true);
    setError(null);
    try {
      const d = await api<{ user: unknown; token?: string }>("/api/auth/login", {
        method: "POST",
        json: { username: u, password: p },
      });
      // ذخیره توکن برای حالت iframe (کوکی مسدود) — در حالت عادی کوکی هم ست می‌شود
      if (d && typeof d.token === "string" && d.token) {
        setAuthToken(d.token);
      }
      notifyAuthChanged("login"); // AuthGate نشست را دوباره بررسی و داشبورد را نمایش می‌دهد
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ورود");
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-950 via-slate-900 to-teal-900 p-4">
      <div className="w-full max-w-md">
        {/* لوگو */}
        <div className="flex flex-col items-center mb-8">
          {brand?.logo ? (
             
            <img src={brand.logo} alt="لوگو" className="w-20 h-20 rounded-2xl object-contain bg-white/10 p-2 backdrop-blur border border-white/20 shadow-2xl mb-4" />
          ) : (
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-2xl shadow-teal-500/30 mb-4">
              <svg viewBox="0 0 24 24" className="w-11 h-11 text-white" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M12 2L20 6v5c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V6l8-4z" strokeLinejoin="round" />
                <path d="M12 8v4l3 2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          )}
          <h1 className="text-2xl font-bold text-white text-center">{brand?.title || "سامانه جامع منابع انسانی"}</h1>
        </div>

        <Card className="border-white/10 bg-white/95 backdrop-blur shadow-2xl">
          <CardContent className="p-6 space-y-5">
            {error && (
              <div className="rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-sm px-4 py-3" role="alert">
                {error}
              </div>
            )}
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                doLogin(username, password);
              }}
            >
              <div className="space-y-2">
                <Label htmlFor="username">نام کاربری</Label>
                <Input
                  id="username"
                  dir="ltr"
                  className="text-left font-medium"
                  placeholder="admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">رمز عبور</Label>
                <Input
                  id="password"
                  type="password"
                  dir="ltr"
                  className="text-left font-medium"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                />
              </div>
              <Button type="submit" className="w-full h-11 text-base font-semibold" disabled={loading}>
                {loading ? "در حال ورود..." : "ورود به سامانه"}
              </Button>
            </form>

            {/* ورود یکپارانه Mattermost */}
            {mmEnabled && (
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                  <span className="flex-1 border-t" />
                  یا
                  <span className="flex-1 border-t" />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  className="w-full h-11 text-sm font-semibold gap-2 border-indigo-300 text-indigo-800 hover:bg-indigo-50"
                  onClick={startMattermostLogin}
                >
                  <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                    <path d="M5.6 9.6 12 4l6.4 5.6v6.1c0 .8-.6 1.4-1.4 1.4H15l-3-2.4-3 2.4H7c-.8 0-1.4-.6-1.4-1.4V9.6Z" opacity="0" />
                    <path d="M12 3.2 3.8 9.9v6.4c0 1.1.9 2 2 2h3.4l2.8-2.3 2.8 2.3h3.4c1.1 0 2-.9 2-2V9.9L12 3.2Zm0 2.5 6.2 5.1v5.5c0 .3-.2.5-.5.5h-2.6L12 14.7l-3.1 2.1H6.3c-.3 0-.5-.2-.5-.5v-5.5L12 5.7Z" />
                  </svg>
                  {mm.data?.buttonLabel || "ورود با Mattermost"}
                </Button>
              </div>
            )}

            {/* حساب‌های نمونه — فقط وقتی «حالت دمو» در تنظیمات فعال باشد */}
            {brand?.demoMode === true && (
              <div className="border-t border-slate-200 pt-4">
                <p className="text-xs text-muted-foreground mb-3 text-center">کاربران نمونه (برای ورود سریع کلیک کنید):</p>
                <div className="grid grid-cols-1 gap-2">
                  {DEMO_USERS.map((u) => (
                    <button
                      key={u.username}
                      type="button"
                      disabled={loading}
                      onClick={() => {
                        setUsername(u.username);
                        setPassword(u.password);
                        doLogin(u.username, u.password);
                      }}
                      className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 hover:border-teal-300 transition-all px-3 py-2 text-sm text-right disabled:opacity-50"
                    >
                      <span className={`w-2.5 h-2.5 rounded-full ${u.color} shrink-0`} />
                      <span className="font-medium text-slate-700">{u.label}</span>
                      <span dir="ltr" className="mr-auto text-xs text-muted-foreground font-mono">
                        {u.username} / {u.password}
                      </span>
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground mt-3 text-center">حالت دمو فعال است — از «تنظیمات ← برندینگ» قابل خاموش‌کردن است.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

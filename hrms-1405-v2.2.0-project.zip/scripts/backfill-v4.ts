// ============================================================
// بک‌فیل نسخه ۴ (تسک ۶) — نقش‌های سیستمی + اتصال کاربران
// + آیتم‌های رفاهی + قالب نامه‌ها + مدیر واحد دپارتمان‌ها
// + مهاجرت وضعیت درخواست‌ها (PENDING → PENDING_DM)
// + کارآموز نمونه (حذف‌شده در ۲.۱.۰) + تنظیمات Mattermost خاموش + قالب قرارداد کارآموزی
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  // ---------- ۱. نقش‌های سیستمی + اتصال به کاربران ----------
  const DEFAULT_ROLES: { key: string; name: string; description: string; permissions: string[] }[] = [
    { key: "SUPER_ADMIN", name: "مدیر کل سیستم", description: "دسترسی کامل به همه بخش‌های سامانه", permissions: ["*"] },
    {
      key: "HR_MANAGER", name: "مدیر منابع انسانی", description: "کارکنان، قراردادها، درخواست‌ها، نامه‌ها، تنظیمات",
      permissions: [
        "dashboard:view", "portal:view", "docs:view",
        "employees:view", "employees:edit",
        "departments:view", "departments:manage",
        "grades:view", "grades:manage",
        "contracts:view", "contracts:manage",
        "letters:create", "letters:approve", "letters:templates", "letters:manual",
        "salary:view", "salary:manage",
        "reports:view", "bonus:view", "bonus:manage",
        "requests:create", "requests:approve_hr", "requests:approve_dept",
        "audit:view", "settings:view", "settings:manage", "jobs:manage", "welfare:manage", "users:view",
      ],
    },
    {
      key: "PAYROLL_OFFICER", name: "کارشناس حقوق و دستمزد", description: "حقوق، محاسبه معکوس، گزارش‌ها، قراردادها",
      permissions: [
        "dashboard:view", "portal:view", "docs:view",
        "employees:view", "contracts:view", "contracts:manage",
        "payroll:view", "payroll:manage", "reverse:use", "reports:view",
        "salary:view", "salary:manage",
        "bonus:view", "bonus:manage", "audit:view", "settings:view",
      ],
    },
    { key: "DEPT_MANAGER", name: "مدیر دپارتمان", description: "مشاهده کارکنان واحد + تأیید مرحله اول درخواست‌ها",
      permissions: [
        "dashboard:view", "portal:view", "docs:view",
        "employees:view", "departments:view", "reports:view",
        "requests:create", "requests:approve_dept", "letters:create",
      ],
    },
    {
      key: "ADMIN_EXPERT", name: "کارشناس اداری", description: "صدور نامه‌های اداری، ثبت نامه دستی و صدور نسخه رسمی",
      permissions: [
        "portal:view", "docs:view",
        "employees:view",
        "letters:create", "letters:approve", "letters:manual",
      ],
    },
    { key: "EMPLOYEE", name: "کارمند", description: "پرتال خودخدماتی، درخواست‌ها و درخواست‌نامه", permissions: ["portal:view", "docs:view", "requests:create", "letters:create"] },
  ];
  for (const r of DEFAULT_ROLES) {
    await db.role.upsert({
      where: { key: r.key },
      update: { name: r.name, description: r.description, permissions: JSON.stringify(r.permissions), isSystem: true },
      create: { key: r.key, name: r.name, description: r.description, permissions: JSON.stringify(r.permissions), isSystem: true },
    });
  }
  // اتصال همه کاربران به نقش متناظر
  const users = await db.user.findMany();
  for (const u of users) {
    const role = await db.role.findUnique({ where: { key: u.role } });
    if (role && u.roleId !== role.id) {
      await db.user.update({ where: { id: u.id }, data: { roleId: role.id } });
    }
  }
  console.log(`نقش‌ها: ${DEFAULT_ROLES.length} — کاربران متصل: ${users.length}`);

  // ---------- ۲. آیتم‌های رفاهی ----------
  const WELFARE = [
    { title: "زودکس پی (خرید سهام)", description: "طرح مشارکت کارکنان در سهام شرکت" },
    { title: "غذای سازمانی", description: "وعده ناهار در محل کار" },
    { title: "بیمه تکمیلی درمان", description: "پوشش تکمیلی خانواده" },
    { title: "سرویس رفت‌وآمد", description: "سرویس ایاب و ذهاب" },
    { title: "عضویت باشگاه ورزشی", description: "باشگاه شرکتی" },
    { title: "وام مسکن کارکنان", description: "وام قرض‌الحسنه مسکن" },
    { title: "دوره‌های آموزشی", description: "توسعه مهارت حرفه‌ای" },
    { title: "بسته رفاهی مناسبت", description: "پک مناسبتی (نوروز و ...)" },
  ];
  let welfareCount = 0;
  for (let i = 0; i < WELFARE.length; i++) {
    const code = `WEL-${String(i + 1).padStart(3, "0")}`;
    await db.welfareItem.upsert({
      where: { code },
      update: { title: WELFARE[i].title, description: WELFARE[i].description },
      create: { code, title: WELFARE[i].title, description: WELFARE[i].description, isActive: true },
    });
    welfareCount++;
  }
  // رفاهیات نمونه برای کارکنان فعال (برای نمایش)
  const items = await db.welfareItem.findMany({ where: { isActive: true } });
  const emps = await db.employee.findMany({ where: { status: "ACTIVE" }, select: { id: true } });
  let assigned = 0;
  for (let i = 0; i < emps.length; i++) {
    // هر کارمند ۲ تا ۴ رفاهیت نمونه
    const picks = [items[i % items.length], items[(i + 3) % items.length], items[(i + 5) % items.length]];
    for (const it of picks) {
      const exists = await db.employeeWelfare.findFirst({ where: { employeeId: emps[i].id, welfareItemId: it.id } });
      if (!exists) {
        await db.employeeWelfare.create({ data: { employeeId: emps[i].id, welfareItemId: it.id } });
        assigned++;
      }
    }
  }
  console.log(`رفاهیات: ${welfareCount} آیتم — ${assigned} انتساب`);

  // ---------- ۳. قالب نامه‌ها ----------
  const LETTER_TEMPLATES = [
    {
      code: "LT-001", title: "درخواست تمدید قرارداد", category: "HR", approverRole: "HR_MANAGER",
      description: "نامه رسمی درخواست تمدید قرارداد همکاری",
      fields: [
        { key: "current_end_date", label: "تاریخ پایان قرارداد فعلی", type: "date", required: true },
        { key: "requested_period", label: "مدت تمدید درخواستی", type: "select", options: ["یک سال", "دو سال", "سه سال", "نامحدود"], required: true },
        { key: "reason", label: "دلیل درخواست", type: "textarea", required: true },
      ],
      bodyTemplate: `خدمات {{approver_title}} محترم شرکت {{company_name}},

با احترام، اینجانب {{employee_name}} (کد پرسنلی {{employee_personnel_code}})، همکار در سمت «{{employee_job_title}}»، به موجب این نامه درخواست تمدید قرارداد همکاری خودم را پس از تاریخ {{field_current_end_date}} برای مدت {{field_requested_period}} دارم.

شرح دلیل:
{{field_reason}}

خواهشمند است دستور فرمایید نسبت به بررسی و تأیید این درخواست اقدام فرمایید.

با تشکر — {{employee_name}}
شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`,
    },
    {
      code: "LT-002", title: "درخواست وام و مساعده", category: "FINANCE", approverRole: "HR_MANAGER",
      description: "درخواست رسمی وام/مساعده از صندوق قرض‌الحسنه شرکت",
      fields: [
        { key: "amount", label: "مبلغ درخواستی (تومان)", type: "number", required: true },
        { key: "installments", label: "تعداد اقساط", type: "select", options: ["۶", "۱۲", "۱۸", "۲۴"], required: true },
        { key: "purpose", label: "هدف استفاده", type: "textarea", required: true },
      ],
      bodyTemplate: `مدیریت محترم سرمایه انسانی و امور مالی شرکت {{company_name}},

اینجانب {{employee_name}} با کد پرسنلی {{employee_personnel_code}} و سابقه خدمت از {{employee_hire_date}}، درخواست وام/مساعده به مبلغ {{field_amount}} تومان در {{field_installments}} قسط را دارم.

هدف از استفاده:
{{field_purpose}}

متعهدم اقساط ماهانه از حقوقم کسر شود.

با تشکر — {{employee_name}}
شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`,
    },
    {
      code: "LT-003", title: "درخواست گواهی سابقه کار", category: "ADMIN", approverRole: "HR_MANAGER",
      description: "گواهی سوابق کاری برای ارائه به مراجع",
      fields: [
        { key: "purpose", label: "مرجع ارائه گواهی", type: "text", required: true },
        { key: "copies", label: "تعداد نسخه", type: "select", options: ["۱", "۲", "۳"], required: false },
      ],
      bodyTemplate: `خدمات واحد اداری شرکت {{company_name}},

اینجانب {{employee_name}} (کد پرسنلی {{employee_personnel_code}}) درخواست صدور گواهی سابقه کار جهت ارائه به {{field_purpose}} را دارم. تعداد نسخه: {{field_copies}}.

مشخصات خدمت:
- سمت: {{employee_job_title}}
- تاریخ استخدام: {{employee_hire_date}}

شماره نامه: {{letter_number}} — تاریخ: {{today_date}}
{{employee_name}}`,
    },
    {
      code: "LT-004", title: "درخواست تغییر ساعات کاری", category: "HR", approverRole: "HR_MANAGER",
      description: "درخواست تغییر ساعت ورود/خروج (کار انعطاف‌پذیر)",
      fields: [
        { key: "new_hours", label: "ساعات پیشنهادی (مثلاً ۸ تا ۱۷)", type: "text", required: true },
        { key: "start_date", label: "تاریخ شروع اعمال", type: "date", required: true },
        { key: "justification", label: "توضیحات", type: "textarea", required: false },
      ],
      bodyTemplate: `مدیر محترم واحد و منابع انسانی شرکت {{company_name}},

اینجانب {{employee_name}} در سمت {{employee_job_title}}، درخواست تغییر ساعات کاری به {{field_new_hours}} از تاریخ {{field_start_date}} را دارم.

توضیحات:
{{field_justification}}

خواهشمند است بررسی و اعلام نتیجه فرمایید.

شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`,
    },
  ];
  for (const t of LETTER_TEMPLATES) {
    await db.letterTemplate.upsert({
      where: { code: t.code },
      update: {
        title: t.title, category: t.category, description: t.description,
        fieldsJson: JSON.stringify(t.fields), bodyTemplate: t.bodyTemplate,
        approverRole: t.approverRole,
      },
      create: {
        code: t.code, title: t.title, category: t.category, description: t.description,
        fieldsJson: JSON.stringify(t.fields), bodyTemplate: t.bodyTemplate,
        approverRole: t.approverRole, isActive: true, createdBy: "system",
      },
    });
  }
  console.log(`قالب نامه‌ها: ${LETTER_TEMPLATES.length}`);

  // ---------- ۴. مدیر واحد برای دپارتمان‌ها ----------
  const departments = await db.department.findMany({ include: { employees: { include: { employee: { select: { id: true, jobGrade: { select: { level: true } } } } } } }, orderBy: { code: "asc" } });
  let managersSet = 0;
  for (const d of departments) {
    if (d.managerEmployeeId) continue;
    // مدیر: ارشد‌ترین فرد همان دپارتمان (بالاترین طبقه)
    const members = d.employees.map((l) => l.employee).filter(Boolean);
    if (members.length === 0) continue;
    const sorted = members.sort((a: { jobGrade?: { level: number } | null }, b: { jobGrade?: { level: number } | null }) => (b.jobGrade?.level || 0) - (a.jobGrade?.level || 0));
    await db.department.update({ where: { id: d.id }, data: { managerEmployeeId: sorted[0].id } });
    managersSet++;
  }
  console.log(`مدیر واحد: ${managersSet} دپارتمان از ${departments.length}`);

  // ---------- ۵. مهاجرت وضعیت درخواست‌ها ----------
  const oldLeaves = await db.leaveRequest.count({ where: { status: "PENDING" } });
  if (oldLeaves > 0) {
    await db.leaveRequest.updateMany({ where: { status: "PENDING" }, data: { status: "PENDING_DM" } });
  }
  const oldAdvs = await db.advanceRequest.count({ where: { status: "PENDING" } });
  if (oldAdvs > 0) {
    await db.advanceRequest.updateMany({ where: { status: "PENDING" }, data: { status: "PENDING_DM" } });
  }
  console.log(`مهاجرت درخواست‌ها: ${oldLeaves} مرخصی + ${oldAdvs} مساعده`);

  // ---------- ۶. (حذف‌شده در ۲.۱.۰) ----------
  // پیش‌تر این بخش یک «کارآموز نمونه» می‌ساخت —
  // از نسخه ۲.۱.۰ هیچ داده پرسنلی نمونه‌ای ایجاد نمی‌شود.
  // کارآموزهای واقعی از ماژول کارکنان یا ایمپورت اکسل وارد می‌شوند.

  // ---------- ۷. قالب قرارداد کارآموزی ----------
  const internTplExists = await db.contractTemplate.findFirst({ where: { contractType: "INTERN" } });
  if (!internTplExists) {
    await db.contractTemplate.create({
      data: {
        title: "قرارداد کارآموزی",
        contractType: "INTERN",
        isActive: true,
        createdBy: "system",
        notes: "مطابق ماده ۴۵ قانون کار — دوره کارآموزی",
        body: `قرارداد کارآموزی

این قرارداد به موجب ماده ۴۵ قانون کار جمهوری اسلامی ایران و آیین‌نامه نحوه جذب کارآموز، بین شرکت {{company_name}} (شناسه ملی: {{company_national_id}}) به نشانی {{company_address}} به‌عنوان کارفرما و خانم/آقای {{employee_name}} فرزند {{employee_father_name}} به شماره ملی {{employee_national_id}} به‌عنوان کارآموز در تاریخ {{contract_date}} منعقد گردید.

ماده ۱ — موضوع قرارداد
کارآموزی و فراگیری حرفه «{{employee_job_title}}» در طبقه {{employee_grade}} زیر نظر مربی مشخصشده کارفرما.

ماده ۲ — مدت کارآموزی
از تاریخ {{contract_start_date}} لغایت {{contract_end_date}} (حداکثر مطابق ضوابط ماده ۴۵ قانون کار).

ماده ۳ — حق‌الزحمه کارآموزی
ماهانه مبلغ {{base_salary_toman}} تومان به حروف {{base_salary_toman_words}} به‌علاوه تداوم بیمه تأمین اجتماعی (شماره: {{employee_sso_number}}).

ماده ۴ — تعهدات کارآموز
حضور منظم، رعایت مقررات ایمنی و محرمانگی اطلاعات شرکت.

ماده ۵ — گواهی پایان دوره
در صورت موفقیت، گواهی کارآموزی صادر و در صورت نیاز کارفرما، جذب رسمی انجام می‌شود.

این قرارداد در ۵ ماده و ۲ نسخه تنظیم و به امضای طرفین رسید.

شماره سیستمی: {{contract_number}}
تاریخ صدور: {{contract_date}}`,
      },
    });
    console.log("قالب قرارداد کارآموزی ساخته شد");
  }

  // ---------- ۸. تنظیمات Mattermost (خاموش — فعال‌سازی از تنظیمات) ----------
  const mm = await db.systemSetting.findUnique({ where: { key: "mattermost" } });
  if (!mm) {
    await db.systemSetting.create({
      data: {
        key: "mattermost",
        value: JSON.stringify({
          enabled: false, serverUrl: "", clientId: "", clientSecret: "",
          autoCreate: true, defaultRoleKey: "EMPLOYEE", buttonLabel: "ورود با Mattermost",
        }),
      },
    });
  }

  // ---------- ۹. پیکربندی پاداش پیش‌فرض ----------
  const bonusCfg = await db.systemSetting.findUnique({ where: { key: "bonus_config" } });
  if (!bonusCfg) {
    await db.systemSetting.create({
      data: {
        key: "bonus_config",
        value: JSON.stringify({
          levels: { "1": 0, "2": 3, "3": 3, "4": 5, "5": 6, "6": 7, "7": 9 },
          tiers: [
            { key: "BELOW_80", label: "نرسیده به تارگت (کمتر از ۸۰٪)", minRatio: 0, paymentPercent: 0, extraMonths: 0 },
            { key: "AT_80", label: "تا ۸۰٪ تارگت (۸۰٪ تا ۱۰۰٪)", minRatio: 0.8, paymentPercent: 80, extraMonths: 0 },
            { key: "AT_100", label: "تحقق ۱۰۰٪ تارگت (۱۰۰٪ تا ۱۲۰٪)", minRatio: 1.0, paymentPercent: 100, extraMonths: 0 },
            { key: "OVER_120", label: "اور تارگت (۱۲۰٪ و بیشتر)", minRatio: 1.2, paymentPercent: 100, extraMonths: 1 },
          ],
        }),
      },
    });
  }

  console.log("بک‌فیل نسخه ۴ کامل شد.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

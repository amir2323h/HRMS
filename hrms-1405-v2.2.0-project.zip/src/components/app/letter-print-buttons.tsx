"use client";

// ============================================================
// دکمه‌های چاپ/دانلود درخواست‌نامه — ۴ حالت:
//   چاپ با سربرگ | چاپ بدون سربرگ | دانلود با سربرگ | دانلود بدون سربرگ
// سربرگ خودکار از تنظیمات خوانده می‌شود:
//   • اگر تصویر PNG سربرگ رسمی شرکت (A4/A5) آپلود شده باشد، همان به‌عنوان
//     پس‌زمینه صفحه قرار می‌گیرد (گرافیک دیجیتال حذف می‌شود).
//   • وگرنه سربرگ دیجیتال (لوگو/نام شرکت/شناسه ملی/نشانی) رندر می‌شود.
// انتخاب کاغذ A4/A5 — تصویر سربرگ متناسب همان سایز اعمال می‌شود.
// نامه‌های تأییدشده در همه حالت‌ها، امضای دیجیتال با کد راستی‌آزمایی دارند.
// prop «allowed» — کنترل کدام دکمه‌ها نمایش داده شوند (سیاست دانلود کارمند):
//   پیش‌فرض همه فعال (مدیر/کارشناس)؛ پرتال کارمند طبق تنظیمات فیلتر می‌شود.
// تصویر امضا و مهر فقط در نسخه «با سربرگ» چاپ می‌شوند — نسخه بدون سربرگ
// فقط نام امضاکننده دارد (قاعده مکاتبات رسمی).
// ============================================================

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Printer, Download, ShieldCheck, Image as ImageIcon } from "lucide-react";
import { useBranding } from "./use-branding";
import { useApi } from "@/lib/client";
import { printLetter, downloadLetter, type LetterPrintData, type LetterPaperSize } from "@/lib/letter-print";
import { formatDateJ, isoToJalaliStr } from "@/lib/jalali";

interface LetterheadInfo {
  a4: string;
  a5: string;
  a4TopMm: number;
  a4BottomMm: number;
  a5TopMm: number;
  a5BottomMm: number;
  signers?: { name: string; title: string; signature: string; seal: string }[];
}

/** دکمه‌های مجاز — پیش‌فرض همه (استفاده مدیریتی) */
export interface LetterPrintAllow {
  printLH?: boolean;
  printPlain?: boolean;
  downloadLH?: boolean;
  downloadPlain?: boolean;
}

export function LetterPrintButtons({ letter, allowed }: { letter: LetterPrintData; allowed?: LetterPrintAllow }) {
  const { brand } = useBranding();
  const company = {
    name: brand?.companyName || "",
    nationalId: brand?.companyNationalId || "",
    address: brand?.companyAddress || "",
    logo: brand?.logo || "",
    phone: brand?.companyPhone || "",
    mobile: brand?.companyMobile || "",
    website: brand?.companyWebsite || "",
    email: brand?.companyEmail || "",
  };
  const lh = useApi<LetterheadInfo>("/api/letters/letterhead");

  const hasA4 = !!lh.data?.a4;
  const hasA5 = !!lh.data?.a5;
  // سایز پیش‌فرض: اگر فقط A5 آپلود شده → A5؛ در غیر این صورت A4
  const [paper, setPaper] = useState<LetterPaperSize>(hasA5 && !hasA4 ? "A5" : "A4");
  const activePaper: LetterPaperSize = paper === "A5" && !hasA5 && hasA4 ? "A4" : paper;

  const image = activePaper === "A5" ? lh.data?.a5 || "" : lh.data?.a4 || "";
  const topMm = activePaper === "A5" ? lh.data?.a5TopMm : lh.data?.a4TopMm;
  const bottomMm = activePaper === "A5" ? lh.data?.a5BottomMm : lh.data?.a4BottomMm;
  const hasCustom = !!image;

  // تصویر امضای دست‌نویس و مهر امضاکننده این نامه — از فهرست امضاکنندگان تنظیمات (تطبیق نام)
  const signerLookup = letter.source === "MANUAL" ? letter.signerName || letter.decidedBy : letter.decidedBy;
  const signerEntry =
    letter.status === "APPROVED" && signerLookup
      ? lh.data?.signers?.find((s) => s.name.trim() === String(signerLookup).trim())
      : undefined;

  function opts(letterhead: boolean) {
    return {
      letterhead,
      paperSize: activePaper,
      letterheadImage: letterhead ? image : undefined,
      letterheadTopMm: topMm,
      letterheadBottomMm: bottomMm,
      // تصاویر امضا/مهر فقط در نسخه با سربرگ (نسخه بدون سربرگ = فقط نام)
      signerSignature: letterhead ? signerEntry?.signature || undefined : undefined,
      sealImage: letterhead ? signerEntry?.seal || undefined : undefined,
    };
  }

  const signed = letter.status === "APPROVED" && !!letter.signatureCode;
  const allow: Required<LetterPrintAllow> = {
    printLH: allowed?.printLH ?? true,
    printPlain: allowed?.printPlain ?? true,
    downloadLH: allowed?.downloadLH ?? true,
    downloadPlain: allowed?.downloadPlain ?? true,
  };
  const anyAllowed = allow.printLH || allow.printPlain || allow.downloadLH || allow.downloadPlain;
  if (!anyAllowed) return null;

  return (
    <div className="space-y-2 w-full">
      {/* انتخاب سایز کاغذ */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-[11px] font-bold text-slate-600">سایز کاغذ:</span>
        <div className="inline-flex rounded-lg border border-slate-200 overflow-hidden">
          {(["A4", "A5"] as const).map((s) => (
            <button
              key={s}
              type="button"
              disabled={s === "A5" ? !hasA5 && hasA4 : false}
              onClick={() => setPaper(s)}
              className={`px-3 py-1 text-[11px] font-bold transition-colors ${
                activePaper === s ? "bg-teal-600 text-white" : "bg-white text-slate-600 hover:bg-slate-50"
              } disabled:opacity-40 disabled:cursor-not-allowed`}
              title={s === "A5" && !hasA5 ? "تصویر سربرگ A5 آپلود نشده است" : ""}
            >
              {s}
              {s === "A4" ? " (۲۱۰×۲۹۷)" : " (۱۴۸×۲۱۰)"}
            </button>
          ))}
        </div>
        {hasCustom ? (
          <span className="inline-flex items-center gap-1 rounded-md bg-blue-50 border border-blue-200 px-2 py-0.5 text-[10px] text-blue-700">
            <ImageIcon className="w-3 h-3" /> سربرگ رسمی شرکت ({activePaper}) در پس‌زمینه اعمال می‌شود
          </span>
        ) : null}
      </div>

      <div className="grid grid-cols-2 gap-2">
        {allow.printLH && (
          <Button
            className="bg-teal-600 hover:bg-teal-700 gap-1.5 h-9"
            onClick={() => printLetter(letter, company, opts(true))}
          >
            <Printer className="w-4 h-4" /> {hasCustom ? "چاپ روی سربرگ رسمی" : "چاپ با سربرگ دیجیتال"}
          </Button>
        )}
        {allow.printPlain && (
          <Button variant="outline" className="gap-1.5 h-9" onClick={() => printLetter(letter, company, opts(false))}>
            <Printer className="w-4 h-4" /> چاپ بدون سربرگ
          </Button>
        )}
        {allow.downloadLH && (
          <Button variant="outline" className="gap-1.5 h-9" onClick={() => downloadLetter(letter, company, opts(true))}>
            <Download className="w-4 h-4" /> دانلود با سربرگ
          </Button>
        )}
        {allow.downloadPlain && (
          <Button variant="outline" className="gap-1.5 h-9" onClick={() => downloadLetter(letter, company, opts(false))}>
            <Download className="w-4 h-4" /> دانلود بدون سربرگ
          </Button>
        )}
      </div>
      <p className="text-[11px] leading-5 text-muted-foreground flex items-start gap-1.5">
        <ShieldCheck className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${signed ? "text-emerald-600" : "text-slate-400"}`} />
        {signed
          ? <>
              این نامه تأیید شده و در همه نسخه‌ها «امضای دیجیتال» با کد <span className="font-mono text-[10px] text-emerald-700" dir="ltr">{letter.signatureCode}</span> درج می‌شود (قابل راستی‌آزمایی از مسیر عمومی).
            </>
          : letter.status === "PENDING"
            ? "این نامه هنوز تأیید نشده — نسخه چاپی با اعلان «در انتظار تأیید» صادر می‌شود."
            : "این نامه رد شده است — نسخه چاپی با اعلان وضعیت رد صادر می‌شود."}
      </p>
    </div>
  );
}

/** نشان کد امضای دیجیتال — نمایش در لیست/دیالوگ برای نامه‌های تأییدشده */
export function LetterSignatureBadge({ code, decidedAt }: { code?: string | null; decidedAt?: string | null }) {
  if (!code) return null;
  const date = decidedAt ? formatDateJ(isoToJalaliStr(new Date(decidedAt))) : "";
  return (
    <span className="inline-flex items-center gap-1 rounded-md bg-emerald-50 border border-emerald-200 px-2 py-0.5 text-[10px] text-emerald-700" title={date ? `تأییدشده — ${date}` : "تأییدشده"}>
      <ShieldCheck className="w-3 h-3" />
      امضای دیجیتال <span className="font-mono" dir="ltr">{code}</span>
    </span>
  );
}

"use client";

import { useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, Users, FileText, Upload, Download, Trash2, Edit3, ArrowRight, Eye, FileSignature, ShieldPlus, Gift } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa, CONTRACT_TYPE_LABELS, MARITAL_LABELS, EMPLOYEE_STATUS_LABELS, DOC_TYPE_LABELS, LEAVE_TYPE_LABELS, REQUEST_STATUS_LABELS, SUPP_INSURANCE_LABELS, DEPENDENT_RELATION_LABELS, isValidNationalId, EMPLOYMENT_TYPE_LABELS, SHIFT_PATTERN_LABELS } from "@/lib/format";
import { formatDateJ, toFaDigits, periodTitle } from "@/lib/jalali";
import { JalaliDatePicker } from "../jalali-datepicker";
import { MoneyInput, Money } from "../money-input";
import { PayslipPrintDialog, type PayslipData } from "../payslip-print";
import { ExcelImportDialog, type ImportOutcome } from "../excel-import-dialog";
import { pick, cellStr, cellInt } from "@/lib/excel";
import { isValidJalali } from "@/lib/jalali";

interface EmployeeRow {
  id: string; personnelCode: string; fullName: string; nationalId: string; ssoNumber: string;
  mobile: string; email: string; maritalStatus: string; childCount: number; hireDateJ: string;
  probationEndDateJ: string; contractType: string; contractStartJ: string; contractEndJ: string;
  employmentType?: string; shiftPattern?: string;
  jobTitle: string; status: string; bankName: string; iban: string; overtimeHours: number;
  baseSalary: number; jobGradeId: string | null; grade: { level: number; title: string } | null;
  jobTitleId: string | null;
  departments: { id: string; name: string }[]; primaryDepartment: { name: string } | null;
  suppInsurance: string; suppCoveredCount: number; suppInsurerName: string; suppPolicyNumber: string;
  suppDependents: DependentForm[];
  welfare?: { id: string; title: string; code: string }[];
}

/** فرم فرد تحت پوشش بیمه تکمیلی */
interface DependentForm {
  id?: string;
  firstName: string; lastName: string; nationalId: string; relationship: string; birthDateJ: string;
}

interface GradeRow { id: string; level: number; title: string; minBaseSalary: number; maxBaseSalary: number }
interface DeptRow { id: string; name: string; code: string }
interface JobLite { id: string; code: string; title: string; gradeLevel: number | null; gradeJobGradeId?: string | null; isActive: boolean }

const CONTRACT_BADGE: Record<string, string> = {
  PERMANENT: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  FIXED: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  TEMPORARY: "bg-slate-100 text-slate-600 hover:bg-slate-100",
  PROBATION: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  INTERN: "bg-violet-100 text-violet-700 hover:bg-violet-100",
};

export function EmployeesView({ onNavigate, detailId }: { onNavigate: (v: string, p?: string) => void; detailId?: string | null }) {
  const [q, setQ] = useState("");
  const [dept, setDept] = useState("all");
  const [grade, setGrade] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [editing, setEditing] = useState<EmployeeRow | null>(null);
  const [selected, setSelected] = useState<EmployeeRow | null>(null);
  const { toast } = useToast();

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (dept !== "all") p.set("dept", dept);
    if (grade !== "all") p.set("grade", grade);
    return `/api/employees?${p.toString()}`;
  }, [q, dept, grade]);

  const list = useApi<{ employees: EmployeeRow[]; departments: DeptRow[] }>(query, [q, dept, grade]);
  const grades = useApi<{ grades: GradeRow[] }>("/api/grades");
  const jobsApi = useApi<{ jobs: (JobLite & { jobGradeId?: string | null })[] }>("/api/jobs");
  const activeJobs = (jobsApi.data?.jobs || []).filter((j) => j.isActive);

  if (detailId) {
    return <EmployeeDetail id={detailId} onBack={() => onNavigate("employees")} />;
  }

  const rows = list.data?.employees || [];

  return (
    <div className="space-y-4">
      {/* نوار ابزار */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            className="pr-9"
            placeholder="جستجو: نام، کد پرسنلی، کد ملی..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <Select value={dept} onValueChange={setDept}>
          <SelectTrigger className="w-[180px]"><SelectValue placeholder="همه دپارتمان‌ها" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه دپارتمان‌ها</SelectItem>
            {(list.data?.departments || []).map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={grade} onValueChange={setGrade}>
          <SelectTrigger className="w-[140px]"><SelectValue placeholder="همه سطوح" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه سطوح</SelectItem>
            {(grades.data?.grades || []).map((g) => <SelectItem key={g.id} value={String(g.level)}>سطح {toFaDigits(g.level)} — {g.title}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
          <Plus className="w-4 h-4" /> کارمند جدید
        </Button>
        <Button variant="outline" className="gap-1.5" onClick={() => setImportOpen(true)}>
          <Upload className="w-4 h-4" /> ایمپورت اکسل
        </Button>
      </div>

      {/* جدول */}
      <Card className="rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          {list.loading ? (
            <div className="p-4 space-y-2">{[0, 1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-12" />)}</div>
          ) : rows.length === 0 ? (
            <div className="py-16 text-center">
              <Users className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">کارمندی یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    <TableHead className="text-right">کد پرسنلی</TableHead>
                    <TableHead className="text-right">نام و نام خانوادگی</TableHead>
                    <TableHead className="text-right">دپارتمان</TableHead>
                    <TableHead className="text-right">سطح / شغل</TableHead>
                    <TableHead className="text-right">تاریخ استخدام</TableHead>
                    <TableHead className="text-right">قرارداد</TableHead>
                    <TableHead className="text-left">حقوق پایه</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    <TableHead className="text-center">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((e) => (
                    <TableRow key={e.id} className="cursor-pointer hover:bg-teal-50/40" onClick={() => setSelected(e)}>
                      <TableCell className="tabular-nums text-muted-foreground text-xs" dir="ltr">{e.personnelCode}</TableCell>
                      <TableCell className="font-medium">{e.fullName}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{e.primaryDepartment?.name || "—"}</TableCell>
                      <TableCell className="text-sm">
                        {e.grade ? <Badge variant="outline" className="mb-0.5">سطح {toFaDigits(e.grade.level)}</Badge> : null}
                        <span className="text-muted-foreground text-xs block">{e.jobTitle}</span>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground tabular-nums">{formatDateJ(e.hireDateJ)}</TableCell>
                      <TableCell>
                        <Badge className={CONTRACT_BADGE[e.contractType] || ""}>{CONTRACT_TYPE_LABELS[e.contractType]}</Badge>
                      </TableCell>
                      <TableCell className="text-left tabular-nums text-sm font-medium"><Money amount={e.baseSalary} short /></TableCell>
                      <TableCell className="text-center">
                        <Badge className={e.status === "ACTIVE" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                          {EMPLOYEE_STATUS_LABELS[e.status]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center" onClick={(ev) => ev.stopPropagation()}>
                        <div className="flex justify-center gap-1">
                          <button className="p-1.5 rounded-lg hover:bg-teal-100 text-teal-600" title="پرونده" onClick={() => setSelected(e)}>
                            <Eye className="w-4 h-4" />
                          </button>
                          <button className="p-1.5 rounded-lg hover:bg-amber-100 text-amber-600" title="ویرایش" onClick={() => { setEditing(e); setFormOpen(true); }}>
                            <Edit3 className="w-4 h-4" />
                          </button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* فرم ثبت/ویرایش */}
      <EmployeeForm
        open={formOpen}
        onOpenChange={setFormOpen}
        editing={editing}
        grades={grades.data?.grades || []}
        departments={list.data?.departments || []}
        jobs={activeJobs}
        onSaved={() => { list.refetch(); toast({ title: editing ? "پرونده به‌روزرسانی شد" : "کارمند جدید ثبت شد", description: "در لاگ حسابرسی ثبت گردید." }); }}
      />

      {/* نمایش جزئیات سریع (dialog) */}
      <EmployeeQuickView employee={selected} onClose={() => setSelected(null)} onFullProfile={(id) => { setSelected(null); onNavigate("employee-detail", id); }} onEdit={(e) => { setSelected(null); setEditing(e); setFormOpen(true); }} />

      {/* ایمپورت اکسل/CSV کارکنان */}
      <EmployeeImportDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        onImported={(o) => {
          list.refetch();
          if (o.failed === 0) toast({ title: "ایمپورت کارکنان کامل شد", description: `${toFaDigits(o.created)} نفر جدید و ${toFaDigits(o.updated)} نفر به‌روزرسانی شد.` });
        }}
      />
    </div>
  );
}

// ================= فرم کارمند =================
function EmployeeForm({ open, onOpenChange, editing, grades, departments, jobs, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: EmployeeRow | null;
  grades: GradeRow[];
  departments: DeptRow[];
  jobs: (JobLite & { jobGradeId?: string | null })[];
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [salaryDraft, setSalaryDraft] = useState(false); // تغییر حقوق به‌صورت پیش‌نویس (ذخیره موقت)
  const [f, setF] = useState(() => defaultForm(editing, departments));
  // آیتم‌های رفاهی فعال از تنظیمات
  const welfareApi = useApi<{ items: { id: string; title: string; description: string; isActive: boolean }[] }>(open ? "/api/welfare?active=1" : null);
  const welfareItems = welfareApi.data?.items || [];

  function set(field: string, value: unknown) {
    setF((prev) => ({ ...prev, [field]: value }));
  }

  /** به‌روزرسانی یک فرد تحت پوشش */
  function setDep(index: number, field: keyof DependentForm, value: string) {
    setF((prev) => {
      const deps = [...prev.suppDependents];
      deps[index] = { ...deps[index], [field]: value };
      return { ...prev, suppDependents: deps };
    });
  }

  function addDependent() {
    setF((prev) => ({ ...prev, suppDependents: [...prev.suppDependents, { firstName: "", lastName: "", nationalId: "", relationship: "", birthDateJ: "" }] }));
  }

  function removeDependent(index: number) {
    setF((prev) => ({ ...prev, suppDependents: prev.suppDependents.filter((_, i) => i !== index) }));
  }

  /** اعتبارسنجی سمت کلاینت قبل از ارسال */
  function validate(): string | null {
    if (!f.firstName.trim()) return "نام الزامی است.";
    if (!f.lastName.trim()) return "نام خانوادگی الزامی است.";
    if (f.nationalId && !isValidNationalId(f.nationalId)) return "کد ملی نامعتبر است (رقم کنترل).";
    if ((f.suppInsurance || "NONE") === "FAMILY") {
      for (let i = 0; i < f.suppDependents.length; i++) {
        const d = f.suppDependents[i];
        const label = `فرد تحت پوشش ${toFaDigits(i + 1)}`;
        if (!d.firstName.trim()) return `${label}: نام الزامی است.`;
        if (!d.relationship) return `${label}: نسبت را انتخاب کنید.`;
        if (d.nationalId && d.nationalId.length !== 10) return `${label}: کد ملی باید ۱۰ رقم باشد.`;
        if (d.nationalId && !isValidNationalId(d.nationalId)) return `${label}: رقم کنترل کد ملی نامعتبر است.`;
      }
    }
    return null;
  }

  async function save() {
    const err = validate();
    if (err) {
      toast({ title: err, variant: "destructive" });
      return;
    }
    // تغییر حقوق از مسیر پیش‌نویس؟ (فقط ویرایش — تغییر پایه/اضافه‌کاری/طبقه با تأیید بعدی اعمال می‌شود)
    const salaryChanged = !!editing && (
      Math.round(f.baseSalary * 10) !== Math.round(editing.baseSalary) ||
      (f.overtimeHours || 0) !== (editing.overtimeHours || 0) ||
      (f.jobGradeId || "") !== (editing.jobGradeId || "")
    );
    const useSalaryDraft = !!editing && salaryDraft && salaryChanged;

    setSaving(true);
    try {
      const payload: Record<string, unknown> = {
        ...f,
        baseSalary: useSalaryDraft ? undefined : f.baseSalary * 10, // تومان → ریال
        overtimeHours: useSalaryDraft ? undefined : f.overtimeHours,
        jobGradeId: useSalaryDraft ? undefined : (f.jobGradeId || null),
        jobTitleId: f.jobTitleId || null,
        jobTitle: f.jobTitle.trim(),
        // افراد تحت پوشش — فقط در حالت خانوادگی ارسال می‌شود
        suppDependents: (f.suppInsurance || "NONE") === "FAMILY" ? f.suppDependents : [],
        // رفاهیات مورد استفاده (چک‌باکس‌ها)
        welfareIds: f.welfareIds || [],
      };
      delete payload.jobCustom;
      // در حالت پیش‌نویس، فیلدهای حقوق حذف می‌شوند تا روی پرونده اعمال نشوند
      for (const k of ["baseSalary", "overtimeHours", "jobGradeId"]) {
        if (payload[k] === undefined) delete payload[k];
      }
      if (editing) {
        await api(`/api/employees/${editing.id}`, { method: "PATCH", json: payload });
        if (useSalaryDraft) {
          // ثبت تغییر حقوق به‌صورت پیش‌نویس (ذخیره موقت — اعمال پس از تأیید)
          await api("/api/salary/drafts", {
            method: "POST",
            json: {
              mode: "single",
              employeeId: editing.id,
              newBaseSalary: Math.round(f.baseSalary * 10),
              newOvertimeHours: f.overtimeHours || 0,
              newJobGradeId: f.jobGradeId || null,
              reason: "تغییر از فرم ویرایش پرونده کارمند",
            },
          });
        }
      } else {
        await api("/api/employees", { method: "POST", json: payload });
      }
      onOpenChange(false);
      if (useSalaryDraft) {
        toast({
          title: "تغییر حقوق به‌صورت پیش‌نویس ثبت شد",
          description: "سایر اطلاعات پرونده ذخیره شد؛ تغییر حقوق پس از تأیید در ماژول «مدیریت تغییرات حقوق» اعمال می‌شود.",
        });
      }
      onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }
  const selectedGrade = grades.find((g) => g.id === f.jobGradeId);

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) setF(defaultForm(editing, departments)); }}>
      <DialogContent className="sm:max-w-[58.8rem] max-h-[88vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? `ویرایش پرونده — ${editing.fullName}` : "ثبت کارمند جدید"}</DialogTitle>
        </DialogHeader>
        <Tabs defaultValue="personal" dir="rtl">
          <TabsList className="w-full mb-4">
            <TabsTrigger value="personal" className="flex-1">اطلاعات فردی</TabsTrigger>
            <TabsTrigger value="contract" className="flex-1">قرارداد و استخدام</TabsTrigger>
            <TabsTrigger value="salary" className="flex-1">حقوق و شغل</TabsTrigger>
            <TabsTrigger value="insurance" className="flex-1 gap-1"><ShieldPlus className="w-3.5 h-3.5" /> بیمه تکمیلی</TabsTrigger>
            <TabsTrigger value="welfare" className="flex-1 gap-1"><Gift className="w-3.5 h-3.5" /> رفاهیات</TabsTrigger>
          </TabsList>

          <TabsContent value="personal" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Field label="نام *"><Input value={f.firstName} onChange={(e) => set("firstName", e.target.value)} /></Field>
              <Field label="نام خانوادگی *"><Input value={f.lastName} onChange={(e) => set("lastName", e.target.value)} /></Field>
              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">کد ملی <span className="text-rose-600">*</span></Label>
                <Input
                  dir="ltr"
                  className="text-left tabular-nums"
                  maxLength={10}
                  placeholder="۱۰ رقم"
                  value={f.nationalId}
                  onChange={(e) => set("nationalId", e.target.value.replace(/\D/g, ""))}
                  required
                />
                {f.nationalId && f.nationalId.length !== 10 && (
                  <p className="text-[10px] text-rose-600">کد ملی باید دقیقاً ۱۰ رقم باشد ({toFaDigits(f.nationalId.length)} رقم وارد شده)</p>
                )}
              </div>
              <Field label="شماره بیمه"><Input dir="ltr" className="text-left tabular-nums" value={f.ssoNumber} onChange={(e) => set("ssoNumber", e.target.value.replace(/\D/g, ""))} /></Field>
              <Field label="موبایل"><Input dir="ltr" className="text-left tabular-nums" value={f.mobile} onChange={(e) => set("mobile", e.target.value.replace(/\D/g, ""))} /></Field>
              <Field label="ایمیل"><Input dir="ltr" className="text-left" type="email" value={f.email} onChange={(e) => set("email", e.target.value)} /></Field>
              <Field label="وضعیت تأهل">
                <Select value={f.maritalStatus} onValueChange={(v) => set("maritalStatus", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SINGLE">مجرد</SelectItem>
                    <SelectItem value="MARRIED">متأهل</SelectItem>
                  </SelectContent>
                </Select>
              </Field>
              <Field label="تعداد فرزند مشمول حق اولاد">
                <Input type="number" min={0} max={6} className="tabular-nums" value={f.childCount} onChange={(e) => set("childCount", +e.target.value || 0)} />
              </Field>
            </div>
          </TabsContent>

          <TabsContent value="contract" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Field label="نوع قرارداد">
                <Select value={f.contractType} onValueChange={(v) => set("contractType", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(CONTRACT_TYPE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="نوع اشتغال (شیفت‌بندی)">
                <Select value={f.employmentType || "DAILY"} onValueChange={(v) => setF((prev) => ({ ...prev, employmentType: v, shiftPattern: v === "DAILY" ? "" : prev.shiftPattern || "TWO_SHIFT" }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(EMPLOYMENT_TYPE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              {(f.employmentType || "DAILY") === "SHIFT" && (
                <Field label="الگوی شیفت (نوبتی‌کاری)">
                  <Select value={f.shiftPattern || "TWO_SHIFT"} onValueChange={(v) => set("shiftPattern", v)}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(SHIFT_PATTERN_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </Field>
              )}
              <Field label="دپارتمان">
                <Select value={f.departmentId || "none"} onValueChange={(v) => set("departmentId", v === "none" ? "" : v)}>
                  <SelectTrigger><SelectValue placeholder="انتخاب دپارتمان" /></SelectTrigger>
                  <SelectContent>
                    {departments.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="تاریخ استخدام"><JalaliDatePicker value={f.hireDateJ} onChange={(v) => set("hireDateJ", v)} /></Field>
              <Field label="شروع قرارداد"><JalaliDatePicker value={f.contractStartJ} onChange={(v) => set("contractStartJ", v)} /></Field>
              <Field label="پایان دوره آزمایشی"><JalaliDatePicker value={f.probationEndDateJ} onChange={(v) => set("probationEndDateJ", v)} /></Field>
              <Field label="پایان قرارداد (مدت‌دار)"><JalaliDatePicker value={f.contractEndJ} onChange={(v) => set("contractEndJ", v)} /></Field>
            </div>
            <p className="text-xs text-muted-foreground bg-slate-50 rounded-lg p-3 leading-5">
              برای قراردادهای دائم، تاریخ پایان را خالی بگذارید. پایان دوره آزمایشی حداکثر یک ماه از شروع قرارداد است (ماده ۱۱ قانون کار).
            </p>
          </TabsContent>

          {/* تب بیمه تکمیلی */}
          <TabsContent value="insurance" className="space-y-4">
            <div className="rounded-xl bg-teal-50/60 border border-teal-200/70 p-3 mb-1">
              <p className="text-xs text-teal-800 leading-5">
                وضعیت بیمه تکمیلی هر پرسنل ثبت می‌شود. در بیمه <b>خانوادگی</b>، مشخصات و نسبت هر فرد تحت پوشش (بجز خود بیمه‌شده) به‌صورت الزامی دریافت می‌شود.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label="وضعیت بیمه تکمیلی">
                <Select value={f.suppInsurance || "NONE"} onValueChange={(v) => set("suppInsurance", v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {Object.entries(SUPP_INSURANCE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="بیمه‌گر (شرکت بیمه)">
                <Input value={f.suppInsurerName} onChange={(e) => set("suppInsurerName", e.target.value)} placeholder="مثلاً بیمه آسیا" disabled={(f.suppInsurance || "NONE") === "NONE"} />
              </Field>
              <Field label="شماره بیمه‌نامه">
                <Input dir="ltr" className="text-left tabular-nums" value={f.suppPolicyNumber} onChange={(e) => set("suppPolicyNumber", e.target.value)} disabled={(f.suppInsurance || "NONE") === "NONE"} />
              </Field>
              <div className="flex items-end">
                <div className="w-full rounded-xl border bg-slate-50 px-3.5 py-2.5 text-xs leading-5">
                  {(f.suppInsurance || "NONE") === "FAMILY" ? (
                    <>مجموع تحت پوشش: <b className="text-teal-700">{toFaDigits(1 + f.suppDependents.length)} نفر</b> (خود + {toFaDigits(f.suppDependents.length)} بستگان)</>
                  ) : (f.suppInsurance || "NONE") === "INDIVIDUAL" ? (
                    <>مجموع تحت پوشش: <b>۱ نفر</b> (فقط خود پرسنل)</>
                  ) : (
                    <span className="text-muted-foreground">بدون بیمه تکمیلی</span>
                  )}
                </div>
              </div>
            </div>

            {/* مشخصات افراد تحت پوشش (بستگان) — فقط در بیمه خانوادگی */}
            {(f.suppInsurance || "NONE") === "FAMILY" && (
              <div className="rounded-xl border border-teal-200/70 bg-teal-50/30 p-3.5 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <p className="text-xs font-bold text-teal-800">افراد تحت پوشش (بستگان)</p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">نام، نسبت و مشخصات هر فرد را وارد کنید — کد ملی و تاریخ تولد اختیاری است</p>
                  </div>
                  <Button size="sm" variant="outline" className="gap-1 h-8 shrink-0" onClick={addDependent} disabled={f.suppDependents.length >= 20}>
                    <Plus className="w-3.5 h-3.5" /> افزودن فرد
                  </Button>
                </div>
                {f.suppDependents.length === 0 && (
                  <p className="text-[11px] text-muted-foreground bg-white rounded-lg border border-dashed p-3 text-center">
                    هنوز فردی ثبت نشده — با «افزودن فرد»، نسبت و مشخصات هر فرد تحت پوشش را تکمیل کنید.
                  </p>
                )}
                <div className="space-y-2.5">
                  {f.suppDependents.map((d, i) => (
                    <div key={i} className="rounded-lg bg-white border p-3 space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-teal-700">فرد تحت پوشش {toFaDigits(i + 1)}</span>
                        <button type="button" className="p-1 rounded-lg hover:bg-rose-100 text-rose-500" title="حذف" onClick={() => removeDependent(i)}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2.5">
                        <div className="space-y-1">
                          <Label className="text-[10px] text-slate-500">نام <span className="text-rose-600">*</span></Label>
                          <Input className="h-9" value={d.firstName} onChange={(e) => setDep(i, "firstName", e.target.value)} />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-[10px] text-slate-500">نام خانوادگی</Label>
                          <Input className="h-9" value={d.lastName} onChange={(e) => setDep(i, "lastName", e.target.value)} />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-[10px] text-slate-500">نسبت <span className="text-rose-600">*</span></Label>
                          <Select value={d.relationship || "none"} onValueChange={(v) => setDep(i, "relationship", v === "none" ? "" : v)}>
                            <SelectTrigger className="h-9"><SelectValue placeholder="انتخاب نسبت" /></SelectTrigger>
                            <SelectContent>
                              {Object.entries(DEPENDENT_RELATION_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-[10px] text-slate-500">کد ملی (اختیاری)</Label>
                          <Input dir="ltr" className="h-9 text-left tabular-nums" maxLength={10} placeholder="۱۰ رقم" value={d.nationalId} onChange={(e) => setDep(i, "nationalId", e.target.value.replace(/\D/g, ""))} />
                        </div>
                        <div className="space-y-1 col-span-2 sm:col-span-1">
                          <Label className="text-[10px] text-slate-500">تاریخ تولد (اختیاری)</Label>
                          <JalaliDatePicker value={d.birthDateJ} onChange={(v) => setDep(i, "birthDateJ", v)} placeholder="۱۴۰۵/۰۱/۰۱" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>

          {/* تب رفاهیات */}
          <TabsContent value="welfare" className="space-y-4">
            <div className="rounded-xl bg-violet-50/60 border border-violet-200/70 p-3">
              <p className="text-xs text-violet-800 leading-5">
                رفاهیاتی که این کارمند استفاده می‌کند — آیتم‌ها در تنظیمات (تب رفاهیات) تعریف می‌شوند.
              </p>
            </div>
            {welfareItems.length === 0 ? (
              <p className="text-sm text-muted-foreground py-6 text-center">آیتم رفاهی تعریف نشده — از تنظیمات تب «رفاهیات» اضافه کنید.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {welfareItems.map((w) => {
                  const checked = (f.welfareIds || []).includes(w.id);
                  return (
                    <label
                      key={w.id}
                      className={`flex items-center gap-3 rounded-xl border p-3 cursor-pointer transition-colors ${checked ? "border-violet-400 bg-violet-50" : "border-slate-200 hover:border-violet-300"}`}
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={(v) => {
                          const cur = f.welfareIds || [];
                          set("welfareIds", v ? [...cur, w.id] : cur.filter((x: string) => x !== w.id));
                        }}
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-medium flex items-center gap-1.5"><Gift className="w-3.5 h-3.5 text-violet-500" /> {w.title}</p>
                        {w.description && <p className="text-[11px] text-muted-foreground mt-0.5 leading-4">{w.description}</p>}
                      </div>
                    </label>
                  );
                })}
              </div>
            )}
            <p className="text-[11px] text-muted-foreground">{toFaDigits((f.welfareIds || []).length)} رفاهیت انتخاب شده</p>
          </TabsContent>

          <TabsContent value="salary" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {/* عنوان شغل — انتخاب از مشاغل تعریف‌شده در تنظیمات */}
              <div className="space-y-1.5 col-span-2">
                <Label className="text-xs text-slate-600">عنوان شغل {jobs.length > 0 && <span className="text-rose-600">*</span>}</Label>
                {jobs.length > 0 ? (
                  <>
                    <Select
                      value={f.jobTitleId || (f.jobCustom || f.jobTitle ? "custom" : "none")}
                      onValueChange={(v) => {
                        if (v === "none") {
                          setF((prev) => ({ ...prev, jobTitleId: "", jobTitle: "", jobCustom: false }));
                        } else if (v === "custom") {
                          setF((prev) => ({ ...prev, jobTitleId: "", jobCustom: true }));
                        } else {
                          const job = jobs.find((j) => j.id === v);
                          setF((prev) => ({
                            ...prev,
                            jobTitleId: v,
                            jobTitle: job?.title || "",
                            jobCustom: false,
                            // طبقه شغلی هوشمند از روی شغل انتخابی
                            jobGradeId: job?.jobGradeId || prev.jobGradeId,
                          }));
                        }
                      }}
                    >
                      <SelectTrigger><SelectValue placeholder="انتخاب از مشاغل تعریف‌شده" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">— بدون شغل —</SelectItem>
                        {jobs.map((j) => (
                          <SelectItem key={j.id} value={j.id}>
                            {j.title}{j.gradeLevel ? ` (سطح ${toFaDigits(j.gradeLevel)})` : ""}
                          </SelectItem>
                        ))}
                        <SelectItem value="custom">سایر (ورود دستی)</SelectItem>
                      </SelectContent>
                    </Select>
                    {(f.jobCustom || (!f.jobTitleId && !!f.jobTitle)) && (
                      <Input value={f.jobTitle} onChange={(e) => set("jobTitle", e.target.value)} placeholder="عنوان شغل را دستی وارد کنید" />
                    )}
                    <p className="text-[10px] text-muted-foreground">مشاغل در «تنظیمات ← مشاغل و عناوین شغلی» تعریف می‌شوند و با ایمپورت اکسل قابل بارگذاری‌اند.</p>
                  </>
                ) : (
                  <>
                    <Input value={f.jobTitle} onChange={(e) => set("jobTitle", e.target.value)} placeholder="عنوان شغل" />
                    <p className="text-[10px] text-muted-foreground">هنوز شغلی در تنظیمات تعریف نشده — می‌توانید دستی وارد کنید یا از «تنظیمات ← مشاغل» تعریف کنید.</p>
                  </>
                )}
              </div>
              <Field label="طبقه شغلی (سطح ۱ تا ۷)">
                <Select value={f.jobGradeId || "none"} onValueChange={(v) => set("jobGradeId", v === "none" ? "" : v)}>
                  <SelectTrigger><SelectValue placeholder="انتخاب سطح" /></SelectTrigger>
                  <SelectContent>
                    {grades.map((g) => <SelectItem key={g.id} value={g.id}>سطح {toFaDigits(g.level)} — {g.title}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Field>
              <Field label="حقوق پایه (ماهانه)">
                <MoneyInput value={f.baseSalary} onChange={(v) => set("baseSalary", v)} />
              </Field>
              <Field label="ساعت اضافه‌کاری پیش‌فرض ماه">
                <Input type="number" min={0} max={120} className="tabular-nums" value={f.overtimeHours} onChange={(e) => set("overtimeHours", +e.target.value || 0)} />
              </Field>
              {editing && (
                <div className="col-span-2 flex items-start gap-2.5 rounded-lg border border-amber-200 bg-amber-50/70 p-3">
                  <Switch checked={salaryDraft} onCheckedChange={setSalaryDraft} id="salary-draft-switch" className="mt-0.5 shrink-0" />
                  <label htmlFor="salary-draft-switch" className="text-[11px] leading-5 text-amber-900 cursor-pointer">
                    ثبت تغییر حقوق به‌صورت <b>پیش‌نویس (ذخیره موقت)</b> — حقوق پایه/اضافه‌کاری/طبقه پس از تأیید در ماژول
                    «مدیریت تغییرات حقوق» اعمال می‌شود؛ سایر اطلاعات پرونده همین حالا ذخیره می‌شود.
                  </label>
                </div>
              )}
              <Field label="بانک"><Input value={f.bankName} onChange={(e) => set("bankName", e.target.value)} /></Field>
              <Field label="شماره شبا">
                <Input dir="ltr" className="text-left font-mono text-xs" placeholder="IR..." maxLength={26} value={f.iban} onChange={(e) => set("iban", e.target.value.toUpperCase())} />
              </Field>
            </div>
            {selectedGrade && (
              <div className="text-xs bg-teal-50 border border-teal-200 rounded-lg p-3 text-teal-800 leading-5">
                بازه مجاز سطح {toFaDigits(selectedGrade.level)}: از <b className="tabular-nums">{groupFa(Math.round(selectedGrade.minBaseSalary / 10))}</b> تا <b className="tabular-nums">{groupFa(Math.round(selectedGrade.maxBaseSalary / 10))}</b> تومان
              </div>
            )}
          </TabsContent>
        </Tabs>

        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">
            {saving ? "در حال ذخیره..." : editing ? "ذخیره تغییرات" : "ثبت کارمند"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function defaultForm(editing: EmployeeRow | null, _departments: DeptRow[]) {
  if (editing) {
    return {
      firstName: editing.firstName || "",
      lastName: editing.lastName || "",
      nationalId: editing.nationalId || "",
      ssoNumber: editing.ssoNumber || "",
      mobile: editing.mobile || "",
      email: editing.email || "",
      maritalStatus: editing.maritalStatus || "SINGLE",
      childCount: editing.childCount || 0,
      contractType: editing.contractType || "PERMANENT",
      employmentType: editing.employmentType || "DAILY",
      shiftPattern: editing.shiftPattern || "",
      hireDateJ: editing.hireDateJ || "",
      contractStartJ: editing.contractStartJ || "",
      contractEndJ: editing.contractEndJ || "",
      probationEndDateJ: editing.probationEndDateJ || "",
      jobTitle: editing.jobTitle || "",
      jobTitleId: editing.jobTitleId || "",
      jobCustom: !editing.jobTitleId && !!editing.jobTitle,
      jobGradeId: editing.jobGradeId || "",
      baseSalary: Math.round(editing.baseSalary / 10),
      overtimeHours: editing.overtimeHours || 0,
      bankName: editing.bankName || "",
      iban: editing.iban || "",
      departmentId: editing.departments?.[0]?.id || "",
      suppInsurance: editing.suppInsurance || "NONE",
      suppInsurerName: editing.suppInsurerName || "",
      suppPolicyNumber: editing.suppPolicyNumber || "",
      welfareIds: (editing.welfare || []).map((w) => w.id),
      suppDependents: (editing.suppDependents || []).map((d) => ({
        id: d.id,
        firstName: d.firstName || "",
        lastName: d.lastName || "",
        nationalId: d.nationalId || "",
        relationship: d.relationship || "",
        birthDateJ: d.birthDateJ || "",
      })),
    };
  }
  return {
    firstName: "", lastName: "", nationalId: "", ssoNumber: "", mobile: "", email: "",
    maritalStatus: "SINGLE", childCount: 0, contractType: "PERMANENT", hireDateJ: "",
    employmentType: "DAILY", shiftPattern: "",
    contractStartJ: "", contractEndJ: "", probationEndDateJ: "", jobTitle: "", jobTitleId: "", jobCustom: false, jobGradeId: "",
    baseSalary: 0, overtimeHours: 0, bankName: "", iban: "", departmentId: "",
    suppInsurance: "NONE", suppInsurerName: "", suppPolicyNumber: "", suppDependents: [], welfareIds: [],
  };
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-slate-600">{label}</Label>
      {children}
    </div>
  );
}

// ================= نمایش سریع =================
function EmployeeQuickView({ employee, onClose, onFullProfile, onEdit }: {
  employee: EmployeeRow | null;
  onClose: () => void;
  onFullProfile: (id: string) => void;
  onEdit: (e: EmployeeRow) => void;
}) {
  if (!employee) return null;
  return (
    <Dialog open={!!employee} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[44.8rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {employee.fullName}
            <Badge variant="outline">{employee.personnelCode}</Badge>
          </DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
          <KV label="دپارتمان" value={employee.primaryDepartment?.name || "—"} />
          <KV label="عنوان شغل" value={employee.jobTitle || "—"} />
          <KV label="سطح شغلی" value={employee.grade ? `سطح ${toFaDigits(employee.grade.level)} — ${employee.grade.title}` : "—"} />
          <KV label="نوع قرارداد" value={CONTRACT_TYPE_LABELS[employee.contractType]} />
          <KV label="نوع اشتغال" value={`${EMPLOYMENT_TYPE_LABELS[employee.employmentType || "DAILY"] || employee.employmentType || "روزکار عادی"}${employee.shiftPattern ? ` — ${SHIFT_PATTERN_LABELS[employee.shiftPattern] || ""}` : ""}`} />
          <KV label="تاریخ استخدام" value={formatDateJ(employee.hireDateJ)} />
          <KV label="تعداد فرزند" value={toFaDigits(employee.childCount)} />
          <KV label="حقوق پایه" value="" />
          <div className="col-span-2 -mt-2"><Money amount={employee.baseSalary} className="font-bold text-teal-700" /></div>
          <KV label="بانک" value={employee.bankName || "—"} />
          <KV label="شبا" value={employee.iban ? `${employee.iban.slice(0, 8)}...${employee.iban.slice(-4)}` : "—"} />
        </div>
        <DialogFooter className="mt-4 gap-2">
          <Button variant="outline" className="gap-1.5" onClick={() => onEdit(employee)}><Edit3 className="w-4 h-4" /> ویرایش</Button>
          <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => onFullProfile(employee.id)}>
            <FileText className="w-4 h-4" /> پرونده کامل
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function KV({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="font-medium text-sm mt-0.5">{value}</p>
    </div>
  );
}

// ================= پرونده کامل کارمند =================
function EmployeeDetail({ id, onBack }: { id: string; onBack: () => void }) {
  const detail = useApi<{
    employee: EmployeeRow & { address: string; notes: string };
    documents: { id: string; type: string; title: string; fileName: string; size: number; createdAt: string; uploadedBy: string }[];
    payslips: PayslipData[];
    leaveRequests: { id: string; type: string; startDateJ: string; endDateJ: string; days: number; status: string; reason: string }[];
    advanceRequests: { id: string; amount: number; installments: number; status: string; reason: string }[];
  }>(`/api/employees/${id}`);
  const company = useApi<{ name: string; nationalId: string; ssoCode: string; taxId: string; address: string }>("/api/settings");
  const [printSlip, setPrintSlip] = useState<PayslipData | null>(null);
  const { toast } = useToast();

  if (detail.loading) return <div className="space-y-3"><Skeleton className="h-24 rounded-2xl" /><Skeleton className="h-64 rounded-2xl" /></div>;
  if (detail.error || !detail.data) return <div className="rounded-xl bg-rose-50 border border-rose-200 text-rose-700 p-4 text-sm">{detail.error}</div>;
  const { employee: e, documents, payslips, leaveRequests, advanceRequests } = detail.data;

  return (
    <div className="space-y-4">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-teal-700 hover:text-teal-900 font-medium">
        <ArrowRight className="w-4 h-4" /> بازگشت به لیست کارکنان
      </button>

      {/* کارت هدر */}
      <Card className="rounded-2xl overflow-hidden">
        <div className="bg-gradient-to-l from-teal-600 to-teal-800 p-5 text-white">
          <div className="flex flex-wrap items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/15 border border-white/30 flex items-center justify-center text-2xl font-bold">
              {e.fullName.charAt(0)}
            </div>
            <div className="flex-1 min-w-[200px]">
              <h2 className="text-xl font-bold">{e.fullName}</h2>
              <p className="text-teal-100 text-sm mt-0.5">{e.jobTitle} — {e.primaryDepartment?.name || "بدون دپارتمان"}</p>
              <div className="flex gap-2 mt-2 flex-wrap">
                <Badge className="bg-white/15 text-white hover:bg-white/15 border-white/20">{e.personnelCode}</Badge>
                <Badge className="bg-white/15 text-white hover:bg-white/15 border-white/20">{e.grade ? `سطح ${toFaDigits(e.grade.level)}` : "بدون طبقه"}</Badge>
                <Badge className={`${CONTRACT_BADGE[e.contractType]} border-0`}>{CONTRACT_TYPE_LABELS[e.contractType]}</Badge>
                <Badge className="bg-white/15 text-white hover:bg-white/15 border-white/20">{MARITAL_LABELS[e.maritalStatus]} — {toFaDigits(e.childCount)} فرزند</Badge>
              </div>
            </div>
            <div className="text-left">
              <p className="text-xs text-teal-200">حقوق پایه</p>
              <p className="text-lg font-bold tabular-nums">{groupFa(Math.round(e.baseSalary / 10))} <span className="text-xs font-normal">تومان</span></p>
            </div>
          </div>
        </div>
        <CardContent className="p-0">
          <Tabs defaultValue="profile" dir="rtl">
            <div className="px-4 pt-3 border-b">
              <TabsList>
                <TabsTrigger value="profile">اطلاعات پرونده</TabsTrigger>
                <TabsTrigger value="docs" className="gap-1.5"><FileSignature className="w-3.5 h-3.5" /> اسناد ({toFaDigits(documents.length)})</TabsTrigger>
                <TabsTrigger value="payslips">فیش‌های حقوقی</TabsTrigger>
                <TabsTrigger value="requests">درخواست‌ها</TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="profile" className="p-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-4">
                <KV label="کد ملی" value={e.nationalId ? toFaDigits(e.nationalId) : "—"} />
                <KV label="شماره بیمه" value={e.ssoNumber ? toFaDigits(e.ssoNumber) : "—"} />
                <KV label="موبایل" value={e.mobile ? toFaDigits(e.mobile) : "—"} />
                <KV label="ایمیل" value={e.email || "—"} />
                <KV label="تاریخ استخدام" value={formatDateJ(e.hireDateJ)} />
                <KV label="شروع قرارداد" value={formatDateJ(e.contractStartJ)} />
                <KV label="پایان دوره آزمایشی" value={formatDateJ(e.probationEndDateJ)} />
                <KV label="پایان قرارداد" value={e.contractEndJ ? formatDateJ(e.contractEndJ) : "قرارداد دائم"} />
                <KV label="اضافه‌کاری پیش‌فرض" value={`${toFaDigits(e.overtimeHours)} ساعت در ماه`} />
                <KV label="بانک" value={e.bankName || "—"} />
                <KV label="شماره شبا" value={e.iban || "—"} />
                <KV label="وضعیت" value={EMPLOYEE_STATUS_LABELS[e.status]} />
              </div>

              {/* بیمه تکمیلی */}
              <div className="mt-6 pt-5 border-t">
                <h4 className="text-sm font-bold mb-3 flex items-center gap-2">
                  <ShieldPlus className="w-4 h-4 text-teal-600" /> بیمه تکمیلی
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-4">
                  <KV label="وضعیت" value={SUPP_INSURANCE_LABELS[e.suppInsurance || "NONE"]} />
                  <KV label="افراد تحت پوشش" value={e.suppInsurance !== "NONE" ? `${toFaDigits(e.suppCoveredCount || 0)} نفر${e.suppInsurance === "FAMILY" ? ` (خود + ${toFaDigits((e.suppDependents || []).length)} بستگان)` : ""}` : "—"} />
                  <KV label="بیمه‌گر" value={e.suppInsurerName || "—"} />
                  <KV label="شماره بیمه‌نامه" value={e.suppPolicyNumber ? toFaDigits(e.suppPolicyNumber) : "—"} />
                </div>

                {/* مشخصات بستگان تحت پوشش */}
                {(e.suppDependents || []).length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-bold mb-2 text-teal-800">بستگان تحت پوشش ({toFaDigits(e.suppDependents.length)} نفر)</p>
                    <div className="overflow-x-auto rounded-xl border">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-slate-50/80">
                            <TableHead className="text-right">نام و نام خانوادگی</TableHead>
                            <TableHead className="text-center">نسبت</TableHead>
                            <TableHead className="text-center">کد ملی</TableHead>
                            <TableHead className="text-center">تاریخ تولد</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {e.suppDependents.map((d) => (
                            <TableRow key={d.id || d.nationalId + d.firstName}>
                              <TableCell className="text-sm font-medium">{`${d.firstName} ${d.lastName}`.trim()}</TableCell>
                              <TableCell className="text-center text-sm">{DEPENDENT_RELATION_LABELS[d.relationship] || d.relationship}</TableCell>
                              <TableCell className="text-center text-sm tabular-nums" dir="ltr">{d.nationalId ? toFaDigits(d.nationalId) : "—"}</TableCell>
                              <TableCell className="text-center text-xs text-muted-foreground tabular-nums">{d.birthDateJ ? formatDateJ(d.birthDateJ) : "—"}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="docs" className="p-5">
              <DocumentUploader employeeId={e.id} onUploaded={() => detail.refetch()} />
              <div className="mt-4 space-y-2">
                {documents.length === 0 && <p className="text-sm text-muted-foreground py-6 text-center">سندی بارگذاری نشده است</p>}
                {documents.map((d) => (
                  <div key={d.id} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 hover:border-teal-300 transition-colors">
                    <FileText className="w-5 h-5 text-teal-600 shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium truncate">{d.title}</p>
                      <p className="text-[11px] text-muted-foreground">
                        {DOC_TYPE_LABELS[d.type] || d.type} • {groupFa(d.size / 1024)} کیلوبایت • بارگذاری: {d.uploadedBy || "—"}
                      </p>
                    </div>
                    <a href={`/api/documents/${d.id}`} className="p-2 rounded-lg hover:bg-teal-100 text-teal-600" title="دانلود">
                      <Download className="w-4 h-4" />
                    </a>
                    <button
                      className="p-2 rounded-lg hover:bg-rose-100 text-rose-600"
                      title="حذف"
                      onClick={async () => {
                        try {
                          await api(`/api/documents/${d.id}`, { method: "DELETE" });
                          detail.refetch();
                          toast({ title: "سند حذف شد" });
                        } catch (err) {
                          toast({ title: "خطا در حذف", description: err instanceof Error ? err.message : "", variant: "destructive" });
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="payslips" className="p-5">
              <div className="space-y-2">
                {payslips.length === 0 && <p className="text-sm text-muted-foreground py-6 text-center">فیشی صادر نشده است</p>}
                {payslips.map((p) => (
                  <div key={p.id} className="flex items-center gap-3 rounded-xl border border-slate-200 p-3 hover:border-teal-300 transition-colors">
                    <div className="flex-1">
                      <p className="text-sm font-medium">{p.period ? periodTitle(p.period.year, p.period.month) : "—"}</p>
                      <p className="text-[11px] text-muted-foreground tabular-nums">
                        ناخالص: {groupFa(Math.round(p.gross / 10))} تومان • خالص: <b className="text-emerald-700">{groupFa(Math.round(p.netPay / 10))}</b> تومان
                        {p.isReverse && <Badge className="mr-2 bg-amber-100 text-amber-700 hover:bg-amber-100">معکوس</Badge>}
                      </p>
                    </div>
                    <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setPrintSlip(p)}>
                      <Eye className="w-3.5 h-3.5" /> مشاهده فیش
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="requests" className="p-5">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h4 className="text-sm font-bold mb-3">مرخصی‌ها</h4>
                  <div className="space-y-2">
                    {leaveRequests.length === 0 && <p className="text-xs text-muted-foreground">مرخصی ثبت نشده</p>}
                    {leaveRequests.map((l) => (
                      <div key={l.id} className="rounded-xl border p-3 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="font-medium">{LEAVE_TYPE_LABELS[l.type]}</span>
                          <Badge className={l.status === "APPROVED" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : l.status === "REJECTED" ? "bg-rose-100 text-rose-700 hover:bg-rose-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}>
                            {REQUEST_STATUS_LABELS[l.status]}
                          </Badge>
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-1">{formatDateJ(l.startDateJ)} تا {formatDateJ(l.endDateJ)} ({toFaDigits(l.days)} روز)</p>
                        {l.reason && <p className="text-[11px] text-muted-foreground mt-0.5">دلیل: {l.reason}</p>}
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-bold mb-3">مساعدها</h4>
                  <div className="space-y-2">
                    {advanceRequests.length === 0 && <p className="text-xs text-muted-foreground">مساعده‌ای ثبت نشده</p>}
                    {advanceRequests.map((a) => (
                      <div key={a.id} className="rounded-xl border p-3 text-sm">
                        <div className="flex items-center justify-between">
                          <span className="font-medium tabular-nums">{groupFa(Math.round(a.amount / 10))} تومان</span>
                          <Badge className={a.status === "APPROVED" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : a.status === "REJECTED" ? "bg-rose-100 text-rose-700 hover:bg-rose-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}>
                            {REQUEST_STATUS_LABELS[a.status]}
                          </Badge>
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-1">{toFaDigits(a.installments)} قسط {a.reason ? `• ${a.reason}` : ""}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <PayslipPrintDialog
        open={!!printSlip}
        onOpenChange={(v) => !v && setPrintSlip(null)}
        payslip={printSlip}
        company={company.data || { name: "", nationalId: "", ssoCode: "", taxId: "", address: "" }}
      />
    </div>
  );
}

// ================= ایمپورت اکسل کارکنان =================
interface EmployeeImportRow {
  firstName: string;
  lastName: string;
  nationalId: string;
  mobile: string;
  email: string;
  hireDateJ: string;
  contractType: string;
  jobTitle: string;
  gradeLevel: number | null;
  baseSalary: number; // ریال
  department: string;
  bankName: string;
  iban: string;
  maritalStatus: string;
  childCount: number;
  ssoNumber: string;
  overtimeHours: number;
}

/** پارس ردیف اکسل → داده ایمپورت (تحمل ارقام فارسی، تاریخ با جداکننده‌های مختلف، مبلغ تومان) */
function parseEmployeeRow(row: Record<string, unknown>): { data: EmployeeImportRow; errors: string[] } {
  const errors: string[] = [];

  const firstName = cellStr(pick(row, ["نام", "اسم", "FirstName"]));
  const lastName = cellStr(pick(row, ["نام خانوادگی", "فامیل", "LastName"]));
  const nationalId = cellStr(pick(row, ["کد ملی", "کدملی", "NationalId"])).replace(/\D/g, "");
  const mobile = cellStr(pick(row, ["موبایل", "تلفن همراه", "شماره موبایل", "Mobile"]));
  const email = cellStr(pick(row, ["ایمیل", "رایانامه", "Email"]));
  // تاریخ: تحمل - و . و ارقام فارسی → استاندارد 1405/01/15
  let hireDateJ = cellStr(pick(row, ["تاریخ استخدام", "تاریخ استخدام (جلالی)", "استخدام", "HireDate"])).replace(/[.\-]/g, "/");
  const contractType = cellStr(pick(row, ["نوع قرارداد", "نوع همکاری", "قرارداد", "ContractType"]));
  const jobTitle = cellStr(pick(row, ["عنوان شغل", "شغل", "سمت", "JobTitle"]));
  const gradeRaw = pick(row, ["سطح", "طبقه", "سطح شغلی", "Level"]);
  const gradeLevel = gradeRaw === undefined || cellStr(gradeRaw) === "" ? null : cellInt(gradeRaw);
  // مبلغ: پذیرش «تومان» (پیش‌فرض) یا «ریال» — جداکننده سه‌رقمی و ارقام فارسی تحمل می‌شود
  const baseTomanRaw = pick(row, ["حقوق پایه", "حقوق پایه (تومان)", "حقوق پایه ماهانه", "دستمزد", "BaseSalary"]);
  const baseSalaryToman = cellInt(baseTomanRaw);
  const department = cellStr(pick(row, ["دپارتمان", "واحد سازمانی", "واحد", "بخش", "Department"]));
  const bankName = cellStr(pick(row, ["بانک", "نام بانک", "Bank"]));
  const iban = cellStr(pick(row, ["شبا", "شماره شبا", "شماره حساب (شبا)", "Iban"])).replace(/\s/g, "");
  const maritalStatus = cellStr(pick(row, ["وضعیت تأهل", "وضعیت تاهل", "تأهل", "MaritalStatus"]));
  const childCount = cellInt(pick(row, ["تعداد فرزند", "فرزند", "Children"]));
  const ssoNumber = cellStr(pick(row, ["شماره بیمه", "کد بیمه", "شماره تأمین اجتماعی", "SsoNumber"]));
  const overtimeHours = cellInt(pick(row, ["ساعات اضافه‌کاری", "اضافه‌کاری", "Overtime"]));

  if (!firstName) errors.push("نام الزامی است.");
  if (!lastName) errors.push("نام خانوادگی الزامی است.");
  if (!nationalId) errors.push("کد ملی الزامی است.");
  else if (!/^\d{10}$/.test(nationalId)) errors.push("کد ملی باید ۱۰ رقم باشد.");
  else if (!isValidNationalId(nationalId)) errors.push("رقم کنترل کد ملی نامعتبر است.");
  if (hireDateJ && !isValidJalali(hireDateJ)) errors.push("قالب تاریخ استخدام نامعتبر است (مثال: 1405/01/15).");
  else if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(hireDateJ)) {
    // نرمال‌سازی ماه/روز دورقمی
    const [y, m, d] = hireDateJ.split("/").map((x) => x.padStart(2, "0"));
    hireDateJ = `${y}/${m}/${d}`;
  }
  if (!baseSalaryToman || baseSalaryToman <= 0) errors.push("حقوق پایه الزامی و باید مثبت باشد (تومان).");
  if (gradeLevel !== null && (gradeLevel < 1 || gradeLevel > 7)) errors.push("سطح طبقه باید ۱ تا ۷ باشد.");
  if (iban && !/^IR\d{24}$/i.test(iban)) errors.push("شماره شبا نامعتبر است (فرمت IR + ۲۴ رقم).");

  return {
    data: {
      firstName,
      lastName,
      nationalId,
      mobile,
      email,
      hireDateJ,
      contractType,
      jobTitle,
      gradeLevel,
      baseSalary: Math.round(baseSalaryToman * 10), // تومان → ریال
      department,
      bankName,
      iban,
      maritalStatus,
      childCount,
      ssoNumber,
      overtimeHours,
    },
    errors,
  };
}

function EmployeeImportDialog({ open, onOpenChange, onImported }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onImported: (o: ImportOutcome) => void;
}) {
  return (
    <ExcelImportDialog<EmployeeImportRow>
      open={open}
      onOpenChange={onOpenChange}
      title="ایمپورت کارکنان از اکسل/CSV"
      description="ورود گروهی کارمند جدید — ردیف‌ها بر اساس کد ملی ایجاد یا به‌روزرسانی می‌شوند (کد ملی تکراری = ویرایش همان پرونده). تاریخ‌ها جلالی و حقوق پایه به تومان وارد شود."
      endpoint="/api/employees/import"
      templateFilename="قالب-کارکنان.xlsx"
      sheetName="کارکنان"
      headers={["نام*", "نام خانوادگی*", "کد ملی*", "موبایل", "ایمیل", "تاریخ استخدام (جلالی)", "نوع قرارداد", "عنوان شغل", "سطح (۱-۷)", "حقوق پایه (تومان)*", "دپارتمان", "بانک", "شبا", "وضعیت تأهل", "تعداد فرزند", "شماره بیمه"]}
      sampleRows={[
        { "نام": "آرش", "نام خانوادگی": "کامکاری", "کد ملی": "1295384761", "موبایل": "09121234567", "ایمیل": "arash@example.com", "تاریخ استخدام": "1404/05/01", "نوع قرارداد": "دائم", "عنوان شغل": "برنامه‌نویس ارشد", "سطح": 5, "حقوق پایه": "95000000", "دپارتمان": "فناوری اطلاعات", "بانک": "پارسیان", "شبا": "IR820540102680020817909002", "وضعیت تأهل": "متأهل", "تعداد فرزند": 1, "شماره بیمه": "51872639401" },
        { "نام": "مریم", "نام خانوادگی": "رستگار", "کد ملی": "0084571236", "موبایل": "09351234567", "ایمیل": "maryam@example.com", "تاریخ استخدام": "1405/01/15", "نوع قرارداد": "کارآموز", "عنوان شغل": "کارآموز منابع انسانی", "سطح": 2, "حقوق پایه": "18000000", "دپارتمان": "منابع انسانی", "بانک": "", "شبا": "", "وضعیت تأهل": "مجرد", "تعداد فرزند": 0, "شماره بیمه": "" },
      ]}
      parseRow={parseEmployeeRow}
      onImported={onImported}
    />
  );
}

function DocumentUploader({ employeeId, onUploaded }: { employeeId: string; onUploaded: () => void }) {
  const [type, setType] = useState("CONTRACT");
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  async function upload() {
    if (!file || !title.trim()) {
      toast({ title: "عنوان و فایل الزامی است", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.set("employeeId", employeeId);
      fd.set("type", type);
      fd.set("title", title);
      fd.set("file", file);
      const res = await fetch("/api/documents", { method: "POST", body: fd });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || "خطا در بارگذاری");
      }
      setTitle("");
      setFile(null);
      onUploaded();
      toast({ title: "سند بارگذاری شد", description: "در اسناد امن کارمند ذخیره گردید." });
    } catch (e) {
      toast({ title: "خطا در بارگذاری", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="rounded-xl border-2 border-dashed border-slate-200 p-4 bg-slate-50/50">
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
        <Field label="نوع سند">
          <Select value={type} onValueChange={setType}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(DOC_TYPE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </Field>
        <Field label="عنوان">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: قرارداد سال ۱۴۰۵" />
        </Field>
        <Field label="فایل (حداکثر ۵ مگابایت)">
          <Input type="file" className="text-xs" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        </Field>
        <Button onClick={upload} disabled={uploading} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
          <Upload className="w-4 h-4" /> {uploading ? "در حال بارگذاری..." : "بارگذاری"}
        </Button>
      </div>
      <p className="text-[11px] text-muted-foreground mt-2">اسناد حساس مانند قرارداد، سفته و چک ضمانت به‌صورت امن در دیتابیس ذخیره و در لاگ حسابرسی ثبت می‌شوند.</p>
    </div>
  );
}

"use client";

// ============================================================
// موتور محاسبه معکوس حقوق ۱۴۰۵ — رابط تعاملی
// ورودی: خالص پرداختی هدف → خروجی: حقوق پایه + تمام اجزا + جدول تکرار الگوریتم
// ============================================================
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { Calculator, Zap, Save, BookOpen, CheckCircle2, AlertTriangle, RotateCcw, Target, Percent, CalendarClock } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa, fmtPercent, EMPLOYMENT_TYPE_LABELS, SHIFT_PATTERN_LABELS } from "@/lib/format";
import { periodTitle, toFaDigits } from "@/lib/jalali";
import { MoneyInput, Money } from "../money-input";
import { StackBar } from "../charts";

interface ReverseResponse {
  result: {
    ok: boolean;
    targetNet: number;
    baseSalary: number;
    achievedNet: number;
    residual: number;
    iterations: { step: number; lower: number; upper: number; mid: number; netAtMid: number; error: number }[];
    iterationsCount: number;
    warnings: string[];
    notes: string[];
    paysheet: {
      baseSalary: number; seniority: number; housing: number; grocery: number; childAllowance: number;
      attraction: number; overtimeAmount: number; gross: number; insurableBase: number; employeeSso: number;
      employerSso20: number; unemploymentSso3: number; employerTotalSso: number; taxableIncome: number;
      incomeTax: number; netPay: number; employerTotalCost: number; warnings: string[];
      nightHours: number; nightAmount: number; fridayHours: number; fridayAmount: number;
      holidayHours: number; holidayAmount: number; shiftAllowance: number;
      absentDays: number; absenceDeduction: number;
    };
  };
  brackets: { sortOrder: number; lowerLimit: number; upperLimit: number | null; rate: number; taxableInBracket: number; tax: number }[];
  legal: {
    minWage: number; housing: number; grocery: number; childPerChild: number;
    employeeSsoRate: number; employerSsoRate: number; unemploymentRate: number;
    taxBrackets: { lowerLimit: number; upperLimit: number | null; rate: number }[];
  };
  savedPayslipId: string | null;
}

interface GradeRow { id: string; level: number; title: string; seniorityBase: number; attraction: number }
interface PeriodRow { id: string; year: number; month: number; status?: string }
interface EmployeeRow { id: string; fullName: string; personnelCode: string }

const PRESETS = [20, 25, 30, 50, 80, 120, 200];

export function ReverseView() {
  const { toast } = useToast();
  const grades = useApi<{ grades: GradeRow[] }>("/api/grades");
  const periods = useApi<{ periods: PeriodRow[] }>("/api/payroll/periods");
  const employees = useApi<{ employees: EmployeeRow[] }>("/api/employees");

  // ورودی‌ها
  const [targetNet, setTargetNet] = useState(50_000_000); // تومان
  const [gradeId, setGradeId] = useState("");
  const [childCount, setChildCount] = useState(0);
  const [seniorityYears, setSeniorityYears] = useState(0);
  const [housingOn, setHousingOn] = useState(true);
  const [groceryOn, setGroceryOn] = useState(true);
  const [otherAllowance, setOtherAllowance] = useState(0);
  const [rounding, setRounding] = useState("0");
  // شیفت/کارکرد — اقلامی که با حقوق پایه نسبت مستقیم دارند (در معادله لحاظ می‌شوند)
  const [employmentType, setEmploymentType] = useState("DAILY");
  const [shiftPattern, setShiftPattern] = useState("TWO_SHIFT");
  const [nightHours, setNightHours] = useState(0);
  const [fridayHours, setFridayHours] = useState(0);
  const [holidayHours, setHolidayHours] = useState(0);
  const [absentDays, setAbsentDays] = useState(0);

  const [result, setResult] = useState<ReverseResponse | null>(null);
  const [calculating, setCalculating] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);

  const selectedGrade = (grades.data?.grades || []).find((g) => g.id === gradeId);

  async function calculate() {
    if (targetNet <= 0) {
      toast({ title: "مبلغ خالص هدف را وارد کنید", variant: "destructive" });
      return;
    }
    setCalculating(true);
    setResult(null);
    try {
      const res = await api<ReverseResponse>("/api/payroll/reverse", {
        method: "POST",
        json: {
          targetNet: targetNet * 10, // تومان → ریال
          gradeId: gradeId || null,
          childCount,
          seniorityYears,
          housingEnabled: housingOn,
          groceryEnabled: groceryOn,
          otherAllowance: otherAllowance * 10,
          rounding: +rounding || null,
          employmentType,
          shiftPattern: employmentType === "SHIFT" ? shiftPattern : "",
          nightHours,
          fridayHours,
          holidayHours,
          absentDays,
        },
      });
      setResult(res);
      if (!res.result.ok) {
        toast({ title: "هدف قابل‌تحقق نیست", description: res.result.warnings[0] || "", variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "خطا در محاسبه", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setCalculating(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* پنل ورودی */}
        <Card className="xl:col-span-1 rounded-2xl h-fit xl:sticky xl:top-20">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Calculator className="w-4 h-4 text-teal-600" />
              ورودی محاسبه معکوس
            </CardTitle>
            <p className="text-xs text-muted-foreground mt-1">مبلغ خالص موردنظر را تعیین کنید؛ سامانه معادله حقوق را معکوس حل می‌کند.</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="rounded-xl bg-gradient-to-l from-teal-600 to-teal-700 p-4 text-white">
              <Label className="text-teal-100 text-xs">خالص پرداختی هدف (ماهانه)</Label>
              <div className="mt-2 [&_input]:text-white [&_input]:bg-white/10 [&_input]:border-white/20 [&_input]:placeholder:text-teal-200/50 [&_span]:text-teal-200">
                <MoneyInput value={targetNet} onChange={setTargetNet} unit="تومان" />
              </div>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {PRESETS.map((p) => (
                  <button
                    key={p}
                    onClick={() => setTargetNet(p * 1_000_000)}
                    className={`text-[11px] px-2.5 py-1 rounded-full transition-colors ${targetNet === p * 1_000_000 ? "bg-white text-teal-700 font-bold" : "bg-white/15 hover:bg-white/25 text-white"}`}
                  >
                    {groupFa(p)} میلیون
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs text-slate-600">طبقه شغلی (سنوات و جذب خودکار اعمال می‌شود)</Label>
              <Select value={gradeId || "none"} onValueChange={(v) => setGradeId(v === "none" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="بدون طبقه" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون طبقه (بدون سنوات و جذب)</SelectItem>
                  {(grades.data?.grades || []).map((g) => (
                    <SelectItem key={g.id} value={g.id}>سطح {toFaDigits(g.level)} — {g.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedGrade && (
                <p className="text-[11px] text-muted-foreground bg-slate-50 rounded-lg p-2 leading-4">
                  سنوات هر سال: <Money amount={selectedGrade.seniorityBase} short /> • حق جذب: <Money amount={selectedGrade.attraction} short />
                </p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">تعداد فرزند مشمول</Label>
                <Input type="number" min={0} max={4} className="tabular-nums" value={childCount} onChange={(e) => setChildCount(Math.max(0, +e.target.value || 0))} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">سال‌های سابقه (سنوات)</Label>
                <Input type="number" min={0} max={40} className="tabular-nums" value={seniorityYears} onChange={(e) => setSeniorityYears(Math.max(0, +e.target.value || 0))} />
              </div>
            </div>

            <div className="space-y-2.5">
              <div className="flex items-center justify-between rounded-xl border px-3.5 py-2.5">
                <div>
                  <p className="text-sm font-medium">حق مسکن</p>
                  <p className="text-[11px] text-muted-foreground tabular-nums">{result ? <Money amount={result.legal.housing} /> : "مطابق مصوبه ۱۴۰۵"}</p>
                </div>
                <Switch checked={housingOn} onCheckedChange={setHousingOn} />
              </div>
              <div className="flex items-center justify-between rounded-xl border px-3.5 py-2.5">
                <div>
                  <p className="text-sm font-medium">بن کارگری</p>
                  <p className="text-[11px] text-muted-foreground tabular-nums">{result ? <Money amount={result.legal.grocery} /> : "معاف از مالیات (ماده ۹۱)"}</p>
                </div>
                <Switch checked={groceryOn} onCheckedChange={setGroceryOn} />
              </div>
            </div>

            {/* شیفت و کارکرد — اقلام با نسبت مستقیم به پایه در معادله معکوس لحاظ می‌شوند */}
            <div className="rounded-xl border border-violet-200 bg-violet-50/40 p-3.5 space-y-3">
              <p className="text-xs font-bold text-violet-800 flex items-center gap-1.5">
                <CalendarClock className="w-3.5 h-3.5" />
                شیفت و کارکرد ماه (اختیاری)
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs text-slate-600">نوع اشتغال</Label>
                  <Select value={employmentType} onValueChange={setEmploymentType}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(EMPLOYMENT_TYPE_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {employmentType === "SHIFT" && (
                  <div className="space-y-1.5">
                    <Label className="text-xs text-slate-600">الگوی شیفت</Label>
                    <Select value={shiftPattern} onValueChange={setShiftPattern}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {Object.entries(SHIFT_PATTERN_LABELS).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="space-y-1">
                  <Label className="text-[11px] text-slate-600">شب‌کاری (ساعت)</Label>
                  <Input type="number" min={0} max={300} step="0.5" className="tabular-nums h-9" value={nightHours || ""} placeholder="۰" onChange={(e) => setNightHours(Math.max(0, Math.min(300, +e.target.value || 0)))} />
                </div>
                <div className="space-y-1">
                  <Label className="text-[11px] text-slate-600">جمعه‌کاری (ساعت)</Label>
                  <Input type="number" min={0} max={300} step="0.5" className="tabular-nums h-9" value={fridayHours || ""} placeholder="۰" onChange={(e) => setFridayHours(Math.max(0, Math.min(300, +e.target.value || 0)))} />
                </div>
                <div className="space-y-1">
                  <Label className="text-[11px] text-slate-600">تعطیل‌کاری (ساعت)</Label>
                  <Input type="number" min={0} max={300} step="0.5" className="tabular-nums h-9" value={holidayHours || ""} placeholder="۰" onChange={(e) => setHolidayHours(Math.max(0, Math.min(300, +e.target.value || 0)))} />
                </div>
                <div className="space-y-1">
                  <Label className="text-[11px] text-slate-600">غیبت (روز)</Label>
                  <Input type="number" min={0} max={30} className="tabular-nums h-9" value={absentDays || ""} placeholder="۰" onChange={(e) => setAbsentDays(Math.max(0, Math.min(30, +e.target.value || 0)))} />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground leading-4">
                فوق‌العاده‌های شب‌کاری (۳۵٪)، جمعه/تعطیل‌کاری (۴۰٪) و حق شیفت (۲۲.۵٪/۴۵٪) به حقوق پایه وابسته‌اند و در حل معادله لحاظ می‌شوند؛ ساعات را از کارکرد «حضور و غیب» همان ماه بردارید.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">سایر مزایا (اختیاری)</Label>
                <MoneyInput value={otherAllowance} onChange={setOtherAllowance} />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-slate-600">گرد کردن حقوق پایه</Label>
                <Select value={rounding} onValueChange={setRounding}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">بدون گرد کردن (دقیق)</SelectItem>
                    <SelectItem value="100000">۱۰ هزار تومان</SelectItem>
                    <SelectItem value="1000000">۱۰۰ هزار تومان</SelectItem>
                    <SelectItem value="10000000">۱ میلیون تومان</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <Button className="w-full h-11 gap-2 text-base font-bold" disabled={calculating} onClick={calculate}>
              {calculating ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {calculating ? "در حال حل معادله..." : "محاسبه معکوس"}
            </Button>
          </CardContent>
        </Card>

        {/* نتایج */}
        <div className="xl:col-span-2 space-y-4">
          {calculating && <Skeleton className="h-40 rounded-2xl" />}
          {!calculating && !result && (
            <Card className="rounded-2xl border-dashed">
              <CardContent className="py-16 text-center">
                <Target className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="font-medium text-slate-600">نتیجه محاسبه اینجا نمایش داده می‌شود</p>
                <p className="text-sm text-muted-foreground mt-2 max-w-md mx-auto leading-6">
                  مبلغ خالص پرداختی هدف را در پنل روبه‌رو وارد کنید. سامانه با الگوریتم دو-بخشی (Bisection) روی معادله غیرخطی
                  «خالص = ناخالص − بیمه ۷٪ − مالیات پلکانی»، حقوق پایه دقیق را می‌یابد.
                </p>
              </CardContent>
            </Card>
          )}

          {result && result.result.ok && <ReverseResultPanel res={result} onSave={() => setSaveOpen(true)} onDocs={() => (window.location.hash = "/docs")} />}
          {result && !result.result.ok && (
            <Card className="rounded-2xl border-rose-200 bg-rose-50">
              <CardContent className="p-5">
                <div className="flex items-center gap-2 text-rose-700 font-bold">
                  <AlertTriangle className="w-5 h-5" /> هدف قابل‌تحقق نیست
                </div>
                {(result.result.warnings || []).map((w, i) => <p key={i} className="text-sm text-rose-600 mt-2 leading-6">{w}</p>)}
                <p className="text-xs text-rose-500 mt-3 leading-5">
                  کمینه خالص با این مزایای ثابت، از ترکیب بن/مسکن/اولاد بدون مالیات حاصل می‌شود. هدف بالاتر یا مزایای کمتر انتخاب کنید.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* ذخیره فیش معکوس */}
      {result?.result.ok && (
        <SaveReverseDialog
          open={saveOpen}
          onOpenChange={setSaveOpen}
          periods={periods.data?.periods || []}
          employees={employees.data?.employees || []}
          targetNet={targetNet}
          gradeId={gradeId}
          childCount={childCount}
          seniorityYears={seniorityYears}
          housingOn={housingOn}
          groceryOn={groceryOn}
          otherAllowance={otherAllowance}
          rounding={rounding}
          employmentType={employmentType}
          shiftPattern={employmentType === "SHIFT" ? shiftPattern : ""}
          nightHours={nightHours}
          fridayHours={fridayHours}
          holidayHours={holidayHours}
          absentDays={absentDays}
          onSaved={() => toast({ title: "فیش معکوس ذخیره شد", description: "در دوره انتخابی ثبت و در لاگ حسابرسی گردید." })}
        />
      )}
    </div>
  );
}

// ================= پنل نتیجه =================
function ReverseResultPanel({ res, onSave, onDocs }: { res: ReverseResponse; onSave: () => void; onDocs: () => void }) {
  const r = res.result;
  const s = r.paysheet;
  const earnings = [
    { title: "حقوق پایه (معکوس‌شده)", amount: s.baseSalary, highlight: true },
    { title: "حق سنوات", amount: s.seniority },
    { title: "حق مسکن", amount: s.housing },
    { title: "بن کارگری", amount: s.grocery },
    { title: "حق اولاد", amount: s.childAllowance },
    { title: "حق جذب", amount: s.attraction },
  ];
  if (s.shiftAllowance > 0) earnings.push({ title: "حق شیفت (نوبتی‌کاری)", amount: s.shiftAllowance });
  if (s.nightAmount > 0) earnings.push({ title: `فوق‌العاده شب‌کاری (${toFaDigits(s.nightHours)} ساعت)`, amount: s.nightAmount });
  if (s.fridayAmount > 0) earnings.push({ title: `فوق‌العاده جمعه‌کاری (${toFaDigits(s.fridayHours)} ساعت)`, amount: s.fridayAmount });
  if (s.holidayAmount > 0) earnings.push({ title: `فوق‌العاده تعطیل‌کاری (${toFaDigits(s.holidayHours)} ساعت)`, amount: s.holidayAmount });
  earnings.push({
    title: "سایر مزایا",
    amount: s.gross - s.baseSalary - s.seniority - s.housing - s.grocery - s.childAllowance - s.attraction - s.shiftAllowance - s.nightAmount - s.fridayAmount - s.holidayAmount,
  });
  const filtered = earnings.filter((e) => e.amount !== 0 || e.highlight);

  return (
    <>
      {/* کارت‌های قهرمان */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Card className="rounded-2xl bg-gradient-to-br from-teal-600 to-teal-700 border-0 text-white">
          <CardContent className="p-4">
            <p className="text-xs text-teal-100 flex items-center gap-1.5"><Calculator className="w-3.5 h-3.5" /> حقوق پایه موردنیاز</p>
            <p className="text-2xl font-black mt-2 tabular-nums">{groupFa(Math.round(s.baseSalary / 10))}</p>
            <p className="text-[11px] text-teal-200 mt-1">تومان در ماه</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Target className="w-3.5 h-3.5" /> خالص محقق‌شده</p>
            <p className="text-2xl font-black mt-2 tabular-nums text-emerald-700">{groupFa(Math.round(r.achievedNet / 10))}</p>
            <p className="text-[11px] text-muted-foreground mt-1">تومان — هدف: {groupFa(Math.round(r.targetNet / 10))}</p>
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground flex items-center gap-1.5"><Percent className="w-3.5 h-3.5" /> خطای محاسبه</p>
            <p className={`text-2xl font-black mt-2 tabular-nums ${Math.abs(r.residual) <= 10 ? "text-emerald-600" : "text-amber-600"}`}>
              {groupFa(Math.round(Math.abs(r.residual / 10)))} <span className="text-sm font-normal">تومان</span>
            </p>
            <p className="text-[11px] text-muted-foreground mt-1">در {toFaDigits(r.iterationsCount)} تکرار الگوریتم</p>
          </CardContent>
        </Card>
      </div>

      {(r.warnings.length > 0 || r.notes.length > 0) && (
        <Card className="rounded-2xl border-amber-200 bg-amber-50/60">
          <CardContent className="p-4 space-y-1.5">
            {r.warnings.map((w, i) => (
              <p key={i} className="text-xs text-amber-800 flex gap-2 leading-5"><AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" /> {w}</p>
            ))}
            {r.notes.map((n, i) => (
              <p key={`n${i}`} className="text-xs text-slate-600 flex gap-2 leading-5"><CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5 text-teal-600" /> {n}</p>
            ))}
          </CardContent>
        </Card>
      )}

      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            ساختار حقوق حاصل از محاسبه معکوس
            <Badge variant="outline" className="font-normal">جمع هزینه کارفرما: <Money amount={s.employerTotalCost} /></Badge>
            <div className="mr-auto flex gap-2">
              <Button size="sm" variant="outline" className="gap-1.5" onClick={onDocs}><BookOpen className="w-3.5 h-3.5" /> الگوریتم</Button>
              <Button size="sm" className="gap-1.5 bg-teal-600 hover:bg-teal-700" onClick={onSave}><Save className="w-3.5 h-3.5" /> ذخیره به‌عنوان فیش</Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="breakdown" dir="rtl">
            <TabsList>
              <TabsTrigger value="breakdown">تجزیه حقوق</TabsTrigger>
              <TabsTrigger value="tax">پله‌های مالیات</TabsTrigger>
              <TabsTrigger value="iterations">جدول تکرار الگوریتم</TabsTrigger>
            </TabsList>

            <TabsContent value="breakdown" className="mt-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/80">
                      <TableHead className="text-right">شرح</TableHead>
                      <TableHead className="text-left">مبلغ</TableHead>
                      <TableHead className="text-center">بیمه‌پذیر</TableHead>
                      <TableHead className="text-center">مشمول مالیات</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((e, i) => (
                      <TableRow key={i} className={e.highlight ? "bg-teal-50/60 font-bold" : ""}>
                        <TableCell className={e.highlight ? "text-teal-800" : ""}>{e.title}</TableCell>
                        <TableCell className="text-left tabular-nums"><Money amount={e.amount} /></TableCell>
                        <TableCell className="text-center text-[11px]">{["حقوق پایه", "اضافه‌کاری", "شب‌کاری", "جمعه‌کاری", "تعطیل‌کاری", "حق شیفت"].some((k) => e.title.includes(k)) ? "بله" : "—"}</TableCell>
                        <TableCell className="text-center text-[11px]">{e.title.includes("بن") ? "معاف (ماده ۹۱)" : "بله"}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="bg-slate-100 font-bold">
                      <TableCell>جمع حقوق و مزایا (ناخالص)</TableCell>
                      <TableCell className="text-left tabular-nums"><Money amount={s.gross} /></TableCell>
                      <TableCell colSpan={2} />
                    </TableRow>
                    <TableRow>
                      <TableCell>مشمول بیمه (کمینه = حداقل دستمزد ۱۴۰۵)</TableCell>
                      <TableCell className="text-left tabular-nums"><Money amount={s.insurableBase} /></TableCell>
                      <TableCell colSpan={2} className="text-center text-[11px] text-muted-foreground">سهم کارفرما ۲۳٪ = <Money amount={s.employerTotalSso} /></TableCell>
                    </TableRow>
                    <TableRow className="text-rose-700">
                      <TableCell>کسور: بیمه سهم کارمند (۷٪)</TableCell>
                      <TableCell className="text-left tabular-nums text-rose-700"><Money amount={-s.employeeSso} /></TableCell>
                      <TableCell colSpan={2} />
                    </TableRow>
                    <TableRow className="text-rose-700">
                      <TableCell>کسور: مالیات حقوق (پلکانی ۱۴۰۵)</TableCell>
                      <TableCell className="text-left tabular-nums text-rose-700"><Money amount={-s.incomeTax} /></TableCell>
                      <TableCell colSpan={2} className="text-center text-[11px] text-muted-foreground">درآمد مشمول: <Money amount={s.taxableIncome} /></TableCell>
                    </TableRow>
                    {s.absenceDeduction > 0 && (
                      <TableRow className="text-rose-700">
                        <TableCell>کسور: کسر مزد غیبت ({toFaDigits(s.absentDays)} روز)</TableCell>
                        <TableCell className="text-left tabular-nums text-rose-700"><Money amount={-s.absenceDeduction} /></TableCell>
                        <TableCell colSpan={2} />
                      </TableRow>
                    )}
                    <TableRow className="bg-emerald-50 font-black text-emerald-800 border-t-2 border-emerald-200">
                      <TableCell>خالص پرداختی</TableCell>
                      <TableCell className="text-left tabular-nums"><Money amount={s.netPay} /></TableCell>
                      <TableCell colSpan={2} />
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              {/* ترکیب هزینه */}
              <div className="mt-6 pt-5 border-t">
                <p className="text-sm font-bold mb-3">ترکیب کل هزینه کارفرما (ماهانه)</p>
                <StackBar
                  parts={[
                    { label: "حقوق پایه", value: s.baseSalary, color: "#0d9488" },
                    { label: "مزایای قانونی", value: s.gross - s.baseSalary, color: "#14b8a6" },
                    { label: "بیمه کارفرما ۲۳٪", value: s.employerTotalSso, color: "#f59e0b" },
                  ]}
                />
              </div>
            </TabsContent>

            <TabsContent value="tax" className="mt-4">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/80">
                      <TableHead className="text-right">پله (ماده ۸۵ بودجه ۱۴۰۵)</TableHead>
                      <TableHead className="text-left">نرخ</TableHead>
                      <TableHead className="text-left">مبلغ مشمول این پله</TableHead>
                      <TableHead className="text-left">مالیات پله</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {res.brackets.map((b) => (
                      <TableRow key={b.sortOrder} className={b.taxableInBracket > 0 ? "bg-teal-50/40" : "opacity-50"}>
                        <TableCell>
                          پله {toFaDigits(b.sortOrder)}: {b.upperLimit === null ? `مازاد بر ${groupFa(Math.round(b.lowerLimit / 10))}` : `${groupFa(Math.round(b.lowerLimit / 10))} تا ${b.upperLimit === null ? "∞" : groupFa(Math.round(b.upperLimit / 10))}`} تومان
                        </TableCell>
                        <TableCell className="text-left tabular-nums">{fmtPercent(b.rate)}</TableCell>
                        <TableCell className="text-left tabular-nums">{b.taxableInBracket > 0 ? <Money amount={b.taxableInBracket} /> : "—"}</TableCell>
                        <TableCell className="text-left tabular-nums font-medium">{b.tax > 0 ? <Money amount={b.tax} /> : "—"}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="bg-slate-100 font-bold">
                      <TableCell colSpan={2}>جمع مالیات ماهانه</TableCell>
                      <TableCell className="text-left tabular-nums">درآمد مشمول: <Money amount={s.taxableIncome} /></TableCell>
                      <TableCell className="text-left tabular-nums text-rose-700"><Money amount={s.incomeTax} /></TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="iterations" className="mt-4">
              <p className="text-xs text-muted-foreground mb-3 leading-5">
                الگوریتم دو-بخشی بازه [کران پایین، کران بالا] را در هر گام نصف می‌کند و خالصِ نقطه میانی را با هدف مقایسه می‌کند.
                ستون «اختلاف» منفی یعنی خالص کمتر از هدف است و جستجو به سمت حقوق بالاتر می‌رود.
              </p>
              <div className="overflow-x-auto max-h-96 overflow-y-auto rounded-xl border">
                <Table>
                  <TableHeader className="sticky top-0">
                    <TableRow className="bg-slate-100">
                      <TableHead className="text-center">گام</TableHead>
                      <TableHead className="text-left">کرن پایین (تومان)</TableHead>
                      <TableHead className="text-left">کرن بالا (تومان)</TableHead>
                      <TableHead className="text-left">حقوق آزمایش (تومان)</TableHead>
                      <TableHead className="text-left">خالص حاصل (تومان)</TableHead>
                      <TableHead className="text-left">اختلاف با هدف</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {r.iterations.map((it) => (
                      <TableRow key={it.step} className={Math.abs(it.error) < 1000 ? "bg-emerald-50 font-bold" : ""}>
                        <TableCell className="text-center tabular-nums">{toFaDigits(it.step)}</TableCell>
                        <TableCell className="text-left tabular-nums text-xs">{groupFa(Math.round(it.lower / 10))}</TableCell>
                        <TableCell className="text-left tabular-nums text-xs">{groupFa(Math.round(it.upper / 10))}</TableCell>
                        <TableCell className="text-left tabular-nums text-sm font-medium text-teal-700">{groupFa(Math.round(it.mid / 10))}</TableCell>
                        <TableCell className="text-left tabular-nums text-sm">{groupFa(Math.round(it.netAtMid / 10))}</TableCell>
                        <TableCell className={`text-left tabular-nums text-xs ${it.error > 0 ? "text-rose-600" : "text-emerald-700"}`}>
                          {it.error > 0 ? "+" : ""}{groupFa(Math.round(it.error / 10))}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </>
  );
}

// ================= دیالوگ ذخیره =================
function SaveReverseDialog(props: {
  open: boolean; onOpenChange: (v: boolean) => void;
  periods: PeriodRow[]; employees: EmployeeRow[];
  targetNet: number; gradeId: string; childCount: number; seniorityYears: number;
  housingOn: boolean; groceryOn: boolean; otherAllowance: number; rounding: string;
  employmentType: string; shiftPattern: string;
  nightHours: number; fridayHours: number; holidayHours: number; absentDays: number;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [periodId, setPeriodId] = useState("");
  const [employeeId, setEmployeeId] = useState("");
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    const list = props.employees || [];
    if (!q) return list.slice(0, 50);
    return list.filter((e) => e.fullName.includes(q) || e.personnelCode.includes(q)).slice(0, 50);
  }, [props.employees, q]);

  async function save() {
    if (!periodId || !employeeId) {
      toast({ title: "انتخاب دوره و کارمند الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/payroll/reverse", {
        method: "POST",
        json: {
          targetNet: props.targetNet * 10,
          gradeId: props.gradeId || null,
          childCount: props.childCount,
          seniorityYears: props.seniorityYears,
          housingEnabled: props.housingOn,
          groceryEnabled: props.groceryOn,
          otherAllowance: props.otherAllowance * 10,
          rounding: +props.rounding || null,
          employmentType: props.employmentType,
          shiftPattern: props.shiftPattern,
          nightHours: props.nightHours,
          fridayHours: props.fridayHours,
          holidayHours: props.holidayHours,
          absentDays: props.absentDays,
          save: { periodId, employeeId },
        },
      });
      props.onOpenChange(false);
      props.onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={props.open} onOpenChange={props.onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle>ذخیره فیش معکوس</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <p className="text-xs text-muted-foreground bg-slate-50 rounded-lg p-3 leading-5">
            فیش معکوس جایگزین فیش عادی کارمند در دوره انتخابی می‌شود و با برچسب «معکوس» مشخص می‌گردد.
          </p>
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-600">دوره حقوق</Label>
            <Select value={periodId} onValueChange={setPeriodId}>
              <SelectTrigger><SelectValue placeholder="انتخاب دوره" /></SelectTrigger>
              <SelectContent>
                {props.periods.filter((p) => p.status !== "PAID").map((p) => (
                  <SelectItem key={p.id} value={p.id}>{periodTitle(p.year, p.month)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-slate-600">کارمند</Label>
            <Input placeholder="جستجوی نام..." value={q} onChange={(e) => setQ(e.target.value)} className="mb-1.5" />
            <Select value={employeeId} onValueChange={setEmployeeId}>
              <SelectTrigger><SelectValue placeholder="انتخاب کارمند" /></SelectTrigger>
              <SelectContent>
                {filtered.map((e) => (
                  <SelectItem key={e.id} value={e.id}>{e.fullName} ({e.personnelCode})</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => props.onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره فیش"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ============================================================
// مدیریت تغییرات حقوق — پیش‌نویس (ذخیره موقت) + اعمال + لاگ/آرشیو
// گردش کار: تغییر (فردی/گروهی/معکوس) ← پیش‌نویس PENDING
//           ← «تأیید و اعمال» ← به‌روزرسانی پرونده + ثبت در لاگ/آرشیو
// ============================================================
import { db } from "@/lib/db";
import type { SessionUser } from "@/lib/auth";
import { audit } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import {
  computePaysheet,
  contextFromEmployee,
  shiftRateOf,
  type LegalParams,
  type PaysheetResult,
} from "@/lib/payroll/engine";
import { solveBaseForNet } from "@/lib/payroll/solve";
import { todayJalaliStr } from "@/lib/jalali";

// ------------------- انواع -------------------

export type SalaryDraftRecord = {
  id: string;
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  oldBaseSalary: number;
  newBaseSalary: number;
  oldOvertimeHours: number;
  newOvertimeHours: number;
  oldJobGradeId: string | null;
  newJobGradeId: string | null;
  oldGradeTitle: string;
  newGradeTitle: string;
  oldNet: number;
  newNet: number;
  targetNet: number | null;
  source: string;
  reason: string;
  status: string;
  createdBy: string;
  createdByName: string;
  createdAt: string;
  decidedBy: string;
  decidedByName: string;
  decidedAt: string | null;
};

export type SalaryLogRecord = {
  id: string;
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  oldBaseSalary: number;
  newBaseSalary: number;
  oldOvertimeHours: number;
  newOvertimeHours: number;
  oldGradeTitle: string;
  newGradeTitle: string;
  deltaAmount: number;
  deltaPercent: number;
  oldNet: number;
  newNet: number;
  source: string;
  reason: string;
  draftId: string;
  performedBy: string;
  performedByName: string;
  performedAt: string;
};

/** کارمند سبک برای محاسبه خالص تخمینی ماهانه */
export interface EmployeeSalaryLike {
  id: string;
  firstName: string;
  lastName: string;
  personnelCode: string;
  status: string;
  baseSalary: bigint;
  overtimeHours: number;
  childCount: number;
  maritalStatus: string;
  hireDateJ: string;
  employmentType?: string | null;
  shiftPattern?: string | null;
  jobGradeId?: string | null;
  jobGrade?: { id: string; level: number; title: string; seniorityBase: bigint; attraction: bigint } | null;
}
// ------------------- محاسبه خالص تخمینی -------------------

/** خالص ماهانه تخمینی کارمند با مقادیر فعلی (فرض کارکرد پیش‌فرض پرسنلی) */
export function estimateNet(
  emp: EmployeeSalaryLike,
  params: LegalParams,
  atDateJ: string
): PaysheetResult {
  const ctx = contextFromEmployee(
    {
      baseSalary: emp.baseSalary,
      childCount: emp.childCount,
      maritalStatus: emp.maritalStatus,
      overtimeHours: emp.overtimeHours,
      hireDateJ: emp.hireDateJ,
      employmentType: emp.employmentType || undefined,
      shiftPattern: emp.shiftPattern || undefined,
    },
    emp.jobGrade ?? null,
    atDateJ
  );
  ctx.shiftRate = shiftRateOf(emp.employmentType || undefined, emp.shiftPattern || undefined, params);
  return computePaysheet(Number(emp.baseSalary), ctx, params);
}

/** خالص ماهانه تخمینی با مقادیر جایگزین (پایه/اضافه‌کاری/طبقه جدید) */
export function estimateNetWith(
  emp: EmployeeSalaryLike,
  params: LegalParams,
  atDateJ: string,
  override: { baseSalary?: number; overtimeHours?: number; grade?: { id: string; level: number; title: string; seniorityBase: bigint; attraction: bigint } | null }
): PaysheetResult {
  const merged: EmployeeSalaryLike = {
    ...emp,
    baseSalary: BigInt(Math.max(0, Math.round(override.baseSalary ?? Number(emp.baseSalary)))),
    overtimeHours: override.overtimeHours ?? emp.overtimeHours,
    jobGradeId: override.grade ? override.grade.id : emp.jobGradeId,
    jobGrade: (override.grade !== undefined ? override.grade : emp.jobGrade) ?? null,
  };
  return estimateNet(merged, params, atDateJ);
}

// ------------------- سریالایزرها -------------------

export function serializeDraft(d: Record<string, unknown> & { employee?: Record<string, unknown> | null }): SalaryDraftRecord {
  const emp = (d.employee || {}) as Record<string, unknown>;
  return {
    id: d.id as string,
    employeeId: d.employeeId as string,
    employeeName: emp.firstName ? `${emp.firstName} ${emp.lastName}` : ((d as { employeeNameFallback?: string }).employeeNameFallback || ""),
    personnelCode: (emp.personnelCode as string) || "",
    oldBaseSalary: Number(d.oldBaseSalary || 0),
    newBaseSalary: Number(d.newBaseSalary || 0),
    oldOvertimeHours: (d.oldOvertimeHours as number) || 0,
    newOvertimeHours: (d.newOvertimeHours as number) || 0,
    oldJobGradeId: (d.oldJobGradeId as string) || null,
    newJobGradeId: (d.newJobGradeId as string) || null,
    oldGradeTitle: (d.oldGradeTitle as string) || "",
    newGradeTitle: (d.newGradeTitle as string) || "",
    oldNet: Number(d.oldNet || 0),
    newNet: Number(d.newNet || 0),
    targetNet: d.targetNet === null || d.targetNet === undefined ? null : Number(d.targetNet),
    source: (d.source as string) || "MANUAL",
    reason: (d.reason as string) || "",
    status: (d.status as string) || "PENDING",
    createdBy: (d.createdBy as string) || "",
    createdByName: (d.createdByName as string) || "",
    createdAt: (d.createdAt as Date).toISOString(),
    decidedBy: (d.decidedBy as string) || "",
    decidedByName: (d.decidedByName as string) || "",
    decidedAt: d.decidedAt ? (d.decidedAt as Date).toISOString() : null,
  };
}

export function serializeLog(l: Record<string, unknown>): SalaryLogRecord {
  return {
    id: l.id as string,
    employeeId: l.employeeId as string,
    employeeName: (l.employeeName as string) || "",
    personnelCode: (l.personnelCode as string) || "",
    oldBaseSalary: Number(l.oldBaseSalary || 0),
    newBaseSalary: Number(l.newBaseSalary || 0),
    oldOvertimeHours: (l.oldOvertimeHours as number) || 0,
    newOvertimeHours: (l.newOvertimeHours as number) || 0,
    oldGradeTitle: (l.oldGradeTitle as string) || "",
    newGradeTitle: (l.newGradeTitle as string) || "",
    deltaAmount: Number(l.deltaAmount || 0),
    deltaPercent: (l.deltaPercent as number) || 0,
    oldNet: Number(l.oldNet || 0),
    newNet: Number(l.newNet || 0),
    source: (l.source as string) || "MANUAL",
    reason: (l.reason as string) || "",
    draftId: (l.draftId as string) || "",
    performedBy: (l.performedBy as string) || "",
    performedByName: (l.performedByName as string) || "",
    performedAt: (l.performedAt as Date).toISOString(),
  };
}

/** حل معکوس پایه برای خالص هدف — با زمینه کامل کارمند (شامل اضافه‌کاری پیش‌فرض/شیفت) */
export function solveEmployeeBaseForNet(
  emp: EmployeeSalaryLike,
  params: LegalParams,
  atDateJ: string,
  targetNet: number
): { ok: boolean; baseSalary: number; achievedNet: number; residual: number; minAchievableNet: number } {
  const ctx = contextFromEmployee(
    {
      baseSalary: emp.baseSalary,
      childCount: emp.childCount,
      maritalStatus: emp.maritalStatus,
      overtimeHours: emp.overtimeHours,
      hireDateJ: emp.hireDateJ,
      employmentType: emp.employmentType || undefined,
      shiftPattern: emp.shiftPattern || undefined,
    },
    emp.jobGrade ?? null,
    atDateJ
  );
  ctx.shiftRate = shiftRateOf(emp.employmentType || undefined, emp.shiftPattern || undefined, params);
  const r = solveBaseForNet(Math.round(targetNet), ctx, params);
  return { ok: r.ok, baseSalary: r.baseSalary, achievedNet: r.achievedNet, residual: r.residual, minAchievableNet: r.minAchievableNet };
}

// ------------------- ساخت/به‌روزرسانی پیش‌نویس -------------------

export interface DraftInput {
  employeeId: string;
  newBaseSalary: number; // ریال
  newOvertimeHours: number;
  newJobGradeId?: string | null; // null = بدون تغییر
  targetNet?: number | null;
  source: string;
  reason?: string;
}

/**
 * ثبت پیش‌نویس (ذخیره موقت) — به ازای هر کارمند حداکثر یک پیش‌نویس PENDING:
 * ثبت مجدد، پیش‌نویس قبلی همان کارمند را به‌روزرسانی می‌کند.
 */
export async function upsertDrafts(session: SessionUser, inputs: DraftInput[]): Promise<{ created: number; updated: number; skipped: number }> {
  const params = await getLegalParams();
  const atDateJ = todayJalaliStr();
  let created = 0;
  let updated = 0;
  let skipped = 0;

  for (const input of inputs) {
    const emp = await db.employee.findUnique({
      where: { id: input.employeeId },
      include: { jobGrade: true },
    });
    if (!emp) {
      skipped += 1;
      continue;
    }
    const newBase = Math.max(0, Math.round(input.newBaseSalary || 0));
    if (newBase <= 0) {
      skipped += 1;
      continue;
    }

    let newGrade: { id: string; level: number; title: string; seniorityBase: bigint; attraction: bigint } | null = null;
    if (input.newJobGradeId) {
      const g = await db.jobGrade.findUnique({ where: { id: input.newJobGradeId } });
      if (g) newGrade = { id: g.id, level: g.level, title: g.title, seniorityBase: g.seniorityBase, attraction: g.attraction };
    }

    const oldNet = estimateNet(emp as unknown as EmployeeSalaryLike, params, atDateJ).netPay;
    const newNet = estimateNetWith(emp as unknown as EmployeeSalaryLike, params, atDateJ, {
      baseSalary: newBase,
      overtimeHours: Math.max(0, input.newOvertimeHours || 0),
      grade: newGrade,
    }).netPay;

    const data = {
      oldBaseSalary: emp.baseSalary,
      newBaseSalary: BigInt(newBase),
      oldOvertimeHours: emp.overtimeHours,
      newOvertimeHours: Math.max(0, input.newOvertimeHours || 0),
      oldJobGradeId: emp.jobGradeId,
      newJobGradeId: input.newJobGradeId || null,
      oldGradeTitle: emp.jobGrade?.title || "",
      newGradeTitle: newGrade?.title || (input.newJobGradeId ? "" : emp.jobGrade?.title || ""),
      oldNet: BigInt(oldNet),
      newNet: BigInt(newNet),
      targetNet: input.targetNet ? BigInt(Math.round(input.targetNet)) : null,
      source: input.source,
      reason: (input.reason || "").slice(0, 500),
      status: "PENDING",
      createdBy: session.uid,
      createdByName: session.fullName,
    };

    const existing = await db.salaryDraft.findFirst({
      where: { employeeId: emp.id, status: "PENDING" },
    });
    if (existing) {
      await db.salaryDraft.update({ where: { id: existing.id }, data });
      updated += 1;
    } else {
      await db.salaryDraft.create({ data: { ...data, employeeId: emp.id } });
      created += 1;
    }
  }

  return { created, updated, skipped };
}

// ------------------- اعمال / رد پیش‌نویس -------------------

/** تأیید و اعمال پیش‌نویس‌ها روی پرونده کارکنان + ثبت لاگ/آرشیو */
export async function applyDrafts(
  session: SessionUser,
  ids: string[] | "ALL",
  note?: string
): Promise<{ applied: number; logs: SalaryLogRecord[]; totalDelta: number }> {
  const params = await getLegalParams();
  const atDateJ = todayJalaliStr();
  const drafts = await db.salaryDraft.findMany({
    where: { status: "PENDING", ...(ids === "ALL" ? {} : { id: { in: ids } }) },
    include: { employee: { include: { jobGrade: true } } },
    orderBy: { createdAt: "asc" },
  });

  const logs: SalaryLogRecord[] = [];
  let applied = 0;
  let totalDelta = 0;

  for (const draft of drafts) {
    const emp = draft.employee;
    // مقادیر «قدیم» از وضعیت زنده کارمند در لحظه اعمال (نه زمان ثبت پیش‌نویس)
    const liveOldBase = Number(emp.baseSalary);
    const liveOldOvertime = emp.overtimeHours;
    const liveOldGrade = emp.jobGrade;

    const newBase = Number(draft.newBaseSalary);
    const newOvertime = Number(draft.newOvertimeHours);
    const newGradeId = draft.newJobGradeId || null;
    let newGrade = liveOldGrade;
    if (newGradeId && newGradeId !== liveOldGrade?.id) {
      newGrade = await db.jobGrade.findUnique({ where: { id: newGradeId } });
    }

    const oldNet = estimateNet(emp as unknown as EmployeeSalaryLike, params, atDateJ).netPay;

    // به‌روزرسانی پرونده کارمند
    await db.employee.update({
      where: { id: emp.id },
      data: {
        baseSalary: BigInt(newBase),
        overtimeHours: newOvertime,
        ...(newGradeId ? { jobGradeId: newGradeId } : {}),
      },
    });

    const newNet = estimateNetWith(emp as unknown as EmployeeSalaryLike, params, atDateJ, {
      baseSalary: newBase,
      overtimeHours: newOvertime,
      grade: newGrade
        ? { id: newGrade.id, level: newGrade.level, title: newGrade.title, seniorityBase: newGrade.seniorityBase, attraction: newGrade.attraction }
        : null,
    }).netPay;

    const deltaAmount = newBase - liveOldBase;
    const deltaPercent = liveOldBase > 0 ? (deltaAmount / liveOldBase) * 100 : 0;
    totalDelta += deltaAmount;

    const log = await db.salaryChangeLog.create({
      data: {
        employeeId: emp.id,
        employeeName: `${emp.firstName} ${emp.lastName}`,
        personnelCode: emp.personnelCode,
        oldBaseSalary: BigInt(liveOldBase),
        newBaseSalary: BigInt(newBase),
        oldOvertimeHours: liveOldOvertime,
        newOvertimeHours: newOvertime,
        oldJobGradeId: liveOldGrade?.id || null,
        newJobGradeId: newGradeId,
        oldGradeTitle: liveOldGrade?.title || "",
        newGradeTitle: newGrade?.title || draft.newGradeTitle || "",
        deltaAmount: BigInt(deltaAmount),
        deltaPercent: Math.round(deltaPercent * 100) / 100,
        oldNet: BigInt(oldNet),
        newNet: BigInt(newNet),
        source: draft.source,
        reason: [draft.reason, note].filter(Boolean).join(" — ").slice(0, 500),
        draftId: draft.id,
        performedBy: session.uid,
        performedByName: session.fullName,
      },
    });
    logs.push(serializeLog(log as unknown as Record<string, unknown>));

    await db.salaryDraft.update({
      where: { id: draft.id },
      data: {
        status: "APPLIED",
        decidedBy: session.uid,
        decidedByName: session.fullName,
        decidedAt: new Date(),
      },
    });
    applied += 1;
  }

  if (applied > 0) {
    await audit(
      session,
      "APPROVE",
      "SALARY_DRAFT",
      ids === "ALL" ? "ALL" : ids.join(","),
      `اعمال ${applied} تغییر حقوق (پیش‌نویس تأییدشده) — جمع تغییر پایه: ${totalDelta.toLocaleString("en-US")} ریال`,
      undefined,
      { applied, totalDelta }
    );
  }

  return { applied, logs, totalDelta };
}

/** رد/حذف پیش‌نویس‌های در انتظار */
export async function discardDrafts(
  session: SessionUser,
  ids: string[] | "ALL"
): Promise<number> {
  const drafts = await db.salaryDraft.findMany({
    where: { status: "PENDING", ...(ids === "ALL" ? {} : { id: { in: ids } }) },
    include: { employee: true },
  });
  for (const d of drafts) {
    await db.salaryDraft.update({
      where: { id: d.id },
      data: {
        status: "DISCARDED",
        decidedBy: session.uid,
        decidedByName: session.fullName,
        decidedAt: new Date(),
      },
    });
  }
  if (drafts.length > 0) {
    await audit(
      session,
      "DELETE",
      "SALARY_DRAFT",
      ids === "ALL" ? "ALL" : ids.join(","),
      `رد ${drafts.length} پیش‌نویس تغییر حقوق`
    );
  }
  return drafts.length;
}

// ------------------- لاگ تغییر مستقیم (فرم ویرایش کارکنان) -------------------

/** ثبت تغییر مستقیم حقوق (بدون پیش‌نویس) در لاگ/آرشیو — برای مسیر ویرایش پرونده */
export async function logDirectSalaryChange(
  session: SessionUser | null,
  empBefore: { id: string; firstName: string; lastName: string; personnelCode: string; status: string; baseSalary: bigint; overtimeHours: number; jobGradeId: string | null; jobGradeTitle: string; childCount: number; maritalStatus: string; hireDateJ: string; employmentType: string | null; shiftPattern: string | null; },
  empAfter: { baseSalary: bigint; overtimeHours: number; jobGradeId: string | null; jobGradeTitle: string }
): Promise<void> {
  const oldBase = Number(empBefore.baseSalary);
  const newBase = Number(empAfter.baseSalary);
  if (oldBase === newBase && empBefore.overtimeHours === empAfter.overtimeHours && empBefore.jobGradeId === empAfter.jobGradeId) {
    return; // تغییری در حقوق رخ نداده است
  }
  const params = await getLegalParams();
  const atDateJ = todayJalaliStr();
  const oldGrade = empBefore.jobGradeId
    ? await db.jobGrade.findUnique({ where: { id: empBefore.jobGradeId } })
    : null;
  const newGrade = empAfter.jobGradeId
    ? await db.jobGrade.findUnique({ where: { id: empAfter.jobGradeId } })
    : null;

  const oldNet = estimateNet(
    { ...empBefore, jobGrade: oldGrade ? { id: oldGrade.id, level: oldGrade.level, title: oldGrade.title, seniorityBase: oldGrade.seniorityBase, attraction: oldGrade.attraction } : null } as unknown as EmployeeSalaryLike,
    params,
    atDateJ
  ).netPay;
  const newNet = estimateNetWith(
    { ...empBefore, jobGrade: oldGrade ? { id: oldGrade.id, level: oldGrade.level, title: oldGrade.title, seniorityBase: oldGrade.seniorityBase, attraction: oldGrade.attraction } : null } as unknown as EmployeeSalaryLike,
    params,
    atDateJ,
    {
      baseSalary: newBase,
      overtimeHours: empAfter.overtimeHours,
      grade: newGrade ? { id: newGrade.id, level: newGrade.level, title: newGrade.title, seniorityBase: newGrade.seniorityBase, attraction: newGrade.attraction } : null,
    }
  ).netPay;

  const deltaAmount = newBase - oldBase;
  const deltaPercent = oldBase > 0 ? (deltaAmount / oldBase) * 100 : 0;

  await db.salaryChangeLog.create({
    data: {
      employeeId: empBefore.id,
      employeeName: `${empBefore.firstName} ${empBefore.lastName}`,
      personnelCode: empBefore.personnelCode,
      oldBaseSalary: BigInt(oldBase),
      newBaseSalary: BigInt(newBase),
      oldOvertimeHours: empBefore.overtimeHours,
      newOvertimeHours: empAfter.overtimeHours,
      oldJobGradeId: empBefore.jobGradeId,
      newJobGradeId: empAfter.jobGradeId,
      oldGradeTitle: empBefore.jobGradeTitle,
      newGradeTitle: empAfter.jobGradeTitle,
      deltaAmount: BigInt(deltaAmount),
      deltaPercent: Math.round(deltaPercent * 100) / 100,
      oldNet: BigInt(oldNet),
      newNet: BigInt(newNet),
      source: "EDIT",
      reason: "ویرایش مستقیم پرونده کارمند",
      draftId: "",
      performedBy: session?.uid || "",
      performedByName: session?.fullName || "system",
    },
  });
}

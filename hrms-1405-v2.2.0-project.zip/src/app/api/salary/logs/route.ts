import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { serializeLog } from "@/lib/salary";

/**
 * GET /api/salary/logs?employeeId=&source=&limit=
 * لاگ و آرشیو تغییرات حقوق — همیشه در دسترس (مجوز salary:view)
 * source: MANUAL | BULK | REVERSE | EDIT
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "salary:view");
    const employeeId = req.nextUrl.searchParams.get("employeeId") || "";
    const source = req.nextUrl.searchParams.get("source") || "";
    const limit = Math.min(1000, Math.max(1, +(req.nextUrl.searchParams.get("limit") || 300)));

    const where = {
      ...(employeeId ? { employeeId } : {}),
      ...(source ? { source } : {}),
    };
    const logs = await db.salaryChangeLog.findMany({
      where,
      orderBy: { performedAt: "desc" },
      take: limit,
    });

    // آمار کلی آرشیو
    const [totalCount, increaseCount, decreaseCount, sumDelta] = await Promise.all([
      db.salaryChangeLog.count(),
      db.salaryChangeLog.count({ where: { deltaAmount: { gt: 0 } } }),
      db.salaryChangeLog.count({ where: { deltaAmount: { lt: 0 } } }),
      db.salaryChangeLog.aggregate({ _sum: { deltaAmount: true } }),
    ]);

    return {
      logs: logs.map((l) => serializeLog(l as unknown as Record<string, unknown>)),
      stats: {
        totalCount,
        increaseCount,
        decreaseCount,
        sumDelta: Number(sumDelta._sum.deltaAmount || 0),
      },
    };
  });
}

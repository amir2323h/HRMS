import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeEmployee } from "@/lib/serializers";
import { isValidNationalId } from "@/lib/format";
import { isValidJalali } from "@/lib/jalali";
import { validateDependents, coveredCountFrom } from "@/lib/dependents";

const EMPLOYEE_INCLUDE = {
  jobGrade: true,
  jobTitleRef: true,
  departments: { include: { department: true } },
  insuranceDependents: { orderBy: { createdAt: "asc" } },
  welfare: { include: { welfareItem: true } },
} as const;

const CONTRACT_TYPES = ["PERMANENT", "FIXED", "TEMPORARY", "PROBATION", "INTERN"];

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "employees:view");
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() || "";
    const dept = searchParams.get("dept") || "";
    const grade = searchParams.get("grade") || "";
    const status = searchParams.get("status") || "";

    const employees = await db.employee.findMany({
      where: {
        AND: [
          q
            ? {
                OR: [
                  { firstName: { contains: q } },
                  { lastName: { contains: q } },
                  { personnelCode: { contains: q } },
                  { nationalId: { contains: q } },
                ],
              }
            : {},
          status ? { status } : {},
          grade ? { jobGrade: { level: +grade } } : {},
          dept ? { departments: { some: { departmentId: dept } } } : {},
        ],
      },
      include: EMPLOYEE_INCLUDE,
      orderBy: [{ status: "asc" }, { personnelCode: "asc" }],
    });

    // اگر نقش مدیر دپارتمان است فقط کارکنان دپارتمان خودش
    let list = employees.map((e) => serializeEmployee(e as never));
    if (session.role === "DEPT_MANAGER") {
      // نمایش همه برای گزارش تیم — فقط خواندنی در UI
    }

    const departments = await db.department.findMany({ orderBy: { code: "asc" } });
    return { employees: list, departments };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "employees:edit");
    const body = await req.json();
    const b = body || {};

    // اعتبارسنجی
    const errors: string[] = [];
    if (!b.firstName?.trim()) errors.push("نام الزامی است.");
    if (!b.lastName?.trim()) errors.push("نام خانوادگی الزامی است.");
    // کد ملی الزامی (درخواست کاربر) — ۱۰ رقم + رقم کنترل
    const nationalId = String(b.nationalId || "").replace(/\D/g, "");
    if (!nationalId) errors.push("کد ملی الزامی است.");
    else if (!/^\d{10}$/.test(nationalId)) errors.push("کد ملی باید ۱۰ رقم باشد.");
    else if (!isValidNationalId(nationalId)) errors.push("رقم کنترل کد ملی نامعتبر است.");
    // تکرارنبودن کد ملی
    if (nationalId) {
      const dup = await db.employee.findFirst({ where: { nationalId } });
      if (dup) errors.push("کارمندی با این کد ملی قبلاً ثبت شده است.");
    }
    if (b.iban && !/^IR\d{24}$/i.test(String(b.iban).replace(/\s/g, ""))) errors.push("شماره شبا نامعتبر است (فرمت IR + ۲۴ رقم).");
    for (const f of ["hireDateJ", "contractStartJ"]) {
      if (b[f] && !isValidJalali(b[f])) errors.push("قالب تاریخ جلالی نامعتبر است (مثال: 1405/01/15).");
    }
    const base = Number(b.baseSalary || 0);
    if (!base || base <= 0) errors.push("حقوق پایه الزامی است.");
    // بیمه تکمیلی — افراد تحت پوشش (نسبت + مشخصات)
    const suppInsurance = ["NONE", "INDIVIDUAL", "FAMILY"].includes(b.suppInsurance) ? b.suppInsurance : "NONE";
    const dep = validateDependents(b.suppDependents, suppInsurance);
    errors.push(...dep.errors);
    if (errors.length) {
      return Response.json({ error: errors.join(" ") }, { status: 400 });
    }

    // عنوان شغل: انتخاب از مشاغل تعریف‌شده در تنظیمات (یا متن آزاد)
    let jobTitleId: string | null = null;
    let jobTitle = String(b.jobTitle || "").trim();
    let jobGradeId = b.jobGradeId || null;
    if (b.jobTitleId) {
      const job = await db.jobTitle.findUnique({ where: { id: b.jobTitleId }, include: { jobGrade: true } });
      if (!job) return Response.json({ error: "عنوان شغلی انتخاب‌شده در تنظیمات یافت نشد." }, { status: 400 });
      jobTitleId = job.id;
      jobTitle = job.title; // اسنپ‌شات از دیتای مشاغل
      // طبقه شغلی هوشمند: اگر طبقه ارسال نشده ولی شغل طبقه دارد
      if (!jobGradeId && job.jobGradeId) jobGradeId = job.jobGradeId;
    }

    // کد پرسنلی خودکار
    const count = await db.employee.count();
    const personnelCode = `EMP-${1001 + count}`;

    const employee = await db.employee.create({
      data: {
        personnelCode,
        firstName: String(b.firstName).trim(),
        lastName: String(b.lastName).trim(),
        nationalId,
        ssoNumber: String(b.ssoNumber || ""),
        mobile: String(b.mobile || ""),
        email: String(b.email || ""),
        address: String(b.address || ""),
        maritalStatus: b.maritalStatus === "MARRIED" ? "MARRIED" : "SINGLE",
        childCount: Math.max(0, +b.childCount || 0),
        hireDateJ: String(b.hireDateJ || ""),
        probationEndDateJ: String(b.probationEndDateJ || ""),
        contractType: CONTRACT_TYPES.includes(b.contractType) ? b.contractType : "PERMANENT",
        contractStartJ: String(b.contractStartJ || ""),
        contractEndJ: String(b.contractEndJ || ""),
        employmentType: b.employmentType === "SHIFT" ? "SHIFT" : "DAILY",
        shiftPattern: b.employmentType === "SHIFT" && ["TWO_SHIFT", "THREE_SHIFT"].includes(b.shiftPattern) ? b.shiftPattern : "",
        jobGradeId,
        jobTitleId,
        jobTitle,
        baseSalary: BigInt(Math.round(base)),
        overtimeHours: Math.max(0, +b.overtimeHours || 0),
        status: "ACTIVE",
        bankName: String(b.bankName || ""),
        iban: String(b.iban || "").replace(/\s/g, "").toUpperCase(),
        // بیمه تکمیلی — تعداد تحت پوشش از روی فهرست بستگان محاسبه می‌شود
        suppInsurance,
        suppCoveredCount: coveredCountFrom(suppInsurance, dep.list.length),
        suppInsurerName: String(b.suppInsurerName || ""),
        suppPolicyNumber: String(b.suppPolicyNumber || ""),
        // مشخصات افراد تحت پوشش
        insuranceDependents: {
          create: dep.list.map((d) => ({
            firstName: d.firstName,
            lastName: d.lastName,
            nationalId: d.nationalId,
            relationship: d.relationship,
            birthDateJ: d.birthDateJ,
          })),
        },
      },
      include: EMPLOYEE_INCLUDE,
    });

    // انتساب دپارتمان
    if (b.departmentId) {
      await db.employeeDepartment.create({
        data: { employeeId: employee.id, departmentId: b.departmentId, allocationPercent: 100 },
      });
    }

    // رفاهیات مورد استفاده (چک‌باکس‌ها)
    if (Array.isArray(b.welfareIds) && b.welfareIds.length > 0) {
      const items = await db.welfareItem.findMany({ where: { id: { in: b.welfareIds.map(String) }, isActive: true } });
      for (const it of items) {
        await db.employeeWelfare.create({ data: { employeeId: employee.id, welfareItemId: it.id } }).catch(() => undefined);
      }
    }

    const full = await db.employee.findUnique({ where: { id: employee.id }, include: EMPLOYEE_INCLUDE });
    await audit(session, "CREATE", "EMPLOYEE", employee.id, `ثبت کارمند جدید: ${b.firstName} ${b.lastName} (${personnelCode})`, null, {
      firstName: b.firstName,
      lastName: b.lastName,
      baseSalary: Math.round(base),
      contractType: b.contractType,
      jobTitle,
      suppInsurance,
      suppDependents: dep.list.length,
    });
    return { employee: serializeEmployee(full as never) };
  });
}

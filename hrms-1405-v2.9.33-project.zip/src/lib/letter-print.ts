"use client";

// ============================================================
// سند چاپی نامه — مطابق قالب مکاتبات رسمی مرجع کاربر
// (نمونه: نامه ZDX_AD_0507019 — سربرگ زودکس‌گونه)
//
//  ساختار صفحه (مطابق الگو):
//   ┌──────────────────────────────────────────────────────┐
//   │ [تاریخ/شماره]      بِسمِهِ تَعالی      [خطوط+نام+لوگو] │
//   │ موضوع: … (توپیر)                                     │
//   │ [گیرنده] (توپیر)                                      │
//   │ با سلام و احترام + متن بدنه (تراز دوطرفه)             │
//   │ [جدول پیوست: کد/شناسه | شرح | ردیف]                   │
//   │ مهر دیجیتال (چپ) | باکس نام/سمت + امضا/مهر کنار آن      │
//   └──────────────────────────────────────────────────────┘
//
//  دو حالت سربرگ (حذف سربرگ دیجیتال — درخواست کاربر: تنها منبع
//  گرافیک سربرگ، تصویر «سربرگ رسمی شرکت» از تنظیمات است):
//   ۱) تصویر سربرگ رسمی (PNG آپلودی A4/A5) — پس‌زمینه صفحه؛
//      تاریخ/شماره (بالا-چپ) + بِسمِهِ تَعالی + محتوا + امضاها روی تصویر
//   ۲) بدون تصویر — هیچ گرافیک سربرگ/پابری چاپ نمی‌شود؛ فقط تاریخ/شماره
//      + بِسمِهِ تَعالی + محتوا + امضاها (چاپ روی کاغذ پیش‌چاپ)
//  جانمایی امضا/مهر: پیش‌فرض جریان (زیر متن) یا ویژوال — مختصات مطلق روی
//  کاغذ از ادیتور درگ‌اند‌دراپ تنظیمات (تنظیمات ← قالب نامه‌ها).
//  سایز کاغذ: A4 (۲۱۰×۲۹۷) و A5 (۱۴۸×۲۱۰) — @page هماهنگ.
//  تاریخ/شماره/کدها با ارقام لاتین (مطابق نامه مرجع).
// ============================================================

import { isoToJalaliStr, toFaDigits } from "@/lib/jalali";
import { sanitizeLetterHtml } from "@/lib/rich-html";
import { qrCodeSvg } from "@/lib/qrcode";

export interface LetterPrintItem {
  title: string;
  code: string;
}

export interface LetterPrintData {
  number: string;
  title: string;
  body: string;
  bodyHtml?: string | null; // متن غنی (جدول/قالب‌بندی) — نامه دستی
  status: string; // PENDING | APPROVED | REJECTED
  source?: string; // REQUEST | MANUAL
  recipient?: string;
  recipientPosition?: string; // سمت گیرنده نامه دستی (مثل «مدیرعامل شرکت …»)
  decidedBy?: string;
  decidedAt?: string | null; // ISO
  decisionNote?: string;
  signatureCode?: string | null;
  employeeName: string;
  personnelCode?: string;
  department?: string;
  signerName?: string;
  signerTitle?: string;
  items?: LetterPrintItem[];
  createdAt?: string; // ISO
}

export interface LetterPrintCompany {
  name: string;
  nationalId?: string;
  address?: string;
  logo?: string; // data URL
  phone?: string;
  mobile?: string;
  website?: string;
  email?: string;
}

export type LetterPaperSize = "A4" | "A5";

export interface LetterPrintOptions {
  letterhead: boolean; // سربرگ رسمی (تصویر) یا دیجیتال — false = بدون سربرگ
  paperSize?: LetterPaperSize; // اندازه کاغذ (پیش‌فرض A4)
  letterheadImage?: string; // data URL تصویر سربرگ رسمی (حالت letterhead:true)
  letterheadTopMm?: number; // فاصله محتوا از بالا وقتی تصویر سربرگ فعال است
  letterheadBottomMm?: number; // فاصله محتوا از پایین
  signerSignature?: string; // تصویر امضای دست‌نویس امضاکننده (data URL) — فقط با سربرگ چاپ می‌شود
  sealImage?: string; // تصویر مهر سازمان/شخص (data URL) — فقط با سربرگ چاپ می‌شود
  signatureSizeMm?: number; // قد تصویر امضا در چاپ (mm) — پیش‌فرض ۱۱ — کنترل از تنظیمات
  sealSizeMm?: number; // قد تصویر مهر در چاپ (mm) — پیش‌فرض ۱۳ — کنترل از تنظیمات
  /** جانمایی ویژوال امضا/مهر روی کاغذ — از ادیتور درگ‌اند‌دراپ تنظیمات
   *  custom=true: گروه امضا/مهر و مهر امضای دیجیتال مطلقاً روی کاغذ در همین
   *  مختصات (mm از لبه چپ/پایین) جانمایی می‌شوند — هماهنگ با تصویر سربرگ */
  signLayout?: { custom: boolean; groupX: number; groupY: number; digiX: number; digiY: number };
  showDigitalSignature?: boolean; // نمایش مهر امضای دیجیتال (پیش‌فرض true — کنترل از اطلاعات پایه)
  baseUrl?: string; // برای فایل دانلودی (آدرس مطلق سرور برای فونت/راستی‌آزمایی)
  embeddedFonts?: Record<string, string>; // فونت‌های base64 (فایل خودکفا)
}

/** ابعاد کاغذ (میلی‌متر) + حاشیه‌های جانبی */
const PAGE_GEO: Record<LetterPaperSize, { w: number; h: number; side: number; label: string }> = {
  A4: { w: 210, h: 297, side: 16, label: "A4" },
  A5: { w: 148, h: 210, side: 12, label: "A5" },
};

const STATUS_LABELS: Record<string, string> = {
  PENDING: "در انتظار تأیید",
  APPROVED: "تأییدشده",
  REJECTED: "ردشده",
};

/** رنگ سازمانی قالب مرجع (مهر امضای دیجیتال/نوار ابزار — آبی) */
const BLUE = "#3050A0";

function esc(s: string): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** تاریخ جلالی با ارقام لاتین (مطابق الگو: 1405/07/12) */
function letterDateLatin(iso?: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  return isNaN(d.getTime()) ? "" : isoToJalaliStr(d);
}

/** تبدیل ارقام فارسی/عربی به لاتین — شماره نامه همیشه با ارقام لاتین چاپ می‌شود */
function toEnDigits(s: string): string {
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  const ar = "٠١٢٣٤٥٦٧٨٩";
  return String(s ?? "").replace(/[۰-۹٠-٩]/g, (d) => {
    const i = fa.indexOf(d);
    return String(i >= 0 ? i : ar.indexOf(d));
  });
}

/** تاریخ رسمی نامه: تاریخ صدور/تأیید وگرنه تاریخ ثبت — با ارقام فارسی (۱۴۰۵/۰۷/۱۲) */
function letterDate(l: LetterPrintData): string {
  const iso = l.status === "APPROVED" && l.decidedAt ? l.decidedAt : l.createdAt;
  return toFaDigits(letterDateLatin(iso));
}

/** تاریخ + ساعت جلالی با ارقام فارسی — ۱۴۰۵/۰۷/۱۳ — ۱۴:۳۰ */
function faDateTimeFa(iso?: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return toFaDigits(`${isoToJalaliStr(d)} — ${hh}:${mm}`);
}

function fontFaces(baseUrl?: string, embedded?: Record<string, string>): string {
  // embedded: نام فایل → data URL (فایل دانلودی خودکفا — فونت داخل فایل)
  // LetterLatin: جفت لاتین B Nazanin (سریف) با size-adjust — حروف لاتین متن ۱۰pt وقتی فارسی ۱۲pt است
  const spec: { file: string; family: string; weight: number; adjust?: number }[] = [
    { file: "Vazirmatn-Regular.woff2", family: "Vazirmatn", weight: 400 },
    { file: "Vazirmatn-Medium.woff2", family: "Vazirmatn", weight: 500 },
    { file: "Vazirmatn-SemiBold.woff2", family: "Vazirmatn", weight: 600 },
    { file: "Vazirmatn-Bold.woff2", family: "Vazirmatn", weight: 700 },
    { file: "NotoNastaliqUrdu.woff2", family: "NotoNastaliq", weight: 400 },
    { file: "BNazanin.woff2", family: "B Nazanin", weight: 400 },
    { file: "BTitr.woff2", family: "B Titr", weight: 700 },
    { file: "LetterLatin-Regular.woff2", family: "LetterLatin", weight: 400, adjust: 83.33 },
    { file: "LetterLatin-Bold.woff2", family: "LetterLatin", weight: 700, adjust: 83.33 },
  ];
  return spec
    .map(({ file, family, weight, adjust }) => {
      const src = embedded && embedded[file]
        ? `url('${embedded[file]}')`
        : `url('${(baseUrl || "").replace(/\/$/, "")}/fonts/${file}')`;
      return `@font-face { font-family: '${family}'; src: ${src} format('woff2'); font-weight: ${weight};${adjust ? ` size-adjust: ${adjust}%;` : ""} font-display: block; }`;
    })
    .join("\n");
}

const FONT_FILES = [
  "Vazirmatn-Regular.woff2",
  "Vazirmatn-Medium.woff2",
  "Vazirmatn-SemiBold.woff2",
  "Vazirmatn-Bold.woff2",
  "NotoNastaliqUrdu.woff2",
  "BNazanin.woff2",
  "BTitr.woff2",
  "LetterLatin-Regular.woff2",
  "LetterLatin-Bold.woff2",
];

/** خانواده متن نامه — فارسی B Nazanin 12pt، حروف لاتین خودکار به LetterLatin (۱۰pt با size-adjust)
 *  (B Nazanin گلیف حروف لاتین ندارد → مرورگر نویسه‌های لاتین را از LetterLatin می‌گیرد) */
const LETTER_BODY_FONT = "'B Nazanin', 'LetterLatin', 'Vazirmatn', serif";

/** فونت تیتر نامه — موضوع/گیرنده/«با سلام و احترام» با B Titr چاپ می‌شوند
 *  (فونت تیتر استاندارد مکاتبات رسمی — فقط وزن Bold دارد؛ لاتین از LetterLatin) */
const LETTER_TITLE_FONT = "'B Titr', 'LetterLatin', 'Vazirmatn', serif";

/** عبارت احترام ابتدای نامه — «با سلام و احترام» با فاصله‌گذاری آزاد (باسلام/با سلام و…)
 *  این عبارت در ابتدای متن (ساده یا غنی) با فونت تیتر چاپ می‌شود */
const GREETING_RE = /^(با\s*سلام(?:\s*و\s*احترام)?[،,؛;:]?)/;

/** عبارت احترام پیش‌فرض — متن نامه اگر با «با سلام…» شروع نشده باشد،
 *  این عبارت خودکار با فونت تیتر (B Titr) در ابتدای بدنه درج می‌شود */
const GREETING_PREFIX = "با سلام و احترام،";

/** درج <span class="greet"> دور عبارت احترام در ابتدای متن ساده (پیش از escape)
 *  متن بدون عبارت احترام → درج خودکار «با سلام و احترام،» با فونت تیتر */
function bodyTextHtml(body: string): string {
  const m = body.match(/^\s*/) || [""];
  const lead = m[0];
  const rest = body.slice(lead.length);
  const g = rest.match(GREETING_RE);
  if (!g) return `<span class="greet">${esc(GREETING_PREFIX)}</span>\n${esc(body)}`;
  return `${esc(lead)}<span class="greet">${esc(g[1])}</span>${esc(rest.slice(g[1].length))}`;
}

/** درج <span class="greet"> دور عبارت احترام در ابتدای متن غنی (پس از پاک‌سازی)
 *  از روی تگ‌های آغازین (p/b/div و…) رد می‌شود تا به نخستین متن برسد */
function wrapGreetingInHtml(html: string): string {
  const lead = html.match(/^(?:\s|<[^>]+>)*/);
  const idx = lead ? lead[0].length : 0;
  const rest = html.slice(idx);
  const g = rest.match(GREETING_RE);
  if (!g) return html;
  return `${html.slice(0, idx)}<span class="greet">${g[1]}</span>${rest.slice(g[1].length)}`;
}

/** اطمینان از وجود عبارت احترام در ابتدای متن غنی —
 *  اگر متن با «با سلام…» شروع نشده باشد، پاراگراف احترام با فونت تیتر خودکار درج می‌شود */
function ensureGreetingHtml(html: string): string {
  const wrapped = wrapGreetingInHtml(html);
  if (wrapped !== html) return wrapped; // عبارت احترام موجود بود — فقط فونت تیتر گرفت
  return `<p><span class="greet">${esc(GREETING_PREFIX)}</span></p>${html}`;
}

/** فونت‌های سرور را به data URL تبدیل می‌کند — برای فایل دانلودی خودکفا (بدون وابستگی به سرور/CORS) */
async function fetchEmbeddedFonts(baseUrl: string): Promise<Record<string, string> | undefined> {
  try {
    const out: Record<string, string> = {};
    await Promise.all(
      FONT_FILES.map(async (f) => {
        const res = await fetch(`${baseUrl.replace(/\/$/, "")}/fonts/${f}`);
        if (!res.ok) throw new Error(`font ${f}: ${res.status}`);
        const buf = await res.arrayBuffer();
        const bytes = new Uint8Array(buf);
        let bin = "";
        const CHUNK = 0x8000;
        for (let i = 0; i < bytes.length; i += CHUNK) {
          bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
        }
        out[f] = `data:font/woff2;base64,${btoa(bin)}`;
      })
    );
    return out;
  } catch {
    return undefined; // fallback: آدرس مطلق سرور
  }
}

// ---------- بلوک‌های سند ----------

/** خطوط تاریخ/شماره — مشترک هر سه حالت سربرگ
 *  تاریخ: ارقام فارسی (۱۴۰۵/۰۷/۱۳) • شماره نامه: ارقام لاتین • فونت B Nazanin */
function refLines(l: LetterPrintData): string {
  return `
      <p class="ref-line"><span class="ref-label">تاریخ:</span> <b class="ref-value">${esc(letterDate(l) || "—")}</b></p>
      <p class="ref-line"><span class="ref-label">شماره نامه:</span> <b class="ref-value" dir="ltr">${esc(toEnDigits(l.number))}</b></p>`;
}

/** بلوک ارجاع تاریخ/شماره + بِسمِهِ تَعالی — حالت «بدون تصویر سربرگ»
 *  (کاغذ پیش‌چاپ یا حالت بدون سربرگ — سربرگ دیجیتال حذف شده است) */
function refsPlainHtml(l: LetterPrintData): string {
  return `
  <header class="letterhead plain">
    <div class="lh-brand-plain"></div>
    <p class="besm">بِسمِهِ تَعالی</p>
    <div class="lh-refs">
      ${refLines(l)}
    </div>
  </header>`;
}

/** تاریخ/شماره در حالت تصویر سربرگ رسمی — لایه شناور بالا-چپ روی تصویر (مطابق الگو)
 *  + «بِسمِهِ تَعالی» نستعلیق وسط — ۳ اینتر پایین‌تر از لبه صفحه (زیر نوار گرافیک سربرگ)
 *  تصویر سربرگ این متن را ندارد، پس همیشه چاپ می‌شود */
function refsOverlayHtml(l: LetterPrintData): string {
  return `
  <p class="besm besm-overlay">بِسمِهِ تَعالی</p>
  <div class="refs-overlay">
      ${refLines(l)}
  </div>`;
}

/** بلوک موضوع/گیرنده — مطابق الگو: موضوع و گیرنده توپیر، راست‌چین
 *  سمت گیرنده (اختیاری — نامه دستی) خط دوم زیر گیرنده چاپ می‌شود */
function subjectHtml(l: LetterPrintData): string {
  const recipient = (l.recipient || "").trim();
  const position = (l.recipientPosition || "").trim();
  return `
  <div class="subject-block">
    <p class="subject">موضوع: <span>${esc(l.title)}</span></p>
    ${recipient ? `<p class="recipient">${esc(recipient)}</p>` : ""}
    ${position ? `<p class="recipient-pos">${esc(position)}</p>` : ""}
  </div>`;
}

/** جدول پیوست نامه — ستون‌ها مطابق الگو: کد/شناسه | شرح | ردیف (سربرگ خاکستری) */
function itemsTableHtml(items: LetterPrintItem[]): string {
  if (!items || items.length === 0) return "";
  const rows = items
    .map(
      (it, i) => `
      <tr>
        <td class="it-code">${it.code ? `<span dir="ltr">${esc(it.code)}</span>` : "—"}</td>
        <td class="it-title">${esc(it.title || "—")}</td>
        <td class="it-row">${i + 1}</td>
      </tr>`
    )
    .join("");
  return `
  <table class="items-table">
    <thead>
      <tr><th>کد/شناسه</th><th class="th-title">شرح</th><th>ردیف</th></tr>
    </thead>
    <tbody>${rows}</tbody>
  </table>`;
}

/** مهر امضای دیجیتال — فشرده و کم‌ارتفاع — سمت راست صفحه
 *  نامه دستی: امضاکننده ثبت‌شده (signerName/signerTitle)؛ نامه قالبی: مرجع تأییدکننده
 *  راستی‌آزمایی: QR درون‌خطی (مولد بومی — بدون CDN) به‌جای لینک متنی */
function digitalSignatureHtml(l: LetterPrintData, baseUrl: string): string {
  const code = (l.signatureCode || "").toUpperCase();
  const manual = l.source === "MANUAL";
  const name = manual ? l.signerName || l.decidedBy || "—" : l.decidedBy || "—";
  const roleLabel = manual
    ? l.signerTitle || "امضاکننده"
    : `مرجع تأییدکننده — ${STATUS_LABELS[l.status] || l.status}`;
  const when = faDateTimeFa(l.decidedAt);
  const verifyUrl = `${baseUrl}/api/letters/verify?code=${code.replace(/-/g, "")}`;
  let qr = "";
  try {
    qr = qrCodeSvg(verifyUrl, { dark: "#0f172a" });
  } catch {
    qr = ""; // متن بیش‌ازحد بلند — بازگشت به لینک متنی
  }
  return `
  <div class="digi-sig">
    <div class="ds-head">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" class="ds-icon"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
      <span>امضای دیجیتال</span>
    </div>
    <div class="ds-flex">
      ${qr ? `<div class="ds-qr">${qr}</div>` : ""}
      <div class="ds-info">
        <p class="ds-name">${esc(name)}</p>
        <p class="ds-role">${esc(roleLabel)}${when ? ` — <span>${esc(when)}</span>` : ""}</p>
        <p class="ds-code" dir="ltr">${esc(code)}</p>
      </div>
    </div>
    ${
      qr
        ? `<p class="ds-verify">اسکن برای راستی‌آزمایی امضای دیجیتال</p>`
        : `<p class="ds-verify">راستی‌آزمایی: <span dir="ltr">${esc(verifyUrl)}</span></p>`
    }
  </div>`;
}

/** ناحیه امضا — چیدمان دوستونه (درخواست کاربر):
 *  • باکس نام/سمت امضاکننده («با تجدید احترام» + نام + سمت): سمت چپ صفحه، ۲۵٪ از حاشیه چپ
 *  • پشته امضا/مهر: کنارِ باکس نام در سمت «راستِ» آن — امضای دست‌نویس بالا، مهر زیر امضا
 *    (بدون هم‌پوشانی با نام/سمت — دو ستون جدا)
 *  • مهر امضای دیجیتال: چسبیده به حاشیه چپ صفحه
 *  تصویر امضای دست‌نویس و تصویر مهر سازمان/شخص فقط در نسخه «با سربرگ» چاپ می‌شوند —
 *  در نسخه «بدون سربرگ» (چاپ روی کاغذ پیش‌چاپ) فقط نام (و سمت) امضاکننده درج می‌شود */
function signaturesHtml(l: LetterPrintData, baseUrl: string, signerSignature: string | undefined, sealImage: string | undefined, letterhead: boolean, showDigitalSignature = true, customLayout = false): string {
  const approved = l.status === "APPROVED" && !!l.signatureCode;
  const manual = l.source === "MANUAL";
  // امضاکننده نامه: نامه دستی → امضاکننده ثبت‌شده؛ نامه قالبی تأییدشده → تأییدکننده صدور
  const signerName = approved
    ? manual
      ? l.signerName || l.decidedBy || "—"
      : l.decidedBy || "—"
    : l.employeeName || "—";
  const signerTitle = approved && manual ? l.signerTitle || "" : "";
  const pendingLabel = approved ? "" : "امضای درخواست‌کننده";
  // تصاویر امضا/مهر فقط با سربرگ (طبق قواعد مکاتبات رسمی)
  const sigImg = letterhead && signerSignature
    ? `<img src="${esc(signerSignature)}" alt="امضا" class="sg-sig" />`
    : "";
  const sealImg = letterhead && sealImage
    ? `<img src="${esc(sealImage)}" alt="مهر" class="sg-seal" />`
    : "";
  // زون امضا: امضای دست‌نویس بالا، مهر زیر امضا (عمودی) — نامه در انتظار تأیید: خط‌چین امضا
  const signZone = sigImg || sealImg
    ? `<div class="sg-stack">${sigImg}${sealImg}</div>`
    : !approved
      ? `<div class="sg-stack"><div class="sg-line"></div></div>`
      : "";

  return `
  <div class="sign-area${customLayout ? " custom" : ""}">
    ${approved && showDigitalSignature ? digitalSignatureHtml(l, baseUrl) : ""}
    <div class="signer-group">
      ${signZone}
      <div class="signer">
        <p class="sg-thanks">با تجدید احترام</p>
        <p class="sg-name">${esc(signerName)}</p>
        ${signerTitle ? `<p class="sg-title">${esc(signerTitle)}</p>` : ""}
        ${pendingLabel ? `<p class="sg-pending">${esc(pendingLabel)}</p>` : ""}
        ${!approved && l.personnelCode ? `<p class="sg-meta">کد پرسنلی <span dir="ltr">${esc(toEnDigits(l.personnelCode))}</span></p>` : ""}
      </div>
    </div>
  </div>`;
}

/** اعلان وضعیت برای نامه‌های تعیین‌تکلیف‌نشده/ردشده */
function statusNoticeHtml(l: LetterPrintData): string {
  if (l.status === "PENDING") {
    return `<div class="notice notice-pending">این نامه هنوز تأیید نشده است و نسخه رسمی محسوب نمی‌شود — صرفاً جهت بازبینی/پیش‌نمایش است.</div>`;
  }
  if (l.status === "REJECTED") {
    return `<div class="notice notice-rejected">این نامه توسط مرجع تأییدکننده رد شده است${l.decisionNote ? ` — دلیل: ${esc(l.decisionNote)}` : ""}.</div>`;
  }
  return "";
}

// ---------- سند کامل ----------

/** ساخت سند HTML کامل RTL — A4/A5 با فونت‌های لوکال (وزیرمتن + نستعلیق) */
export function buildLetterDocument(letter: LetterPrintData, company: LetterPrintCompany, opts: LetterPrintOptions): string {
  const baseUrl = (opts.baseUrl || "").replace(/\/$/, "");
  const size: LetterPaperSize = opts.paperSize === "A5" ? "A5" : "A4";
  const geo = PAGE_GEO[size];
  // شماره نامه همیشه با ارقام لاتین (عنوان/نوار ابزار/خطوط ارجاع) — یکجا نرمال‌سازی می‌شود
  const letterNumber = toEnDigits(letter.number || "");
  // حالت تصویر سربرگ رسمی — فقط وقتی letterhead فعال و تصویر موجود است
  const bgImage = opts.letterhead ? (opts.letterheadImage || "").trim() : "";
  const useBg = !!bgImage;
  const bgTop = Math.max(5, Math.round(opts.letterheadTopMm ?? 42));
  const bgBottom = Math.max(5, Math.round(opts.letterheadBottomMm ?? 16));

  const head = useBg ? refsOverlayHtml(letter) : refsPlainHtml(letter);
  const subject = subjectHtml(letter);
  const table = itemsTableHtml(letter.items || []);
  const notices = statusNoticeHtml(letter);
  // جانمایی ویژوال امضا/مهر (ادیتور درگ‌اند‌دراپ تنظیمات) — custom فعال؟
  const sl = opts.signLayout && opts.signLayout.custom ? opts.signLayout : null;
  const sigs = signaturesHtml(letter, baseUrl, opts.signerSignature, opts.sealImage, opts.letterhead, opts.showDigitalSignature !== false, !!sl);
  // متن غنی (جدول/قالب‌بندی نامه دستی) — پاک‌سازی مجدد سمت چاپ؛ در غیاب آن متن ساده
  // عبارت احترام ابتدای متن («با سلام و احترام») با فونت تیتر (B Titr) چاپ می‌شود؛
  // در نبود آن، خودکار با فونت تیتر در ابتدای بدنه درج می‌شود
  const richBody = sanitizeLetterHtml(letter.bodyHtml || "");
  const bodyBlock = richBody
    ? `<div class="body-rich">${ensureGreetingHtml(richBody)}</div>`
    : `<div class="body-text">${bodyTextHtml(letter.body)}</div>`;
  // سربرگ دیجیتال حذف شد (درخواست کاربر) — تنها منبع گرافیک سربرگ/پابرگ،
  // تصویر «سربرگ رسمی شرکت» از تنظیمات است؛ بدون تصویر هیچ گرافیکی چاپ نمی‌شود
  // (letterhead بدون تصویر = چاپ روی کاغذ پیش‌چاپ با امضا/مهر)
  const modeLabel = useBg ? "روی سربرگ رسمی شرکت" : opts.letterhead ? "کاغذ پیش‌چاپ (بدون گرافیک سربرگ)" : "بدون سربرگ";
  const kindLabel = letter.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه";

  // استایل صفحه بر اساس حالت/سایز
  // تصویر سربرگ رسمی: هر «کاشی» به قد کامل کاغذ (A4=۲۹۷ / A5=۲۱۰) تکرار عمودی می‌شود —
  // در نتیجه در چاپ چندصفحه‌ای، سربرگ و پابرگ روی «هر صفحه» کامل نمایش داده می‌شود
  const pageBg = useBg
    ? `background: #fff url('${bgImage}') top center / 100% ${geo.h}mm repeat-y; padding: ${bgTop}mm ${geo.side}mm ${bgBottom}mm; -webkit-print-color-adjust: exact; print-color-adjust: exact;`
    : size === "A5"
      ? "padding: 8mm 12mm 6mm;"
      : "padding: 10mm 16mm 8mm;";
  const printPadding = useBg
    ? `padding: ${bgTop}mm ${geo.side}mm ${bgBottom}mm;`
    : size === "A5"
      ? "padding: 8mm 12mm 6mm;"
      : "padding: 10mm 14mm;";
  const refsPos = size === "A5" ? "top: 5mm; left: 12mm;" : "top: 6mm; left: 16mm;";

  // سایز تصویر امضا/مهر — تنظیم از «امضاکنندگان» تنظیمات (mm)
  // A4 مستقیم؛ A5 به‌میزان متناسب کوچک‌تر (۸۲٪ — هم‌ساز با مقیاس فونت A5)
  const sigMm = Math.min(40, Math.max(6, Math.round(opts.signatureSizeMm ?? 11)));
  const sealMm = Math.min(40, Math.max(6, Math.round(opts.sealSizeMm ?? 13)));
  const sigMm5 = Math.max(6, Math.round(sigMm * 0.82));
  const sealMm5 = Math.max(6, Math.round(sealMm * 0.82));
  // ارتفاع ناحیه امضا — گروه امضا/مهر مطلق است؛ ارتفاع باکس با قد پشته امضا+مهر هم‌قد می‌شود
  // (تصاویر امضا/مهر فقط در نسخه «با سربرگ» چاپ می‌شوند)
  const hasSignImages = !!opts.letterhead && !!(opts.signerSignature || opts.sealImage);
  const signAreaMm = hasSignImages ? Math.max(29, sigMm + sealMm + 5) : 29;
  const signAreaMm5 = hasSignImages ? Math.max(25, sigMm5 + sealMm5 + 5) : 25;
  const sizeCss = `
/* ---------- سایز چاپ امضا/مهر (تنظیمات) — حداکثر قد به میلی‌متر ----------
   max-height (نه height): تصویر پهن (امضای دست‌نویس/مهر مستطیلی) به نسبت خودش
   کوتاه‌تر چاپ می‌شود و داخل جعبه قدثابت letterbox نمی‌شود — وگرنه فضای خالی
   داخل جعبه، فاصلهٔ بصری بین جوهر امضا و جوهر مهر می‌سازد */
.sg-sig { max-height: ${sigMm}mm; max-width: ${Math.round(sigMm * 3.1)}mm; }
.sg-seal { max-height: ${sealMm}mm; max-width: ${Math.round(sealMm * 1.25)}mm; }
.a5 .sg-sig { max-height: ${sigMm5}mm; max-width: ${Math.round(sigMm5 * 3.1)}mm; }
.a5 .sg-seal { max-height: ${sealMm5}mm; max-width: ${Math.round(sealMm5 * 1.25)}mm; }
.sign-area { min-height: ${signAreaMm}mm; }
.a5 .sign-area { min-height: ${signAreaMm5}mm; }
${sl ? `
/* ---------- جانمایی ویژوال امضا/مهر (ادیتور درگ‌اند‌دراپ تنظیمات) ----------
   .sign-area استاتیک می‌شود → گروه امضا/مهر و مهر امضای دیجیتال مستقیم نسبت
   به «کاغذ» جانمایی می‌شوند (left از لبه چپ، bottom از لبه پایین کاغذ) —
   مختصات دقیقاً همان مقادیر ادیتور (mm) و در نمایش/چاپ/فایل دانلودی یکسان است */
.sign-area.custom { position: static; min-height: 0; margin-top: 3mm; margin-bottom: 0; }
.a5 .sign-area.custom { min-height: 0; }
.sign-area.custom .signer-group { left: ${sl.groupX}mm; bottom: ${sl.groupY}mm; }
.sign-area.custom .digi-sig { left: ${sl.digiX}mm; bottom: ${sl.digiY}mm; }
` : ""}`;

  // برش حاشیه خالی تصاویر امضا/مهر — اسکریپت درون‌سند (همه حالت‌ها):
  // تصویر اسکن‌شده امضا/مهر اغلب حاشیه شفاف/سفید بزرگی دور جوهر دارد؛
  // بدون برش، این حاشیه «فاصله خالی» بین جوهر امضا و جوهر مهر می‌سازد
  // (چیدمان درست است ولی به چشم جدا از هم دیده می‌شوند — گزارش کاربر).
  // جوهر = پیکسل غیرشفاف و غیر تقریباً سفید؛ با ۲px حاشیه اطمینان برش می‌شود.
  // پرچم __sigTrimDone پس از پایان (یا خطا) ست می‌شود تا چاپ بعد از برش آغاز شود.
  const trimSignScript = `
<script>
(function () {
  function trimImg(el) {
    return new Promise(function (resolve) {
      try {
        var src = el.getAttribute('src') || '';
        if (!src || src.indexOf('data:') !== 0) return resolve();
        var img = new Image();
        img.onload = function () {
          try {
            var w = img.naturalWidth || 0, h = img.naturalHeight || 0;
            if (!w || !h) return resolve();
            var c = document.createElement('canvas');
            c.width = w; c.height = h;
            var ctx = c.getContext('2d');
            if (!ctx) return resolve();
            ctx.drawImage(img, 0, 0);
            var d;
            try { d = ctx.getImageData(0, 0, w, h).data; } catch (e) { return resolve(); }
            var minX = w, minY = h, maxX = -1, maxY = -1;
            for (var y = 0; y < h; y++) {
              for (var x = 0; x < w; x++) {
                var i = (y * w + x) * 4;
                var a = d[i + 3];
                if (a < 16) continue;            /* شفاف */
                var r = d[i], g = d[i + 1], b = d[i + 2];
                if (r > 238 && g > 238 && b > 238) continue; /* تقریباً سفید */
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
              }
            }
            if (maxX < 0 || maxY < 0) return resolve(); /* خالی — دست نزن */
            var m = 2;
            var x0 = Math.max(0, minX - m), y0 = Math.max(0, minY - m);
            var x1 = Math.min(w - 1, maxX + m), y1 = Math.min(h - 1, maxY + m);
            var tw = x1 - x0 + 1, th = y1 - y0 + 1;
            if ((tw >= w && th >= h) || tw < 4 || th < 4) return resolve();
            var c2 = document.createElement('canvas');
            c2.width = tw; c2.height = th;
            var ctx2 = c2.getContext('2d');
            if (!ctx2) return resolve();
            ctx2.drawImage(c, x0, y0, tw, th, 0, 0, tw, th);
            el.src = c2.toDataURL('image/png');
            resolve();
          } catch (e) { resolve(); }
        };
        img.onerror = function () { resolve(); };
        img.src = src;
      } catch (e) { resolve(); }
    });
  }
  var imgs = Array.prototype.slice.call(document.querySelectorAll('img.sg-sig, img.sg-seal'));
  if (!imgs.length) { window.__sigTrimDone = true; return; }
  Promise.all(imgs.map(trimImg)).then(function () { window.__sigTrimDone = true; },
                                      function () { window.__sigTrimDone = true; });
})();
</script>`;

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>${esc(letter.title)} — ${esc(letterNumber)}</title>
<style>
${fontFaces(baseUrl, opts.embeddedFonts)}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { background: #eef2f5; }
body { font-family: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif; direction: rtl; }
@page { size: ${size}; margin: 0; }
.page { background: #fff; width: ${geo.w}mm; min-height: ${geo.h}mm; margin: 8mm auto; box-shadow: 0 2px 14px rgba(0,0,0,.14); display: flex; flex-direction: column; position: relative; ${pageBg} }
/* حالت تصویر سربرگ رسمی: تا آماده‌شدن کامل تصویر پس‌زمینه صفحه مخفی می‌ماند
   (حذف نمایش لحظه‌ای «صفحه سفید بدون سربرگ» پیش از لود کامل بکگراند نامه) */
.page.img-bg { visibility: hidden; }
.page.img-bg.bg-ready { visibility: visible; }

/* ---------- بلوک ارجاع (تاریخ/شماره + بِسمِه‌تعالی وسط) ----------
    سربرگ دیجیتال حذف شد — تنها منبع گرافیک سربرگ، تصویر رسمی تنظیمات است */
.letterhead { display: flex; align-items: flex-start; justify-content: space-between; gap: 4mm; min-height: 22mm; position: relative; }
.lh-brand-plain { width: 34%; }
.besm { position: absolute; left: 50%; top: 1mm; transform: translateX(-50%); white-space: nowrap; font-family: 'NotoNastaliq', 'Vazirmatn', serif; font-size: 14.5pt; line-height: 2.4; color: #1e293b; }
/* روی تصویر سربرگ رسمی — نستعلیق وسط، ۳ اینتر پایین‌تر از لبه صفحه
   (هر اینتر = یک سطر متن نامه ≈ ۸.۷mm → ۲.۵mm + ۳×۸.۷mm ≈ ۲۸.۵mm — زیر نوار گرافیک سربرگ) */
.besm-overlay { position: absolute; left: 50%; top: 28.5mm; transform: translateX(-50%); z-index: 2; }
.lh-refs { width: 34%; padding-top: 1mm; text-align: right; }
.ref-line { font-family: 'B Nazanin', 'LetterLatin', 'Vazirmatn', serif; font-size: 11.5pt; line-height: 2; color: #111; text-align: right; }
.ref-label { font-weight: 700; }
.ref-value { font-weight: 700; }

/* ---------- لایه تاریخ/شماره روی تصویر سربرگ رسمی (بالا-چپ مطابق الگو) ---------- */
.refs-overlay { position: absolute; ${refsPos} z-index: 2; text-align: right; }

/* ---------- موضوع/گیرنده (B Titr — فونت تیتر مکاتبات رسمی) ----------
    فاصله بین دو خط موضوع/گیرنده فشرده است (درخواست کاربر)
    سمت گیرنده (خط دوم — اختیاری) */
.subject-block { margin-top: 7mm; text-align: right; }
.subject { font-family: ${LETTER_TITLE_FONT}; font-size: 12pt; font-weight: 700; color: #0f172a; line-height: 1.6; }
.subject span { font-weight: 700; }
.recipient { font-family: ${LETTER_TITLE_FONT}; font-size: 12pt; font-weight: 700; color: #1e293b; margin-top: 1mm; line-height: 1.6; }
.recipient-pos { font-family: ${LETTER_TITLE_FONT}; font-size: 11.5pt; font-weight: 700; color: #1e293b; margin-top: .4mm; line-height: 1.6; }

/* ---------- متن بدنه — B Nazanin 12 (لاتین ۱۰ با size-adjust LetterLatin) ----------
    عبارت احترام ابتدای متن («با سلام و احترام») با فونت تیتر B Titr */
.body-text { margin-top: 5mm; font-family: ${LETTER_BODY_FONT}; font-size: 12pt; line-height: 2.05; font-weight: 400; color: #1f2937; white-space: pre-wrap; text-align: justify; flex: 1; }
.greet { font-family: ${LETTER_TITLE_FONT}; font-weight: 700; }

/* ---------- متن غنی (جدول/قالب‌بندی نامه دستی) — B Nazanin ----------
    عبارت احترام («با سلام و احترام») — موجود یا درج‌شده خودکار — با فونت تیتر B Titr */
.body-rich { margin-top: 5mm; font-family: ${LETTER_BODY_FONT}; font-size: 12pt; line-height: 2; font-weight: 400; color: #1f2937; text-align: justify; flex: 1; }
.body-rich p { margin: 0 0 3.5mm; }
.body-rich ul, .body-rich ol { margin: 2mm 7mm 4mm 0; padding-right: 7mm; }
.body-rich li { margin-bottom: 1mm; }
.body-rich blockquote { border-right: 1pt solid #cbd5e1; margin: 2mm 0 3mm; padding: 1mm 4mm 1mm 0; color: #475569; }
.body-rich h3, .body-rich h4 { font-weight: 700; margin: 3mm 0 2mm; }
.body-rich b, .body-rich strong { font-weight: 700; }
.body-rich table { direction: rtl; width: 100%; border-collapse: collapse; margin: 3mm 0 5mm; border: .6pt solid #c6c6c6; }
.body-rich thead th { background: #dcdcdc; font-family: ${LETTER_BODY_FONT}; font-size: 11pt; font-weight: 700; color: #111; padding: 1.8mm 2.6mm; border: .6pt solid #bfbfbf; text-align: center; }
.body-rich td { font-family: ${LETTER_BODY_FONT}; font-size: 11pt; padding: 1.6mm 2.6mm; border: .6pt solid #cccccc; vertical-align: middle; }
.body-rich td:empty::after, .body-rich th:empty::after { content: "\\2003"; }

/* ---------- جدول پیوست (مطابق الگو: خطوط ظریف خاکستری + سربرگ خاکستری روشن) ---------- */
.items-table { width: 100%; border-collapse: collapse; margin-top: 4mm; border: .6pt solid #c6c6c6; }
.items-table th { background: #dcdcdc; font-family: ${LETTER_BODY_FONT}; font-size: 11pt; font-weight: 700; color: #111; padding: 2mm 3mm; border: .6pt solid #bfbfbf; text-align: center; }
.items-table td { font-family: ${LETTER_BODY_FONT}; font-size: 11pt; padding: 1.9mm 3mm; border: .6pt solid #cccccc; color: #1f2937; vertical-align: middle; }
.it-code { width: 26%; text-align: center; font-weight: 600; }
.it-title { text-align: right; }
.th-title { width: 58%; }
.it-row { width: 11%; text-align: center; color: #333; font-weight: 600; }

/* ---------- اعلان وضعیت ---------- */
.notice { margin-top: 5mm; padding: 2.5mm 4mm; border-radius: 1.5mm; font-size: 9.5pt; line-height: 1.9; }
.notice-pending { background: #fefce866; border: 1pt dashed #d97706aa; color: #92400e; }
.notice-rejected { background: #fef2f266; border: 1pt dashed #dc2626aa; color: #991b1b; }

/* ---------- ناحیه امضا (چیدمان دوستونه — درخواست کاربر) ----------
    باکس نام/سمت امضاکننده («با تجدید احترام» + نام + سمت): سمت چپ صفحه، ۲۵٪ از حاشیه چپ؛
    پشته امضا/مهر: کنارِ باکس نام در سمت راستِ آن — امضای دست‌نویس بالا، مهر زیر امضا
    (دو ستون جدا — مهر هیچ‌وقت روی نام/سمت نمی‌افتد)؛ مهر امضای دیجیتال: حاشیه چپ */
.sign-area { position: relative; margin-top: 10mm; margin-bottom: 9mm; min-height: 29mm; }
.signer-group { position: absolute; left: 25%; bottom: 0; display: flex; align-items: flex-end; gap: 5mm; }
.signer { text-align: right; font-family: ${LETTER_BODY_FONT}; }
.signer p { line-height: 1.15; }
.sg-stack { display: flex; flex-direction: column; align-items: center; justify-content: flex-end; gap: 1mm; min-width: 22mm; }
/* max-height (نه height ثابت): جوهر تصویر تا سقف تنظیمات قد می‌گیرد و پهنای واقعی
   تصویر پهن (امضا/مهر مستطیلی) حفظ می‌شود — بدون letterbox عمودی داخل جعبه */
.sg-sig { max-height: 11mm; max-width: 34mm; object-fit: contain; }
.sg-seal { max-height: 13mm; max-width: 16mm; object-fit: contain; opacity: .96; }
.sg-thanks { font-size: 11pt; font-weight: 700; color: #0f172a; }
.sg-line { width: 100%; border-top: 1pt dotted #64748b; margin-top: 11mm; }
.sg-name { font-size: 11pt; font-weight: 700; color: #1e293b; margin-top: 1.2mm; }
.sg-title { font-size: 10pt; color: #475569; margin-top: .4mm; }
.sg-pending { font-size: 8.5pt; color: #64748b; margin-top: .6mm; }
.sg-meta { font-size: 8pt; color: #94a3b8; margin-top: .3mm; }

/* ---------- مهر امضای دیجیتال (QR راستی‌آزمایی + مشخصات — کم‌ارتفاع) — حاشیه چپ ---------- */
.digi-sig { position: absolute; left: 0; bottom: 0; border: 1pt double ${BLUE}; border-radius: 1.6mm; padding: .8mm 1.5mm; background: #f5f7fd80; text-align: center; max-width: 42mm; line-height: 1.45; }
.ds-head { display: flex; align-items: center; justify-content: center; gap: 1.1mm; color: ${BLUE}; font-size: 7pt; font-weight: 700; }
.ds-icon { width: 2.6mm; height: 2.6mm; }
.ds-flex { display: flex; align-items: center; justify-content: center; gap: 1.6mm; margin-top: .5mm; }
.ds-qr { width: 17mm; height: 17mm; flex-shrink: 0; background: #fff; border: .4pt solid #cbd5e1; border-radius: 1mm; padding: .4mm; }
.ds-qr svg { display: block; width: 100%; height: 100%; }
.ds-info { text-align: center; flex: 1; min-width: 0; }
.ds-name { font-size: 8pt; color: #0f172a; font-weight: 700; margin-top: .3mm; }
.ds-role { font-size: 6pt; color: #64748b; margin-top: .1mm; }
.ds-code { font-family: ui-monospace, 'Courier New', monospace; font-size: 7.5pt; font-weight: 700; color: ${BLUE}; letter-spacing: .7px; margin-top: .4mm; direction: ltr; }
.ds-verify { font-size: 6pt; color: #64748b; margin-top: .4mm; }
.ds-verify span { font-family: ui-monospace, monospace; direction: ltr; unicode-bidi: embed; }

/* ---------- تنظیم A5 (کاغذ کوچک‌تر — فونت/حاشیه متناسب) ---------- */
.a5 .besm { font-size: 12pt; }
.a5 .besm-overlay { top: 23.7mm; }
.a5 .ref-line { font-size: 10pt; }
.a5 .subject { font-size: 10.5pt; }
.a5 .recipient { font-size: 10.5pt; }
.a5 .recipient-pos { font-size: 10pt; }
.a5 .body-text { font-size: 10.5pt; line-height: 2; }
.a5 .items-table th, .a5 .items-table td { font-size: 10pt; padding: 1.6mm 2.4mm; }
.a5 .notice { font-size: 8.5pt; }
.a5 .sg-thanks { font-size: 10pt; }
.a5 .sg-name { font-size: 10pt; }
.a5 .sg-title { font-size: 9pt; }
.a5 .sign-area { min-height: 25mm; }
.a5 .signer-group { gap: 4mm; }
.a5 .sg-line { margin-top: 9mm; }
.a5 .sg-sig { max-height: 9mm; max-width: 27mm; }
.a5 .sg-seal { max-height: 10.5mm; max-width: 13mm; }
.a5 .digi-sig { max-width: 36mm; }
.a5 .ds-name { font-size: 7pt; }
.a5 .ds-code { font-size: 6.5pt; }
.a5 .ds-qr { width: 13mm; height: 13mm; }
.a5 .body-rich { font-size: 10.5pt; line-height: 2; }
.a5 .body-rich table { margin: 2.4mm 0 4mm; }
.a5 .body-rich thead th, .a5 .body-rich td { font-size: 9.5pt; padding: 1.3mm 2mm; }
${sizeCss}

/* ---------- نوار ابزار (غیرچاپی) ---------- */
.toolbar { position: fixed; top: 0; right: 0; left: 0; background: #0f172aee; color: #fff; display: flex; align-items: center; gap: 10px; padding: 8px 14px; font-family: 'Vazirmatn', sans-serif; z-index: 99; }
.toolbar button { font-family: inherit; font-size: 12px; padding: 6px 14px; border: 0; border-radius: 8px; cursor: pointer; }
.toolbar .btn-print { background: ${BLUE}; color: #fff; }
.toolbar .btn-close { background: #475569; color: #fff; }
.toolbar .hint { font-size: 11px; opacity: .75; margin-right: auto; }

@media print {
  html, body { background: #fff; }
  .toolbar { display: none !important; }
  /* ایمنی: چاپ دستی (Ctrl+P) هرگز صفحه مخیف چاپ نکند — حتی اگر اسکریپت اجرا نشده باشد */
  .page.img-bg { visibility: visible !important; }
  /* هر صفحه چاپی = یک قالب کامل کاغذ (A4/A5):
     با box-decoration-break: clone حاشیه/پس‌زمینه برای «هر قطعه صفحه» جدا اعمال می‌شود
     (در مرورگرهای مدرن — کروم ۱۳۰+/فایرفاکس)؛ مرورگرهای قدیمی از تکرار کاشی پس‌زمینه پیروی می‌کنند */
  .page { width: ${geo.w}mm; min-height: ${geo.h}mm; margin: 0; box-shadow: none; ${printPadding}
          -webkit-box-decoration-break: clone; box-decoration-break: clone; }
  .page + .page { page-break-before: always; }
  /* حالت تصویر سربرگ (چندصفحه‌ای): در چاپ، کش‌شدگی بدنه (flex-grow) خاموش می‌شود —
     بدنه فقط به‌اندازه محتوایش قد می‌گیرد و ناحیه امضا بلافاصله پس از متن می‌آید؛
     وگرنه فضای خالیِ کشیده‌شده، ناحیه امضا را به یک «صفحه اضافه» تقریباً خالی می‌راند */
  .page.img-bg .body-text, .page.img-bg .body-rich { flex: none; }
}
</style>
</head>
<body>
<div class="toolbar">
  <button class="btn-print" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
  <button class="btn-close" onclick="window.close()">بستن</button>
  <span class="hint">${esc(letterNumber)} — ${esc(kindLabel)} — ${esc(modeLabel)} — ${size}${letter.status === "APPROVED" && letter.signatureCode ? " + امضای دیجیتال" : ""}</span>
</div>
<section class="page${size === "A5" ? " a5" : ""}${useBg ? " img-bg" : ""}">
  ${head}
  ${subject}
  ${bodyBlock}
  ${table}
  ${notices}
  ${sigs}
</section>
${trimSignScript}
${
  useBg
    ? `<noscript><style>.page.img-bg { visibility: visible !important; }</style></noscript>
<script>
(function () {
  var p = document.querySelector('.page.img-bg');
  if (!p) return;
  var H_MM = ${geo.h};
  var PAD_MM = ${bgTop + bgBottom};
  /* ارتفاع صفحه همیشه مضرب صحیحِ «تعداد صفحات چاپی» می‌شود — کاشی پس‌زمینه
     سربرگ (هر ${geo.h}mm یک قالب کامل A4/A5) روی «هر صفحه چاپی» کامل می‌افتد:
     صفحه دوم هم سربرگ دارد هم پابرگ (درخواست کاربر).
     نکته مهم: در چاپ، box-decoration-break: clone حاشیه بالا/پایین را به‌ازای
     «هر قطعه صفحه» جدا اعمال می‌کند؛ پس ناحیه مفید هر صفحه چاپی =
     قد کاغذ منهای حاشیه‌ها (مثلاً A4: ۲۹۷−۵۸=۲۳۹mm) — نه کل قد کاغذ.
     تعداد صفحات باید از ناحیه مفید چاپی محاسبه شود وگرنه محتوا به یک
     صفحه سرریزِ تقریباً خالی می‌ریزد. اندازه‌گیری چاپی + نمایشی هر دو
     لحاظ می‌شوند (بیشینه). */
  function fitPages() {
    try {
      var ph = H_MM * 96 / 25.4;      // قد کامل کاغذ (px)
      var pad = PAD_MM * 96 / 25.4;   // مجموع حاشیه بالا/پایین (در نمایش فقط یک‌بار)
      var usable = ph - pad;           // ناحیه مفید هر صفحه چاپی (clone حاشیه را تکرار می‌کند)
      p.style.minHeight = '0';
      var h = p.offsetHeight;          // محتوا + حاشیه یک‌باره
      if (!h || !isFinite(h)) return;
      var content = Math.max(0, h - pad);
      var pagesPrint = Math.max(1, Math.ceil((content - 1) / usable));
      var pagesScreen = Math.max(1, Math.ceil((h - 2) / ph));
      var pages = Math.max(pagesPrint, pagesScreen);
      /* ‑۰٫۲mm ایمنی: مضرب «دقیق» قد کاغذ در واحد Layout مرورگر کمی بزرگ‌تر می‌شود
         و یک صفحه خالی انتهایی می‌سازد — کمی کوتاه‌تر می‌بندیم (برای چشم نامرئی) */
      p.style.minHeight = (pages * H_MM - 0.2) + 'mm';
    } catch (e) {}
  }
  function ready() {
    if (window.__bgReady) return;
    window.__bgReady = true;
    p.className += ' bg-ready';
    fitPages();
    try { window.dispatchEvent(new Event('letterbgready')); } catch (e) {}
  }
  try {
    var bg = (window.getComputedStyle ? getComputedStyle(p) : {}).backgroundImage || '';
    var m = /^url\\((['\"]?)(.*?)\\1\\)$/.exec(String(bg).trim());
    if (!m || !m[2] || m[2] === 'none') { ready(); return; }
    var done = false;
    var fin = function () { if (!done) { done = true; ready(); } };
    var img = new Image();
    img.onload = function () { if (img.decode) { img.decode().then(fin, fin); } else { fin(); } };
    img.onerror = fin;
    img.src = m[2];
    setTimeout(fin, 2500);
  } catch (e) { ready(); }
  fitPages();
  try { if (document.fonts && document.fonts.ready) { document.fonts.ready.then(function () { fitPages(); }); } } catch (e) {}
  window.addEventListener('load', fitPages);
  window.addEventListener('beforeprint', fitPages);
  setTimeout(fitPages, 350);
})();
</script>`
    : ""
}
</body>
</html>`;
}

/** چاپ نامه در پنجره مستقل (اندازه پنجره متناسب کاغذ) — fallback: iframe مخفی
 *  حالت تصویر سربرگ: چاپ فقط پس از آماده‌شدن کامل تصویر پس‌زمینه (پرچم __bgReady)
 *  آغاز می‌شود تا پیش‌نمایش چاپ هرگز بدون سربرگ/با بکگراند ناقص بیفتد. */
export function printLetter(letter: LetterPrintData, company: LetterPrintCompany, opts: LetterPrintOptions): void {
  // آدرس مطلق سرور: فونت‌ها و QR راستی‌آزمایی در پنجره چاپ به‌درستی resolve شوند
  const baseUrl = opts.baseUrl || window.location.origin;
  const html = buildLetterDocument(letter, company, { ...opts, baseUrl });
  const useBg = !!(opts.letterhead && (opts.letterheadImage || "").trim());
  const winSize = opts.paperSize === "A5" ? "width=700,height=760" : "width=920,height=760";
  const w = window.open("", "_blank", winSize);
  if (w) {
    w.document.open();
    w.document.write(html);
    w.document.close();
    w.focus();
    let fired = false;
    const fire = () => {
      if (fired) return;
      fired = true;
      setTimeout(() => {
        try {
          w.focus();
          w.print();
        } catch {
          /* کاربر خودش دکمه چاپ را می‌زند */
        }
      }, useBg ? 120 : 400);
    };
    // آماده‌سازی سند پیش از چاپ (هر دو مسیر):
    //   • حالت تصویر سربرگ: پرچم __bgReady پس از دکود کامل تصویر پس‌زمینه
    //   • همه حالت‌ها: پرچم __sigTrimDone پس از برش حاشیه خالی تصاویر امضا/مهر
    // چاپ فقط پس از آماده‌شدن کامل آغاز می‌شود (سقف ۳٫۴s ایمنی)
    const t0 = Date.now();
    const poll = () => {
      let ok = false;
      try {
        const wx = w as unknown as { __bgReady?: boolean; __sigTrimDone?: boolean };
        ok = (useBg ? !!wx.__bgReady : true) && !!wx.__sigTrimDone;
      } catch {
        ok = true;
      }
      if (ok || Date.now() - t0 > 3400) {
        fire();
        return;
      }
      setTimeout(poll, 40);
    };
    w.addEventListener("load", poll);
    setTimeout(poll, 700); // پشتیبان: اگر رویداد load به هر دلیل اجرا نشد
    return;
  }
  const f = document.createElement("iframe");
  f.style.cssText = "position:fixed;left:200%;bottom:200%;width:0;height:0;border:0;visibility:hidden;";
  document.body.appendChild(f);
  f.onload = () => {
    setTimeout(() => {
      try { f.contentWindow?.focus(); f.contentWindow?.print(); } catch { /* noop */ }
      setTimeout(() => f.remove(), 60_000);
    }, 500);
  };
  f.srcdoc = html;
}

/** دانلود نامه به‌صورت فایل HTML خودکفا — فونت‌ها base64 داخل فایل (بدون نیاز به سرور) */
export async function downloadLetter(letter: LetterPrintData, company: LetterPrintCompany, opts: LetterPrintOptions): Promise<void> {
  const baseUrl = (opts.baseUrl || window.location.origin).replace(/\/$/, "");
  const embeddedFonts = await fetchEmbeddedFonts(baseUrl);
  const html = buildLetterDocument(letter, company, { ...opts, baseUrl, embeddedFonts });
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  // نام فایل مطابق الگوی کاربر: نامه_ZDX_AD_0507019.html (+ _A5 برای کاغذ A5)
  const safe = toEnDigits(letter.number || "").replace(/[^A-Za-z0-9_-]/g, "") || "letter";
  a.download = `نامه_${safe}${opts.paperSize === "A5" ? "_A5" : ""}${opts.letterhead ? "" : "_بدون-سربرگ"}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

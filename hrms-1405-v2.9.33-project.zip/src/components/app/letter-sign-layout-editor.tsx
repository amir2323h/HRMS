"use client";

// ============================================================
// ادیتور ویژوال جانمایی امضا و مهر روی کاغذ نامه (درگ‌اند‌دراپ)
// پیش‌نمایش واقعی کاغذ A4/A5 با تصویر «سربرگ رسمی شرکت» در پس‌زمینه؛
// کاربر کادر «گروه امضا/مهر» (امضای دست‌نویس + مهر + باکس نام/سمت) و
// کادر «مهر امضای دیجیتال» را با ماوس/لمس می‌کشد و در همان نقطه روی
// کاغذ چاپی جای می‌گیرد.
//   • مختصات: X = فاصله از لبه چپ کاغذ (mm) — Y = فاصله از لبه پایین (mm)
//   • در چاپ/دانلود نامه همین مختصات مطلقاً روی کاغذ اعمال می‌شود
//     (هماهنگ با کاغذ پیش‌چاپ/تصویر سربرگ رسمی دارای محل امضا)
//   • پیش‌فرض (custom=false): چیدمان جریان قدیمی (گروه امضا زیر متن نامه)
//     — با کشیدن هر کادر، جانمایی سفارشی خودکار فعال می‌شود
//   • دکمه «بازنشانی» چیدمان پیش‌فرض را برمی‌گرداند و ذخیره می‌کند
// ذخیره: PUT /api/letters/letterhead → signLayoutA4 + signLayoutA5
// ============================================================

import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { NativeSelect } from "@/components/app/native-select";
import { useToast } from "@/hooks/use-toast";
import { api, useApi } from "@/lib/client";
import { Move, RotateCcw, Save, MousePointerClick } from "lucide-react";
import { toFaDigits } from "@/lib/jalali";

interface SignLayout {
  custom: boolean;
  groupX: number;
  groupY: number;
  digiX: number;
  digiY: number;
}

interface SignerEntry {
  name: string;
  title: string;
  signature: string;
  seal: string;
}

interface LetterheadInfo {
  a4: string;
  a5: string;
  a4TopMm?: number;
  a4BottomMm?: number;
  a5TopMm?: number;
  a5BottomMm?: number;
  signatureSizeMm?: number;
  sealSizeMm?: number;
  signers?: SignerEntry[];
  showDigitalSignature?: boolean;
  signLayoutA4?: SignLayout;
  signLayoutA5?: SignLayout;
}

/** ابعاد کاغذ (mm) */
const PAPER: Record<"A4" | "A5", { w: number; h: number; side: number; besm: number }> = {
  A4: { w: 210, h: 297, side: 16, besm: 28.5 },
  A5: { w: 148, h: 210, side: 12, besm: 23.7 },
};

const LAYOUT_DEFAULTS: Record<"A4" | "A5", SignLayout> = {
  A4: { custom: false, groupX: 60, groupY: 24, digiX: 16, digiY: 24 },
  A5: { custom: false, groupX: 43, groupY: 18, digiX: 12, digiY: 18 },
};

export function LetterSignLayoutCard({ canEdit }: { canEdit: boolean }) {
  const { data, refetch } = useApi<LetterheadInfo>("/api/letters/letterhead");
  const { toast } = useToast();

  const [paper, setPaper] = useState<"A4" | "A5">("A4");
  const [layA4, setLayA4] = useState<SignLayout>({ ...LAYOUT_DEFAULTS.A4 });
  const [layA5, setLayA5] = useState<SignLayout>({ ...LAYOUT_DEFAULTS.A5 });
  const [signerIdx, setSignerIdx] = useState(0);
  const [saving, setSaving] = useState(false);
  const [dragging, setDragging] = useState<"group" | "digi" | null>(null);
  const [scale, setScale] = useState(1.5); // پیکسل به میلی‌متر

  const pageRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ key: "group" | "digi"; px0: number; py0: number; x0: number; y0: number } | null>(null);
  const initialized = useRef(false);

  const geo = PAPER[paper];
  const layout = paper === "A4" ? layA4 : layA5;

  // مقداردهی اولیه از تنظیمات ذخیره‌شده
  useEffect(() => {
    if (data && !initialized.current) {
      initialized.current = true;
      setLayA4({ ...LAYOUT_DEFAULTS.A4, ...(data.signLayoutA4 || {}) });
      setLayA5({ ...LAYOUT_DEFAULTS.A5, ...(data.signLayoutA5 || {}) });
    }
  }, [data]);

  // مقیاس پیش‌نمایش (px/mm) — با تغییر اندازه کانتینر به‌روز می‌شود
  useEffect(() => {
    const el = pageRef.current;
    if (!el) return;
    const update = () => setScale(el.clientWidth / geo.w);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [geo.w, paper, data?.a4, data?.a5]);

  function setLayout(patch: Partial<SignLayout>) {
    if (paper === "A4") setLayA4((p) => ({ ...p, ...patch }));
    else setLayA5((p) => ({ ...p, ...patch }));
  }

  // ---------- درگ‌اند‌دراپ ----------
  function startDrag(e: React.PointerEvent<HTMLDivElement>, key: "group" | "digi") {
    if (!canEdit) return;
    e.preventDefault();
    e.stopPropagation();
    const x = key === "group" ? layout.groupX : layout.digiX;
    const y = key === "group" ? layout.groupY : layout.digiY;
    dragRef.current = { key, px0: e.clientX, py0: e.clientY, x0: x, y0: y };
    setDragging(key);
    if (!layout.custom) setLayout({ custom: true }); // کشیدن = فعال‌شدن جانمایی سفارشی
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
  }

  function onDrag(e: React.PointerEvent<HTMLDivElement>) {
    const d = dragRef.current;
    if (!d || !pageRef.current) return;
    const rect = pageRef.current.getBoundingClientRect();
    const mmPerPx = geo.w / rect.width;
    const elemWmm = (e.currentTarget as HTMLElement).offsetWidth * mmPerPx;
    const elemHmm = (e.currentTarget as HTMLElement).offsetHeight * mmPerPx;
    let nx = d.x0 + (e.clientX - d.px0) * mmPerPx;
    let ny = d.y0 - (e.clientY - d.py0) * mmPerPx;
    nx = Math.round(Math.min(Math.max(0, nx), Math.max(0, geo.w - elemWmm)));
    ny = Math.round(Math.min(Math.max(0, ny), Math.max(0, geo.h - elemHmm)));
    if (d.key === "group") setLayout({ groupX: nx, groupY: ny });
    else setLayout({ digiX: nx, digiY: ny });
  }

  function endDrag(e: React.PointerEvent<HTMLDivElement>) {
    dragRef.current = null;
    setDragging(null);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
  }

  // ---------- ذخیره / بازنشانی ----------
  async function save() {
    setSaving(true);
    try {
      await api("/api/letters/letterhead", { method: "PUT", json: { signLayoutA4: layA4, signLayoutA5: layA5 } });
      await refetch();
      toast({
        title: "جانمایی امضا و مهر ذخیره شد",
        description: `${layA4.custom || layA5.custom ? "مختصات سفارشی از این پس در چاپ/دانلود نامه‌ها اعمال می‌شود." : "چیدمان پیش‌فرض (زیر متن نامه) بازیافت شد."}`,
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function resetDefaults() {
    const a4 = { ...LAYOUT_DEFAULTS.A4 };
    const a5 = { ...LAYOUT_DEFAULTS.A5 };
    setLayA4(a4);
    setLayA5(a5);
    setSaving(true);
    try {
      await api("/api/letters/letterhead", { method: "PUT", json: { signLayoutA4: a4, signLayoutA5: a5 } });
      await refetch();
      toast({ title: "چیدمان پیش‌فرض بازیافت شد", description: "گروه امضا/مهر مثل قبل، زیر متن نامه چاپ می‌شود." });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  // ---------- داده‌های پیش‌نمایش ----------
  const bgImage = paper === "A4" ? data?.a4 || "" : data?.a5 || "";
  const topMm = (paper === "A4" ? data?.a4TopMm ?? 42 : data?.a5TopMm ?? 30);
  const signers = data?.signers || [];
  const signer = signers[Math.min(signerIdx, Math.max(0, signers.length - 1))];
  const sigMm = (data?.signatureSizeMm ?? 11) * (paper === "A5" ? 0.82 : 1);
  const sealMm = (data?.sealSizeMm ?? 13) * (paper === "A5" ? 0.82 : 1);
  const mm = (v: number) => v * scale; // mm → px پیش‌نمایش
  const showDigi = data?.showDigitalSignature !== false;

  const pct = (v: number, total: number) => `${(v / total) * 100}%`;

  // کادر جمع‌شده امضا/مهر + باکس نام/سمت — همان ساختار چاپ نامه
  const groupBox = (
    <div
      className={`absolute flex items-end select-none ${canEdit ? "cursor-grab active:cursor-grabbing" : ""}`}
      style={{
        left: pct(layout.groupX, geo.w),
        bottom: pct(layout.groupY, geo.h),
        touchAction: "none",
        outline: dragging === "group" ? "1.5px dashed #0d9488" : canEdit ? "1px dashed #94a3b8" : "none",
        outlineOffset: "2px",
        direction: "rtl",
      }}
      onPointerDown={(e) => startDrag(e, "group")}
      onPointerMove={onDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      role="button"
      tabIndex={canEdit ? 0 : -1}
      aria-label="گروه امضا و مهر — قابل کشیدن"
      onKeyDown={(e) => {
        if (!canEdit) return;
        const step = e.shiftKey ? 5 : 1;
        if (e.key === "ArrowLeft") { e.preventDefault(); setLayout({ groupX: Math.max(0, layout.groupX - step) }); }
        if (e.key === "ArrowRight") { e.preventDefault(); setLayout({ groupX: Math.min(geo.w, layout.groupX + step) }); }
        if (e.key === "ArrowUp") { e.preventDefault(); setLayout({ groupY: Math.min(geo.h, layout.groupY + step) }); }
        if (e.key === "ArrowDown") { e.preventDefault(); setLayout({ groupY: Math.max(0, layout.groupY - step) }); }
      }}
    >
      {/* پشته امضا (بالا) + مهر (زیر امضا) */}
      <div className="flex flex-col items-center justify-end" style={{ gap: mm(1), minWidth: mm(22) }}>
        {signer?.signature ? (
          <img src={signer.signature} alt="امضای دست‌نویس" style={{ height: mm(sigMm), maxWidth: mm(sigMm * 3.1), objectFit: "contain" }} />
        ) : (
          <div className="flex items-center justify-center border border-dashed border-slate-400 text-slate-400" style={{ height: mm(sigMm), minWidth: mm(18), fontSize: Math.max(6, mm(2.2)) }}>
            امضا
          </div>
        )}
        {signer?.seal ? (
          <img src={signer.seal} alt="مهر" style={{ height: mm(sealMm), maxWidth: mm(sealMm * 1.25), objectFit: "contain" }} />
        ) : (
          <div className="flex items-center justify-center border border-dashed border-slate-400 text-slate-400" style={{ height: mm(sealMm), minWidth: mm(12), fontSize: Math.max(6, mm(2.2)) }}>
            مهر
          </div>
        )}
      </div>
      {/* باکس نام/سمت امضاکننده */}
      <div className="text-right leading-tight" style={{ marginRight: mm(5), fontFamily: "inherit" }}>
        <p className="font-bold text-slate-900" style={{ fontSize: Math.max(6, mm(3.9)) }}>با تجدید احترام</p>
        <p className="font-bold text-slate-800" style={{ fontSize: Math.max(6, mm(3.9)), marginTop: mm(0.6) }}>
          {signer?.name || "نام امضاکننده"}
        </p>
        {signer?.title ? (
          <p className="text-slate-500" style={{ fontSize: Math.max(5, mm(3.5)) }}>{signer.title}</p>
        ) : null}
      </div>
    </div>
  );

  // کادر مهر امضای دیجیتال (QR + مشخصات) — نسخه کوچک چاپ
  const digiBox = showDigi ? (
    <div
      className={`absolute select-none ${canEdit ? "cursor-grab active:cursor-grabbing" : ""}`}
      style={{
        left: pct(layout.digiX, geo.w),
        bottom: pct(layout.digiY, geo.h),
        width: mm(paper === "A5" ? 36 : 42),
        touchAction: "none",
        border: "1px double #3050A0",
        borderRadius: mm(1.6),
        background: "rgba(245,247,253,.6)",
        padding: mm(0.8),
        outline: dragging === "digi" ? "1.5px dashed #0d9488" : canEdit ? "1px dashed #94a3b8" : "none",
        outlineOffset: "2px",
        direction: "rtl",
      }}
      onPointerDown={(e) => startDrag(e, "digi")}
      onPointerMove={onDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      role="button"
      tabIndex={canEdit ? 0 : -1}
      aria-label="مهر امضای دیجیتال — قابل کشیدن"
      onKeyDown={(e) => {
        if (!canEdit) return;
        const step = e.shiftKey ? 5 : 1;
        if (e.key === "ArrowLeft") { e.preventDefault(); setLayout({ digiX: Math.max(0, layout.digiX - step) }); }
        if (e.key === "ArrowRight") { e.preventDefault(); setLayout({ digiX: Math.min(geo.w, layout.digiX + step) }); }
        if (e.key === "ArrowUp") { e.preventDefault(); setLayout({ digiY: Math.min(geo.h, layout.digiY + step) }); }
        if (e.key === "ArrowDown") { e.preventDefault(); setLayout({ digiY: Math.max(0, layout.digiY - step) }); }
      }}
    >
      <div className="flex flex-col items-center" style={{ gap: mm(0.5) }}>
        <div className="flex items-center font-bold text-[#3050A0]" style={{ fontSize: Math.max(5, mm(2.5)), gap: mm(1) }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" style={{ width: mm(2.6), height: mm(2.6) }}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
          <span>امضای دیجیتال</span>
        </div>
        <div className="flex items-center" style={{ gap: mm(1.6) }}>
          <div
            className="bg-white border border-slate-300"
            style={{ width: mm(paper === "A5" ? 13 : 17), height: mm(paper === "A5" ? 13 : 17), borderRadius: mm(0.6) }}
          >
            <div
              className="w-full h-full"
              style={{
                backgroundImage:
                  "repeating-conic-gradient(#0f172a 0% 25%, #ffffff 0% 50%)",
                backgroundSize: "36% 36%",
                borderRadius: mm(0.4),
              }}
            />
          </div>
          <div className="text-center" style={{ fontSize: Math.max(4, mm(2.2)), lineHeight: 1.5 }}>
            <p className="font-bold text-slate-900">{signer?.name || "نام تأییدکننده"}</p>
            <p className="text-slate-500">مرجع تأییدکننده</p>
            <p dir="ltr" className="font-mono font-bold text-[#3050A0]">A1B2-C3D4-E5F6-0713</p>
          </div>
        </div>
      </div>
    </div>
  ) : null;

  // پیش‌نمایش کاغذ — تصویر سربرگ رسمی (تنها منبع گرافیک) + متن نمونه + کادرهای قابل کشیدن
  const page = (
    <div
      ref={pageRef}
      className="relative bg-white border border-slate-200 shadow-md overflow-hidden mx-auto"
      style={{ width: "100%", maxWidth: 340, aspectRatio: `${geo.w} / ${geo.h}`, direction: "rtl" }}
    >
      {/* تصویر سربرگ رسمی شرکت — پس‌زمینه */}
      {bgImage ? (
        <div
          className="absolute inset-0"
          style={{ backgroundImage: `url(${bgImage})`, backgroundSize: "100% 100%", backgroundPosition: "center" }}
          aria-hidden="true"
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-[10px] text-slate-300 text-center leading-5 px-4">
            تصویر سربرگ {paper} آپلود نشده — پیش‌نمایش کاغذ خالی
            <br />
            (در چاپ هیچ گرافیک سربرگی درج نمی‌شود)
          </span>
        </div>
      )}

      {/* بِسمِهِ تَعالی — وسط، زیر نوار سربرگ */}
      <p
        className="absolute left-1/2 -translate-x-1/2 text-slate-700 whitespace-nowrap"
        style={{ top: pct(geo.besm, geo.h), fontSize: Math.max(7, mm(5)) }}
        aria-hidden="true"
      >
        بِسمِهِ تَعالی
      </p>

      {/* تاریخ/شماره — بالا-چپ (مانند چاپ واقعی) */}
      <div className="absolute text-slate-800" style={{ left: pct(geo.side, geo.w), top: pct(6, geo.h), fontSize: Math.max(5, mm(4)) }}>
        <p className="leading-relaxed">تاریخ: {toFaDigits("1405/07/12")}</p>
        <p className="leading-relaxed" dir="ltr" style={{ textAlign: "right" }}>ZDX_AD_0507019</p>
      </div>

      {/* موضوع/گیرنده — راست‌چین زیر سربرگ */}
      <div className="absolute text-right text-slate-800 font-bold" style={{ right: pct(geo.side, geo.w), top: pct(topMm + 2, geo.h), left: pct(geo.side, geo.w), fontSize: Math.max(5, mm(4.2)) }}>
        <p className="leading-relaxed">موضوع: درخواست‌نامه اداری (نمونه)</p>
        <p className="leading-relaxed opacity-80">مدیریت محترم شرکت</p>
      </div>

      {/* متن نمونه بدنه — خاکستری کم‌رنگ */}
      <div
        className="absolute text-slate-400"
        style={{ right: pct(geo.side, geo.w), left: pct(geo.side, geo.w), top: pct(topMm + 22, geo.h), fontSize: Math.max(5, mm(4.2)), lineHeight: 2.05, textAlign: "justify" }}
        aria-hidden="true"
      >
        <p>با سلام و احترام،</p>
        <p>این متن صرفاً نمونه است تا جایگاه امضا و مهر نسبت به متن نامه روی کاغذ {paper} مشخص شود؛ کادرهای امضا و مهر را بکشید و در جای دلخواه رها کنید.</p>
        <p>مختصات دقیق به میلی‌متر در پایین همین کارت نمایش داده می‌شود و در چاپ/دانلود نامه عیناً اعمال می‌گردد.</p>
      </div>

      {/* کادرهای قابل کشیدن — روی همه لایه‌ها */}
      {groupBox}
      {digiBox}

      {/* نشان حالت درگ */}
      {dragging ? (
        <div className="absolute top-1.5 left-1.5 bg-teal-600 text-white text-[10px] rounded px-2 py-0.5 shadow">
          در حال جابه‌جایی…
        </div>
      ) : null}
    </div>
  );

  const numField = (label: string, value: number, set: (v: number) => void, max: number) => (
    <div className="space-y-1">
      <Label className="text-[10px]">{label}</Label>
      <Input
        dir="ltr"
        type="number"
        min={0}
        max={max}
        className="h-8 text-xs text-left"
        value={value}
        disabled={!canEdit}
        onChange={(e) => {
          const n = parseInt(e.target.value.replace(/\D/g, ""), 10);
          set(isNaN(n) ? 0 : Math.min(max, Math.max(0, n)));
        }}
      />
    </div>
  );

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2 flex-wrap">
          <Move className="w-4 h-4 text-teal-600" /> جانمایی امضا و مهر روی کاغذ (ویژوال)
          <span className="inline-flex items-center gap-1 rounded-md bg-teal-50 border border-teal-200 px-1.5 py-0.5 text-[10px] font-normal text-teal-700">
            <MousePointerClick className="w-3 h-3" /> بکشید و رها کنید
          </span>
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          محل دقیق «امضا و مهر» و «مهر امضای دیجیتال» را روی کاغذ نامه تعیین کنید: کادرها را روی پیش‌نمایش بکشید (یا با کلیدهای جهت‌دار جابه‌جا کنید) —
          همان مختصات به میلی‌متر (فاصله از لبه چپ/پایین کاغذ) در چاپ و دانلود نامه اعمال می‌شود و با تصویر «سربرگ رسمی شرکت» (مثل کاغذ پیش‌چاپ دارای محل امضا) هماهنگ می‌ماند.
          پیش‌فرض، گروه امضا زیر متن نامه چاپ می‌شود؛ به‌محض کشیدنِ کادرها، جانمایی سفارشی فعال می‌شود.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* انتخاب سایز کاغذ + امضاکننده نمونه + سوییچ جانمایی سفارشی */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex rounded-lg border border-slate-200 overflow-hidden">
            {(["A4", "A5"] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setPaper(s)}
                className={`px-3 py-1 text-[11px] font-bold transition-colors ${
                  paper === s ? "bg-teal-600 text-white" : "bg-white text-slate-600 hover:bg-slate-50"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <div className="w-48">
            <NativeSelect
              value={String(signerIdx)}
              onChange={(v) => setSignerIdx(parseInt(v, 10) || 0)}
              disabled={!canEdit}
              ariaLabel="امضاکننده نمونه پیش‌نمایش"
            >
              {signers.length > 0
                ? signers.map((s, i) => (
                    <option key={`${s.name}-${i}`} value={i}>
                      {s.name}
                    </option>
                  ))
                : <option value={0}>امضاکننده‌ای ثبت نشده</option>}
            </NativeSelect>
          </div>
          <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
            <Switch
              checked={layout.custom}
              onCheckedChange={(v) => canEdit && setLayout({ custom: v })}
              disabled={!canEdit}
              aria-label="جانمایی سفارشی امضا و مهر"
            />
            جانمایی سفارشی {layout.custom ? "(فعال)" : "(پیش‌فرض: زیر متن نامه)"}
          </label>
        </div>

        {/* پیش‌نمایش کاغذ */}
        <div className="max-w-[340px] mx-auto">{page}</div>

        {/* مختصات دقیق (mm) */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-w-[560px]">
          {numField("گروه امضا/مهر — فاصله از لبه چپ (mm)", layout.groupX, (v) => setLayout({ groupX: v, custom: true }), geo.w)}
          {numField("گروه امضا/مهر — فاصله از لبه پایین (mm)", layout.groupY, (v) => setLayout({ groupY: v, custom: true }), geo.h)}
          {showDigi
            ? numField("مهر دیجیتال — فاصله از لبه چپ (mm)", layout.digiX, (v) => setLayout({ digiX: v, custom: true }), geo.w)
            : null}
          {showDigi
            ? numField("مهر دیجیتال — فاصله از لبه پایین (mm)", layout.digiY, (v) => setLayout({ digiY: v, custom: true }), geo.h)
            : null}
        </div>
        <p className="text-[11px] text-muted-foreground leading-5">
          مختصات برای هر سایز کاغذ جداگانه ذخیره می‌شود — پیش‌نمایش و دکمه‌های بالا را روی A4 و A5 جدا تنظیم و یک‌بار ذخیره کنید.
          {showDigi ? "" : " (مهر امضای دیجیتال طبق «اطلاعات پایه» خاموش است و چاپ نمی‌شود.)"}
        </p>

        {canEdit && (
          <div className="flex items-center gap-2 pt-2 border-t flex-wrap">
            <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
              <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره جانمایی"}
            </Button>
            <Button variant="outline" onClick={resetDefaults} disabled={saving} className="gap-1.5">
              <RotateCcw className="w-4 h-4" /> بازنشانی به پیش‌فرض
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

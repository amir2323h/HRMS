// ============================================================
// Backfill v2.9.33 — جانمایی ویژوال امضا/مهر + حذف سربرگ دیجیتال
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۳۳
//  ۳) پاکسازی کش وضعیت آپدیت
// تغییر این نسخه در چاپ/دانلود نامه‌ها:
//  • ادیتور ویژوال (درگ‌اند‌دراپ) در تنظیمات ← قالب نامه‌ها — محل
//    گروه امضا/مهر و مهر امضای دیجیتال با مختصات میلی‌متری دقیق روی
//    کاغذ A4/A5 تعیین می‌شود (هماهنگ با تصویر سربرگ رسمی)
//  • سربرگ دیجیتال (لوگو/نام شرکت/خطوط/پابرگ ساختگی) حذف شد — تنها
//    منبع گرافیک سربرگ، تصویر «سربرگ رسمی شرکت (تصویر)» تنظیمات است؛
//    بدون تصویر، هیچ گرافیک سربرگ/پابری چاپ نمی‌شود (کاغذ پیش‌چاپ)
//  (بدون تغییر اسکیما — فقط کد چاپ و تنظیمات نامه‌ها)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2933.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2933 = {
  version: "2.9.33",
  title: "تازه‌های نسخه ۲.۹.۳۳",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "نامه‌ها: جانمایی ویژوال امضا و مهر روی کاغذ (درگ‌اند‌دراپ)",
      desc: "در «تنظیمات ← قالب نامه‌ها ← جانمایی امضا و مهر (ویژوال)» پیش‌نمایش واقعی کاغذ A4/A5 با تصویر سربرگ رسمی شرکت نمایش داده می‌شود؛ کادر «امضا و مهر» (امضای دست‌نویس، مهر و باکس نام/سمت امضاکننده) و کادر «مهر امضای دیجیتال» را با ماوس بکشید و هر جای کاغذ رها کنید — همان مختصات دقیق (میلی‌متر از لبه چپ/پایین کاغذ) در چاپ و دانلود نامه اعمال می‌شود. مختصات هر سایز کاغذ جداگانه ذخیره می‌شود، با کلیدهای جهت‌دار قابل تنظیم دقیق است و دکمه «بازنشانی» چیدمان پیش‌فرض (زیر متن نامه) را برمی‌گرداند. مناسب هماهنگ‌کردن محل امضا با سربرگ رسمی شرکت یا کاغذ پیش‌چاپِ دارای جای امضا.",
    },
    {
      tag: "IMPROVED",
      title: "نامه‌ها: حذف کامل سربرگ دیجیتال — فقط تصویر «سربرگ رسمی شرکت»",
      desc: "سربرگ دیجیتال (لوگو، نام شرکت، خطوط تزئینی و پابرگ ساختگی که در نبود فایل سربرگ نمایش داده می‌شد) به‌طور کامل حذف شد. طبق درخواست، تنها منبع گرافیک سربرگ و پابرگ از این پس تصویر «سربرگ رسمی شرکت (تصویر)» در تنظیمات است: اگر تصویر A4/A5 آپلود شده باشد در پس‌زمینه صفحه قرار می‌گیرد و اگر آپلود نشده باشد، هیچ لوگو/هدر/پابرگی چاپ نمی‌شود — نامه فقط با تاریخ/شماره، بِسمِهِ تَعالی، متن و امضا/مهر برای چاپ روی کاغذ پیش‌چاپ صادر می‌شود (دکمه چاپ در این حالت «چاپ با امضا و مهر» نام دارد و هشدار عدم آپلود تصویر سربرگ نمایش داده می‌شود).",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2933) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۳۳» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.33") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2933) } });
      console.log(`✓ اطلاعیه ${cfg.version || "—"} به «تازه‌های نسخه ۲.۹.۳۳» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

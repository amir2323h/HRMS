"use client";

// ============================================================
// مدیریت تغییرات حقوق
// ۱) پیش‌نویس‌ها (ذخیره موقت — اعمال پس از تأیید)
// ۲) محاسبه معکوس خالص برای همه کارکنان (عدد خالص ← حقوق پایه)
// ۳) تغییرات گروهی (درصد / مبلغ ثابت / اضافه‌کاری)
// ۴) تاریخچه و آرشیو تغییرات حقوق (همیشه در دسترس)
// ============================================================

import { useMemo, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import {
  ClipboardList, Calculator, Users, History, CheckCheck, XCircle, Plus, ArrowLeft,
  RefreshCw, FileClock, TrendingUp, TrendingDown, Info, FileSpreadsheet, BarChart3,
  CalendarClock, Trash2,
} from "lucide-react";
import { api, useApi } from "@/lib/client";
import { formatDateJ, isoToJalaliStr, toFaDigits, JALALI_MONTHS } from "@/lib/jalali";
import { groupFa } from "@/lib/format";
import { MoneyInput, Money } from "../money-input";
import { CompareBars, TrendChart } from "../charts";
import { downloadExcelSheets } from "@/lib/excel";
import {
  computePaysheet,
  contextFromEmployee,
  shiftRateOf,
  type LegalParams,
} from "@/lib/payroll/engine";
import { solveBaseForNet } from "@/lib/payroll/solve";

// ------------------- انواع -------------------

interface SalaryEmp {
  id: string;
  personnelCode: string;
  fullName: string;
  department: string;
  jobTitle: string;
  gradeId: string | null;
  gradeLevel: number | null;
  gradeTitle: string;
  baseSalary: number; // ریال
  overtimeHours: number;
  childCount: number;
  maritalStatus: string;
  hireDateJ: string;
  employmentType: string;
  shiftPattern: string;
  gradeSeniorityBase: number;
  gradeAttraction: number;
  gradeFixedBase: number; // حقوق پایه ثابت طبقه (۰ = بدون تفکیک)
  gradeMin: number | null;
  gradeMax: number | null;
  net: number; // ریال — تخمینی
  gross: number;
  employeeSso: number;
  incomeTax: number;
  warnings: string[];
}

interface SalaryEmployeesResp {
  employees: SalaryEmp[];
  departments: { id: string; name: string }[];
  grades: { id: string; level: number; title: string; seniorityBase: number; attraction: number; fixedBaseSalary: number; departmentName?: string | null }[];
  legal: LegalParams;
  today: string;
}

interface DraftRow {
  id: string;
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  oldBaseSalary: number;
  newBaseSalary: number;
  oldOvertimeHours: number;
  newOvertimeHours: number;
  oldGradeTitle: string;
  newGradeTitle: string;
  oldNet: number;
  newNet: number;
  targetNet: number | null;
  source: string;
  reason: string;
  status: string;
  createdByName: string;
  createdAt: string;
  decidedByName: string;
  decidedAt: string | null;
}

interface LogRow {
  id: string;
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  oldBaseSalary: number;
  newBaseSalary: number;
  oldOvertimeHours: number;
  newOvertimeHours: number;
  oldGradeTitle: string;
  newGradeTitle: string;
  deltaAmount: number;
  deltaPercent: number;
  oldNet: number;
  newNet: number;
  source: string;
  reason: string;
  performedByName: string;
  performedAt: string;
}

interface SalaryLogsStats {
  totalCount: number;
  increaseCount: number;
  decreaseCount: number;
  sumDelta: number;
  // گزارش جمعی + سری ماهانه (v2.3.0)
  sumIncrease: number;
  sumDecrease: number;
  netDelta: number;
  uniqueEmployees: number;
  avgPercent: number;
  monthly: { key: string; label: string; delta: number; netDelta: number; count: number }[];
}

interface SalaryLogsResp {
  logs: LogRow[];
  stats: SalaryLogsStats;
}

interface ScheduleRow {
  id: string;
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  year: number;
  month: number;
  monthLabel: string;
  newBaseSalary: number; // ریال
  currentBaseSalary: number; // ریال — حقوق زنده کارمند
  reason: string;
  status: string;
  createdByName: string;
  createdAt: string;
  appliedAt: string | null;
  appliedByName: string;
}

interface SchedulesResp {
  schedules: ScheduleRow[];
  counts: { pending: number; due: number; currentYear: number; currentMonth: number };
}

// ------------------- برچسب‌ها -------------------

const SOURCE_LABELS: Record<string, string> = {
  MANUAL: "تغییر فردی",
  BULK: "تغییر گروهی",
  REVERSE: "محاسبه معکوس",
  EDIT: "ویرایش مستقیم پرونده",
  DECREE: "حکم حقوق",
  SCHEDULE: "زمان‌بندی ماهانه",
};

function SourceBadge({ source }: { source: string }) {
  const label = SOURCE_LABELS[source] || source;
  const cls =
    source === "BULK" ? "bg-violet-100 text-violet-800 hover:bg-violet-100"
    : source === "REVERSE" ? "bg-amber-100 text-amber-800 hover:bg-amber-100"
    : source === "EDIT" ? "bg-slate-100 text-slate-700 hover:bg-slate-100"
    : source === "SCHEDULE" ? "bg-cyan-100 text-cyan-800 hover:bg-cyan-100"
    : "bg-teal-100 text-teal-800 hover:bg-teal-100";
  return <Badge variant="outline" className={`${cls} text-[10px] px-1.5 py-0 font-medium whitespace-nowrap`}>{label}</Badge>;
}

function DeltaBadge({ amount, percent }: { amount: number; percent?: number }) {
  if (amount === 0) return <Badge variant="outline" className="text-[10px] text-muted-foreground">بدون تغییر</Badge>;
  const up = amount > 0;
  const pct = percent !== undefined && percent !== 0 ? ` (${up ? "+" : "−"}${toFaDigits(Math.abs(Math.round(percent * 10) / 10))}٪)` : "";
  return (
    <Badge className={`text-[10px] whitespace-nowrap ${up ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-100" : "bg-rose-100 text-rose-800 hover:bg-rose-100"}`}>
      {up ? "+" : "−"}{groupFa(Math.abs(Math.round(amount / 10)))} تومان{pct}
    </Badge>
  );
}

// ------------------- محاسبات سمت کلاینت (هم‌خوان با موتور سرور) -------------------

/** داده طبقه برای context — شامل حقوق پایه ثابت سطح */
interface GradeCtxData {
  seniorityBase: number;
  attraction: number;
  fixedBaseSalary?: number | null;
}

/** زمینه محاسبه کارمند برای حل معکوس/پیش‌نمایش (gradeOverride = طبقه جدید در فرم تغییر) */
function empContext(emp: SalaryEmp, legal: LegalParams, today: string, overrideOvertime?: number, gradeOverride?: GradeCtxData | null) {
  const grade: GradeCtxData = gradeOverride !== undefined
    ? (gradeOverride ?? { seniorityBase: 0, attraction: 0 })
    : { seniorityBase: emp.gradeSeniorityBase, attraction: emp.gradeAttraction, fixedBaseSalary: emp.gradeFixedBase || undefined };
  const ctx = contextFromEmployee(
    {
      baseSalary: emp.baseSalary,
      childCount: emp.childCount,
      maritalStatus: emp.maritalStatus,
      overtimeHours: overrideOvertime ?? emp.overtimeHours,
      hireDateJ: emp.hireDateJ,
      employmentType: emp.employmentType,
      shiftPattern: emp.shiftPattern,
    },
    grade,
    today
  );
  ctx.shiftRate = shiftRateOf(emp.employmentType, emp.shiftPattern, legal);
  return ctx;
}

/** حل معکوس: خالص هدف → حقوق پایه (با زمینه کامل کارمند و طبقه جدید در صورت انتخاب) */
function solveFor(emp: SalaryEmp, legal: LegalParams, today: string, targetNetRial: number, gradeOverride?: GradeCtxData | null) {
  return solveBaseForNet(targetNetRial, empContext(emp, legal, today, undefined, gradeOverride), legal);
}

/** خالص تخمینی با پایه/اضافه‌کاری جدید (و طبقه جدید در صورت انتخاب) */
function netFor(emp: SalaryEmp, legal: LegalParams, today: string, newBase: number, newOvertime?: number, gradeOverride?: GradeCtxData | null): number {
  return computePaysheet(Math.max(0, Math.round(newBase)), empContext(emp, legal, today, newOvertime, gradeOverride), legal).netPay;
}

// ----------------=== کامپوننت اصلی ===----------------

export function SalaryView({ canManage }: { canManage: boolean }) {
  const [tab, setTab] = useState(canManage ? "drafts" : "history");

  const empsApi = useApi<SalaryEmployeesResp>(canManage ? "/api/salary/employees" : null);
  const draftsApi = useApi<{ drafts: DraftRow[]; counts: { pending: number } }>(canManage ? "/api/salary/drafts?status=ALL" : null);
  const logsApi = useApi<SalaryLogsResp>("/api/salary/logs");
  const schedulesApi = useApi<SchedulesResp>(canManage ? "/api/salary/schedules?status=ALL" : null);

  const refetchAll = useCallback(() => {
    empsApi.refetch();
    draftsApi.refetch();
    logsApi.refetch();
    schedulesApi.refetch();
  }, [empsApi, draftsApi, logsApi, schedulesApi]);

  const pendingCount = draftsApi.data?.counts?.pending || 0;
  const pendingScheduleCount = schedulesApi.data?.counts?.pending || 0;

  return (
    <div className="space-y-4">
      {/* معرفی ماژول */}
      <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
        <CardContent className="p-4 flex items-center gap-3 flex-wrap">
          <ClipboardList className="w-8 h-8 text-teal-600 shrink-0" />
          <div className="flex-1 min-w-[240px]">
            <p className="font-bold text-slate-800">مدیریت تغییرات حقوق کارکنان</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              تغییر حقوق ابتدا به‌صورت <b>پیش‌نویس (ذخیره موقت)</b> ثبت می‌شود و فقط پس از <b>تأیید</b> روی پرونده اعمال می‌گردد؛
              افزایش‌های آینده را می‌توان برای ماه‌های مشخص <b>زمان‌بندی</b> کرد (مثلاً از آبان X و از بهمن Y) —
              با رسیدن ماه، خودکار در لیست حقوق اعمال می‌شود. تاریخچه و آرشیو همه تغییرات همیشه در دسترس است.
            </p>
          </div>
          {pendingCount > 0 && (
            <Badge className="bg-amber-500 text-white hover:bg-amber-500 gap-1">
              <FileClock className="w-3 h-3" />
              {toFaDigits(pendingCount)} پیش‌نویس در انتظار تأیید
            </Badge>
          )}
        </CardContent>
      </Card>

      <Tabs value={tab} onValueChange={setTab} dir="rtl">
        <TabsList className="flex-wrap h-auto">
          {canManage && (
            <TabsTrigger value="drafts" className="gap-1.5 data-[state=active]:bg-teal-600 data-[state=active]:text-white">
              <ClipboardList className="w-4 h-4" /> پیش‌نویس‌ها
              {pendingCount > 0 && <Badge className="bg-amber-400 text-amber-950 text-[10px] px-1.5 py-0 font-bold hover:bg-amber-400">{toFaDigits(pendingCount)}</Badge>}
            </TabsTrigger>
          )}
          {canManage && (
            <TabsTrigger value="reverse" className="gap-1.5 data-[state=active]:bg-teal-600 data-[state=active]:text-white">
              <Calculator className="w-4 h-4" /> محاسبه معکوس خالص
            </TabsTrigger>
          )}
          {canManage && (
            <TabsTrigger value="bulk" className="gap-1.5 data-[state=active]:bg-teal-600 data-[state=active]:text-white">
              <Users className="w-4 h-4" /> تغییرات گروهی
            </TabsTrigger>
          )}
          {canManage && (
            <TabsTrigger value="schedule" className="gap-1.5 data-[state=active]:bg-teal-600 data-[state=active]:text-white">
              <CalendarClock className="w-4 h-4" /> زمان‌بندی افزایش
              {pendingScheduleCount > 0 && <Badge className="bg-cyan-400 text-cyan-950 text-[10px] px-1.5 py-0 font-bold hover:bg-cyan-400">{toFaDigits(pendingScheduleCount)}</Badge>}
            </TabsTrigger>
          )}
          <TabsTrigger value="history" className="gap-1.5 data-[state=active]:bg-teal-600 data-[state=active]:text-white">
            <History className="w-4 h-4" /> تاریخچه و آرشیو
          </TabsTrigger>
        </TabsList>

        {canManage && (
          <TabsContent value="drafts" className="mt-4">
            <DraftsTab
              drafts={draftsApi.data?.drafts || []}
              loading={draftsApi.loading}
              employees={empsApi.data?.employees || []}
              grades={empsApi.data?.grades || []}
              legal={empsApi.data?.legal || null}
              today={empsApi.data?.today || ""}
              onChanged={refetchAll}
            />
          </TabsContent>
        )}
        {canManage && (
          <TabsContent value="reverse" className="mt-4">
            <ReverseTab
              data={empsApi.data}
              loading={empsApi.loading}
              onChanged={refetchAll}
              onGoDrafts={() => setTab("drafts")}
            />
          </TabsContent>
        )}
        {canManage && (
          <TabsContent value="bulk" className="mt-4">
            <BulkTab
              data={empsApi.data}
              loading={empsApi.loading}
              onChanged={refetchAll}
              onGoDrafts={() => setTab("drafts")}
            />
          </TabsContent>
        )}
        {canManage && (
          <TabsContent value="schedule" className="mt-4">
            <SchedulesTab
              data={schedulesApi.data}
              loading={schedulesApi.loading}
              employees={empsApi.data?.employees || []}
              legal={empsApi.data?.legal || null}
              today={empsApi.data?.today || ""}
              onChanged={refetchAll}
            />
          </TabsContent>
        )}
        <TabsContent value="history" className="mt-4">
          <HistoryTab
            data={logsApi.data}
            loading={logsApi.loading}
            onChanged={refetchAll}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ----------------=== تب پیش‌نویس‌ها ===----------------

function DraftsTab({ drafts, loading, employees, grades, legal, today, onChanged }: {
  drafts: DraftRow[];
  loading: boolean;
  employees: SalaryEmp[];
  grades: { id: string; level: number; title: string; seniorityBase: number; attraction: number; fixedBaseSalary: number; departmentName?: string | null }[];
  legal: LegalParams | null;
  today: string;
  onChanged: () => void;
}) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [confirmApplyAll, setConfirmApplyAll] = useState(false);
  const [confirmDiscardAll, setConfirmDiscardAll] = useState(false);
  const [applyNote, setApplyNote] = useState("");

  const pending = drafts.filter((d) => d.status === "PENDING");
  const decided = drafts.filter((d) => d.status !== "PENDING").slice(0, 12);

  const totalDelta = pending.reduce((s, d) => s + (d.newBaseSalary - d.oldBaseSalary), 0);
  const changed = pending.filter((d) => d.newBaseSalary !== d.oldBaseSalary).length;

  // خروجی اکسل پیش‌نویس‌های در انتظار — دو شیت: خلاصه + رکوردها (مبالغ تومان، ارقام لاتین)
  function exportDraftsExcel() {
    if (pending.length === 0) {
      toast({ title: "پیش‌نویسی برای خروجی وجود ندارد", variant: "destructive" });
      return;
    }
    const rows = pending.map((d) => ({
      "کارمند": d.employeeName,
      "کد پرسنلی": d.personnelCode,
      "منشأ": SOURCE_LABELS[d.source] || d.source,
      "حقوق پایه فعلی (تومان)": Math.round(d.oldBaseSalary / 10),
      "حقوق پایه جدید (تومان)": Math.round(d.newBaseSalary / 10),
      "تغییر پایه (تومان)": Math.round((d.newBaseSalary - d.oldBaseSalary) / 10),
      "درصد تغییر": d.oldBaseSalary > 0 ? Math.round(((d.newBaseSalary - d.oldBaseSalary) / d.oldBaseSalary) * 1000) / 10 : 0,
      "خالص فعلی (تومان)": Math.round(d.oldNet / 10),
      "خالص جدید (تومان)": Math.round(d.newNet / 10),
      "اضافه‌کاری جدید (ساعت)": d.newOvertimeHours,
      "طبقه جدید": d.newGradeTitle || "",
      "دلیل": d.reason || "",
      "ثبت‌کننده": d.createdByName || "",
      "تاریخ ثبت": formatDateJ(isoToJalaliStr(d.createdAt)),
    }));
    const summary = [
      { "شاخص": "پیش‌نویس‌های در انتظار", "مقدار": pending.length },
      { "شاخص": "مورد با تغییر پایه", "مقدار": changed },
      { "شاخص": "جمع تغییر پایه (تومان)", "مقدار": Math.round(totalDelta / 10) },
      { "شاخص": "تاریخ خروجی", "مقدار": formatDateJ(isoToJalaliStr(new Date())) },
    ];
    downloadExcelSheets(`پیش‌نویس‌های-تغییر-حقوق-${isoToJalaliStr(new Date()).replace(/\//g, "-")}.xlsx`, [
      { name: "پیش‌نویس‌ها", rows },
      { name: "خلاصه", rows: summary },
    ]);
  }

  async function patchDrafts(json: unknown, okTitle: string) {
    setBusy(true);
    try {
      const res = await api<{ applied?: number; totalDelta?: number; discarded?: number }>("/api/salary/drafts", { method: "PATCH", json });
      toast({
        title: okTitle,
        description: res.applied !== undefined
          ? `${toFaDigits(res.applied)} تغییر اعمال شد — جمع تغییر پایه: ${groupFa(Math.round((res.totalDelta || 0) / 10))} تومان`
          : `${toFaDigits(res.discarded || 0)} پیش‌نویس رد شد`,
      });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  if (loading) return <div className="space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}</div>;

  return (
    <div className="space-y-4">
      {/* خلاصه و اقدامات */}
      <Card className="rounded-2xl">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" disabled={busy || pending.length === 0} onClick={() => { setApplyNote(""); setConfirmApplyAll(true); }}>
              <CheckCheck className="w-4 h-4" /> تأیید و اعمال همه ({toFaDigits(pending.length)})
            </Button>
            <Button variant="outline" className="gap-1.5 text-rose-700 hover:text-rose-800 hover:bg-rose-50" disabled={busy || pending.length === 0} onClick={() => setConfirmDiscardAll(true)}>
              <XCircle className="w-4 h-4" /> رد همه
            </Button>
            <Button variant="outline" className="gap-1.5" onClick={() => setAddOpen(true)}>
              <Plus className="w-4 h-4" /> تغییر فردی جدید
            </Button>
            <Button variant="outline" className="gap-1.5 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50" disabled={pending.length === 0} onClick={exportDraftsExcel} title="خروجی اکسل پیش‌نویس‌های در انتظار (دو شیت: خلاصه + رکوردها)">
              <FileSpreadsheet className="w-4 h-4" /> خروجی اکسل
            </Button>
            <Button variant="ghost" size="sm" className="gap-1 mr-auto text-muted-foreground" onClick={onChanged}>
              <RefreshCw className="w-3.5 h-3.5" /> به‌روزرسانی
            </Button>
          </div>
          <div className="flex gap-2 flex-wrap text-xs">
            <Badge variant="outline" className="gap-1 py-1 px-2">
              <FileClock className="w-3 h-3 text-amber-600" />
              {toFaDigits(pending.length)} در انتظار تأیید ({toFaDigits(changed)} مورد با تغییر پایه)
            </Badge>
            <Badge variant="outline" className="gap-1 py-1 px-2">
              <TrendingUp className="w-3 h-3 text-emerald-600" />
              جمع تغییر پایه: {totalDelta >= 0 ? "+" : "−"}{groupFa(Math.abs(Math.round(totalDelta / 10)))} تومان
            </Badge>
            <Badge variant="outline" className="py-1 px-2 text-muted-foreground">
              ثبت مجدد برای یک کارمند، پیش‌نویس قبلی همان کارمند را به‌روز می‌کند
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* جدول پیش‌نویس‌های در انتظار */}
      {pending.length === 0 ? (
        <Card className="rounded-2xl border-dashed">
          <CardContent className="p-8 text-center text-muted-foreground">
            <ClipboardList className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">پیش‌نویسی در انتظار تأیید نیست</p>
            <p className="text-xs mt-1 opacity-70">تغییر حقوق از تب «محاسبه معکوس خالص» یا «تغییرات گروهی» به‌صورت ذخیره موقت ثبت می‌شود</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="rounded-2xl overflow-hidden">
          <CardHeader className="py-3 bg-slate-50 border-b">
            <CardTitle className="text-sm">پیش‌نویس‌های در انتظار — ذخیره موقت (تا تأیید روی پرونده اعمال نمی‌شود)</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">کارمند</TableHead>
                    <TableHead className="text-right">منشأ</TableHead>
                    <TableHead className="text-right">حقوق پایه (تومان)</TableHead>
                    <TableHead className="text-right">تغییر</TableHead>
                    <TableHead className="text-right">خالص تخمینی (تومان)</TableHead>
                    <TableHead className="text-right">سایر تغییرات</TableHead>
                    <TableHead className="text-right">دلیل</TableHead>
                    <TableHead className="text-right">ثبت</TableHead>
                    <TableHead className="text-right">اقدام</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pending.map((d) => (
                    <TableRow key={d.id} className="align-top">
                      <TableCell>
                        <p className="font-medium text-sm">{d.employeeName}</p>
                        <p className="text-[11px] text-muted-foreground tabular-nums">{d.personnelCode}</p>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-1 items-start">
                          <SourceBadge source={d.source} />
                          {d.targetNet ? <span className="text-[10px] text-amber-700 tabular-nums">هدف: {groupFa(Math.round(d.targetNet / 10))}</span> : null}
                        </div>
                      </TableCell>
                      <TableCell className="tabular-nums">
                        <span className="text-muted-foreground line-through decoration-muted-foreground/40">{groupFa(Math.round(d.oldBaseSalary / 10))}</span>
                        <ArrowLeft className="w-3 h-3 inline mx-1 text-muted-foreground" />
                        <span className="font-bold text-teal-800">{groupFa(Math.round(d.newBaseSalary / 10))}</span>
                      </TableCell>
                      <TableCell><DeltaBadge amount={d.newBaseSalary - d.oldBaseSalary} percent={d.oldBaseSalary > 0 ? ((d.newBaseSalary - d.oldBaseSalary) / d.oldBaseSalary) * 100 : undefined} /></TableCell>
                      <TableCell className="tabular-nums text-xs">
                        <span className="text-muted-foreground">{groupFa(Math.round(d.oldNet / 10))}</span>
                        <ArrowLeft className="w-3 h-3 inline mx-1 text-muted-foreground" />
                        <span className="font-medium text-emerald-700">{groupFa(Math.round(d.newNet / 10))}</span>
                      </TableCell>
                      <TableCell className="text-[11px] text-muted-foreground space-y-0.5">
                        {d.newOvertimeHours !== d.oldOvertimeHours && (
                          <p>اضافه‌کاری: {toFaDigits(d.oldOvertimeHours)} ← {toFaDigits(d.newOvertimeHours)} ساعت</p>
                        )}
                        {d.newGradeTitle && d.newGradeTitle !== d.oldGradeTitle && (
                          <p>طبقه: {d.oldGradeTitle || "—"} ← {d.newGradeTitle}</p>
                        )}
                        {d.newOvertimeHours === d.oldOvertimeHours && (!d.newGradeTitle || d.newGradeTitle === d.oldGradeTitle) && <span>—</span>}
                      </TableCell>
                      <TableCell className="text-xs max-w-[160px]"><p className="truncate" title={d.reason}>{d.reason || "—"}</p></TableCell>
                      <TableCell className="text-[11px] text-muted-foreground whitespace-nowrap">
                        <p>{d.createdByName || "—"}</p>
                        <p className="tabular-nums">{formatDateJ(isoToJalaliStr(d.createdAt))}</p>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="sm" className="h-7 bg-teal-600 hover:bg-teal-700 gap-1 text-[11px]" disabled={busy} onClick={() => patchDrafts({ action: "APPLY", ids: [d.id] }, "تغییر حقوق اعمال شد")}>
                            <CheckCheck className="w-3 h-3" /> اعمال
                          </Button>
                          <Button size="sm" variant="outline" className="h-7 gap-1 text-[11px] text-rose-700 hover:text-rose-800 hover:bg-rose-50" disabled={busy} onClick={() => patchDrafts({ action: "DISCARD", ids: [d.id] }, "پیش‌نویس رد شد")}>
                            <XCircle className="w-3 h-3" /> رد
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* آخرین تصمیم‌ها */}
      {decided.length > 0 && (
        <Card className="rounded-2xl">
          <CardHeader className="py-3 bg-slate-50 border-b">
            <CardTitle className="text-sm text-muted-foreground">آخرین پیش‌نویس‌های تصمیم‌گیری‌شده</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-64 overflow-y-auto">
              <Table>
                <TableBody>
                  {decided.map((d) => (
                    <TableRow key={d.id}>
                      <TableCell className="text-sm font-medium">{d.employeeName}</TableCell>
                      <TableCell><SourceBadge source={d.source} /></TableCell>
                      <TableCell className="text-xs tabular-nums text-muted-foreground">
                        {groupFa(Math.round(d.oldBaseSalary / 10))} ← {groupFa(Math.round(d.newBaseSalary / 10))} تومان
                      </TableCell>
                      <TableCell>
                        <Badge className={d.status === "APPLIED" ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-100" : "bg-slate-100 text-slate-600 hover:bg-slate-100"}>
                          {d.status === "APPLIED" ? "اعمال‌شده" : "ردشده"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[11px] text-muted-foreground whitespace-nowrap">
                        {d.decidedByName} — {d.decidedAt ? formatDateJ(isoToJalaliStr(d.decidedAt)) : ""}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* تأیید اعمال همه */}
      <AlertDialog open={confirmApplyAll} onOpenChange={setConfirmApplyAll}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>تأیید و اعمال همه پیش‌نویس‌ها؟</AlertDialogTitle>
            <AlertDialogDescription className="leading-6">
              حقوق پایه {toFaDigits(pending.length)} کارمند به مقادیر پیش‌نویس تغییر می‌کند و در «تاریخچه و آرشیو» ثبت می‌گردد.
              این اقدام قابل بازگشت خودکار نیست (بازگشت از مسیر تغییر جدید امکان‌پذیر است).
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-1.5">
            <Label className="text-xs">یادداشت اعمال (اختیاری — در تاریخچه هر کارمند ثبت می‌شود)</Label>
            <Input value={applyNote} onChange={(e) => setApplyNote(e.target.value)} placeholder="مثلاً: افزایش حقوق سال ۱۴۰۵ مصوب هیئت‌مدیره" />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              className="bg-teal-600 hover:bg-teal-700"
              onClick={() => patchDrafts({ action: "APPLY_ALL", note: applyNote }, "همه تغییرات اعمال شد")}
            >
              بله، اعمال کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* رد همه */}
      <AlertDialog open={confirmDiscardAll} onOpenChange={setConfirmDiscardAll}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>رد همه پیش‌نویس‌ها؟</AlertDialogTitle>
            <AlertDialogDescription>
              {toFaDigits(pending.length)} پیش‌نویس در انتظار رد می‌شود؛ هیچ تغییری روی پرونده کارکنان اعمال نمی‌گردد.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction className="bg-rose-600 hover:bg-rose-700" onClick={() => patchDrafts({ action: "DISCARD_ALL" }, "پیش‌نویس‌ها رد شد")}>
              بله، رد کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* فرم تغییر فردی */}
      <SingleDraftDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        employees={employees}
        grades={grades}
        legal={legal}
        today={today}
        onSaved={() => { onChanged(); toast({ title: "پیش‌نویس ثبت شد (ذخیره موقت)", description: "برای اعمال روی پرونده، از جدول بالا «تأیید و اعمال» کنید." }); }}
      />
    </div>
  );
}

// ----------------=== فرم تغییر فردی ===----------------

function SingleDraftDialog({ open, onOpenChange, employees, grades, legal, today, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  employees: SalaryEmp[];
  grades: { id: string; level: number; title: string; seniorityBase: number; attraction: number; fixedBaseSalary: number; departmentName?: string | null }[];
  legal: LegalParams | null;
  today: string;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [employeeId, setEmployeeId] = useState("");
  const [mode, setMode] = useState<"BASE" | "NET">("BASE");
  const [newBase, setNewBase] = useState(0); // تومان
  const [targetNet, setTargetNet] = useState(0); // تومان
  const [overtime, setOvertime] = useState(0);
  const [gradeId, setGradeId] = useState("");
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  const emp = employees.find((e) => e.id === employeeId) || null;

  // همگام‌سازی فیلدها با کارمند انتخابی
  const [lastEmp, setLastEmp] = useState("");
  if (emp && lastEmp !== emp.id) {
    setLastEmp(emp.id);
    setMode("BASE");
    setNewBase(Math.round(emp.baseSalary / 10));
    setTargetNet(Math.round(emp.net / 10));
    setOvertime(emp.overtimeHours);
    setGradeId("");
    setReason("");
  }

  // پیش‌نمایش زنده: پایه جدید و خالص نتیجه — با طبقه جدید در صورت انتخاب
  // (پیش از این تغییر طبقه در پیش‌نمایش لحاظ نمی‌شد و شکست پایه/مسولیت/شایستگی نادیده می‌ماند)
  const gradeOverride = useMemo(() => {
    if (!gradeId || !emp || gradeId === emp.gradeId) return undefined;
    const g = grades.find((x) => x.id === gradeId);
    return g ? { seniorityBase: g.seniorityBase, attraction: g.attraction, fixedBaseSalary: g.fixedBaseSalary || undefined } : undefined;
  }, [gradeId, emp, grades]);

  const preview = useMemo(() => {
    if (!emp || !legal) return null;
    let baseRial = Math.round(newBase * 10);
    if (mode === "NET" && targetNet > 0) {
      const solved = solveFor(emp, legal, today, Math.round(targetNet * 10), gradeOverride);
      baseRial = solved.baseSalary;
      if (!solved.ok) return { error: `خالص هدف کمتر از حداقل قابل‌تحقق (${groupFa(Math.round(solved.minAchievableNet / 10))} تومان) است` };
    }
    if (baseRial <= 0) return null;
    const net = netFor(emp, legal, today, baseRial, overtime, gradeOverride);
    return {
      baseRial,
      net,
      deltaBase: baseRial - emp.baseSalary,
      deltaNet: net - emp.net,
      gradeChanged: gradeId && gradeId !== emp.gradeId,
    };
  }, [emp, legal, today, mode, newBase, targetNet, overtime, gradeId, gradeOverride]);

  async function save() {
    if (!emp) {
      toast({ title: "کارمند را انتخاب کنید", variant: "destructive" });
      return;
    }
    const payload: Record<string, unknown> = {
      mode: "single",
      employeeId: emp.id,
      newOvertimeHours: overtime,
      newJobGradeId: gradeId || null,
      reason: reason.trim(),
    };
    if (mode === "NET" && targetNet > 0) {
      payload.targetNet = Math.round(targetNet * 10);
    } else {
      if (newBase <= 0) {
        toast({ title: "حقوق پایه جدید نامعتبر است", variant: "destructive" });
        return;
      }
      payload.newBaseSalary = Math.round(newBase * 10);
    }
    setSaving(true);
    try {
      await api("/api/salary/drafts", { method: "POST", json: payload });
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) { setEmployeeId(""); setLastEmp(""); } }}>
      <DialogContent className="sm:max-w-[40rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>ثبت تغییر حقوق فردی (پیش‌نویس)</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5 sm:col-span-2">
            <Label className="text-xs">کارمند</Label>
            <Select value={employeeId || "none"} onValueChange={(v) => setEmployeeId(v === "none" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="انتخاب کارمند…" /></SelectTrigger>
              <SelectContent className="max-h-64">
                <SelectItem value="none">— انتخاب کارمند —</SelectItem>
                {employees.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.fullName} — {e.personnelCode} {e.gradeTitle ? `(${e.gradeTitle})` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {emp && (
            <div className="sm:col-span-2 rounded-xl bg-slate-50 border p-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div>
                <p className="text-[10px] text-muted-foreground">حقوق پایه فعلی</p>
                <p className="text-sm font-bold tabular-nums text-teal-800"><Money amount={emp.baseSalary} /></p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">خالص ماهانه فعلی</p>
                <p className="text-sm font-bold tabular-nums"><Money amount={emp.net} /></p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">اضافه‌کاری فعلی</p>
                <p className="text-sm font-bold tabular-nums">{toFaDigits(emp.overtimeHours)} ساعت</p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">طبقه فعلی</p>
                <p className="text-sm font-bold">{emp.gradeTitle || "—"}</p>
              </div>
            </div>
          )}

          <div className="space-y-1.5 sm:col-span-2">
            <Label className="text-xs">روش تعیین حقوق جدید</Label>
            <div className="flex gap-2">
              <Button type="button" size="sm" variant={mode === "BASE" ? "default" : "outline"} className={mode === "BASE" ? "bg-teal-600 hover:bg-teal-700" : ""} onClick={() => setMode("BASE")}>ورود مستقیم حقوق پایه</Button>
              <Button type="button" size="sm" variant={mode === "NET" ? "default" : "outline"} className={mode === "NET" ? "bg-amber-600 hover:bg-amber-700" : ""} onClick={() => setMode("NET")}>ورود خالص پرداختی (محاسبه معکوس)</Button>
            </div>
          </div>

          {mode === "BASE" ? (
            <div className="space-y-1.5">
              <Label className="text-xs">حقوق پایه جدید (ماهانه)</Label>
              <MoneyInput value={newBase} onChange={setNewBase} />
            </div>
          ) : (
            <div className="space-y-1.5">
              <Label className="text-xs">خالص پرداختی هدف (ماهانه)</Label>
              <MoneyInput value={targetNet} onChange={setTargetNet} />
              <p className="text-[10px] text-muted-foreground">حقوق پایه به‌صورت معکوس محاسبه می‌شود</p>
            </div>
          )}

          <div className="space-y-1.5">
            <Label className="text-xs">ساعت اضافه‌کاری پیش‌فرض ماهانه</Label>
            <Input type="number" min={0} max={120} className="tabular-nums" value={overtime} onChange={(e) => setOvertime(Math.max(0, +e.target.value || 0))} />
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">طبقه شغلی</Label>
            <Select value={gradeId || "keep"} onValueChange={(v) => setGradeId(v === "keep" ? "" : v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent className="max-h-56">
                <SelectItem value="keep">بدون تغییر {emp?.gradeTitle ? `(${emp.gradeTitle})` : ""}</SelectItem>
                {grades.map((g) => (
                  <SelectItem key={g.id} value={g.id}>سطح {toFaDigits(g.level)} — {g.title}{g.departmentName ? ` (${g.departmentName})` : ""}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5 sm:col-span-2">
            <Label className="text-xs">دلیل تغییر (در تاریخچه ثبت می‌شود)</Label>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="مثلاً: ارتقای شغلی / افزایش سنواتی" />
          </div>

          {preview && !("error" in preview) && emp && (
            <div className="sm:col-span-2 rounded-xl bg-emerald-50 border border-emerald-200 p-3 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
              <div>
                <p className="text-[10px] text-muted-foreground">حقوق پایه جدید</p>
                <p className="text-sm font-bold tabular-nums text-teal-800"><Money amount={preview.baseRial} /></p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">تغییر پایه</p>
                <div className="mt-1 flex justify-center"><DeltaBadge amount={preview.deltaBase} percent={emp.baseSalary > 0 ? (preview.deltaBase / emp.baseSalary) * 100 : undefined} /></div>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">خالص ماهانه جدید</p>
                <p className="text-sm font-bold tabular-nums text-emerald-700"><Money amount={preview.net} /></p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">تغییر خالص</p>
                <div className="mt-1 flex justify-center"><DeltaBadge amount={preview.deltaNet} /></div>
              </div>
            </div>
          )}
          {preview && "error" in preview && (
            <p className="sm:col-span-2 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg p-2">{preview.error}</p>
          )}
        </div>

        <DialogFooter className="mt-2 gap-2">
          <p className="text-[11px] text-muted-foreground mr-auto flex items-center gap-1"><Info className="w-3 h-3" /> ثبت به‌صورت پیش‌نویس است — پس از تأیید اعمال می‌شود</p>
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving || !emp} className="bg-teal-600 hover:bg-teal-700">{saving ? "..." : "ثبت پیش‌نویس"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ----------------=== تب محاسبه معکوس خالص (همه کارکنان) ===----------------

function ReverseTab({ data, loading, onChanged, onGoDrafts }: {
  data: SalaryEmployeesResp | null;
  loading: boolean;
  onChanged: () => void;
  onGoDrafts: () => void;
}) {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("all");
  const [targets, setTargets] = useState<Record<string, number>>({}); // تومان
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  const legal = data?.legal || null;
  const today = data?.today || "";
  const employees = data?.employees || [];

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return employees.filter((e) => {
      if (deptFilter !== "all" && e.department !== deptFilter && !(deptFilter === "__NONE__" && !e.department)) return false;
      if (!q) return true;
      return e.fullName.toLowerCase().includes(q) || e.personnelCode.includes(q) || (e.jobTitle || "").toLowerCase().includes(q);
    });
  }, [employees, search, deptFilter]);

  // نتیجه معکوس هر ردیف که هدف آن وارد شده و با خالص فعلی فرق دارد
  const solvedRows = useMemo(() => {
    const map: Record<string, { ok: boolean; baseRial: number; minAchievableNet: number; residual: number; net: number } | { error: string }> = {};
    if (!legal) return map;
    for (const e of rows) {
      const t = targets[e.id];
      if (t === undefined || t <= 0) continue;
      const targetRial = Math.round(t * 10);
      if (targetRial === e.net) continue;
      const solved = solveFor(e, legal, today, targetRial);
      if (!solved.ok) {
        map[e.id] = { error: `حداقل خالص قابل‌تحقق ${groupFa(Math.round(solved.minAchievableNet / 10))} تومان است` };
        continue;
      }
      map[e.id] = {
        ok: true,
        baseRial: solved.baseSalary,
        minAchievableNet: solved.minAchievableNet,
        residual: solved.residual,
        net: solved.achievedNet,
      };
    }
    return map;
  }, [rows, targets, legal, today]);

  const changedIds = Object.keys(solvedRows).filter((id) => "ok" in solvedRows[id] && (solvedRows[id] as { ok: boolean }).ok);
  const errorIds = Object.keys(solvedRows).filter((id) => "error" in solvedRows[id]);

  function setTarget(id: string, toman: number) {
    setTargets((prev) => ({ ...prev, [id]: toman }));
  }

  async function registerDrafts() {
    if (changedIds.length === 0) return;
    setSaving(true);
    try {
      const res = await api<{ drafts: number; errors: string[] }>("/api/salary/drafts", {
        method: "POST",
        json: {
          mode: "reverse",
          items: changedIds.map((id) => ({ employeeId: id, targetNet: Math.round((targets[id] || 0) * 10) })),
          reason: reason.trim(),
        },
      });
      toast({
        title: `${toFaDigits(res.drafts)} پیش‌نویس معکوس ثبت شد (ذخیره موقت)`,
        description: "برای اعمال روی پرونده‌ها، تب «پیش‌نویس‌ها» را تأیید کنید.",
      });
      setTargets({});
      setReason("");
      onChanged();
      onGoDrafts();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-14 rounded-2xl" />)}</div>;
  if (!legal) return <p className="text-sm text-muted-foreground text-center p-8">پارامترهای قانونی در دسترس نیست.</p>;
  if (employees.length === 0) {
    return (
      <Card className="rounded-2xl border-dashed">
        <CardContent className="p-8 text-center text-muted-foreground">
          <Users className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p className="text-sm">کارمند فعالی ثبت نشده است</p>
          <p className="text-xs mt-1 opacity-70">پس از ثبت کارکنان، فرم محاسبه معکوس خالص فعال می‌شود</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-amber-50 to-white border-amber-200">
        <CardContent className="p-4 space-y-2">
          <p className="text-sm font-bold text-slate-800 flex items-center gap-2"><Calculator className="w-4 h-4 text-amber-600" /> عدد خالص پرداختی را وارد کنید — حقوق پایه به‌صورت معکوس محاسبه می‌شود</p>
          <p className="text-xs text-muted-foreground leading-5">
            خالص ماهانه جاری هر کارمند با پارامترهای قانونی ۱۴۰۵ و کارکرد پیش‌فرض پرسنلی (فرزند/سنوات/اضافه‌کاری/شیفت) تخمین زده می‌شود.
            عدد جدید را تایپ کنید؛ حقوق پایه معادل به‌صورت پیش‌نویس ثبت و پس از تأیید اعمال می‌گردد.
          </p>
        </CardContent>
      </Card>

      {/* فیلترها */}
      <div className="flex gap-2 flex-wrap items-center">
        <Input
          className="sm:max-w-xs"
          placeholder="جستجوی نام / کد پرسنلی / سمت…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <Select value={deptFilter} onValueChange={setDeptFilter}>
          <SelectTrigger className="sm:max-w-[220px]"><SelectValue /></SelectTrigger>
          <SelectContent className="max-h-56">
            <SelectItem value="all">همه دپارتمان‌ها</SelectItem>
            <SelectItem value="__NONE__">بدون دپارتمان</SelectItem>
            {(data?.departments || []).map((d) => (
              <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="mr-auto flex items-center gap-2">
          {changedIds.length > 0 && (
            <Badge className="bg-amber-500 text-white hover:bg-amber-500">{toFaDigits(changedIds.length)} تغییر آماده ثبت</Badge>
          )}
          <Button variant="ghost" size="sm" className="text-muted-foreground" onClick={() => setTargets({})}>پاک‌کردن همه</Button>
        </div>
      </div>

      {/* جدول همه کارکنان */}
      <Card className="rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                  <TableHead className="text-right">کارمند</TableHead>
                  <TableHead className="text-right">طبقه / سمت</TableHead>
                  <TableHead className="text-right">حقوق پایه فعلی</TableHead>
                  <TableHead className="text-right">خالص ماهانه جاری</TableHead>
                  <TableHead className="text-right">خالص پرداختی جدید</TableHead>
                  <TableHead className="text-right">حقوق پایه معکوس‌شده</TableHead>
                  <TableHead className="text-right">تغییر</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rows.map((e) => {
                  const solved = solvedRows[e.id];
                  const hasError = solved && "error" in solved;
                  const ok = solved && !hasError && (solved as { ok: boolean }).ok;
                  const target = targets[e.id];
                  return (
                    <TableRow key={e.id} className={ok ? "bg-amber-50/60" : hasError ? "bg-rose-50/60" : ""}>
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          <p className="font-medium text-sm whitespace-nowrap">{e.fullName}</p>
                          {e.warnings.length > 0 && (
                            <span title={e.warnings.join(" • ")} className="text-amber-600 cursor-help"><Info className="w-3.5 h-3.5" /></span>
                          )}
                        </div>
                        <p className="text-[11px] text-muted-foreground tabular-nums">{e.personnelCode} {e.department ? `• ${e.department}` : ""}</p>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        <p>{e.gradeTitle || "—"}</p>
                        <p className="text-[10px] opacity-70">{e.jobTitle || ""}</p>
                      </TableCell>
                      <TableCell className="tabular-nums text-sm"><Money amount={e.baseSalary} short /></TableCell>
                      <TableCell className="tabular-nums text-sm font-medium"><Money amount={e.net} short /></TableCell>
                      <TableCell className="min-w-[170px]">
                        <MoneyInput
                          value={target ?? Math.round(e.net / 10)}
                          onChange={(v) => setTarget(e.id, v)}
                          placeholder="۰"
                        />
                      </TableCell>
                      <TableCell className="tabular-nums text-sm">
                        {ok ? (
                          <span className="font-bold text-teal-800"><Money amount={(solved as { baseRial: number }).baseRial} short /></span>
                        ) : hasError ? (
                          <span className="text-[11px] text-rose-700 whitespace-nowrap">{(solved as { error: string }).error}</span>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {ok ? (
                          <DeltaBadge amount={(solved as { baseRial: number }).baseRial - e.baseSalary} percent={e.baseSalary > 0 ? (((solved as { baseRial: number }).baseRial - e.baseSalary) / e.baseSalary) * 100 : undefined} />
                        ) : hasError ? (
                          <Badge variant="outline" className="text-[10px] text-rose-700 border-rose-300">هدف نامعتبر</Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
                {rows.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-sm text-muted-foreground py-8">کارمندی مطابق فیلتر یافت نشد</TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ثبت */}
      <Card className="rounded-2xl">
        <CardContent className="p-4 flex items-center gap-2 flex-wrap">
          <Input
            className="sm:max-w-sm"
            placeholder="دلیل تغییر (در تاریخچه ثبت می‌شود) — مثلاً: تعیین خالص پرداختی مصوب ۱۴۰۵"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          />
          <Button
            className="bg-amber-600 hover:bg-amber-700 gap-1.5 mr-auto"
            disabled={saving || changedIds.length === 0}
            onClick={registerDrafts}
          >
            <ClipboardList className="w-4 h-4" />
            ثبت {changedIds.length > 0 ? `(${toFaDigits(changedIds.length)} تغییر) ` : ""}به‌عنوان پیش‌نویس
          </Button>
        </CardContent>
        {errorIds.length > 0 && (
          <CardContent className="pt-0">
            <p className="text-xs text-rose-700">{toFaDigits(errorIds.length)} ردیف هدف نامعتبر دارد و ثبت نمی‌شود (کمتر از حداقل خالص قابل‌تحقق).</p>
          </CardContent>
        )}
      </Card>
    </div>
  );
}

// ----------------=== تب تغییرات گروهی ===----------------

type BulkOpType = "PERCENT_BASE" | "SET_BASE" | "ADD_BASE" | "SET_OVERTIME";

const BULK_OP_LABELS: Record<BulkOpType, string> = {
  PERCENT_BASE: "درصد روی حقوق پایه (±)",
  SET_BASE: "تعیین مبلغ ثابت جدید برای پایه",
  ADD_BASE: "افزایش مبلغ ثابت به پایه",
  SET_OVERTIME: "تعیین ساعت اضافه‌کاری پیش‌فرض",
};

function BulkTab({ data, loading, onChanged, onGoDrafts }: {
  data: SalaryEmployeesResp | null;
  loading: boolean;
  onChanged: () => void;
  onGoDrafts: () => void;
}) {
  const { toast } = useToast();
  const [opType, setOpType] = useState<BulkOpType>("PERCENT_BASE");
  const [percent, setPercent] = useState(20);
  const [baseAmount, setBaseAmount] = useState(0); // تومان
  const [overtimeHours, setOvertimeHours] = useState(0);
  const [deptFilter, setDeptFilter] = useState("all");
  const [gradeFilter, setGradeFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  const legal = data?.legal || null;
  const today = data?.today || "";
  const employees = data?.employees || [];

  // دامنه انتخاب
  const scope = useMemo(() => {
    const q = search.trim().toLowerCase();
    return employees.filter((e) => {
      if (deptFilter !== "all" && e.department !== deptFilter && !(deptFilter === "__NONE__" && !e.department)) return false;
      if (gradeFilter === "NONE" && e.gradeId) return false;
      if (gradeFilter !== "all" && gradeFilter !== "NONE" && e.gradeId !== gradeFilter) return false;
      if (!q) return true;
      return e.fullName.toLowerCase().includes(q) || e.personnelCode.includes(q);
    });
  }, [employees, deptFilter, gradeFilter, search]);

  // پیش‌نمایش عملیات روی هر کارمند
  const preview = useMemo(() => {
    if (!legal) return [] as { emp: SalaryEmp; newBase: number; newOvertime: number; newNet: number }[];
    return scope.map((e) => {
      const oldBase = e.baseSalary;
      let newBase = oldBase;
      let newOvertime = e.overtimeHours;
      if (opType === "PERCENT_BASE") newBase = Math.round(oldBase * (1 + percent / 100));
      else if (opType === "SET_BASE") newBase = Math.round(baseAmount * 10);
      else if (opType === "ADD_BASE") newBase = Math.round(oldBase + baseAmount * 10);
      else if (opType === "SET_OVERTIME") newOvertime = Math.max(0, Math.round(overtimeHours));
      const newNet = newBase > 0 ? netFor(e, legal, today, newBase, newOvertime) : 0;
      return { emp: e, newBase, newOvertime, newNet };
    });
  }, [scope, opType, percent, baseAmount, overtimeHours, legal, today]);

  const valid = preview.filter((p) => p.newBase > 0);
  const invalid = preview.length - valid.length;
  const totalDelta = valid.reduce((s, p) => s + (p.newBase - p.emp.baseSalary), 0);
  const changedCount = valid.filter((p) => p.newBase !== p.emp.baseSalary || p.newOvertime !== p.emp.overtimeHours).length;

  const opReady =
    opType === "PERCENT_BASE" ? percent !== 0
    : opType === "SET_BASE" ? baseAmount > 0
    : opType === "ADD_BASE" ? baseAmount !== 0
    : overtimeHours >= 0;

  async function registerDrafts() {
    if (valid.length === 0) return;
    setSaving(true);
    try {
      const res = await api<{ drafts: number; errors: string[] }>("/api/salary/drafts", {
        method: "POST",
        json: {
          mode: "bulk",
          employeeIds: valid.map((p) => p.emp.id),
          operation: {
            type: opType,
            value: opType === "PERCENT_BASE" ? percent : opType === "SET_OVERTIME" ? overtimeHours : Math.round(baseAmount * 10),
          },
          reason: reason.trim(),
        },
      });
      toast({
        title: `${toFaDigits(res.drafts)} پیش‌نویس گروهی ثبت شد (ذخیره موقت)`,
        description: "برای اعمال روی پرونده‌ها، تب «پیش‌نویس‌ها» را تأیید کنید.",
      });
      setReason("");
      onChanged();
      onGoDrafts();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-14 rounded-2xl" />)}</div>;
  if (!legal) return <p className="text-sm text-muted-foreground text-center p-8">پارامترهای قانونی در دسترس نیست.</p>;
  if (employees.length === 0) {
    return (
      <Card className="rounded-2xl border-dashed">
        <CardContent className="p-8 text-center text-muted-foreground">
          <Users className="w-10 h-10 mx-auto mb-2 opacity-30" />
          <p className="text-sm">کارمند فعالی ثبت نشده است</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* فرم عملیات */}
      <Card className="rounded-2xl">
        <CardHeader className="py-3 bg-slate-50 border-b">
          <CardTitle className="text-sm">تعریف تغییر گروهی — روی {toFaDigits(scope.length)} کارمند در دامنه انتخاب</CardTitle>
        </CardHeader>
        <CardContent className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">نوع عملیات</Label>
            <Select value={opType} onValueChange={(v) => setOpType(v as BulkOpType)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(BULK_OP_LABELS).map(([k, v]) => (
                  <SelectItem key={k} value={k}>{v}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {opType === "PERCENT_BASE" && (
            <div className="space-y-1.5">
              <Label className="text-xs">درصد تغییر (منفی = کاهش)</Label>
              <Input type="number" step="0.5" className="tabular-nums" value={percent} onChange={(e) => setPercent(+e.target.value || 0)} placeholder="مثلاً: 20 یا -10" />
              <p className="text-[10px] text-muted-foreground">مثبت = افزایش • منفی = کاهش</p>
            </div>
          )}
          {(opType === "SET_BASE" || opType === "ADD_BASE") && (
            <div className="space-y-1.5">
              <Label className="text-xs">{opType === "SET_BASE" ? "مبلغ جدید حقوق پایه (همه یکسان)" : "مبلغ افزایش پایه"}</Label>
              <MoneyInput value={baseAmount} onChange={setBaseAmount} />
            </div>
          )}
          {opType === "SET_OVERTIME" && (
            <div className="space-y-1.5">
              <Label className="text-xs">ساعت اضافه‌کاری پیش‌فرض ماهانه (همه یکسان)</Label>
              <Input type="number" min={0} max={120} className="tabular-nums" value={overtimeHours} onChange={(e) => setOvertimeHours(Math.max(0, +e.target.value || 0))} />
            </div>
          )}

          <div className="space-y-1.5">
            <Label className="text-xs">دامنه: دپارتمان</Label>
            <Select value={deptFilter} onValueChange={setDeptFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent className="max-h-56">
                <SelectItem value="all">همه دپارتمان‌ها</SelectItem>
                <SelectItem value="__NONE__">بدون دپارتمان</SelectItem>
                {(data?.departments || []).map((d) => (
                  <SelectItem key={d.id} value={d.name}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">دامنه: طبقه شغلی</Label>
            <Select value={gradeFilter} onValueChange={setGradeFilter}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent className="max-h-56">
                <SelectItem value="all">همه طبقات</SelectItem>
                <SelectItem value="NONE">بدون طبقه</SelectItem>
                {(data?.grades || []).map((g) => (
                  <SelectItem key={g.id} value={g.id}>سطح {toFaDigits(g.level)} — {g.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">جستجو در دامنه</Label>
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="نام / کد پرسنلی…" />
          </div>

          <div className="space-y-1.5 sm:col-span-2 lg:col-span-3">
            <Label className="text-xs">دلیل تغییر (در تاریخچه هر کارمند ثبت می‌شود)</Label>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="مثلاً: افزایش سالانه حقوق طبق مصوبه ۱۴۰۵" />
          </div>
        </CardContent>
      </Card>

      {/* پیش‌نمایش */}
      <Card className="rounded-2xl overflow-hidden">
        <CardHeader className="py-3 bg-slate-50 border-b flex flex-wrap items-center gap-2">
          <CardTitle className="text-sm">پیش‌نمایش تغییرات ({toFaDigits(valid.length)} کارمند)</CardTitle>
          <div className="flex gap-2 flex-wrap mr-auto text-xs">
            <Badge variant="outline" className="gap-1">
              <TrendingUp className="w-3 h-3 text-emerald-600" />
              جمع تغییر پایه: {totalDelta >= 0 ? "+" : "−"}{groupFa(Math.abs(Math.round(totalDelta / 10)))} تومان
            </Badge>
            {invalid > 0 && <Badge variant="outline" className="text-rose-700 border-rose-300">{toFaDigits(invalid)} ردیف نامعتبر (پایه صفر)</Badge>}
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto max-h-[50vh] overflow-y-auto">
            <Table>
              <TableHeader className="sticky top-0 bg-white z-10">
                <TableRow>
                  <TableHead className="text-right">کارمند</TableHead>
                  <TableHead className="text-right">حقوق پایه فعلی</TableHead>
                  <TableHead className="text-right">حقوق پایه جدید</TableHead>
                  <TableHead className="text-right">تغییر پایه</TableHead>
                  <TableHead className="text-right">خالص جاری</TableHead>
                  <TableHead className="text-right">خالص جدید</TableHead>
                  {opType === "SET_OVERTIME" && <TableHead className="text-right">اضافه‌کاری</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {valid.slice(0, 200).map((p) => (
                  <TableRow key={p.emp.id} className={p.newBase !== p.emp.baseSalary ? "bg-teal-50/40" : ""}>
                    <TableCell>
                      <p className="font-medium text-sm whitespace-nowrap">{p.emp.fullName}</p>
                      <p className="text-[11px] text-muted-foreground tabular-nums">{p.emp.personnelCode} {p.emp.gradeTitle ? `• ${p.emp.gradeTitle}` : ""}</p>
                    </TableCell>
                    <TableCell className="tabular-nums text-sm"><Money amount={p.emp.baseSalary} short /></TableCell>
                    <TableCell className="tabular-nums text-sm font-bold text-teal-800"><Money amount={p.newBase} short /></TableCell>
                    <TableCell><DeltaBadge amount={p.newBase - p.emp.baseSalary} percent={p.emp.baseSalary > 0 ? ((p.newBase - p.emp.baseSalary) / p.emp.baseSalary) * 100 : undefined} /></TableCell>
                    <TableCell className="tabular-nums text-sm"><Money amount={p.emp.net} short /></TableCell>
                    <TableCell className="tabular-nums text-sm font-medium text-emerald-700"><Money amount={p.newNet} short /></TableCell>
                    {opType === "SET_OVERTIME" && (
                      <TableCell className="text-xs tabular-nums">{toFaDigits(p.emp.overtimeHours)} ← {toFaDigits(p.newOvertime)} ساعت</TableCell>
                    )}
                  </TableRow>
                ))}
                {valid.length > 200 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-xs text-muted-foreground py-3">
                      … و {toFaDigits(valid.length - 200)} کارمند دیگر (در ثبت لحاظ می‌شوند)
                    </TableCell>
                  </TableRow>
                )}
                {valid.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-sm text-muted-foreground py-8">
                      کارمندی در دامنه انتخاب نیست یا مقدار عملیات را وارد کنید
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* ثبت */}
      <Card className="rounded-2xl">
        <CardContent className="p-4 flex items-center gap-3 flex-wrap">
          <p className="text-xs text-muted-foreground flex items-center gap-1 mr-auto">
            <Info className="w-3.5 h-3.5" />
            ثبت به‌صورت پیش‌نویس (ذخیره موقت) است — پس از تأیید در تب «پیش‌نویس‌ها» اعمال می‌شود
          </p>
          <Button
            className="bg-teal-600 hover:bg-teal-700 gap-1.5"
            disabled={saving || valid.length === 0 || !opReady || changedCount === 0}
            onClick={registerDrafts}
          >
            <Users className="w-4 h-4" />
            ثبت {changedCount > 0 ? `(${toFaDigits(changedCount)} تغییر) ` : ""}گروهی به‌عنوان پیش‌نویس
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ----------------=== تب زمان‌بندی افزایش حقوق (ماه‌های آینده) ===----------------

function SchedulesTab({ data, loading, employees, legal, today, onChanged }: {
  data: SchedulesResp | null;
  loading: boolean;
  employees: SalaryEmp[];
  legal: LegalParams | null;
  today: string;
  onChanged: () => void;
}) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [confirmApplyDue, setConfirmApplyDue] = useState(false);
  const [search, setSearch] = useState("");

  const schedules = data?.schedules || [];
  const counts = data?.counts;
  const curY = counts?.currentYear || 0;
  const curM = counts?.currentMonth || 0;
  const curIdx = curY * 12 + curM;
  const dueCount = counts?.due || 0;

  const pending = schedules
    .filter((s) => s.status === "PENDING")
    .filter((s) => !search.trim() || s.employeeName.includes(search.trim()) || s.personnelCode.includes(search.trim()) || (s.monthLabel || "").includes(search.trim()))
    .sort((a, b) => a.year * 12 + a.month - (b.year * 12 + b.month));
  const decided = schedules
    .filter((s) => s.status !== "PENDING")
    .sort((a, b) => (b.appliedAt || "").localeCompare(a.appliedAt || ""))
    .slice(0, 12);

  const empById = useMemo(() => new Map(employees.map((e) => [e.id, e])), [employees]);

  async function patchSchedules(json: unknown, okTitle: string) {
    setBusy(true);
    try {
      const res = await api<{ applied?: number; totalDelta?: number; canceled?: number }>("/api/salary/schedules", { method: "PATCH", json });
      toast({
        title: okTitle,
        description: res.applied !== undefined
          ? `${toFaDigits(res.applied)} زمان‌بندی اعمال شد — جمع تغییر حقوق ماهانه: ${groupFa(Math.round((res.totalDelta || 0) / 10))} تومان`
          : `${toFaDigits(res.canceled || 0)} زمان‌بندی لغو شد`,
      });
      onChanged();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  function exportSchedulesExcel() {
    const rows = pending.map((s) => {
      const emp = empById.get(s.employeeId);
      return {
        "کارمند": s.employeeName,
        "کد پرسنلی": s.personnelCode,
        "ماه اعمال": s.monthLabel,
        "حقوق ماهانه فعلی (تومان)": Math.round((s.currentBaseSalary || emp?.baseSalary || 0) / 10),
        "حقوق ماهانه جدید (تومان)": Math.round(s.newBaseSalary / 10),
        "تغییر (تومان)": Math.round((s.newBaseSalary - (s.currentBaseSalary || emp?.baseSalary || 0)) / 10),
        "وضعیت": ymIdxOf(s) <= curIdx ? "سررسید رسیده" : "در انتظار ماه",
        "دلیل": s.reason || "",
        "ثبت‌کننده": s.createdByName || "",
        "تاریخ ثبت": formatDateJ(isoToJalaliStr(s.createdAt)),
      };
    });
    if (rows.length === 0) {
      toast({ title: "زمان‌بندی‌ای برای خروجی وجود ندارد", variant: "destructive" });
      return;
    }
    downloadExcelSheets(`زمان‌بندی-تغییر-حقوق-${isoToJalaliStr(new Date()).replace(/\//g, "-")}.xlsx`, [
      { name: "زمان‌بندی‌ها", rows },
    ]);
  }

  function ymIdxOf(s: ScheduleRow): number {
    return s.year * 12 + s.month;
  }

  if (loading) return <div className="space-y-3">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}</div>;

  return (
    <div className="space-y-4">
      {/* خلاصه و اقدامات */}
      <Card className="rounded-2xl">
        <CardContent className="p-4 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => setAddOpen(true)}>
              <Plus className="w-4 h-4" /> زمان‌بندی افزایش جدید
            </Button>
            <Button
              variant="outline"
              className="gap-1.5 text-amber-700 hover:text-amber-800 hover:bg-amber-50"
              disabled={busy || dueCount === 0}
              onClick={() => setConfirmApplyDue(true)}
              title="اعمال همه زمان‌بندی‌هایی که ماه اعمال‌شان رسیده/گذشته است"
            >
              <CheckCheck className="w-4 h-4" /> اعمال موارد سررسیدشده ({toFaDigits(dueCount)})
            </Button>
            <Button variant="outline" className="gap-1.5 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50" disabled={pending.length === 0} onClick={exportSchedulesExcel} title="خروجی اکسل زمان‌بندی‌های در انتظار">
              <FileSpreadsheet className="w-4 h-4" /> خروجی اکسل
            </Button>
            <Button variant="ghost" size="sm" className="gap-1 mr-auto text-muted-foreground" onClick={onChanged}>
              <RefreshCw className="w-3.5 h-3.5" /> به‌روزرسانی
            </Button>
          </div>
          <div className="flex gap-2 flex-wrap text-xs items-center">
            <Badge variant="outline" className="gap-1 py-1 px-2">
              <CalendarClock className="w-3 h-3 text-cyan-600" />
              {toFaDigits(counts?.pending || 0)} زمان‌بندی در انتظار ماه اعمال
            </Badge>
            {dueCount > 0 && (
              <Badge variant="outline" className="gap-1 py-1 px-2 text-amber-700 border-amber-300 bg-amber-50">
                <CheckCheck className="w-3 h-3" />
                {toFaDigits(dueCount)} مورد سررسید رسیده
              </Badge>
            )}
            <Badge variant="outline" className="py-1 px-2 text-muted-foreground gap-1 whitespace-normal text-right leading-5 max-w-full">
              <Info className="w-3 h-3 shrink-0" />
              با محاسبه لیست حقوق هر ماه، زمان‌بندی‌های رسیده به همان ماه خودکار اعمال می‌شوند
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* جدول زمان‌بندی‌های در انتظار */}
      {pending.length === 0 ? (
        <Card className="rounded-2xl border-dashed">
          <CardContent className="p-8 text-center text-muted-foreground">
            <CalendarClock className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">زمان‌بندی‌ای برای ماه‌های آینده ثبت نشده است</p>
            <p className="text-xs mt-1 opacity-70">مثال: «از آبان حقوق این کارمند X تومان و از بهمن Y تومان شود» — با رسیدن ماه، خودکار اعمال می‌شود</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="rounded-2xl overflow-hidden">
          <CardHeader className="py-3 bg-slate-50 border-b">
            <CardTitle className="text-sm flex items-center gap-2 flex-wrap">
              زمان‌بندی‌های در انتظار — تا رسیدن ماه، حقوق پرونده تغییر نمی‌کند
              <Input className="h-7 w-44 text-xs" placeholder="جستجو (نام/ماه)…" value={search} onChange={(e) => setSearch(e.target.value)} />
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10">
                  <TableRow>
                    <TableHead className="text-right">کارمند</TableHead>
                    <TableHead className="text-right">ماه اعمال</TableHead>
                    <TableHead className="text-right">حقوق ماهانه (تومان)</TableHead>
                    <TableHead className="text-right">تغییر</TableHead>
                    <TableHead className="text-right">خالص تخمینی پس از اعمال</TableHead>
                    <TableHead className="text-right">دلیل</TableHead>
                    <TableHead className="text-right">ثبت</TableHead>
                    <TableHead className="text-right">اقدام</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pending.map((s) => {
                    const emp = empById.get(s.employeeId) || null;
                    const curBase = s.currentBaseSalary || emp?.baseSalary || 0;
                    const delta = s.newBaseSalary - curBase;
                    const monthsLeft = ymIdxOf(s) - curIdx;
                    const newNet = emp && legal ? netFor(emp, legal, today, s.newBaseSalary) : null;
                    return (
                      <TableRow key={s.id} className="align-top">
                        <TableCell>
                          <p className="font-medium text-sm">{s.employeeName}</p>
                          <p className="text-[11px] text-muted-foreground tabular-nums">{s.personnelCode}</p>
                        </TableCell>
                        <TableCell>
                          <p className="text-sm font-medium whitespace-nowrap">{s.monthLabel}</p>
                          {monthsLeft <= 0 ? (
                            <Badge className="mt-1 bg-amber-100 text-amber-800 hover:bg-amber-100 text-[10px] px-1.5 py-0">سررسید رسیده</Badge>
                          ) : (
                            <p className="text-[10px] text-muted-foreground mt-0.5">{toFaDigits(monthsLeft)} ماه مانده</p>
                          )}
                        </TableCell>
                        <TableCell className="tabular-nums">
                          <span className="text-muted-foreground line-through decoration-muted-foreground/40">{groupFa(Math.round(curBase / 10))}</span>
                          <ArrowLeft className="w-3 h-3 inline mx-1 text-muted-foreground" />
                          <span className="font-bold text-teal-800">{groupFa(Math.round(s.newBaseSalary / 10))}</span>
                        </TableCell>
                        <TableCell><DeltaBadge amount={delta} percent={curBase > 0 ? (delta / curBase) * 100 : undefined} /></TableCell>
                        <TableCell className="tabular-nums text-xs">
                          {newNet !== null ? (
                            <span className="font-medium text-emerald-700">{groupFa(Math.round(newNet / 10))}</span>
                          ) : <span className="text-muted-foreground">—</span>}
                        </TableCell>
                        <TableCell className="text-xs max-w-[160px]"><p className="truncate" title={s.reason}>{s.reason || "—"}</p></TableCell>
                        <TableCell className="text-[11px] text-muted-foreground whitespace-nowrap">
                          <p>{s.createdByName || "—"}</p>
                          <p className="tabular-nums">{formatDateJ(isoToJalaliStr(s.createdAt))}</p>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button size="sm" className="h-7 bg-teal-600 hover:bg-teal-700 gap-1 text-[11px]" disabled={busy} onClick={() => patchSchedules({ action: "APPLY", ids: [s.id] }, "زمان‌بندی اعمال شد")}>
                              <CheckCheck className="w-3 h-3" /> اعمال فوری
                            </Button>
                            <Button size="sm" variant="outline" className="h-7 gap-1 text-[11px] text-rose-700 hover:text-rose-800 hover:bg-rose-50" disabled={busy} onClick={() => patchSchedules({ action: "CANCEL", ids: [s.id] }, "زمان‌بندی لغو شد")}>
                              <XCircle className="w-3 h-3" /> لغو
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* آخرین اعمال/لغوها */}
      {decided.length > 0 && (
        <Card className="rounded-2xl">
          <CardHeader className="py-3 bg-slate-50 border-b">
            <CardTitle className="text-sm text-muted-foreground">آخرین زمان‌بندی‌های اعمال/لغوشده</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-64 overflow-y-auto">
              <Table>
                <TableBody>
                  {decided.map((s) => (
                    <TableRow key={s.id}>
                      <TableCell className="text-sm font-medium">{s.employeeName}</TableCell>
                      <TableCell className="text-xs whitespace-nowrap">{s.monthLabel}</TableCell>
                      <TableCell className="text-xs tabular-nums text-muted-foreground">
                        {groupFa(Math.round(s.newBaseSalary / 10))} تومان
                      </TableCell>
                      <TableCell>
                        <Badge className={s.status === "APPLIED" ? "bg-emerald-100 text-emerald-800 hover:bg-emerald-100" : "bg-slate-100 text-slate-600 hover:bg-slate-100"}>
                          {s.status === "APPLIED" ? "اعمال‌شده" : "لغوشده"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[11px] text-muted-foreground whitespace-nowrap">
                        {s.appliedByName} — {s.appliedAt ? formatDateJ(isoToJalaliStr(s.appliedAt)) : ""}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* تأیید اعمال سررسیدشده‌ها */}
      <AlertDialog open={confirmApplyDue} onOpenChange={setConfirmApplyDue}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>اعمال {toFaDigits(dueCount)} زمان‌بندی سررسیدشده؟</AlertDialogTitle>
            <AlertDialogDescription className="leading-6">
              حقوق ماهانه کارکنانِ دارای زمان‌بندیِ رسیده، به مقادیر تعیین‌شده تغییر می‌کند و در «تاریخچه و آرشیو» ثبت می‌گردد.
              زمان‌بندی‌های ماه‌های بعدی دست‌نخورده می‌مانند.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction className="bg-teal-600 hover:bg-teal-700" onClick={() => patchSchedules({ action: "APPLY_DUE" }, "زمان‌بندی‌های سررسیدشده اعمال شد")}>
              بله، اعمال کن
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* فرم ثبت زمان‌بندی */}
      <ScheduleDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        employees={employees}
        legal={legal}
        today={today}
        existing={schedules.filter((s) => s.status === "PENDING")}
        onSaved={() => { onChanged(); toast({ title: "زمان‌بندی ثبت شد", description: "با رسیدن ماه، هنگام محاسبه لیست حقوق همان ماه خودکار اعمال می‌شود (یا همین‌جا «اعمال فوری» کنید)." }); }}
      />
    </div>
  );
}

// ----------------=== فرم زمان‌بندی افزایش (چند ماه همزمان) ===----------------

interface ScheduleFormRow {
  year: number;
  month: number;
  amount: number; // تومان
}

function ScheduleDialog({ open, onOpenChange, employees, legal, today, existing, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  employees: SalaryEmp[];
  legal: LegalParams | null;
  today: string;
  existing: ScheduleRow[];
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [employeeId, setEmployeeId] = useState("");
  const [rows, setRows] = useState<ScheduleFormRow[]>([]);
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  const emp = employees.find((e) => e.id === employeeId) || null;

  // سال/ماه جاری از تاریخ امروز («YYYY/MM/DD»)
  const todayParts = today.split("/").map((x) => parseInt(x, 10));
  const curY = todayParts[0] || 0;
  const curM = todayParts[1] || 0;
  const curIdx = curY * 12 + curM;

  function nextMonth(y: number, m: number): { year: number; month: number } {
    return m >= 12 ? { year: y + 1, month: 1 } : { year: y, month: m + 1 };
  }

  // همگام‌سازی با کارمند انتخابی — یک ردیف پیش‌فرض (ماه بعد)
  const [lastEmp, setLastEmp] = useState("");
  if (emp && lastEmp !== emp.id) {
    setLastEmp(emp.id);
    const nm = nextMonth(curY, curM);
    setRows([{ year: nm.year, month: nm.month, amount: Math.round(emp.baseSalary / 10) }]);
    setReason("");
  }

  const yearOptions = useMemo(() => [curY, curY + 1, curY + 2].filter((y) => y > 0), [curY]);
  const empSchedules = useMemo(() => existing.filter((s) => s.employeeId === employeeId), [existing, employeeId]);

  function setRow(i: number, patch: Partial<ScheduleFormRow>) {
    setRows((rs) => rs.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  }

  const validRows = rows.filter((r) => r.amount > 0 && r.month >= 1 && r.month <= 12 && r.year >= curY);

  async function save() {
    if (!emp) {
      toast({ title: "کارمند را انتخاب کنید", variant: "destructive" });
      return;
    }
    if (validRows.length === 0) {
      toast({ title: "حداقل یک ردیف معتبر (ماه + مبلغ) لازم است", variant: "destructive" });
      return;
    }
    // جلوگیری از ماه تکراری داخل خود فرم
    const keys = new Set<string>();
    for (const r of validRows) {
      const k = `${r.year}/${r.month}`;
      if (keys.has(k)) {
        toast({ title: `ماه ${JALALI_MONTHS[r.month - 1]} ${r.year} تکراری است — هر ماه یک ردیف`, variant: "destructive" });
        return;
      }
      keys.add(k);
    }
    setSaving(true);
    try {
      const res = await api<{ created: number; updated: number }>("/api/salary/schedules", {
        method: "POST",
        json: {
          items: validRows.map((r) => ({
            employeeId: emp.id,
            year: r.year,
            month: r.month,
            newBaseSalary: Math.round(r.amount * 10), // تومان → ریال
            reason: reason.trim(),
          })),
        },
      });
      onOpenChange(false);
      onSaved();
      toast({
        title: `${toFaDigits(res.created + res.updated)} زمان‌بندی ثبت شد`,
        description: res.updated > 0 ? `(${toFaDigits(res.created)} جدید، ${toFaDigits(res.updated)} به‌روزرسانی موارد قبلی همان ماه)` : undefined,
      });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) { setEmployeeId(""); setLastEmp(""); setRows([]); } }}>
      <DialogContent className="sm:max-w-[44rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>زمان‌بندی افزایش حقوق برای ماه‌های آینده</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">کارمند</Label>
            <Select value={employeeId || "none"} onValueChange={(v) => setEmployeeId(v === "none" ? "" : v)}>
              <SelectTrigger><SelectValue placeholder="انتخاب کارمند…" /></SelectTrigger>
              <SelectContent className="max-h-64">
                <SelectItem value="none">— انتخاب کارمند —</SelectItem>
                {employees.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.fullName} — {e.personnelCode} {e.gradeTitle ? `(${e.gradeTitle})` : ""}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {emp && (
            <div className="rounded-xl bg-slate-50 border p-3 grid grid-cols-2 sm:grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-[10px] text-muted-foreground">حقوق ماهانه فعلی</p>
                <p className="text-sm font-bold tabular-nums text-teal-800"><Money amount={emp.baseSalary} /></p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">خالص ماهانه فعلی (تخمینی)</p>
                <p className="text-sm font-bold tabular-nums"><Money amount={emp.net} /></p>
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground">طبقه فعلی</p>
                <p className="text-sm font-bold">{emp.gradeTitle || "—"}</p>
              </div>
            </div>
          )}

          {empSchedules.length > 0 && (
            <div className="rounded-xl bg-amber-50 border border-amber-200 p-3 text-xs space-y-1">
              <p className="font-medium text-amber-800 flex items-center gap-1"><CalendarClock className="w-3.5 h-3.5" /> زمان‌بندی‌های در انتظار این کارمند:</p>
              {empSchedules.map((s) => (
                <p key={s.id} className="text-amber-800 tabular-nums">• {s.monthLabel} ← {groupFa(Math.round(s.newBaseSalary / 10))} تومان (ثبت مجدد همان ماه = به‌روزرسانی)</p>
              ))}
            </div>
          )}

          {/* ردیف‌های ماه/مبلغ */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-xs">ماه اعمال و حقوق ماهانه جدید</Label>
              <Button
                type="button" size="sm" variant="outline" className="h-7 gap-1 text-[11px]"
                onClick={() => {
                  const last = rows[rows.length - 1];
                  const nm = last ? nextMonth(last.year, last.month) : nextMonth(curY, curM);
                  setRows((rs) => [...rs, { year: nm.year, month: nm.month, amount: last?.amount || 0 }]);
                }}
              >
                <Plus className="w-3 h-3" /> افزودن ماه دیگر
              </Button>
            </div>
            {rows.length === 0 && (
              <p className="text-xs text-muted-foreground">با انتخاب کارمند، یک ردیف پیش‌فرض (ماه بعد) ساخته می‌شود</p>
            )}
            {rows.map((r, i) => {
              const rowIdx = r.year * 12 + r.month;
              const isPast = rowIdx < curIdx;
              const dupInForm = rows.filter((x) => x.year === r.year && x.month === r.month).length > 1;
              const exists = empSchedules.some((s) => s.year === r.year && s.month === r.month);
              const previewNet = emp && legal && r.amount > 0 ? netFor(emp, legal, today, Math.round(r.amount * 10)) : null;
              return (
                <div key={i} className="rounded-xl border p-3 space-y-2 bg-white">
                  <div className="grid grid-cols-1 sm:grid-cols-[9rem_9rem_1fr_auto] gap-2 items-end">
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">سال</Label>
                      <Select value={String(r.year)} onValueChange={(v) => setRow(i, { year: +v })}>
                        <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{toFaDigits(y)}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">ماه</Label>
                      <Select value={String(r.month)} onValueChange={(v) => setRow(i, { month: +v })}>
                        <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                        <SelectContent className="max-h-56">
                          {JALALI_MONTHS.map((m, idx) => {
                            const mIdx = r.year * 12 + (idx + 1);
                            const past = mIdx < curIdx;
                            return (
                              <SelectItem key={m} value={String(idx + 1)} disabled={past}>{m}{past ? " (گذشته)" : ""}</SelectItem>
                            );
                          })}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground">حقوق ماهانه از این ماه (تومان)</Label>
                      <MoneyInput value={r.amount} onChange={(v) => setRow(i, { amount: v })} />
                    </div>
                    <Button
                      type="button" size="sm" variant="outline" className="h-8 text-rose-700 hover:text-rose-800 hover:bg-rose-50"
                      disabled={rows.length <= 1}
                      onClick={() => setRows((rs) => rs.filter((_, idx) => idx !== i))}
                      title="حذف این ردیف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                  {(isPast || dupInForm) && (
                    <p className="text-[11px] text-rose-700">
                      {isPast ? "ماه گذشته قابل زمان‌بندی نیست — برای ماه‌های گذشته از «پیش‌نویس تغییر حقوق» استفاده کنید" : "این ماه در فرم تکراری است"}
                    </p>
                  )}
                  {exists && !dupInForm && (
                    <p className="text-[11px] text-amber-700">زمان‌بندی همین ماه از قبل ثبت شده — با ذخیره، به‌روزرسانی می‌شود</p>
                  )}
                  {previewNet !== null && emp && (
                    <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
                      <span>تغییر حقوق ماهانه: <DeltaBadge amount={Math.round(r.amount * 10) - emp.baseSalary} percent={emp.baseSalary > 0 ? ((r.amount * 10 - emp.baseSalary) / emp.baseSalary) * 100 : undefined} /></span>
                      <span className="tabular-nums">خالص تخمینی پس از اعمال: <span className="font-medium text-emerald-700">{groupFa(Math.round(previewNet / 10))} تومان</span></span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="space-y-1.5">
            <Label className="text-xs">دلیل/توضیح (در تاریخچه هر ماه ثبت می‌شود)</Label>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="مثلاً: افزایش سنواتی مصوب هیئت‌مدیره" />
          </div>
        </div>

        <DialogFooter className="mt-2 gap-2">
          <p className="text-[11px] text-muted-foreground mr-auto flex items-center gap-1 text-right leading-4">
            <Info className="w-3 h-3 shrink-0" />
            اعمال خودکار هنگام محاسبه لیست حقوقِ ماه مربوطه؛ یا همین حالا از دکمه «اعمال فوری»
          </p>
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving || !emp || validRows.length === 0} className="bg-teal-600 hover:bg-teal-700">
            {saving ? "..." : `ثبت ${toFaDigits(validRows.length)} زمان‌بندی`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ----------------=== تب تاریخچه و آرشیو ===----------------

function HistoryTab({ data, loading, onChanged }: {
  data: SalaryLogsResp | null;
  loading: boolean;
  onChanged: () => void;
}) {
  const { toast } = useToast();
  const [employeeFilter, setEmployeeFilter] = useState("all");
  const [sourceFilter, setSourceFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [archive, setArchive] = useState<LogRow[] | null>(null);
  const [archiveName, setArchiveName] = useState("");

  const logs = data?.logs || [];
  const stats = data?.stats;

  // گزینه‌های فیلتر کارمند از خود لاگ‌ها (مستقل از دسترسی salary:manage)
  const employeeOptions = useMemo(() => {
    const seen = new Map<string, string>();
    for (const l of logs) {
      if (!seen.has(l.employeeId)) seen.set(l.employeeId, `${l.employeeName} — ${l.personnelCode}`);
    }
    return [...seen.entries()].sort((a, b) => a[1].localeCompare(b[1], "fa"));
  }, [logs]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return logs.filter((l) => {
      if (employeeFilter !== "all" && l.employeeId !== employeeFilter) return false;
      if (sourceFilter !== "all" && l.source !== sourceFilter) return false;
      if (!q) return true;
      return l.employeeName.toLowerCase().includes(q) || l.personnelCode.includes(q) || (l.reason || "").toLowerCase().includes(q) || (l.performedByName || "").toLowerCase().includes(q);
    });
  }, [logs, employeeFilter, sourceFilter, search]);

  // بزرگ‌ترین تغییرات نمای فعلی (فیلترشده) — برای نمودار قبل ← بعد
  const topChanges = useMemo(() => {
    return [...filtered]
      .sort((a, b) => Math.abs(b.deltaAmount) - Math.abs(a.deltaAmount))
      .slice(0, 8)
      .map((l) => ({
        label: `${l.employeeName} (${l.personnelCode})`,
        before: Math.round(l.oldBaseSalary / 10),
        after: Math.round(l.newBaseSalary / 10),
        delta: Math.round(l.deltaAmount / 10),
        sub: `خالص: ${groupFa(Math.round(l.oldNet / 10))} ← ${groupFa(Math.round(l.newNet / 10))} تومان • ${SOURCE_LABELS[l.source] || l.source} • ${formatDateJ(isoToJalaliStr(l.performedAt))}`,
      }));
  }, [filtered]);

  // روند جمع تغییرات ماهانه (کل آرشیو — از سرور)
  const monthlyTrend = useMemo(() => {
    return (stats?.monthly || []).map((m) => ({
      label: toFaDigits(m.label),
      value: Math.round(m.delta / 10), // تومان
    }));
  }, [stats]);

  const fmtToman = (v: number) => `${groupFa(Math.round(v))} تومان`;

  // خروجی اکسل تاریخچه — سه شیت: خلاصه + تاریخچه (فیلترشده) + روند ماهانه
  function exportHistoryExcel() {
    if (filtered.length === 0) {
      toast({ title: "رکوردی برای خروجی وجود ندارد", variant: "destructive" });
      return;
    }
    const rows = filtered.map((l) => ({
      "تاریخ": formatDateJ(isoToJalaliStr(l.performedAt)),
      "کارمند": l.employeeName,
      "کد پرسنلی": l.personnelCode,
      "منشأ": SOURCE_LABELS[l.source] || l.source,
      "حقوق پایه قبلی (تومان)": Math.round(l.oldBaseSalary / 10),
      "حقوق پایه جدید (تومان)": Math.round(l.newBaseSalary / 10),
      "تغییر پایه (تومان)": Math.round(l.deltaAmount / 10),
      "درصد تغییر": Math.round(l.deltaPercent * 10) / 10,
      "خالص قبلی (تومان)": Math.round(l.oldNet / 10),
      "خالص جدید (تومان)": Math.round(l.newNet / 10),
      "دلیل": l.reason || "",
      "ثبت‌کننده": l.performedByName || "",
    }));
    const summary = [
      { "شاخص": "کل تغییرات ثبت‌شده", "مقدار": stats?.totalCount ?? 0 },
      { "شاخص": "افزایشی", "مقدار": stats?.increaseCount ?? 0 },
      { "شاخص": "کاهشی", "مقدار": stats?.decreaseCount ?? 0 },
      { "شاخص": "جمع افزایش پایه (تومان)", "مقدار": Math.round((stats?.sumIncrease || 0) / 10) },
      { "شاخص": "جمع کاهش پایه (تومان)", "مقدار": Math.round((stats?.sumDecrease || 0) / 10) },
      { "شاخص": "اثر خالص بر خالص ماهانه (تومان)", "مقدار": Math.round((stats?.netDelta || 0) / 10) },
      { "شاخص": "کارکنان تغییرکرده", "مقدار": stats?.uniqueEmployees ?? 0 },
      { "شاخص": "میانگین درصد تغییر", "مقدار": Math.round((stats?.avgPercent || 0) * 10) / 10 },
      { "شاخص": "رکوردهای این خروجی (فیلترشده)", "مقدار": filtered.length },
      { "شاخص": "تاریخ خروجی", "مقدار": formatDateJ(isoToJalaliStr(new Date())) },
    ];
    const monthlyRows = (stats?.monthly || []).map((m) => ({
      "ماه": m.label,
      "جمع تغییر پایه (تومان)": Math.round(m.delta / 10),
      "اثر بر خالص (تومان)": Math.round(m.netDelta / 10),
      "تعداد تغییر": m.count,
    }));
    downloadExcelSheets(`تغییرات-حقوق-کارکنان-${isoToJalaliStr(new Date()).replace(/\//g, "-")}.xlsx`, [
      { name: "خلاصه", rows: summary },
      { name: "تاریخچه", rows },
      ...(monthlyRows.length > 0 ? [{ name: "روند ماهانه", rows: monthlyRows }] : []),
    ]);
  }

  async function openArchive(employeeId: string, name: string) {
    try {
      const res = await api<{ logs: LogRow[] }>(`/api/salary/logs?employeeId=${encodeURIComponent(employeeId)}&limit=1000`);
      setArchive(res.logs.slice().reverse()); // قدیمی → جدید
      setArchiveName(name);
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  if (loading) return <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-16 rounded-2xl" />)}</div>;

  return (
    <div className="space-y-4">
      {/* آمار آرشیو */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card className="rounded-2xl">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0"><History className="w-5 h-5" /></div>
            <div>
              <p className="text-[11px] text-muted-foreground">کل تغییرات ثبت‌شده</p>
              <p className="text-lg font-black tabular-nums">{toFaDigits(stats?.totalCount || 0)}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0"><TrendingUp className="w-5 h-5" /></div>
            <div>
              <p className="text-[11px] text-muted-foreground">افزایشی</p>
              <p className="text-lg font-black tabular-nums">{toFaDigits(stats?.increaseCount || 0)}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center shrink-0"><TrendingDown className="w-5 h-5" /></div>
            <div>
              <p className="text-[11px] text-muted-foreground">کاهشی</p>
              <p className="text-lg font-black tabular-nums">{toFaDigits(stats?.decreaseCount || 0)}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-2xl">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0"><TrendingUp className="w-5 h-5" /></div>
            <div className="min-w-0">
              <p className="text-[11px] text-muted-foreground">جمع تغییرات پایه</p>
              <p className="text-sm font-black tabular-nums truncate">
                {(stats?.sumDelta || 0) >= 0 ? "+" : "−"}{groupFa(Math.abs(Math.round((stats?.sumDelta || 0) / 10)))} تومان
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* گزارش جمعی تغییرات — چقدر در مجموع تغییر حاصل شده؟ */}
      {stats && stats.totalCount > 0 && (
        <Card className="rounded-2xl bg-gradient-to-l from-teal-50/70 to-white border-teal-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-teal-600" /> گزارش جمعی تغییرات حقوق (کل آرشیو)
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="rounded-xl bg-white border p-3 text-center">
              <p className="text-[10px] text-muted-foreground">جمع افزایش پایه</p>
              <p className="text-sm font-black tabular-nums text-emerald-700 mt-1">+{groupFa(Math.round(stats.sumIncrease / 10))}</p>
              <p className="text-[10px] text-muted-foreground">تومان • {toFaDigits(stats.increaseCount)} مورد</p>
            </div>
            <div className="rounded-xl bg-white border p-3 text-center">
              <p className="text-[10px] text-muted-foreground">جمع کاهش پایه</p>
              <p className="text-sm font-black tabular-nums text-rose-700 mt-1">−{groupFa(Math.round(stats.sumDecrease / 10))}</p>
              <p className="text-[10px] text-muted-foreground">تومان • {toFaDigits(stats.decreaseCount)} مورد</p>
            </div>
            <div className="rounded-xl bg-white border p-3 text-center">
              <p className="text-[10px] text-muted-foreground">اثر خالص بر خالص ماهانه</p>
              <p className={`text-sm font-black tabular-nums mt-1 ${stats.netDelta >= 0 ? "text-teal-700" : "text-rose-700"}`}>
                {stats.netDelta >= 0 ? "+" : "−"}{groupFa(Math.round(Math.abs(stats.netDelta) / 10))}
              </p>
              <p className="text-[10px] text-muted-foreground">تومان (خالص جدید − خالص قبلی)</p>
            </div>
            <div className="rounded-xl bg-white border p-3 text-center">
              <p className="text-[10px] text-muted-foreground">جمع تغییر پایه</p>
              <p className={`text-sm font-black tabular-nums mt-1 ${stats.sumDelta >= 0 ? "text-slate-800" : "text-rose-700"}`}>
                {stats.sumDelta >= 0 ? "+" : "−"}{groupFa(Math.round(Math.abs(stats.sumDelta) / 10))}
              </p>
              <p className="text-[10px] text-muted-foreground">تومان</p>
            </div>
            <div className="rounded-xl bg-white border p-3 text-center">
              <p className="text-[10px] text-muted-foreground">کارکنان تغییرکرده</p>
              <p className="text-sm font-black tabular-nums mt-1">{toFaDigits(stats.uniqueEmployees)}</p>
              <p className="text-[10px] text-muted-foreground">نفر (یکتا)</p>
            </div>
            <div className="rounded-xl bg-white border p-3 text-center">
              <p className="text-[10px] text-muted-foreground">میانگین درصد تغییر</p>
              <p className="text-sm font-black tabular-nums mt-1">{stats.avgPercent >= 0 ? "+" : "−"}{toFaDigits(Math.round(Math.abs(stats.avgPercent) * 10) / 10)}٪</p>
              <p className="text-[10px] text-muted-foreground">فقط رکوردهای درصدی</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* نمودارها: بزرگ‌ترین تغییرات قبل ← بعد + روند ماهانه */}
      {logs.length > 0 && (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          <Card className="rounded-2xl overflow-hidden">
            <CardHeader className="py-3 bg-slate-50 border-b">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-teal-600" /> بزرگ‌ترین تغییرات — قبل ← بعد
                <Badge variant="outline" className="mr-auto text-[10px] font-normal">۸ تغییر برتر نمای فعلی</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 max-h-[52vh] overflow-y-auto">
              <CompareBars data={topChanges} formatter={fmtToman} />
            </CardContent>
          </Card>
          <Card className="rounded-2xl overflow-hidden">
            <CardHeader className="py-3 bg-slate-50 border-b">
              <CardTitle className="text-sm flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-teal-600" /> روند جمع تغییرات ماهانه (کل آرشیو)
                <Badge variant="outline" className="mr-auto text-[10px] font-normal">جمع Δ پایه — تومان</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3">
              {monthlyTrend.length > 1 ? (
                <TrendChart data={monthlyTrend} height={260} formatter={(v) => `${groupFa(Math.round(v))} ت`} />
              ) : (
                <p className="text-sm text-muted-foreground text-center py-12">بر رسم روند حداقل دو ماه تغییر لازم است — {monthlyTrend.length === 1 ? "تاکنون یک ماه تغییر ثبت شده است" : "تغییری ثبت نشده است"}.</p>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* فیلترها */}
      <div className="flex gap-2 flex-wrap items-center">
        <Input className="sm:max-w-xs" placeholder="جستجو در تاریخچه (نام/دلیل/ثبت‌کننده)…" value={search} onChange={(e) => setSearch(e.target.value)} />
        <Select value={employeeFilter} onValueChange={setEmployeeFilter}>
          <SelectTrigger className="sm:max-w-[240px]"><SelectValue /></SelectTrigger>
          <SelectContent className="max-h-56">
            <SelectItem value="all">همه کارکنان</SelectItem>
            {employeeOptions.map(([id, label]) => (
              <SelectItem key={id} value={id}>{label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sourceFilter} onValueChange={setSourceFilter}>
          <SelectTrigger className="sm:max-w-[180px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه منشأها</SelectItem>
            {Object.entries(SOURCE_LABELS).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" className="gap-1 text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50" disabled={filtered.length === 0} onClick={exportHistoryExcel} title="خروجی اکسل تاریخچه (خلاصه + رکوردهای فیلترشده + روند ماهانه)">
          <FileSpreadsheet className="w-3.5 h-3.5" /> خروجی اکسل
        </Button>
        <Button variant="ghost" size="sm" className="gap-1 mr-auto text-muted-foreground" onClick={onChanged}>
          <RefreshCw className="w-3.5 h-3.5" /> به‌روزرسانی
        </Button>
      </div>

      {/* جدول تاریخچه */}
      {filtered.length === 0 ? (
        <Card className="rounded-2xl border-dashed">
          <CardContent className="p-8 text-center text-muted-foreground">
            <History className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm">تغییری در حقوق ثبت نشده است</p>
            <p className="text-xs mt-1 opacity-70">هر تغییر تأییدشده (فردی/گروهی/معکوس/ویرایش مستقیم) اینجا آرشیو می‌شود</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="rounded-2xl overflow-hidden">
          <CardHeader className="py-3 bg-slate-50 border-b">
            <CardTitle className="text-sm">لاگ تغییرات حقوق — {toFaDigits(filtered.length)} رکورد (آخرین {toFaDigits(logs.length)})</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
              <Table>
                <TableHeader className="sticky top-0 bg-white z-10">
                  <TableRow>
                    <TableHead className="text-right">تاریخ</TableHead>
                    <TableHead className="text-right">کارمند</TableHead>
                    <TableHead className="text-right">منشأ</TableHead>
                    <TableHead className="text-right">حقوق پایه (تومان)</TableHead>
                    <TableHead className="text-right">تغییر</TableHead>
                    <TableHead className="text-right">خالص تخمینی (تومان)</TableHead>
                    <TableHead className="text-right">دلیل</TableHead>
                    <TableHead className="text-right">ثبت‌کننده</TableHead>
                    <TableHead className="text-right">آرشیو</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((l) => (
                    <TableRow key={l.id}>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap tabular-nums">{formatDateJ(isoToJalaliStr(l.performedAt))}</TableCell>
                      <TableCell>
                        <p className="text-sm font-medium whitespace-nowrap">{l.employeeName}</p>
                        <p className="text-[11px] text-muted-foreground tabular-nums">{l.personnelCode}</p>
                      </TableCell>
                      <TableCell><SourceBadge source={l.source} /></TableCell>
                      <TableCell className="tabular-nums text-xs whitespace-nowrap">
                        <span className="text-muted-foreground line-through decoration-muted-foreground/40">{groupFa(Math.round(l.oldBaseSalary / 10))}</span>
                        <ArrowLeft className="w-3 h-3 inline mx-1 text-muted-foreground" />
                        <span className="font-bold text-teal-800">{groupFa(Math.round(l.newBaseSalary / 10))}</span>
                      </TableCell>
                      <TableCell><DeltaBadge amount={l.deltaAmount} percent={l.deltaPercent} /></TableCell>
                      <TableCell className="tabular-nums text-xs whitespace-nowrap">
                        <span className="text-muted-foreground">{groupFa(Math.round(l.oldNet / 10))}</span>
                        <ArrowLeft className="w-3 h-3 inline mx-1 text-muted-foreground" />
                        <span className="font-medium text-emerald-700">{groupFa(Math.round(l.newNet / 10))}</span>
                      </TableCell>
                      <TableCell className="text-xs max-w-[200px]"><p className="truncate" title={l.reason}>{l.reason || "—"}</p></TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{l.performedByName || "—"}</TableCell>
                      <TableCell>
                        <Button size="sm" variant="ghost" className="h-7 gap-1 text-[11px] text-teal-700 hover:bg-teal-50" onClick={() => openArchive(l.employeeId, `${l.employeeName} (${l.personnelCode})`)}>
                          <History className="w-3 h-3" /> پرونده تغییرات
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* مودال آرشیو کارمند */}
      <Dialog open={!!archive} onOpenChange={(v) => { if (!v) setArchive(null); }}>
        <DialogContent className="sm:max-w-[46rem] max-h-[85vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle>آرشیو تغییرات حقوق — {archiveName}</DialogTitle>
          </DialogHeader>
          {archive && archive.length > 0 ? (
            <div className="relative pr-4">
              {/* خط زمانی */}
              <div className="absolute right-[7px] top-2 bottom-2 w-0.5 bg-teal-200" aria-hidden="true" />
              <div className="space-y-3">
                {archive.map((l, idx) => (
                  <div key={l.id} className="relative pr-6">
                    <span className={`absolute right-[-1px] top-1.5 w-4 h-4 rounded-full border-2 border-white ${l.deltaAmount >= 0 ? "bg-emerald-500" : "bg-rose-500"}`} aria-hidden="true" />
                    <div className="rounded-xl border bg-slate-50 p-3">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs text-muted-foreground tabular-nums">{formatDateJ(isoToJalaliStr(l.performedAt))}</span>
                        <SourceBadge source={l.source} />
                        {idx === archive.length - 1 && <Badge className="bg-teal-600 hover:bg-teal-600 text-[10px]">وضعیت فعلی</Badge>}
                      </div>
                      <div className="mt-2 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                        <div>
                          <p className="text-[10px] text-muted-foreground">حقوق پایه</p>
                          <p className="text-xs font-bold tabular-nums">
                            <span className="text-muted-foreground font-normal">{groupFa(Math.round(l.oldBaseSalary / 10))}</span>
                            <ArrowLeft className="w-3 h-3 inline mx-0.5" />
                            {groupFa(Math.round(l.newBaseSalary / 10))}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground">تغییر</p>
                          <div className="mt-0.5 flex justify-center"><DeltaBadge amount={l.deltaAmount} percent={l.deltaPercent} /></div>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground">خالص تخمینی</p>
                          <p className="text-xs font-bold tabular-nums">
                            <span className="text-muted-foreground font-normal">{groupFa(Math.round(l.oldNet / 10))}</span>
                            <ArrowLeft className="w-3 h-3 inline mx-0.5" />
                            {groupFa(Math.round(l.newNet / 10))}
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] text-muted-foreground">اضافه‌کاری / طبقه</p>
                          <p className="text-xs font-medium">
                            {l.newOvertimeHours !== l.oldOvertimeHours ? `${toFaDigits(l.oldOvertimeHours)} ← ${toFaDigits(l.newOvertimeHours)} ساعت` : "—"}
                          </p>
                          {l.newGradeTitle && l.newGradeTitle !== l.oldGradeTitle && (
                            <p className="text-[10px] text-muted-foreground">{l.oldGradeTitle || "—"} ← {l.newGradeTitle}</p>
                          )}
                        </div>
                      </div>
                      {l.reason && <p className="text-[11px] text-muted-foreground mt-2 border-t pt-1.5">دلیل: {l.reason}</p>}
                      <p className="text-[10px] text-muted-foreground mt-1">ثبت: {l.performedByName || "—"}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center p-6">تغییری برای این کارمند ثبت نشده است</p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

"use client";

// ============================================================
// ماژول پاداش/سود سالانه — سه بخش:
//   مدل ۱ (طرح): لِول‌بندی + تارگت + بودجه — فرمول: حقوق پایه × ماه طبقه (+۱ اورتارگت) × (ماه حضور ÷ ۱۲) × درصد تیر
//   مدل ۲ (برآورد بودجه): توزیع نفرات در چهار وضعیت تحقق تارگت ← بودجه لازم
//   حکم گروهی: «خالص پرداختی هر نفر» به‌صورت گروهی ← معکوس از روی حقوق پایه دستیِ
//   هر کارمند (نرخ مالیات نهایی او) ← صدور حکم؛ پیش‌بینی بودجه احکام را لحاظ می‌کند
// ============================================================
import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Gift, Plus, Trash2, CheckCircle2, Printer, Search, Eye, RefreshCw, Banknote, Target, Calculator, RotateCcw, Users, PieChart, ScrollText, Ban } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa, fmtPercent, fmtRial, BONUS_TIER_LABELS, BONUS_SCHEME_STATUS_LABELS } from "@/lib/format";
import { toFaDigits, todayJalaliStr, JALALI_MONTHS } from "@/lib/jalali";
import { MoneyInput, Money } from "../money-input";
import { JalaliDatePicker } from "../jalali-datepicker";
import { NativeSelect } from "../native-select";

interface SchemeRow {
  id: string; year: number; title: string;
  targetAmount: number; actualAmount: number; achievementRatio: number;
  tier: string; tierMode: string; manualTier: string;
  budget: number; scaleToBudget: boolean; referenceDateJ: string;
  status: string; notes: string; totalComputed: number; totalFinal: number;
  lineCount: number; createdBy: string; createdAt: string;
}
interface LineRow {
  id: string; employeeId: string; employeeName: string; personnelCode: string; department: string;
  jobLevel: number; jobLevelTitle: string; baseSalary: number; bonusMonths: number;
  monthsPresent: number; paymentPercent: number; computedAmount: number; finalAmount: number;
}

// ---------- مدل دوم: برآورد بودجه ----------
interface EstimateTier {
  key: string; label: string; minRatio: number; paymentPercent: number; extraMonths: number;
  headcount: number; avgPerPerson: number; minPerPerson: number; maxPerPerson: number; totalIfAll: number;
}
interface EstimateLevel {
  level: number; title: string; headcount: number; avgBaseSalary: number; bonusMonths: number;
  perTier: Record<string, number>;
}
interface EstimatePerson {
  id: string; name: string; personnelCode: string; team: string;
  level: number; levelTitle: string; bonusMonths: number; monthsPresent: number; baseSalary: number;
  perTier: Record<string, number>;
}
interface EstimateData {
  referenceDateJ: string; headcount: number;
  config: { levels: Record<string, number>; tiers: EstimateTier[] };
  tiers: EstimateTier[];
  levels: EstimateLevel[];
  people: EstimatePerson[];
  generatedAtJ: string;
}

const TIER_BADGE: Record<string, string> = {
  BELOW_80: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  AT_80: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  AT_100: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  OVER_120: "bg-teal-100 text-teal-800 hover:bg-teal-100",
};
const TIER_SHORT: Record<string, string> = {
  BELOW_80: "نرسیده",
  AT_80: "۸۰٪",
  AT_100: "۱۰۰٪",
  OVER_120: "۱۲۰٪+",
};
const TIER_SELECT: Record<string, string> = {
  BELOW_80: "نرسیده به تارگت",
  AT_80: "۸۰٪ تارگت",
  AT_100: "۱۰۰٪ تارگت",
  OVER_120: "۱۲۰٪+ اورتارگت",
};
const TIER_TEXT: Record<string, string> = {
  BELOW_80: "text-rose-700",
  AT_80: "text-amber-700",
  AT_100: "text-emerald-700",
  OVER_120: "text-teal-700",
};

export function BonusView({ canManage }: { canManage: boolean }) {
  const [creating, setCreating] = useState(false);
  const [viewingId, setViewingId] = useState<string | null>(null);
  const [estimatorOpen, setEstimatorOpen] = useState(false);
  const list = useApi<{ schemes: SchemeRow[] }>("/api/bonus");
  const config = useApi<{ config: { levels: Record<string, number>; tiers: { key: string; label: string; paymentPercent: number; extraMonths: number }[] } }>("/api/bonus-config");
  const schemes = list.data?.schemes || [];

  return (
    <Tabs defaultValue="schemes" dir="rtl" className="space-y-4">
      <TabsList className="flex-wrap h-auto">
        <TabsTrigger value="schemes" className="text-xs gap-1"><Gift className="w-3.5 h-3.5" /> طرح‌های پاداش</TabsTrigger>
        <TabsTrigger value="decrees" className="text-xs gap-1"><ScrollText className="w-3.5 h-3.5" /> حکم گروهی (پایان سال)</TabsTrigger>
      </TabsList>

      <TabsContent value="schemes" className="space-y-4">
      {/* کارت راهنمای قواعد */}
      <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Target className="w-6 h-6 text-teal-600 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-slate-800">پاداش سالانه بر اساس لِول‌بندی</p>
              <p className="text-xs text-muted-foreground mt-1 leading-5">
                هر پاداش = یک ماه حقوق پایه (بدون اضافات قانونی). ماه پاداش هر طبقه و درصد پرداخت تیرها در تنظیمات تعریف می‌شود؛
                در صورت تحقق ۱۲۰٪+ تارگت، یک پله (یک ماه) به پاداش اضافه می‌شود و در تحقق ۸۰٪، ۸۰٪ مبلغ پرداخت می‌گردد.
                ماه حضور در سال طرح به‌صورت خودکار از تاریخ استخدام محاسبه می‌شود.
              </p>
              <p className="text-xs text-muted-foreground mt-1.5 leading-5">
                <b className="text-teal-700">مدل دوم — برآورد بودجه:</b> تعداد نفرات را در چهار وضعیت تحقق تارگت (نرسیده / ۸۰٪ / ۱۰۰٪ / ۱۲۰٪) وارد کنید تا
                بر اساس «تعداد بونس» ثبت‌شده هر طبقه در اطلاعات پایه، بودجه لازم پاداش برآورد شود؛
                در حالت «نفر به نفر» دریافتی هر نفر و سهم هر تیم از کل پاداش — ریالی و درصدی — نمایش داده می‌شود.
              </p>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {Object.entries(config.data?.config.levels || {}).map(([lv, m]) => (
                  <Badge key={lv} variant="outline" className="text-[10px]">
                    طبقه {toFaDigits(lv)}: {toFaDigits(m)} ماه
                  </Badge>
                ))}
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-1.5 shrink-0">
              <Button
                variant="outline"
                className="border-teal-300 text-teal-700 hover:bg-teal-50 hover:text-teal-800 gap-1.5"
                onClick={() => setEstimatorOpen(true)}
              >
                <Calculator className="w-4 h-4" /> برآورد بودجه پاداش
              </Button>
              {canManage && (
                <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => setCreating(true)}>
                  <Plus className="w-4 h-4" /> طرح پاداش جدید
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* لیست طرح‌ها */}
      <Card className="rounded-2xl overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><Gift className="w-4 h-4 text-teal-600" /> طرح‌های پاداش</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {list.loading ? (
            <div className="p-4 space-y-2">{[0, 1].map((i) => <Skeleton key={i} className="h-12" />)}</div>
          ) : schemes.length === 0 ? (
            <div className="py-16 text-center">
              <Gift className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">هنوز طرح پاداشی ثبت نشده — با «طرح پاداش جدید» شروع کنید.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    <TableHead className="text-right">عنوان طرح</TableHead>
                    <TableHead className="text-center">تارگت / تحقق</TableHead>
                    <TableHead className="text-center">وضعیت تارگت</TableHead>
                    <TableHead className="text-center">بودجه / جمع پرداختی</TableHead>
                    <TableHead className="text-center">نفرات</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    <TableHead className="text-center">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {schemes.map((s) => (
                    <TableRow key={s.id} className="hover:bg-teal-50/40">
                      <TableCell className="font-medium text-sm">
                        {s.title}
                        <span className="block text-[11px] text-muted-foreground">سال {toFaDigits(s.year)} • مرجع: {toFaDigits(s.referenceDateJ)}</span>
                      </TableCell>
                      <TableCell className="text-xs tabular-nums text-center">
                        <Money amount={s.targetAmount} />
                        <span className="block text-muted-foreground">↓ <Money amount={s.actualAmount} /></span>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={TIER_BADGE[s.tier] || ""}>{BONUS_TIER_LABELS[s.tier] || s.tier}</Badge>
                        <span className="block text-[10px] text-muted-foreground mt-1 tabular-nums">
                          {s.achievementRatio >= 99 ? "≥" : ""}{fmtPercent(Math.min(s.achievementRatio, 9.99), 1)}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs tabular-nums text-center">
                        <Money amount={s.budget} />
                        <span className="block text-emerald-700 font-medium">↑ <Money amount={s.totalFinal} /></span>
                      </TableCell>
                      <TableCell className="text-center text-xs tabular-nums">{toFaDigits(s.lineCount)}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={s.status === "DRAFT" ? "bg-slate-100 text-slate-600 hover:bg-slate-100" : s.status === "CONFIRMED" ? "bg-amber-100 text-amber-700 hover:bg-amber-100" : "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"}>
                          {BONUS_SCHEME_STATUS_LABELS[s.status]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center gap-1">
                          <button className="p-1.5 rounded-lg hover:bg-teal-100 text-teal-600" title="جزئیات و محاسبه" onClick={() => setViewingId(s.id)}>
                            <Eye className="w-4 h-4" />
                          </button>
                          {canManage && s.status === "DRAFT" && (
                            <>
                              <button className="p-1.5 rounded-lg hover:bg-emerald-100 text-emerald-600" title="تأیید نهایی طرح" onClick={() => confirmScheme(s)}>
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title="حذف پیش‌نویس" onClick={() => removeScheme(s)}>
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {canManage && s.status === "CONFIRMED" && (
                            <button className="p-1.5 rounded-lg hover:bg-emerald-100 text-emerald-600" title="ثبت پرداخت" onClick={() => payScheme(s)}>
                              <Banknote className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {canManage && creating && (
        <SchemeEditor
          onClose={() => setCreating(false)}
          onSaved={() => { setCreating(false); list.refetch(); toast2() }}
        />
      )}

      {estimatorOpen && (
        <BudgetEstimator onClose={() => setEstimatorOpen(false)} />
      )}

      {viewingId && (
        <SchemeDetail id={viewingId} canManage={canManage} onClose={() => setViewingId(null)} onChanged={() => list.refetch()} />
      )}
      </TabsContent>

      <TabsContent value="decrees" className="space-y-0">
        <DecreeTab canManage={canManage} />
      </TabsContent>
    </Tabs>
  );

  function toast2() {
    // placeholder — toast در SchemeEditor خودش نمایش می‌دهد
  }

  async function confirmScheme(s: SchemeRow) {
    try {
      await api(`/api/bonus/${s.id}`, { method: "PATCH", json: { status: "CONFIRMED" } });
      await list.refetch();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    }
  }
  async function payScheme(s: SchemeRow) {
    try {
      await api(`/api/bonus/${s.id}`, { method: "PATCH", json: { status: "PAID" } });
      await list.refetch();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    }
  }
  async function removeScheme(s: SchemeRow) {
    if (!confirm(`حذف طرح «${s.title}»؟`)) return;
    try {
      await api(`/api/bonus/${s.id}`, { method: "DELETE" });
      await list.refetch();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    }
  }
}

// ================= ساخت/ویرایش طرح =================
function SchemeEditor({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const year = +todayJalaliStr().slice(0, 4);
  const [title, setTitle] = useState(`پاداش سال ${toFaDigits(year)}`);
  const [targetToman, setTargetToman] = useState(50_000_000_000); // ۵۰ میلیارد تومان
  const [actualToman, setActualToman] = useState(0);
  const [budgetToman, setBudgetToman] = useState(20_000_000_000);
  const [tierMode, setTierMode] = useState("AUTO");
  const [manualTier, setManualTier] = useState("AT_100");
  const [scaleToBudget, setScaleToBudget] = useState(true);
  const [referenceDateJ, setReferenceDateJ] = useState(`${year}/12/29`);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  // پیش‌نمایش تیر
  const ratio = targetToman > 0 ? actualToman / targetToman : 0;
  const previewTier = tierMode === "MANUAL" ? manualTier : ratio >= 1.2 ? "OVER_120" : ratio >= 1 ? "AT_100" : ratio >= 0.8 ? "AT_80" : "BELOW_80";

  async function save() {
    if (!title.trim()) {
      toast({ title: "عنوان طرح الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/bonus", {
        method: "POST",
        json: {
          year,
          title,
          targetAmount: Math.round(targetToman * 10), // تومان → ریال
          actualAmount: Math.round(actualToman * 10),
          budget: Math.round(budgetToman * 10),
          tierMode,
          manualTier,
          scaleToBudget,
          referenceDateJ,
          notes,
        },
      });
      toast({ title: "طرح پاداش محاسبه شد", description: "خطوط هر نفر بر اساس طبقه، ماه حضور و تیر محاسبه شد." });
      onSaved();
    } catch (e) {
      toast({ title: "خطا در محاسبه طرح", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[58.8rem] max-h-[88vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Plus className="w-5 h-5 text-teal-600" /> طرح پاداش جدید — سال {toFaDigits(year)}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5 sm:col-span-2">
            <Label className="text-xs">عنوان طرح</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تارگت (هدف) — تومان</Label>
            <MoneyInput value={targetToman} onChange={setTargetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تحقق واقعی — تومان</Label>
            <MoneyInput value={actualToman} onChange={setActualToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">بودجه پاداش — تومان</Label>
            <MoneyInput value={budgetToman} onChange={setBudgetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تاریخ مرجع محاسبه ماه حضور</Label>
            <JalaliDatePicker value={referenceDateJ} onChange={setReferenceDateJ} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تعیین وضعیت تارگت</Label>
            <NativeSelect value={tierMode} onChange={setTierMode} ariaLabel="حالت تیر">
              <option value="AUTO">خودکار — از نسبت تحقق ({fmtPercent(Math.min(ratio, 9.99), 1)})</option>
              <option value="MANUAL">انتخاب دستی وضعیت</option>
            </NativeSelect>
          </div>
          {tierMode === "MANUAL" && (
            <div className="space-y-1.5">
              <Label className="text-xs">وضعیت (چهار حالت)</Label>
              <NativeSelect value={manualTier} onChange={setManualTier} ariaLabel="وضعیت تارگت">
                {Object.entries(BONUS_TIER_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </NativeSelect>
            </div>
          )}
          <div className="flex items-center gap-2 sm:col-span-2 rounded-xl border p-3">
            <Checkbox id="scale" checked={scaleToBudget} onCheckedChange={(v) => setScaleToBudget(!!v)} />
            <label htmlFor="scale" className="text-xs leading-5 cursor-pointer">
              مقیاس‌بندی خطی برای جا شدن در بودجه — اگر جمع پاداش از بودجه بیشتر شود، سهم همه به‌نسبت بودجه کاهش می‌یابد.
            </label>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label className="text-xs">یادداشت (اختیاری)</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>

        <div className={`rounded-xl border p-3 text-xs leading-6 ${previewTier === "OVER_120" ? "bg-teal-50 border-teal-200 text-teal-800" : previewTier === "AT_100" ? "bg-emerald-50 border-emerald-200 text-emerald-800" : previewTier === "AT_80" ? "bg-amber-50 border-amber-200 text-amber-800" : "bg-rose-50 border-rose-200 text-rose-800"}`}>
          <b>پیش‌نمایش وضعیت: {BONUS_TIER_LABELS[previewTier]}</b>
          {previewTier === "BELOW_80" && " — پاداشی پرداخت نمی‌شود (نرسیدن به ۸۰٪ تارگت)."}
          {previewTier === "AT_80" && " — ۸۰٪ مبلغ پاداش هر نفر پرداخت می‌شود."}
          {previewTier === "AT_100" && " — پاداش کامل طبقه هر نفر پرداخت می‌شود."}
          {previewTier === "OVER_120" && " — پاداش کامل + یک ماه پاداش اضافه برای هر نفر."}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            <RefreshCw className={`w-4 h-4 ${saving ? "animate-spin" : ""}`} /> {saving ? "در حال محاسبه..." : "محاسبه و ذخیره"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= جزئیات طرح =================
function SchemeDetail({ id, canManage, onClose, onChanged }: { id: string; canManage: boolean; onClose: () => void; onChanged: () => void }) {
  const { toast } = useToast();
  const detail = useApi<{ scheme: SchemeRow & { levels: Record<string, number>; tiers: { key: string; label: string; paymentPercent: number; extraMonths: number }[] }; lines: LineRow[] }>(`/api/bonus/${id}`);
  const [recomputeOpen, setRecomputeOpen] = useState(false);

  if (detail.loading || !detail.data) return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent dir="rtl">
        {/* عنوان لازم برای دسترسی‌پذیری Radix (بدون آن TitleWarning کنسول خطا می‌دهد) */}
        <DialogHeader>
          <DialogTitle className="text-sm">در حال بارگذاری جزئیات طرح پاداش…</DialogTitle>
        </DialogHeader>
        <Skeleton className="h-64 rounded-xl" />
      </DialogContent>
    </Dialog>
  );
  const s = detail.data.scheme;
  const lines = detail.data.lines;
  const overBudget = s.budget > 0 && s.totalFinal > s.budget;
  const budgetUsage = s.budget > 0 ? Math.min(100, (s.totalFinal / s.budget) * 100) : 0;
  // سهم طبقات — محاسبه مستقیم (بدون hook تا بعد از early-return)
  const levelMap = new Map<number, { count: number; total: number }>();
  for (const l of lines) {
    const cur = levelMap.get(l.jobLevel) || { count: 0, total: 0 };
    cur.count++;
    cur.total += l.finalAmount;
    levelMap.set(l.jobLevel, cur);
  }
  const byLevel = Array.from(levelMap.entries()).sort((a, b) => b[0] - a[0]);

  function exportCsv() {
    const header = ["کد پرسنلی", "نام", "واحد", "طبقه", "حقوق پایه (تومان)", "ماه پاداش", "ماه حضور", "درصد پرداخت", "محاسبه‌شده (تومان)", "پرداخت نهایی (تومان)"];
    const rows = lines.map((l) => [
      l.personnelCode, l.employeeName, l.department, String(l.jobLevel),
      String(Math.round(l.baseSalary / 10)), String(l.bonusMonths), String(l.monthsPresent),
      String(l.paymentPercent), String(Math.round(l.computedAmount / 10)), String(Math.round(l.finalAmount / 10)),
    ]);
    const csv = "\uFEFF" + [header, ...rows].map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bonus-${s.year}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function recompute(patch: Record<string, unknown>) {
    try {
      await api(`/api/bonus/${id}`, { method: "PATCH", json: patch });
      await detail.refetch();
      onChanged();
      setRecomputeOpen(false);
      toast({ title: "طرح بازمحاسبه شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[89.6rem] max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap text-base">
            <Gift className="w-5 h-5 text-teal-600" /> {s.title}
            <Badge className={TIER_BADGE[s.tier]}>{BONUS_TIER_LABELS[s.tier]}</Badge>
            <Badge variant="outline">{BONUS_SCHEME_STATUS_LABELS[s.status]}</Badge>
            {s.scaleToBudget && <Badge className="bg-slate-100 text-slate-600 hover:bg-slate-100">مقیاس‌بندی بودجه</Badge>}
          </DialogTitle>
        </DialogHeader>

        {/* کارت‌های خلاصه */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard label="تارگت" value={<Money amount={s.targetAmount} />} />
          <StatCard label="تحقق" value={<Money amount={s.actualAmount} />} sub={fmtPercent(Math.min(s.achievementRatio, 9.99), 1)} />
          <StatCard label="بودجه پاداش" value={<Money amount={s.budget} />} sub={overBudget ? `عبور: ${fmtPercent(budgetUsage)}` : `مصرف: ${fmtPercent(budgetUsage)}`} />
          <StatCard label="جمع پرداخت نهایی" value={<Money amount={s.totalFinal} />} sub={`${toFaDigits(lines.length)} نفر`} highlight />
        </div>

        {/* نوار بودجه */}
        {s.budget > 0 && (
          <div className="rounded-xl border p-3">
            <div className="flex justify-between text-[11px] mb-1.5">
              <span className="text-muted-foreground">مصرف بودجه</span>
              <span className="tabular-nums font-medium">{fmtPercent(budgetUsage)}</span>
            </div>
            <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
              <div className={`h-full rounded-full ${overBudget ? "bg-rose-500" : "bg-teal-500"}`} style={{ width: `${Math.min(100, budgetUsage)}%` }} />
            </div>
            {overBudget && !s.scaleToBudget && (
              <p className="text-[11px] text-rose-600 mt-2">جمع پاداش از بودجه عبور کرده — «مقیاس‌بندی بودجه» فعال نیست؛ برای جا شدن در بودجه فعالش کنید.</p>
            )}
          </div>
        )}

        {/* سهم طبقات */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="rounded-xl">
            <CardHeader className="pb-2"><CardTitle className="text-xs">سهم هر طبقه</CardTitle></CardHeader>
            <CardContent className="space-y-1.5">
              {byLevel.map(([lv, v]) => (
                <div key={lv} className="flex items-center gap-2 text-xs">
                  <Badge variant="outline" className="w-16 justify-center">طبقه {toFaDigits(lv)}</Badge>
                  <span className="text-muted-foreground tabular-nums">{toFaDigits(v.count)} نفر</span>
                  <span className="mr-auto tabular-nums font-medium"><Money amount={v.total} /></span>
                </div>
              ))}
            </CardContent>
          </Card>
          <Card className="rounded-xl">
            <CardHeader className="pb-2"><CardTitle className="text-xs">قواعد اعمال‌شده (اسنپ‌شات)</CardTitle></CardHeader>
            <CardContent className="space-y-1.5">
              {s.tiers.map((t) => (
                <div key={t.key} className="flex items-center gap-2 text-xs">
                  <Badge className={`${TIER_BADGE[t.key]} ${t.key !== s.tier ? "opacity-40" : ""}`}>{BONUS_TIER_LABELS[t.key]}</Badge>
                  <span className="text-muted-foreground">پرداخت {fmtPercent(t.paymentPercent / 100)}</span>
                  {t.extraMonths > 0 && <Badge variant="outline" className="text-[10px]">+{toFaDigits(t.extraMonths)} ماه</Badge>}
                  {t.key === s.tier && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mr-auto" />}
                </div>
              ))}
              <p className="text-[10px] text-muted-foreground pt-1 border-t">ماه پاداش طبقات: {Object.entries(s.levels).map(([l, m]) => `${toFaDigits(l)}→${toFaDigits(m)}`).join("، ")}</p>
            </CardContent>
          </Card>
        </div>

        {/* جدول خطوط */}
        <div className="rounded-xl border overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 bg-slate-50 border-b">
            <p className="text-xs font-bold">پاداش به تفکیک هر نفر</p>
            <div className="flex gap-1.5">
              <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={exportCsv}><Printer className="w-3 h-3" /> خروجی CSV</Button>
              {canManage && s.status === "DRAFT" && (
                <>
                  <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => setRecomputeOpen(true)}><RefreshCw className="w-3 h-3" /> ویرایش و بازمحاسبه</Button>
                  <Button size="sm" className="h-7 gap-1 text-xs bg-teal-600 hover:bg-teal-700" onClick={() => recompute({ status: "CONFIRMED" })}>تأیید نهایی</Button>
                </>
              )}
              {canManage && s.status === "CONFIRMED" && (
                <Button size="sm" className="h-7 gap-1 text-xs bg-emerald-600 hover:bg-emerald-700" onClick={() => recompute({ status: "PAID" })}><Banknote className="w-3 h-3" /> ثبت پرداخت</Button>
              )}
            </div>
          </div>
          <div className="max-h-80 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50/60">
                  <TableHead className="text-right">کارمند</TableHead>
                  <TableHead className="text-right">واحد</TableHead>
                  <TableHead className="text-center">طبقه</TableHead>
                  <TableHead className="text-center">حقوق پایه</TableHead>
                  <TableHead className="text-center">ماه پاداش</TableHead>
                  <TableHead className="text-center">ماه حضور</TableHead>
                  <TableHead className="text-center">%</TableHead>
                  <TableHead className="text-center">پرداخت نهایی</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lines.map((l) => (
                  <TableRow key={l.id} className="hover:bg-teal-50/40">
                    <TableCell className="text-xs font-medium">
                      {l.employeeName}
                      <span className="block text-[10px] text-muted-foreground tabular-nums" dir="ltr">{l.personnelCode}</span>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{l.department}</TableCell>
                    <TableCell className="text-center"><Badge variant="outline" className="text-[10px]">{toFaDigits(l.jobLevel)}</Badge></TableCell>
                    <TableCell className="text-xs tabular-nums text-center"><Money amount={l.baseSalary} /></TableCell>
                    <TableCell className="text-xs tabular-nums text-center">{toFaDigits(l.bonusMonths)}</TableCell>
                    <TableCell className="text-xs tabular-nums text-center">{toFaDigits(l.monthsPresent)}</TableCell>
                    <TableCell className="text-xs tabular-nums text-center">{fmtPercent(l.paymentPercent / 100)}</TableCell>
                    <TableCell className="text-xs tabular-nums text-center font-bold text-emerald-700"><Money amount={l.finalAmount} /></TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-teal-50/60 font-bold">
                  <TableCell colSpan={7} className="text-xs">جمع کل — {toFaDigits(lines.length)} نفر</TableCell>
                  <TableCell className="text-xs tabular-nums text-center text-teal-800"><Money amount={s.totalFinal} /></TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </div>

        {recomputeOpen && (
          <RecomputeDialog scheme={s} onClose={() => setRecomputeOpen(false)} onRecompute={recompute} />
        )}
      </DialogContent>
    </Dialog>
  );
}

function RecomputeDialog({ scheme, onClose, onRecompute }: { scheme: SchemeRow; onClose: () => void; onRecompute: (patch: Record<string, unknown>) => void }) {
  const [targetToman, setTargetToman] = useState(Math.round(scheme.targetAmount / 10));
  const [actualToman, setActualToman] = useState(Math.round(scheme.actualAmount / 10));
  const [budgetToman, setBudgetToman] = useState(Math.round(scheme.budget / 10));
  const [tierMode, setTierMode] = useState(scheme.tierMode);
  const [manualTier, setManualTier] = useState(scheme.manualTier || scheme.tier);
  const [scaleToBudget, setScaleToBudget] = useState(scheme.scaleToBudget);

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[44.8rem]" dir="rtl">
        <DialogHeader><DialogTitle className="text-sm">ویرایش و بازمحاسبه طرح</DialogTitle></DialogHeader>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">تارگت — تومان</Label>
            <MoneyInput value={targetToman} onChange={setTargetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تحقق — تومان</Label>
            <MoneyInput value={actualToman} onChange={setActualToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">بودجه — تومان</Label>
            <MoneyInput value={budgetToman} onChange={setBudgetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حالت تیر</Label>
            <NativeSelect value={tierMode} onChange={setTierMode} ariaLabel="حالت تیر">
              <option value="AUTO">خودکار از تحقق</option>
              <option value="MANUAL">دستی</option>
            </NativeSelect>
          </div>
          {tierMode === "MANUAL" && (
            <div className="space-y-1.5">
              <Label className="text-xs">وضعیت</Label>
              <NativeSelect value={manualTier} onChange={setManualTier} ariaLabel="وضعیت">
                {Object.entries(BONUS_TIER_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </NativeSelect>
            </div>
          )}
          <div className="flex items-center gap-2 sm:col-span-2 rounded-xl border p-3">
            <Checkbox id="scale2" checked={scaleToBudget} onCheckedChange={(v) => setScaleToBudget(!!v)} />
            <label htmlFor="scale2" className="text-xs cursor-pointer">مقیاس‌بندی خطی برای جا شدن در بودجه</label>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button
            className="bg-teal-600 hover:bg-teal-700 gap-1.5"
            onClick={() => onRecompute({
              targetAmount: Math.round(targetToman * 10),
              actualAmount: Math.round(actualToman * 10),
              budget: Math.round(budgetToman * 10),
              tierMode,
              manualTier,
              scaleToBudget,
            })}
          >
            <RefreshCw className="w-4 h-4" /> بازمحاسبه
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= مدل دوم: برآورد بودجه پاداش =================
// توزیع نفرات در چهار وضعیت تحقق تارگت ← بودجه لازم
// مبنا: ماه پاداش («تعداد بونس») ثبت‌شده هر طبقه در تنظیمات پاداش
function BudgetEstimator({ onClose }: { onClose: () => void }) {
  const year = +todayJalaliStr().slice(0, 4);
  const [referenceDateJ, setReferenceDateJ] = useState(`${year}/12/29`);
  const est = useApi<EstimateData>(`/api/bonus/estimate?referenceDateJ=${encodeURIComponent(referenceDateJ)}`);
  const [counts, setCounts] = useState<Record<string, number> | null>(null);
  const [inited, setInited] = useState(false);
  // حالت نفر به نفر: وضعیت تارگت انتخابی هر کارمند
  const [assignments, setAssignments] = useState<Record<string, string> | null>(null);
  const [assignInited, setAssignInited] = useState(false);
  const [q, setQ] = useState("");

  // پیش‌فرض توزیع: همه کارکنان فعال در وضعیت «تحقق ۱۰۰٪»
  useEffect(() => {
    if (est.data && !inited) {
      setCounts({ BELOW_80: 0, AT_80: 0, AT_100: est.data.headcount, OVER_120: 0 });
      setInited(true);
    }
  }, [est.data, inited]);

  useEffect(() => {
    if (est.data && !assignInited) {
      setAssignments(Object.fromEntries(est.data.people.map((p) => [p.id, "AT_100"])));
      setAssignInited(true);
    }
  }, [est.data, assignInited]);

  function parseCount(v: string): number {
    const en = v.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
    const n = parseInt(en.replace(/\D/g, ""), 10);
    return isNaN(n) ? 0 : Math.min(n, 100_000);
  }
  function setCount(key: string, v: string) {
    setCounts((c) => (c ? { ...c, [key]: parseCount(v) } : c));
  }
  function resetAll() {
    if (est.data) setCounts({ BELOW_80: 0, AT_80: 0, AT_100: est.data.headcount, OVER_120: 0 });
  }
  function setAssignment(id: string, tier: string) {
    setAssignments((a) => (a ? { ...a, [id]: tier } : a));
  }
  function setAllPeople(tier: string) {
    if (est.data) setAssignments(Object.fromEntries(est.data.people.map((p) => [p.id, tier])));
  }
  const resetPeople = () => setAllPeople("AT_100");

  const d = est.data;
  const tierRows = d?.tiers || [];
  const totalPeople = counts ? Object.values(counts).reduce((s, v) => s + v, 0) : 0;
  const totalBudget = counts
    ? tierRows.reduce((s, t) => s + (counts[t.key] || 0) * t.avgPerPerson, 0)
    : 0;

  // ---------- حالت نفر به نفر ----------
  const peopleRows = useMemo(() => d?.people || [], [d]);
  const statusOf = (id: string) => assignments?.[id] || "AT_100";
  const personAmt = (p: EstimatePerson) => p.perTier[statusOf(p.id)] || 0;
  const filteredPeople = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return peopleRows;
    return peopleRows.filter((p) =>
      p.name.toLowerCase().includes(term) ||
      String(p.personnelCode || "").toLowerCase().includes(term) ||
      p.team.toLowerCase().includes(term),
    );
  }, [peopleRows, q]);
  const scenarioTotal = useMemo(
    () => peopleRows.reduce((s, p) => s + personAmt(p), 0),
    [peopleRows, assignments],
  );
  const receivers = useMemo(
    () => peopleRows.filter((p) => personAmt(p) > 0).length,
    [peopleRows, assignments],
  );
  const teamRows = useMemo(() => {
    const map = new Map<string, { team: string; count: number; sum: number }>();
    for (const p of peopleRows) {
      const row = map.get(p.team) || { team: p.team, count: 0, sum: 0 };
      row.count++;
      row.sum += personAmt(p);
      map.set(p.team, row);
    }
    return Array.from(map.values()).sort((a, b) => b.sum - a.sum || a.team.localeCompare(b.team, "fa"));
  }, [peopleRows, assignments]);

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[67.2rem] max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap text-base">
            <Calculator className="w-5 h-5 text-teal-600" /> برآورد بودجه پاداش
            <Badge variant="outline" className="text-[10px]">مدل دوم</Badge>
          </DialogTitle>
        </DialogHeader>

        {est.loading || !d || !counts ? (
          <Skeleton className="h-72 rounded-xl" />
        ) : d.headcount === 0 ? (
          <div className="py-14 text-center">
            <Calculator className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">
              کارمند فعالی ثبت نشده — برآورد بودجه نیازمند کارکنان فعال با حقوق پایه و طبقه شغلی است.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* راهنمای مدل */}
            <div className="rounded-xl border border-teal-200 bg-teal-50/60 p-3 text-xs leading-6 text-teal-900">
              <b>چطور کار می‌کند؟</b> دو روش برآورد: در «توزیع سریع» فقط تعداد نفرات هر وضعیت را وارد کنید (بودجه = تعداد × میانگین پاداش هر نفر)؛
              در «نفر به نفر» وضعیت تحقق تارگت هر کارمند را انتخاب کنید تا دریافتی او بر اساس «تعداد بونس» طبقه‌اش در اطلاعات پایه،
              حقوق پایه و ماه حضور محاسبه و سهم هر تیم از کل پاداش — ریالی و درصدی — نمایش داده شود.
              نرسیده به تارگت پاداشی دریافت نمی‌کند.
            </div>

            {/* تاریخ مرجع + نفرات فعال */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs">تاریخ مرجع محاسبه ماه حضور</Label>
                <JalaliDatePicker value={referenceDateJ} onChange={setReferenceDateJ} />
              </div>
              <div className="flex items-end pb-1">
                <Badge variant="outline" className="text-[11px] tabular-nums">
                  کارکنان فعال: {toFaDigits(d.headcount)} نفر
                </Badge>
              </div>
            </div>

            <Tabs defaultValue="quick" dir="rtl" className="w-full">
              <TabsList className="w-full grid grid-cols-2 h-10">
                <TabsTrigger value="quick" className="text-xs gap-1"><Calculator className="w-3.5 h-3.5" /> توزیع سریع</TabsTrigger>
                <TabsTrigger value="people" className="text-xs gap-1"><Users className="w-3.5 h-3.5" /> نفر به نفر و سهم تیم‌ها</TabsTrigger>
              </TabsList>

              <TabsContent value="quick" className="space-y-4 mt-4">
            <div className="flex justify-end">
              <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={resetAll}>
                <RotateCcw className="w-3.5 h-3.5" /> بازنشانی (همه در ۱۰۰٪)
              </Button>
            </div>

            {/* چهار وضعیت */}
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
              {tierRows.map((t) => {
                const c = counts[t.key] || 0;
                const budget = c * t.avgPerPerson;
                return (
                  <div key={t.key} className={`rounded-xl border p-3 space-y-2 ${t.key === "OVER_120" ? "bg-teal-50/50 border-teal-200" : t.key === "AT_100" ? "bg-emerald-50/50 border-emerald-200" : t.key === "AT_80" ? "bg-amber-50/50 border-amber-200" : "bg-rose-50/40 border-rose-200"}`}>
                    <Badge className={`${TIER_BADGE[t.key]} w-full justify-center text-[11px]`}>{BONUS_TIER_LABELS[t.key]}</Badge>
                    <div className="flex items-center justify-center gap-1 text-[10px] text-muted-foreground">
                      <span>پرداخت {fmtPercent(t.paymentPercent / 100)}</span>
                      {t.extraMonths > 0 && <Badge variant="outline" className="text-[9px] px-1">+{toFaDigits(t.extraMonths)} ماه</Badge>}
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px]">تعداد نفرات</Label>
                      <Input
                        className="h-9 text-center tabular-nums font-bold"
                        value={String(c)}
                        onChange={(e) => setCount(t.key, e.target.value)}
                        inputMode="numeric"
                        placeholder="۰"
                      />
                    </div>
                    <div className="space-y-0.5 pt-1 border-t">
                      <p className="text-[10px] text-muted-foreground">میانگین پاداش هر نفر</p>
                      <p className="text-xs font-bold tabular-nums">
                        {t.avgPerPerson > 0 ? <Money amount={t.avgPerPerson} /> : "—"}
                      </p>
                      {t.avgPerPerson > 0 && (
                        <p className="text-[9px] text-muted-foreground tabular-nums">
                          بازه: <Money amount={t.minPerPerson} short /> تا <Money amount={t.maxPerPerson} short />
                        </p>
                      )}
                    </div>
                    <div className={`rounded-lg p-2 ${budget > 0 ? "bg-white/80" : "bg-white/40"}`}>
                      <p className="text-[10px] text-muted-foreground">بودجه این وضعیت</p>
                      <p className={`text-sm font-bold tabular-nums ${budget > 0 ? "text-teal-800" : "text-muted-foreground"}`}>
                        <Money amount={budget} />
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* جمع کل */}
            <div className="rounded-xl border-2 border-teal-300 bg-gradient-to-l from-teal-50 to-white p-4 flex flex-wrap items-center gap-x-8 gap-y-2">
              <div>
                <p className="text-[11px] text-muted-foreground">جمع نفرات توزیع‌شده</p>
                <p className="text-lg font-bold tabular-nums">{toFaDigits(totalPeople)} نفر</p>
              </div>
              <div className="mr-auto text-left" dir="rtl">
                <p className="text-[11px] text-muted-foreground">بودجه پاداش لازم (برآوردی)</p>
                <p className="text-lg font-bold tabular-nums text-teal-800">
                  <Money amount={totalBudget} />
                </p>
              </div>
            </div>
            {totalPeople !== d.headcount && (
              <p className="text-[11px] text-amber-700 -mt-2">
                ⓘ جمع نفرات واردشده ({toFaDigits(totalPeople)}) با کارکنان فعال ({toFaDigits(d.headcount)}) برابر نیست —
                اگر فقط بخشی از سازمان مشمول پاداش‌اند مشکلی نیست.
              </p>
            )}

            {/* سناریوی کل سازمان */}
            <div className="rounded-xl border p-3">
              <p className="text-xs font-bold mb-2">سناریو — اگر همه {toFaDigits(d.headcount)} نفر فعال در یک وضعیت بودند:</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {tierRows.map((t) => (
                  <div key={t.key} className="rounded-lg bg-slate-50 border border-slate-200/70 p-2.5 text-center">
                    <Badge className={`${TIER_BADGE[t.key]} text-[10px] mb-1.5`}>{BONUS_TIER_LABELS[t.key]}</Badge>
                    <p className="text-xs font-bold tabular-nums">
                      <Money amount={t.totalIfAll} />
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* تفکیک طبقات — تعداد بونس ثبت‌شده */}
            <div className="rounded-xl border overflow-hidden">
              <div className="px-3 py-2 bg-slate-50 border-b">
                <p className="text-xs font-bold">مبنای محاسبه — تعداد بونس (ماه پاداش) ثبت‌شده هر طبقه و میانگین پاداش هر نفر</p>
              </div>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/60">
                      <TableHead className="text-right">طبقه</TableHead>
                      <TableHead className="text-center">نفرات</TableHead>
                      <TableHead className="text-center">میانگین حقوق پایه</TableHead>
                      <TableHead className="text-center">تعداد بونس (ماه)</TableHead>
                      <TableHead className="text-center">پاداش نفر در ۸۰٪</TableHead>
                      <TableHead className="text-center">پاداش نفر در ۱۰۰٪</TableHead>
                      <TableHead className="text-center">پاداش نفر در ۱۲۰٪</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {d.levels.map((l) => (
                      <TableRow key={l.level} className="hover:bg-teal-50/40">
                        <TableCell className="text-xs font-medium whitespace-nowrap">
                          <Badge variant="outline" className="text-[10px]">{l.level > 0 ? `طبقه ${toFaDigits(l.level)}` : "بدون طبقه"}</Badge>
                          {l.level > 0 && l.title && <span className="block text-[9px] text-muted-foreground mt-0.5 max-w-[8rem] truncate">{l.title}</span>}
                        </TableCell>
                        <TableCell className="text-xs tabular-nums text-center">{toFaDigits(l.headcount)}</TableCell>
                        <TableCell className="text-xs tabular-nums text-center"><Money amount={l.avgBaseSalary} /></TableCell>
                        <TableCell className="text-xs tabular-nums text-center">{toFaDigits(l.bonusMonths)}</TableCell>
                        <TableCell className="text-xs tabular-nums text-center text-amber-700">{l.perTier.AT_80 > 0 ? <Money amount={l.perTier.AT_80} /> : "—"}</TableCell>
                        <TableCell className="text-xs tabular-nums text-center text-emerald-700">{l.perTier.AT_100 > 0 ? <Money amount={l.perTier.AT_100} /> : "—"}</TableCell>
                        <TableCell className="text-xs tabular-nums text-center text-teal-700">{l.perTier.OVER_120 > 0 ? <Money amount={l.perTier.OVER_120} /> : "—"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <p className="px-3 py-2 text-[10px] text-muted-foreground border-t leading-5">
                فرمول هر نفر: حقوق پایه × (ماه طبقه + ماه اضافه تیر) × (ماه حضور ÷ ۱۲) × درصد پرداخت — وضعیت «نرسیده به تارگت» پاداشی ندارد و در جدول نمایش داده نمی‌شود.
                مقادیر میانگین بر اساس داده کارکنان فعال فعلی است؛ بودجه نهایی دقیق در «طرح پاداش» محاسبه می‌شود.
              </p>
            </div>
              </TabsContent>

              {/* ---------- حالت نفر به نفر + سهم تیم‌ها ---------- */}
              <TabsContent value="people" className="space-y-4 mt-4">
                {/* نوار ابزار: جستجو + تنظیم گروهی + بازنشانی */}
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative flex-1 min-w-[11rem] max-w-[17rem]">
                    <Search className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                    <Input
                      value={q}
                      onChange={(e) => setQ(e.target.value)}
                      placeholder="جستجوی نام، کد پرسنلی یا تیم…"
                      className="h-9 pr-8 text-xs"
                    />
                  </div>
                  <div className="flex items-center gap-1 mr-auto flex-wrap">
                    <span className="text-[10px] text-muted-foreground hidden sm:inline">همه در:</span>
                    {(["BELOW_80", "AT_80", "AT_100", "OVER_120"] as const).map((k) => (
                      <Button
                        key={k}
                        size="sm"
                        variant="outline"
                        className="h-7 px-2.5 text-[10px]"
                        onClick={() => setAllPeople(k)}
                      >
                        {TIER_SHORT[k]}
                      </Button>
                    ))}
                    <Button size="sm" variant="outline" className="h-7 px-2.5 text-[10px] gap-1" onClick={resetPeople}>
                      <RotateCcw className="w-3 h-3" /> بازنشانی
                    </Button>
                  </div>
                </div>

                {/* جمع سناریوی نفر به نفر */}
                <div className="rounded-xl border-2 border-teal-300 bg-gradient-to-l from-teal-50 to-white p-4 flex flex-wrap items-center gap-x-8 gap-y-2">
                  <div>
                    <p className="text-[11px] text-muted-foreground">جمع دریافتی نفرات (کل پاداش)</p>
                    <p className="text-lg font-bold tabular-nums text-teal-800"><Money amount={scenarioTotal} /></p>
                  </div>
                  <div>
                    <p className="text-[11px] text-muted-foreground">دریافت‌کننده پاداش</p>
                    <p className="text-lg font-bold tabular-nums">
                      {toFaDigits(receivers)} <span className="text-xs font-normal text-muted-foreground">از {toFaDigits(peopleRows.length)} نفر</span>
                    </p>
                  </div>
                  <div className="mr-auto text-left" dir="rtl">
                    <p className="text-[11px] text-muted-foreground">تعداد تیم</p>
                    <p className="text-lg font-bold tabular-nums">{toFaDigits(teamRows.length)}</p>
                  </div>
                </div>

                {/* لیست نفرات — تعداد بونس و دریافتی هر نفر */}
                <div className="rounded-xl border overflow-hidden">
                  <div className="px-3 py-2 bg-slate-50 border-b flex items-center justify-between gap-2">
                    <p className="text-xs font-bold">لیست نفرات — تعداد بونس و دریافتی هر نفر</p>
                    <Badge variant="outline" className="text-[10px] tabular-nums shrink-0">
                      {toFaDigits(filteredPeople.length)} از {toFaDigits(peopleRows.length)} نفر
                    </Badge>
                  </div>
                  <div className="overflow-auto max-h-[24rem]">
                    <Table>
                      <TableHeader className="sticky top-0 z-10">
                        <TableRow className="bg-slate-50/95 backdrop-blur-sm hover:bg-slate-50/95">
                          <TableHead className="text-center w-10">#</TableHead>
                          <TableHead className="text-right">نام</TableHead>
                          <TableHead className="text-right">تیم</TableHead>
                          <TableHead className="text-center whitespace-nowrap">طبقه</TableHead>
                          <TableHead className="text-center whitespace-nowrap">تعداد بونس</TableHead>
                          <TableHead className="text-center whitespace-nowrap">ماه حضور</TableHead>
                          <TableHead className="text-center whitespace-nowrap">وضعیت تارگت</TableHead>
                          <TableHead className="text-center whitespace-nowrap">دریافتی پاداش</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredPeople.map((p, i) => {
                          const st = statusOf(p.id);
                          const amt = p.perTier[st] || 0;
                          return (
                            <TableRow key={p.id} className="hover:bg-teal-50/40">
                              <TableCell className="text-[10px] text-muted-foreground tabular-nums text-center">{toFaDigits(i + 1)}</TableCell>
                              <TableCell className="text-xs font-medium whitespace-nowrap">
                                {p.name}
                                <span className="block text-[9px] text-muted-foreground tabular-nums">{p.personnelCode}</span>
                              </TableCell>
                              <TableCell className="text-[11px] text-muted-foreground whitespace-nowrap">{p.team}</TableCell>
                              <TableCell className="text-center whitespace-nowrap">
                                <Badge variant="outline" className="text-[9px]">{p.level > 0 ? `طبقه ${toFaDigits(p.level)}` : "بدون طبقه"}</Badge>
                              </TableCell>
                              <TableCell className="text-xs tabular-nums text-center">{p.bonusMonths > 0 ? `${toFaDigits(p.bonusMonths)} ماه` : "—"}</TableCell>
                              <TableCell className="text-[11px] tabular-nums text-center text-muted-foreground">{toFaDigits(p.monthsPresent)}</TableCell>
                              <TableCell className="text-center">
                                <NativeSelect
                                  value={st}
                                  onChange={(v) => setAssignment(p.id, v)}
                                  className="w-36"
                                  ariaLabel={`وضعیت تارگت ${p.name}`}
                                >
                                  {(["BELOW_80", "AT_80", "AT_100", "OVER_120"] as const).map((k) => (
                                    <option key={k} value={k}>{TIER_SELECT[k]}</option>
                                  ))}
                                </NativeSelect>
                              </TableCell>
                              <TableCell className="text-xs tabular-nums text-center font-bold whitespace-nowrap">
                                {amt > 0 ? (
                                  <span className={TIER_TEXT[st] || ""}><Money amount={amt} /></span>
                                ) : (
                                  <span className="text-muted-foreground font-normal">—</span>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                        {filteredPeople.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center text-xs text-muted-foreground py-8">
                              موردی مطابق جستجو یافت نشد.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                  <p className="px-3 py-2 text-[10px] text-muted-foreground border-t leading-5">
                    «تعداد بونس» = ماه پاداش ثبت‌شدهٔ طبقهٔ هر نفر در اطلاعات پایه — دریافتی = حقوق پایه × (تعداد بونس + ماه اضافه تیر) × (ماه حضور ÷ ۱۲) × درصد پرداخت تیر.
                  </p>
                </div>

                {/* سهم هر تیم از کل پاداش */}
                <div className="rounded-xl border overflow-hidden">
                  <div className="px-3 py-2 bg-slate-50 border-b">
                    <p className="text-xs font-bold flex items-center gap-1.5">
                      <PieChart className="w-3.5 h-3.5 text-teal-600" /> سهم هر تیم از کل پاداش — ریالی و درصدی
                    </p>
                  </div>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-slate-50/60">
                          <TableHead className="text-right">تیم</TableHead>
                          <TableHead className="text-center">نفرات</TableHead>
                          <TableHead className="text-center whitespace-nowrap">جمع دریافتی پاداش</TableHead>
                          <TableHead className="text-center whitespace-nowrap">سهم از کل</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {teamRows.map((t) => {
                          const share = scenarioTotal > 0 ? t.sum / scenarioTotal : 0;
                          return (
                            <TableRow key={t.team} className="hover:bg-teal-50/40">
                              <TableCell className="text-xs font-medium whitespace-nowrap">{t.team}</TableCell>
                              <TableCell className="text-xs tabular-nums text-center">{toFaDigits(t.count)}</TableCell>
                              <TableCell className="text-xs tabular-nums text-center font-bold text-teal-800">
                                {t.sum > 0 ? (
                                  <>
                                    <Money amount={t.sum} />
                                    <span className="block text-[9px] text-muted-foreground font-normal">{fmtRial(t.sum)}</span>
                                  </>
                                ) : (
                                  <span className="text-muted-foreground font-normal">—</span>
                                )}
                              </TableCell>
                              <TableCell className="text-center">
                                <div className="flex items-center justify-center gap-2">
                                  <div className="h-1.5 w-14 rounded-full bg-slate-100 overflow-hidden hidden sm:block">
                                    <div
                                      className="h-full rounded-full bg-teal-500"
                                      style={{ width: `${Math.min(100, Math.round(share * 100))}%` }}
                                    />
                                  </div>
                                  <span className="text-xs font-bold tabular-nums">{fmtPercent(share, 1)}</span>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                        <TableRow className="bg-slate-50 font-bold">
                          <TableCell className="text-xs">جمع کل</TableCell>
                          <TableCell className="text-xs tabular-nums text-center">{toFaDigits(peopleRows.length)}</TableCell>
                          <TableCell className="text-xs tabular-nums text-center text-teal-800">
                            <Money amount={scenarioTotal} />
                            <span className="block text-[9px] text-muted-foreground font-normal">{fmtRial(scenarioTotal)}</span>
                          </TableCell>
                          <TableCell className="text-xs tabular-nums text-center">۱۰۰٪</TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                  <p className="px-3 py-2 text-[10px] text-muted-foreground border-t leading-5">
                    سهم هر تیم از «جمع دریافتی نفرات» در همین سناریو محاسبه می‌شود — با تغییر وضعیت تارگت افراد، سهم تیم‌ها به‌صورت زنده به‌روز می‌شود.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>بستن</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function StatCard({ label, value, sub, highlight }: { label: string; value: React.ReactNode; sub?: React.ReactNode; highlight?: boolean }) {
  return (
    <div className={`rounded-xl border p-3 ${highlight ? "bg-teal-50/60 border-teal-200" : "bg-white"}`}>
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className={`text-sm font-bold mt-1 tabular-nums ${highlight ? "text-teal-800" : ""}`}>{value}</p>
      {sub && <p className="text-[10px] text-muted-foreground mt-0.5 tabular-nums">{sub}</p>}
    </div>
  );
}

// ================= تب حکم گروهی (عیدی/پاداش پایان سال) =================
// جریان: «خالص پرداختی هر نفر» را به‌صورت گروهی تعیین کنید؛ سامانه برای هر
// کارمند نرخ مالیات نهایی او را از حقوق پایه دستی‌اش درمی‌آید، مبلغ ناخالص
// حکم را معکوس حل می‌کند و حکم گروهی صادر می‌شود. پیش‌بینی بودجه حقوق،
// احکام صادرشده را در ماه پرداختِ آنها لحاظ می‌کند.

interface DecreeRowUI {
  id: string; decreeNo: string; year: number; title: string;
  kind: string; // BONUS = عیدی/پاداش | SALARY = حکم حقوق فردی
  payMonthY: number; payMonthM: number;
  scope: string; scopeDeptName: string; levelTitle: string;
  scopeEmployeeId?: string | null;
  scopeEmployeeName?: string;
  previousSalary?: number | null;
  appliedSalary?: boolean;
  newSalary?: number;
  targetNetPerPerson: number; taxExempt: number;
  headcount: number; totalGross: number; totalTax: number; totalNet: number;
  status: string; notes: string; createdBy: string; createdAt: string; lineCount: number;
}

interface DecreeBaseData {
  decrees: DecreeRowUI[];
  legal: { year: number; minWage: number; defaultTaxExempt: number; taxBrackets: { lowerLimit: number; upperLimit: number | null; rate: number }[] };
  defaults: { payMonthY: number; payMonthM: number; title: string };
  today: string;
}

interface DecreeLineUI {
  employeeName: string; personnelCode: string; department: string;
  jobLevel: number; jobLevelTitle: string; baseSalary: number;
  marginalRate: number; targetNet: number; taxAmount: number;
  grossAmount: number; netAmount: number; coefficient: number;
  details?: {
    items?: { code: string; title: string; amount: number; kind: string }[];
    seniorityYears?: number; childCount?: number; married?: boolean;
    baseSplit?: string; splitBaseAmount?: number; effectiveJ?: string;
    previousSalary?: number; currentNet?: number; achievedNet?: number; residual?: number;
  } | null;
}

interface DecreePreview {
  dryRun: true;
  title: string;
  payLabel: string;
  scopeLabel: string;
  levelLabel: string;
  meta: { targetNetPerPerson: number; taxExempt: number; payMonthY: number; payMonthM: number };
  lines: DecreeLineUI[];
  totals: { headcount: number; totalGross: number; totalTax: number; totalNet: number };
}

function DecreeTab({ canManage }: { canManage: boolean }) {
  const list = useApi<DecreeBaseData>("/api/decree");
  const [editorOpen, setEditorOpen] = useState(false);
  const [viewingId, setViewingId] = useState<string | null>(null);
  const decrees = list.data?.decrees || [];
  const issued = decrees.filter((d) => d.status === "ISSUED");

  return (
    <div className="space-y-4">
      {/* کارت راهنما */}
      <Card className="rounded-2xl bg-gradient-to-l from-amber-50 to-white border-amber-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <ScrollText className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-slate-800">احکام — دو روش صدور</p>
              <div className="text-xs text-muted-foreground mt-1.5 leading-5 space-y-1">
                <p>
                  <b className="text-amber-800">۱) حکم گروهی عیدی/پاداش:</b> «خالص پرداختی هر نفر» را به‌صورت گروهی تعیین کنید؛ سامانه برای هر کارمند، نرخ مالیات نهایی او را از روی
                  <b> حقوق پایه دستیِ</b> همان نفر درمی‌آورد، مبلغ ناخالص حکم را <b>معکوس</b> حل می‌کند (معافیت عیدی = ۲× حداقل دستمزد، مالیات فقط بر مازادِ معافیت)
                  و حکم گروهی با ضریبِ نسبت به حقوق پایه هر نفر صادر می‌شود. «پیش‌بینی بودجه حقوق» این احکام را در ماه پرداخت به بودجه اضافه می‌کند.
                </p>
                <p>
                  <b className="text-violet-800">۲) حکم حقوق فردی (از محاسبه معکوس):</b> در «موتور محاسبه معکوس» (منوی حقوق ← محاسبه معکوس)، کارمند و ماه اجرا را انتخاب کنید،
                  خالص هدف را وارد و محاسبه کنید — با کانتکس واقعی پرونده او (فرزند/تاهل/سنوات از تاریخ استخدام/طبقه/شیفت) — سپس دکمه
                  <b> «صدور حکم حقوق»</b> را بزنید. حقوق جدید می‌تواند هم‌زمان روی پرونده کارمند اعمال شود (با ثبت در «سابقه تغییرات حقوق»).
                </p>
              </div>
              {issued.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <Badge variant="outline" className="border-amber-300 text-amber-800 bg-amber-50">{toFaDigits(issued.filter((d) => d.kind !== "SALARY").length)} حکم گروهی عیدی/پاداش</Badge>
                  <Badge variant="outline" className="border-violet-300 text-violet-800 bg-violet-50">{toFaDigits(issued.filter((d) => d.kind === "SALARY").length)} حکم حقوق فردی</Badge>
                  <Badge variant="outline" className="border-amber-300 text-amber-800 bg-amber-50">
                    جمع ناخالص: <Money amount={issued.reduce((s, d) => s + d.totalGross, 0)} short />
                  </Badge>
                </div>
              )}
            </div>
            {canManage && (
              <Button className="bg-amber-600 hover:bg-amber-700 gap-1.5 shrink-0" onClick={() => setEditorOpen(true)}>
                <Plus className="w-4 h-4" /> صدور حکم گروهی
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* لیست احکام */}
      <Card className="rounded-2xl overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><ScrollText className="w-4 h-4 text-amber-600" /> احکام صادرشده</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {list.loading ? (
            <div className="p-4 space-y-2">{[0, 1].map((i) => <Skeleton key={i} className="h-12" />)}</div>
          ) : decrees.length === 0 ? (
            <div className="py-16 text-center">
              <ScrollText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">هنوز حکمی صادر نشده — با «صدور حکم گروهی» شروع کنید.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    <TableHead className="text-right">حکم / عنوان</TableHead>
                    <TableHead className="text-center">نوع</TableHead>
                    <TableHead className="text-center">ماه {""}(پرداخت/اجرا)</TableHead>
                    <TableHead className="text-right">دامنه / کارمند</TableHead>
                    <TableHead className="text-center">خالص هدف هر نفر</TableHead>
                    <TableHead className="text-center">نفرات</TableHead>
                    <TableHead className="text-left">مبلغ / حقوق جدید</TableHead>
                    <TableHead className="text-left">مالیات</TableHead>
                    <TableHead className="text-left">خالص</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    <TableHead className="text-center">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {decrees.map((d) => {
                    const isSalary = d.kind === "SALARY";
                    return (
                      <TableRow key={d.id} className={d.status === "CANCELLED" ? "opacity-50" : isSalary ? "hover:bg-violet-50/40" : "hover:bg-amber-50/40"}>
                        <TableCell className="font-medium text-sm">
                          <span className={isSalary ? "text-violet-800 font-bold" : "text-amber-800 font-bold"}>{d.decreeNo}</span>
                          <span className="block">{d.title}</span>
                          <span className="block text-[10px] text-muted-foreground">صادرکننده: {d.createdBy || "—"}</span>
                        </TableCell>
                        <TableCell className="text-center">
                          <Badge className={isSalary ? "bg-violet-100 text-violet-800 hover:bg-violet-100" : "bg-amber-100 text-amber-800 hover:bg-amber-100"}>
                            {isSalary ? "حکم حقوق" : "عیدی/پاداش"}
                          </Badge>
                          {isSalary && d.appliedSalary && (
                            <span className="block text-[9px] text-emerald-700 mt-1">اعمال‌شده روی پرونده</span>
                          )}
                        </TableCell>
                        <TableCell className="text-center text-xs tabular-nums whitespace-nowrap">
                          {JALALI_MONTHS[d.payMonthM - 1]} {toFaDigits(d.payMonthY)}
                        </TableCell>
                        <TableCell className="text-xs">
                          {isSalary ? (
                            <>
                              <span className="font-medium text-slate-700">{d.scopeEmployeeName || "—"}</span>
                              <span className="block text-[10px] text-muted-foreground">{d.scopeDeptName}</span>
                            </>
                          ) : (
                            <>
                              {d.scopeDeptName}
                              <span className="block text-[10px] text-muted-foreground">{d.levelTitle}</span>
                            </>
                          )}
                        </TableCell>
                        <TableCell className="text-center"><Money amount={d.targetNetPerPerson} short /></TableCell>
                        <TableCell className="text-center tabular-nums">{toFaDigits(d.headcount)}</TableCell>
                        <TableCell className="text-left font-semibold">
                          <Money amount={isSalary ? d.newSalary ?? d.totalGross : d.totalGross} short />
                          {isSalary && <span className="block text-[9px] text-muted-foreground">حقوق ماهانه جدید</span>}
                        </TableCell>
                        <TableCell className="text-left"><Money amount={d.totalTax} short /></TableCell>
                        <TableCell className="text-left text-emerald-700 font-medium"><Money amount={d.totalNet} short /></TableCell>
                        <TableCell className="text-center">
                          <Badge className={d.status === "ISSUED" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-rose-100 text-rose-700 hover:bg-rose-100"}>
                            {d.status === "ISSUED" ? "صادرشده" : "ابطال‌شده"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center">
                          <div className="flex justify-center gap-1">
                            <button className="p-1.5 rounded-lg hover:bg-amber-100 text-amber-700" title="جزئیات حکم" onClick={() => setViewingId(d.id)}>
                              <Eye className="w-4 h-4" />
                            </button>
                            {canManage && d.status === "ISSUED" && (
                              <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title="ابطال حکم" onClick={() => setViewingId(d.id)}>
                                <Ban className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {editorOpen && (
        <DecreeEditor
          onClose={() => setEditorOpen(false)}
          onSaved={() => {
            setEditorOpen(false);
            list.refetch();
          }}
        />
      )}

      {viewingId && (
        <DecreeDetail
          id={viewingId}
          canManage={canManage}
          onClose={() => setViewingId(null)}
          onChanged={() => list.refetch()}
        />
      )}
    </div>
  );
}

// ================= فرم صدور حکم گروهی =================
function DecreeEditor({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const base = useApi<DecreeBaseData>("/api/decree");
  const departments = useApi<{ departments: { id: string; name: string }[] }>("/api/departments");
  const grades = useApi<{ grades: { id: string; level: number; title: string; departmentId: string | null; departmentName: string | null }[] }>("/api/grades");

  const defaults = base.data?.defaults;
  const legal = base.data?.legal;

  const [inited, setInited] = useState(false);
  const [title, setTitle] = useState("");
  const [payY, setPayY] = useState(0);
  const [payM, setPayM] = useState(0);
  const [scopeDeptId, setScopeDeptId] = useState(""); // "" = همه دپارتمان‌ها
  const [levelId, setLevelId] = useState(""); // "" = همه سطوح
  const [targetToman, setTargetToman] = useState(50_000_000); // خالص هدف هر نفر — تومان
  const [exemptToman, setExemptToman] = useState(0); // 0 → پیش‌فرض سرور (۲× حداقل دستمزد)
  const [notes, setNotes] = useState("");
  const [preview, setPreview] = useState<DecreePreview | null>(null);
  const [previewSig, setPreviewSig] = useState("");
  const [busy, setBusy] = useState(false);

  if (!inited && defaults) {
    setInited(true);
    setTitle(defaults.title);
    setPayY(defaults.payMonthY);
    setPayM(defaults.payMonthM);
    if (legal && legal.defaultTaxExempt > 0) setExemptToman(Math.round(legal.defaultTaxExempt / 10));
  }

  const yearOptions = useMemo(() => {
    const y0 = (defaults?.payMonthY || 1405) - 1;
    return [0, 1, 2, 3, 4].map((i) => y0 + i);
  }, [defaults]);

  /** سطح‌های قابل انتخاب برای دامنه: سراسری + سطح‌بندی دپارتمان انتخابی */
  const levelOptions = (grades.data?.grades || []).filter((g) => {
    if (!scopeDeptId) return true; // همه دپارتمان‌ها → همه سطوح قابل انتخاب
    return !g.departmentId || g.departmentId === scopeDeptId;
  });

  const currentSig = JSON.stringify([title, payY, payM, scopeDeptId, levelId, Math.round(targetToman * 10), Math.round(exemptToman * 10)]);
  const previewIsFresh = !!preview && previewSig === currentSig;

  async function run(dryRun: boolean) {
    if (targetToman <= 0) {
      toast({ title: "خالص هدف هر نفر را وارد کنید", variant: "destructive" });
      return;
    }
    if (!payY || !payM) {
      toast({ title: "ماه پرداخت حکم را انتخاب کنید", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await api<DecreePreview | { decree: { decreeNo: string; title: string } }>("/api/decree", {
        method: "POST",
        json: {
          title,
          payMonthY: payY,
          payMonthM: payM,
          scopeDeptId: scopeDeptId || null,
          levelId: levelId || null,
          targetNetPerPerson: Math.round(targetToman * 10),
          taxExempt: exemptToman > 0 ? Math.round(exemptToman * 10) : 0,
          dryRun,
          notes,
        },
      });
      if (dryRun) {
        setPreview(res as DecreePreview);
        setPreviewSig(currentSig);
        toast({ title: "پیش‌نمایش محاسبه شد", description: `${toFaDigits((res as DecreePreview).totals.headcount)} نفر — جمع ناخالص: ${groupFa(Math.round((res as DecreePreview).totals.totalGross / 10))} تومان` });
      } else {
        const r = res as { decree: { decreeNo: string; title: string } };
        toast({ title: `حکم گروهی ${r.decree.decreeNo} صادر شد`, description: "پیش‌بینی بودجه حقوق از این پس این حکم را لحاظ می‌کند." });
        onSaved();
      }
    } catch (e) {
      toast({ title: dryRun ? "خطا در پیش‌نمایش" : "خطا در صدور حکم", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[60rem] max-h-[92vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ScrollText className="w-5 h-5 text-amber-600" /> صدور حکم گروهی عیدی/پاداش
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-xs text-muted-foreground bg-amber-50 border border-amber-100 rounded-lg p-3 leading-5">
            برای گروه انتخابی (دپارتمان/سطح) مقدار <b>خالص دریافتی هر نفر</b> را تعیین کنید؛ سامانه برای هر نفر، نرخ مالیات نهایی او را از حقوق پایه دستی‌اش
            (پله مالیاتی همان نفر) درمی‌آورد و مبلغ <b>ناخالص حکم</b> را معکوس محاسبه می‌کند: مازادِ معافیت عیدی با نرخ نهاییِ همان نفر مالیات می‌خورد —
            سپس حکم با «ضریب نسبت به حقوق پایه» صادر می‌شود.
          </p>

          {/* فرم */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="space-y-1.5 sm:col-span-2">
              <Label className="text-xs">عنوان حکم</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="عیدی و پاداش پایان سال" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">ماه پرداخت حکم</Label>
              <div className="flex gap-1.5">
                <Select value={String(payM)} onValueChange={(v) => setPayM(+v)}>
                  <SelectTrigger className="h-9 w-[104px]"><SelectValue /></SelectTrigger>
                  <SelectContent>{JALALI_MONTHS.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
                </Select>
                <Select value={String(payY)} onValueChange={(v) => setPayY(+v)}>
                  <SelectTrigger className="h-9 w-[96px]"><SelectValue /></SelectTrigger>
                  <SelectContent>{yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{toFaDigits(y)}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <p className="text-[10px] text-muted-foreground">این ماه در «پیش‌بینی بودجه» لحاظ می‌شود</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">دامنه — دپارتمان</Label>
              <Select
                value={scopeDeptId || "all"}
                onValueChange={(v) => {
                  const deptId = v === "all" ? "" : v;
                  setScopeDeptId(deptId);
                  // اگر سطح انتخابی مخصوص دپارتمان دیگری است، پاک شود
                  const stillOk = (grades.data?.grades || []).some((g) => g.id === levelId && (!g.departmentId || g.departmentId === deptId));
                  if (!stillOk) setLevelId("");
                }}
              >
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">همه دپارتمان‌ها</SelectItem>
                  {(departments.data?.departments || []).map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">دامنه — سطح (اختیاری)</Label>
              <Select value={levelId || "all"} onValueChange={(v) => setLevelId(v === "all" ? "" : v)}>
                <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-56">
                  <SelectItem value="all">همه سطوح</SelectItem>
                  {levelOptions.map((g) => (
                    <SelectItem key={g.id} value={g.id}>سطح {toFaDigits(g.level)} — {g.title}{g.departmentName ? ` (${g.departmentName})` : ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-amber-800 font-bold">خالص دریافتی هر نفر (تومان)</Label>
              <MoneyInput value={targetToman} onChange={setTargetToman} />
              <p className="text-[10px] text-muted-foreground">عدد دلخواه شما — سامانه ناخالصِ آن را معکوس حساب می‌کند</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">معافیت مالیاتی عیدی (تومان)</Label>
              <MoneyInput value={exemptToman} onChange={setExemptToman} />
              <p className="text-[10px] text-muted-foreground leading-4">
                پیش‌فرض: ۲× حداقل دستمزد {legal ? <>= <Money amount={legal.defaultTaxExempt} short /></> : ""}
              </p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">یادداشت (اختیاری)</Label>
              <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="مبانی حکم، شماره مصوبه و…" />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button variant="outline" className="gap-1.5 border-amber-300 text-amber-800 hover:bg-amber-50" disabled={busy} onClick={() => run(true)}>
              <Calculator className="w-4 h-4" /> {busy ? "…" : "پیش‌نمایش محاسبه"}
            </Button>
            <Button className="bg-amber-600 hover:bg-amber-700 gap-1.5" disabled={busy || !previewIsFresh} onClick={() => run(false)} title={previewIsFresh ? "" : "ابتدا پیش‌نمایشِ به‌روز را ببینید"}>
              <ScrollText className="w-4 h-4" /> {busy ? "…" : "صدور حکم گروهی"}
            </Button>
            {preview && !previewIsFresh && (
              <span className="text-[11px] text-amber-700 self-center">ورودی‌ها تغییر کرده — پیش‌نمایش را به‌روزرسانی کنید.</span>
            )}
          </div>

          {/* پیش‌نمایش */}
          {preview && previewIsFresh && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
                <StatCard label="نفرات حکم" value={toFaDigits(preview.totals.headcount)} sub={preview.scopeLabel} highlight />
                <StatCard label="جمع مبلغ احکام (ناخالص)" value={<Money amount={preview.totals.totalGross} />} highlight />
                <StatCard label="جمع مالیات" value={<Money amount={preview.totals.totalTax} />} />
                <StatCard label="جمع خالص پرداختی" value={<Money amount={preview.totals.totalNet} />} sub={`هدف هر نفر: ${groupFa(Math.round(preview.meta.targetNetPerPerson / 10))} تومان`} />
              </div>
              <div className="rounded-xl border overflow-hidden">
                <div className="overflow-x-auto max-h-80 overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10">
                      <TableRow className="bg-slate-50/95 backdrop-blur">
                        <TableHead className="text-right">کارمند</TableHead>
                        <TableHead className="text-right">دپارتمان</TableHead>
                        <TableHead className="text-right">سطح</TableHead>
                        <TableHead className="text-left">حقوق پایه (ماهانه)</TableHead>
                        <TableHead className="text-center">نرخ مالیات نهایی</TableHead>
                        <TableHead className="text-left">مبلغ حکم (ناخالص)</TableHead>
                        <TableHead className="text-left">مالیات</TableHead>
                        <TableHead className="text-left">خالص</TableHead>
                        <TableHead className="text-center">ضریب / حقوق پایه</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {preview.lines.map((l, i) => (
                        <TableRow key={i} className="hover:bg-amber-50/30">
                          <TableCell className="text-sm font-medium">
                            {l.employeeName}
                            <span className="block text-[10px] text-muted-foreground tabular-nums">{l.personnelCode}</span>
                          </TableCell>
                          <TableCell className="text-xs">{l.department}</TableCell>
                          <TableCell className="text-xs">{l.jobLevelTitle}</TableCell>
                          <TableCell className="text-left"><Money amount={l.baseSalary} short /></TableCell>
                          <TableCell className="text-center text-xs tabular-nums">{fmtPercent(l.marginalRate)}</TableCell>
                          <TableCell className="text-left font-semibold"><Money amount={l.grossAmount} short /></TableCell>
                          <TableCell className="text-left"><Money amount={l.taxAmount} short /></TableCell>
                          <TableCell className="text-left text-emerald-700 font-medium"><Money amount={l.netAmount} short /></TableCell>
                          <TableCell className="text-center text-xs tabular-nums text-amber-800 font-bold">{groupFa(l.coefficient.toFixed(2))}×</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground leading-5 bg-slate-50 rounded-lg p-2.5">
                <b>مبنای محاسبه:</b> برای هر نفر فیش استاندارد ماهِ پرداخت با حقوق پایه دستیِ او محاسبه می‌شود و نرخ مالیات نهایی (پله مالیاتی همان نفر) بر مازادِ
                معافیتِ عیدی اعمال می‌شود؛ خالص هر نفر دقیقاً برابر هدف است (گرد کردن در مالیات می‌نشیند). «ضریب» = مبلغ حکم ÷ حقوق پایه ماهانه همان نفر.
              </p>
            </div>
          )}
        </div>

        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= جزئیات حکم =================
function DecreeDetail({ id, canManage, onClose, onChanged }: { id: string; canManage: boolean; onClose: () => void; onChanged: () => void }) {
  const { toast } = useToast();
  const detail = useApi<{
    decree: DecreeRowUI;
    lines: (DecreeLineUI & { id: string })[];
  }>(`/api/decree/${id}`);
  const [confirming, setConfirming] = useState(false);
  const [revertSalary, setRevertSalary] = useState(true);
  const [busy, setBusy] = useState(false);

  async function cancelDecree() {
    if (!detail.data) return;
    const isSalary = detail.data.decree.kind === "SALARY";
    setBusy(true);
    try {
      const res = await api<{ salaryReverted?: boolean }>(`/api/decree/${id}`, {
        method: "PATCH",
        json: { action: "cancel", ...(isSalary && revertSalary ? { revertSalary: true } : {}) },
      });
      toast({
        title: "حکم ابطال شد",
        description: res.salaryReverted
          ? `${detail.data.decree.decreeNo} — حقوق کارمند به مقدار قبل از حکم بازگردانده شد.`
          : isSalary
            ? `${detail.data.decree.decreeNo} — حکم حقوق ابطال شد.`
            : `${detail.data.decree.decreeNo} — از پیش‌بینی بودجه حذف می‌شود.`,
      });
      setConfirming(false);
      onChanged();
      onClose();
    } catch (e) {
      toast({ title: "خطا در ابطال", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  if (detail.loading) {
    return (
      <Dialog open onOpenChange={(v) => !v && onClose()}>
        <DialogContent className="sm:max-w-[56rem]" dir="rtl">
          <div className="space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-10" />)}</div>
        </DialogContent>
      </Dialog>
    );
  }
  if (detail.error || !detail.data) {
    return (
      <Dialog open onOpenChange={(v) => !v && onClose()}>
        <DialogContent dir="rtl">
          <DialogHeader><DialogTitle>خطا</DialogTitle></DialogHeader>
          <p className="text-sm text-rose-600">{detail.error || "حکم یافت نشد."}</p>
          <DialogFooter><Button variant="outline" onClick={onClose}>بستن</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  const d = detail.data.decree;
  const lines = detail.data.lines;
  const isSalary = d.kind === "SALARY";
  const salaryLine = isSalary ? lines[0] : null;
  const det = salaryLine?.details;

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[64rem] max-h-[92vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2">
            <ScrollText className={`w-5 h-5 ${isSalary ? "text-violet-600" : "text-amber-600"}`} />
            {d.decreeNo} — {d.title}
            <Badge className={isSalary ? "bg-violet-100 text-violet-800 hover:bg-violet-100" : "bg-amber-100 text-amber-800 hover:bg-amber-100"}>
              {isSalary ? "حکم حقوق" : "عیدی/پاداش"}
            </Badge>
            <Badge className={d.status === "ISSUED" ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-rose-100 text-rose-700 hover:bg-rose-100"}>
              {d.status === "ISSUED" ? "صادرشده" : "ابطال‌شده"}
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {isSalary && salaryLine ? (
            <>
              {/* ——— حکم حقوق فردی ——— */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
                <StatCard label="کارمند" value={d.scopeEmployeeName || salaryLine.employeeName} sub={`کد ${salaryLine.personnelCode} • ${salaryLine.department}`} highlight />
                <StatCard label="ماه اجرا" value={`${JALALI_MONTHS[d.payMonthM - 1]} ${toFaDigits(d.payMonthY)}`} sub={det?.effectiveJ ? `تا ${det.effectiveJ}` : undefined} />
                <StatCard
                  label="حقوق ماهانه"
                  value={<><Money amount={d.previousSalary ?? 0} short /> ← <b className="text-violet-700"><Money amount={salaryLine.baseSalary} short /></b></>}
                  sub={<>خالص هدف: <Money amount={d.targetNetPerPerson} short /></>}
                />
                <StatCard
                  label="فیش ماه اول (حقوق جدید)"
                  value={<Money amount={d.totalGross} short />}
                  sub={<>مالیات: <Money amount={d.totalTax} short /> • خالص: <b className="text-emerald-700"><Money amount={d.totalNet} short /></b></>}
                />
              </div>

              {(d.appliedSalary || d.notes) && (
                <div className="flex flex-wrap gap-1.5">
                  {d.appliedSalary && (
                    <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">✓ اعمال‌شده روی پرونده کارمند (سابقه تغییرات حقوق ثبت شد)</Badge>
                  )}
                  {d.notes && <p className="text-xs text-muted-foreground bg-slate-50 rounded-lg p-2.5 w-full">{d.notes}</p>}
                </div>
              )}

              {/* ریز فیش کامل حکم */}
              <div className="rounded-xl border overflow-hidden">
                <p className="text-xs font-bold bg-violet-50 text-violet-800 px-3 py-2 border-b">
                  ریز فیش ماه اول با حقوق جدید
                  {det ? ` — سنوات ${toFaDigits(det.seniorityYears ?? 0)} سال • ${det.married ? "متاهل" : "مجرد"} • ${toFaDigits(det.childCount ?? 0)} فرزند${det.baseSplit === "LEGAL" ? " • تفکیک پایه: عدد اداره کار" : ""}` : ""}
                </p>
                <div className="overflow-x-auto max-h-72 overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10">
                      <TableRow className="bg-slate-50/95 backdrop-blur">
                        <TableHead className="text-right">شرح</TableHead>
                        <TableHead className="text-left">مبلغ</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(det?.items || []).map((it, i) => (
                        <TableRow key={i} className={it.kind === "DEDUCTION" ? "text-rose-700" : ""}>
                          <TableCell className="text-xs">{it.title}</TableCell>
                          <TableCell className={`text-left tabular-nums text-xs ${it.kind === "DEDUCTION" ? "text-rose-700" : ""}`}>
                            <Money amount={it.kind === "DEDUCTION" ? -it.amount : it.amount} />
                          </TableCell>
                        </TableRow>
                      ))}
                      <TableRow className="bg-emerald-50 font-black text-emerald-800 border-t-2 border-emerald-200">
                        <TableCell className="text-xs">خالص پرداختی (هدف: <Money amount={d.targetNetPerPerson} short />)</TableCell>
                        <TableCell className="text-left tabular-nums text-xs"><Money amount={d.totalNet} /></TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>

              <p className="text-[11px] text-muted-foreground leading-5 bg-slate-50 rounded-lg p-2.5">
                صادرکننده: {d.createdBy || "—"} • «حقوق ماهانه» = حل معکوس خالص هدف با کانتکس واقعی پرونده تا پایان ماه اجرا.
                حکم حقوق فردی هزینه یک‌باره نیست — تغییر حقوق از طریق پرونده کارمند در «پیش‌بینی بودجه» لحاظ می‌شود.
                {det && det.currentNet ? <> خالص قبل از حکم: <Money amount={det.currentNet} short />.</> : null}
              </p>
            </>
          ) : (
            <>
              {/* ——— حکم گروهی عیدی/پاداش ——— */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
                <StatCard label="ماه پرداخت" value={`${JALALI_MONTHS[d.payMonthM - 1]} ${toFaDigits(d.payMonthY)}`} sub={`دامنه: ${d.scopeDeptName} • ${d.levelTitle}`} />
                <StatCard label="خالص هدف هر نفر" value={<Money amount={d.targetNetPerPerson} />} sub={<>معافیت عیدی: <Money amount={d.taxExempt} short /></>} />
                <StatCard label="نفرات" value={toFaDigits(d.headcount)} highlight />
                <StatCard label="جمع مبلغ احکام" value={<Money amount={d.totalGross} />} sub={<>مالیات: <Money amount={d.totalTax} short /> • خالص: <Money amount={d.totalNet} short /></>} highlight />
              </div>
              {d.notes && <p className="text-xs text-muted-foreground bg-slate-50 rounded-lg p-2.5">{d.notes}</p>}

              <div className="rounded-xl border overflow-hidden">
                <div className="overflow-x-auto max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader className="sticky top-0 z-10">
                      <TableRow className="bg-slate-50/95 backdrop-blur">
                        <TableHead className="text-right">کارمند</TableHead>
                        <TableHead className="text-right">دپارتمان</TableHead>
                        <TableHead className="text-right">سطح</TableHead>
                        <TableHead className="text-left">حقوق پایه (ماهانه)</TableHead>
                        <TableHead className="text-center">نرخ مالیات نهایی</TableHead>
                        <TableHead className="text-left">مبلغ حکم (ناخالص)</TableHead>
                        <TableHead className="text-left">مالیات</TableHead>
                        <TableHead className="text-left">خالص</TableHead>
                        <TableHead className="text-center">ضریب / حقوق پایه</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {lines.map((l) => (
                        <TableRow key={l.id} className="hover:bg-amber-50/30">
                          <TableCell className="text-sm font-medium">
                            {l.employeeName}
                            <span className="block text-[10px] text-muted-foreground tabular-nums">{l.personnelCode}</span>
                          </TableCell>
                          <TableCell className="text-xs">{l.department}</TableCell>
                          <TableCell className="text-xs">{l.jobLevelTitle}</TableCell>
                          <TableCell className="text-left"><Money amount={l.baseSalary} short /></TableCell>
                          <TableCell className="text-center text-xs tabular-nums">{fmtPercent(l.marginalRate)}</TableCell>
                          <TableCell className="text-left font-semibold"><Money amount={l.grossAmount} short /></TableCell>
                          <TableCell className="text-left"><Money amount={l.taxAmount} short /></TableCell>
                          <TableCell className="text-left text-emerald-700 font-medium"><Money amount={l.netAmount} short /></TableCell>
                          <TableCell className="text-center text-xs tabular-nums text-amber-800 font-bold">{groupFa(l.coefficient.toFixed(2))}×</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>

              <p className="text-[11px] text-muted-foreground leading-5 bg-slate-50 rounded-lg p-2.5">
                صادرکننده: {d.createdBy || "—"} • «ضریب» = مبلغ حکم ÷ حقوق پایه ماهانه همان نفر (≈ چند «ماه پایه»).
                این حکم در «پیش‌بینی بودجه حقوق» در ماه {JALALI_MONTHS[d.payMonthM - 1]} {toFaDigits(d.payMonthY)} لحاظ می‌شود.
              </p>
            </>
          )}
        </div>

        <DialogFooter className="mt-2 gap-2 flex-wrap">
          {canManage && d.status === "ISSUED" && !confirming && (
            <Button variant="outline" className="gap-1.5 border-rose-300 text-rose-700 hover:bg-rose-50" onClick={() => setConfirming(true)}>
              <Ban className="w-4 h-4" /> ابطال حکم
            </Button>
          )}
          {canManage && d.status === "ISSUED" && confirming && (
            <>
              {isSalary && d.appliedSalary && (
                <label className="flex items-center gap-2 text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2">
                  <input
                    type="checkbox"
                    checked={revertSalary}
                    onChange={(e) => setRevertSalary(e.target.checked)}
                    className="accent-rose-600 w-4 h-4"
                  />
                  حقوق کارمند هم به مقدار قبل از حکم بازگردانده شود
                </label>
              )}
              <span className="text-xs text-rose-700 self-center">
                {isSalary ? "این حکم حقوق ابطال شود؟" : "این حکم ابطال شود؟ (از پیش‌بینی بودجه حذف می‌شود)"}
              </span>
              <Button variant="destructive" className="gap-1.5" disabled={busy} onClick={cancelDecree}>
                <Ban className="w-4 h-4" /> {busy ? "…" : "بله، ابطال کن"}
              </Button>
              <Button variant="outline" onClick={() => setConfirming(false)}>خیر</Button>
            </>
          )}
          <Button variant="outline" onClick={onClose}>بستن</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

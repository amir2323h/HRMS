import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import { computeReversePaysheet } from "@/lib/payroll/reverse";
import { taxBracketBreakdown, shiftRateOf } from "@/lib/payroll/engine";
import { computeEmployeeReverse } from "@/lib/reverse-employee";
import { todayJalaliStr } from "@/lib/jalali";

/**
 * محاسبه معکوس حقوق:
 * POST { targetNet (ریال), gradeId?, childCount?, housingEnabled?, groceryEnabled?,
 *        seniorityYears?, otherAllowance?, rounding?,
 *        employmentType? (DAILY|SHIFT), shiftPattern? (TWO_SHIFT|THREE_SHIFT),
 *        nightHours?, fridayHours?, holidayHours?, absentDays?, missionDays?,
 *        employeeId?, effectiveY?, effectiveM?,  ← حالت «کارمند مشخص»
 *        save?{ periodId, employeeId } }
 * حالت کارمند مشخص: کانتکس واقعی او (فرزند/تاهل/سنوات از تاریخ استخدام/طبقه/جذب/شیفت)
 * تا پایان «ماه اجرا» بارگذاری می‌شود — خروجی دقیقاً با فیش حقوقی و «پیش‌بینی بودجه»
 * همان کارمند یکی است (هر دو از contextFromEmployee می‌سازند). سنوات ورودی دستی
 * نادیده گرفته می‌شود و از تاریخ استخدام محاسبه می‌شود.
 * اقلام شیفت/شب/جمعه/تعطیل/غیبت/مأموریت با حقوق پایه نسبت مستقیم دارند → در معادله معکوس
 * لحاظ می‌شوند و حل دو-بخشی همچنان همگراست (خالص اکیداً صعودی و تکه‌ای-خطی).
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "reverse:use");
    const b = await req.json();
    const targetNet = Math.round(+b.targetNet || 0);
    if (!targetNet || targetNet <= 0) {
      return Response.json({ error: "مبلغ خالص هدف نامعتبر است." }, { status: 400 });
    }

    const params = await getLegalParams(true);

    // ————————————————————————————————
    // حالت ۱: کارمند مشخص — کانتکس واقعی پرونده + ماه اجرا
    // (یکسان با فیش حقوقی، پیش‌بینی بودجه و حکم حقوق)
    // ————————————————————————————————
    if (b.employeeId) {
      const outcome = await computeEmployeeReverse({
        employeeId: String(b.employeeId),
        targetNet,
        effectiveY: b.effectiveY,
        effectiveM: b.effectiveM,
        params,
        overrides: {
          gradeId: b.gradeId ?? null,
          childCount: b.childCount !== undefined ? b.childCount : undefined,
          married: b.married !== undefined ? b.married === true : undefined,
          housingEnabled: b.housingEnabled !== undefined ? b.housingEnabled !== false : undefined,
          groceryEnabled: b.groceryEnabled !== undefined ? b.groceryEnabled !== false : undefined,
          otherAllowance: b.otherAllowance !== undefined ? b.otherAllowance : undefined,
          employmentType: b.employmentType,
          shiftPattern: b.shiftPattern,
          nightHours: b.nightHours,
          fridayHours: b.fridayHours,
          holidayHours: b.holidayHours,
          absentDays: b.absentDays,
          missionDays: b.missionDays,
          rounding: b.rounding ? +b.rounding : null,
          baseSplit: b.baseSplit === "GRADE" ? "GRADE" : "LEGAL",
        },
      });
      if ("error" in outcome) return Response.json({ error: outcome.error }, { status: 400 });

      await audit(
        session,
        "REVERSE_CALC",
        "PAYROLL",
        outcome.employee.id,
        `محاسبه معکوس برای ${outcome.employee.fullName} — خالص هدف ${targetNet.toLocaleString("en-US")} ریال → حقوق ماهانه ${outcome.result.baseSalary.toLocaleString("en-US")} ریال (ماه اجرا ${outcome.effectiveY}/${String(outcome.effectiveM).padStart(2, "0")})`,
        { targetNet, employeeId: outcome.employee.id },
        { baseSalary: outcome.result.baseSalary, achievedNet: outcome.result.achievedNet, residual: outcome.result.residual }
      );

      const brackets = taxBracketBreakdown(outcome.result.paysheet.taxableIncome, params.taxBrackets);
      return {
        result: outcome.result,
        baseSplit: outcome.baseSplit,
        splitBaseAmount: outcome.splitBaseAmount,
        brackets,
        legal: {
          year: params.year,
          minWage: params.minWage,
          housing: params.housing,
          grocery: params.grocery,
          childPerChild: params.childPerChild,
          marriageAllowance: params.marriageAllowance,
          seniorityMode: params.seniorityMode,
          seniorityDailyByYear: params.seniorityDailyByYear,
          employeeSsoRate: params.employeeSsoRate,
          employerSsoRate: params.employerSsoRate,
          unemploymentRate: params.unemploymentRate,
          taxBrackets: params.taxBrackets,
        },
        today: todayJalaliStr(),
        savedPayslipId: null,
        employee: {
          ...outcome.employee,
          effectiveY: outcome.effectiveY,
          effectiveM: outcome.effectiveM,
          effectiveJ: outcome.effectiveJ,
        },
        marginalRate: outcome.marginalRate,
      };
    }

    // ————————————————————————————————
    // حالت ۲: ورودی دستی (بدون انتخاب کارمند) — رفتار پیشین
    // ————————————————————————————————
    const grade = b.gradeId ? await db.jobGrade.findUnique({ where: { id: b.gradeId } }) : null;

    // ——— مبنای تفکیک حقوق پایه در نتیجه ———
    // LEGAL (پیش‌فرض): عدد پایه اداره کار (حداقل دستمزد ۱۴۰۵) در «حقوق پایه» می‌نشیند
    //   و مابالفاوت حقوق ماهانه در «سایر مزایا»؛ اقلام قانونی (مسکن/بن/اولاد/تاهل/سنوات) علاوه می‌شود.
    // GRADE: حقوق پایه ثابت سطح (عدد دستیِ ثبت‌شده در طبقه) — بدون ثابت = کل حقوق، پایه.
    const baseSplit: "LEGAL" | "GRADE" = b.baseSplit === "GRADE" ? "GRADE" : "LEGAL";
    const splitBaseAmount = baseSplit === "LEGAL" ? params.minWage : grade && Number(grade.fixedBaseSalary) > 0 ? Number(grade.fixedBaseSalary) : 0;

    // نوع اشتغال/شیفت + کارکرد ماهانه (شب/جمعه/تعطیل/غیبت/مأموریت) — قابل لحاظ در معادله معکوس
    const employmentType = b.employmentType === "SHIFT" ? "SHIFT" : "DAILY";
    const shiftPattern = employmentType === "SHIFT" && ["TWO_SHIFT", "THREE_SHIFT"].includes(b.shiftPattern) ? String(b.shiftPattern) : "";
    const hours = (v: unknown) => Math.max(0, Math.min(300, Number(v) || 0));
    const nightHours = hours(b.nightHours);
    const fridayHours = hours(b.fridayHours);
    const holidayHours = hours(b.holidayHours);
    const absentDays = Math.max(0, Math.min(30, +b.absentDays || 0));
    const missionDays = Math.max(0, Math.min(30, +b.missionDays || 0));

    const result = computeReversePaysheet({
      targetNet,
      params,
      gradeMin: grade ? Number(grade.minBaseSalary) : undefined,
      gradeMax: grade ? Number(grade.maxBaseSalary) : undefined,
      rounding: b.rounding ? +b.rounding : null,
      context: {
        childCount: Math.max(0, +b.childCount || 0),
        housingEnabled: b.housingEnabled !== false,
        groceryEnabled: b.groceryEnabled !== false,
        seniorityYears: Math.max(0, +b.seniorityYears || 0),
        seniorityBase: grade ? Number(grade.seniorityBase) : 0,
        married: b.married === true, // حق تاهل ۱۴۰۵ — فقط برای کارکنان متاهل
        attraction: grade ? Number(grade.attraction) : 0,
        // تفکیک حقوق پایه: LEGAL = عدد پایه اداره کار | GRADE = حقوق پایه ثابت سطح
        fixedBaseAmount: baseSplit === "LEGAL" ? params.minWage : grade && Number(grade.fixedBaseSalary) > 0 ? Number(grade.fixedBaseSalary) : undefined,
        overtimeHours: 0,
        otherAllowance: Math.max(0, +b.otherAllowance || 0),
        otherDeduction: 0,
        nightHours,
        fridayHours,
        holidayHours,
        absentDays,
        missionDays,
        shiftRate: shiftRateOf(employmentType, shiftPattern, params),
      },
    });

    await audit(
      session,
      "REVERSE_CALC",
      "PAYROLL",
      b.gradeId || "",
      `محاسبه معکوس — خالص هدف ${targetNet.toLocaleString("en-US")} ریال → حقوق پایه ${result.baseSalary.toLocaleString("en-US")} ریال`,
      { targetNet },
      { baseSalary: result.baseSalary, achievedNet: result.achievedNet, residual: result.residual }
    );

    // جزئیات پله‌های مالیات برای درآمد مشمول نتیجه
    const brackets = taxBracketBreakdown(result.paysheet.taxableIncome, params.taxBrackets);

    let saved: string | null = null;
    if (b.save && b.save.periodId && b.save.employeeId) {
      // ذخیره به‌عنوان فیش معکوس برای کارمند در دوره موردنظر (جایگزین فیش قبلی همان کارمند)
      const existing = await db.payslip.findFirst({
        where: { periodId: b.save.periodId, employeeId: b.save.employeeId },
      });
      const sheet = result.paysheet;
      const data = {
        baseSalary: BigInt(sheet.baseCore), // حقوق پایه — عدد ثابت سطح
        otherBenefits: BigInt(sheet.otherBenefits), // سایر مزایا — باقیمانده حقوق ماهانه
        responsibility: BigInt(0), // قدیمی — از ۲.۹.۱۷ جای خود را به «سایر مزایا» داد
        merit: BigInt(0),
        seniority: BigInt(sheet.seniority),
        marriageAllowance: BigInt(sheet.marriageAllowance), // حق تاهل — مصوبه ۱۴۰۵
        housing: BigInt(sheet.housing),
        grocery: BigInt(sheet.grocery),
        childAllowance: BigInt(sheet.childAllowance),
        attraction: BigInt(sheet.attraction),
        overtimeHours: 0,
        overtimeAmount: BigInt(sheet.overtimeAmount),
        nightHours: sheet.nightHours,
        nightAmount: BigInt(sheet.nightAmount),
        fridayHours: sheet.fridayHours,
        fridayAmount: BigInt(sheet.fridayAmount),
        holidayHours: sheet.holidayHours,
        holidayAmount: BigInt(sheet.holidayAmount),
        shiftAllowance: BigInt(sheet.shiftAllowance),
        absentDays: sheet.absentDays,
        absenceDeduction: BigInt(sheet.absenceDeduction),
        missionDays: sheet.missionDays,
        missionAmount: BigInt(sheet.missionAmount),
        otherAllowance: BigInt(sheet.otherAllowance),
        gross: BigInt(sheet.gross),
        insurableBase: BigInt(sheet.insurableBase),
        employeeSso: BigInt(sheet.employeeSso),
        employerSso20: BigInt(sheet.employerSso20),
        unemploymentSso3: BigInt(sheet.unemploymentSso3),
        taxableIncome: BigInt(sheet.taxableIncome),
        incomeTax: BigInt(sheet.incomeTax),
        otherDeduction: BigInt(sheet.otherDeduction),
        netPay: BigInt(sheet.netPay),
        isReverse: true,
        targetNet: BigInt(targetNet),
      };
      if (existing) {
        await db.payslip.update({ where: { id: existing.id }, data });
        saved = existing.id;
      } else {
        const slip = await db.payslip.create({
          data: { ...data, periodId: b.save.periodId, employeeId: b.save.employeeId },
        });
        saved = slip.id;
      }
      await audit(
        session,
        "CREATE",
        "PAYSLIP",
        saved,
        `ثبت فیش معکوس — خالص هدف ${targetNet.toLocaleString("en-US")} ریال`,
        undefined,
        { isReverse: true, targetNet }
      );
    }

    return {
      result,
      baseSplit,
      splitBaseAmount,
      brackets,
      legal: {
        year: params.year,
        minWage: params.minWage,
        housing: params.housing,
        grocery: params.grocery,
        childPerChild: params.childPerChild,
        marriageAllowance: params.marriageAllowance,
        seniorityMode: params.seniorityMode,
        seniorityDailyByYear: params.seniorityDailyByYear,
        employeeSsoRate: params.employeeSsoRate,
        employerSsoRate: params.employerSsoRate,
        unemploymentRate: params.unemploymentRate,
        taxBrackets: params.taxBrackets,
      },
      today: todayJalaliStr(),
      savedPayslipId: saved,
    };
  });
}

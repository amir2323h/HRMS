// ============================================================
// Backfill v2.9.31 — رفع باگ‌های چاپ نامه + چیدمان دوستونه امضا/مهر
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۳۱
//  ۳) پاکسازی کش وضعیت آپدیت
// تغییرات این نسخه در چاپ/دانلود نامه‌ها:
//  • باکس نام/سمت امضاکننده («با تجدید احترام» + نام + سمت):
//    سمت چپ پایین نامه با فاصله ۲۵٪ از حاشیه چپ
//  • تصویر امضای دست‌نویس و مهر «کنارِ» همین باکس در سمت راستِ آن —
//    مهر دقیقاً زیر امضا، بدون هم‌پوشانی با نام/سمت
//  • سمت گیرنده (مثل «مدیرعامل شرکت …») خط دوم زیر گیرنده
//  • چاپ/دانلود چندصفحه‌ای با سربرگ: تمپلیت کامل کاغذ A4/A5
//    (سربرگ + پابرگ) روی «هر صفحه» تکرار می‌شود + تعداد صفحات
//    دقیق (بدون صفحه اضافه‌ی تقریباً خالی) و متن ادامه صفحات
//    از ناحیه سربرگ فاصله می‌گیرد
//  • مهر امضای دیجیتال (بارکد) چسبیده به حاشیه چپ صفحه
//  (اسکیما: فیلد recipientPosition — backfill v2.9.30+، db push)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2931.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2931 = {
  version: "2.9.31",
  title: "تازه‌های نسخه ۲.۹.۳۱",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "IMPROVED",
      title: "نامه‌ها: چیدمان دوستونه امضا/مهر",
      desc: "در نسخه چاپی و دانلودی نامه‌ها، ناحیه امضا بازطراحی شد: باکس مشخصات امضاکننده — شامل عبارت «با تجدید احترام» (به‌جای «با تشکر» سابق)، نام و سمت — اکنون در سمت چپ پایین نامه و با فاصله ۲۵٪ از حاشیه چپ قرار می‌گیرد و تصویر امضای دست‌نویس و مهر دقیقاً «کنارِ» همین باکس در سمت راستِ آن چاپ می‌شوند؛ مهر زیر امضای دست‌نویس می‌افتد و هرگز روی نام/سمت امضاکننده نمی‌آید. مهر امضای دیجیتال (بارکد راستی‌آزمایی) چسبیده به حاشیه چپ صفحه است تا با امضای دست‌نویس و مهر تداخل نکند. همچنین اگر متن نامه با عبارت «با سلام و احترام» آغاز نشده باشد، این عبارت به‌صورت خودکار با فونت تیتر (B Titr) در ابتدای متن درج می‌شود — هم در متن ساده و هم در نامه‌های دستی با متن غنی/جدولدار.",
    },
    {
      tag: "FEATURE",
      title: "نامه‌ها: ثبت «سمت گیرنده» در نامه دستی",
      desc: "در فرم ثبت نامه دستی، فیلد جدید «سمت گیرنده» (مثل «مدیرعامل شرکت نمونه») اضافه شد. سمت گیرنده در نسخه چاپی/دانلودی نامه به‌صورت خط دوم زیر نام گیرنده با فونت تیتر درج می‌شود، در صفحه راستی‌آزمایی عمومی امضای دیجیتال هم نمایش داده می‌شود و داخل کد امضای دیجیتال نامه قفل می‌شود تا هر تغییر بعدی در آن، نامعتبر اعلام شود.",
    },
    {
      tag: "FIXED",
      title: "چاپ چندصفحه‌ای: تمپلیت کامل کاغذ A4/A5 روی هر صفحه",
      desc: "در نسخه «با سربرگ» (چاپ و دانلود)، وقتی نامه بیش از یک صفحه می‌شد، سربرگ فقط در صفحه اول و پابرگ فقط در صفحه آخر چاپ می‌شد. اکنون قالب کامل کاغذ A4/A5 — هم سربرگ و هم پابرگ — روی «هر صفحه» نامه‌های چندصفحه‌ای تکرار می‌شود؛ متن نامه هم در ادامه صفحات از ناحیه سربرگ فاصله می‌گیرد و روی گرافیک نمی‌افتد و تعداد صفحات چاپی دقیق محاسبه می‌شود (صفحه اضافه‌ی تقریباً خالی چاپ نمی‌شود). این رفتار برای هر دو حالت سربرگ (تصویر رسمی و سربرگ دیجیتال) و هر دو سایز کاغذ A4/A5 برقرار است.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2931) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۳۱» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.31") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2931) } });
      console.log(`✓ اطلاعیه ${cfg.version || "—"} به «تازه‌های نسخه ۲.۹.۳۱» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.32 — چسبیدن امضا و مهر به هم در چاپ نامه
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۳۲
//  ۳) پاکسازی کش وضعیت آپدیت
// تغییر این نسخه در چاپ/دانلود نامه‌ها:
//  • حاشیه خالی (شفاف/سفید) تصاویر امضا و مهر هنگام چاپ/دانلود
//    خودکار برش داده می‌شود — جوهر مهر بلافاصله (≈۱mm) زیر جوهر
//    امضا می‌نشیند (رفع «جدا دیده‌شدن امضا و مهر از هم» در
//    تصاویر اسکن‌شده دارای حاشیه)
//  • همین برش هنگام آپلود تصویر امضا/مهر در تنظیمات هم انجام می‌شود
//  • جعبه قدثابت تصویر → حداکثر قد (تصویر پهن دیگر letterbox عمودی
//    نمی‌گیرد و جوهرش کامل رندر می‌شود)
//  (بدون تغییر اسکیما — فقط کد چاپ src/lib/letter-print.ts)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2932.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2932 = {
  version: "2.9.32",
  title: "تازه‌های نسخه ۲.۹.۳۲",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "نامه‌ها: چسبیدن امضا و مهر به هم در چاپ (برش خودکار حاشیه تصاویر)",
      desc: "اگر تصویر امضا یا مهرِ آپلودشده در تنظیمات، دور خودش حاشیه خالی (شفاف یا سفید) داشته باشد — اتفاق رایج در تصاویر اسکن‌شده — جوهرِ امضا و جوهرِ مهر در نسخه چاپی به‌صورت جدا از هم و با فاصله دیده می‌شدند، در حالی که چیدمان (امضا بالا، مهر دقیقاً زیر آن، باکس نام/سمت در سمت چپ) درست بود. اکنون حاشیه خالی تصاویر امضا و مهر هنگام چاپ/دانلود نامه به‌صورت خودکار برش داده می‌شود و جوهر مهر بلافاصله (حدود یک میلی‌متر) زیر جوهر امضا می‌نشیند؛ همین برش هنگام آپلود تصویر جدید امضا/مهر در «تنظیمات ← قالب نامه‌ها ← امضاکنندگان مجاز» هم انجام می‌شود تا تصویر تمیز ذخیره شود. این اصلاح برای همه تصاویر قبلی هم بدون نیاز به آپلود مجدد اعمال می‌شود (چاپ روی سربرگ رسمی، سربرگ دیجیتال و فایل دانلودی خودکفا — هر دو کاغذ A4 و A5).",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2932) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۳۲» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.32") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2932) } });
      console.log(`✓ اطلاعیه ${cfg.version || "—"} به «تازه‌های نسخه ۲.۹.۳۲» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

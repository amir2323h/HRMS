// ============================================================
// Backfill v2.9.30 — چیدمان جدید امضا/مهر نامه‌ها
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۳۰
//  ۳) پاکسازی کش وضعیت آپدیت
// چیدمان جدید امضا/مهر در چاپ نامه‌ها:
//  • عبارت «با تجدید احترام» (به‌جای «با تشکر») همراه نام و سمت
//    امضاکننده در یک بلوک در سمت راست پایین نامه
//  • مهر دقیقاً زیر امضای دست‌نویس — بدون هم‌پوشانی با نام/سمت
//  • مهر امضای دیجیتال (بارکد) به سمت چپ صفحه منتقل شد
//  • درج خودکار «با سلام و احترام» با فونت تیتر در ابتدای متن
//    نامه‌هایی که با این عبارت شروع نمی‌شوند
//  (بدون تغییر اسکیما)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2930.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2930 = {
  version: "2.9.30",
  title: "تازه‌های نسخه ۲.۹.۳۰",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "IMPROVED",
      title: "نامه‌ها: چیدمان جدید امضا و مهر + درج خودکار «با سلام و احترام»",
      desc: "در نسخه چاپی و دانلودی نامه‌ها، ناحیه امضا مطابق اصول مکاتبات رسمی بازطراحی شد: بلوک امضاکننده — شامل عبارت «با تجدید احترام» (به‌جای «با تشکر» سابق)، تصویر امضای دست‌نویس و سپس نام و سمت امضاکننده — هم‌اکنون در سمت راست پایین نامه (سمت امضاکننده) قرار می‌گیرد و تصویر مهر دقیقاً زیر امضای دست‌نویس چاپ می‌شود؛ بدین ترتیب مهر دیگر روی نام و سمت امضاکننده نمی‌افتد و کل بلوک در یک قاب مرتب جمع می‌شود. مهر امضای دیجیتال (بارکد راستی‌آزمایی) به سمت چپ صفحه منتقل شد تا با امضای دست‌نویس و مهر تداخل نکند. همچنین اگر متن نامه با عبارت «با سلام و احترام» آغاز نشده باشد، این عبارت به‌صورت خودکار با فونت تیتر (B Titr) در ابتدای متن درج می‌شود — هم در متن ساده و هم در نامه‌های دستی با متن غنی/جدولدار.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2930) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۳۰» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.30") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2930) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۳۰» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

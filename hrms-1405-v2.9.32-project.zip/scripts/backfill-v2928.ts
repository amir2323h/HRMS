// ============================================================
// Backfill v2.9.28 — بهبود چاپ نامه‌ها
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۸
//  ۳) پاکسازی کش وضعیت آپدیت
// بهبود چاپ نامه‌ها:
//  • موضوع، گیرنده و «با سلام و احترام» با فونت تیتر (B Titr)
//    چاپ می‌شوند + فاصله فشرده‌تر خط موضوع/گیرنده
//  • تنظیم سایز چاپ تصویر امضا و مهر (میلی‌متر) از
//    «تنظیمات ← قالب نامه‌ها ← امضاکنندگان مجاز»
//  (فونت BTitr.woff2 در public/fonts — بدون تغییر اسکیما)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2928.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2928 = {
  version: "2.9.28",
  title: "تازه‌های نسخه ۲.۹.۲۸",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "IMPROVED",
      title: "نامه‌ها: فونت تیتر برای موضوع/گیرنده/احترام + تنظیم سایز امضا و مهر",
      desc: "در نسخه چاپی و دانلودی نامه‌ها، «موضوع»، «گیرنده» و عبارت «با سلام و احترام» ابتدای متن حالا با فونت تیتر (B Titr) — فونت استاندارد تیتر مکاتبات رسمی — چاپ می‌شوند و فاصله بین خط موضوع و گیرنده فشرده‌تر شده است. عبارت احترام در ابتدای متن (چه متن ساده و چه نامه دستی با جدول) خودکار شناسایی و تیتر می‌شود. همچنین در «تنظیمات ← قالب نامه‌ها ← امضاکنندگان مجاز» دو فیلد «قد تصویر امضا» و «قد تصویر مهر» (میلی‌متر) اضافه شد تا اندازه تصاویر امضای دست‌نویس و مهر در چاپ دقیقاً مطابق نیاز تنظیم شود (پیش‌فرض: امضا ۱۱ و مهر ۱۳ میلی‌متر — در کاغذ A5 به‌میزان متناسب کوچک‌تر). فونت B Titr به‌صورت کاملاً محلی در بسته قرار گرفته و در فایل دانلودی خودکفا نامه هم تعبیه می‌شود.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2928) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۸» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.28") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2928) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۸» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

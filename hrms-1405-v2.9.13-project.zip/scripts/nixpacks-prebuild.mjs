// ============================================================
// nixpacks-prebuild — آماده‌سازی محیط برای بیلدرهای Nixpacks
// (داکپلوی / Coolify / Railway و…)
//
// اجرا در گام build (nixpacks.toml) — قبل از «npm run build»:
//  ۱) تعیین DATABASE_URL — اولویت: متغیر محیطی پنل > مسیر پیش‌فرض پروژه
//  ۲) نوشتن .env (DATABASE_URL + AUTH_SECRET + APP_VERSION) برای اجرای
//     runtime سرور standalone (next build آن را داخل standalone کپی می‌کند)
//  ۳) ساخت/همگام‌سازی دیتابیس SQLite (prisma db push)
//  ۴) bootstrap مدیر اولیه (admin / admin123) + مهر نسخه — idempotent
//  ۵) زنجیره بک‌فیل‌های داده پایه — همان دنباله نصب تمیز VPS/داکر:
//     قالب‌نامه‌ها، تعطیلات رسمی ۱۴۰۵، شیفت‌ها، اطلاعیه نسخه و…
//  ۶) AUTH_SECRET تصادفی در صورت نبود (ورود یکپارچه/امنیت)
//
// ⚠ v2.9.7 — معماری والیوم ماندگار:
//   داده‌های runtime روی پلتفرم PaaS در والیوم (مثل /data) نگه داشته
//   می‌شوند. این اسکریپت «دیتابیس آماده» را همیشه در مسیر لوکال ایمیج
//   (db/custom.db) می‌پزد تا nixpacks-start.mjs در زمان اجرا آن را روی
//   والیوم کپی کند (نصب تازه) یا موجود را به‌روزرسانی کند (آپدیت بدون
//   پاک شدن داده‌ها). اگر پنل DATABASE_URL خارجی (file:/data/...) داده
//   باشد، یک نسخهٔ دورریز آن هم در همان مسیر ساخته می‌شود تا next build
//   در صورت نیاز به دیتابیس، مسیر معتبری داشته باشد (در زمان اجرا با
//   والیوم خالی mount می‌شود و از نو مقداردهی خواهد شد).
// ============================================================
import { existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, rmSync } from "fs";
import { execSync } from "child_process";
import { randomBytes } from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dbDir = path.join(root, "db");
const dbFile = path.join(dbDir, "custom.db");
const localUrl = `file:${dbFile}`; // دیتابیس «آماده» — داخل ایمیج پخته می‌شود

// همان دنباله نصب تمیز داکر/VPS — همیشه idempotent
const BACKFILLS = [
  "backfill-v8.ts", // قالب‌نامه‌های آماده
  "backfill-v28.ts", // تعطیلات رسمی ۱۴۰۵ + شیفت‌ها و ساعت استاندارد
  "backfill-v281.ts", // اطلاعیه ۲.۸.۱ (پشتیبان‌گیری/بازیابی)
  "backfill-v29.ts", // مجوز مدیریت کار + اطلاعیه ۲.۹.۰
  "backfill-v291.ts",
  "backfill-v292.ts",
  "backfill-v293.ts",
  "backfill-v294.ts",
  "backfill-v295.ts",
  "backfill-v296.ts",
  "backfill-v297.ts", // اطلاعیه ۲.۹.۷ + مهر نسخه در دیتابیس
  "backfill-v298.ts", // رفع کرش RoleEditor + اطلاعیه ۲.۹.۸
  "backfill-v299.ts", // مدل دوم پاداش (برآورد بودجه) + اطلاعیه ۲.۹.۹
  "backfill-v2910.ts", // لیست نفرات + سهم تیم‌ها در برآورد بودجه + اطلاعیه ۲.۹.۱۰
  "backfill-v2911.ts", // انتخاب چندتایی/حذف/ترک کار + خالص پرداختی طبقات + اطلاعیه ۲.۹.۱۱
  "backfill-v2912.ts", // رفع خالص پرداختی طبقات + افزایش قانونی مزد ۱۴۰۵ + اطلاعیه ۲.۹.۱۲
  "backfill-v2913.ts", // فرمول قطعی خالص پرداختی طبقات: پایه + مسکن + بن − بیمه − مالیات + اطلاعیه ۲.۹.۱۳
];

// ---------- ۱) DATABASE_URL ----------
// runtimeUrl: مسیری که سرور در زمان اجرا استفاده می‌کند (پنل یا پیش‌فرض)
let runtimeUrl = (process.env.DATABASE_URL || "").trim();
if (runtimeUrl.startsWith("file:")) {
  const p = runtimeUrl.replace(/^file:/i, "").split("?")[0].trim();
  runtimeUrl = "file:" + (path.isAbsolute(p) ? p : path.join(root, "prisma", p));
} else {
  if (runtimeUrl) {
    console.warn(`⚠ DATABASE_URL پنل (${runtimeUrl.slice(0, 40)}…) پایگاه غیر-SQLite است — این سامانه SQLite است؛ نادیده گرفته شد.`);
  }
  // پنل چیزی نگفته — nixpacks-start.mjs در runtime والیوم /data را خودکار
  // تشخیص می‌دهد؛ اینجا مسیر پیش‌فرض موقتی می‌نویسیم (runtime بازنویسی می‌کند)
  runtimeUrl = localUrl;
}
console.log(`▪ DATABASE_URL (runtime) = ${runtimeUrl}`);
console.log(`▪ DATABASE_URL (بیلد — دیتابیس آماده) = ${localUrl}`);
mkdirSync(dbDir, { recursive: true });

// ---------- ۲) .env برای runtime ----------
// next build این فایل را داخل .next/standalone کپی می‌کند و سرور standalone
// همان‌جا لودش می‌کند — nixpacks-start.mjs مقادیر نهایی را در runtime بازنویسی می‌کند
const pkg = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8"));
const authSecret = (process.env.AUTH_SECRET || "").trim() || randomBytes(32).toString("hex");
const envPath = path.join(root, ".env");
const existingEnv = existsSync(envPath) ? readFileSync(envPath, "utf8") : "";
let envContent = existingEnv;
const setVar = (name, val) => {
  const re = new RegExp(`^${name}=.*$`, "m");
  if (re.test(envContent)) envContent = envContent.replace(re, `${name}=${val}`);
  else {
    if (envContent && !envContent.endsWith("\n")) envContent += "\n";
    envContent += `${name}=${val}\n`;
  }
};
setVar("DATABASE_URL", runtimeUrl);
setVar("AUTH_SECRET", authSecret);
// نسخه محصول — رفع باگ v2.9.5: بدون این خط فوتر/پنل آپدیت در PaaS نسخه نمی‌نمود
setVar("APP_VERSION", pkg.version);
writeFileSync(envPath, envContent);
console.log(`✓ .env آماده شد (DATABASE_URL + AUTH_SECRET + APP_VERSION=${pkg.version})`);

// ---------- ۳) پخت دیتابیس «آماده» در مسیر لوکال ایمیج ----------
// از صفر می‌پزیم (مثل dbprep داکر): دیتابیس توسعهٔ مخزن ممکن است کاربران
// دمو داشته باشد — نصب تازهٔ مشتری فقط باید «admin» داشته باشد (بهداشت امنیتی)
try { rmSync(dbFile, { force: true }); } catch { /* نبود فایل عادی است */ }
try {
  execSync("npx prisma db push --skip-generate --accept-data-loss", {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, DATABASE_URL: localUrl },
  });
  console.log("✓ دیتابیس SQLite آماده (اسکیما + فقط مدیر اولیه — نصب تمیز) از نو ساخته شد");
} catch (e) {
  console.error("✗ همگام‌سازی اسکیمای دیتابیس شکست خورد:", e.message);
  process.exit(1);
}

// ---------- ۴) bootstrap مدیر اولیه + مهر نسخه ----------
try {
  execSync("node scripts/docker-bootstrap.mjs", {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, DATABASE_URL: localUrl },
  });
} catch (e) {
  console.error("✗ ساخت مدیر اولیه شکست خورد:", e.message);
  process.exit(1);
}

// ---------- ۵) زنجیره بک‌فیل‌های داده پایه ----------
// شکست هر بک‌فیل بیلد را متوقف نمی‌کند (داده مهم‌تر از بیلد نیست) اما
// با صدای بلند لاگ می‌شود تا در لاگ دیپلوی دیده شود.
let failed = 0;
for (const bf of BACKFILLS) {
  const p = path.join(root, "scripts", bf);
  if (!existsSync(p)) continue;
  try {
    execSync(`npx --yes tsx@4.19.2 scripts/${bf}`, {
      cwd: root,
      stdio: "inherit",
      env: { ...process.env, DATABASE_URL: localUrl },
    });
  } catch (e) {
    failed++;
    console.warn(`⚠ بک‌فیل ${bf} ناموفق بود (ادامه می‌دهیم): ${String(e.message || "").split("\n")[0]}`);
  }
}
if (failed > 0) {
  console.warn(`⚠ جمع‌بندی: ${failed} بک‌فیل ناموفق — داده پایه ممکن است ناقص باشد (لاگ بالا را ببینید)`);
} else {
  console.log("✓ داده پایه (تعطیلات ۱۴۰۵، قالب‌نامه‌ها، اطلاعیه نسخه و…) بارگذاری شد");
}

// ---------- ۶) نسخهٔ دورریز در مسیر پنل (برای next build) ----------
const runtimePath = runtimeUrl.replace(/^file:/i, "");
if (path.resolve(runtimePath) !== path.resolve(dbFile)) {
  try {
    mkdirSync(path.dirname(runtimePath), { recursive: true });
    copyFileSync(dbFile, runtimePath);
    console.log(`▪ نسخهٔ دورریز دیتابیس در ${runtimePath} ساخته شد (فقط برای بیلد — در runtime با والیوم mount می‌شود)`);
  } catch (e) {
    console.warn(`⚠ ساخت نسخهٔ دورریز در ${runtimePath} ممکن نشد (${String(e.message || e).split("\n")[0]}) — اگر بیلد به دیتابیس نیاز نداشته باشد مشکلی نیست`);
  }
}

console.log(`▪ HRMS ${pkg.version} — آمادهٔ بیلد Nixpacks (ورود پیش‌فرض: admin / admin123)`);

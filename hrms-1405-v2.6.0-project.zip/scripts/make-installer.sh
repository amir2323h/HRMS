#!/usr/bin/env bash
# ================================================================
# سازنده بسته نصب — سورس پروژه را داخل یک اسکریپت تک‌فایل می‌گنجاند
# خروجی: download/install-hrms.sh (اجرا روی VPS: sudo bash install-hrms.sh)
# ================================================================
set -euo pipefail
cd "$(dirname "$0")/.."   # ریشه پروژه

OUT_DIR="download"
OUT="${OUT_DIR}/install-hrms.sh"
TMP_TAR="$(mktemp /tmp/hrms-src-XXXXXX.tar.gz)"
TMP_B64="$(mktemp /tmp/hrms-payload-XXXXXX.b64)"

trap 'rm -f "$TMP_TAR" "$TMP_B64"' EXIT

# ---------- ۱) آرشیو سورس (فهرست سفید — فقط فایل‌های لازم برای اجرا/بیلد) ----------
info() { echo "◈ $*"; }
info "ساخت آرشیو سورس…"
# فقط آنچه برای نصب/بیلد لازم است: src، public، prisma، بک‌فیل نقش‌ها و فایل‌های ریشه
WHITELIST=(
  ./src
  ./public
  ./prisma
  ./scripts/backfill-v4.ts
  ./scripts/backfill-v5.ts
  ./scripts/backfill-v8.ts
  ./scripts/backfill-v9.ts
  ./scripts/backfill-v10.ts
  ./scripts/purge-demo.ts
  ./package.json
  ./bun.lock
  ./next.config.ts
  ./tsconfig.json
  ./tailwind.config.ts
  ./postcss.config.mjs
  ./components.json
  ./next-env.d.ts
)
for item in "${WHITELIST[@]}"; do
  [ -e "$item" ] || { echo "✗ مورد فهرست سفید یافت نشد: $item"; exit 1; }
done
tar -czf "$TMP_TAR" "${WHITELIST[@]}"

# ---------- ۲) کدگذاری base64 ----------
info "کدگذاری بسته…"
base64 -w 76 "$TMP_TAR" > "$TMP_B64"
SRC_KB=$(( $(du -k "$TMP_TAR" | cut -f1) ))
B64_KB=$(( $(du -k "$TMP_B64" | cut -f1) ))
info "حجم سورس فشرده: ${SRC_KB}KB → پایه۶۴: ${B64_KB}KB"

# ---------- ۳) ترکیب قالب نصب‌کننده + مارکر + پی‌لود ----------
mkdir -p "$OUT_DIR"
TEMPLATE="scripts/installer-template.sh"
[ -f "$TEMPLATE" ] || { echo "✗ قالب نصب‌کننده یافت نشد: $TEMPLATE"; exit 1; }

{
  cat "$TEMPLATE"
  echo ""
  echo "# ================== پی‌لود بسته (سورس، base64) =================="
  echo "# این بخش توسط اسکریپت استخراج می‌شود — دستکاری نکنید"
  echo "__PAYLOAD_B64__"
  cat "$TMP_B64"
} > "$OUT"

chmod +x "$OUT"

# ---------- ۴) راستی‌آزمایی: سینتکس + مارکر + قابلیت استخراج ----------
bash -n "$OUT" || { echo "✗ خطای سینتکس در خروجی"; exit 1; }
grep -q '^__PAYLOAD_B64__$' "$OUT" || { echo "✗ مارکر پی‌لود گم شده"; exit 1; }
PROBE="$(mktemp -d)"
awk 'f{print} /^__PAYLOAD_B64__$/{f=1}' "$OUT" | base64 -d | tar -xzf - -C "$PROBE" 2>/dev/null
[ -f "$PROBE/package.json" ] && [ -f "$PROBE/prisma/schema.prisma" ] && [ -f "$PROBE/src/app/page.tsx" ] \
  || { echo "✗ راستی‌آزمایی استخراج ناموفق"; rm -rf "$PROBE"; exit 1; }
COUNT=$(find "$PROBE" -type f | wc -l)
rm -rf "$PROBE"

FINAL_KB=$(( $(du -k "$OUT" | cut -f1) ))
echo ""
echo "✓ بسته نصب تک‌فایل ساخته شد: $OUT"
echo "  حجم نهایی: ${FINAL_KB}KB | فایل‌های سورس: ${COUNT}"
echo ""
echo "  نحوه استقرار روی VPS:"
echo "    1) scp download/install-hrms.sh root@SERVER:/root/"
echo "    2) ssh root@SERVER 'bash /root/install-hrms.sh'"
echo "    (یا: curl اگر آپلود کردید — سپس: sudo bash install-hrms.sh)"

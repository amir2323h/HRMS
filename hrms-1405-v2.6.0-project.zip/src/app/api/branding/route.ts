import { NextRequest } from "next/server";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getBranding, saveBranding, saveCompanyName, getCompanyInfo, defaultFooterText, getDemoMode, saveDemoMode, type Branding } from "@/lib/settings";

const MAX_IMAGE_BYTES = 200 * 1024; // ۲۰۰ کیلوبایت (پس از base64)
const ALLOWED_MIME = ["image/png", "image/jpeg", "image/svg+xml", "image/x-icon", "image/vnd.microsoft.icon", "image/webp"];

function validateDataUrl(dataUrl: string, what: string): string | null {
  const m = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!m) return `فرمت ${what} نامعتبر است (باید data URL باشد).`;
  const mime = m[1];
  if (!ALLOWED_MIME.includes(mime)) return `فرمت ${what} پشتیبانی نمی‌شود (PNG، JPG، SVG، WebP یا ICO).`;
  const bytes = Math.floor((m[2].length * 3) / 4);
  if (bytes > MAX_IMAGE_BYTES) return `حجم ${what} نباید بیش از ۲۰۰ کیلوبایت باشد.`;
  return null;
}

/** برندینگ عمومی است — صفحه ورود (بدون نشست) هم به آن نیاز دارد */
export async function GET() {
  return handle(async () => {
    const branding = await getBranding();
    // اطلاعات شرکت برای سربرگ نامه‌ها (شناسه ملی/نشانی) — عمومی مثل خود سربرگ چاپی
    const company = await getCompanyInfo();
    // حالت دمو — فقط پرچم بولین؛ حساب‌های نمونه صفحه ورود مشروط به آن نمایش داده می‌شوند
    const demoMode = await getDemoMode();
    // متن مؤثر فوتر (خالی = پیش‌فرض) — برای نمایش بی‌دردسر سمت کلاینت
    return {
      branding: {
        ...branding,
        footerText: branding.footerText || defaultFooterText(),
        demoMode,
        companyNationalId: company.nationalId || "",
        companyAddress: company.address || "",
        companyPhone: company.phone || "",
        companyMobile: company.mobile || "",
        companyWebsite: company.website || "",
        companyEmail: company.email || "",
      },
    };
  });
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:manage");
    const b = await req.json();
    const before = await getBranding();

    const patch: Partial<Branding> = {};
    if (b.title !== undefined) {
      const t = String(b.title).trim();
      if (!t) return Response.json({ error: "عنوان نمی‌تواند خالی باشد." }, { status: 400 });
      if (t.length > 80) return Response.json({ error: "عنوان حداکثر ۸۰ نویسه است." }, { status: 400 });
      patch.title = t;
    }
    if (b.subtitle !== undefined) patch.subtitle = String(b.subtitle).trim().slice(0, 120);
    if (b.footerText !== undefined) patch.footerText = String(b.footerText).trim().slice(0, 300);
    if (b.logo !== undefined) {
      const v = String(b.logo || "");
      if (v) {
        const err = validateDataUrl(v, "لوگو");
        if (err) return Response.json({ error: err }, { status: 400 });
      }
      patch.logo = v;
    }
    if (b.favicon !== undefined) {
      const v = String(b.favicon || "");
      if (v) {
        const err = validateDataUrl(v, "فاوآیکون");
        if (err) return Response.json({ error: err }, { status: 400 });
      }
      patch.favicon = v;
    }
    // نام شرکت — منبع حقیقت «اطلاعات شرکت» (فیش حقوقی/نامه‌ها/سایدبار همه از آن می‌خوانند)
    let companyName: string | undefined;
    if (b.companyName !== undefined) {
      companyName = String(b.companyName).trim().slice(0, 120);
      if (!companyName) return Response.json({ error: "نام شرکت نمی‌تواند خالی باشد." }, { status: 400 });
      await saveCompanyName(companyName);
    }

    // حالت دمو — نمایش حساب‌های نمونه در صفحه ورود
    let demoMode: boolean | undefined;
    if (b.demoMode !== undefined) {
      demoMode = !!b.demoMode;
      await saveDemoMode(demoMode);
    }

    await saveBranding(patch);
    await audit(
      session,
      "UPDATE",
      "SETTINGS",
      "branding",
      "به‌روزرسانی برندینگ سامانه (عنوان/نام شرکت/لوگو/فاوآیکون/فوتر/حالت دمو)",
      { title: before.title, companyName: before.companyName, hasLogo: !!before.logo, hasFavicon: !!before.favicon, footerText: before.footerText },
      {
        title: patch.title ?? before.title,
        companyName: companyName ?? before.companyName,
        hasLogo: patch.logo !== undefined ? !!patch.logo : !!before.logo,
        hasFavicon: patch.favicon !== undefined ? !!patch.favicon : !!before.favicon,
        footerText: patch.footerText ?? before.footerText,
      }
    );
    const branding = await getBranding();
    return { branding: { ...branding, footerText: branding.footerText || defaultFooterText(), demoMode: demoMode ?? (await getDemoMode()) } };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import { normalizeAttendanceInput, aggregateAttendance, defaultStatusForDate, monthDaysJ, timeJToMinutes, ATTENDANCE_STATUS_LABELS } from "@/lib/attendance";
import { todayJalaliStr, parseJalali } from "@/lib/jalali";

/** حضور و غیب و تردد
 *  GET  ?year=&month=&employeeId=  → کارکرد ماهانه + رکوردهای روزانه
 *       ?summary=1&year=&month=    → فقط تجمیع همه کارکنان (فقط برای مجوز دیدن)
 *  POST (attendance:manage)        → ثبت/به‌روزرسانی رکورد روزانه (upsert)
 *       mode=bulk                  → ثبت گروهی ماه (روزهای کاری پیش‌فرض)
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const url = new URL(req.url);
    const year = +(url.searchParams.get("year") || 0);
    const month = +(url.searchParams.get("month") || 0);
    const employeeId = url.searchParams.get("employeeId") || "";
    const canSeeAll = session.perms?.includes("*") || session.perms?.includes("attendance:view");

    // کارمند عادی فقط کارکرد خودش را می‌بیند (پرتال)
    const scopeEmployeeId = canSeeAll ? employeeId : session.employeeId || "";

    const today = todayJalaliStr();
    let y = year;
    let m = month;
    if (!y || !m) {
      const t = parseJalali(today)!;
      y = t.jy;
      m = t.jm;
    }
    const monthPrefix = `${y}/${String(m).padStart(2, "0")}/`;

    // رکوردهای ماه
    const where: Record<string, unknown> = { dateJ: { startsWith: monthPrefix } };
    if (scopeEmployeeId) where.employeeId = scopeEmployeeId;
    const records = await db.attendanceRecord.findMany({
      where,
      orderBy: { dateJ: "asc" },
      include: { employee: { select: { id: true, firstName: true, lastName: true, personnelCode: true, employmentType: true, shiftPattern: true, jobTitle: true } } },
    });

    // تجمیع به تفکیک کارمند
    const byEmp = new Map<string, { employee: { id: string; fullName: string; personnelCode: string; employmentType: string; shiftPattern: string; jobTitle: string }; records: typeof records }>();
    for (const r of records) {
      const key = r.employeeId;
      if (!byEmp.has(key)) {
        byEmp.set(key, {
          employee: {
            id: r.employee.id,
            fullName: `${r.employee.firstName} ${r.employee.lastName}`.trim(),
            personnelCode: r.employee.personnelCode,
            employmentType: r.employee.employmentType || "DAILY",
            shiftPattern: r.employee.shiftPattern || "",
            jobTitle: r.employee.jobTitle || "",
          },
          records: [],
        });
      }
      byEmp.get(key)!.records.push(r);
    }
    const summaries = [...byEmp.values()].map((v) => ({
      employee: v.employee,
      ...aggregateAttendance(v.records.map((r) => ({ employeeId: r.employeeId, status: r.status, workHours: r.workHours, overtimeHours: r.overtimeHours, nightHours: r.nightHours, fridayHours: r.fridayHours, holidayHours: r.holidayHours }))),
    }));

    // روزهای ماه + وضعیت جمعه
    const days = monthDaysJ(y, m).map((d) => ({ dateJ: d.dateJ, day: d.day, isFriday: d.isFriday }));
    const params = await getLegalParams();

    // فهرست سبک کارکنان فعال (برای انتخاب کارمند در نمای حضور — بدون نیاز به مجوز کارکنان)
    const activeEmployees = canSeeAll
      ? (await db.employee.findMany({
          where: { status: "ACTIVE" },
          select: { id: true, firstName: true, lastName: true, personnelCode: true, employmentType: true, shiftPattern: true, jobTitle: true },
          orderBy: { personnelCode: "asc" },
        })).map((e) => ({
          id: e.id,
          fullName: `${e.firstName} ${e.lastName}`.trim(),
          personnelCode: e.personnelCode,
          employmentType: e.employmentType || "DAILY",
          shiftPattern: e.shiftPattern || "",
          jobTitle: e.jobTitle || "",
        }))
      : [];

    // رکوردهای روزانه فقط برای یک کارمند مشخص (جزئیات تردد)
    let daily: unknown[] = [];
    if (scopeEmployeeId) {
      daily = records
        .filter((r) => r.employeeId === scopeEmployeeId)
        .map((r) => ({
          id: r.id,
          dateJ: r.dateJ,
          checkInJ: r.checkInJ,
          checkOutJ: r.checkOutJ,
          status: r.status,
          workHours: r.workHours,
          overtimeHours: r.overtimeHours,
          nightHours: r.nightHours,
          fridayHours: r.fridayHours,
          holidayHours: r.holidayHours,
          note: r.note,
          updatedAt: r.updatedAt,
        }));
    }

    return {
      year: y,
      month: m,
      dailyStandardHours: Math.round((params.monthlyWorkHours / 30) * 100) / 100,
      days,
      today,
      summaries,
      employees: activeEmployees,
      records: daily,
      selfScope: !canSeeAll,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "attendance:manage");
    const b = await req.json();
    const params = await getLegalParams();
    const std = params.monthlyWorkHours / 30;

    // ---------- ثبت گروهی کارکرد ماه ----------
    if (b.mode === "bulk") {
      const employeeId = String(b.employeeId || "");
      const year = +b.year;
      const month = +b.month;
      if (!employeeId || !year || !month) return Response.json({ error: "کارمند و ماه الزامی است." }, { status: 400 });
      const emp = await db.employee.findUnique({ where: { id: employeeId } });
      if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });

      const checkIn = String(b.checkInJ || "08:00");
      const checkOut = String(b.checkOutJ || "17:00");
      if (timeJToMinutes(checkIn) === null || timeJToMinutes(checkOut) === null) {
        return Response.json({ error: "ساعت ورود/خروج نامعتبر است." }, { status: 400 });
      }
      const skipFridays = b.skipFridays !== false; // پیش‌فرض: جمعه‌ها تعطیل

      const days = monthDaysJ(year, month);
      let created = 0;
      for (const d of days) {
        const exists = await db.attendanceRecord.findUnique({ where: { employeeId_dateJ: { employeeId, dateJ: d.dateJ } } });
        if (exists) continue;
        if (skipFridays && d.isFriday) continue;
        const status = defaultStatusForDate(d.dateJ);
        const buckets = normalizeAttendanceInput({
          employeeId, dateJ: d.dateJ, checkInJ: checkIn, checkOutJ: checkOut,
          status, dailyStandardHours: std,
        });
        if (!buckets.ok) continue;
        await db.attendanceRecord.create({ data: { ...buckets.data, createdBy: session.fullName } });
        created += 1;
      }
      await audit(session, "CREATE", "ATTENDANCE", employeeId, `ثبت گروهی کارکرد ${month}/${year} برای ${emp.personnelCode} (${created} روز)`);
      return { created };
    }

    // ---------- ثبت/ویرایش تک‌رکورد (upsert) ----------
    const norm = normalizeAttendanceInput({ ...b, dailyStandardHours: std });
    if (!norm.ok) return Response.json({ error: norm.error }, { status: 400 });
    const data = norm.data;
    const emp = await db.employee.findUnique({ where: { id: data.employeeId }, select: { personnelCode: true, firstName: true, lastName: true } });
    if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });

    const row = await db.attendanceRecord.upsert({
      where: { employeeId_dateJ: { employeeId: data.employeeId, dateJ: data.dateJ } },
      update: {
        checkInJ: data.checkInJ,
        checkOutJ: data.checkOutJ,
        status: data.status,
        workHours: data.workHours,
        overtimeHours: data.overtimeHours,
        nightHours: data.nightHours,
        fridayHours: data.fridayHours,
        holidayHours: data.holidayHours,
        note: data.note,
      },
      create: { ...data, createdBy: session.fullName },
    });
    await audit(
      session,
      "UPDATE",
      "ATTENDANCE",
      row.id,
      `تردد ${emp.firstName} ${emp.lastName} (${emp.personnelCode}) در ${data.dateJ}: ${ATTENDANCE_STATUS_LABELS[data.status] || data.status}${data.checkInJ ? ` ${data.checkInJ}–${data.checkOutJ}` : ""}`
    );
    return { record: row };
  });
}

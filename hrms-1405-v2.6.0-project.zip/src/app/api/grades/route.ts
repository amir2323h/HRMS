import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeGrade } from "@/lib/serializers";

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "grades:view");
    const grades = await db.jobGrade.findMany({ orderBy: { level: "asc" } });
    const counts = await db.employee.groupBy({
      by: ["jobGradeId"],
      where: { status: "ACTIVE" },
      _count: { id: true },
    });
    const countMap: Record<string, number> = {};
    for (const c of counts) if (c.jobGradeId) countMap[c.jobGradeId] = c._count.id;
    return { grades: grades.map((g) => serializeGrade(g, countMap[g.id] || 0)) };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "grades:manage");
    const b = await req.json();
    if (!b.title?.trim() || !b.level) return Response.json({ error: "عنوان و سطح الزامی است." }, { status: 400 });
    const dup = await db.jobGrade.findUnique({ where: { level: +b.level } });
    if (dup) return Response.json({ error: "این سطح قبلاً تعریف شده است." }, { status: 400 });
    const grade = await db.jobGrade.create({
      data: {
        level: +b.level,
        code: String(b.code || `L${b.level}`),
        title: String(b.title).trim(),
        description: String(b.description || ""),
        minBaseSalary: BigInt(Math.round(+b.minBaseSalary || 0)),
        maxBaseSalary: BigInt(Math.round(+b.maxBaseSalary || 0)),
        seniorityBase: BigInt(Math.round(+b.seniorityBase || 0)),
        attraction: BigInt(Math.round(+b.attraction || 0)),
      },
    });
    await audit(session, "CREATE", "GRADE", grade.id, `ایجاد سطح ${b.level}: ${b.title}`);
    return { grade: serializeGrade(grade, 0) };
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "grades:manage");
    const b = await req.json();
    if (!b.id) return Response.json({ error: "شناسه الزامی است." }, { status: 400 });
    const before = await db.jobGrade.findUnique({ where: { id: b.id } });
    if (!before) return Response.json({ error: "سطح یافت نشد." }, { status: 404 });
    const data: Record<string, unknown> = {};
    for (const f of ["title", "code", "description"]) if (b[f] !== undefined) data[f] = String(b[f]).trim();
    for (const f of ["minBaseSalary", "maxBaseSalary", "seniorityBase", "attraction"]) {
      if (b[f] !== undefined) data[f] = BigInt(Math.round(+b[f] || 0));
    }
    await db.jobGrade.update({ where: { id: b.id }, data });
    const after = await db.jobGrade.findUnique({ where: { id: b.id } });
    await audit(
      session,
      "UPDATE",
      "GRADE",
      b.id,
      `ویرایش سطح ${after?.level} (${after?.title})`,
      before ? { min: Number(before.minBaseSalary), max: Number(before.maxBaseSalary), sen: Number(before.seniorityBase), att: Number(before.attraction) } : null,
      { min: Number(after?.minBaseSalary), max: Number(after?.maxBaseSalary), sen: Number(after?.seniorityBase), att: Number(after?.attraction) }
    );
    return { grade: serializeGrade(after!, 0) };
  });
}

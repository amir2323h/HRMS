import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { hasPerm } from "@/lib/permissions";

/** شمارش سبک نامه‌ها — نشان منو/داشبورد (letters:approve یا letters:manual)
 *  pending: در انتظار تأیید | issued: صادره (تأییدشده با امضای دیجیتال) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    if (!(hasPerm(session.perms, "letters:approve") || hasPerm(session.perms, "letters:manual"))) {
      return Response.json({ error: "دسترسی ندارید." }, { status: 403 });
    }
    const [pending, issued] = await Promise.all([
      db.letterRequest.count({ where: { status: "PENDING" } }),
      db.letterRequest.count({ where: { status: "APPROVED" } }),
    ]);
    return { pending, issued };
  });
}

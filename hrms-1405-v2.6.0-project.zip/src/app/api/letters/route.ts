import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getCompanyInfo } from "@/lib/settings";
import { parseLetterFields, validateLetterFields, buildLetterVars, renderLetter, nextLetterNumber, resolveLetterFlowSnapshot, parseLetterFlowSteps, parseLetterTrail } from "@/lib/letters";
import { hasPerm } from "@/lib/permissions";

/** درخواست‌نامه‌ها — GET (کاربر: خودش | مجوز دیدن همه) / POST (letters:create — قالب‌محور) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const canSeeAll =
      hasPerm(session.perms, "letters:approve") ||
      hasPerm(session.perms, "letters:templates") ||
      hasPerm(session.perms, "letters:manual");
    const url = new URL(req.url);
    const status = url.searchParams.get("status");
    const where: Record<string, unknown> = {};
    if (!canSeeAll) where.employeeId = session.employeeId || "none";
    if (status) where.status = status;
    const rows = await db.letterRequest.findMany({ where, orderBy: { createdAt: "desc" }, take: 500 });
    return {
      letters: rows.map((r) => ({
        id: r.id,
        number: r.number,
        source: r.source,
        category: r.category,
        templateTitle: r.templateTitle,
        employeeId: r.employeeId,
        employeeName: r.employeeName,
        personnelCode: r.personnelCode,
        department: r.department,
        recipient: r.recipient,
        title: r.title,
        body: r.body,
        bodyHtml: r.bodyHtml,
        status: r.status,
        decidedBy: r.decidedBy,
        decidedAt: r.decidedAt,
        decisionNote: r.decisionNote,
        signatureCode: r.signatureCode,
        signerName: r.signerName,
        signerTitle: r.signerTitle,
        items: JSON.parse(r.itemsJson || "[]"),
        fields: JSON.parse(r.fieldsJson || "{}"),
        pendingStep: r.pendingStep,
        flowSteps: parseLetterFlowSteps(r.flowSnapshot),
        approvalTrail: parseLetterTrail(r.approvalTrail),
        createdBy: r.createdBy,
        createdAt: r.createdAt,
      })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "letters:create");
    const b = await req.json();
    const templateId = String(b.templateId || "");
    const employeeId = session.employeeId ? String(session.employeeId) : String(b.employeeId || "");
    if (!templateId) return Response.json({ error: "قالب نامه الزامی است." }, { status: 400 });
    if (!employeeId) return Response.json({ error: "حساب شما به پرونده کارمندی متصل نیست." }, { status: 400 });

    const tpl = await db.letterTemplate.findUnique({ where: { id: templateId } });
    if (!tpl || !tpl.isActive) return Response.json({ error: "قالب نامه یافت نشد یا غیرفعال است." }, { status: 404 });
    const emp = await db.employee.findUnique({
      where: { id: employeeId },
      include: { jobGrade: { select: { level: true, title: true } }, departments: { include: { department: { select: { name: true } } } } },
    });
    if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });

    const fields = parseLetterFields(tpl.fieldsJson);
    const values: Record<string, string> = {};
    for (const k of Object.keys(b.values || {})) values[k] = String((b.values || {})[k] ?? "");
    const errors = validateLetterFields(fields, values);
    if (errors.length) return Response.json({ error: errors.join(" ") }, { status: 400 });

    const company = await getCompanyInfo();
    const number = await nextLetterNumber(tpl.category);
    const vars = buildLetterVars({
      employee: emp,
      company,
      fields,
      values,
      letterNumber: number,
    });
    const body = renderLetter(tpl.bodyTemplate, vars);
    const deptName = emp.departments[0]?.department?.name || "—";

    // روال تأیید داینامیک دسته این نامه — اسنپ‌شات ذخیره می‌شود تا ویرایش روال
    // بعدی روی نامه‌های در جریان اثر نگذارد (خالی = تک‌مرحله‌ای با نقش قالب)
    const flowSteps = await resolveLetterFlowSnapshot(tpl.category);

    const row = await db.letterRequest.create({
      data: {
        number,
        source: "REQUEST",
        category: tpl.category,
        templateId: tpl.id,
        templateTitle: tpl.title,
        templateVersion: tpl.version,
        employeeId: emp.id,
        employeeName: `${emp.firstName} ${emp.lastName}`.trim(),
        personnelCode: emp.personnelCode,
        department: deptName,
        title: tpl.title,
        body,
        fieldsJson: JSON.stringify(values),
        status: "PENDING",
        pendingStep: flowSteps.length ? 1 : 0,
        flowSnapshot: JSON.stringify(flowSteps),
        approvalTrail: "[]",
        createdBy: session.fullName,
      },
    });
    await audit(
      session,
      "CREATE",
      "LETTER_REQUEST",
      row.id,
      `ثبت درخواست‌نامه «${tpl.title}» (${number}) توسط ${row.employeeName}` +
        (flowSteps.length ? ` — روال تأیید ${flowSteps.length} مرحله‌ای` : "")
    );
    return { letter: { ...row, fields: values, flowSteps, approvalTrail: [] } };
  });
}

"use client";

// ============================================================
// حضور و غیب — تردد روزانه + کارکرد ماهانه پرسنل
// مبنای محاسبه فیش حقوقی (اضافه‌کاری/شب‌کاری/جمعه‌کاری/تعطیل‌کاری/غیبت)
// ============================================================
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { CalendarClock, Users, Plus, Trash2, Pencil, Wand2, Info } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { EMPLOYMENT_TYPE_LABELS, SHIFT_PATTERN_LABELS } from "@/lib/format";
import { toFaDigits, formatDateJ, todayJalaliStr, parseJalali, formatMonthJ } from "@/lib/jalali";
import { JalaliDatePicker } from "../jalali-datepicker";
import { ATTENDANCE_STATUS_LABELS, ATTENDANCE_STATUS_BADGE, ATTENDANCE_STATUSES, defaultStatusForDate } from "@/lib/attendance";
import type { SessionInfo } from "../app-root";

interface AttendanceRecordRow {
  id: string;
  dateJ: string;
  checkInJ: string;
  checkOutJ: string;
  status: string;
  workHours: number;
  overtimeHours: number;
  nightHours: number;
  fridayHours: number;
  holidayHours: number;
  note: string;
  updatedAt?: string;
}

interface SummaryRow {
  employee: { id: string; fullName: string; personnelCode: string; employmentType: string; shiftPattern: string; jobTitle: string };
  records: number;
  presentDays: number;
  absentDays: number;
  leaveDays: number;
  missionDays: number;
  fridayWorkDays: number;
  holidayWorkDays: number;
  workHours: number;
  overtimeHours: number;
  nightHours: number;
  fridayHours: number;
  holidayHours: number;
}

interface EmployeeLite {
  id: string;
  fullName: string;
  personnelCode: string;
  employmentType: string;
  shiftPattern: string;
  jobTitle: string;
}

interface AttendanceData {
  year: number;
  month: number;
  dailyStandardHours: number;
  days: { dateJ: string; day: number; isFriday: boolean }[];
  today: string;
  summaries: SummaryRow[];
  employees: EmployeeLite[];
  records: AttendanceRecordRow[];
  selfScope: boolean;
}

const MONTHS = Array.from({ length: 12 }, (_, i) => i + 1);
const YEARS = (() => {
  const t = parseJalali(todayJalaliStr())!;
  return [t.jy - 1, t.jy, t.jy + 1];
})();

export function AttendanceView({ user, canManage }: { user: SessionInfo; canManage: boolean }) {
  const { toast } = useToast();
  const today = parseJalali(todayJalaliStr())!;
  const [year, setYear] = useState(today.jy);
  const [month, setMonth] = useState(today.jm);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>("");
  const [editRecord, setEditRecord] = useState<Partial<AttendanceRecordRow> & { manualBuckets?: boolean } | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);

  // خلاصه ماهانه همه کارکنان (بدون employeeId) — و با انتخاب کارمند، رکوردهای روزانه
  const summaryApi = useApi<AttendanceData>(`/api/attendance?year=${year}&month=${month}`, [year, month]);
  const detailApi = useApi<AttendanceData>(
    selectedEmployeeId ? `/api/attendance?year=${year}&month=${month}&employeeId=${selectedEmployeeId}` : null,
    [selectedEmployeeId, year, month]
  );

  const data = summaryApi.data;
  const summaries = data?.summaries || [];
  const employees = data?.employees || [];
  const summaryById = useMemo(() => new Map(summaries.map((s) => [s.employee.id, s])), [summaries]);
  // فهرست کامل کارکنان + کارکرد (حتی بدون رکورد — برای شروع ثبت)
  const allRows = useMemo(() => {
    return employees.map((e) => ({ employee: e, summary: summaryById.get(e.id) || null }));
  }, [employees, summaryById]);

  const detailRecords = detailApi.data?.records || [];
  const recordByDate = useMemo(() => new Map(detailRecords.map((r) => [r.dateJ, r])), [detailRecords]);
  const days = detailApi.data?.days || data?.days || [];
  const selectedEmployee = employees.find((e) => e.id === selectedEmployeeId) || null;
  const stdHours = data?.dailyStandardHours || 7.33;

  async function saveRecord() {
    if (!editRecord || !selectedEmployeeId) return;
    const body = {
      employeeId: selectedEmployeeId,
      dateJ: editRecord.dateJ || "",
      checkInJ: editRecord.checkInJ || "",
      checkOutJ: editRecord.checkOutJ || "",
      status: editRecord.status || "PRESENT",
      note: editRecord.note || "",
      manualBuckets: editRecord.manualBuckets === true,
      workHours: editRecord.workHours || 0,
      overtimeHours: editRecord.overtimeHours || 0,
      nightHours: editRecord.nightHours || 0,
      fridayHours: editRecord.fridayHours || 0,
      holidayHours: editRecord.holidayHours || 0,
    };
    try {
      await api("/api/attendance", { method: "POST", json: body });
      setEditRecord(null);
      await Promise.all([summaryApi.refetch(), detailApi.refetch?.()]);
      toast({ title: "تردد ذخیره شد", description: `${body.dateJ} — سطل‌های ساعت ${body.manualBuckets ? "دستی" : "خودکار"} محاسبه شد.` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function deleteRecord(id: string) {
    try {
      await api(`/api/attendance/${id}`, { method: "DELETE" });
      await Promise.all([summaryApi.refetch(), detailApi.refetch?.()]);
      toast({ title: "رکورد حذف شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  const totalOvertime = summaries.reduce((a, s) => a + s.overtimeHours, 0);
  const totalNight = summaries.reduce((a, s) => a + s.nightHours, 0);
  const totalFriday = summaries.reduce((a, s) => a + s.fridayHours, 0);
  const totalHoliday = summaries.reduce((a, s) => a + s.holidayHours, 0);
  const totalAbsent = summaries.reduce((a, s) => a + s.absentDays, 0);

  if (summaryApi.loading && !data) {
    return <div className="space-y-3"><Skeleton className="h-24 rounded-2xl" /><Skeleton className="h-96 rounded-2xl" /></div>;
  }

  return (
    <div className="space-y-4">
      {/* انتخاب ماه + راهنما */}
      <Card className="rounded-2xl">
        <CardContent className="p-4 flex flex-wrap items-end gap-3">
          <div className="space-y-1.5">
            <Label className="text-xs">ماه کارکرد</Label>
            <div className="flex items-center gap-2">
              <Select value={String(month)} onValueChange={(v) => setMonth(+v)}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {MONTHS.map((m) => (
                    <SelectItem key={m} value={String(m)}>{formatMonthJ(year, m)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={String(year)} onValueChange={(v) => setYear(+v)}>
                <SelectTrigger className="w-28"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {YEARS.map((y) => <SelectItem key={y} value={String(y)}>{toFaDigits(y)}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex flex-wrap gap-2 mr-auto">
            <StatChip label="اضافه‌کاری" value={`${toFaDigits(totalOvertime)} ساعت`} tone="text-teal-700 bg-teal-50" />
            <StatChip label="شب‌کاری" value={`${toFaDigits(totalNight)} ساعت`} tone="text-indigo-700 bg-indigo-50" />
            <StatChip label="جمعه‌کاری" value={`${toFaDigits(totalFriday)} ساعت`} tone="text-cyan-700 bg-cyan-50" />
            <StatChip label="تعطیل‌کاری" value={`${toFaDigits(totalHoliday)} ساعت`} tone="text-amber-700 bg-amber-50" />
            <StatChip label="غیبت" value={`${toFaDigits(totalAbsent)} روز`} tone="text-rose-700 bg-rose-50" />
          </div>
          <p className="w-full text-[11px] text-muted-foreground leading-5 flex items-start gap-1.5">
            <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
            کارکرد ثبت‌شده این ماه، هنگام <b>محاسبه لیست حقوق همین دوره</b> به‌صورت خودکار مبنای اضافه‌کاری، شب‌کاری (۳۵٪)، جمعه‌کاری و تعطیل‌کاری (۴۰٪) و کسر مزد غیبت قرار می‌گیرد — شیفت‌بندی (۲۲.۵٪/۴۵٪) از پرونده کارمند خوانده می‌شود.
          </p>
        </CardContent>
      </Card>

      <Tabs defaultValue="monthly" dir="rtl">
        <TabsList className="flex-wrap">
          <TabsTrigger value="monthly" className="gap-1.5"><Users className="w-4 h-4" /> کارکرد ماهانه پرسنل</TabsTrigger>
          <TabsTrigger value="daily" className="gap-1.5"><CalendarClock className="w-4 h-4" /> تردد روزانه</TabsTrigger>
        </TabsList>

        {/* ---------- کارکرد ماهانه ---------- */}
        <TabsContent value="monthly" className="mt-3">
          <Card className="rounded-2xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2 flex-wrap">
                کارکرد {formatMonthJ(year, month)}
                <Badge variant="outline">{toFaDigits(summaries.length)} نفر دارای رکورد</Badge>
                {canManage && (
                  <Button size="sm" className="mr-auto gap-1.5 bg-teal-600 hover:bg-teal-700" onClick={() => setBulkOpen(true)}>
                    <Wand2 className="w-3.5 h-3.5" /> ثبت گروهی کارکرد ماه
                  </Button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-slate-50 text-[11px] text-slate-600">
                      <th className="py-2.5 px-3 text-right font-medium">کارمند</th>
                      <th className="py-2.5 px-2 text-center font-medium">نوع اشتغال</th>
                      <th className="py-2.5 px-2 text-center font-medium">روز حضور</th>
                      <th className="py-2.5 px-2 text-center font-medium">غیبت</th>
                      <th className="py-2.5 px-2 text-center font-medium">مرخصی</th>
                      <th className="py-2.5 px-2 text-center font-medium">کارکرد (ساعت)</th>
                      <th className="py-2.5 px-2 text-center font-medium">اضافه‌کاری</th>
                      <th className="py-2.5 px-2 text-center font-medium">شب‌کاری</th>
                      <th className="py-2.5 px-2 text-center font-medium">جمعه/تعطیل</th>
                      <th className="py-2.5 px-2 text-center font-medium"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {allRows.length === 0 && (
                      <tr><td colSpan={10} className="py-10 text-center text-muted-foreground text-sm">کارمند فعالی برای نمایش وجود ندارد</td></tr>
                    )}
                    {allRows.map(({ employee: e, summary: s }) => (
                      <tr key={e.id} className="border-b last:border-0 hover:bg-slate-50/60">
                        <td className="py-2.5 px-3">
                          <p className="font-medium">{e.fullName}</p>
                          <p className="text-[10px] text-muted-foreground font-mono" dir="ltr">{e.personnelCode}</p>
                        </td>
                        <td className="py-2.5 px-2 text-center">
                          <Badge className={e.employmentType === "SHIFT" ? "bg-violet-100 text-violet-700 hover:bg-violet-100" : "bg-slate-100 text-slate-600 hover:bg-slate-100"} title={e.shiftPattern ? SHIFT_PATTERN_LABELS[e.shiftPattern] : ""}>
                            {EMPLOYMENT_TYPE_LABELS[e.employmentType] || e.employmentType}
                          </Badge>
                        </td>
                        <td className="py-2.5 px-2 text-center tabular-nums">{s ? toFaDigits(s.presentDays + s.fridayWorkDays + s.holidayWorkDays) : "—"}</td>
                        <td className="py-2.5 px-2 text-center tabular-nums">{s && s.absentDays > 0 ? <span className="text-rose-600 font-bold">{toFaDigits(s.absentDays)}</span> : s ? "۰" : "—"}</td>
                        <td className="py-2.5 px-2 text-center tabular-nums">{s ? toFaDigits(s.leaveDays) : "—"}</td>
                        <td className="py-2.5 px-2 text-center tabular-nums">{s ? toFaDigits(Math.round(s.workHours)) : "—"}</td>
                        <td className="py-2.5 px-2 text-center tabular-nums font-medium text-teal-700">{s && s.overtimeHours > 0 ? toFaDigits(s.overtimeHours) : "۰"}</td>
                        <td className="py-2.5 px-2 text-center tabular-nums font-medium text-indigo-700">{s && s.nightHours > 0 ? toFaDigits(s.nightHours) : "۰"}</td>
                        <td className="py-2.5 px-2 text-center tabular-nums font-medium text-cyan-700">{s && s.fridayHours + s.holidayHours > 0 ? `${toFaDigits(s.fridayHours)}/${toFaDigits(s.holidayHours)}` : "۰"}</td>
                        <td className="py-2.5 px-2 text-center">
                          <Button
                            size="sm"
                            variant={selectedEmployeeId === e.id ? "default" : "outline"}
                            className="h-7 text-xs gap-1"
                            onClick={() => setSelectedEmployeeId(e.id)}
                          >
                            <Pencil className="w-3 h-3" /> تردد
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ---------- تردد روزانه ---------- */}
        <TabsContent value="daily" className="mt-3">
          <Card className="rounded-2xl">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex flex-wrap items-center gap-2">
                تردد روزانه
                <div className="w-72">
                  <Select value={selectedEmployeeId} onValueChange={setSelectedEmployeeId}>
                    <SelectTrigger><SelectValue placeholder="انتخاب کارمند…" /></SelectTrigger>
                    <SelectContent>
                      {employees.map((e) => (
                        <SelectItem key={e.id} value={e.id}>
                          {e.fullName} <span className="text-[10px] text-muted-foreground font-mono" dir="ltr">{e.personnelCode}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {selectedEmployee && (
                  <Badge variant="outline">
                    {EMPLOYMENT_TYPE_LABELS[selectedEmployee.employmentType]}
                    {selectedEmployee.shiftPattern ? ` • ${SHIFT_PATTERN_LABELS[selectedEmployee.shiftPattern]}` : ""}
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!selectedEmployeeId ? (
                <p className="py-10 text-center text-sm text-muted-foreground">یک کارمند از جدول «کارکرد ماهانه» یا فهرست بالا انتخاب کنید.</p>
              ) : detailApi.loading && !detailApi.data ? (
                <Skeleton className="h-64 rounded-xl" />
              ) : (
                <div className="overflow-x-auto rounded-xl border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b bg-slate-50 text-[11px] text-slate-600">
                        <th className="py-2 px-2 text-right font-medium w-28">تاریخ</th>
                        <th className="py-2 px-2 text-center font-medium w-24">وضعیت</th>
                        <th className="py-2 px-2 text-center font-medium w-24">ورود</th>
                        <th className="py-2 px-2 text-center font-medium w-24">خروج</th>
                        <th className="py-2 px-2 text-center font-medium">عادی</th>
                        <th className="py-2 px-2 text-center font-medium">اضافه</th>
                        <th className="py-2 px-2 text-center font-medium">شب</th>
                        <th className="py-2 px-2 text-center font-medium">جمعه</th>
                        <th className="py-2 px-2 text-center font-medium">تعطیل</th>
                        <th className="py-2 px-2 text-center font-medium w-20"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {days.map((d) => {
                        const r = recordByDate.get(d.dateJ);
                        const isToday = d.dateJ === data?.today;
                        return (
                          <tr key={d.dateJ} className={`border-b last:border-0 ${d.isFriday ? "bg-teal-50/40" : ""} ${isToday ? "ring-1 ring-inset ring-teal-400" : ""}`}>
                            <td className="py-2 px-2 tabular-nums text-xs">
                              {formatDateJ(d.dateJ)}
                              {d.isFriday && <span className="mr-1 text-[9px] text-teal-600 font-bold">جمعه</span>}
                            </td>
                            <td className="py-2 px-2 text-center">
                              {r ? (
                                <Badge className={ATTENDANCE_STATUS_BADGE[r.status] || ""}>{ATTENDANCE_STATUS_LABELS[r.status] || r.status}</Badge>
                              ) : (
                                <span className="text-[10px] text-muted-foreground">ثبت نشده</span>
                              )}
                            </td>
                            <td className="py-2 px-2 text-center tabular-nums text-xs" dir="ltr">{r?.checkInJ || "—"}</td>
                            <td className="py-2 px-2 text-center tabular-nums text-xs" dir="ltr">{r?.checkOutJ || "—"}</td>
                            <td className="py-2 px-2 text-center tabular-nums text-xs">{r ? toFaDigits(r.workHours) : "—"}</td>
                            <td className="py-2 px-2 text-center tabular-nums text-xs text-teal-700">{r && r.overtimeHours > 0 ? toFaDigits(r.overtimeHours) : "—"}</td>
                            <td className="py-2 px-2 text-center tabular-nums text-xs text-indigo-700">{r && r.nightHours > 0 ? toFaDigits(r.nightHours) : "—"}</td>
                            <td className="py-2 px-2 text-center tabular-nums text-xs text-cyan-700">{r && r.fridayHours > 0 ? toFaDigits(r.fridayHours) : "—"}</td>
                            <td className="py-2 px-2 text-center tabular-nums text-xs text-amber-700">{r && r.holidayHours > 0 ? toFaDigits(r.holidayHours) : "—"}</td>
                            <td className="py-2 px-2 text-center">
                              {canManage && (
                                <div className="flex items-center justify-center gap-1">
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-7 w-7 p-0"
                                    title={r ? "ویرایش تردد" : "ثبت تردد"}
                                    onClick={() =>
                                      setEditRecord(
                                        r
                                          ? { ...r, manualBuckets: false }
                                          : { dateJ: d.dateJ, status: defaultStatusForDate(d.dateJ), checkInJ: "08:00", checkOutJ: "17:00", manualBuckets: false }
                                      )
                                    }
                                  >
                                    {r ? <Pencil className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                                  </Button>
                                  {r && (
                                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-rose-600 hover:text-rose-700" title="حذف" onClick={() => deleteRecord(r.id)}>
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </Button>
                                  )}
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
              {selectedEmployeeId && (
                <p className="mt-3 text-[11px] text-muted-foreground leading-5">
                  سطل‌های ساعت خودکار محاسبه می‌شوند: شیفت استاندارد روزانه {toFaDigits(stdHours)} ساعت (۲۲۰÷۳۰) — مازاد آن اضافه‌کاری، هم‌پوشانی بازه ۲۲:۰۰–۰۶:۰۰ شب‌کاری، و وضعیت جمعه‌کاری/تعطیل‌کاری کل ساعت را در همان سطل ثبت می‌کند. برای اصلاح دستی، در فرم ثبت «ورودی دستی سطل‌ها» را فعال کنید.
                </p>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* ---------- فرم ثبت/ویرایش تردد ---------- */}
      <Dialog open={!!editRecord} onOpenChange={(v) => !v && setEditRecord(null)}>
        <DialogContent className="sm:max-w-[44.8rem] max-h-[85vh] overflow-y-auto" dir="rtl">
          {editRecord && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <CalendarClock className="w-5 h-5 text-teal-600" />
                  {editRecord.id ? "ویرایش تردد" : "ثبت تردد جدید"}
                  {selectedEmployee && <span className="text-xs text-muted-foreground">— {selectedEmployee.fullName}</span>}
                </DialogTitle>
              </DialogHeader>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">تاریخ</Label>
                  <JalaliDatePicker value={editRecord.dateJ || ""} onChange={(v) => setEditRecord({ ...editRecord, dateJ: v })} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">وضعیت</Label>
                  <Select value={editRecord.status || "PRESENT"} onValueChange={(v) => setEditRecord({ ...editRecord, status: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {ATTENDANCE_STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>{ATTENDANCE_STATUS_LABELS[s]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">ساعت ورود</Label>
                  <Input dir="ltr" placeholder="08:00" value={editRecord.checkInJ || ""} onChange={(e) => setEditRecord({ ...editRecord, checkInJ: e.target.value })} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">ساعت خروج</Label>
                  <Input dir="ltr" placeholder="17:00" value={editRecord.checkOutJ || ""} onChange={(e) => setEditRecord({ ...editRecord, checkOutJ: e.target.value })} />
                </div>
                <div className="sm:col-span-2 space-y-1.5">
                  <Label className="text-xs">یادداشت (اختیاری)</Label>
                  <Input value={editRecord.note || ""} onChange={(e) => setEditRecord({ ...editRecord, note: e.target.value })} placeholder="مثلاً: تأخیر ۲۰ دقیقه‌ای — هماهنگی با مدیر" />
                </div>

                <div className="sm:col-span-2 rounded-xl border border-teal-200 bg-teal-50/40 p-3 space-y-3">
                  <label className="flex items-center gap-2 text-xs font-bold text-teal-800">
                    <input
                      type="checkbox"
                      checked={editRecord.manualBuckets === true}
                      onChange={(e) => setEditRecord({ ...editRecord, manualBuckets: e.target.checked })}
                      className="accent-teal-600"
                    />
                    ورودی دستی سطل‌های ساعت (غیر از محاسبه خودکار)
                  </label>
                  {editRecord.manualBuckets ? (
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                      {([
                        { k: "workHours", l: "عادی" },
                        { k: "overtimeHours", l: "اضافه‌کاری" },
                        { k: "nightHours", l: "شب‌کاری" },
                        { k: "fridayHours", l: "جمعه‌کاری" },
                        { k: "holidayHours", l: "تعطیل‌کاری" },
                      ] as const).map((f) => (
                        <div key={f.k} className="space-y-1">
                          <Label className="text-[11px]">{f.l} (ساعت)</Label>
                          <Input
                            dir="ltr"
                            inputMode="decimal"
                            className="h-9 text-center"
                            value={String((editRecord as Record<string, unknown>)[f.k] ?? 0)}
                            onChange={(e) => setEditRecord({ ...editRecord, [f.k]: e.target.value })}
                          />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[11px] leading-5 text-muted-foreground">
                      سطل‌ها از روی ورود/خروج و وضعیت محاسبه می‌شوند — شیفت استاندارد {toFaDigits(stdHours)} ساعت در روز؛ مازاد = اضافه‌کاری؛ هم‌پوشانی ۲۲:۰۰ تا ۰۶:۰۰ = شب‌کاری؛ وضعیت جمعه/تعطیل = کل ساعت در سطل مربوطه.
                    </p>
                  )}
                </div>
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setEditRecord(null)}>انصراف</Button>
                <Button onClick={saveRecord} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
                  <Plus className="w-4 h-4" /> ذخیره تردد
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ---------- ثبت گروهی ماه ---------- */}
      <BulkMonthDialog
        open={bulkOpen}
        onOpenChange={setBulkOpen}
        employees={employees}
        year={year}
        month={month}
        onSaved={async () => {
          await summaryApi.refetch();
          if (selectedEmployeeId) await detailApi.refetch?.();
        }}
      />
    </div>
  );
}

function StatChip({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div className={`rounded-xl border border-white/50 px-3 py-1.5 text-xs ${tone}`}>
      <span className="opacity-70">{label}: </span>
      <b className="tabular-nums">{value}</b>
    </div>
  );
}

function BulkMonthDialog({ open, onOpenChange, employees, year, month, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  employees: EmployeeLite[];
  year: number;
  month: number;
  onSaved: () => void | Promise<void>;
}) {
  const { toast } = useToast();
  const [employeeId, setEmployeeId] = useState("");
  const [checkIn, setCheckIn] = useState("08:00");
  const [checkOut, setCheckOut] = useState("17:00");
  const [skipFridays, setSkipFridays] = useState(true);
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!employeeId) {
      toast({ title: "کارمند را انتخاب کنید", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const r = await api<{ created: number }>("/api/attendance", {
        method: "POST",
        json: { mode: "bulk", employeeId, year, month, checkInJ: checkIn, checkOutJ: checkOut, skipFridays },
      });
      onOpenChange(false);
      await onSaved();
      toast({
        title: "کارکرد ماهانه ثبت شد",
        description: `${toFaDigits(r.created)} روز جدید برای ${formatMonthJ(year, month)} ساخته شد — روزهای موجود دست نخوردند.`,
      });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Wand2 className="w-5 h-5 text-teal-600" /> ثبت گروهی کارکرد {formatMonthJ(year, month)}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">کارمند</Label>
            <Select value={employeeId} onValueChange={setEmployeeId}>
              <SelectTrigger><SelectValue placeholder="انتخاب کارمند…" /></SelectTrigger>
              <SelectContent>
                {employees.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.fullName} <span className="text-[10px] text-muted-foreground font-mono" dir="ltr">{e.personnelCode}</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">ساعت ورود</Label>
              <Input dir="ltr" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} placeholder="08:00" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">ساعت خروج</Label>
              <Input dir="ltr" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} placeholder="17:00" />
            </div>
          </div>
          <label className="flex items-center gap-2 text-xs">
            <input type="checkbox" checked={skipFridays} onChange={(e) => setSkipFridays(e.target.checked)} className="accent-teal-600" />
            جمعه‌ها تعطیل بماند (رکورد ساخته نشود)
          </label>
          <p className="text-[11px] text-muted-foreground bg-amber-50 border border-amber-100 rounded-lg p-2.5 leading-5">
            برای همه روزهای بدون رکوردِ این ماه، تردد «حضور» با ساعت ورود/خروج بالا ساخته می‌شود؛ روزهای ثبت‌شده قبلی تغییر نمی‌کنند. سپس روزهای خاص (غیبت/مرخصی/جمعه‌کاری/تعطیل‌کاری) را از جدول تردد روزانه اصلاح کنید.
          </p>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            <Wand2 className="w-4 h-4" /> {saving ? "در حال ثبت…" : "ثبت گروهی"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

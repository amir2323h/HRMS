"use client";

// ============================================================
// هوک برندینگ — با کش لوکال برای نمایش آنی لوگو/عنوان
// اولین رندر از کش localStorage (بدون فلش لوگوی پیش‌فرض)،
// سپس داده تازه API جایگزین می‌شود و کش به‌روز می‌گردد.
// ============================================================
import { useEffect, useState } from "react";
import { useApi } from "@/lib/client";

export interface BrandInfo {
  title: string;
  subtitle: string;
  logo: string;
  favicon: string;
  companyName: string;
  footerText: string;
  demoMode?: boolean; // حالت دمو — نمایش حساب‌های نمونه در صفحه ورود (پیش‌فرض خاموش)
  companyNationalId?: string; // شناسه ملی — سربرگ/پابرگ نامه‌ها
  companyAddress?: string; // نشانی — پابرگ نامه‌ها
  companyPhone?: string; // تلفن — پابرگ نامه‌ها
  companyMobile?: string; // موبایل — پابرگ نامه‌ها
  companyWebsite?: string; // وب‌سایت — پابرگ نامه‌ها
  companyEmail?: string; // ایمیل — پابرگ نامه‌ها
}

const CACHE_KEY = "hrms_branding_cache";

function readCache(): Partial<BrandInfo> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as Partial<BrandInfo>) : null;
  } catch {
    return null;
  }
}

export function useBranding() {
  // خواندن کش در اولین رندر (initializer همگام — نه در effect)
  const [cached] = useState<Partial<BrandInfo> | null>(readCache);
  const { data, loading } = useApi<{ branding: BrandInfo }>("/api/branding");

  // نوشتن کش برای بارگذاری بعدی (بدون به‌روزرسانی state — رندر از داده تازه)
  useEffect(() => {
    if (data?.branding) {
      try {
        window.localStorage.setItem(CACHE_KEY, JSON.stringify(data.branding));
      } catch {
        /* حالت ناشناس/محدود */
      }
    }
  }, [data]);

  const brand = data?.branding || cached || null;
  return { brand, loading };
}

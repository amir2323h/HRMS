"use client";

// ============================================================
// ابزار چاپ اسناد A4 — پنجره جدید مستقل با فونت وزیرمتن لوکال
// رفع مشکل چاپ داخل دیالوگ (overflow/clip) + پشتیبانی چندسند
// ============================================================

export interface PrintSignature {
  title: string; // مثلاً «امضای کارفرما»
  name?: string; // نام زیر خط امضا
}

export interface PrintSection {
  docTitle: string; // عنوان سند (وسط صفحه اول هر سند)
  metaLtr?: string; // سطر شماره/تاریخ (چپ‌به‌راست)
  headerTitle?: string; // نام سازمان بالای سند
  body: string; // متن اصلی (whitespace-pre-wrap)
  signatures?: [PrintSignature, PrintSignature] | null;
  footerNote?: string;
}

const FONT_FACES = `
@font-face { font-family: 'Vazirmatn'; src: url('/fonts/Vazirmatn-Regular.woff2') format('woff2'); font-weight: 400; font-display: block; }
@font-face { font-family: 'Vazirmatn'; src: url('/fonts/Vazirmatn-Medium.woff2') format('woff2'); font-weight: 500; font-display: block; }
@font-face { font-family: 'Vazirmatn'; src: url('/fonts/Vazirmatn-SemiBold.woff2') format('woff2'); font-weight: 600; font-display: block; }
@font-face { font-family: 'Vazirmatn'; src: url('/fonts/Vazirmatn-Bold.woff2') format('woff2'); font-weight: 700; font-display: block; }
`;

function esc(s: string): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** ساخت سند HTML کامل RTL برای چاپ/دانلود — هر بخش یک صفحه A4 با شکست صفحه */
export function buildPrintDocument(sections: PrintSection[], docTitle: string): string {
  const pages = sections
    .map((s) => {
      const sig = s.signatures
        ? `<div class="sigs">
            <div>
              <p class="sig-title">${esc(s.signatures[0].title)}</p>
              <p class="sig-name">${esc(s.signatures[0].name || "")}</p>
            </div>
            <div>
              <p class="sig-title">${esc(s.signatures[1].title)}</p>
              <p class="sig-name">${esc(s.signatures[1].name || "")}</p>
            </div>
          </div>`
        : "";
      return `<section class="page">
        ${s.headerTitle ? `<p class="org">${esc(s.headerTitle)}</p>` : ""}
        <h1 class="doc-title">${esc(s.docTitle)}</h1>
        ${s.metaLtr ? `<p class="meta" dir="ltr">${esc(s.metaLtr)}</p>` : ""}
        <div class="body-text">${esc(s.body)}</div>
        ${sig}
        ${s.footerNote ? `<p class="footnote">${esc(s.footerNote)}</p>` : ""}
      </section>`;
    })
    .join("\n");

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>${esc(docTitle)}</title>
<style>
${FONT_FACES}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { background: #eef2f5; }
body { font-family: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif; direction: rtl; }
.page {
  background: #fff;
  width: 210mm;
  min-height: 297mm;
  margin: 8mm auto;
  padding: 18mm 16mm;
  box-shadow: 0 2px 14px rgba(0,0,0,.14);
  display: flex;
  flex-direction: column;
}
.org { text-align: center; font-weight: 700; color: #0f766e; font-size: 13pt; padding-bottom: 4mm; border-bottom: 1.5pt solid #0f766e33; }
.doc-title { text-align: center; font-size: 15pt; font-weight: 700; color: #1e293b; margin-top: 7mm; }
.meta { text-align: center; font-size: 9.5pt; color: #64748b; margin-top: 2mm; font-variant-numeric: tabular-nums; }
.body-text { margin-top: 8mm; font-size: 11.5pt; line-height: 2.15; color: #334155; white-space: pre-wrap; text-align: justify; flex: 1; }
.sigs { margin-top: 14mm; padding-top: 6mm; border-top: 1pt dotted #94a3b8; display: grid; grid-template-columns: 1fr 1fr; gap: 10mm; text-align: center; }
.sig-title { font-size: 10pt; color: #64748b; margin-bottom: 22mm; }
.sig-name { font-size: 10pt; color: #334155; border-top: 1pt dotted #64748b; padding-top: 2mm; }
.footnote { margin-top: 6mm; font-size: 8.5pt; color: #94a3b8; text-align: center; }
.toolbar { position: fixed; top: 0; right: 0; left: 0; background: #0f172aee; color: #fff; display: flex; align-items: center; gap: 10px; padding: 8px 14px; font-family: 'Vazirmatn', sans-serif; z-index: 99; }
.toolbar button { font-family: inherit; font-size: 12px; padding: 6px 14px; border: 0; border-radius: 8px; cursor: pointer; }
.toolbar .btn-print { background: #14b8a6; color: #fff; }
.toolbar .btn-close { background: #475569; color: #fff; }
.toolbar .hint { font-size: 11px; opacity: .75; margin-right: auto; }
@media print {
  html, body { background: #fff; }
  .toolbar { display: none !important; }
  .page { width: auto; min-height: auto; margin: 0; box-shadow: none; padding: 12mm 10mm; }
  .page + .page { page-break-before: always; }
  .noprint { display: none; }
}
</style>
</head>
<body>
<div class="toolbar">
  <button class="btn-print" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
  <button class="btn-close" onclick="window.close()">بستن</button>
  <span class="hint">${esc(docTitle)} — برای PDF در پنجره چاپ گزینه «Save as PDF» را انتخاب کنید</span>
</div>
${pages}
</body>
</html>`;
}

/**
 * چاپ اسناد در پنجره جدید — هر سند یک صفحه A4.
 * در محیط‌هایی که popup مسدود است، به‌صورت fallback در iframe مخفی چاپ می‌شود.
 */
export function printSections(sections: PrintSection[], docTitle: string): void {
  const html = buildPrintDocument(sections, docTitle);
  const w = window.open("", "_blank", "width=920,height=760");
  if (w) {
    w.document.open();
    w.document.write(html);
    w.document.close();
    w.focus();
    // چاپ پس از بارگذاری فونت‌ها
    w.addEventListener("load", () => setTimeout(() => { try { w.focus(); w.print(); } catch { /* کاربر خودش دکمه چاپ را می‌زند */ } }, 350));
    return;
  }
  // fallback: iframe مخفی
  const f = document.createElement("iframe");
  f.style.cssText = "position:fixed;left:200%;bottom:200%;width:0;height:0;border:0;visibility:hidden;";
  document.body.appendChild(f);
  f.onload = () => {
    setTimeout(() => {
      try {
        f.contentWindow?.focus();
        f.contentWindow?.print();
      } catch { /* noop */ }
      setTimeout(() => f.remove(), 60_000);
    }, 500);
  };
  f.srcdoc = html;
}

/** دانلود همان سند چاپی به‌صورت فایل HTML (قابل چاپ/اشتراک) */
export function downloadPrintDocument(sections: PrintSection[], docTitle: string, fileName: string): void {
  const html = buildPrintDocument(sections, docTitle);
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName.endsWith(".html") ? fileName : `${fileName}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ============================================================
// راستی‌آزمایی مبنای بیمه فیش حقوقی ۱۴۰۵ — v2.9.14
// فرمول رسمی (ماده ۳۰ قانون تأمین اجتماعی — اصلاحی ۱۳۹۴):
//   بیمه سهم کارگر = ۷٪ × (حقوق پایه + حق مسکن + بن کارگری + مزایای ناشی از کار)
// اجرا: bun scripts/verify-sso-base.ts   (یا: npx tsx scripts/verify-sso-base.ts)
// ============================================================
import { LEGAL_DEFAULTS_1405, computePaysheet, gradeNetSimple, EMPTY_CONTEXT } from "../src/lib/payroll/engine";
import { computeReversePaysheet } from "../src/lib/payroll/reverse";

const P = LEGAL_DEFAULTS_1405;
const fa = (n: number) => n.toLocaleString("fa-IR");

let failures = 0;
function check(name: string, got: number, expected: number) {
  const ok = got === expected;
  if (!ok) failures++;
  console.log(`${ok ? "✅" : "❌"} ${name}: ${fa(got)} ${ok ? "==" : "!= انتظار"} ${fa(expected)}`);
}

// ——— ۱) حداقل‌بگیر مجرد: بیمه = ۷٪ × (پایه + مسکن + بن) ———
console.log("———— ۱) حداقل‌بگیر ۱۴۰۵ — مبنای بیمه شامل مسکن و بن ————");
const r1 = computePaysheet(P.minWage, { ...EMPTY_CONTEXT }, P);
const gross1 = P.minWage + P.housing + P.grocery; // ۲۱۸,۲۵۵,۵۰۰
check("مشمول بیمه (پایه + مسکن + بن)", r1.insurableBase, gross1);
check("بیمه سهم کارگر ۷٪", r1.employeeSso, Math.round(gross1 * 0.07)); // ۱۵,۲۷۷,۸۸۵
check("سهم کارفرما ۲۰٪", r1.employerSso20, Math.round(gross1 * 0.20));
check("بیمه بیکاری ۳٪", r1.unemploymentSso3, Math.round(gross1 * 0.03));

// ——— ۲) همسویی فیش با کارت طبقه‌بندی (gradeNetSimple) ———
console.log("\n———— ۲) همسویی فیش و کارت طبقه‌بندی ————");
const card = gradeNetSimple(P.minWage, P);
check("بیمه فیش == بیمه کارت (۱۵,۲۷۷,۸۸۵)", r1.employeeSso, card.sso);
check("خالص فیش == خالص کارت (۲۰۲,۹۷۷,۶۱۵)", r1.netPay, card.net);
console.log(`   → کارت: خالص ${fa(card.net)} | فیش: خالص ${fa(r1.netPay)} — یکسان ✓`);

// ——— ۳) بدون مسکن/بن (غیرمشتمول): مبنای بیمه فقط پایه + کف قانونی ———
console.log("\n———— ۳) کارمند بدون حق مسکن/بن — کف حداقل دستمزد ————");
const r3 = computePaysheet(100_000_000, { ...EMPTY_CONTEXT, housingEnabled: false, groceryEnabled: false }, P);
check("مبنای بیمه = کف حداقل دستمزد", r3.insurableBase, P.minWage);
check("بیمه = ۷٪ × حداقل", r3.employeeSso, Math.round(P.minWage * 0.07));
if (!r3.warnings.some((w) => w.includes("حداقل دستمزد"))) { failures++; console.log("❌ هشدار کف بیمه فعال نشد"); }
else console.log("✅ هشدار «مزد مشمول بیمه کمتر از حداقل» صادر شد");

// ——— ۴) اضافه‌کاری + فوق‌العاده‌ها همگی بیمه‌پذیر ———
console.log("\n———— ۴) اضافه‌کاری/شب‌کاری/شیفت/مأموریت — بیمه‌پذیر ————");
const ctx4 = {
  ...EMPTY_CONTEXT,
  overtimeHours: 50,
  nightHours: 40,
  fridayHours: 8,
  shiftRate: 0.225,
  missionDays: 3,
};
const r4 = computePaysheet(200_000_000, ctx4, P);
const expect4 = 200_000_000 + r4.overtimeAmount + r4.nightAmount + r4.fridayAmount + r4.shiftAllowance + r4.missionAmount + P.housing + P.grocery;
check("مبنای بیمه = پایه + فوق‌العاده‌ها + مسکن + بن", r4.insurableBase, expect4);
check("بیمه = ۷٪ × مبنا", r4.employeeSso, Math.round(expect4 * 0.07));

// ——— ۵) پرچم اقلام فیش: مسکن و بن بیمه‌پذیر ———
console.log("\n———— ۵) پرچم بیمه‌پذیری اقلام فیش ————");
const hItem = r1.items.find((i) => i.code === "HOUSING");
const gItem = r1.items.find((i) => i.code === "GROCERY");
const sItem = r1.items.find((i) => i.code === "SENIORITY");
if (hItem?.insurable) console.log("✅ حق مسکن: بیمه‌پذیر"); else { failures++; console.log("❌ حق مسکن: بیمه‌پذیر نیست"); }
if (gItem?.insurable) console.log("✅ بن کارگری: بیمه‌پذیر"); else { failures++; console.log("❌ بن کارگری: بیمه‌پذیر نیست"); }
if (!sItem || !sItem.insurable) console.log("✅ سنوات: بیمه‌ناپذیر (طبق قانون)"); else { failures++; console.log("❌ سنوات نباید بیمه‌پذیر باشد"); }

// ——— ۶) موتور معکوس: با فرمول جدید همگرا و سازگار ———
console.log("\n———— ۶) موتور معکوس (Bisection) با مبنای جدید ————");
const target = 300_000_000; // خالص هدف ۳۰ میلیون تومان
const rev = computeReversePaysheet({ targetNet: target, context: { ...EMPTY_CONTEXT }, params: P });
check("خالص نتیجه == هدف", rev.paysheet.netPay, target);
check("بیمه معکوس = ۷٪ × (پایه + مسکن + بن)", rev.paysheet.employeeSso, Math.round((rev.paysheet.baseCore + P.housing + P.grocery) * 0.07));
console.log(`   → پایه معکوس: ${fa(rev.paysheet.baseCore)} | تکرار: ${fa(rev.iterationsCount)}`);

const target2 = 150_000_000_000; // سقف طبقه ۷ — پل ۳۰٪ مالیات
const rev2 = computeReversePaysheet({ targetNet: target2, context: { ...EMPTY_CONTEXT }, params: P });
check("هدف سنگین (پل ۳۰٪) — خالص == هدف", rev2.paysheet.netPay, target2);

console.log(`\n${failures === 0 ? "🎉 همهٔ آزمون‌ها موفق — فیش حقوقی اکنون طبق فرمول رسمی: بیمه = ۷٪ × (پایه + مسکن + بن + مزایای کار)" : `⚠️ ${failures} آزمون ناموفق`}`);
process.exit(failures === 0 ? 0 : 1);

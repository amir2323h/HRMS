// ============================================================
// راستی‌آزمایی محاسبه خالص پرداختی کارت طبقه‌بندی مشاغل ۱۴۰۵
// فرمول: خالص = (حقوق پایه + حق مسکن + بن کارگری) − بیمه ۷٪ − مالیات
// اجرا: bun scripts/verify-grade-net.ts
// ============================================================
import { LEGAL_DEFAULTS_1405, applyLegalIncrease, gradeNetSimple, progressiveTax } from "../src/lib/payroll/engine";

const P = LEGAL_DEFAULTS_1405;

// ——— ارقام رسمی ۱۴۰۵ (تأییدشده با جستجوی وب — بخشنامه مزد/بودجه) ———
const OFFICIAL = {
  minWageMonthly: 166_255_500, // حداقل مزد ماهانه (روزی ۵,۵۴۱,۸۵۰ × ۳۰)
  housing: 30_000_000, // حق مسکن
  grocery: 22_000_000, // بن کارگری
  grossSingleMinWage: 218_255_500, // دریافتی مجرد بدون سابقه (پایه+مسکن+بن) — منابع رسمی
  sso7: 15_277_885, // بیمه سهم کارگر ۷٪ × ۲۱۸,۲۵۵,۵۰۰
  exemptionMonthly: 400_000_000, // معافیت ماهانه ماده ۸۵ بودجه ۱۴۰۵
  increasePercent: 0.45, // افزایش سایر سطوح مزدی
  increaseFixedMonthly: 15_586_470, // ثابت ماهانه (روزی ۵۱۹,۵۴۹ × ۳۰)
};

let failures = 0;
function check(name: string, got: number, expected: number) {
  const ok = got === expected;
  if (!ok) failures++;
  console.log(`${ok ? "✅" : "❌"} ${name}: ${got.toLocaleString("en-US")} ${ok ? "==" : "!= محاسبه دستی"} ${expected.toLocaleString("en-US")}`);
}

function fa(n: number) {
  return n.toLocaleString("fa-IR");
}

// ——— ۱) حداقل‌بگیر مجرد ۱۴۰۵ (راستی‌آزمایی با ارقام رسمی) ———
console.log("———— ۱) حداقل‌بگیر ۱۴۰۵ — مطابقت با ارقام رسمی ————");
const r1 = gradeNetSimple(OFFICIAL.minWageMonthly, P);
check("جمع دریافتی (پایه+مسکن+بن)", r1.gross, OFFICIAL.grossSingleMinWage);
check("بیمه سهم کارگر ۷٪", r1.sso, OFFICIAL.sso7);
check("مالیات (زیر معافیت ۴۰۰M)", r1.tax, 0);
check("خالص پرداختی", r1.net, OFFICIAL.grossSingleMinWage - OFFICIAL.sso7);
console.log(`   → خالص ماهانه حداقل‌بگیر: ${fa(r1.net)} ریال (${fa(Math.round(r1.net / 10))} تومان)`);

// ——— ۲) محاسبه دستی مستقل برای مبانی نمونه ———
console.log("\n———— ۲) مبانی نمونه — مقایسه با محاسبه دستی مستقل ————");
const samples = [166_255_500, 200_000_000, 300_000_000, 400_000_000, 500_000_000, 800_000_000, 1_200_000_000];
for (const base of samples) {
  const r = gradeNetSimple(base, P);
  const gross = base + OFFICIAL.housing + OFFICIAL.grocery;
  const sso = Math.round(gross * 0.07);
  const taxable = gross - sso;
  // مالیات پلکانی دستی: ۰–۴۰۰M معاف | ۴۰۰–۸۰۰M: ۱۰٪ | ۸۰۰M–۱B: ۱۵٪ | ۱–۱.۲B: ۲۰٪ | ۱.۲–۱.۴B: ۲۵٪ | +۱.۴B: ۳۰٪
  let tax = 0;
  if (taxable > 400_000_000) tax += (Math.min(taxable, 800_000_000) - 400_000_000) * 0.10;
  if (taxable > 800_000_000) tax += (Math.min(taxable, 1_000_000_000) - 800_000_000) * 0.15;
  if (taxable > 1_000_000_000) tax += (Math.min(taxable, 1_200_000_000) - 1_000_000_000) * 0.20;
  if (taxable > 1_200_000_000) tax += (Math.min(taxable, 1_400_000_000) - 1_200_000_000) * 0.25;
  if (taxable > 1_400_000_000) tax += (taxable - 1_400_000_000) * 0.30;
  tax = Math.round(tax);
  const net = gross - sso - tax;
  const ok = r.gross === gross && r.sso === sso && r.tax === tax && r.net === net;
  if (!ok) failures++;
  console.log(`${ok ? "✅" : "❌"} پایه ${fa(base)}: دریافتی ${fa(gross)} − بیمه ${fa(sso)} − مالیات ${fa(tax)} = خالص ${fa(net)}${ok ? "" : ` | موتور: ${fa(r.net)}`}`);
}

// ——— ۳) افزایش قانونی سایر سطوح مزدی ———
console.log("\n———— ۳) افزایش قانونی ۱۴۰۵ (۴۵٪ + ثابت ۱۵,۵۸۶,۴۷۰؛ کف حداقل دستمزد) ————");
const inc1 = applyLegalIncrease(100_000_000, P); // ۱۰۰M → ۱۶۰.۵M → کف ۱۶۶,۲۵۵,۵۰۰
check("کف قانونی (۱۰۰M → حداقل)", inc1.base, Math.max(100_000_000 * 1.45 + OFFICIAL.increaseFixedMonthly, OFFICIAL.minWageMonthly));
check("applied", inc1.applied ? 1 : 0, 1);
const inc2 = applyLegalIncrease(200_000_000, P); // ۲۰۰M → ۳۰۵,۵۸۶,۴۷۰
check("سایر سطوح (۲۰۰M)", inc2.base, Math.round(200_000_000 * (1 + OFFICIAL.increasePercent) + OFFICIAL.increaseFixedMonthly));
// بازتولید دقیق حداقل ۱۴۰۵ از حداقل ۱۴۰۴ (۱۶۶,۲۵۵,۵۰۰ ÷ ۱.۶ ≈ ۱۰۳,۹۰۹,۶۸۷.۵)
const min1404 = OFFICIAL.minWageMonthly / 1.6;
const inc3 = applyLegalIncrease(Math.round(min1404), P);
console.log(`ℹ️ حداقل ۱۴۰۴ ≈ ${fa(Math.round(min1404))} → پس از افزایش: ${fa(inc3.base)} (حداقل ۱۴۰۵: ${fa(OFFICIAL.minWageMonthly)}) — اختلاف ناشی از گرد شدن روزانه`);

// ——— ۴) سناریوی کامل کارت: بازه ثبت‌شده → افزایش → خالص ———
console.log("\n———— ۴) سناریوی کامل کارت سطح (بازه ثبت‌شده → مبنای ۱۴۰۵ → خالص) ————");
const scenarios = [
  { stored: [100_000_000, 180_000_000], label: "سطح ۱" },
  { stored: [180_000_000, 280_000_000], label: "سطح ۲" },
  { stored: [280_000_000, 400_000_000], label: "سطح ۳" },
  { stored: [400_000_000, 550_000_000], label: "سطح ۴" },
  { stored: [550_000_000, 750_000_000], label: "سطح ۵" },
  { stored: [750_000_000, 1_000_000_000], label: "سطح ۶" },
  { stored: [1_000_000_000, 1_400_000_000], label: "سطح ۷" },
];
for (const s of scenarios) {
  const effMin = applyLegalIncrease(s.stored[0], P);
  const effMax = applyLegalIncrease(s.stored[1], P);
  const nMin = gradeNetSimple(effMin.base, P);
  const nMax = gradeNetSimple(effMax.base, P);
  console.log(`${s.label}: ثبت ${fa(s.stored[0])}–${fa(s.stored[1])}`);
  console.log(`   مبنای ۱۴۰۵: ${fa(effMin.base)} – ${fa(effMax.base)}`);
  console.log(`   خالص کف: ${fa(nMin.net)} (بیمه ${fa(nMin.sso)}، مالیات ${fa(nMin.tax)})`);
  console.log(`   خالص سقف: ${fa(nMax.net)} (بیمه ${fa(nMax.sso)}، مالیات ${fa(nMax.tax)})`);
  // درون‌گیری دستی: خالص = (پایه + ۵۲M) × ۰.۹۳ − مالیات
  const manualNet = (b: number) => {
    const g = b + OFFICIAL.housing + OFFICIAL.grocery;
    return g - Math.round(g * 0.07) - progressiveTax(Math.max(0, g - Math.round(g * 0.07)), P.taxBrackets);
  };
  if (nMin.net !== manualNet(effMin.base) || nMax.net !== manualNet(effMax.base)) {
    failures++;
    console.log("❌ عدم تطابق با محاسبه دستی");
  }
}

// ——— ۵) رابط ثابت: خالص = ۹۳٪ × دریافتی − مالیات (زیر معافیت) ———
console.log("\n———— ۵) روابط ثابت ————");
const r5 = gradeNetSimple(300_000_000, P);
check("خالص = ۹۳٪ × دریافتی (بدون مالیات)", r5.net, Math.round(352_000_000 * 0.93));
check("بیمه = ۷٪ × (پایه+مسکن+بن) — نه فقط پایه", r5.sso, Math.round(352_000_000 * 0.07));

console.log(`\n${failures === 0 ? "🎉 همهٔ آزمون‌ها موفق — اعداد کارت دقیقاً طبق فرمول: پایه + مسکن + بن − بیمه ۷٪ − مالیات" : `⚠️ ${failures} آزمون ناموفق`}`);
process.exit(failures === 0 ? 0 : 1);

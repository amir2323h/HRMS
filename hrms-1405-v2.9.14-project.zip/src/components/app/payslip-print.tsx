"use client";

// ============================================================
// فیش حقوقی — قالب کلاسیک ایرانی، قابل چاپ
// ============================================================
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer, X } from "lucide-react";
import { groupFa } from "@/lib/format";
import { periodTitle, formatDateJ, toFaDigits } from "@/lib/jalali";
import { CONTRACT_TYPE_LABELS } from "@/lib/format";
import { useApi } from "@/lib/client";

export interface PayslipData {
  id: string;
  employee: {
    fullName: string; personnelCode: string; nationalId: string; ssoNumber: string;
    iban: string; bankName: string; jobTitle: string; hireDateJ: string; childCount: number;
    maritalStatus: string;
  } | null;
  period: { year: number; month: number } | null;
  baseSalary: number; seniority: number; marriageAllowance?: number; housing: number; grocery: number; childAllowance: number;
  attraction: number; overtimeHours: number; overtimeAmount: number; otherAllowance: number;
  // ---- تفکیک حقوق ماهانه طبق درصد سطح ----
  responsibility?: number; // حق مسولیت — سهم تفکیک سطح
  merit?: number; // پاداش شایستگی — سهم تفکیک سطح
  // ---- شیفت/شب/تعطیل/غیبت/مأموریت ----
  nightHours?: number; nightAmount?: number;
  fridayHours?: number; fridayAmount?: number;
  holidayHours?: number; holidayAmount?: number;
  shiftAllowance?: number;
  absentDays?: number; absenceDeduction?: number;
  missionDays?: number; missionAmount?: number;
  gross: number; insurableBase: number; employeeSso: number; employerSso20: number; unemploymentSso3: number;
  taxableIncome: number; incomeTax: number; otherDeduction: number; netPay: number;
  isReverse: boolean; targetNet: number | null;
}

export interface CompanyInfo {
  name: string; nationalId: string; ssoCode: string; taxId: string; address: string;
}

export function PayslipPrintDialog({ open, onOpenChange, payslip, company }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  payslip: PayslipData | null;
  company: CompanyInfo;
}) {
  // نام شرکت از برندینگ (تنظیمات → اطلاعات شرکت) — پشتیبان وقتی prop هنوز لود نشده است
  const branding = useApi<{ branding: { companyName: string } }>("/api/branding");
  const companyName = (company.name || branding.data?.branding.companyName || "").trim();
  if (!payslip) return null;
  const p = payslip;
  // پرچم insurable مطابق موتور (ماده ۳۰ ق.ت.ا): مسکن و بن نیز بیمه‌پذیرند
  const earnings: { title: string; amount: number; insurable?: boolean }[] = [
    { title: "حقوق پایه", amount: p.baseSalary, insurable: true },
  ];
  if ((p.responsibility || 0) > 0) earnings.push({ title: "حق مسولیت", amount: p.responsibility || 0, insurable: true });
  if ((p.merit || 0) > 0) earnings.push({ title: "پاداش شایستگی", amount: p.merit || 0, insurable: true });
  if (p.seniority > 0) earnings.push({ title: "حق سنوات (جدول تجمیعی ۱۴۰۵)", amount: p.seniority });
  if ((p.marriageAllowance || 0) > 0) earnings.push({ title: "حق تاهل", amount: p.marriageAllowance || 0 });
  if (p.housing > 0) earnings.push({ title: "حق مسکن", amount: p.housing, insurable: true });
  if (p.grocery > 0) earnings.push({ title: "بن کارگری", amount: p.grocery, insurable: true });
  if (p.childAllowance > 0) earnings.push({ title: "حق اولاد", amount: p.childAllowance });
  if (p.attraction > 0) earnings.push({ title: "حق جذب", amount: p.attraction });
  if ((p.shiftAllowance || 0) > 0) earnings.push({ title: "حق شیفت (نوبتی‌کاری)", amount: p.shiftAllowance || 0, insurable: true });
  if (p.overtimeAmount > 0) earnings.push({ title: `اضافه‌کاری (${toFaDigits(p.overtimeHours)} ساعت)`, amount: p.overtimeAmount, insurable: true });
  if ((p.nightAmount || 0) > 0) earnings.push({ title: `فوق‌العاده شب‌کاری (${toFaDigits(p.nightHours || 0)} ساعت)`, amount: p.nightAmount || 0, insurable: true });
  if ((p.fridayAmount || 0) > 0) earnings.push({ title: `فوق‌العاده جمعه‌کاری (${toFaDigits(p.fridayHours || 0)} ساعت)`, amount: p.fridayAmount || 0, insurable: true });
  if ((p.holidayAmount || 0) > 0) earnings.push({ title: `فوق‌العاده تعطیل‌کاری (${toFaDigits(p.holidayHours || 0)} ساعت)`, amount: p.holidayAmount || 0, insurable: true });
  if ((p.missionAmount || 0) > 0) earnings.push({ title: `حق مأموریت (${toFaDigits(p.missionDays || 0)} روز)`, amount: p.missionAmount || 0, insurable: true });
  if (p.otherAllowance > 0) earnings.push({ title: "سایر مزایا", amount: p.otherAllowance });
  const deductions: { title: string; amount: number }[] = [
    { title: "حق بیمه سهم کارمند (۷٪)", amount: p.employeeSso },
    { title: "مالیات حقوق", amount: p.incomeTax },
  ];
  if ((p.absenceDeduction || 0) > 0) deductions.push({ title: `کسر مزد غیبت (${toFaDigits(p.absentDays || 0)} روز)`, amount: p.absenceDeduction || 0 });
  if (p.otherDeduction > 0) deductions.push({ title: "سایر کسورات", amount: p.otherDeduction });

  const maxRows = Math.max(earnings.length, deductions.length);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[67.2rem] !max-h-none overflow-y-auto p-0" dir="rtl">
        <DialogTitle className="sr-only">فیش حقوقی</DialogTitle>
        <div className="absolute left-3 top-3 z-10 flex gap-1">
          <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={() => window.print()}>
            <Printer className="w-3.5 h-3.5" /> چاپ
          </Button>
          <Button size="sm" variant="ghost" className="h-8 w-8 p-0" onClick={() => onOpenChange(false)}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div id="payslip-print-area" className="bg-white text-slate-900 p-5" style={{ fontFamily: "Vazirmatn" }}>
          {/* سربرگ */}
          <div className="flex items-start justify-between border-b-2 border-teal-700 pb-3">
            <div className="text-right">
              <p className="font-bold text-lg text-teal-800">{companyName || "—"}</p>
              {company.nationalId && (
                <p className="text-[10px] text-slate-500 mt-1">شناسه ملی: {company.nationalId} | کد کارگاه بیمه: {company.ssoCode} | شناسه مالیاتی: {company.taxId}</p>
              )}
              {company.address && <p className="text-[10px] text-slate-500">{company.address}</p>}
            </div>
            <div className="text-center">
              <p className="font-bold text-teal-800 border-2 border-teal-700 rounded-lg px-4 py-1">فیش حقوقی</p>
              <p className="text-xs mt-2 font-medium">{p.period ? periodTitle(p.period.year, p.period.month) : "—"}</p>
            </div>
            <div className="text-left text-[10px] text-slate-500">
              <p>شماره فیش: {p.id.slice(-8)}</p>
              <p>تاریخ صدور: {formatDateJ(new Date().toISOString().slice(0, 10))}</p>
              {p.isReverse && <p className="text-amber-700 font-bold mt-1">صادره از محاسبه معکوس</p>}
            </div>
          </div>

          {/* مشخصات کارمند */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-1.5 text-[11px] border-b border-slate-200 py-2.5">
            <Info label="نام و نام خانوادگی" value={p.employee?.fullName || "—"} />
            <Info label="شماره پرسنلی" value={p.employee?.personnelCode || "—"} />
            <Info label="کد ملی" value={p.employee?.nationalId || "—"} />
            <Info label="شماره بیمه" value={p.employee?.ssoNumber || "—"} />
            <Info label="عنوان شغل" value={p.employee?.jobTitle || "—"} />
            <Info label="تاریخ استخدام" value={formatDateJ(p.employee?.hireDateJ) || "—"} />
            <Info label="وضعیت تأهل" value={CONTRACT_TYPE_LABELS[p.employee?.maritalStatus === "MARRIED" ? "PERMANENT" : ""] || (p.employee?.maritalStatus === "MARRIED" ? "متأهل" : "مجرد")} />
            <Info label="تعداد فرزند" value={toFaDigits(p.employee?.childCount || 0)} />
          </div>

          {/* جدول حقوق و کسورات */}
          <table className="w-full mt-3 border-collapse text-[11px]">
            <thead>
              <tr className="bg-teal-700 text-white">
                <th colSpan={4} className="border border-teal-700 py-1.5 font-bold">حقوق و مزایا (ریال)</th>
                <th colSpan={4} className="border border-teal-700 py-1.5 font-bold">کسورات (ریال)</th>
              </tr>
              <tr className="bg-teal-50 text-teal-900">
                <th className="border border-slate-300 py-1 font-medium w-8">ردیف</th>
                <th className="border border-slate-300 py-1 font-medium">شرح</th>
                <th className="border border-slate-300 py-1 font-medium w-32">مبلغ</th>
                <th className="border border-slate-300 py-1 font-medium w-24">بیمه‌پذیر</th>
                <th className="border border-slate-300 py-1 font-medium w-8">ردیف</th>
                <th className="border border-slate-300 py-1 font-medium">شرح</th>
                <th className="border border-slate-300 py-1 font-medium w-32">مبلغ</th>
                <th className="border border-slate-300 py-1 font-medium w-24">مشمول مالیات</th>
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: maxRows }).map((_, i) => {
                const e = earnings[i];
                const d = deductions[i];
                const insurable = e ? (e.insurable ? "بله" : "—") : "";
                return (
                  <tr key={i} className={i % 2 ? "bg-slate-50" : ""}>
                    <td className="border border-slate-300 py-1 text-center tabular-nums">{e ? toFaDigits(i + 1) : ""}</td>
                    <td className="border border-slate-300 py-1 pr-1.5">{e?.title || ""}</td>
                    <td className="border border-slate-300 py-1 text-center tabular-nums">{e ? groupFa(e.amount) : ""}</td>
                    <td className="border border-slate-300 py-1 text-center">{insurable}</td>
                    <td className="border border-slate-300 py-1 text-center tabular-nums">{d ? toFaDigits(i + 1) : ""}</td>
                    <td className="border border-slate-300 py-1 pr-1.5">{d?.title || ""}</td>
                    <td className="border border-slate-300 py-1 text-center tabular-nums">{d ? groupFa(d.amount) : ""}</td>
                    <td className="border border-slate-300 py-1 text-center">{d ? "—" : ""}</td>
                  </tr>
                );
              })}
              <tr className="bg-slate-100 font-bold">
                <td className="border border-slate-300 py-1.5" colSpan={2}>جمع حقوق و مزایا</td>
                <td className="border border-slate-300 py-1.5 text-center tabular-nums">{groupFa(p.gross)}</td>
                <td className="border border-slate-300 py-1.5 text-center">مشمول: {groupFa(p.insurableBase)}</td>
                <td className="border border-slate-300 py-1.5" colSpan={2}>جمع کسورات</td>
                <td className="border border-slate-300 py-1.5 text-center tabular-nums">{groupFa(p.employeeSso + p.incomeTax + p.otherDeduction + (p.absenceDeduction || 0))}</td>
                <td className="border border-slate-300 py-1.5 text-center">—</td>
              </tr>
            </tbody>
          </table>

          {/* خلاصه نهایی */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mt-3 text-[11px]">
            <div className="rounded-lg border border-slate-300 p-2.5">
              <p className="text-slate-500 mb-1">مشمول بیمه (حقوق و مزایای بیمه‌پذیر)</p>
              <p className="font-bold tabular-nums">{groupFa(p.insurableBase)} ریال</p>
              <p className="text-slate-400 mt-1 text-[10px]">سهم کارفرما: ۲۰٪ = {groupFa(p.employerSso20)} | بیمه بیکاری ۳٪ = {groupFa(p.unemploymentSso3)}</p>
            </div>
            <div className="rounded-lg border border-slate-300 p-2.5">
              <p className="text-slate-500 mb-1">درآمد مشمول مالیات (پس از کسر بیمه)</p>
              <p className="font-bold tabular-nums">{groupFa(p.taxableIncome)} ریال</p>
              <p className="text-slate-400 mt-1 text-[10px]">مالیات پلکانی ۱۴۰۵: {groupFa(p.incomeTax)} ریال</p>
            </div>
            <div className="rounded-lg bg-teal-700 text-white p-2.5 flex flex-col justify-center">
              <p className="opacity-80 mb-1 text-[10px]">خالص پرداختی (واریزی به حساب)</p>
              <p className="font-bold text-sm tabular-nums">{groupFa(p.netPay)} ریال</p>
              <p className="opacity-70 mt-1 text-[10px]">معادل {groupFa(Math.round(p.netPay / 10))} تومان</p>
            </div>
          </div>

          {/* امضاها */}
          <div className="grid grid-cols-3 gap-6 mt-8 text-center text-[10px] text-slate-500">
            <div className="border-t border-slate-400 pt-1">تهیه‌کننده — کارشناس حقوق و دستمزد</div>
            <div className="border-t border-slate-400 pt-1">تأیید — مدیر مالی</div>
            <div className="border-t border-slate-400 pt-1">امضای کارمند</div>
          </div>
          <p className="text-center text-[9px] text-slate-400 mt-4">این فیش به‌صورت الکترونیکی صادر شده و نیازی به امضای حمایلی ندارد — سامانه جامع منابع انسانی ۱۴۰۵</p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <p className="flex gap-1">
      <span className="text-slate-500 shrink-0">{label}:</span>
      <span className="font-medium truncate">{value}</span>
    </p>
  );
}

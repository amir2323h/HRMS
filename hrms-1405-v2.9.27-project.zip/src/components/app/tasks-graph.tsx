"use client";

// ============================================================
// نمای نودی واگذاری کارها — گراف SVG بومی (بدون کتابخانه خارجی، آفلاین)
// نود = کاربر (سر زنجیره بالا) | یال = جریان واگذاری «از ← به» با آمار وضعیت
// تعامل: پن پس‌زمینه (درگ) + زوم (چرخ/دکمه) + جابه‌جایی نودها + کلیک برای جزئیات
// ============================================================
import { useCallback, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import {
  Network, ZoomIn, ZoomOut, Maximize2, X, Users, Zap,
} from "lucide-react";
import { useApi } from "@/lib/client";
import { formatDateJ, toFaDigits } from "@/lib/jalali";
import {
  TASK_STATUS_LABELS, TASK_STATUS_COLORS, QUADRANTS,
  type GraphResponse, type GraphNode, type GraphEdge, type GraphTaskMini,
} from "@/lib/tasks";

const VW = 1200; // عرض بوم مجازی
const VH = 820; // ارتفاع بوم مجازی
const NW = 168; // عرض نود
const NH = 64; // ارتفاع نود
const LEVEL_GAP = 168; // فاصله عمودی سطوح

interface Pt {
  x: number;
  y: number;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "؟";
  if (parts.length === 1) return parts[0].slice(0, 2);
  return (parts[0][0] || "") + (parts[1][0] || "");
}

/** چیدمان درختی ساده: هر سطح به‌طور مساوی در عرض پخش می‌شود */
function computeLayout(nodes: GraphNode[]): Record<string, Pt> {
  const byLevel = new Map<number, GraphNode[]>();
  for (const n of nodes) {
    if (!byLevel.has(n.level)) byLevel.set(n.level, []);
    byLevel.get(n.level)!.push(n);
  }
  const pos: Record<string, Pt> = {};
  for (const [, group] of [...byLevel.entries()].sort((a, b) => a[0] - b[0])) {
    const y = 80 + group[0].level * LEVEL_GAP;
    const margin = NW / 2 + 30;
    const span = VW - margin * 2;
    group.forEach((n, i) => {
      const x = margin + (group.length === 1 ? span / 2 : (i * span) / (group.length - 1));
      pos[n.id] = { x, y };
    });
  }
  return pos;
}

function edgeColor(e: GraphEdge): string {
  if (e.overdue > 0) return "#e11d48"; // رز — کار عقب‌افتاده در مسیر
  if (e.active > 0) return "#d97706"; // کهربایی — کار باز در جریان
  return "#059669"; // زمرد — همه تمام شده
}

function nodeAccent(n: GraphNode, isRoot: boolean): { stroke: string; ring: string; avatar: string } {
  if (isRoot) return { stroke: "#7c3aed", ring: "rgba(124,58,237,0.25)", avatar: "#7c3aed" };
  if (n.overdueCount > 0) return { stroke: "#e11d48", ring: "rgba(225,29,72,0.22)", avatar: "#e11d48" };
  if (n.activeCount > 0) return { stroke: "#d97706", ring: "rgba(217,119,6,0.22)", avatar: "#d97706" };
  return { stroke: "#059669", ring: "rgba(5,150,105,0.22)", avatar: "#059669" };
}

function bezierPoint(p0: Pt, c1: Pt, c2: Pt, p3: Pt): Pt {
  // نقطه میانی بزیه (t=0.5): (P0 + 3C1 + 3C2 + P3) / 8
  return { x: (p0.x + 3 * c1.x + 3 * c2.x + p3.x) / 8, y: (p0.y + 3 * c1.y + 3 * c2.y + p3.y) / 8 };
}

export function TasksGraph({ meId, onChanged }: { meId: string; onChanged: () => void }) {
  const { data, loading, refetch } = useApi<GraphResponse>("/api/tasks/graph");
  const svgRef = useRef<SVGSVGElement>(null);
  // جابه‌جایی دستی نودها — فقط آفست‌ها نگه داشته می‌شوند؛ چیدمان پایه از داده مشتق می‌شود
  const [nodeOffsets, setNodeOffsets] = useState<Record<string, Pt>>({});
  const [view, setView] = useState({ x: 0, y: 0, k: 1 });
  const [selectedNode, setSelectedNode] = useState<string | null>(null);
  const [selectedEdge, setSelectedEdge] = useState<string | null>(null);
  const [hoverNode, setHoverNode] = useState<string | null>(null);
  const [panelOpen, setPanelOpen] = useState(false);
  const [panning, setPanning] = useState(false);
  // شناسه آخرین داده دیده‌شده — برای بازنشانی انتخاب/نما هنگام داده تازه (الگوی رسمی React در فاز رندر)
  const [lastData, setLastData] = useState<GraphResponse | null | undefined>(undefined);

  // پن (درگ پس‌زمینه) / درگ نود
  const dragRef = useRef<{ mode: "pan" | "node" | null; nodeId?: string; startPointer: Pt; startView?: { x: number; y: number }; startPos?: Pt; moved: boolean }>({ mode: null, startPointer: { x: 0, y: 0 }, moved: false });

  const nodes = data?.nodes || [];
  const edges = data?.edges || [];
  const hasGraph = edges.length > 0;

  // چیدمان پایه از داده (خالص) + ادغام جابه‌جایی دستی
  const layout = useMemo(() => computeLayout(nodes), [nodes]);
  const positions = useMemo(() => {
    const p: Record<string, Pt> = {};
    for (const n of nodes) p[n.id] = nodeOffsets[n.id] ?? layout[n.id];
    return p;
  }, [nodes, layout, nodeOffsets]);

  // داده تازه → بازنشانی انتخاب، آفست‌ها و برازش خودکار نما (تنظیم state در فاز رندر)
  if (data !== lastData) {
    setLastData(data);
    setSelectedNode(null);
    setSelectedEdge(null);
    setPanelOpen(false);
    setNodeOffsets({});
    if (data && data.nodes.length) {
      const ys = Object.values(computeLayout(data.nodes)).map((p) => p.y);
      const minY = Math.min(...ys) - 90;
      const maxY = Math.max(...ys) + 90;
      const k = Math.min(1.15, VH / Math.max(VH, maxY - minY + 40));
      setView({ x: 0, y: minY > 0 ? -minY * k : 0, k });
    } else {
      setView({ x: 0, y: 0, k: 1 });
    }
  }

  const nodeById = useMemo(() => new Map(nodes.map((n) => [n.id, n])), [nodes]);
  const edgeKey = (e: GraphEdge) => `${e.from}→${e.to}`;

  /** تبدیل مختصات کلاینت به مختصات بوم SVG */
  const toSvgPoint = useCallback((clientX: number, clientY: number): Pt => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const rect = svg.getBoundingClientRect();
    const scale = VW / rect.width;
    return { x: (clientX - rect.left) * scale, y: (clientY - rect.top) * (VH / rect.height) };
  }, []);

  /** تبدیل نقطه بوم (پیش از ترنسفورم) به مختصات محتوای گراف */
  const toContent = useCallback((p: Pt): Pt => {
    return { x: (p.x - view.x) / view.k, y: (p.y - view.y) / view.k };
  }, [view]);

  function onPointerDown(e: React.PointerEvent, mode: "pan" | "node", nodeId?: string) {
    (e.target as Element).setPointerCapture?.(e.pointerId);
    if (mode === "pan") setPanning(true);
    dragRef.current = {
      mode,
      nodeId,
      startPointer: { x: e.clientX, y: e.clientY },
      startView: { ...view },
      startPos: nodeId ? positions[nodeId] : undefined,
      moved: false,
    };
  }

  function onPointerMove(e: React.PointerEvent) {
    const d = dragRef.current;
    if (!d.mode) return;
    const dx = e.clientX - d.startPointer.x;
    const dy = e.clientY - d.startPointer.y;
    if (Math.abs(dx) + Math.abs(dy) > 3) d.moved = true;
    if (d.mode === "pan") {
      const rect = svgRef.current?.getBoundingClientRect();
      const sx = rect ? VW / rect.width : 1;
      const sy = rect ? VH / rect.height : 1;
      setView((v) => ({ ...v, x: (d.startView?.x || 0) + dx * sx, y: (d.startView?.y || 0) + dy * sy }));
    } else if (d.mode === "node" && d.nodeId && d.startPos) {
      const rect = svgRef.current?.getBoundingClientRect();
      const sx = rect ? VW / rect.width : 1;
      const sy = rect ? VH / rect.height : 1;
      const nx = d.startPos.x + (dx * sx) / view.k;
      const ny = d.startPos.y + (dy * sy) / view.k;
      setNodeOffsets((o) => ({ ...o, [d.nodeId!]: { x: nx, y: ny } }));
    }
  }

  function onPointerUp(e: React.PointerEvent) {
    const d = dragRef.current;
    dragRef.current = { mode: null, startPointer: { x: 0, y: 0 }, moved: false };
    setPanning(false);
    // کلیک نود (بدون درگ) → انتخاب و پنل جزئیات
    if (d.mode === "node" && !d.moved && d.nodeId) {
      setSelectedNode(d.nodeId);
      setSelectedEdge(null);
      setPanelOpen(true);
    }
  }

  function onWheel(e: React.WheelEvent) {
    e.preventDefault();
    const p = toSvgPoint(e.clientX, e.clientY);
    setView((v) => {
      const k = Math.min(2.5, Math.max(0.4, v.k * (e.deltaY < 0 ? 1.12 : 0.89)));
      // زوم حول نشانگر ماوس
      return { k, x: p.x - ((p.x - v.x) / v.k) * k, y: p.y - ((p.y - v.y) / v.k) * k };
    });
  }

  function zoomBy(factor: number) {
    setView((v) => ({ ...v, k: Math.min(2.5, Math.max(0.4, v.k * factor)) }));
  }

  function fitView(nodeList: GraphNode[]) {
    if (nodeList.length) {
      const ys = Object.values(computeLayout(nodeList)).map((p) => p.y);
      const minY = Math.min(...ys) - 90;
      const maxY = Math.max(...ys) + 90;
      const k = Math.min(1.15, VH / Math.max(VH, maxY - minY + 40));
      setView({ x: 0, y: minY > 0 ? -minY * k : 0, k });
    } else {
      setView({ x: 0, y: 0, k: 1 });
    }
  }

  function resetView() {
    setNodeOffsets({});
    fitView(nodes);
  }

  function autoLayout() {
    setNodeOffsets({});
  }

  const selNode = selectedNode ? nodeById.get(selectedNode) : null;
  const selEdge = selectedEdge ? edges.find((e) => edgeKey(e) === selectedEdge) : null;

  // ---------- درگ‌اند‌دراپ نود روی دسکتاپ (draggable div خارج از SVG نیست — همه داخل SVG) ----------

  if (loading) return <Skeleton className="h-[560px] rounded-2xl" />;

  if (!hasGraph) {
    return (
      <Card className="rounded-2xl">
        <CardContent className="py-16 text-center">
          <Network className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="font-medium text-muted-foreground">هنوز زنجیره واگذاری‌ای وجود ندارد</p>
          <p className="text-xs text-muted-foreground mt-1 max-w-md mx-auto leading-5">
            وقتی کاری را به همکاران بسپارید (یا آن‌ها به دیگران واگذار کنند)، نقشه نودی «چه کسی، به چه کسی، چه کاری» همین‌جا رسم می‌شود.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {/* خلاصه بالای گراف */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <Badge variant="outline" className="gap-1 border-violet-300 bg-violet-50 text-violet-800">
          <Users className="w-3 h-3" /> {toFaDigits(nodes.length - 1)} نفر در زنجیره
        </Badge>
        <Badge variant="outline" className="border-amber-300 bg-amber-50 text-amber-800">
          <Zap className="w-3 h-3" /> {toFaDigits(data?.totalDelegated || 0)} واگذاری ثبت‌شده
        </Badge>
        <div className="flex items-center gap-2 text-muted-foreground mr-auto">
          <span className="hidden sm:inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-600" /> همه انجام شده</span>
          <span className="hidden sm:inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-amber-600" /> کار باز دارد</span>
          <span className="inline-flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-rose-600" /> عقب‌افتاده دارد</span>
        </div>
      </div>

      <div className="relative rounded-2xl border bg-gradient-to-b from-muted/40 to-background overflow-hidden" style={{ height: "min(74vh, 620px)" }}>
        {/* نوار ابزار */}
        <div className="absolute top-2 left-2 z-10 flex flex-col gap-1">
          <Button variant="outline" size="icon" className="h-8 w-8 bg-background/90" onClick={() => zoomBy(1.25)} title="بزرگ‌نمایی" aria-label="بزرگ‌نمایی">
            <ZoomIn className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8 bg-background/90" onClick={() => zoomBy(0.8)} title="کوچک‌نمایی" aria-label="کوچک‌نمایی">
            <ZoomOut className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8 bg-background/90" onClick={autoLayout} title="چیدمان خودکار (بازچینش سطح‌ها)" aria-label="چیدمان خودکار">
            <Network className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon" className="h-8 w-8 bg-background/90" onClick={resetView} title="بازنشانی نما" aria-label="بازنشانی نما">
            <Maximize2 className="w-4 h-4" />
          </Button>
        </div>

        <svg
          ref={svgRef}
          viewBox={`0 0 ${VW} ${VH}`}
          className="w-full h-full touch-none select-none"
          style={{ cursor: panning ? "grabbing" : "default" }}
          onPointerDown={(e) => {
            if ((e.target as Element).closest("[data-node]")) return;
            if ((e.target as Element).closest("[data-edge]")) return;
            onPointerDown(e, "pan");
          }}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerLeave={onPointerUp}
          onWheel={onWheel}
          onDoubleClick={resetView}
          role="application"
          aria-label="نمای نودی زنجیره واگذاری کارها"
        >
          <defs>
            <marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
              <path d="M 0 1 L 9 5 L 0 9 z" fill="context-stroke" opacity="0.9" />
            </marker>
            <pattern id="dots" width="26" height="26" patternUnits="userSpaceOnUse">
              <circle cx="1.5" cy="1.5" r="1" fill="currentColor" opacity="0.12" />
            </pattern>
          </defs>
          <rect x="0" y="0" width={VW} height={VH} fill="url(#dots)" className="text-foreground" />

          <g transform={`translate(${view.x} ${view.y}) scale(${view.k})`}>
            {/* ---------- یال‌ها ---------- */}
            {edges.map((e) => {
              const from = positions[e.from];
              const to = positions[e.to];
              if (!from || !to) return null;
              const p0 = { x: from.x, y: from.y + NH / 2 };
              const p3 = { x: to.x, y: to.y - NH / 2 };
              const dy = Math.max(30, (p3.y - p0.y) * 0.45);
              const c1 = { x: p0.x, y: p0.y + dy };
              const c2 = { x: p3.x, y: p3.y - dy };
              const mid = bezierPoint(p0, c1, c2, p3);
              const key = edgeKey(e);
              const isSel = selectedEdge === key;
              const isHover = hoverNode === e.from || hoverNode === e.to;
              const dimmed = (hoverNode && !isHover) || (selectedNode && !isHover && selectedNode !== e.from && selectedNode !== e.to);
              const color = edgeColor(e);
              return (
                <g key={key} data-edge={key} className="cursor-pointer" opacity={dimmed ? 0.2 : 1}>
                  <path
                    d={`M ${p0.x} ${p0.y} C ${c1.x} ${c1.y}, ${c2.x} ${c2.y}, ${p3.x} ${p3.y}`}
                    fill="none"
                    stroke={color}
                    strokeWidth={isSel || isHover ? 3.5 : 2.2}
                    markerEnd="url(#arrow)"
                    strokeOpacity={isSel || isHover ? 1 : 0.75}
                    onClick={() => { setSelectedEdge(key); setSelectedNode(null); setPanelOpen(true); }}
                  />
                  {/* ناحیه کلیک پهن‌تر برای یال */}
                  <path
                    d={`M ${p0.x} ${p0.y} C ${c1.x} ${c1.y}, ${c2.x} ${c2.y}, ${p3.x} ${p3.y}`}
                    fill="none" stroke="transparent" strokeWidth={16}
                    onClick={() => { setSelectedEdge(key); setSelectedNode(null); setPanelOpen(true); }}
                  />
                  {/* برچسب تعداد کار روی یال */}
                  <g
                    transform={`translate(${mid.x} ${mid.y})`}
                    onClick={() => { setSelectedEdge(key); setSelectedNode(null); setPanelOpen(true); }}
                    data-edge={key}
                  >
                    <rect x={-34} y={-11} width={68} height={22} rx={11} fill="white" stroke={color} strokeWidth={1.5} />
                    <text x={0} y={5} textAnchor="middle" fontSize={11} fontWeight={700} fill={color}>
                      {toFaDigits(e.count)} کار
                    </text>
                    {e.overdue > 0 && (
                      <circle cx={26} cy={-8} r={6} fill="#e11d48">
                        <title>{toFaDigits(e.overdue)} عقب‌افتاده</title>
                      </circle>
                    )}
                  </g>
                </g>
              );
            })}

            {/* ---------- نودها ---------- */}
            {nodes.map((n) => {
              const p = positions[n.id];
              if (!p) return null;
              const isRoot = n.id === meId;
              const acc = nodeAccent(n, isRoot);
              const isSel = selectedNode === n.id;
              const dimmed = (hoverNode && hoverNode !== n.id && !edges.some((e) => (e.from === hoverNode && e.to === n.id) || (e.to === hoverNode && e.from === n.id))) ||
                (selectedNode && selectedNode !== n.id && !edges.some((e) => (e.from === selectedNode && e.to === n.id) || (e.to === selectedNode && e.from === n.id)));
              return (
                <g
                  key={n.id}
                  data-node={n.id}
                  transform={`translate(${p.x} ${p.y})`}
                  className="cursor-grab"
                  opacity={dimmed ? 0.35 : 1}
                  onPointerDown={(e) => { e.stopPropagation(); onPointerDown(e, "node", n.id); }}
                  onPointerEnter={() => setHoverNode(n.id)}
                  onPointerLeave={() => setHoverNode(null)}
                >
                  {/* حلقه تمرکز/انتخاب */}
                  {(isSel || isRoot) && <rect x={-NW / 2 - 6} y={-NH / 2 - 6} width={NW + 12} height={NH + 12} rx={18} fill={acc.ring} />}
                  <rect
                    x={-NW / 2} y={-NH / 2} width={NW} height={NH} rx={14}
                    fill="white" stroke={acc.stroke} strokeWidth={isSel ? 3 : 2}
                    filter={isRoot ? "drop-shadow(0 3px 6px rgba(124,58,237,0.35))" : "drop-shadow(0 2px 4px rgba(0,0,0,0.12))"}
                  />
                  {/* آواتار با حروف اول نام */}
                  <circle cx={-NW / 2 + 26} cy={0} r={17} fill={acc.avatar} />
                  <text x={-NW / 2 + 26} y={5} textAnchor="middle" fontSize={13} fontWeight={700} fill="white">
                    {initials(n.name)}
                  </text>
                  {/* نام و نقش */}
                  <text x={-NW / 2 + 50} y={-8} fontSize={12.5} fontWeight={700} fill="currentColor" className="text-foreground">
                    {n.name.length > 17 ? n.name.slice(0, 16) + "…" : n.name}
                  </text>
                  <text x={-NW / 2 + 50} y={7} fontSize={10} fill="currentColor" className="text-muted-foreground">
                    {isRoot ? "شما — سر زنجیره" : n.roleLabel}
                  </text>
                  {/* نوار وضعیت پایین نود */}
                  <g>
                    {n.activeCount > 0 && (
                      <>
                        <rect x={-NW / 2 + 50} y={14} width={58} height={15} rx={7.5} fill="#fef3c7" stroke="#fcd34d" strokeWidth={0.8} />
                        <text x={-NW / 2 + 79} y={24.5} textAnchor="middle" fontSize={9} fontWeight={700} fill="#b45309">
                          {toFaDigits(n.activeCount)} باز
                        </text>
                      </>
                    )}
                    {n.overdueCount > 0 && (
                      <>
                        <rect x={-NW / 2 + 112} y={14} width={44} height={15} rx={7.5} fill="#ffe4e6" stroke="#fda4af" strokeWidth={0.8} />
                        <text x={-NW / 2 + 134} y={24.5} textAnchor="middle" fontSize={9} fontWeight={700} fill="#be123c">
                          {toFaDigits(n.overdueCount)} عقب
                        </text>
                      </>
                    )}
                    {n.activeCount === 0 && n.overdueCount === 0 && n.doneCount > 0 && (
                      <>
                        <rect x={-NW / 2 + 50} y={14} width={58} height={15} rx={7.5} fill="#d1fae5" stroke="#a7f3d0" strokeWidth={0.8} />
                        <text x={-NW / 2 + 79} y={24.5} textAnchor="middle" fontSize={9} fontWeight={700} fill="#047857">
                          ✓ تمام
                        </text>
                      </>
                    )}
                    {n.activeCount === 0 && n.overdueCount === 0 && n.doneCount === 0 && (
                      <text x={-NW / 2 + 50} y={24.5} fontSize={9} fill="currentColor" className="text-muted-foreground">
                        کار جاری از شما ندارد
                      </text>
                    )}
                  </g>
                </g>
              );
            })}
          </g>
        </svg>

        {/* راهنمای تعامل */}
        <div className="absolute bottom-2 right-2 z-10 text-[10px] text-muted-foreground bg-background/80 rounded-md px-2 py-1 pointer-events-none">
          درگ پس‌زمینه = جابه‌جایی · چرخ ماوس = زوم · درگ نود = چیدمان دستی · دابل‌کلیک = بازنشانی
        </div>

        {/* ---------- پنل جزئیات ---------- */}
        {panelOpen && (selNode || selEdge) && (
          <div className="absolute top-2 bottom-2 left-2 z-20 w-[min(21rem,calc(100%-1rem))]">
            <Card className="rounded-2xl h-full overflow-hidden shadow-xl border-border/80">
              <CardContent className="p-0 h-full flex flex-col">
                <div className="p-3 border-b bg-muted/40">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      {selNode ? (
                        <>
                          <p className="font-bold text-sm truncate">{selNode.name}{selNode.id === meId ? " (شما)" : ""}</p>
                          <p className="text-[11px] text-muted-foreground">{selNode.roleLabel} · سطح {toFaDigits(selNode.level)} زنجیره</p>
                          <div className="flex flex-wrap gap-1 mt-1.5">
                            <Badge variant="outline" className={`text-[10px] ${selNode.activeCount ? "border-amber-300 bg-amber-50 text-amber-800" : "border-emerald-300 bg-emerald-50 text-emerald-700"}`}>
                              {toFaDigits(selNode.activeCount)} کار باز
                            </Badge>
                            {selNode.overdueCount > 0 && <Badge variant="destructive" className="text-[10px]">{toFaDigits(selNode.overdueCount)} عقب‌افتاده</Badge>}
                            <Badge variant="outline" className="text-[10px]">{toFaDigits(selNode.doneCount)} انجام‌شده</Badge>
                          </div>
                        </>
                      ) : selEdge ? (
                        <>
                          <p className="font-bold text-sm truncate">
                            {nodeById.get(selEdge.from)?.name} ← {nodeById.get(selEdge.to)?.name}
                          </p>
                          <p className="text-[11px] text-muted-foreground">جریان واگذاری مستقیم</p>
                          <div className="flex flex-wrap gap-1 mt-1.5">
                            <Badge variant="outline" className="text-[10px]">{toFaDigits(selEdge.count)} کار سپرده‌شده</Badge>
                            <Badge variant="outline" className="text-[10px] border-amber-300 bg-amber-50 text-amber-800">{toFaDigits(selEdge.active)} باز</Badge>
                            {selEdge.overdue > 0 && <Badge variant="destructive" className="text-[10px]">{toFaDigits(selEdge.overdue)} عقب‌افتاده</Badge>}
                          </div>
                        </>
                      ) : null}
                    </div>
                    <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={() => { setPanelOpen(false); setSelectedNode(null); setSelectedEdge(null); }} aria-label="بستن پنل">
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                  <PanelTaskList
                    tasks={(selNode?.tasks || selEdge?.tasks || []) as GraphTaskMini[]}
                    emptyMsg={selNode ? "این کاربر در حال حاضر کاری از استخر واگذاری شما ندارد." : "کاری از این یال باقی نمانده است."}
                  />
                </div>
                <div className="p-2 border-b-0 border-t text-[10px] text-muted-foreground leading-4 bg-muted/30">
                  تغییر وضعیت و واگذاری از تب «ماتریس آیزنهاور» انجام می‌شود.
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

function PanelTaskList({ tasks, emptyMsg }: { tasks: GraphTaskMini[]; emptyMsg: string }) {
  if (tasks.length === 0) return <p className="text-xs text-muted-foreground text-center py-6 leading-5">{emptyMsg}</p>;
  const ordered = [...tasks].sort((a, b) => {
    const rank = (s: string) => (s === "IN_PROGRESS" ? 0 : s === "TODO" ? 1 : 2);
    if (a.overdue !== b.overdue) return a.overdue ? -1 : 1;
    const r = rank(a.status) - rank(b.status);
    if (r) return r;
    if (a.dueDateJ && b.dueDateJ) return a.dueDateJ < b.dueDateJ ? -1 : 1;
    return 0;
  });
  return (
    <>
      {ordered.map((t) => (
        <div key={t.id} className={`rounded-lg border p-2 ${t.overdue ? "border-red-200 bg-red-50/60" : "bg-card"}`}>
          <p className="text-xs font-medium leading-5">{t.title}</p>
          <div className="flex flex-wrap items-center gap-1 mt-1">
            <Badge variant="outline" className={`text-[9px] px-1 py-0 ${TASK_STATUS_COLORS[t.status]}`}>{TASK_STATUS_LABELS[t.status]}</Badge>
            <Badge variant="outline" className={`text-[9px] px-1 py-0 ${QUADRANTS.find((q) => q.q === t.quadrant)?.chip}`}>ربع {toFaDigits(t.quadrant)}</Badge>
            {t.dueDateJ && (
              <Badge variant="outline" className={`text-[9px] px-1 py-0 ${t.overdue ? "border-red-300 text-red-700" : ""}`}>
                مهلت: {formatDateJ(t.dueDateJ)}
              </Badge>
            )}
          </div>
        </div>
      ))}
    </>
  );
}

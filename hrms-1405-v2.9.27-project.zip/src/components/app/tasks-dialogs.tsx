"use client";

// ============================================================
// دیالوگ‌های مدیریت کار — ایجاد/ویرایش کار + واگذاری به کاربر دیگر
// ============================================================
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { api } from "@/lib/client";
import { QUADRANTS, TASK_STATUS_LABELS, TASK_STATUSES, quadrantOf, type TaskRow, type TaskStatus, type TaskUserOption } from "@/lib/tasks";
import { NativeSelect } from "./native-select";
import { JalaliDatePicker } from "./jalali-datepicker";

// ------------------------------------------------------------
// دیالوگ ایجاد/ویرایش کار — انتخاب ربع بصری + مهلت + واگذاری مستقیم
// ------------------------------------------------------------
export function TaskDialog({
  open,
  onOpenChange,
  users,
  canAssign,
  meId,
  initial,
  defaultQuadrant,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  users: TaskUserOption[];
  canAssign: boolean;
  meId: string;
  initial: TaskRow | null;
  defaultQuadrant?: 1 | 2 | 3 | 4;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [quadrant, setQuadrant] = useState<1 | 2 | 3 | 4>(defaultQuadrant || 1);
  const [dueDateJ, setDueDateJ] = useState("");
  const [status, setStatus] = useState<TaskStatus>("TODO");
  const [assigneeId, setAssigneeId] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setError("");
    if (initial) {
      setTitle(initial.title);
      setDescription(initial.description);
      setQuadrant(quadrantOf(initial.important, initial.urgent));
      setDueDateJ(initial.dueDateJ);
      setStatus(initial.status);
      setAssigneeId(initial.assigneeId);
      setNote("");
    } else {
      setTitle("");
      setDescription("");
      setQuadrant(defaultQuadrant || 1);
      setDueDateJ("");
      setStatus("TODO");
      setAssigneeId(meId);
      setNote("");
    }
  }, [open, initial, defaultQuadrant, meId]);

  const qdef = QUADRANTS.find((q) => q.q === quadrant)!;

  async function save() {
    if (!title.trim()) {
      setError("عنوان کار الزامی است.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      const body = {
        title: title.trim(),
        description: description.trim(),
        important: qdef.important,
        urgent: qdef.urgent,
        status,
        dueDateJ,
        ...(canAssign && assigneeId && assigneeId !== (initial?.assigneeId || meId) ? { assigneeId, note: note.trim() } : {}),
      };
      if (initial) {
        await api(`/api/tasks/${initial.id}`, { method: "PATCH", json: body });
        toast({ title: "کار به‌روزرسانی شد" });
      } else {
        await api("/api/tasks", { method: "POST", json: body });
        toast({ title: "کار جدید ثبت شد", description: `ربع ${qdef.title}` });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در ذخیره کار");
    } finally {
      setSaving(false);
    }
  }

  const otherUsers = users.filter((u) => u.id !== meId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{initial ? "ویرایش کار" : "کار جدید"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="task-title">عنوان کار *</Label>
            <Input
              id="task-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثلاً: تهیه گزارش بیمه ماهانه"
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="task-desc">توضیحات</Label>
            <Textarea
              id="task-desc"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="جزئیات، خروجی مورد انتظار یا لینک مرتبط…"
            />
          </div>

          <div className="space-y-1.5">
            <Label>ربع ماتریس آیزنهاور</Label>
            <div className="grid grid-cols-2 gap-2">
              {QUADRANTS.map((q) => (
                <button
                  key={q.q}
                  type="button"
                  onClick={() => setQuadrant(q.q)}
                  className={`rounded-xl border-2 p-3 text-right transition-all ${quadrant === q.q ? `${q.ring} bg-card shadow-sm` : "border-transparent bg-muted/50 hover:bg-muted"}`}
                  aria-pressed={quadrant === q.q}
                >
                  <span className="flex items-center gap-1.5">
                    <span className={`w-2.5 h-2.5 rounded-full ${q.bar}`} aria-hidden />
                    <span className="text-sm font-semibold">{q.title}</span>
                  </span>
                  <span className="block text-xs text-muted-foreground mt-1">{q.subtitle}</span>
                  <span className="block text-[10px] text-muted-foreground/70 mt-0.5">
                    {q.urgent ? "فوری" : "غیرفوری"} · {q.important ? "مهم" : "غیرمهم"}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>مهلت انجام</Label>
              <JalaliDatePicker value={dueDateJ} onChange={setDueDateJ} placeholder="بدون مهلت" />
            </div>
            <div className="space-y-1.5">
              <Label>وضعیت</Label>
              <NativeSelect value={status} onChange={(v) => setStatus(v as TaskStatus)} ariaLabel="وضعیت کار">
                {TASK_STATUSES.map((s) => (
                  <option key={s} value={s}>{TASK_STATUS_LABELS[s]}</option>
                ))}
              </NativeSelect>
            </div>
          </div>

          {canAssign && (
            <div className="space-y-3 rounded-xl border border-dashed border-amber-300 bg-amber-50/60 p-3">
              <div className="space-y-1.5">
                <Label>مسئول کار</Label>
                <NativeSelect
                  value={assigneeId}
                  onChange={setAssigneeId}
                  ariaLabel="مسئول کار"
                >
                  <option value={meId}>خودم</option>
                  {otherUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.fullName} ({u.roleLabel})
                    </option>
                  ))}
                </NativeSelect>
                <p className="text-[11px] text-muted-foreground leading-5">
                  انتخاب کاربر دیگر = واگذاری کار؛ زنجیره واگذاری برای پیگیری مدیر ثبت می‌شود.
                </p>
              </div>
              {assigneeId !== meId && (
                <div className="space-y-1.5">
                  <Label htmlFor="task-note">پیام واگذاری</Label>
                  <Input
                    id="task-note"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="مثلاً: تا پنجشنبه آماده کن"
                  />
                </div>
              )}
            </div>
          )}

          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving}>{saving ? "در حال ذخیره…" : initial ? "ذخیره تغییرات" : "ثبت کار"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ------------------------------------------------------------
// دیالوگ واگذاری — انتقال کار به کاربر دیگر + پیام
// ------------------------------------------------------------
export function DelegateDialog({
  open,
  onOpenChange,
  task,
  users,
  meId,
  onSaved,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  task: TaskRow | null;
  users: TaskUserOption[];
  meId: string;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [assigneeId, setAssigneeId] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!open) return;
    setError("");
    setNote("");
    setAssigneeId(task && task.assigneeId !== meId ? task.assigneeId : "");
  }, [open, task, meId]);

  const candidates = users.filter((u) => u.id !== meId && u.id !== task?.assigneeId);

  async function delegate() {
    if (!task || !assigneeId) {
      setError("کاربر واگذاری را انتخاب کنید.");
      return;
    }
    setSaving(true);
    setError("");
    try {
      await api(`/api/tasks/${task.id}`, { method: "PATCH", json: { assigneeId, note: note.trim() } });
      const target = users.find((u) => u.id === assigneeId);
      toast({ title: "کار واگذار شد", description: `«${task.title}» به ${target?.fullName || "کاربر"} سپرده شد` });
      onOpenChange(false);
      onSaved();
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در واگذاری کار");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>واگذاری کار</DialogTitle>
        </DialogHeader>
        {task && (
          <div className="rounded-lg bg-muted/60 p-3">
            <p className="text-sm font-medium leading-5">{task.title}</p>
            <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
              <Badge variant="outline" className="text-[11px]">
                مسئول فعلی: {task.assigneeId === meId ? "خودم" : task.assigneeName}
              </Badge>
              {task.delegationCount > 0 && (
                <Badge variant="outline" className="text-[11px]">
                  {task.delegationCount} واگذاری در زنجیره
                </Badge>
              )}
            </div>
          </div>
        )}
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>واگذار به *</Label>
            <NativeSelect value={assigneeId} onChange={setAssigneeId} placeholder="انتخاب کاربر…" ariaLabel="کاربر واگذاری">
              {candidates.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.fullName} ({u.roleLabel})
                </option>
              ))}
            </NativeSelect>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="delegate-note">پیام واگذاری</Label>
            <Input
              id="delegate-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="مثلاً: لطفاً تا پایان هفته آماده کن"
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={delegate} disabled={saving || !assigneeId}>{saving ? "در حال واگذاری…" : "واگذاری"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

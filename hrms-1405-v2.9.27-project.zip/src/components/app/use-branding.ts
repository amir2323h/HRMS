"use client";

// ============================================================
// هوک برندینگ — با کش لوکال برای نمایش آنی لوگو/عنوان
// کش localStorage فقط «پس از هیدریشن» اعمال می‌شود (useLayoutEffect
// قبل از پینت) — خواندن همگام در رندر اول باعث واگرایی SSR/کلاینت
// (Hydration Mismatch در بازدید دوم به بعد) می‌شد و ممکن بود صفحه
// در حالت بارگذاری گیر کند. اکنون اولین رندر کلاینت = سرور است.
// ============================================================
import { useEffect, useLayoutEffect, useState } from "react";
import { useApi } from "@/lib/client";

export interface BrandInfo {
  title: string;
  subtitle: string;
  logo: string;
  favicon: string;
  companyName: string;
  footerText: string;
  version?: string; // نسخه نصب‌شده (env APP_VERSION) — فوتر/صفحه ورود
  demoMode?: boolean; // حالت دمو — نمایش حساب‌های نمونه در صفحه ورود (پیش‌فرض خاموش)
  companyNationalId?: string; // شناسه ملی — سربرگ/پابرگ نامه‌ها
  companyAddress?: string; // نشانی — پابرگ نامه‌ها
  companyPhone?: string; // تلفن — پابرگ نامه‌ها
  companyMobile?: string; // موبایل — پابرگ نامه‌ها
  companyWebsite?: string; // وب‌سایت — پابرگ نامه‌ها
  companyEmail?: string; // ایمیل — پابرگ نامه‌ها
}

const CACHE_KEY = "hrms_branding_cache";

function readCache(): Partial<BrandInfo> | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(CACHE_KEY);
    return raw ? (JSON.parse(raw) as Partial<BrandInfo>) : null;
  } catch {
    return null;
  }
}

// در سرور useEffect (بدون هشدار SSR) — در کلاینت useLayoutEffect (قبل از پینت، بدون فلش)
const useIsomorphicLayoutEffect = typeof window !== "undefined" ? useLayoutEffect : useEffect;

export function useBranding() {
  // کش لوکال پس از هیدریشن — اولین رندر کلاینت دقیقاً مطابق سرور (بدون لوگو)
  const [cached, setCached] = useState<Partial<BrandInfo> | null>(null);
  useIsomorphicLayoutEffect(() => {
    const c = readCache();
    if (c) setCached(c);
  }, []);
  const { data, loading } = useApi<{ branding: BrandInfo }>("/api/branding");

  // نوشتن کش برای بارگذاری بعدی (بدون به‌روزرسانی state — رندر از داده تازه)
  useEffect(() => {
    if (data?.branding) {
      try {
        window.localStorage.setItem(CACHE_KEY, JSON.stringify(data.branding));
      } catch {
        /* حالت ناشناس/محدود */
      }
    }
  }, [data]);

  const brand = data?.branding || cached || null;
  return { brand, loading };
}

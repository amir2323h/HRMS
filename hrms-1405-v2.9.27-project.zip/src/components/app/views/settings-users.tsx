"use client";

// ============================================================
// مدیریت کاربران سامانه — در تنظیمات
// CRUD + ایمپورت اکسل + اتصال به پرونده کارمند + تغییر گروهی نقش
// فقط مدیر کل دسترسی ویرایش دارد
// ============================================================
import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, UserCog, Upload, Download, Trash2, Edit3, KeyRound, ShieldQuestion, Users } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { ROLE_LABELS } from "@/lib/format";
import { formatDateJ, toFaDigits } from "@/lib/jalali";
import { ExcelImportDialog, type ImportOutcome } from "../excel-import-dialog";
import { downloadExcel, pick, cellStr, cellBool } from "@/lib/excel";

// تاریخ ISO آخرین ورود → نمایش جلالی خوانا
function lastLoginDisplay(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  const j = iso.slice(0, 10).replace(/-/g, "/");
  return `${formatDateJ(j)} — ${toFaDigits(String(d.getHours()).padStart(2, "0"))}:${toFaDigits(String(d.getMinutes()).padStart(2, "0"))}`;
}

export interface UserRow {
  id: string;
  username: string;
  fullName: string;
  role: string;
  roleId: string | null;
  roleLabel: string;
  employeeId: string | null;
  employeeName: string;
  personnelCode: string;
  oauthProvider: string;
  oauthEmail: string;
  isActive: boolean;
  lastLoginAt: string | null;
  twoFaEnrolled?: boolean;
  createdAt: string;
}

interface EmployeeLite { id: string; personnelCode: string; fullName: string }

const ROLE_BADGES: Record<string, string> = {
  SUPER_ADMIN: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  HR_MANAGER: "bg-teal-100 text-teal-700 hover:bg-teal-100",
  PAYROLL_OFFICER: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  DEPT_MANAGER: "bg-violet-100 text-violet-700 hover:bg-violet-100",
  EMPLOYEE: "bg-slate-100 text-slate-600 hover:bg-slate-100",
};

/** نقش اکسل: کد لاتین یا برچسب فارسی */
export function parseRoleCell(raw: unknown): string {
  const s = cellStr(raw).trim();
  if (!s) return "";
  const upper = s.toUpperCase().replace(/\s+/g, "_");
  const codes = ["SUPER_ADMIN", "HR_MANAGER", "PAYROLL_OFFICER", "DEPT_MANAGER", "EMPLOYEE"];
  if (codes.includes(upper)) return upper;
  for (const [code, label] of Object.entries(ROLE_LABELS)) {
    if (s === label || s.replace(/\s+/g, "_") === label.replace(/\s+/g, "_")) return code;
  }
  return "";
}

export function UsersManager({ canEdit, currentUsername }: { canEdit: boolean; currentUsername?: string }) {
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const list = useApi<{ users: UserRow[]; roles: { id: string; key: string; name: string; isSystem: boolean }[] }>("/api/users");
  const employees = useApi<{ employees: EmployeeLite[] }>("/api/employees");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<UserRow | null>(null);
  const [importOpen, setImportOpen] = useState(false);
  const [bulkRoleOpen, setBulkRoleOpen] = useState(false); // تغییر گروهی نقش
  const [selected, setSelected] = useState<Set<string>>(new Set()); // کاربران انتخاب‌شده برای عملیات گروهی
  const roles = list.data?.roles || [];

  const rows = useMemo(() => {
    const all = list.data?.users || [];
    if (!q.trim()) return all;
    const t = q.trim().toLowerCase();
    return all.filter((u) => u.username.toLowerCase().includes(t) || u.fullName.includes(t) || (u.personnelCode || "").toLowerCase().includes(t));
  }, [list.data, q]);

  // پاک‌سازی انتخاب‌ها پس از هر بارگیری مجدد (کاربر حذف‌شده از انتخاب خارج شود)
  useEffect(() => {
    setSelected((prev) => {
      if (prev.size === 0) return prev;
      const alive = new Set((list.data?.users || []).map((u) => u.id));
      const next = new Set([...prev].filter((id) => alive.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [list.data]);

  const allShownSelected = rows.length > 0 && rows.every((u) => selected.has(u.id));
  function toggleAllShown(checked: boolean) {
    setSelected((prev) => {
      const next = new Set(prev);
      for (const u of rows) { if (checked) next.add(u.id); else next.delete(u.id); }
      return next;
    });
  }
  function toggleOne(id: string, checked: boolean) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id); else next.delete(id);
      return next;
    });
  }

  async function toggleActive(user: UserRow) {
    try {
      await api(`/api/users/${user.id}`, { method: "PATCH", json: { isActive: !user.isActive } });
      list.refetch();
      toast({ title: user.isActive ? "کاربر غیرفعال شد" : "کاربر فعال شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function reset2fa(user: UserRow) {
    if (!confirm(`بازنشانی ورود دو مرحله‌ای «${user.fullName}»؟\nراز 2FA او پاک می‌شود و در ورود بعدی دوباره ثبت‌نام می‌کند (QR جدید).`)) return;
    try {
      await api(`/api/users/${user.id}`, { method: "PATCH", json: { reset2fa: true } });
      await list.refetch();
      toast({ title: "2FA بازنشانی شد", description: `${user.fullName} در ورود بعدی QR راه‌اندازی جدید می‌گیرد.` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function remove(user: UserRow) {
    try {
      await api(`/api/users/${user.id}`, { method: "DELETE" });
      list.refetch();
      toast({ title: `کاربر «${user.username}» حذف شد` });
    } catch (e) {
      toast({ title: "حذف ممکن نیست", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  function exportExcel() {
    const data = (list.data?.users || []).map((u) => ({
      "نام کاربری": u.username,
      "نام و نام خانوادگی": u.fullName,
      "رمز عبور": "",
      "نقش": u.roleLabel || ROLE_LABELS[u.role] || u.role,
      "کد پرسنلی": u.personnelCode,
      "فعال": u.isActive ? "بله" : "خیر",
    }));
    downloadExcel("کاربران.xlsx", "کاربران", data);
  }

  function parseUserRow(row: Record<string, unknown>): { data: { username: string; fullName: string; password: string; role: string; personnelCode: string; isActive: boolean }; errors: string[] } {
    const errors: string[] = [];
    const username = cellStr(pick(row, ["نام کاربری", "username"])).toLowerCase();
    const fullName = cellStr(pick(row, ["نام و نام خانوادگی", "نام", "fullName"]));
    const password = cellStr(pick(row, ["رمز عبور", "رمز", "password"]));
    const role = parseRoleCell(pick(row, ["نقش", "سمت", "نقش کاربری"]));
    const personnelCode = cellStr(pick(row, ["کد پرسنلی", "personnelCode"]));
    const isActive = cellBool(pick(row, ["فعال", "وضعیت"]), true);

    if (!username) errors.push("نام کاربری خالی است.");
    else if (!/^[a-z0-9._-]{3,30}$/.test(username)) errors.push("نام کاربری نامعتبر (۳ تا ۳۰ کاراکتر لاتین).");
    if (!fullName) errors.push("نام و نام خانوادگی خالی است.");
    if (password && password.length < 6) errors.push("رمز عبور کمتر از ۶ کاراکتر است.");
    if (!role) errors.push("نقش نامعتبر است (مدیر کل سیستم / مدیر منابع انسانی / کارشناس حقوق و دستمزد / مدیر دپارتمان / کارمند).");
    return { data: { username, fullName, password, role, personnelCode, isActive }, errors };
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <UserCog className="w-4 h-4 text-teal-600" /> کاربران و دسترسی‌ها
            <Badge variant="outline">{toFaDigits(rows.length)} کاربر</Badge>
            {!canEdit && <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">فقط مشاهده</Badge>}
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1 leading-5">
            کاربران سامانه با نقش‌های پنج‌گانه — با ایمپورت اکسل می‌توانید گروهی از کاربران را ساخت و هر کاربر را با «کد پرسنلی» به پرونده کارمند متصل کرد.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* نوار ابزار */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input className="pr-9" placeholder="جستجو: نام کاربری، نام، کد پرسنلی..." value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <Button variant="outline" className="gap-1.5" onClick={exportExcel}>
              <Download className="w-4 h-4" /> خروجی اکسل
            </Button>
            {canEdit && (
              <>
                <Button variant="outline" className="gap-1.5" onClick={() => setImportOpen(true)}>
                  <Upload className="w-4 h-4" /> ایمپورت اکسل
                </Button>
                <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
                  <Plus className="w-4 h-4" /> کاربر جدید
                </Button>
              </>
            )}
          </div>

          {/* نوار عملیات گروهی — وقتی کاربری انتخاب شده باشد */}
          {canEdit && selected.size > 0 && (
            <div className="flex flex-wrap items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2">
              <Users className="w-4 h-4 text-amber-700" />
              <span className="text-xs font-bold text-amber-900">{toFaDigits(selected.size)} کاربر انتخاب شده</span>
              <Button
                size="sm"
                className="h-8 gap-1.5 bg-amber-600 hover:bg-amber-700"
                onClick={() => setBulkRoleOpen(true)}
              >
                <Users className="w-3.5 h-3.5" /> تغییر گروهی نقش
              </Button>
              <Button size="sm" variant="ghost" className="h-8 text-amber-800 hover:bg-amber-100" onClick={() => setSelected(new Set())}>
                لغو انتخاب
              </Button>
            </div>
          )}

          {/* جدول */}
          {list.loading ? (
            <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-11" />)}</div>
          ) : rows.length === 0 ? (
            <div className="py-10 text-center">
              <UserCog className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">کاربری یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    {canEdit && (
                      <TableHead className="w-10">
                        <Checkbox
                          aria-label="انتخاب همه کاربران"
                          checked={allShownSelected ? true : rows.some((u) => selected.has(u.id)) ? "indeterminate" : false}
                          onCheckedChange={(v) => toggleAllShown(v === true)}
                        />
                      </TableHead>
                    )}
                    <TableHead className="text-right">نام کاربری</TableHead>
                    <TableHead className="text-right">نام و نام خانوادگی</TableHead>
                    <TableHead className="text-center">نقش</TableHead>
                    <TableHead className="text-right">پرونده متصل</TableHead>
                    <TableHead className="text-center">آخرین ورود</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    {canEdit && <TableHead className="text-center">عملیات</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((u) => (
                    <TableRow key={u.id} className={selected.has(u.id) ? "bg-amber-50/60 hover:bg-amber-50" : "hover:bg-teal-50/40"}>
                      {canEdit && (
                        <TableCell>
                          <Checkbox
                            aria-label={`انتخاب ${u.fullName}`}
                            checked={selected.has(u.id)}
                            onCheckedChange={(v) => toggleOne(u.id, v === true)}
                          />
                        </TableCell>
                      )}
                      <TableCell className="tabular-nums text-sm font-medium" dir="ltr">
                        {u.username}
                        {u.username === currentUsername && <Badge className="mr-1.5 bg-teal-100 text-teal-700 hover:bg-teal-100">شما</Badge>}
                      </TableCell>
                      <TableCell className="text-sm">{u.fullName}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={ROLE_BADGES[u.role] || ""}>{u.roleLabel}</Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {u.employeeName ? (
                          <span>{u.employeeName} <span className="text-[11px] text-muted-foreground tabular-nums" dir="ltr">({u.personnelCode})</span></span>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </TableCell>
                      <TableCell className="text-center text-xs text-muted-foreground tabular-nums">{lastLoginDisplay(u.lastLoginAt)}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={u.isActive ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                          {u.isActive ? "فعال" : "غیرفعال"}
                        </Badge>
                      </TableCell>
                      {canEdit && (
                        <TableCell className="text-center">
                          <div className="flex justify-center gap-1">
                            <button className="p-1.5 rounded-lg hover:bg-amber-100 text-amber-600" title="ویرایش" onClick={() => { setEditing(u); setFormOpen(true); }}>
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              className={`p-1.5 rounded-lg ${u.isActive ? "hover:bg-slate-100 text-slate-500" : "hover:bg-emerald-100 text-emerald-600"}`}
                              title={u.isActive ? "غیرفعال کردن" : "فعال کردن"}
                              onClick={() => toggleActive(u)}
                            >
                              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
                                {u.isActive ? <path d="M18.36 6.64A9 9 0 1 1 5.64 6.64M12 2v10" strokeLinecap="round" /> : <path d="M12 2v10m6.36-5.36A9 9 0 1 1 5.64 6.64" strokeLinecap="round" />}
                              </svg>
                            </button>
                            {u.twoFaEnrolled && (
                              <button
                                className="p-1.5 rounded-lg hover:bg-violet-100 text-violet-600"
                                title="بازنشانی ورود دو مرحله‌ای (اگر کاربر اپ احرازکننده را گم کرده)"
                                onClick={() => reset2fa(u)}
                              >
                                <ShieldQuestion className="w-4 h-4" />
                              </button>
                            )}
                            <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title="حذف" onClick={() => remove(u)}>
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* فرم کاربر */}
      <UserForm
        open={formOpen}
        onOpenChange={setFormOpen}
        editing={editing}
        roles={roles}
        employees={(employees.data?.employees || []).map((e) => ({ id: e.id, fullName: e.fullName, personnelCode: e.personnelCode }))}
        onSaved={() => { list.refetch(); toast({ title: editing ? "کاربر به‌روزرسانی شد" : "کاربر جدید ایجاد شد", description: "در لاگ حسابرسی ثبت گردید." }); }}
      />

      {/* ایمپورت اکسل */}
      {canEdit && (
        <ExcelImportDialog
          open={importOpen}
          onOpenChange={setImportOpen}
          title="ایمپورت کاربران از اکسل"
          description="فایل اکسل شامل کاربران را انتخاب کنید. کاربران موجود (بر اساس نام کاربری) به‌روزرسانی می‌شوند و کاربران جدید ایجاد می‌شوند. رمز عبور در خروجی اکسل خالی است — در فایل ایمپورت الزامی است."
          endpoint="/api/users/import"
          templateFilename="قالب-کاربران.xlsx"
          sheetName="کاربران"
          headers={["نام کاربری", "نام و نام خانوادگی", "رمز عبور", "نقش", "کد پرسنلی (اختیاری)", "فعال (بله/خیر)"]}
          sampleRows={[
            { "نام کاربری": "ali.rezaei", "نام و نام خانوادگی": "علی رضایی", "رمز عبور": "123456", "نقش": "کارمند", "کد پرسنلی": "EMP-1005", "فعال": "بله" },
            { "نام کاربری": "hr2", "نام و نام خانوادگی": "مریم احمدی", "رمز عبور": "pass1234", "نقش": "مدیر منابع انسانی", "کد پرسنلی": "", "فعال": "بله" },
          ]}
          parseRow={parseUserRow}
          onImported={(_outcome: ImportOutcome) => list.refetch()}
        />
      )}
      {/* تغییر گروهی نقش */}
      {canEdit && (
        <BulkRoleDialog
          open={bulkRoleOpen}
          onOpenChange={(v) => { setBulkRoleOpen(v); if (!v) setSelected(new Set()); }}
          ids={[...selected]}
          users={list.data?.users || []}
          roles={roles}
          currentUsername={currentUsername}
          onDone={() => list.refetch()}
        />
      )}
    </div>
  );
}

// ================= تغییر گروهی نقش =================
interface BulkRoleResult {
  updatedCount: number;
  skippedCount: number;
  updated: { username: string; fullName: string }[];
  skipped: { id: string; username: string; name: string; reason: string }[];
  roleLabel: string;
}

function BulkRoleDialog({ open, onOpenChange, ids, users, roles, currentUsername, onDone }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  ids: string[];
  users: UserRow[];
  roles: { id: string; key: string; name: string; isSystem: boolean }[];
  currentUsername?: string;
  onDone: () => void;
}) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [roleId, setRoleId] = useState("");
  const [result, setResult] = useState<BulkRoleResult | null>(null);

  // با هر بازشدن، فرم و نتیجه قبلی ریست می‌شود
  useEffect(() => {
    if (open) { setResult(null); setRoleId(""); }
  }, [open]);

  const target = useMemo(() => {
    const byId = new Map(users.map((u) => [u.id, u]));
    return ids.map((id) => byId.get(id)).filter((u): u is UserRow => !!u);
  }, [ids, users]);

  const role = roles.find((r) => r.id === roleId) || null;

  // پیش‌نمایش: چه کسانی تغییر می‌کنند و چه کسانی رد می‌شوند
  const preview = target.map((u) => {
    let ok = true;
    let why = "";
    if (u.username === currentUsername) { ok = false; why = "حساب خودتان"; }
    else if (role && (u.roleId === role.id || u.role === role.key)) { ok = false; why = `از قبل «${role.name}»`; }
    return { u, ok, why };
  });
  const changeCount = preview.filter((p) => p.ok).length;

  async function apply() {
    if (!role) return;
    setBusy(true);
    try {
      const d = await api<BulkRoleResult>("/api/users/bulk-role", {
        method: "POST",
        json: { ids: target.map((u) => u.id), roleId: role.id },
      });
      setResult(d);
      if (d.updatedCount > 0) {
        toast({
          title: `نقش ${toFaDigits(d.updatedCount)} کاربر به «${d.roleLabel}» تغییر کرد`,
          description: d.skippedCount > 0 ? `${toFaDigits(d.skippedCount)} نفر رد شدند — جزئیات در دیالوگ.` : undefined,
        });
      } else {
        toast({ title: "هیچ تغییری اعمال نشد", description: "همه کاربران انتخابی رد شدند — دلایل در دیالوگ.", variant: "destructive" });
      }
      onDone();
    } catch (e) {
      toast({ title: "خطا در تغییر گروهی نقش", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[42rem] max-h-[88vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-800">
            <Users className="w-5 h-5" />
            تغییر گروهی نقش {ids.length > 0 ? `(${toFaDigits(ids.length)} کاربر)` : ""}
          </DialogTitle>
        </DialogHeader>

        {!result ? (
          <div className="space-y-4">
            <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-xs leading-6 text-amber-900">
              <p className="font-bold mb-1">نقش جدید برای همه کاربران انتخابی:</p>
              <Select value={roleId} onValueChange={setRoleId}>
                <SelectTrigger className="h-8 w-full mt-1 border-amber-300">
                  <SelectValue placeholder="انتخاب نقش جدید…">{role ? role.name : ""}</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {roles.map((r) => (
                    <SelectItem key={r.id} value={r.id}>{r.name}{r.isSystem ? " (سیستمی)" : ""}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="mt-1">حساب کاربری خودتان و آخرین مدیر کل فعال سامانه به‌صورت خودکار رد می‌شوند و تغییری نمی‌کنند.</p>
            </div>

            <div className="rounded-xl border overflow-hidden">
              <div className="max-h-56 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-50/80">
                      <TableHead className="text-right">کاربر</TableHead>
                      <TableHead className="text-center">نقش فعلی</TableHead>
                      <TableHead className="text-center">وضعیت</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {preview.map((p) => (
                      <TableRow key={p.u.id}>
                        <TableCell>
                          <span className="font-medium text-sm">{p.u.fullName}</span>
                          <span className="block text-[10px] text-muted-foreground tabular-nums" dir="ltr">{p.u.username}{p.u.username === currentUsername ? " (شما)" : ""}</span>
                        </TableCell>
                        <TableCell className="text-center"><Badge className={ROLE_BADGES[p.u.role] || ""}>{p.u.roleLabel}</Badge></TableCell>
                        <TableCell className="text-center">
                          {!role
                            ? <Badge className="bg-slate-100 text-slate-500 hover:bg-slate-100">نقش جدید را انتخاب کنید</Badge>
                            : p.ok
                              ? <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">تغییر می‌کند</Badge>
                              : <Badge className="bg-slate-100 text-slate-500 hover:bg-slate-100">{p.why}</Badge>}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            <p className="text-xs text-muted-foreground">
              {role
                ? changeCount > 0
                  ? <><b className="text-emerald-700">{toFaDigits(changeCount)} کاربر</b> به نقش «<b>{role.name}</b>» تغییر می‌کنند{preview.length - changeCount > 0 ? <> — <b>{toFaDigits(preview.length - changeCount)}</b> رد می‌شوند.</> : "."}</>
                  : "هیچ‌کدام از کاربران انتخابی تغییر نمی‌کنند."
                : "برای مشاهده پیش‌نمایش، نقش جدید را انتخاب کنید."}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className={`rounded-xl border p-3 text-sm ${result.updatedCount > 0 ? "border-emerald-200 bg-emerald-50 text-emerald-900" : "border-amber-200 bg-amber-50 text-amber-900"}`}>
              <p className="font-bold">
                {result.updatedCount > 0
                  ? `نقش ${toFaDigits(result.updatedCount)} کاربر به «${result.roleLabel}» تغییر کرد.`
                  : "هیچ تغییری اعمال نشد."}
              </p>
              {result.updatedCount > 0 && <p className="text-xs mt-1">کاربران در ورود بعدی با دسترسی‌های نقش جدید وارد می‌شوند.</p>}
            </div>

            {result.updated.length > 0 && (
              <div className="rounded-xl border overflow-hidden">
                <p className="px-3 py-2 bg-emerald-50 text-xs font-bold text-emerald-900">تغییرکردگان ({toFaDigits(result.updated.length)})</p>
                <div className="max-h-40 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50/80">
                        <TableHead className="text-right">کاربر</TableHead>
                        <TableHead className="text-left">نام کاربری</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {result.updated.map((c) => (
                        <TableRow key={c.username}>
                          <TableCell className="text-sm font-medium">{c.fullName}</TableCell>
                          <TableCell className="text-xs tabular-nums" dir="ltr">{c.username}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}

            {result.skipped.length > 0 && (
              <div className="rounded-xl border border-amber-200 overflow-hidden">
                <p className="px-3 py-2 bg-amber-50 text-xs font-bold text-amber-900">ردشده‌ها ({toFaDigits(result.skipped.length)})</p>
                <div className="max-h-40 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50/80">
                        <TableHead className="text-right">کاربر</TableHead>
                        <TableHead className="text-right">دلیل</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {result.skipped.map((s) => (
                        <TableRow key={s.id + s.username}>
                          <TableCell className="text-sm">{s.name}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{s.reason}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </div>
        )}

        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>بستن</Button>
          {!result && (
            <Button className="bg-amber-600 hover:bg-amber-700 gap-1.5" onClick={apply} disabled={busy || !role || changeCount === 0}>
              {busy ? "در حال اعمال…" : <><Users className="w-4 h-4" /> تغییر نقش {toFaDigits(changeCount)} کاربر به «{role?.name || "…"}»</>}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= فرم کاربر =================
function UserForm({ open, onOpenChange, editing, roles, employees, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: UserRow | null;
  roles: { id: string; key: string; name: string; isSystem: boolean }[];
  employees: { id: string; fullName: string; personnelCode: string }[];
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [f, setF] = useState(() => ({
    username: editing?.username || "",
    fullName: editing?.fullName || "",
    password: "",
    roleId: editing?.roleId || "",
    employeeId: editing?.employeeId || "none",
    isActive: editing?.isActive ?? true,
  }));
  const [lastKey, setLastKey] = useState(editing?.id || "new");
  const key = editing?.id || "new";
  if (lastKey !== key) {
    setLastKey(key);
    setF({
      username: editing?.username || "",
      fullName: editing?.fullName || "",
      password: "",
      roleId: editing?.roleId || "",
      employeeId: editing?.employeeId || "none",
      isActive: editing?.isActive ?? true,
    });
  }

  async function save() {
    const errors: string[] = [];
    if (!editing && !/^[a-z0-9._-]{3,30}$/.test(f.username.trim().toLowerCase())) errors.push("نام کاربری نامعتبر است (۳ تا ۳۰ کاراکتر لاتین).");
    if (!f.fullName.trim()) errors.push("نام و نام خانوادگی الزامی است.");
    if (!editing && f.password.length < 6) errors.push("رمز عبور باید حداقل ۶ کاراکتر باشد.");
    if (editing && f.password && f.password.length < 6) errors.push("رمز عبور باید حداقل ۶ کاراکتر باشد.");
    if (errors.length) {
      toast({ title: errors[0], variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        const payload: Record<string, unknown> = {
          fullName: f.fullName.trim(),
          roleId: f.roleId || undefined,
          employeeId: f.employeeId === "none" ? null : f.employeeId,
          isActive: f.isActive,
        };
        if (f.password) payload.password = f.password;
        await api(`/api/users/${editing.id}`, { method: "PATCH", json: payload });
      } else {
        await api("/api/users", {
          method: "POST",
          json: {
            username: f.username.trim().toLowerCase(),
            fullName: f.fullName.trim(),
            password: f.password,
            roleId: f.roleId || undefined,
            employeeId: f.employeeId === "none" ? null : f.employeeId,
            isActive: f.isActive,
          },
        });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? `ویرایش کاربر — ${editing.username}` : "ایجاد کاربر جدید"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">نام کاربری <span className="text-rose-600">*</span></Label>
            <Input dir="ltr" className="text-left" value={f.username} disabled={!!editing} onChange={(e) => setF({ ...f, username: e.target.value.toLowerCase() })} placeholder="مثلاً ali.rezaei" />
            {editing && <p className="text-[10px] text-muted-foreground">نام کاربری قابل تغییر نیست</p>}
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نام و نام خانوادگی <span className="text-rose-600">*</span></Label>
            <Input value={f.fullName} onChange={(e) => setF({ ...f, fullName: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">
              {editing ? <>رمز عبور جدید <span className="text-muted-foreground">(خالی = بدون تغییر)</span></> : <>رمز عبور <span className="text-rose-600">*</span></>}
            </Label>
            <div className="relative">
              <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input dir="ltr" className="text-left pr-9" type="text" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} placeholder="حداقل ۶ کاراکتر" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs">نقش <span className="text-rose-600">*</span></Label>
              <Select value={f.roleId} onValueChange={(v) => setF({ ...f, roleId: v })}>
                <SelectTrigger><SelectValue placeholder="انتخاب نقش" /></SelectTrigger>
                <SelectContent>
                  {roles.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.name}{r.isSystem ? " (سیستمی)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-[10px] text-muted-foreground">مجوزها از تعریف نقش می‌آیند — قابل تعریف در تب «نقش‌ها و مجوزها»</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">پرونده کارمند (اختیاری)</Label>
              <Select value={f.employeeId} onValueChange={(v) => setF({ ...f, employeeId: v })}>
                <SelectTrigger><SelectValue placeholder="بدون اتصال" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون اتصال</SelectItem>
                  {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.fullName} ({e.personnelCode})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex items-center justify-between rounded-xl border px-3.5 py-2.5">
            <div>
              <p className="text-sm font-medium">فعال</p>
              <p className="text-[11px] text-muted-foreground">کاربر غیرفعال نمی‌تواند وارد شود</p>
            </div>
            <Switch checked={f.isActive} onCheckedChange={(v) => setF({ ...f, isActive: v })} />
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">{saving ? "..." : "ذخیره"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

"use client";

import { useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Layers, Edit3, TrendingUp, Coins, Gauge, PieChart, Info, Building2, Wallet } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";
import { groupFa } from "@/lib/format";
import { MoneyInput, Money } from "../money-input";

interface GradeRow {
  id: string; level: number; code: string; title: string; description: string;
  minBaseSalary: number; maxBaseSalary: number; seniorityBase: number; attraction: number; employeeCount: number;
  fixedBaseSalary: number;
  departmentId: string | null; departmentName: string | null; departmentCode: string | null;
}

interface DeptLite { id: string; name: string; code: string }

const LEVEL_COLORS = [
  "from-slate-400 to-slate-500", "from-teal-400 to-teal-500", "from-cyan-500 to-teal-600",
  "from-emerald-500 to-teal-600", "from-teal-600 to-emerald-700", "from-teal-700 to-cyan-800",
  "from-slate-700 to-teal-900", "from-emerald-700 to-slate-800", "from-cyan-800 to-slate-900",
];

export function GradesView() {
  const { data, loading, refetch } = useApi<{ grades: GradeRow[]; departments: DeptLite[] }>("/api/grades");
  const [editing, setEditing] = useState<GradeRow | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  // دامنه نمایش: all = همه | GLOBAL = سراسری | <id> = دپارتمان خاص
  const [scope, setScope] = useState<string>("all");
  const { toast } = useToast();

  const grades = data?.grades || [];
  const departments = data?.departments || [];
  const shown = useMemo(
    () => (scope === "all" ? grades : grades.filter((g) => (scope === "GLOBAL" ? !g.departmentId : g.departmentId === scope))),
    [grades, scope],
  );
  const scopeLabel = useMemo(() => {
    if (scope === "all") return "همه سطح‌ها";
    if (scope === "GLOBAL") return "طبقه‌بندی سراسری سازمان";
    return departments.find((d) => d.id === scope)?.name || "";
  }, [scope, departments]);

  if (loading) return <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}</div>;

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
        <CardContent className="p-4 flex items-center gap-3 flex-wrap">
          <Layers className="w-8 h-8 text-teal-600 shrink-0" />
          <div className="flex-1 min-w-[240px]">
            <p className="font-bold text-slate-800">ماتریس طبقه‌بندی مشاغل</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              حداقل/حداکثر حقوق ماهانه، پایه سنوات سالانه و حق جذب هر سطح — مبنای موتور محاسبه و معکوس.
              تعداد سطوح محدودیتی ندارد و علاوه بر <b>طبقه‌بندی سراسری سازمان</b>، هر دپارتمان می‌تواند
              <b> سطح‌بندی اختصاصی خودش</b> را تعریف کند (مثلاً فنی با ۹ سطح، فروش با ۳ سطح).
              برای هر سطح یک <b>«حقوق پایه ثابت»</b> تعیین می‌کنید؛ هر چه از حقوق ماهانه کارمند مازاد بر آن باشد
              به‌عنوان <b>«سایر مزایا»</b> می‌نشیند (مشمول بیمه و مالیات) — اضافه‌کاری، مأموریت و فوق‌العاده‌ها فقط از حقوق پایه ثابت محاسبه می‌شوند.
            </p>
          </div>
          <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Edit3 className="w-4 h-4" /> سطح جدید
          </Button>
        </CardContent>
      </Card>

      {/* انتخاب دامنه سطح‌بندی */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-muted-foreground flex items-center gap-1 shrink-0">
          <Building2 className="w-3.5 h-3.5" /> دامنه سطح‌بندی:
        </span>
        <Select value={scope} onValueChange={setScope}>
          <SelectTrigger className="w-[240px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه (سراسری + همه دپارتمان‌ها)</SelectItem>
            <SelectItem value="GLOBAL">سطح‌بندی سراسری سازمان</SelectItem>
            {departments.map((d) => (
              <SelectItem key={d.id} value={d.id}>سطح‌بندی {d.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Badge variant="outline" className="tabular-nums">{toFaDigits(shown.length)} سطح</Badge>
      </div>

      <div className="space-y-3">
        {shown.map((g) => (
          <Card key={g.id} className="rounded-2xl overflow-hidden hover:shadow-md transition-shadow">
            <CardContent className="p-0">
              <div className="flex items-stretch">
                {/* نوار سطح */}
                <div className={`w-24 shrink-0 bg-gradient-to-b ${LEVEL_COLORS[(g.level - 1) % LEVEL_COLORS.length]} text-white flex flex-col items-center justify-center gap-1 py-4`}>
                  <span className="text-2xl font-black tabular-nums">{toFaDigits(g.level)}</span>
                  <span className="text-[10px] opacity-80">{g.code}</span>
                </div>
                <div className="flex-1 p-4 grid grid-cols-1 md:grid-cols-3 xl:grid-cols-5 gap-4 items-center">
                  <div>
                    <p className="font-bold text-slate-800">{g.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{g.description}</p>
                    <div className="flex flex-wrap items-center gap-1.5 mt-2">
                      <Badge variant="outline" className="tabular-nums">{toFaDigits(g.employeeCount)} کارمند فعال</Badge>
                      {g.departmentId ? (
                        <Badge className="bg-violet-100 text-violet-700 hover:bg-violet-100 border-violet-200" title={`سطح‌بندی اختصاصی ${g.departmentName}`}>
                          <Building2 className="w-3 h-3 ml-1" />{g.departmentName}
                        </Badge>
                      ) : (
                        <Badge className="bg-teal-50 text-teal-700 hover:bg-teal-50 border-teal-200">سراسری</Badge>
                      )}
                    </div>
                  </div>
                  <div>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1"><Gauge className="w-3 h-3" /> بازه حقوق ماهانه</p>
                    <p className="text-sm font-medium mt-1 tabular-nums"><Money amount={g.minBaseSalary} short /></p>
                    <p className="text-xs text-muted-foreground tabular-nums">تا <Money amount={g.maxBaseSalary} short /></p>
                  </div>
                  <div>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1"><TrendingUp className="w-3 h-3" /> پایه سنوات (هر سال)</p>
                    <p className="text-sm font-medium mt-1"><Money amount={g.seniorityBase} short /></p>
                  </div>
                  <div>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1"><PieChart className="w-3 h-3" /> تفکیک حقوق ماهانه</p>
                    {g.fixedBaseSalary > 0 ? (
                      <div className="mt-1.5 space-y-0.5">
                        <p className="text-sm font-medium flex items-center gap-1"><Wallet className="w-3 h-3 text-teal-600" /> پایه ثابت <Money amount={g.fixedBaseSalary} short /></p>
                        <p className="text-[10px] text-muted-foreground leading-4">مازاد حقوق ماهانه هر کارمند ← سایر مزایا</p>
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground mt-1">بدون تفکیک — کل حقوق = پایه</p>
                    )}
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="text-[11px] text-muted-foreground flex items-center gap-1"><Coins className="w-3 h-3" /> حق جذب</p>
                      <p className="text-sm font-medium mt-1"><Money amount={g.attraction} short /></p>
                    </div>
                    <Button size="sm" variant="outline" className="gap-1" onClick={() => { setEditing(g); setFormOpen(true); }}>
                      <Edit3 className="w-3.5 h-3.5" /> ویرایش
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        {shown.length === 0 && (
          <Card className="rounded-2xl">
            <CardContent className="py-12 text-center">
              <Layers className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">
                {scope === "all" ? "هنوز سطحی تعریف نشده است" : `برای «${scopeLabel}» سطحی تعریف نشده است`}
              </p>
              <Button size="sm" className="mt-4 bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
                <Edit3 className="w-4 h-4" /> تعریف اولین سطح
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      <GradeForm
        open={formOpen}
        onOpenChange={setFormOpen}
        editing={editing}
        departments={departments}
        grades={grades}
        onSaved={() => { refetch(); toast({ title: editing ? "سطح به‌روزرسانی شد" : "سطح جدید ایجاد شد", description: "تغییرات در لاگ حسابرسی ثبت گردید." }); }}
      />
    </div>
  );
}

function GradeForm({ open, onOpenChange, editing, departments, grades, onSaved }: {
  open: boolean; onOpenChange: (v: boolean) => void; editing: GradeRow | null; departments: DeptLite[]; grades: GradeRow[]; onSaved: () => void;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [f, setF] = useState(() => initForm(editing));
  const [lastKey, setLastKey] = useState(editing?.id || "new");
  const [wasOpen, setWasOpen] = useState(open);
  const key = editing?.id || "new";
  // هر بار بازشدن دیالوگ، فرم از داده تازه مقداردهی می‌شود (رفع حالت کهنه هنگام بازکردن مجدد همان سطح)
  if (open && !wasOpen) {
    setWasOpen(true);
    setLastKey(key);
    setF(initForm(editing));
  } else if (!open && wasOpen) {
    setWasOpen(false);
  }
  if (open && lastKey !== key) {
    setLastKey(key);
    setF(initForm(editing));
  }

  // سطوح اشغال‌شده در دامنه انتخاب‌شده (برای راهنمای کاربر)
  const takenLevels = useMemo(
    () => grades
      .filter((g) => (g.departmentId || "GLOBAL") === (f.departmentId || "GLOBAL") && g.id !== editing?.id)
      .map((g) => g.level)
      .sort((a, b) => a - b),
    [grades, f.departmentId, editing],
  );

  const fixedBase = Math.max(0, f.fixedBase || 0);
  // نمونه زنده: میانگین بازه حقوق ماهانه سطح (تومان)
  const exSalary = f.maxBaseSalary > 0 ? Math.round(((Math.max(0, f.minBaseSalary) + f.maxBaseSalary) / 2) / 10_000) * 10_000 : 0;
  const exOther = Math.max(0, exSalary - fixedBase);
  const exBasePct = exSalary > 0 && fixedBase > 0 ? Math.min(100, (fixedBase / exSalary) * 100) : 0;
  const fixedAboveMax = fixedBase > 0 && f.maxBaseSalary > 0 && fixedBase > f.maxBaseSalary;

  async function save() {
    if (!f.title.trim()) {
      toast({ title: "عنوان سطح الزامی است", variant: "destructive" });
      return;
    }
    const level = Math.round(+f.level);
    if (!Number.isInteger(level) || level < 1 || level > 99) {
      toast({ title: "شماره سطح باید عدد صحیح بین ۱ تا ۹۹ باشد", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...f,
        level,
        departmentId: f.departmentId || "GLOBAL",
        minBaseSalary: f.minBaseSalary * 10,
        maxBaseSalary: f.maxBaseSalary * 10,
        seniorityBase: f.seniorityBase * 10,
        attraction: f.attraction * 10,
        fixedBaseSalary: Math.max(0, f.fixedBase || 0) * 10,
      };
      if (editing) {
        await api("/api/grades", { method: "PATCH", json: { id: editing.id, ...payload } });
      } else {
        await api("/api/grades", { method: "POST", json: payload });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[44.8rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? `ویرایش سطح ${toFaDigits(editing.level)}` : "سطح جدید طبقه‌بندی"}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">دامنه سطح‌بندی</Label>
            <Select
              value={f.departmentId || "GLOBAL"}
              onValueChange={(v) => setF({ ...f, departmentId: v === "GLOBAL" ? "" : v })}
              disabled={!!editing}
            >
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="GLOBAL">سراسری (کل سازمان)</SelectItem>
                {departments.map((d) => (
                  <SelectItem key={d.id} value={d.id}>دپارتمان {d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground leading-4">
              سطح سراسری برای همه دپارتمان‌ها قابل انتخاب است؛ سطح دپارتمانی فقط در همان دپارتمان (برای کارکنان همان واحد و پیش‌بینی بودجه) نمایش داده می‌شود.
            </p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">شماره سطح</Label>
            <Input
              type="number" min={1} max={99} className="tabular-nums" value={f.level}
              onChange={(e) => setF({ ...f, level: Math.min(99, Math.max(1, Math.round(+e.target.value || 1))) })}
              disabled={!!editing}
            />
            {takenLevels.length > 0 && (
              <p className="text-[10px] text-muted-foreground leading-4">
                سطوح تعریف‌شده این دامنه: {takenLevels.map((l) => toFaDigits(l)).join("، ")}
              </p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">کد</Label>
            <Input dir="ltr" className="text-left" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} placeholder="L5" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان سطح</Label>
            <Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="مثلاً: کارشناس ارشد" />
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label className="text-xs">توضیحات</Label>
            <Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حداقل حقوق پایه (ماهانه)</Label>
            <MoneyInput value={f.minBaseSalary} onChange={(v) => setF({ ...f, minBaseSalary: v })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حداکثر حقوق پایه</Label>
            <MoneyInput value={f.maxBaseSalary} onChange={(v) => setF({ ...f, maxBaseSalary: v })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">پایه سنوات (هر سال خدمت)</Label>
            <MoneyInput value={f.seniorityBase} onChange={(v) => setF({ ...f, seniorityBase: v })} />
            <p className="text-[10px] text-muted-foreground leading-4">فقط در حالت «طبقه‌ای» محاسبه سنوات (تنظیمات ← پایه سنوات) استفاده می‌شود؛ در حالت «قانونی» (پیش‌فرض) جدول تجمیعی رسمی ۱۴۰۵ ملاک است</p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حق جذب</Label>
            <MoneyInput value={f.attraction} onChange={(v) => setF({ ...f, attraction: v })} />
          </div>
          {/* ---- تفکیک حقوق ماهانه سطح ---- */}
          <div className="col-span-2 rounded-xl border border-teal-200 bg-teal-50/40 p-3 space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <PieChart className="w-4 h-4 text-teal-600" />
              <p className="text-xs font-bold text-teal-800">تفکیک حقوق ماهانه این سطح</p>
              <Badge className={fixedBase > 0 ? "bg-teal-100 text-teal-700 hover:bg-teal-100" : "bg-slate-100 text-slate-600 hover:bg-slate-100"}>
                {fixedBase > 0 ? "حقوق پایه ثابت + سایر مزایا" : "بدون تفکیک — کل حقوق = پایه"}
              </Badge>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground">حقوق پایه (عدد ثابت ماهانه)</Label>
                <MoneyInput value={fixedBase} onChange={(v) => setF({ ...f, fixedBase: Math.max(0, v) })} />
                <p className="text-[10px] text-muted-foreground leading-4">
                  برای همه کارکنان این سطح یکسان — مبنای اضافه‌کاری، مأموریت، شب/جمعه/تعطیل‌کاری و غیبت. صفر یا خالی = بدون تفکیک.
                </p>
              </div>
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground">سایر مزایا (خودکار — باقیمانده حقوق ماهانه)</Label>
                <div className="h-9 rounded-lg border bg-white px-3 flex items-center gap-1 text-sm tabular-nums">
                  {exSalary > 0 && fixedBase > 0 ? (
                    <>
                      <span className="text-muted-foreground text-[10px]">نمونه:</span>
                      <b><Money amount={exOther * 10} short /></b>
                    </>
                  ) : (
                    <span className="text-muted-foreground text-[11px]">{fixedBase > 0 ? "برای هر کارمند: حقوق ماهانه − حقوق پایه ثابت" : "—"}</span>
                  )}
                </div>
                <p className="text-[10px] text-muted-foreground leading-4">
                  مازاد حقوق ماهانه هر کارمند روی حقوق پایه ثابت، خودکار در این فیلد می‌نشیند — مشمول بیمه و مالیات، اما مبنای فوق‌العاده‌ها نیست.
                </p>
              </div>
            </div>
            {exSalary > 0 && fixedBase > 0 && (
              <>
                <div className="w-full h-2.5 rounded-full overflow-hidden flex border border-teal-100 bg-slate-100" dir="ltr">
                  <div className="bg-teal-500 transition-all" style={{ width: `${exBasePct}%` }} title={`حقوق پایه ${Math.round(exBasePct)}٪`} />
                  <div className="bg-violet-400 transition-all" style={{ width: `${100 - exBasePct}%` }} title={`سایر مزایا ${Math.round(100 - exBasePct)}٪`} />
                </div>
                <p className="text-[10px] text-muted-foreground leading-5 flex gap-1">
                  <Info className="w-3 h-3 shrink-0 mt-0.5 text-teal-600" />
                  نمونه برای حقوق ماهانه {groupFa(exSalary)} تومانی در این سطح: {groupFa(fixedBase)} حقوق پایه (ثابت) + {groupFa(exOther)} سایر مزایا.
                  هر دو جزو بیمه و مالیات؛ فقط حقوق پایه مبنای فوق‌العاده‌هاست.
                </p>
              </>
            )}
            {fixedAboveMax && (
              <p className="text-[10px] text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-2 leading-4">
                حقوق پایه ثابت بیشتر از سقف بازه حقوق این سطح است — برای کارکنان با حقوق ماهانه کمتر از این عدد، پایه به کل حقوق محدود می‌شود.
              </p>
            )}
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">{saving ? "..." : "ذخیره"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function initForm(editing: GradeRow | null) {
  return {
    level: editing?.level || 1,
    title: editing?.title || "",
    code: editing?.code || "",
    description: editing?.description || "",
    departmentId: editing?.departmentId || "",
    minBaseSalary: Math.round((editing?.minBaseSalary || 0) / 10),
    maxBaseSalary: Math.round((editing?.maxBaseSalary || 0) / 10),
    seniorityBase: Math.round((editing?.seniorityBase || 0) / 10),
    attraction: Math.round((editing?.attraction || 0) / 10),
    fixedBase: Math.round((editing?.fixedBaseSalary || 0) / 10),
  };
}

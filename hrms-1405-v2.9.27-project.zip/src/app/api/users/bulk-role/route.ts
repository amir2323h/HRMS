import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// تغییر گروهی نقش کاربران — POST /api/users/bulk-role
//  • ids[]: شناسه کاربران (حداکثر ۵۰۰)
//  • roleId: نقش مقصد
// حفاظت‌ها:
//  • نقش حساب کاربری خودِ درخواست‌کننده قابل تغییر گروهی نیست
//  • آخرین مدیر کل فعال سامانه تغییر نقش داده نمی‌شود
//  • کاربرانی که از قبل همان نقش را دارند رد می‌شوند (بدون تغییر)
// ============================================================

interface SkipRow { id: string; username: string; name: string; reason: string }

/** شمارش مدیران کل فعال (برای حفاظت آخرین مدیر) */
async function activeSuperCount(excludeId?: string): Promise<number> {
  return db.user.count({ where: { role: "SUPER_ADMIN", isActive: true, ...(excludeId ? { id: { not: excludeId } } : {}) } });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "users:manage");
    const b = await req.json();
    const ids: string[] = Array.isArray(b.ids) ? b.ids.map(String).filter(Boolean) : [];
    if (ids.length === 0) return Response.json({ error: "هیچ کاربری انتخاب نشده است." }, { status: 400 });
    if (ids.length > 500) return Response.json({ error: "در هر نوبت حداکثر ۵۰۰ کاربر." }, { status: 400 });

    if (!b.roleId) return Response.json({ error: "انتخاب نقش جدید الزامی است." }, { status: 400 });
    const role = await db.role.findUnique({ where: { id: String(b.roleId) } });
    if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 400 });

    const users = await db.user.findMany({ where: { id: { in: ids } } });
    const byId = new Map(users.map((u) => [u.id, u]));

    const updated: { username: string; fullName: string }[] = [];
    const skipped: SkipRow[] = [];

    for (const id of ids) {
      const user = byId.get(id);
      if (!user) { skipped.push({ id, username: "—", name: "—", reason: "کاربر یافت نشد." }); continue; }

      if (user.id === session.uid) {
        skipped.push({ id, username: user.username, name: user.fullName, reason: "نقش حساب کاربری خودتان را نمی‌توانید به‌صورت گروهی تغییر دهید." });
        continue;
      }
      // حفاظت آخرین مدیر کل فعال
      if (user.role === "SUPER_ADMIN" && role.key !== "SUPER_ADMIN" && (await activeSuperCount(user.id)) === 0) {
        skipped.push({ id, username: user.username, name: user.fullName, reason: "آخرین مدیر کل فعال سامانه را نمی‌توان تغییر نقش داد." });
        continue;
      }
      if (user.roleId === role.id || user.role === role.key) {
        skipped.push({ id, username: user.username, name: user.fullName, reason: `از قبل نقش «${role.name}» را دارد.` });
        continue;
      }

      await db.user.update({ where: { id: user.id }, data: { roleId: role.id, role: role.key } });
      updated.push({ username: user.username, fullName: user.fullName });
      await audit(
        session,
        "UPDATE",
        "USER",
        user.id,
        `تغییر گروهی نقش — «${user.username}»: ${user.role} → ${role.key}`,
        { role: user.role, roleId: user.roleId },
        { role: role.key, roleId: role.id }
      );
    }

    await audit(
      session,
      "BULK",
      "USER",
      "",
      `تغییر گروهی نقش کاربران به «${role.name}»: ${updated.length} تغییر، ${skipped.length} رد شد`,
      null,
      { updatedCount: updated.length, skippedCount: skipped.length, roleKey: role.key, roleId: role.id }
    );

    return {
      updatedCount: updated.length,
      skippedCount: skipped.length,
      updated,
      skipped,
      roleLabel: role.name,
    };
  });
}

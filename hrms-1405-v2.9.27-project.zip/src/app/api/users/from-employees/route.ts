import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, hashPassword } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// تبدیل گروهی پرسنل به کاربر سامانه — POST /api/users/from-employees
//  • نام کاربری = شماره موبایل کارمند
//  • رمز عبور   = کد ملی کارمند
//  • نقش پیش‌فرض = EMPLOYEE (کاربر عادی سیستم — پرتال خودخدماتی)
// کارمندانی که ترک کار کرده‌اند، پیش‌تر کاربر دارند یا موبایل/کد ملی
// معتبر ندارند، رد (skip) می‌شوند و دلیلش در پاسخ برمی‌گردد.
// ============================================================

const DEFAULT_ROLE_KEY = "EMPLOYEE";

interface SkipRow { id: string; name: string; code: string; reason: string }

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "users:manage");
    const b = await req.json();
    const ids: string[] = Array.isArray(b.ids) ? b.ids.map(String).filter(Boolean) : [];
    if (ids.length === 0) return Response.json({ error: "هیچ کارمندی انتخاب نشده است." }, { status: 400 });
    if (ids.length > 500) return Response.json({ error: "در هر نوبت حداکثر ۵۰۰ نفر." }, { status: 400 });

    const roleKey = String(b.roleKey || DEFAULT_ROLE_KEY);
    const role = await db.role.findUnique({ where: { key: roleKey } });
    if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 400 });
    // حفاظت امنیتی: تبدیل گروهی پرسنل هرگز نباید کاربر «مدیر کل سیستم» بسازد.
    // (جلوگیری از خطای انسانی/کلید اشتباه — نقش مدیر کل فقط دستی و تک‌تک از «کاربران و دسترسی‌ها» تعیین می‌شود.)
    if (role.key === "SUPER_ADMIN") {
      return Response.json({ error: "ساخت کاربر با نقش «مدیر کل سیستم» از طریق تبدیل پرسنل امکان‌پذیر نیست. کاربران را با نقش عادی بسازید و در صورت نیاز، نقش مدیر کل را به‌صورت دستی از «کاربران و دسترسی‌ها» تعیین کنید." }, { status: 400 });
    }

    // بارگذاری کارکنان انتخابی + کاربر متصل (در صورت وجود)
    const employees = await db.employee.findMany({
      where: { id: { in: ids } },
      include: { user: { select: { username: true, fullName: true } } },
    });
    const byId = new Map(employees.map((e) => [e.id, e]));

    // نام‌های کاربری اشغال‌شده (پیش‌تر موجود) — یکجا برای تشخیص تکراری
    const wantedMobiles = employees
      .map((e) => (e.mobile || "").replace(/\D/g, ""))
      .filter((m) => /^09\d{9}$/.test(m));
    const existingUsers = wantedMobiles.length
      ? await db.user.findMany({ where: { username: { in: wantedMobiles } }, select: { username: true } })
      : [];
    const takenUsernames = new Set(existingUsers.map((u) => u.username));

    const created: { username: string; fullName: string }[] = [];
    const skipped: SkipRow[] = [];
    const usedThisRun = new Set<string>(); // موبایل تکراری بین خود انتخاب‌شده‌ها

    for (const id of ids) {
      const emp = byId.get(id);
      if (!emp) { skipped.push({ id, name: "—", code: "—", reason: "کارمند یافت نشد." }); continue; }
      const name = `${emp.firstName} ${emp.lastName}`;
      const label = { id: emp.id, name, code: emp.personnelCode };

      if (emp.status !== "ACTIVE") { skipped.push({ ...label, reason: "کارمند غیرفعال است (ترک کار / قطع همکاری)." }); continue; }
      if (emp.user) { skipped.push({ ...label, reason: `قبلاً کاربر دارد: «${emp.user.username}»` }); continue; }

      const mobile = (emp.mobile || "").replace(/\D/g, "");
      if (!mobile) { skipped.push({ ...label, reason: "شماره موبایل ثبت نشده است." }); continue; }
      if (!/^09\d{9}$/.test(mobile)) { skipped.push({ ...label, reason: `شماره موبایل نامعتبر است (${mobile}).` }); continue; }

      const nationalId = (emp.nationalId || "").replace(/\D/g, "");
      if (!nationalId || !/^\d{10}$/.test(nationalId)) { skipped.push({ ...label, reason: "کد ملی نامعتبر یا ثبت‌نشده است (رمز عبور از کد ملی ساخته می‌شود)." }); continue; }

      if (takenUsernames.has(mobile)) {
        const other = await db.user.findUnique({ where: { username: mobile }, select: { username: true } });
        skipped.push({ ...label, reason: `شماره موبایل قبلاً به‌عنوان نام کاربری «${other?.username || mobile}» ثبت شده است.` });
        continue;
      }
      if (usedThisRun.has(mobile)) { skipped.push({ ...label, reason: `شماره موبایل تکراری است (در همین لیست برای نفر دیگری استفاده شد).` }); continue; }

      // ایجاد کاربر — نام کاربری: موبایل، رمز: کد ملی
      const user = await db.user.create({
        data: {
          username: mobile,
          fullName: name,
          role: role.key,
          roleId: role.id,
          passwordHash: hashPassword(nationalId),
          employeeId: emp.id,
          isActive: true,
        },
      });
      usedThisRun.add(mobile);
      takenUsernames.add(mobile);
      created.push({ username: user.username, fullName: user.fullName });
      await audit(session, "CREATE", "USER", user.id, `تبدیل پرسنل به کاربر — «${user.username}» برای ${name} با نقش ${role.key}`, null, { username: user.username, fullName: name, role: role.key, personnelCode: emp.personnelCode });
    }

    await audit(session, "BULK", "USER", "", `تبدیل گروهی پرسنل به کاربر: ${created.length} ایجاد، ${skipped.length} رد شد`, null, { createdCount: created.length, skippedCount: skipped.length, roleKey: role.key });

    return {
      createdCount: created.length,
      skippedCount: skipped.length,
      created,
      skipped,
      roleLabel: role.name,
    };
  });
}

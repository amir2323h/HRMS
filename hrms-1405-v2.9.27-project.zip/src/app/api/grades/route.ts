import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeGrade } from "@/lib/serializers";

/** حقوق پایه ثابت ماهانه سطح — ریال؛ ۰ = بدون تفکیک (کل حقوق ماهانه = پایه)
 *  مبنای اضافه‌کاری/مأموریت/فوق‌العاده‌ها | مازاد حقوق ماهانه → «سایر مزایا» (بیمه+مالیات) */
function parseFixedBase(b: Record<string, unknown>): { fixedBaseSalary: bigint } | { error: string } {
  const raw = Math.round(Number(b.fixedBaseSalary) || 0);
  if (raw < 0) return { error: "حقوق پایه ثابت نمی‌تواند منفی باشد." };
  return { fixedBaseSalary: BigInt(raw) };
}

/** اعتبارسنجی دامنه سطح: سراسری یا یک دپارتمان معتبر
 *  خروجی: departmentId (تهی = سراسری) یا خطا */
async function resolveScope(b: Record<string, unknown>): Promise<{ departmentId: string | null } | { error: string }> {
  const raw = String(b.departmentId || "").trim();
  if (!raw || raw === "GLOBAL") return { departmentId: null };
  const dept = await db.department.findUnique({ where: { id: raw } });
  if (!dept) return { error: "دپارتمان انتخاب‌شده یافت نشد." };
  return { departmentId: dept.id };
}

/** یکتایی شماره سطح در دامنه (سراسری یا داخل یک دپارتمان) */
async function assertLevelFree(level: number, departmentId: string | null, exceptId?: string): Promise<string | null> {
  const clash = await db.jobGrade.findFirst({
    where: { level, departmentId, ...(exceptId ? { id: { not: exceptId } } : {}) },
  });
  if (!clash) return null;
  return departmentId
    ? `در این دپارتمان قبلاً سطح ${level} («${clash.title}») تعریف شده است.`
    : `سطح ${level} در طبقه‌بندی سراسری قبلاً تعریف شده است («${clash.title}»).`;
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "grades:view");
    const grades = await db.jobGrade.findMany({
      include: { department: { select: { id: true, name: true, code: true } } },
      orderBy: [{ departmentId: "asc" }, { level: "asc" }],
    });
    const counts = await db.employee.groupBy({
      by: ["jobGradeId"],
      where: { status: "ACTIVE" },
      _count: { id: true },
    });
    const countMap: Record<string, number> = {};
    for (const c of counts) if (c.jobGradeId) countMap[c.jobGradeId] = c._count.id;

    const departments = await db.department.findMany({
      orderBy: { code: "asc" },
      select: { id: true, name: true, code: true },
    });

    return {
      grades: grades.map((g) => ({
        ...serializeGrade(g, countMap[g.id] || 0),
        departmentId: g.departmentId,
        departmentName: g.department?.name || null,
        departmentCode: g.department?.code || null,
      })),
      departments,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "grades:manage");
    const b = await req.json();
    if (!b.title?.trim() || !b.level) return Response.json({ error: "عنوان و شماره سطح الزامی است." }, { status: 400 });
    const level = Math.round(+b.level);
    if (!Number.isInteger(level) || level < 1 || level > 99) {
      return Response.json({ error: "شماره سطح باید عدد صحیح بین ۱ تا ۹۹ باشد." }, { status: 400 });
    }
    const scope = await resolveScope(b);
    if ("error" in scope) return Response.json({ error: scope.error }, { status: 400 });
    const dupMsg = await assertLevelFree(level, scope.departmentId);
    if (dupMsg) return Response.json({ error: dupMsg }, { status: 400 });
    const split = parseFixedBase(b);
    if ("error" in split) return Response.json({ error: split.error }, { status: 400 });
    const grade = await db.jobGrade.create({
      data: {
        departmentId: scope.departmentId,
        level,
        code: String(b.code || `L${level}`),
        title: String(b.title).trim(),
        description: String(b.description || ""),
        minBaseSalary: BigInt(Math.round(+b.minBaseSalary || 0)),
        maxBaseSalary: BigInt(Math.round(+b.maxBaseSalary || 0)),
        seniorityBase: BigInt(Math.round(+b.seniorityBase || 0)),
        attraction: BigInt(Math.round(+b.attraction || 0)),
        fixedBaseSalary: split.fixedBaseSalary,
      },
    });
    await audit(
      session,
      "CREATE",
      "GRADE",
      grade.id,
      `ایجاد سطح ${level} (${b.title})${scope.departmentId ? " — دپارتمانی" : " — سراسری"}`,
    );
    return { grade: { ...serializeGrade(grade, 0), departmentId: grade.departmentId } };
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "grades:manage");
    const b = await req.json();
    if (!b.id) return Response.json({ error: "شناسه الزامی است." }, { status: 400 });
    const before = await db.jobGrade.findUnique({ where: { id: b.id } });
    if (!before) return Response.json({ error: "سطح یافت نشد." }, { status: 404 });

    // جابه‌جایی دامنه سطح (سراسری ↔ دپارتمان) — شماره سطح در دامنه جدید باید آزاد باشد
    let nextDepartmentId = before.departmentId;
    if (b.departmentId !== undefined) {
      const scope = await resolveScope(b);
      if ("error" in scope) return Response.json({ error: scope.error }, { status: 400 });
      nextDepartmentId = scope.departmentId;
    }
    if (nextDepartmentId !== before.departmentId) {
      const dupMsg = await assertLevelFree(before.level, nextDepartmentId, before.id);
      if (dupMsg) return Response.json({ error: dupMsg }, { status: 400 });
    }

    const data: Record<string, unknown> = { departmentId: nextDepartmentId };
    for (const f of ["title", "code", "description"]) if (b[f] !== undefined) data[f] = String(b[f]).trim();
    for (const f of ["minBaseSalary", "maxBaseSalary", "seniorityBase", "attraction"]) {
      if (b[f] !== undefined) data[f] = BigInt(Math.round(+b[f] || 0));
    }
    // حقوق پایه ثابت — فقط وقتی ارسال شده باشد
    if (b.fixedBaseSalary !== undefined) {
      const split = parseFixedBase(b);
      if ("error" in split) return Response.json({ error: split.error }, { status: 400 });
      data.fixedBaseSalary = split.fixedBaseSalary;
    }
    await db.jobGrade.update({ where: { id: b.id }, data });
    const after = await db.jobGrade.findUnique({ where: { id: b.id }, include: { department: true } });
    await audit(
      session,
      "UPDATE",
      "GRADE",
      b.id,
      `ویرایش سطح ${after?.level} (${after?.title})${after?.departmentId ? ` — ${after.department?.name || ""}` : " — سراسری"}`,
      before ? { min: Number(before.minBaseSalary), max: Number(before.maxBaseSalary), sen: Number(before.seniorityBase), att: Number(before.attraction) } : null,
      { min: Number(after?.minBaseSalary), max: Number(after?.maxBaseSalary), sen: Number(after?.seniorityBase), att: Number(after?.attraction) }
    );
    return { grade: { ...serializeGrade(after!, 0), departmentId: after?.departmentId } };
  });
}

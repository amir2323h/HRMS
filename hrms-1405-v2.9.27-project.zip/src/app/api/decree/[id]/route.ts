import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAnyPerm } from "@/lib/auth";
import { handle, audit, num } from "@/lib/api-helpers";
import { fmtToman } from "@/lib/format";
import { logEmployeeChange, type ChangeEntry } from "@/lib/employee-changelog";

// ============================================================
// جزئیات/ابطال حکم (گروهی عیدی/پاداش یا فردی حقوق)
//  GET   : حکم + خطوط نفر به نفر (+ ریز فیش کامل حکم حقوق از detailsJson)
//  PATCH : { action: "cancel", revertSalary? } — ابطال حکم صادرشده
//          revertSalary=true فقط برای حکم حقوقِ اعمال‌شده: حقوق کارمند
//          به مقدار قبل از حکم برمی‌گردد (با لاگ تغییر حقوق).
// ============================================================

function parseDetails(raw: string) {
  if (!raw) return null;
  try {
    const d = JSON.parse(raw) as {
      items?: { code: string; title: string; amount: number; kind: string }[];
      seniorityYears?: number;
      childCount?: number;
      married?: boolean;
      baseSplit?: string;
      splitBaseAmount?: number;
      effectiveJ?: string;
      previousSalary?: number;
      currentNet?: number;
      achievedNet?: number;
      residual?: number;
      warnings?: string[];
      notes?: string[];
    };
    return d;
  } catch {
    return null;
  }
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(req, "bonus:view");
    const { id } = await params;
    const decree = await db.salaryDecree.findUnique({ where: { id } });
    if (!decree) return Response.json({ error: "حکم یافت نشد." }, { status: 404 });
    const lines = await db.salaryDecreeLine.findMany({
      where: { decreeId: id },
      orderBy: [{ department: "asc" }, { jobLevel: "desc" }, { employeeName: "asc" }],
    });
    return {
      decree: {
        id: decree.id,
        decreeNo: decree.decreeNo,
        year: decree.year,
        title: decree.title,
        kind: decree.kind,
        payMonthY: decree.payMonthY,
        payMonthM: decree.payMonthM,
        scope: decree.scope,
        scopeDeptName: decree.scopeDeptName,
        scopeEmployeeId: decree.scopeEmployeeId,
        scopeEmployeeName: decree.scopeEmployeeName,
        previousSalary: decree.previousSalary === null ? null : num(decree.previousSalary),
        appliedSalary: decree.appliedSalary,
        levelTitle: decree.levelTitle,
        targetNetPerPerson: num(decree.targetNetPerPerson),
        taxExempt: num(decree.taxExempt),
        headcount: decree.headcount,
        totalGross: num(decree.totalGross),
        totalTax: num(decree.totalTax),
        totalNet: num(decree.totalNet),
        status: decree.status,
        notes: decree.notes,
        createdBy: decree.createdBy,
        createdAt: decree.createdAt,
      },
      lines: lines.map((l) => ({
        id: l.id,
        employeeName: l.employeeName,
        personnelCode: l.personnelCode,
        department: l.department,
        jobLevel: l.jobLevel,
        jobLevelTitle: l.jobLevelTitle,
        baseSalary: num(l.baseSalary),
        marginalRate: l.marginalRate,
        targetNet: num(l.targetNet),
        taxAmount: num(l.taxAmount),
        grossAmount: num(l.grossAmount),
        netAmount: num(l.netAmount),
        coefficient: l.coefficient,
        details: parseDetails(l.detailsJson),
      })),
    };
  });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requireAnyPerm(req, ["bonus:manage", "salary:manage"]);
    const { id } = await params;
    const b = await req.json().catch(() => ({}));

    if (b?.action !== "cancel") {
      return Response.json({ error: "عملیات نامعتبر است." }, { status: 400 });
    }
    const decree = await db.salaryDecree.findUnique({ where: { id } });
    if (!decree) return Response.json({ error: "حکم یافت نشد." }, { status: 404 });
    if (decree.status !== "ISSUED") {
      return Response.json({ error: "این حکم قبلاً ابطال شده است." }, { status: 400 });
    }
    const before = { status: decree.status };

    // ——— ابطال حکم حقوق فردی: بازگردانی اختیاری حقوق کارمند ———
    let salaryReverted = false;
    let revertNote = "";
    if (decree.kind === "SALARY" && b?.revertSalary === true && decree.appliedSalary && decree.scopeEmployeeId) {
      const prev = Number(decree.previousSalary || 0);
      if (prev > 0) {
        const emp = await db.employee.findUnique({ where: { id: decree.scopeEmployeeId } });
        if (emp) {
          const line = await db.salaryDecreeLine.findFirst({ where: { decreeId: decree.id } });
          const appliedSalaryAmount = line ? Number(line.baseSalary) : Number(emp.baseSalary);
          if (Number(emp.baseSalary) !== appliedSalaryAmount) {
            return Response.json({
              error: `حقوق فعلی این کارمند (${fmtToman(Number(emp.baseSalary))}) با حقوق اعمالی حکم (${fmtToman(appliedSalaryAmount)}) فرق دارد — برای جلوگیری از دستکاری تغییرات بعدی، حقوق به‌صورت خودکار برنگردانده شد. حکم بدون بازگردانی ابطال شود یا حقوق را دستی اصلاح کنید.`,
            }, { status: 400 });
          }
          await db.employee.update({
            where: { id: emp.id },
            data: { baseSalary: BigInt(prev) },
          });
          salaryReverted = true;
          revertNote = " و حقوق کارمند به مقدار قبل از حکم بازگردانده شد";

          const empChanges: ChangeEntry[] = [{
            field: "baseSalary", label: "حقوق پایه", kind: "money",
            from: String(appliedSalaryAmount), to: String(prev),
            fromDisplay: fmtToman(appliedSalaryAmount), toDisplay: fmtToman(prev),
          }];
          await logEmployeeChange(
            session,
            emp.id,
            empChanges,
            "SALARY",
            `ابطال حکم حقوق ${decree.decreeNo} و بازگردانی حقوق`,
          );
        }
      }
    }

    await db.salaryDecree.update({
      where: { id },
      data: { status: "CANCELLED", ...(salaryReverted ? { appliedSalary: false } : {}) },
    });
    const kindLabel = decree.kind === "SALARY" ? "حکم حقوق" : "حکم گروهی";
    await audit(
      session,
      "CANCEL",
      "SALARY_DECREE",
      id,
      `ابطال ${kindLabel} ${decree.decreeNo} «${decree.title}» — ${decree.headcount} نفر، جمع ${num(decree.totalGross).toLocaleString("en-US")} ریال${revertNote}`,
      before,
      { status: "CANCELLED", salaryReverted },
    );
    return { ok: true, salaryReverted };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAnyPerm } from "@/lib/auth";
import { handle, audit, num } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import { computeDecreeLines } from "@/lib/decree";
import { computeEmployeeReverse } from "@/lib/reverse-employee";
import { todayJalaliStr } from "@/lib/jalali";
import { fmtToman } from "@/lib/format";
import { logEmployeeChange, type ChangeEntry } from "@/lib/employee-changelog";

// ============================================================
// احکام — دو نوع:
//  ۱) BONUS — حکم گروهی عیدی/پاداش پایان سال (دامنه دپارتمان/سطح)
//     جریان: خالص هدف هر نفر → معکوس با نرخ مالیات نهاییِ همان نفر
//     (از روی حقوق پایه دستی او) → حکم گروهی؛ پیش‌بینی بودجه، احکام
//     صادرشده را در ماه پرداختِ آنها لحاظ می‌کند.
//  ۲) SALARY — حکم حقوق فردی (از موتور محاسبه معکوس):
//     خالص هدف یک کارمند مشخص → حل معکوس با کانتکس واقعی پرونده‌اش
//     (فرزند/تاهل/سنوات از تاریخ استخدام/طبقه/جذب/شیفت تا پایان ماه اجرا)
//     → صدور حکم + اعمال اختیاری حقوق جدید روی پرونده (با لاگ تغییر حقوق).
//  GET  : لیست احکام + پارامترهای قانونی (برای فرم صدور)
//  POST : صدور حکم — kind=SALARY (فردی) یا پیش‌فرض BONUS (گروهی)؛ dryRun=true فقط پیش‌نمایش
// ============================================================

function serializeLine(l: {
  employeeName: string; personnelCode: string; department: string;
  jobLevel: number; jobLevelTitle: string; baseSalary: bigint | number;
  marginalRate: number; targetNet: bigint | number; taxAmount: bigint | number;
  grossAmount: bigint | number; netAmount: bigint | number; coefficient: number;
}) {
  return {
    employeeName: l.employeeName,
    personnelCode: l.personnelCode,
    department: l.department,
    jobLevel: l.jobLevel,
    jobLevelTitle: l.jobLevelTitle,
    baseSalary: num(l.baseSalary as bigint),
    marginalRate: l.marginalRate,
    targetNet: num(l.targetNet as bigint),
    taxAmount: num(l.taxAmount as bigint),
    grossAmount: num(l.grossAmount as bigint),
    netAmount: num(l.netAmount as bigint),
    coefficient: l.coefficient,
  };
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "bonus:view");

    const [decrees, params] = await Promise.all([
      db.salaryDecree.findMany({ orderBy: { createdAt: "desc" } }),
      getLegalParams(),
    ]);
    const lineCounts = await db.salaryDecreeLine.groupBy({ by: ["decreeId"], _count: { decreeId: true } });
    const countMap = new Map(lineCounts.map((c) => [c.decreeId, c._count.decreeId]));
    // حقوق ماهانه جدید حکم‌های حقوق فردی (خط اول هر حکم)
    const salaryDecreeIds = decrees.filter((d) => d.kind === "SALARY").map((d) => d.id);
    const salaryLines = salaryDecreeIds.length
      ? await db.salaryDecreeLine.findMany({
          where: { decreeId: { in: salaryDecreeIds } },
          select: { decreeId: true, baseSalary: true },
        })
      : [];
    const newSalaryMap = new Map(salaryLines.map((l) => [l.decreeId, num(l.baseSalary)]));

    const today = todayJalaliStr(); // YYYY/MM/DD
    const ty = Number(today.split("/")[0]);

    return {
      decrees: decrees.map((d) => ({
        id: d.id,
        decreeNo: d.decreeNo,
        year: d.year,
        title: d.title,
        kind: d.kind,
        payMonthY: d.payMonthY,
        payMonthM: d.payMonthM,
        scope: d.scope,
        scopeDeptName: d.scopeDeptName,
        scopeEmployeeId: d.scopeEmployeeId,
        scopeEmployeeName: d.scopeEmployeeName,
        previousSalary: d.previousSalary === null ? null : num(d.previousSalary),
        appliedSalary: d.appliedSalary,
        newSalary: d.kind === "SALARY" ? newSalaryMap.get(d.id) ?? 0 : undefined,
        levelTitle: d.levelTitle,
        targetNetPerPerson: num(d.targetNetPerPerson),
        taxExempt: num(d.taxExempt),
        headcount: d.headcount,
        totalGross: num(d.totalGross),
        totalTax: num(d.totalTax),
        totalNet: num(d.totalNet),
        status: d.status,
        notes: d.notes,
        createdBy: d.createdBy,
        createdAt: d.createdAt,
        lineCount: countMap.get(d.id) || 0,
      })),
      legal: {
        year: params.year,
        minWage: params.minWage,
        defaultTaxExempt: params.minWage * 2, // معافیت عیدی = ۲× حداقل دستمزد
        taxBrackets: params.taxBrackets,
      },
      defaults: {
        // پیش‌فرض فرم: عیدی پایان سال جاری (اسفند)
        payMonthY: ty,
        payMonthM: 12,
        title: `عیدی و پاداش پایان سال ${ty}`,
      },
      today,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const b = await req.json();

    // ————————————————————————————————————————
    // نوع ۲: حکم حقوق فردی (از محاسبه معکوس) — kind=SALARY
    // ————————————————————————————————————————
    if (b?.kind === "SALARY") {
      const session = requireAnyPerm(req, ["bonus:manage", "salary:manage"]);
      const employeeId = String(b?.employeeId || "");
      if (!employeeId) {
        return Response.json({ error: "کارمند حکم حقوق انتخاب نشده است." }, { status: 400 });
      }
      const targetNet = Math.round(+b?.targetNet || 0); // ریال
      if (!(targetNet > 0)) {
        return Response.json({ error: "مبلغ خالص هدف باید مثبت باشد." }, { status: 400 });
      }
      const payMonthY = Math.round(+b?.payMonthY || 0); // ماه اجرای حکم
      const payMonthM = Math.round(+b?.payMonthM || 0);
      if (!payMonthY || payMonthM < 1 || payMonthM > 12) {
        return Response.json({ error: "ماه اجرای حکم نامعتبر است." }, { status: 400 });
      }

      const params = await getLegalParams(true);
      // حل معکوس سمت سرور با کانتکس واقعی کارمند — هرگز به اعداد کلاینت اعتماد نمی‌شود
      const outcome = await computeEmployeeReverse({
        employeeId,
        targetNet,
        effectiveY: payMonthY,
        effectiveM: payMonthM,
        params,
        overrides: {
          gradeId: b?.gradeId ?? null,
          childCount: b?.childCount !== undefined ? b.childCount : undefined,
          married: b?.married !== undefined ? b.married === true : undefined,
          housingEnabled: b?.housingEnabled !== undefined ? b.housingEnabled !== false : undefined,
          groceryEnabled: b?.groceryEnabled !== undefined ? b.groceryEnabled !== false : undefined,
          otherAllowance: b?.otherAllowance !== undefined ? b.otherAllowance : undefined,
          employmentType: b?.employmentType,
          shiftPattern: b?.shiftPattern,
          nightHours: b?.nightHours,
          fridayHours: b?.fridayHours,
          holidayHours: b?.holidayHours,
          absentDays: b?.absentDays,
          missionDays: b?.missionDays,
          rounding: b?.rounding ? +b.rounding : null,
          baseSplit: b?.baseSplit === "GRADE" ? "GRADE" : "LEGAL",
        },
      });
      if ("error" in outcome) return Response.json({ error: outcome.error }, { status: 400 });
      if (!outcome.result.ok) {
        return Response.json({ error: outcome.result.warnings[0] || "خالص هدف قابل‌تحقق نیست." }, { status: 400 });
      }

      const newSalary = outcome.result.baseSalary;
      const sheet = outcome.result.paysheet;
      const prevSalary = outcome.employee.currentSalary;
      const applySalary = b?.applySalary !== false; // پیش‌فرض: اعمال روی پرونده
      const title = String(b?.title || "").trim() || `حکم حقوق — ${outcome.employee.fullName}`;

      // ——— پیش‌نمایش بدون ذخیره ———
      if (b?.dryRun === true) {
        return {
          dryRun: true,
          kind: "SALARY",
          title,
          employee: outcome.employee,
          effectiveY: payMonthY,
          effectiveM: payMonthM,
          newSalary,
          paysheet: {
            gross: sheet.gross,
            net: sheet.netPay,
            employeeSso: sheet.employeeSso,
            incomeTax: sheet.incomeTax,
            seniority: sheet.seniority,
            housing: sheet.housing,
            grocery: sheet.grocery,
            childAllowance: sheet.childAllowance,
            marriageAllowance: sheet.marriageAllowance,
            attraction: sheet.attraction,
          },
          warnings: outcome.result.warnings,
        };
      }

      // ——— صدور حکم حقوق ———
      const year = payMonthY;
      const existingCount = await db.salaryDecree.count({ where: { year } });
      const seq = existingCount + 1;

      const detailsJson = JSON.stringify({
        items: sheet.items,
        seniorityYears: outcome.employee.seniorityYears,
        childCount: outcome.employee.childCount,
        married: outcome.employee.married,
        baseSplit: outcome.baseSplit,
        splitBaseAmount: outcome.splitBaseAmount,
        effectiveJ: outcome.effectiveJ,
        previousSalary: prevSalary,
        currentNet: outcome.employee.currentNet,
        achievedNet: outcome.result.achievedNet,
        residual: outcome.result.residual,
        warnings: outcome.result.warnings,
        notes: outcome.result.notes,
      });

      const data = {
        year,
        title,
        kind: "SALARY",
        payMonthY,
        payMonthM,
        scope: "PERSON",
        scopeDeptId: null,
        scopeDeptName: outcome.employee.department,
        scopeEmployeeId: outcome.employee.id,
        scopeEmployeeName: outcome.employee.fullName,
        previousSalary: BigInt(Math.round(prevSalary)),
        appliedSalary: false,
        levelId: null,
        levelTitle: outcome.employee.levelTitle,
        targetNetPerPerson: BigInt(targetNet),
        taxExempt: BigInt(0),
        headcount: 1,
        totalGross: BigInt(sheet.gross),
        totalTax: BigInt(sheet.incomeTax),
        totalNet: BigInt(sheet.netPay),
        status: "ISSUED",
        notes: String(b?.notes || ""),
        createdBy: session.fullName,
      };

      let decree;
      try {
        decree = await db.salaryDecree.create({
          data: { ...data, decreeNo: `حکم-${year}-${String(seq).padStart(3, "0")}` },
        });
      } catch {
        decree = await db.salaryDecree.create({
          data: { ...data, decreeNo: `حکم-${year}-${String(seq + 1).padStart(3, "0")}` },
        });
      }

      await db.salaryDecreeLine.create({
        data: {
          decreeId: decree.id,
          employeeId: outcome.employee.id,
          employeeName: outcome.employee.fullName,
          personnelCode: outcome.employee.personnelCode,
          department: outcome.employee.department,
          jobLevel: 0,
          jobLevelTitle: outcome.employee.levelTitle,
          baseSalary: BigInt(newSalary), // حقوق ماهانه جدید
          marginalRate: outcome.marginalRate,
          targetNet: BigInt(targetNet),
          taxAmount: BigInt(sheet.incomeTax),
          grossAmount: BigInt(sheet.gross),
          netAmount: BigInt(sheet.netPay),
          coefficient: prevSalary > 0 ? Math.round((newSalary / prevSalary) * 1000) / 1000 : 0, // ضریب حقوق جدید به قبلی
          detailsJson,
        },
      });

      // ——— اعمال حقوق جدید روی پرونده کارمند + لاگ‌ها ———
      let salaryApplied = false;
      if (applySalary && newSalary !== prevSalary) {
        await db.employee.update({
          where: { id: outcome.employee.id },
          data: { baseSalary: BigInt(newSalary) },
        });
        await db.salaryDecree.update({ where: { id: decree.id }, data: { appliedSalary: true } });
        salaryApplied = true;

        const deltaAmount = newSalary - prevSalary;
        const deltaPercent = prevSalary > 0 ? (deltaAmount / prevSalary) * 100 : 0;
        await db.salaryChangeLog.create({
          data: {
            employeeId: outcome.employee.id,
            employeeName: outcome.employee.fullName,
            personnelCode: outcome.employee.personnelCode,
            oldBaseSalary: BigInt(Math.round(prevSalary)),
            newBaseSalary: BigInt(newSalary),
            oldOvertimeHours: 0,
            newOvertimeHours: 0,
            oldJobGradeId: null,
            newJobGradeId: null,
            oldGradeTitle: "",
            newGradeTitle: "",
            deltaAmount: BigInt(deltaAmount),
            deltaPercent: Math.round(deltaPercent * 100) / 100,
            oldNet: BigInt(Math.round(outcome.employee.currentNet)),
            newNet: BigInt(sheet.netPay),
            source: "DECREE",
            reason: `صدور حکم حقوق ${decree.decreeNo}${String(b?.notes || "") ? ` — ${String(b.notes).slice(0, 300)}` : ""}`.slice(0, 500),
            draftId: "",
            performedBy: session.uid,
            performedByName: session.fullName,
          },
        });

        const empChanges: ChangeEntry[] = [{
          field: "baseSalary", label: "حقوق پایه", kind: "money",
          from: String(prevSalary), to: String(newSalary),
          fromDisplay: fmtToman(prevSalary), toDisplay: fmtToman(newSalary),
        }];
        await logEmployeeChange(
          session,
          outcome.employee.id,
          empChanges,
          "SALARY",
          `صدور حکم حقوق ${decree.decreeNo} — ${title}`,
        );
      }

      await audit(
        session,
        "ISSUE",
        "SALARY_DECREE",
        decree.id,
        `صدور حکم حقوق ${decree.decreeNo} «${title}» برای ${outcome.employee.fullName} — خالص هدف ${targetNet.toLocaleString("en-US")} ریال → حقوق ماهانه ${newSalary.toLocaleString("en-US")} ریال (اجرا ${payMonthY}/${String(payMonthM).padStart(2, "0")}${salaryApplied ? "، اعمال‌شده روی پرونده" : ""})`,
        undefined,
        { targetNet, newSalary, prevSalary, applied: salaryApplied },
      );

      return {
        dryRun: false,
        decree: {
          id: decree.id,
          decreeNo: decree.decreeNo,
          title: decree.title,
          kind: decree.kind,
          payMonthY: decree.payMonthY,
          payMonthM: decree.payMonthM,
          scopeEmployeeName: decree.scopeEmployeeName,
          levelTitle: decree.levelTitle,
          targetNetPerPerson: targetNet,
          headcount: 1,
          totalGross: sheet.gross,
          totalTax: sheet.incomeTax,
          totalNet: sheet.netPay,
          status: decree.status,
          appliedSalary: salaryApplied,
        },
        employee: outcome.employee,
        newSalary,
        salaryApplied,
      };
    }

    // ————————————————————————————————————————
    // نوع ۱: حکم گروهی عیدی/پاداش (پیش‌فرض) — kind=BONUS
    // ————————————————————————————————————————
    const session = requirePerm(req, "bonus:manage");
    const targetNet = Math.round(+b?.targetNetPerPerson || 0); // ریال
    if (!(targetNet > 0)) {
      return Response.json({ error: "خالص هدف هر نفر را وارد کنید (باید مثبت باشد)." }, { status: 400 });
    }
    const payMonthY = Math.round(+b?.payMonthY || 0);
    const payMonthM = Math.round(+b?.payMonthM || 0);
    if (!payMonthY || payMonthM < 1 || payMonthM > 12) {
      return Response.json({ error: "ماه پرداخت حکم نامعتبر است." }, { status: 400 });
    }

    const params = await getLegalParams(true);
    // معافیت مالیاتی عیدی — پیش‌فرض ۲× حداقل دستمزد (صفر/منفی = همان پیش‌فرض)
    let taxExempt = Math.round(+b?.taxExempt || 0);
    if (!(taxExempt > 0)) taxExempt = params.minWage * 2;

    // ——— دامنه: دپارتمان + سطح (اختیاری) ———
    let scopeDeptId: string | null = null;
    let scopeDeptName = "همه دپارتمان‌ها";
    if (b?.scopeDeptId) {
      const dept = await db.department.findUnique({ where: { id: String(b.scopeDeptId) } });
      if (!dept) return Response.json({ error: "دپارتمان انتخاب‌شده یافت نشد." }, { status: 400 });
      scopeDeptId = dept.id;
      scopeDeptName = dept.name;
    }
    let levelId: string | null = null;
    let levelTitle = "همه سطوح";
    if (b?.levelId) {
      const grade = await db.jobGrade.findUnique({ where: { id: String(b.levelId) } });
      if (!grade) return Response.json({ error: "سطح انتخاب‌شده یافت نشد." }, { status: 400 });
      levelId = grade.id;
      levelTitle = `سطح ${grade.level} — ${grade.title}`;
    }

    // ——— محاسبه خطوط ———
    const calc = await computeDecreeLines({
      params,
      scopeDeptId,
      levelId,
      targetNet,
      taxExempt,
      payMonthY,
      payMonthM,
    });
    if ("error" in calc) return Response.json({ error: calc.error }, { status: 400 });

    const title = String(b?.title || "").trim() || `عیدی و پاداش پایان سال ${payMonthY}`;
    const dryRun = b?.dryRun === true;

    // ——— پیش‌نمایش — بدون ذخیره ———
    if (dryRun) {
      return {
        dryRun: true,
        title,
        payLabel: `${payMonthY}/${String(payMonthM).padStart(2, "0")}`,
        scopeLabel: scopeDeptName,
        levelLabel: levelTitle,
        meta: {
          targetNetPerPerson: targetNet,
          taxExempt,
          payMonthY,
          payMonthM,
        },
        lines: calc.lines.map(serializeLine),
        totals: calc.totals,
      };
    }

    // ——— صدور حکم ———
    const year = payMonthY;
    const existingCount = await db.salaryDecree.count({ where: { year } });
    const seq = existingCount + 1;

    const data = {
      year,
      title,
      kind: "BONUS",
      payMonthY,
      payMonthM,
      scope: (scopeDeptId ? "DEPT" : "ALL") as string,
      scopeDeptId,
      scopeDeptName,
      levelId,
      levelTitle,
      targetNetPerPerson: BigInt(targetNet),
      taxExempt: BigInt(taxExempt),
      headcount: calc.totals.headcount,
      totalGross: BigInt(calc.totals.totalGross),
      totalTax: BigInt(calc.totals.totalTax),
      totalNet: BigInt(calc.totals.totalNet),
      status: "ISSUED",
      notes: String(b?.notes || ""),
      createdBy: session.fullName,
    };

    let decree;
    try {
      decree = await db.salaryDecree.create({
        data: { ...data, decreeNo: `حکم-${year}-${String(seq).padStart(3, "0")}` },
      });
    } catch {
      // برخورد شماره (هم‌زمانی) — یک شماره جلوتر
      decree = await db.salaryDecree.create({
        data: { ...data, decreeNo: `حکم-${year}-${String(seq + 1).padStart(3, "0")}` },
      });
    }

    for (const l of calc.lines) {
      await db.salaryDecreeLine.create({
        data: {
          decreeId: decree.id,
          employeeId: l.employeeId,
          employeeName: l.employeeName,
          personnelCode: l.personnelCode,
          department: l.department,
          jobLevel: l.jobLevel,
          jobLevelTitle: l.jobLevelTitle,
          baseSalary: BigInt(l.baseSalary),
          marginalRate: l.marginalRate,
          targetNet: BigInt(l.targetNet),
          taxAmount: BigInt(l.taxAmount),
          grossAmount: BigInt(l.grossAmount),
          netAmount: BigInt(l.netAmount),
          coefficient: l.coefficient,
        },
      });
    }

    await audit(
      session,
      "ISSUE",
      "SALARY_DECREE",
      decree.id,
      `صدور حکم گروهی «${title}» ${decree.decreeNo} — ${calc.totals.headcount} نفر، خالص هدف هر نفر ${targetNet.toLocaleString("en-US")} ریال، جمع احکام ${calc.totals.totalGross.toLocaleString("en-US")} ریال (پرداخت ${payMonthY}/${payMonthM})`,
      undefined,
      { targetNet, taxExempt, headcount: calc.totals.headcount, totalGross: calc.totals.totalGross },
    );

    return {
      dryRun: false,
      decree: {
        id: decree.id,
        decreeNo: decree.decreeNo,
        title: decree.title,
        payMonthY: decree.payMonthY,
        payMonthM: decree.payMonthM,
        scopeDeptName: decree.scopeDeptName,
        levelTitle: decree.levelTitle,
        targetNetPerPerson: targetNet,
        taxExempt,
        headcount: decree.headcount,
        totalGross: calc.totals.totalGross,
        totalTax: calc.totals.totalTax,
        totalNet: calc.totals.totalNet,
        status: decree.status,
      },
      lines: calc.lines.map(serializeLine),
      totals: calc.totals,
    };
  });
}

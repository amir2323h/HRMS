import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import {
  applySchedules,
  cancelSchedules,
  serializeSchedule,
  todayYm,
  upsertSchedules,
  ymIndex,
} from "@/lib/salary-schedule";

/**
 * GET /api/salary/schedules?status=PENDING|ALL&employeeId=...
 * فهرست زمان‌بندی‌های تغییر حقوق (ماه‌های آینده) + شمارنده‌ها
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "salary:view");
    const status = req.nextUrl.searchParams.get("status") || "PENDING";
    const employeeId = req.nextUrl.searchParams.get("employeeId") || "";

    const where = {
      ...(status === "ALL" ? {} : { status }),
      ...(employeeId ? { employeeId } : {}),
    };
    const schedules = await db.salarySchedule.findMany({
      where,
      include: {
        employee: {
          select: { firstName: true, lastName: true, personnelCode: true, baseSalary: true },
        },
      },
      orderBy: [{ year: "asc" }, { month: "asc" }, { createdAt: "desc" }],
      take: status === "ALL" ? 500 : 200,
    });

    const { year: curY, month: curM } = todayYm();
    const curIdx = ymIndex(curY, curM);
    const pending = await db.salarySchedule.count({ where: { status: "PENDING" } });
    const dueRows = await db.salarySchedule.findMany({
      where: { status: "PENDING" },
      select: { year: true, month: true },
    });
    const due = dueRows.filter((s) => ymIndex(s.year, s.month) <= curIdx).length;

    return {
      schedules: schedules.map((s) => serializeSchedule(s as unknown as Record<string, unknown>)),
      counts: { pending, due, currentYear: curY, currentMonth: curM },
    };
  });
}

/**
 * POST /api/salary/schedules — ثبت زمان‌بندی برای ماه‌های آینده
 * { items: [{ employeeId, year, month, newBaseSalary (ریال), reason? }] }
 * به‌ازای هر کارمند+ماه حداکثر یک زمان‌بندی در انتظار — ثبت مجدد همان ماه = به‌روزرسانی
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "salary:manage");
    const b = await req.json();
    const items = Array.isArray(b.items) ? b.items : [];
    if (items.length === 0) {
      return Response.json({ error: "فهرست زمان‌بندی خالی است." }, { status: 400 });
    }
    const res = await upsertSchedules(
      session,
      items.map((it: Record<string, unknown>) => ({
        employeeId: String(it.employeeId || ""),
        year: +it.year || 0,
        month: +it.month || 0,
        newBaseSalary: +it.newBaseSalary || 0,
        reason: it.reason ? String(it.reason) : "",
      }))
    );
    if (res.created + res.updated === 0) {
      return Response.json(
        { error: res.errors[0] || "زمان‌بندی معتبری ثبت نشد.", errors: res.errors },
        { status: 400 }
      );
    }
    return res;
  });
}

/**
 * PATCH /api/salary/schedules
 * { action: "APPLY" | "APPLY_DUE" | "CANCEL", ids?: string[], note?: string }
 *  APPLY     — اعمال فوری موارد انتخابی (صرف‌نظر از ماه)
 *  APPLY_DUE — اعمال همه موارد سررسیدشده (ماه اعمال ≤ ماه جاری)
 *  CANCEL    — لغو موارد در انتظار
 */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "salary:manage");
    const b = await req.json();
    const action = String(b.action || "");
    const ids: string[] = Array.isArray(b.ids) ? b.ids.map(String).filter(Boolean) : [];

    if (action === "APPLY") {
      if (ids.length === 0) {
        return Response.json({ error: "زمان‌بندی انتخاب نشده است." }, { status: 400 });
      }
      const res = await applySchedules(session, ids, undefined, b.note ? String(b.note) : undefined);
      return res;
    }

    if (action === "APPLY_DUE") {
      const res = await applySchedules(session, "DUE", undefined, b.note ? String(b.note) : undefined);
      return res;
    }

    if (action === "CANCEL") {
      if (ids.length === 0) {
        return Response.json({ error: "زمان‌بندی انتخاب نشده است." }, { status: 400 });
      }
      const count = await cancelSchedules(session, ids);
      return { canceled: count };
    }

    return Response.json({ error: "عملیات نامعتبر است." }, { status: 400 });
  });
}

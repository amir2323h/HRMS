// ============================================================
// Next.js 16 Proxy (جانشین middleware) — بهداشت کوکی نشست در مسیرهای ورود
// ============================================================
// نکته مهم: احراز هویت و کنترل دسترسی این سامانه در سطح API انجام
// می‌شود (requireAuth / requirePerm در هر route) و صفحه ورود داخل
// همان SPA در مسیر / است؛ بنابراین این proxy عمداً حداقلی است و فقط
// مسیرهای «ورود/خروج» مستقل را تطبیق می‌دهد — در گردش عادی سامانه
// هیچ دخالتی ندارد.
//
// اگر فایل proxy دیگری (مثلاً از یک ویرایش دستی قدیمی) با خطای
// «Export isSessionCurrent doesn't exist» بیلد را شکسته بود، این
// نسخهٔ استاندارد جای آن می‌نشیند و با src/lib/auth.ts هماهنگ است.
// (proxy در Next.js 16 همیشه روی runtime نود اجرا می‌شود؛ متغیر
//  runtime در config مجاز نیست.)
import { NextRequest, NextResponse } from "next/server";
import { getSessionFromRequest, isSessionCurrent, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";

// مسیرهای ورود/خروج باید حتی با کوکیِ نشست قبلی، امکان ورود مجدد/خروج را فراهم کنند.
const SESSION_ENTRY_PATHS = new Set(["/login", "/logout"]);

export default function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // خارج از مسیرهای ورود/خروج هیچ دخالتی نداریم.
  if (!SESSION_ENTRY_PATHS.has(pathname)) {
    return NextResponse.next();
  }

  // کوکی نشستِ جاری نیست (نبود / نامعتبر / منقضی)؟ در مسیر ورود پاکش
  // می‌کنیم تا کوکی کهنهِ نشست قبلی مزاحم ورود مجدد یا خروج نشود.
  if (!isSessionCurrent(getSessionFromRequest(req))) {
    const res = NextResponse.next();
    res.cookies.set(SESSION_COOKIE, "", { ...sessionCookieOptions(req), maxAge: 0 });
    return res;
  }

  return NextResponse.next();
}

export const config = {
  // فقط مسیرهای ورود/خروج مستقل (در این سامانه SPA در / اجرا می‌شود و
  // این مسیرها جزء روتینگ عادی نیستند؛ matcher عمومی نگیرید).
  matcher: ["/login", "/logout"],
};

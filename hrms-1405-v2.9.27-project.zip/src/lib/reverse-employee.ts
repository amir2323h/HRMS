// ============================================================
// محاسبه معکوس حقوق برای یک کارمند مشخص — ۱۴۰۵
// منبع یکپارچه برای «موتور محاسبه معکوس» (پیش‌نمایش) و «صدور حکم حقوق»
//
// نکته کلیدی یکسان‌سازی اعداد: کانتکس محاسبه (فرزند/تاهل/سنوات/طبقه/جذب/شیفت)
// از پرونده واقعی همان کارمند ساخته می‌شود — همان تابعی که فیش حقوقی،
// «پیش‌بینی بودجه» و «حکم گروهی» استفاده می‌کنند (contextFromEmployee).
// سنوات همیشه از تاریخ استخدام تا پایان «ماه اجرا» محاسبه می‌شود
// (ورودی دستی seniorityYears در حالت کارمند نادیده گرفته می‌شود) ⇒
// معکوس(خالص هدف) و پیش‌بینی(حقوق ماهانه) دقیقاً معکوس یکدیگرند.
// واحد: ریال (integer)
// ============================================================
import { db } from "@/lib/db";
import {
  computePaysheet,
  contextFromEmployee,
  shiftRateOf,
  marginalTaxRate,
  type LegalParams,
  type PayrollContext,
} from "@/lib/payroll/engine";
import { computeReversePaysheet, type ReverseResult } from "@/lib/payroll/reverse";
import { daysInJalaliMonth, todayJalali } from "@/lib/jalali";

export interface EmployeeReverseOverrides {
  // ——— لغوهای دستی (اختیاری — پیش‌فرض: مقادیر واقعی پرونده) ———
  gradeId?: string | null; // تغییر طبقه (پیش‌فرض: طبقه فعلی کارمند)
  childCount?: number; // تعداد فرزند مشمول
  married?: boolean; // حق تاهل
  housingEnabled?: boolean;
  groceryEnabled?: boolean;
  otherAllowance?: number; // ریال
  employmentType?: string; // DAILY | SHIFT
  shiftPattern?: string; // TWO_SHIFT | THREE_SHIFT
  nightHours?: number;
  fridayHours?: number;
  holidayHours?: number;
  absentDays?: number;
  missionDays?: number;
  rounding?: number | null; // گرد کردن حقوق ماهانه — ریال
  baseSplit?: "LEGAL" | "GRADE"; // مبنای تفکیک حقوق پایه در نتیجه
}

export interface EmployeeReverseOutcome {
  ok: true;
  result: ReverseResult;
  employee: {
    id: string;
    fullName: string;
    personnelCode: string;
    department: string;
    levelTitle: string;
    currentSalary: number; // حقوق ماهانه فعلی — ریال
    currentNet: number; // خالص استاندارد فعلی (همان کانتکس، حقوق فعلی) — ریال
    currentGross: number; // ناخالص استاندارد فعلی — ریال
    seniorityYears: number; // سابقه محاسبه‌شده تا پایان ماه اجرا
    hireDateJ: string;
    childCount: number;
    married: boolean;
  };
  effectiveY: number;
  effectiveM: number;
  effectiveJ: string; // تاریخ پایان ماه اجرا — YYYY/MM/DD
  context: PayrollContext; // کانتکس نهایی (برای شفافیت/دیباگ)
  baseSplit: "LEGAL" | "GRADE";
  splitBaseAmount: number;
  marginalRate: number; // نرخ مالیات نهایی درآمد مشمول نتیجه
}

const pad2 = (n: number) => String(n).padStart(2, "0");

/** محاسبه معکوس حقوق یک کارمند با کانتکس واقعی پرونده‌اش (+ لغوهای دستی اختیاری) */
export async function computeEmployeeReverse(opts: {
  employeeId: string;
  targetNet: number; // ریال
  effectiveY?: number; // ماه اجرا — پیش‌فرض: ماه جاری
  effectiveM?: number;
  params: LegalParams;
  overrides?: EmployeeReverseOverrides;
}): Promise<EmployeeReverseOutcome | { error: string }> {
  const { params } = opts;
  const targetNet = Math.round(opts.targetNet);
  if (!(targetNet > 0)) return { error: "مبلغ خالص هدف باید مثبت باشد." };

  const employee = await db.employee.findUnique({
    where: { id: opts.employeeId },
    include: {
      jobGrade: true,
      departments: { include: { department: { select: { id: true, name: true } } }, orderBy: { allocationPercent: "desc" } },
    },
  });
  if (!employee) return { error: "کارمند انتخاب‌شده یافت نشد." };
  if (employee.status !== "ACTIVE") return { error: "این کارمند فعال نیست — حکم حقوق فقط برای کارکنان فعال صادر می‌شود." };

  const t = todayJalali();
  const effY = Math.round(+(opts.effectiveY ?? 0) || t.jy);
  const effM = Math.round(+(opts.effectiveM ?? 0) || t.jm);
  if (!effY || effM < 1 || effM > 12) return { error: "ماه اجرای حکم نامعتبر است." };
  const effectiveJ = `${effY}/${pad2(effM)}/${pad2(daysInJalaliMonth(effY, effM))}`;

  const ov = opts.overrides || {};
  // طبقه مؤثر: لغو دستی یا طبقه فعلی کارمند
  let grade = employee.jobGrade;
  if (ov.gradeId !== undefined && ov.gradeId !== null && ov.gradeId !== "" && (!grade || ov.gradeId !== grade.id)) {
    const g = await db.jobGrade.findUnique({ where: { id: String(ov.gradeId) } });
    if (!g) return { error: "طبقه انتخاب‌شده یافت نشد." };
    grade = g;
  }

  // ——— کانتکس واقعی کارمند در پایان ماه اجرا ———
  const employmentType = ov.employmentType === "SHIFT" ? "SHIFT" : ov.employmentType === "DAILY" ? "DAILY" : employee.employmentType;
  const shiftPattern =
    employmentType === "SHIFT" && ["TWO_SHIFT", "THREE_SHIFT"].includes(String(ov.shiftPattern))
      ? String(ov.shiftPattern)
      : employmentType === "SHIFT"
        ? employee.shiftPattern || "TWO_SHIFT"
        : "";
  const hours = (v: unknown, max: number) => Math.max(0, Math.min(max, Number(v) || 0));

  const ctx = contextFromEmployee(
    {
      baseSalary: 0, // حقوق پایه متغیر حل معکوس است — در solve جایگزین می‌شود
      childCount: ov.childCount !== undefined ? Math.max(0, Math.min(4, Math.round(+ov.childCount) || 0)) : employee.childCount || 0,
      maritalStatus:
        ov.married === undefined || ov.married === null
          ? employee.maritalStatus
          : ov.married
            ? "MARRIED"
            : "SINGLE",
      overtimeHours: 0,
      hireDateJ: employee.hireDateJ || "",
      employmentType,
      shiftPattern,
    },
    grade,
    effectiveJ,
    {
      overtimeHours: 0,
      otherAllowance: ov.otherAllowance !== undefined ? Math.max(0, Math.round(+ov.otherAllowance) || 0) : 0,
      otherDeduction: 0,
      nightHours: hours(ov.nightHours, 300),
      fridayHours: hours(ov.fridayHours, 300),
      holidayHours: hours(ov.holidayHours, 300),
      absentDays: hours(ov.absentDays, 30),
      missionDays: hours(ov.missionDays, 30),
      shiftRate: shiftRateOf(employmentType, shiftPattern, params),
      // تفکیک حقوق پایه در «نتیجه» — LEGAL = عدد پایه اداره کار
      fixedBaseAmount: undefined,
    },
  );

  // ——— مبنای تفکیک حقوق پایه ———
  const baseSplit: "LEGAL" | "GRADE" = ov.baseSplit === "GRADE" ? "GRADE" : "LEGAL";
  const splitBaseAmount =
    baseSplit === "LEGAL"
      ? params.minWage
      : grade && Number(grade.fixedBaseSalary) > 0
        ? Number(grade.fixedBaseSalary)
        : 0;
  ctx.fixedBaseAmount = splitBaseAmount > 0 ? splitBaseAmount : undefined;

  // ——— حل معکوس ———
  const result = computeReversePaysheet({
    targetNet,
    context: ctx,
    params,
    gradeMin: grade ? Number(grade.minBaseSalary) : undefined,
    gradeMax: grade ? Number(grade.maxBaseSalary) : undefined,
    rounding: ov.rounding && +ov.rounding > 0 ? +ov.rounding : null,
  });

  const dept = employee.departments?.[0]?.department;
  // فیش استاندارد فعلی کارمند (همان کانتکس و همان ماه اجرا) — مبنای «قبل از حکم»
  const currentSheet = computePaysheet(Number(employee.baseSalary), ctx, params);
  return {
    ok: true,
    result,
    employee: {
      id: employee.id,
      fullName: `${employee.firstName} ${employee.lastName}`.trim(),
      personnelCode: employee.personnelCode || "—",
      department: dept?.name || "بدون دپارتمان",
      levelTitle: grade ? `سطح ${grade.level} — ${grade.title}` : "بدون طبقه",
      currentSalary: Number(employee.baseSalary),
      currentNet: currentSheet.netPay,
      currentGross: currentSheet.gross,
      seniorityYears: ctx.seniorityYears,
      hireDateJ: employee.hireDateJ || "",
      childCount: ctx.childCount,
      married: ctx.married === true,
    },
    effectiveY: effY,
    effectiveM: effM,
    effectiveJ,
    context: ctx,
    baseSplit,
    splitBaseAmount,
    marginalRate: marginalTaxRate(result.paysheet.taxableIncome, params.taxBrackets),
  };
}

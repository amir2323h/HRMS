// ============================================================
// موتور احکام گروهی (عیدی/پاداش پایان سال) — ۱۴۰۵
// جریان: مدیر «خالص پرداختی هر نفر» را به‌صورت گروهی تعیین می‌کند؛
// سامانه برای هر کارمند:
//   ۱) فیش استاندارد ماه او را با حقوق پایه دستی محاسبه می‌کند
//      → نرخ مالیات نهایی (Marginal) او از پله مالیاتی‌اش درمی‌آید؛
//   ۲) مبلغ ناخالص حکم را معکوس حل می‌کند:
//         خالص هدف X ، معافیت عیدی E ، نرخ نهایی r
//         G > E ⇔ G − r×(G−E) = X  →  G = (X − r·E) ÷ (1−r)
//      (G ≤ E یا r = 0 → بدون مالیات: G = X)
//   ۳) مالیات = G − X (خالص دقیقاً برابر هدف؛ گرد کردن در مالیات می‌نشیند)
//   ۴) ضریب = G ÷ حقوق پایه ماهانه (≈ چند «ماه پایه» است)
// عیدی/پاداش مشمول بیمه نیست؛ مالیات فقط بر مازادِ معافیت (۲× حداقل دستمزد
// مصوب — قابل ویرایش) با نرخ نهاییِ همان نفر از روی حقوق پایه او.
// واحد: ریال (integer)
// ============================================================
import { db } from "@/lib/db";
import {
  computePaysheet,
  contextFromEmployee,
  shiftRateOf,
  marginalTaxRate,
  type LegalParams,
} from "@/lib/payroll/engine";
import { daysInJalaliMonth } from "@/lib/jalali";

export interface DecreeLineCalc {
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  department: string;
  jobLevel: number;
  jobLevelTitle: string;
  baseSalary: number; // حقوق پایه ماهانه (ریال)
  marginalRate: number; // نرخ مالیات نهایی — از حقوق پایه او
  targetNet: number;
  taxAmount: number;
  grossAmount: number; // مبلغ حکم (ناخالص)
  netAmount: number;
  coefficient: number; // ضریب نسبت به حقوق پایه (≈ ماه پایه)
}

export interface DecreeTotals {
  headcount: number;
  totalGross: number;
  totalTax: number;
  totalNet: number;
}

/** حل معکوس خالص → ناخالص برای یک نفر (نرخ ثابتِ نهایی روی مازادِ معافیت) */
export function grossUpUniform(
  targetNet: number,
  exempt: number,
  rate: number,
): { gross: number; tax: number } {
  const X = Math.round(targetNet);
  const E = Math.max(0, Math.round(exempt));
  let r = rate || 0;
  if (r < 0) r = 0;
  if (r > 0.95) r = 0.95; // سپر محاسباتی — نرخ‌های واقعی حداکثر ۳۰٪ هستند
  if (X <= 0) return { gross: 0, tax: 0 };
  if (X <= E || r === 0) return { gross: X, tax: 0 }; // زیر معافیت یا بدون مالیات
  const g0 = (X - r * E) / (1 - r);
  // گرد به ۱۰۰۰ ریال (۱۰۰ تومان) — اعداد مرتب حکم
  let gross = Math.max(E + 1, Math.round(g0 / 1000) * 1000);
  let tax = gross - X;
  if (tax < 0) {
    // سپر عدم‌منفی‌شدن مالیات در مرز معافیت (اختلاف گرد کردن ≤ ۵۰۰ ریال)
    gross = X;
    tax = 0;
  }
  return { gross, tax };
}

const pad2 = (n: number) => String(n).padStart(2, "0");

/** محاسبه خطوط حکم گروهی برای یک دامنه (دپارتمان اختیاری + سطح اختیاری) */
export async function computeDecreeLines(opts: {
  params: LegalParams;
  scopeDeptId: string | null; // null = همه دپارتمان‌ها
  levelId: string | null; // null = همه سطوح
  targetNet: number; // خالص هدف هر نفر — ریال
  taxExempt: number; // معافیت مالیاتی عیدی — ریال
  payMonthY: number;
  payMonthM: number;
}): Promise<{ lines: DecreeLineCalc[]; totals: DecreeTotals } | { error: string }> {
  const { params, targetNet, taxExempt } = opts;
  if (!(targetNet > 0)) return { error: "خالص هدف هر نفر باید مثبت باشد." };

  const payEndJ = `${opts.payMonthY}/${pad2(opts.payMonthM)}/${pad2(daysInJalaliMonth(opts.payMonthY, opts.payMonthM))}`;

  const employees = await db.employee.findMany({
    where: { status: "ACTIVE" },
    include: {
      jobGrade: true,
      departments: { include: { department: { select: { id: true, name: true } } }, orderBy: { allocationPercent: "desc" } },
    },
  });

  const lines: DecreeLineCalc[] = [];
  for (const e of employees) {
    // دامنه دپارتمان
    const empDept = e.departments?.[0]?.department || null;
    if (opts.scopeDeptId && empDept?.id !== opts.scopeDeptId) continue;
    // دامنه سطح
    if (opts.levelId && e.jobGradeId !== opts.levelId) continue;

    const grade = e.jobGrade;
    const base = Math.max(0, Number(e.baseSalary));
    const shiftRate = shiftRateOf(e.employmentType, e.shiftPattern, params);
    const ctx = contextFromEmployee(
      {
        baseSalary: base,
        childCount: e.childCount || 0,
        maritalStatus: e.maritalStatus,
        overtimeHours: 0,
        hireDateJ: e.hireDateJ || "",
        employmentType: e.employmentType,
        shiftPattern: e.shiftPattern,
      },
      grade,
      payEndJ,
      { overtimeHours: 0, otherAllowance: 0, otherDeduction: 0, nightHours: 0, fridayHours: 0, holidayHours: 0, absentDays: 0, missionDays: 0, shiftRate },
    );
    const sheet = computePaysheet(base, ctx, params);
    const rate = marginalTaxRate(sheet.taxableIncome, params.taxBrackets);
    const { gross, tax } = grossUpUniform(targetNet, taxExempt, rate);
    const coefficient = base > 0 ? Math.round((gross / base) * 1000) / 1000 : 0;
    lines.push({
      employeeId: e.id,
      employeeName: `${e.firstName} ${e.lastName}`.trim(),
      personnelCode: e.personnelCode || "—",
      department: empDept?.name || "بدون دپارتمان",
      jobLevel: grade?.level || 0,
      jobLevelTitle: grade ? `سطح ${grade.level} — ${grade.title}` : "بدون طبقه",
      baseSalary: base,
      marginalRate: rate,
      targetNet,
      taxAmount: tax,
      grossAmount: gross,
      netAmount: gross - tax,
      coefficient,
    });
  }

  if (lines.length === 0) return { error: "هیچ کارمند فعلی در این دامنه (دپارتمان/سطح) نیست." };

  // مرتب‌سازی: دپارتمان، سپس سطح نزولی، سپس نام
  lines.sort(
    (a, b) =>
      a.department.localeCompare(b.department, "fa") ||
      b.jobLevel - a.jobLevel ||
      a.employeeName.localeCompare(b.employeeName, "fa"),
  );

  let totalGross = 0;
  let totalTax = 0;
  let totalNet = 0;
  for (const l of lines) {
    totalGross += l.grossAmount;
    totalTax += l.taxAmount;
    totalNet += l.netAmount;
  }
  return {
    lines,
    totals: { headcount: lines.length, totalGross, totalTax, totalNet },
  };
}

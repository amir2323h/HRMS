// ============================================================
// تولید کد پرسنلی یکتا — منبع واحد برای ثبت دستی و ایمپورت اکسل
//  روش: بزرگ‌ترین پسوند عددی کدهای موجود (EMP-####) + ۱
//  چرا «تعداد رکورد» نه؟ اگر کارمندی حذف شود یا ایمپورت اکسل
//  کدهای ناپیوسته ساخته باشد، روش «تعداد» با کد موجود تداخل
//  می‌کند (خطای یکتایی P2002) — این روش مقاوم است.
// ============================================================
import { db } from "@/lib/db";

/** استخراج پسوند عددی از قالب EMP-#### (خارج از قالب → null) */
function codeSuffix(code: string): number | null {
  const m = /^EMP-(\d+)$/.exec(String(code || "").trim());
  return m ? parseInt(m[1], 10) : null;
}

/**
 * کد پرسنلی یکتای بعدی — بر اساس بزرگ‌ترین پسوند موجود (+ جابه‌جایی offset
 * برای ایمپورت چندتایی در یک درخواست). تا یافتن کد آزاد جلو می‌رود تا
 * هیچ تداخلی با کدهای غیراستاندارد قبلی رخ ندهد.
 */
export async function nextPersonnelCode(offset = 0): Promise<string> {
  const employees = await db.employee.findMany({ select: { personnelCode: true } });
  let max = 1000; // نقطه شروع تاریخی: EMP-1001
  for (const e of employees) {
    const n = codeSuffix(e.personnelCode);
    if (n !== null && n > max) max = n;
  }
  let k = offset;
  let candidate = `EMP-${max + 1 + k}`;
  // اطمینان از یکتایی (کدهای دستی/غیرعددی یا تداخل هم‌زمان)
  while (await db.employee.findUnique({ where: { personnelCode: candidate } })) {
    k++;
    candidate = `EMP-${max + 1 + k}`;
  }
  return candidate;
}

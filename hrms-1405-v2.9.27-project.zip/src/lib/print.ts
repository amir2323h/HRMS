"use client";

// ============================================================
// ابزار چاپ قراردادها — A4/A5 با صفحه‌بندی خودکار
//  • سایز کاغذ واقعی: @page { size: A4|A5 } + ابعاد برگه مطابق
//    (پیش‌نمایش و چاپ هر دو دقیقاً همان کاغذ انتخابی)
//  • شماره/تاریخ: بالا-سمت-چپ (مشابه نامه‌های رسمی)
//  • محل امضای «طرف اول / طرف دوم»: انتهای «هر صفحه» — اسکریپت
//    صفحه‌بندی متن را بین برگه‌ها توزیع می‌کند و قاب امضا را
//    پایین هر برگه می‌نشاند (بدون هم‌پوشانی متن)
//  • فاصله خطوط بلوک امضا: 1.15
//  • فونت متن: B Nazanin ۱۲ (A4) / ۱۰.۵ (A5) — فاصله سطر ۱.۱۵
//  • چاپ: پنجره جدید مستقل — فونت‌ها با آدرس مطلق همان سرور
//  • دانلود: فایل HTML خودکفا — فونت‌ها base64 داخل فایل
//  • B Nazanin گلیف لاتین ندارد → حروف لاتین خودکار از LetterLatin
// ============================================================

export interface PrintSignature {
  title: string; // مثلاً «طرف اول (کارفرما)»
  name?: string; // نام زیر خط امضا
}

export interface PrintSection {
  docTitle: string; // عنوان سند (وسط صفحه اول هر سند)
  metaNumber?: string; // شماره سند — بلوک بالا-چپ
  metaDate?: string; // تاریخ سند — بلوک بالا-چپ
  headerTitle?: string; // نام سازمان بالای سند (وسط)
  body: string; // متن اصلی (whitespace-pre-wrap)
  signatures?: [PrintSignature, PrintSignature] | null;
  footerNote?: string;
}

export type ContractPaperSize = "A4" | "A5";

export interface PrintDocOptions {
  baseUrl?: string; // آدرس مطلق سرور برای فونت‌ها (پنجره چاپ)
  embeddedFonts?: Record<string, string>; // نام فایل → data URL (فایل دانلودی خودکفا)
  paperSize?: ContractPaperSize; // اندازه کاغذ (پیش‌فرض A4)
}

// فونت‌های سند — B Nazanin (متن فارسی) + LetterLatin (جفت لاتین) + وزیرمتن (پشتیبان رابط)
const FONT_SPEC: { file: string; family: string; weight: number; adjust?: number }[] = [
  { file: "BNazanin.woff2", family: "B Nazanin", weight: 400 },
  { file: "LetterLatin-Regular.woff2", family: "LetterLatin", weight: 400, adjust: 83.33 },
  { file: "LetterLatin-Bold.woff2", family: "LetterLatin", weight: 700, adjust: 83.33 },
  { file: "Vazirmatn-Regular.woff2", family: "Vazirmatn", weight: 400 },
  { file: "Vazirmatn-Bold.woff2", family: "Vazirmatn", weight: 700 },
];

const FONT_FILES = FONT_SPEC.map((f) => f.file);

/** خانواده متن قرارداد — فارسی B Nazanin، لاتین LetterLatin */
const CONTRACT_FONT = "'B Nazanin', 'LetterLatin', 'Vazirmatn', serif";

/** ابعاد کاغذ (میلی‌متر) + حاشیه‌ها */
const PAGE_GEO: Record<ContractPaperSize, { w: number; h: number; side: number; top: number; bottom: number; label: string }> = {
  A4: { w: 210, h: 297, side: 16, top: 14, bottom: 10, label: "A4" },
  A5: { w: 148, h: 210, side: 12, top: 11, bottom: 8, label: "A5" },
};

function fontFaces(baseUrl?: string, embedded?: Record<string, string>): string {
  return FONT_SPEC.map(({ file, family, weight, adjust }) => {
    const src = embedded && embedded[file]
      ? `url('${embedded[file]}')`
      : `url('${(baseUrl || "").replace(/\/$/, "")}/fonts/${file}')`;
    return `@font-face { font-family: '${family}'; src: ${src} format('woff2'); font-weight: ${weight};${adjust ? ` size-adjust: ${adjust}%;` : ""} font-display: block; }`;
  }).join("\n");
}

/** فونت‌های سرور را به data URL تبدیل می‌کند — برای فایل دانلودی خودکفا (بدون وابستگی به سرور) */
async function fetchEmbeddedFonts(baseUrl: string): Promise<Record<string, string> | undefined> {
  try {
    const out: Record<string, string> = {};
    await Promise.all(
      FONT_FILES.map(async (f) => {
        const res = await fetch(`${baseUrl.replace(/\/$/, "")}/fonts/${f}`);
        if (!res.ok) throw new Error(`font ${f}: ${res.status}`);
        const buf = await res.arrayBuffer();
        const bytes = new Uint8Array(buf);
        let bin = "";
        const CHUNK = 0x8000;
        for (let i = 0; i < bytes.length; i += CHUNK) {
          bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
        }
        out[f] = `data:font/woff2;base64,${btoa(bin)}`;
      })
    );
    return out;
  } catch {
    return undefined; // fallback: آدرس مطلق سرور
  }
}

function esc(s: string): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/**
 * اسکریپت صفحه‌بندی — داخل سند چاپی اجرا می‌شود (هم پنجره چاپ، هم فایل دانلودی).
 *  متن هر سند را خط‌به‌خط (با اندازه‌گیری واقعی فونت) بین برگه‌های هم‌اندازهٔ کاغذ
 *  توزیع می‌کند تا «بلوک امضای طرف اول/طرف دوم» پایین «هر برگه» بنشیند و متن
 *  هرگز زیر آن نرود. پس از پایان، پرچم window.__hrmsPrintReady بالا می‌رود.
 */
function paginationScript(): string {
  return `<script>
(function () {
  function ready(fn) {
    if (document.readyState !== "loading") fn();
    else document.addEventListener("DOMContentLoaded", fn);
  }
  ready(function () {
    var fontsDone = (document.fonts && document.fonts.ready) ? document.fonts.ready : Promise.resolve();
    fontsDone.then(function () { try { paginate(); } catch (e) { /* صفحه‌بندی نشد ⇒ تک‌صفحه قبلی */ }
      try { document.documentElement.classList.add("paginated"); } catch (e) {}
      window.__hrmsPrintReady = true;
    });
  });

  function paginate() {
    var pages = Array.prototype.slice.call(document.querySelectorAll("section.page"));
    pages.forEach(function (sec) {
      // ---- اجزای قاب سند ----
      var refsEl = sec.querySelector(".refs");
      var orgEl = sec.querySelector(".org");
      var titleEl = sec.querySelector(".doc-title");
      var bodyEl = sec.querySelector(".body-text");
      var sigsEl = sec.querySelector(".sigs");
      var footEl = sec.querySelector(".footnote");
      if (!bodyEl) return;
      var fullText = bodyEl.textContent || "";

      var refsHtml = refsEl ? refsEl.outerHTML : "";
      var orgHtml = orgEl ? orgEl.outerHTML : "";
      var titleText = titleEl ? titleEl.textContent : "";
      var sigsHtml = sigsEl ? sigsEl.outerHTML : "";
      var footHtml = footEl ? footEl.outerHTML : "";

      // ---- ساخت قاب برگه ----
      function makePage(first) {
        var p = document.createElement("section");
        p.className = "page" + (first ? " doc-first" : "") + " cont-page";
        var head = document.createElement("header");
        head.className = "doc-head" + (first ? "" : " cont");
        head.innerHTML = (first ? orgHtml : "") + refsHtml;
        p.appendChild(head);
        if (first && titleText) {
          var t = document.createElement("h1");
          t.className = "doc-title";
          t.textContent = titleText;
          p.appendChild(t);
        }
        var body = document.createElement("div");
        body.className = "body-text";
        p.appendChild(body);
        if (sigsHtml) {
          var s = document.createElement("div");
          s.innerHTML = sigsHtml;
          p.appendChild(s.firstChild);
        }
        if (footHtml) {
          var f = document.createElement("div");
          f.innerHTML = footHtml;
          p.appendChild(f.firstChild);
        }
        return { page: p, body: body, foot: p.querySelector(".footnote") };
      }

      // ---- اندازه‌گیر (هم‌عرض/هم‌استایل بدنه، خارج از دید) ----
      var measurer = document.createElement("div");
      measurer.className = "body-text";
      measurer.style.cssText = "position:fixed;top:0;left:-99999px;visibility:hidden;";
      document.body.appendChild(measurer);

      var made = [];
      var current = makePage(true);
      sec.parentNode.insertBefore(current.page, sec);
      made.push(current);
      measurer.style.width = current.body.clientWidth + "px";

      var lines = fullText.split("\\n");
      var start = 0;
      var avail = current.body.clientHeight;

      for (var i = 0; i < lines.length; i++) {
        measurer.textContent = lines.slice(start, i + 1).join("\\n");
        if (measurer.offsetHeight > avail && i > start) {
          current.body.textContent = lines.slice(start, i).join("\\n");
          start = i;
          current = makePage(false);
          sec.parentNode.insertBefore(current.page, sec);
          made.push(current);
          measurer.style.width = current.body.clientWidth + "px";
          avail = current.body.clientHeight;
          measurer.textContent = lines.slice(start, i + 1).join("\\n");
          // یک سطر بلندتر از فضای صفحه؟ (بند بلند شکسته‌نشده) — همان‌جا می‌ماند و ادامه می‌یابد
          while (measurer.offsetHeight > avail && (i + 1 - start) > 1) {
            current.body.textContent = lines.slice(start, i).join("\\n");
            start = i;
            current = makePage(false);
            sec.parentNode.insertBefore(current.page, sec);
            made.push(current);
            measurer.style.width = current.body.clientWidth + "px";
            avail = current.body.clientHeight;
            measurer.textContent = lines.slice(start, i + 1).join("\\n");
          }
        }
      }
      current.body.textContent = lines.slice(start).join("\\n");

      // پابرگ فقط برگهٔ آخرِ «هر سند» — از بقیه برگه‌ها حذف می‌شود (فضایش از قبل رزرو شده)
      made.forEach(function (pg, idx) {
        if (idx !== made.length - 1 && pg.foot) pg.foot.remove();
      });

      measurer.remove();
      sec.remove();
    });
  }
})();
</script>`;
}

/** ساخت سند HTML کامل RTL برای چاپ/دانلود — هر سند چند برگهٔ هم‌اندازهٔ کاغذ با امضای پایین هر برگه */
export function buildPrintDocument(sections: PrintSection[], docTitle: string, opts: PrintDocOptions = {}): string {
  const paper: ContractPaperSize = opts.paperSize === "A5" ? "A5" : "A4";
  const geo = PAGE_GEO[paper];

  const pages = sections
    .map((s, si) => {
      const sig = s.signatures
        ? `<div class="sigs">
            <div>
              <p class="sig-title">${esc(s.signatures[0].title)}</p>
              <p class="sig-name">${esc(s.signatures[0].name || "")}</p>
            </div>
            <div>
              <p class="sig-title">${esc(s.signatures[1].title)}</p>
              <p class="sig-name">${esc(s.signatures[1].name || "")}</p>
            </div>
          </div>`
        : "";
      const refs = `<div class="refs">
            <p class="ref-line"><b>شماره:</b> <span class="ref-num" dir="ltr">${esc(s.metaNumber || "—")}</span></p>
            <p class="ref-line"><b>تاریخ:</b> <span class="ref-date">${esc(s.metaDate || "—")}</span></p>
          </div>`;
      return `<section class="page doc-first${si === sections.length - 1 ? " doc-last" : ""}">
        <header class="doc-head">
          ${refs}
          ${s.headerTitle ? `<p class="org">${esc(s.headerTitle)}</p>` : '<p class="org"></p>'}
        </header>
        <h1 class="doc-title">${esc(s.docTitle)}</h1>
        <div class="body-text">${esc(s.body)}</div>
        ${sig}
        ${s.footerNote ? `<p class="footnote">${esc(s.footerNote)}</p>` : '<p class="footnote"></p>'}
      </section>`;
    })
    .join("\n");

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl" class="paper-${paper}">
<head>
<meta charset="utf-8">
<title>${esc(docTitle)}</title>
<style>
${fontFaces(opts.baseUrl, opts.embeddedFonts)}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { background: #eef2f5; }
body { font-family: ${CONTRACT_FONT}; direction: rtl; }
@page { size: ${paper}; margin: 0; }
.page {
  background: #fff;
  width: ${geo.w}mm;
  height: ${geo.h}mm;
  margin: 8mm auto;
  padding: ${geo.top}mm ${geo.side}mm ${geo.bottom}mm;
  box-shadow: 0 2px 14px rgba(0,0,0,.14);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;
}
/* ---------- سربرگ سند: شماره/تاریخ بالا-چپ (مشابه نامه‌ها) — نام سازمان وسط ---------- */
.doc-head { position: relative; display: flex; justify-content: flex-end; align-items: flex-start; padding-bottom: 2.5mm; border-bottom: 1.5pt solid #0f766e33; min-height: 11mm; }
.refs { max-width: 40%; }
.ref-line { font-family: ${CONTRACT_FONT}; font-size: 11pt; line-height: 1.9; color: #111; text-align: right; font-weight: 700; }
.ref-line b { font-weight: 700; color: #0f172a; }
.org { position: absolute; left: 50%; top: 0; transform: translateX(-50%); text-align: center; font-weight: 700; color: #0f766e; font-size: 12pt; max-width: 55%; }
.doc-title { text-align: center; font-size: 13pt; font-weight: 700; color: #1e293b; margin-top: 5mm; }
/* ---------- بدنه: B Nazanin ۱۲ با فاصله سطر ۱.۱۵ ---------- */
.body-text { margin-top: 6mm; font-size: 12pt; line-height: 1.15; color: #334155; white-space: pre-wrap; text-align: justify; flex: 1; }
/* ---------- امضای هر صفحه: طرف اول / طرف دوم — فاصله خطوط ۱.۱۵ ---------- */
.sigs { margin-top: 5mm; padding-top: 4mm; border-top: 1pt dotted #94a3b8; display: grid; grid-template-columns: 1fr 1fr; gap: 8mm; text-align: center; flex-shrink: 0; }
.sig-title { font-size: 11pt; color: #334155; margin-bottom: 18mm; font-weight: 700; line-height: 1.15; }
.sig-name { font-size: 11pt; color: #334155; border-top: 1pt dotted #64748b; padding-top: 1.5mm; line-height: 1.15; }
.footnote { margin-top: 3mm; font-size: 9pt; color: #94a3b8; text-align: center; flex-shrink: 0; min-height: 5mm; }
/* ---------- حالت A5: متن و فاصله‌های متناسب کاغذ کوچک‌تر ---------- */
.paper-a5 .ref-line { font-size: 9.5pt; line-height: 1.8; }
.paper-a5 .org { font-size: 10.5pt; }
.paper-a5 .doc-title { font-size: 11.5pt; margin-top: 4mm; }
.paper-a5 .body-text { font-size: 10.5pt; margin-top: 4.5mm; }
.paper-a5 .sig-title { font-size: 10pt; margin-bottom: 13mm; }
.paper-a5 .sig-name { font-size: 10pt; }
.paper-a5 .footnote { font-size: 8pt; }
.toolbar { position: fixed; top: 0; right: 0; left: 0; background: #0f172aee; color: #fff; display: flex; align-items: center; gap: 10px; padding: 8px 14px; font-family: 'Vazirmatn', sans-serif; z-index: 99; }
.toolbar button { font-family: inherit; font-size: 12px; padding: 6px 14px; border: 0; border-radius: 8px; cursor: pointer; }
.toolbar .btn-print { background: #14b8a6; color: #fff; }
.toolbar .btn-close { background: #475569; color: #fff; }
.toolbar .hint { font-size: 11px; opacity: .75; margin-right: auto; }
.toolbar .paper-chip { font-size: 11px; font-weight: 700; background: #14b8a633; color: #5eead4; border-radius: 8px; padding: 4px 10px; }
@media print {
  html, body { background: #fff; }
  .toolbar { display: none !important; }
  .page { width: ${geo.w}mm; height: ${geo.h}mm; margin: 0; box-shadow: none; page-break-after: always; break-after: page; }
  .page:last-child { page-break-after: auto; break-after: auto; }
  .noprint { display: none; }
}
</style>
</head>
<body>
<div class="toolbar">
  <button class="btn-print" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
  <button class="btn-close" onclick="window.close()">بستن</button>
  <span class="paper-chip">کاغذ ${geo.label} (${geo.w}×${geo.h} میلی‌متر)</span>
  <span class="hint">${esc(docTitle)} — محل امضای طرف اول/دوم در پایین هر صفحه درج می‌شود</span>
</div>
${pages}
${paginationScript()}
</body>
</html>`;
}

/**
 * چاپ اسناد در پنجره جدید — صفحه‌بندی پس از لود فونت‌ها انجام و سپس پنجره چاپ باز می‌شود.
 * فونت‌ها با آدرس مطلق همین سرور (پنجره about:blank آدرس نسبی را resolve نمی‌کند).
 * در محیط‌هایی که popup مسدود است، به‌صورت fallback در iframe مخفی چاپ می‌شود.
 */
export function printSections(sections: PrintSection[], docTitle: string, opts: { paperSize?: ContractPaperSize } = {}): void {
  const html = buildPrintDocument(sections, docTitle, { baseUrl: window.location.origin, paperSize: opts.paperSize });
  const waitForPaginate = (win: Window | null): Promise<void> =>
    new Promise((resolve) => {
      const t0 = Date.now();
      const tick = () => {
        try {
          if (win && (win as unknown as { __hrmsPrintReady?: boolean }).__hrmsPrintReady) return resolve();
        } catch { /* cross-origin نباید رخ دهد */ }
        if (Date.now() - t0 > 5000) return resolve(); // مهلت: بدون صفحه‌بندی هم چاپ می‌کنیم
        setTimeout(tick, 120);
      };
      tick();
    });
  const w = window.open("", "_blank", "width=920,height=760");
  if (w) {
    w.document.open();
    w.document.write(html);
    w.document.close();
    w.focus();
    // چاپ پس از صفحه‌بندی (خود اسکریپت سند، پس از لود فونت‌ها پرچم می‌زند)
    void waitForPaginate(w).then(() => setTimeout(() => { try { w.focus(); w.print(); } catch { /* کاربر خودش دکمه چاپ را می‌زند */ } }, 250));
    return;
  }
  // fallback: iframe مخفی
  const f = document.createElement("iframe");
  f.style.cssText = "position:fixed;left:200%;bottom:200%;width:0;height:0;border:0;visibility:hidden;";
  document.body.appendChild(f);
  f.onload = () => {
    void waitForPaginate(f.contentWindow).then(() => {
      try {
        f.contentWindow?.focus();
        f.contentWindow?.print();
      } catch { /* noop */ }
      setTimeout(() => f.remove(), 60_000);
    });
  };
  f.srcdoc = html;
}

/** دانلود همان سند چاپی به‌صورت فایل HTML خودکفا — فونت‌ها base64 داخل فایل (بدون نیاز به سرور) */
export async function downloadPrintDocument(
  sections: PrintSection[],
  docTitle: string,
  fileName: string,
  opts: { paperSize?: ContractPaperSize } = {},
): Promise<void> {
  const baseUrl = window.location.origin;
  const embeddedFonts = await fetchEmbeddedFonts(baseUrl);
  const html = buildPrintDocument(sections, docTitle, { baseUrl, embeddedFonts, paperSize: opts.paperSize });
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName.endsWith(".html") ? fileName : `${fileName}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

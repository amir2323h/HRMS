// ============================================================
// زمان‌بندی تغییر حقوق — موکول کردن افزایش حقوق به ماه‌های آینده
// گردش کار: «از آبان حقوق این کارمند X می‌شود و از بهمن Y»
//   ثبت زمان‌بندی PENDING (به‌ازای هر کارمند+ماه یک مورد)
//   ← رسیدن ماه: محاسبه لیست حقوق همان ماه (خودکار) یا دکمه
//     «اعمال موارد سررسیدشده» / «اعمال فوری»
//   ← به‌روزرسانی حقوق پایه پرونده + ثبت در لاگ/آرشیو تغییرات
// ============================================================
import { db } from "@/lib/db";
import type { SessionUser } from "@/lib/auth";
import { audit } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import {
  estimateNet,
  estimateNetWith,
  type EmployeeSalaryLike,
} from "@/lib/salary";
import { todayJalaliStr, JALALI_MONTHS } from "@/lib/jalali";
import { fmtToman } from "@/lib/format";
import { logEmployeeChange, type ChangeEntry } from "@/lib/employee-changelog";

// ------------------- انواع -------------------

export type SalaryScheduleRecord = {
  id: string;
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  year: number;
  month: number;
  monthLabel: string; // «آبان ۱۴۰۵»
  newBaseSalary: number; // ریال
  currentBaseSalary: number; // ریال — حقوق پایه زنده کارمند (فقط برای نمایش)
  reason: string;
  status: string; // PENDING | APPLIED | CANCELED
  createdBy: string;
  createdByName: string;
  createdAt: string;
  appliedAt: string | null;
  appliedByName: string;
};

export type ScheduleInput = {
  employeeId: string;
  year: number;
  month: number;
  newBaseSalary: number; // ریال
  reason?: string;
};

// ------------------- ابزارها -------------------

/** برچسب فارسی ماه اعمال — «آبان ۱۴۰۵» */
export function scheduleMonthLabel(year: number, month: number): string {
  return `${JALALI_MONTHS[Math.min(12, Math.max(1, month)) - 1]} ${year}`;
}

/** شاخص ترتیبی ماه جلالی — برای مقایسه «سررسید» */
export function ymIndex(year: number, month: number): number {
  return year * 12 + month;
}

export function todayYm(): { year: number; month: number } {
  const t = todayJalaliStr(); // "YYYY/MM/DD"
  const [y, m] = t.split("/").map((x) => parseInt(x, 10));
  return { year: y, month: m };
}

export function serializeSchedule(
  s: Record<string, unknown> & { employee?: Record<string, unknown> | null }
): SalaryScheduleRecord {
  const emp = (s.employee || {}) as Record<string, unknown>;
  return {
    id: s.id as string,
    employeeId: s.employeeId as string,
    employeeName: emp.firstName ? `${emp.firstName} ${emp.lastName}` : "",
    personnelCode: (emp.personnelCode as string) || "",
    year: (s.year as number) || 0,
    month: (s.month as number) || 0,
    monthLabel: scheduleMonthLabel((s.year as number) || 0, (s.month as number) || 0),
    newBaseSalary: Number(s.newBaseSalary || 0),
    currentBaseSalary: emp.baseSalary !== undefined ? Number(emp.baseSalary) : 0,
    reason: (s.reason as string) || "",
    status: (s.status as string) || "PENDING",
    createdBy: (s.createdBy as string) || "",
    createdByName: (s.createdByName as string) || "",
    createdAt: (s.createdAt as Date).toISOString(),
    appliedAt: s.appliedAt ? (s.appliedAt as Date).toISOString() : null,
    appliedByName: (s.appliedByName as string) || "",
  };
}

// ------------------- ثبت / به‌روزرسانی -------------------

/**
 * ثبت زمان‌بندی (ذخیره برای ماه آینده) — به‌ازای هر کارمند+ماه حداکثر یک
 * زمان‌بندی PENDING: ثبت مجدد همان ماه، مورد قبلی را به‌روزرسانی می‌کند.
 */
export async function upsertSchedules(
  session: SessionUser,
  inputs: ScheduleInput[]
): Promise<{ created: number; updated: number; skipped: number; errors: string[] }> {
  const { year: curY, month: curM } = todayYm();
  let created = 0;
  let updated = 0;
  let skipped = 0;
  const errors: string[] = [];

  for (const input of inputs.slice(0, 200)) {
    const emp = await db.employee.findUnique({ where: { id: input.employeeId } });
    if (!emp) {
      errors.push("کارمند یافت نشد");
      skipped += 1;
      continue;
    }
    const year = Math.round(+input.year || 0);
    const month = Math.round(+input.month || 0);
    const newBase = Math.max(0, Math.round(input.newBaseSalary || 0));
    if (!year || !month || month < 1 || month > 12) {
      errors.push(`${emp.firstName} ${emp.lastName}: سال/ماه اعمال نامعتبر است`);
      skipped += 1;
      continue;
    }
    if (year < curY || (year === curY && month < curM)) {
      errors.push(
        `${emp.firstName} ${emp.lastName}: ماه اعمال (${scheduleMonthLabel(year, month)}) در گذشته است — برای ماه‌های گذشته از «پیش‌نویس تغییر حقوق» استفاده کنید`
      );
      skipped += 1;
      continue;
    }
    if (year > curY + 5) {
      errors.push(`${emp.firstName} ${emp.lastName}: سال اعمال حداکثر ${curY + 5} می‌تواند باشد`);
      skipped += 1;
      continue;
    }
    if (newBase <= 0) {
      errors.push(`${emp.firstName} ${emp.lastName}: حقوق ماهانه جدید نامعتبر است`);
      skipped += 1;
      continue;
    }

    const data = {
      year,
      month,
      newBaseSalary: BigInt(newBase),
      reason: (input.reason || "").slice(0, 500),
      status: "PENDING" as const,
      createdBy: session.uid,
      createdByName: session.fullName,
      appliedAt: null,
      appliedBy: "",
      appliedByName: "",
    };

    // حداکثر یک زمان‌بندی PENDING به‌ازای کارمند+ماه — ثبت مجدد = به‌روزرسانی
    const existing = await db.salarySchedule.findFirst({
      where: { employeeId: emp.id, year, month, status: "PENDING" },
    });
    if (existing) {
      await db.salarySchedule.update({ where: { id: existing.id }, data });
      updated += 1;
    } else {
      await db.salarySchedule.create({ data: { ...data, employeeId: emp.id } });
      created += 1;
    }
  }

  if (created + updated > 0) {
    await audit(
      session,
      "CREATE",
      "SALARY_SCHEDULE",
      "BULK",
      `ثبت ${created + updated} زمان‌بندی تغییر حقوق برای ماه‌های آینده (${created} جدید، ${updated} به‌روزرسانی)`,
      undefined,
      { created, updated, skipped }
    );
  }

  return { created, updated, skipped, errors };
}

// ------------------- اعمال -------------------

/**
 * اعمال زمان‌بندی‌ها روی پرونده کارکنان + ثبت لاگ/آرشیو.
 *  ids = "DUE" → فقط موارد سررسیدشده (ماه اعمال ≤ ماه مرجع)
 *  ids = آرایه → اعمال فوری موارد انتخابی (صرف‌نظر از تاریخ)
 * مرجع سررسید: پیش‌فرض امروز؛ در محاسبه لیست حقوق = ماه همان دوره.
 */
export async function applySchedules(
  session: SessionUser,
  ids: string[] | "DUE",
  upto?: { year: number; month: number },
  note?: string
): Promise<{ applied: number; totalDelta: number }> {
  const params = await getLegalParams();
  const atDateJ = todayJalaliStr();
  const ref = upto || todayYm();
  const refIdx = ymIndex(ref.year, ref.month);

  const where =
    ids === "DUE"
      ? { status: "PENDING" }
      : { status: "PENDING", id: { in: ids } };

  const schedules = await db.salarySchedule.findMany({
    where,
    include: { employee: { include: { jobGrade: true } } },
    orderBy: [{ year: "asc" }, { month: "asc" }, { createdAt: "asc" }],
  });

  // در حالت DUE فقط موارد سررسیدشده (ماه اعمال ≤ ماه مرجع)
  const due = schedules.filter((s) => ids === "DUE" ? ymIndex(s.year, s.month) <= refIdx : true);

  let applied = 0;
  let totalDelta = 0;

  for (const s of due) {
    const emp = s.employee;
    const liveOldBase = Number(emp.baseSalary);
    const newBase = Number(s.newBaseSalary);

    const oldNet = estimateNet(emp as unknown as EmployeeSalaryLike, params, atDateJ).netPay;

    // به‌روزرسانی حقوق پایه پرونده
    await db.employee.update({
      where: { id: emp.id },
      data: { baseSalary: BigInt(newBase) },
    });

    const newNet = estimateNetWith(emp as unknown as EmployeeSalaryLike, params, atDateJ, {
      baseSalary: newBase,
    }).netPay;

    const deltaAmount = newBase - liveOldBase;
    const deltaPercent = liveOldBase > 0 ? (deltaAmount / liveOldBase) * 100 : 0;
    totalDelta += deltaAmount;

    const reasonText = [
      `زمان‌بندی ${scheduleMonthLabel(s.year, s.month)}`,
      s.reason,
      note,
    ]
      .filter(Boolean)
      .join(" — ")
      .slice(0, 500);

    await db.salaryChangeLog.create({
      data: {
        employeeId: emp.id,
        employeeName: `${emp.firstName} ${emp.lastName}`,
        personnelCode: emp.personnelCode,
        oldBaseSalary: BigInt(liveOldBase),
        newBaseSalary: BigInt(newBase),
        oldOvertimeHours: emp.overtimeHours,
        newOvertimeHours: emp.overtimeHours,
        oldJobGradeId: emp.jobGradeId,
        newJobGradeId: emp.jobGradeId,
        oldGradeTitle: emp.jobGrade?.title || "",
        newGradeTitle: emp.jobGrade?.title || "",
        deltaAmount: BigInt(deltaAmount),
        deltaPercent: Math.round(deltaPercent * 100) / 100,
        oldNet: BigInt(oldNet),
        newNet: BigInt(newNet),
        source: "SCHEDULE",
        reason: reasonText,
        draftId: s.id,
        performedBy: session.uid,
        performedByName: session.fullName,
      },
    });

    // ——— ثبت همزمان در لاگ تغییرات پرونده پرسنل ———
    if (newBase !== liveOldBase) {
      const empChanges: ChangeEntry[] = [
        {
          field: "baseSalary",
          label: "حقوق پایه",
          kind: "money",
          from: String(liveOldBase),
          to: String(newBase),
          fromDisplay: fmtToman(liveOldBase),
          toDisplay: fmtToman(newBase),
        },
      ];
      await logEmployeeChange(session, emp.id, empChanges, "SALARY", `اعمال ${reasonText}`);
    }

    await db.salarySchedule.update({
      where: { id: s.id },
      data: {
        status: "APPLIED",
        appliedAt: new Date(),
        appliedBy: session.uid,
        appliedByName: session.fullName,
      },
    });
    applied += 1;
  }

  if (applied > 0) {
    await audit(
      session,
      "APPROVE",
      "SALARY_SCHEDULE",
      ids === "DUE" ? "DUE" : ids.join(","),
      `اعمال ${applied} زمان‌بندی تغییر حقوق${ids === "DUE" ? ` (سررسیدشده تا ${scheduleMonthLabel(ref.year, ref.month)})` : ""} — جمع تغییر پایه: ${totalDelta.toLocaleString("en-US")} ریال`,
      undefined,
      { applied, totalDelta }
    );
  }

  return { applied, totalDelta };
}

/** اعمال موارد سررسیدشده تا ماه یک دوره حقوق — قلاب محاسبه لیست حقوق */
export async function applyDueSchedulesForPeriod(
  session: SessionUser,
  year: number,
  month: number
): Promise<number> {
  const r = await applySchedules(session, "DUE", { year, month });
  return r.applied;
}

// ------------------- لغو -------------------

/** لغو زمان‌بندی‌های در انتظار (حذف منطقی — سابقه نگه داشته می‌شود) */
export async function cancelSchedules(
  session: SessionUser,
  ids: string[]
): Promise<number> {
  const schedules = await db.salarySchedule.findMany({
    where: { status: "PENDING", id: { in: ids } },
    include: { employee: { select: { firstName: true, lastName: true } } },
  });
  for (const s of schedules) {
    await db.salarySchedule.update({
      where: { id: s.id },
      data: {
        status: "CANCELED",
        appliedBy: session.uid,
        appliedByName: session.fullName,
        appliedAt: new Date(),
      },
    });
  }
  if (schedules.length > 0) {
    await audit(
      session,
      "DELETE",
      "SALARY_SCHEDULE",
      ids.join(","),
      `لغو ${schedules.length} زمان‌بندی تغییر حقوق`
    );
  }
  return schedules.length;
}

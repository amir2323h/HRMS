// ============================================================
// ترجمه خطاهای Prisma به پیام فارسی قابل فهم برای کاربر
//  تا متن خام دیتابیس (مثل Unique constraint failed …) هرگز
//  به رابط کاربری راه پیدا نکند.
// ============================================================
import { Prisma } from "@prisma/client";

/** نام فارسی فیلدهای حساس به یکتایی — برای پیام دقیق‌تر */
const FIELD_FA: Record<string, string> = {
  personnelCode: "کد پرسنلی",
  nationalId: "کد ملی",
  username: "نام کاربری",
  code: "کد",
  level: "سطح",
  title: "عنوان",
  decreeNo: "شماره حکم",
  letterNo: "شماره نامه",
  periodKey: "دوره حقوق",
  name: "نام",
};

/** آیا خطای فعلی «نقض یکتایی» است؟ (P2002) */
export function isUniqueViolation(err: unknown): boolean {
  return err instanceof Prisma.PrismaClientKnownRequestError && err.code === "P2002";
}

/** فیلدهای درگیر نقض یکتایی از متادیتای خطا */
function uniqueFields(err: Prisma.PrismaClientKnownRequestError): string[] {
  const target = (err.meta as { target?: unknown })?.target;
  if (Array.isArray(target)) return target.map(String);
  if (typeof target === "string") return [target];
  return [];
}

/**
 * پیام فارسی معادل خطای Prisma — اگر خطا شناخته‌نشده باشد
 * null برمی‌گرداند تا فراخواننده از مسیر پیش‌فرض خود استفاده کند.
 */
export function prismaFaMessage(err: unknown): { message: string; status: number } | null {
  if (!(err instanceof Prisma.PrismaClientKnownRequestError)) return null;

  if (err.code === "P2002") {
    const fields = uniqueFields(err)
      .map((f) => FIELD_FA[f] || f)
      .join("، ");
    const where = fields ? ` (${fields})` : "";
    return {
      message: `مقدار واردشده قبلاً ثبت شده است — رکورد تکراری${where}. لطفاً مقدار دیگری وارد کنید یا رکورد موجود را ویرایش کنید.`,
      status: 409,
    };
  }

  if (err.code === "P2025") {
    return {
      message: "رکورد مورد نظر یافت نشد — ممکن است هم‌زمان توسط کاربر دیگری حذف یا تغییر کرده باشد. صفحه را تازه کنید و دوباره تلاش کنید.",
      status: 404,
    };
  }

  if (err.code === "P2003") {
    return {
      message: "این عملیات انجام نشد چون رکورد به داده‌های دیگری متصل است. ابتدا رکوردهای وابسته را بررسی کنید.",
      status: 409,
    };
  }

  return null;
}

// ============================================================
// Backfill v2.9.23 — تبدیل گروهی پرسنل به کاربر سامانه
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۳
//  ۳) پاکسازی کش وضعیت آپدیت
// قابلیت جدید: در «مدیریت کارکنان» انتخاب گروهی پرسنل و ایجاد
// حساب کاربری با یک کلیک — نام کاربری = شماره موبایل، رمز عبور =
// کد ملی، نقش پیش‌فرض = EMPLOYEE (کاربر عادی). API جدید
// POST /api/users/from-employees با اعتبارسنجی کامل (ترک‌کار /
// کاربر موجود / موبایل و کد ملی نامعتبر → رد با ذکر دلیل).
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2923.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2922 = {
  version: "2.9.23",
  title: "تازه‌های نسخه ۲.۹.۲۳",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "تبدیل پرسنل به کاربر سامانه (گروهی)",
      desc: "در «مدیریت کارکنان» هر تعداد کارمند را انتخاب کنید و با دکمه «تبدیل به کاربر سامانه» یک‌جا برای همه‌شان حساب کاربری بسازید: نام کاربری = شماره موبایل، رمز عبور = کد ملی، نقش پیش‌فرض = کاربر عادی (کارمند). کاربر ساخته‌شده به پرونده همان کارمند متصل می‌شود و پرتال خودخدماتی (فیش حقوقی، مرخصی، مساعده و درخواست‌نامه) را می‌بیند. افرادی که ترک کار کرده‌اند، قبلاً کاربر دارند یا موبایل/کد ملی معتبر ندارند، با ذکر دلیل رد می‌شوند؛ نقش هر کاربر هنگام ساخت قابل تغییر است و کنار نام کارکنانِ دارای حساب، نشان «کاربر» نمایش داده می‌شود.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2922) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۳» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.23") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2922) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۳» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

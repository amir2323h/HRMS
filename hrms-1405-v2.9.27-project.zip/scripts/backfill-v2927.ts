// ============================================================
// Backfill v2.9.27 — زمان‌بندی افزایش حقوق برای ماه‌های آینده
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۷
//  ۳) پاکسازی کش وضعیت آپدیت
// قابلیت جدید:
//  • تب «زمان‌بندی افزایش» در مدیریت تغییرات حقوق: تعیین حقوق
//    ماهانه هر کارمند برای ماه‌های آینده (مثلاً از آبان X و از
//    بهمن Y) — با رسیدن ماه، هنگام محاسبه لیست حقوق همان ماه
//    خودکار اعمال می‌شود؛ اعمال فوری/لغو + تاریخچه کامل.
//  (جدول salary_schedules با prisma db push ساخته می‌شود)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2927.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2927 = {
  version: "2.9.27",
  title: "تازه‌های نسخه ۲.۹.۲۷",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "زمان‌بندی افزایش حقوق برای ماه‌های آینده",
      desc: "در «مدیریت تغییرات حقوق»، تب جدید «زمان‌بندی افزایش»: برای هر کارمند تعیین کنید حقوق ماهانه‌اش از چه ماهی و با چه مبلغی تغییر کند — مثلاً «از آبان ۲۰ میلیون تومان و از بهمن ۲۲ میلیون تومان». چند ماه را هم‌زمان در یک فرم ثبت کنید (ثبت مجدد همان ماه، مورد قبلی را به‌روزرسانی می‌کند) و پیش‌نمایش تغییر درصدی و خالص تخمینی هر ماه را همان لحظه ببینید. با رسیدن ماهِ هر زمان‌بندی، هنگام «محاسبه لیست حقوق» همان ماه تغییر خودکار روی پرونده اعمال و در تاریخچه حقوق ثبت می‌شود؛ برای اطمینان، دکمه «اعمال موارد سررسیدشده» و «اعمال فوری» هم در دسترس است. لغو زمان‌بندی، نشانگر «سررسید رسیده / N ماه مانده»، فیلتر منشأ «زمان‌بندی ماهانه» در تاریخچه و خروجی اکسل نیز اضافه شده است.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2927) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۷» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.27") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2927) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۷» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.24 — تغییر گروهی نقش کاربران + حفاظت نقش در تبدیل پرسنل
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۴
//  ۳) پاکسازی کش وضعیت آپدیت
// قابلیت‌های جدید:
//  • «تنظیمات → کاربران»: انتخاب گروهی کاربران (چک‌باکس) + دکمه
//    «تغییر گروهی نقش» با پیش‌نمایش (حساب خودتان / آخرین مدیر کل /
//    دارندگان همان نقش → رد) و گزارش نتیجه. API جدید
//    POST /api/users/bulk-role با حفاظت‌های امنیتی و لاگ حسابرسی.
//  • تبدیل گروهی پرسنل به کاربر: نقش «مدیر کل سیستم» از فهرست حذف
//    شد و سرور درخواست آن را رد می‌کند (جلوگیری از خطای انسانی)؛
//    نام نقش روی دکمه تأیید نمایش داده می‌شود.
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2924.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2924 = {
  version: "2.9.24",
  title: "تازه‌های نسخه ۲.۹.۲۴",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "تغییر گروهی نقش کاربران",
      desc: "در «تنظیمات → کاربران» حالا می‌توانید هر تعداد کاربر را با چک‌باکس انتخاب کنید و با دکمه «تغییر گروهی نقش»، نقش همه را یک‌جا تغییر دهید. پیش از اعمال، پیش‌نمایش دقیق نشان می‌دهد چه کسی تغییر می‌کند و چه کسی به‌دلیل حفاظت‌های امنیتی رد می‌شود (حساب کاربری خودتان، آخرین مدیر کل فعال سامانه و کسانی که از قبل همان نقش را دارند) و پس از اعمال، فهرست تغییرکردگان و ردشده‌ها با ذکر دلیل نمایش داده می‌شود. برای اصلاح گروهی کاربرانی که مثلاً پس از تبدیل پرسنل با نقش اشتباه ساخته شده‌اند، یک‌کلیکی است.",
    },
    {
      tag: "FIX",
      title: "حفاظت نقش در تبدیل گروهی پرسنل به کاربر",
      desc: "در تبدیل گروهی پرسنل به کاربر سامانه، نقش «مدیر کل سیستم» دیگر در فهرست نقش‌ها نمایش داده نمی‌شود و سرور هم درخواست ساخت کاربر مدیر کل از این مسیر را رد می‌کند — نقش مدیر کل فقط به‌صورت دستی و تک‌تک از «کاربران و دسترسی‌ها» قابل تعیین است. علاوه بر این، نام نقش انتخابی همیشه در دکمه تأیید (مثلاً «ایجاد حساب برای ۵ نفر با نقش «کارمند»») و در فیلد نقش نمایش داده می‌شود تا همیشه دقیقاً معلوم باشد چه نقشی ساخته می‌شود.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2924) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۴» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.24") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2924) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۴» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

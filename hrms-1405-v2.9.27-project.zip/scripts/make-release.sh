#!/usr/bin/env bash
# ================================================================
# سازنده بسته انتشار نسخه‌دار — HRMS 1405
#  ۱) نصب‌کننده تک‌فایل: download/install-hrms-v{V}.sh (+ کپی install-hrms.sh)
#  ۲) آرشیو کامل پروژه:  download/hrms-1405-v{V}-project.zip  (+ کپی بدون نسخه)
#  ۳) راستی‌آزمایی هر دو خروجی
# ================================================================
set -euo pipefail
cd "$(dirname "$0")/.."   # ریشه پروژه

VERSION="${1:-1.5.0}"
OUT_DIR="download"
TMP_TAR="$(mktemp /tmp/hrms-src-XXXXXX.tar.gz)"
TMP_B64="$(mktemp /tmp/hrms-payload-XXXXXX.b64)"
PROBE="$(mktemp -d)"
trap 'rm -rf "$TMP_TAR" "$TMP_B64" "$PROBE"' EXIT

info() { echo "◈ $*"; }
ok()   { echo "✓ $*"; }

mkdir -p "$OUT_DIR"

# هم‌گام‌سازی ENV APP_VERSION داکر با نسخه بسته (رفع باگ نمایش نسخه در داکر)
if [ -f Dockerfile ] && rg -q '^ *APP_VERSION=' Dockerfile 2>/dev/null; then
  sed -i.bak "s/^\( *APP_VERSION=\).*/\1${VERSION}/" Dockerfile && rm -f Dockerfile.bak
  info "ENV APP_VERSION داکر ← ${VERSION}"
fi

# ---------- ۱) نصب‌کننده تک‌فایل ----------
info "ساخت نصب‌کننده نسخه ${VERSION}…"
WHITELIST=(
  ./src
  ./public
  ./prisma
  ./scripts/backfill-v4.ts
  ./scripts/backfill-v5.ts
  ./scripts/backfill-v8.ts
  ./scripts/backfill-v9.ts
  ./scripts/backfill-v10.ts
  ./scripts/backfill-v27.ts
  ./scripts/backfill-v271.ts
  ./scripts/backfill-v272.ts
  ./scripts/backfill-v273.ts
  ./scripts/backfill-v28.ts
  ./scripts/backfill-v281.ts
  ./scripts/backfill-v29.ts
  ./scripts/backfill-v291.ts
  ./scripts/backfill-v292.ts
  ./scripts/backfill-v293.ts
  ./scripts/backfill-v294.ts
  ./scripts/backfill-v295.ts
  ./scripts/backfill-v296.ts
  ./scripts/backfill-v297.ts
  ./scripts/backfill-v298.ts
  ./scripts/backfill-v299.ts
  ./scripts/backfill-v2910.ts
  ./scripts/backfill-v2911.ts
  ./scripts/backfill-v2912.ts
  ./scripts/backfill-v2913.ts
  ./scripts/backfill-v2914.ts
  ./scripts/backfill-v2915.ts
  ./scripts/backfill-v2917.ts
  ./scripts/backfill-v2918.ts
  ./scripts/backfill-v2919.ts \
  ./scripts/backfill-v2920.ts
  ./scripts/backfill-v2921.ts
  ./scripts/backfill-v2922.ts
  ./scripts/backfill-v2923.ts
  ./scripts/backfill-v2924.ts
  ./scripts/backfill-v2925.ts
  ./scripts/backfill-v2926.ts
  ./scripts/backfill-v2927.ts
  ./scripts/nixpacks-prebuild.mjs
  ./scripts/purge-demo.ts
  ./scripts/docker-bootstrap.mjs
  ./scripts/docker-set-admin-password.mjs
  ./package.json
  ./package-lock.json
  ./bun.lock
  ./.nvmrc
  ./.gitignore
  ./.dockerignore
  ./eslint.config.mjs
  ./nixpacks.toml
  ./next.config.ts
  ./tsconfig.json
  ./tailwind.config.ts
  ./postcss.config.mjs
  ./components.json
  ./next-env.d.ts
)
for item in "${WHITELIST[@]}"; do
  [ -e "$item" ] || { echo "✗ مورد فهرست سفید یافت نشد: $item"; exit 1; }
done
# public/downloads (زیپ‌های منتشرشده) در پی‌لود نصب‌کننده جایی ندارد — حذف از tar
tar -czf "$TMP_TAR" --exclude="public/downloads/*" "${WHITELIST[@]}"

info "کدگذاری بسته (base64)…"
base64 -w 76 "$TMP_TAR" > "$TMP_B64"
SRC_KB=$(( $(du -k "$TMP_TAR" | cut -f1) ))

TEMPLATE="scripts/installer-template.sh"
[ -f "$TEMPLATE" ] || { echo "✗ قالب نصب‌کننده یافت نشد"; exit 1; }

INSTALLER_V="${OUT_DIR}/install-hrms-v${VERSION}.sh"
{
  # نسخه را در قالب تزریق می‌کنیم (اگر قالب مقدار پیش‌فرض دارد، همان می‌ماند)
  sed "s/^APP_VERSION=\".*\"/APP_VERSION=\"${VERSION}\"/; s/^APP_VERSION_FA=\".*\"/APP_VERSION_FA=\"$(echo "$VERSION" | sed 's/0/۰/g; s/1/۱/g; s/2/۲/g; s/3/۳/g; s/4/۴/g; s/5/۵/g; s/6/۶/g; s/7/۷/g; s/8/۸/g; s/9/۹/g; s/\\./\\./g')\"/" "$TEMPLATE"
  echo ""
  echo "# ================== پی‌لود بسته (سورس، base64) =================="
  echo "# این بخش توسط اسکریپت استخراج می‌شود — دستکاری نکنید"
  echo "__PAYLOAD_B64__"
  cat "$TMP_B64"
} > "$INSTALLER_V"
chmod +x "$INSTALLER_V"

# راستی‌آزمایی نصب‌کننده
bash -n "$INSTALLER_V" || { echo "✗ خطای سینتکس"; exit 1; }
grep -q '^__PAYLOAD_B64__$' "$INSTALLER_V" || { echo "✗ مارکر پی‌لود گم شد"; exit 1; }
awk 'f{print} /^__PAYLOAD_B64__$/{f=1}' "$INSTALLER_V" | base64 -d | tar -xzf - -C "$PROBE" 2>/dev/null
[ -f "$PROBE/package.json" ] && [ -f "$PROBE/prisma/schema.prisma" ] && [ -f "$PROBE/public/fonts/BNazanin.woff2" ] \
  || { echo "✗ راستی‌آزمایی استخراج نصب‌کننده ناموفق"; exit 1; }
COUNT_INSTALLER=$(find "$PROBE" -type f | wc -l)
cp "$INSTALLER_V" "${OUT_DIR}/install-hrms.sh"
ok "نصب‌کننده: ${INSTALLER_V} ($(( $(du -k "$INSTALLER_V" | cut -f1) ))KB، ${COUNT_INSTALLER} فایل سورس)"

# ---------- ۲) آرشیو کامل پروژه ----------
info "ساخت آرشیو کامل پروژه نسخه ${VERSION}…"
rm -rf "$PROBE"; PROBE="$(mktemp -d)"
ZIP_V="${OUT_DIR}/hrms-1405-v${VERSION}-project.zip"

zip -r -q "$ZIP_V" \
  src public prisma scripts/backfill-v4.ts scripts/backfill-v5.ts scripts/backfill-v8.ts scripts/backfill-v9.ts scripts/backfill-v10.ts scripts/backfill-v27.ts scripts/backfill-v271.ts scripts/backfill-v272.ts scripts/backfill-v273.ts scripts/backfill-v28.ts scripts/backfill-v281.ts scripts/backfill-v29.ts scripts/backfill-v291.ts scripts/backfill-v292.ts scripts/backfill-v293.ts scripts/backfill-v294.ts scripts/backfill-v295.ts scripts/backfill-v296.ts scripts/backfill-v297.ts scripts/backfill-v298.ts scripts/backfill-v299.ts scripts/backfill-v2910.ts scripts/backfill-v2911.ts scripts/backfill-v2912.ts scripts/backfill-v2913.ts scripts/backfill-v2914.ts scripts/backfill-v2915.ts scripts/backfill-v2917.ts scripts/backfill-v2918.ts scripts/backfill-v2919.ts scripts/backfill-v2920.ts scripts/backfill-v2921.ts scripts/backfill-v2922.ts scripts/backfill-v2923.ts scripts/backfill-v2924.ts scripts/backfill-v2925.ts scripts/backfill-v2926.ts scripts/backfill-v2927.ts scripts/nixpacks-prebuild.mjs scripts/nixpacks-start.mjs scripts/purge-demo.ts scripts/docker-bootstrap.mjs scripts/docker-set-admin-password.mjs \
  scripts/make-installer.sh scripts/make-release.sh scripts/installer-template.sh scripts/build-letter-fonts.py \
  Dockerfile docker-compose.yml docker-entrypoint.sh .dockerignore DOCKER-GUIDE.md DOCPLOY-GUIDE.md \
  .nvmrc .gitignore eslint.config.mjs bun.lock nixpacks.toml \
  db/custom.db \
  package.json package-lock.json next.config.ts tsconfig.json tailwind.config.ts postcss.config.mjs components.json \
  Caddyfile \
  -x "*/node_modules/*" "*/.next/*" "*/tool-results/*" "public/downloads/*"
# فایل .env.example برای توسعه‌دهنده (نسخه از متغیر VERSION تزریق می‌شود)
cat > "$PROBE/.env.example" <<ENVEOF
# محیط توسعه — برای استقرار واقعی AUTH_SECRET جدید تولید کنید
DATABASE_URL=file:./db/custom.db
AUTH_SECRET=change-me-to-a-64-char-random-hex
# نسخه نصب‌شده — نمایش در فوتر/صفحه ورود + مبنای چک آپدیت پنل
APP_VERSION=${VERSION}

# ── فقط برای نصب Docker (docker compose) ──
# اگر هنگام بیلد خطای 403 از Docker Hub گرفتید، این فایل را به .env تغییر نام دهید
# و خط زیر را از حالت کامنت خارج کنید (آینه جایگزین ایمیج پایه):
# NODE_IMAGE=mirror.gcr.io/library/node:22-bookworm-slim

# ── استقرار روی PaaS با Build Type = Nixpacks (داکپلوی و…) ──
# راهنمای کامل: DOCPLOY-GUIDE.md — برای ماندگاری داده‌ها روی داکپلوی کافی است
# در Advanced → Volumes/Mounts یک Volume با Mount Path=/data بسازید (متغیر لازم نیست؛
# اسکریپت scripts/nixpacks-start.mjs والیوم را خودکار تشخیص می‌دهد و دیتابیس را
# از /data/custom.db می‌خواند/می‌سازد — آپدیت‌ها دیگر داده‌ها را پاک نمی‌کنند).
# اگر والیوم در مسیر دیگری است، این متغیر را در پنل پلتفرم تنظیم کنید:
# DATABASE_URL=file:/data/custom.db
ENVEOF
zip -q "$ZIP_V" -j "$PROBE/.env.example"

# راستی‌آزمایی زیپ (فهرست را یک‌بار می‌گیریم؛ grep با herestring تا pipefail/SIGPIPE خطای کاذب ندهد)
unzip -t -q "$ZIP_V" >/dev/null || { echo "✗ زیپ خراب است"; exit 1; }
ZIP_LISTING="$(unzip -l "$ZIP_V")"
for must in "src/app/page.tsx" "prisma/schema.prisma" "public/fonts/BNazanin.woff2" "public/fonts/NotoNastaliqUrdu.woff2" "db/custom.db" "package.json" ".env.example" "Dockerfile" "docker-compose.yml" "docker-entrypoint.sh" "DOCKER-GUIDE.md" "DOCPLOY-GUIDE.md" ".nvmrc" "nixpacks.toml" "scripts/nixpacks-prebuild.mjs" "scripts/nixpacks-start.mjs" "scripts/docker-bootstrap.mjs" "scripts/backfill-v2917.ts" "scripts/backfill-v2918.ts" "scripts/backfill-v2919.ts" "scripts/backfill-v2920.ts" "scripts/backfill-v2921.ts" "scripts/backfill-v2922.ts" "scripts/backfill-v2923.ts" "scripts/backfill-v2924.ts" "scripts/backfill-v2925.ts" "scripts/backfill-v2926.ts" "scripts/backfill-v2927.ts" "bun.lock" ".gitignore" "eslint.config.mjs"; do
  grep -q "$must" <<<"$ZIP_LISTING" || { echo "✗ فایل الزامی در زیپ نیست: $must"; exit 1; }
done
COUNT_ZIP=$(unzip -l "$ZIP_V" | tail -1 | awk '{print $2}')
cp "$ZIP_V" "${OUT_DIR}/hrms-1405-project.zip"
ok "آرشیو: ${ZIP_V} ($(( $(du -k "$ZIP_V" | cut -f1) ))KB، ${COUNT_ZIP} فایل)"

echo ""
echo "✓ بسته انتشار نسخه ${VERSION} آماده شد:"
echo "   نصب‌کننده تک‌فایل: download/install-hrms-v${VERSION}.sh"
echo "   آرشیو کامل:        download/hrms-1405-v${VERSION}-project.zip"

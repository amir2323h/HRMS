// ============================================================
// Backfill v2.9.21 — رفع خطای ثبت دستی کارمند (تکرار کد پرسنلی)
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۱
//  ۳) پاکسازی کش وضعیت آپدیت
// زمینه: کد پرسنلی خودکار در ثبت دستی بر اساس «تعداد کارکنان» ساخته
// می‌شد؛ با حذف کارمند یا ایمپورت اکسل (کدهای ناپیوسته) با کد موجود
// تداخل می‌کرد و خطای خام Prisma (P2002) به کاربر می‌رسید. اکنون کد از
// بزرگ‌ترین پسوند موجود +۱ ساخته می‌شود (lib/personnel-code.ts مشترک
// بین ثبت دستی و ایمپورت) و خطاهای یکتایی دیتابیس به پیام فارسی
// ترجمه می‌شوند (lib/prisma-errors.ts).
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2921.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2921 = {
  version: "2.9.21",
  title: "تازه‌های نسخه ۲.۹.۲۱",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "رفع خطای ثبت دستی کارمند جدید (تکرار کد پرسنلی)",
      desc: "اگر کارمندانی حذف شده یا با ایمپورت اکسل ثبت شده باشند، تولید کد پرسنلی بر اساس «تعداد کارکنان» می‌توانست با کد موجود تداخل کند و ثبت با خطای دیتابیس متوقف شود. اکنون کد پرسنلی یکتا از «بزرگ‌ترین شماره موجود + ۱» ساخته می‌شود و هرگز تداخل نمی‌کند؛ پس از ثبت، کد اختصاص‌یافته در پیام موفقیت نمایش داده می‌شود. علاوه بر این، خطاهای یکتایی دیتابیس (مثل کد ملی تکراری) به پیام فارسی خوانا ترجمه می‌شوند تا متن فنی هرگز به کاربر نرسد.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2921) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۱» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.21") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2921) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۱» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

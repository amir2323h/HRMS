// ============================================================
// Backfill v2.9.25 — رفع خطای بیلد استقرار روی داکپلوی (Dokploy)
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۵
//  ۳) پاکسازی کش وضعیت آپدیت
// شرح رفع مشکل:
//  • خطای بیلد «Export isSessionCurrent doesn't exist in target module»
//    (شکستن npm run build روی داکپلوی/Nixpacks به‌دلیل فایل
//    src/proxy.ts دست‌کاری‌شده در مخزن کاربر) با دو کار رفع شد:
//    ۱) افزودن تابع isSessionCurrent به src/lib/auth.ts
//    ۲) ارسال نسخه استاندارد و امن src/proxy.ts در بسته تا نسخه
//       معیوب مخزن را بازنویسی کند (proxy حداقلی Next.js 16 —
//       فقط بهداشت کوکی نشست در مسیرهای /login و /logout).
//  • این نسخه فقط اصلاح زیرساخت استقرار است؛ هیچ تغییر داده/رفتاری ندارد.
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2925.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2925 = {
  version: "2.9.25",
  title: "تازه‌های نسخه ۲.۹.۲۵",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "رفع خطای بیلد استقرار روی داکپلوی (Dokploy)",
      desc: "خطای «Export isSessionCurrent doesn't exist in target module» که بیلد Nixpacks/داکپلوی را متوقف می‌کرد برطرف شد: تابع isSessionCurrent به کتابخانه احراز هویت (src/lib/auth.ts) اضافه شد و نسخه استاندارد و امن فایل src/proxy.ts (جانشین middleware در Next.js 16) در بسته قرار گرفت تا در صورت وجود نسخه دست‌کاری‌شده قبلی در مخزن، جای آن را بگیرد. این نسخه صرفاً اصلاح زیرساخت استقرار است؛ هیچ تغییری در داده‌ها، دسترسی‌ها و رفتار سامانه ندارد.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2925) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۵» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.25") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2925) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۵» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.18 — تثبیت پایداری بیلد بعد از به‌روزرسانی
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱۸
//  ۳) پاکسازی کش وضعیت آپدیت
// زمینه: در به‌روزرسانی ۲.۹.۱۷ محدوده نسخه Next.js باز (^16.1.1) بود و
//  آپدیتِ برخی سرورها وسط عملیات بسته‌ها را دانگرید می‌کرد که به خطای
//  بیلد «generate is not a function» می‌انجامید. از ۲.۹.۱۸ نسخه Next.js
//  روی 16.4.0 (همان نسخه پایدار قبل) قفل شده + قبل از هر بیلد،
//  Prisma Client خودکار تولید می‌شود (prebuild).
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2918.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2918 = {
  version: "2.9.18",
  title: "تازه‌های نسخه ۲.۹.۱۸",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIXED",
      title: "رفع خطای بیلد بعد از به‌روزرسانی (تثبیت نسخه Next.js)",
      desc: "در به‌روزرسانی قبلی، بازبودن محدوده نسخهٔ Next.js باعث می‌شد وسط عملیات آپدیت، بسته‌های بیلد روی سرور دانگرید شوند و بیلد با خطای «generate is not a function» شکست بخورد. اکنون Next.js روی همان نسخهٔ پایدار قبلی سرور شما (16.4.0) قفل شده است؛ آپدیت بدون جابه‌جایی بسته‌های بیلد انجام می‌شود و بیلد مثل قبل درست از آب درمی‌آید.",
    },
    {
      tag: "IMPROVED",
      title: "تولید خودکار Prisma Client پیش از هر بیلد",
      desc: "گام prebuild به فرایند بیلد اضافه شد؛ قبل از هر «npm run build» کلاینت پرایسما مطابق آخرین اسکیمای دیتابیس خودکار تولید می‌شود تا در هیچ سناریوی آپدیتی کلاینت کهنه با کد جدید بیلد نشود.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2918) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱۸» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.18") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2918) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱۸» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

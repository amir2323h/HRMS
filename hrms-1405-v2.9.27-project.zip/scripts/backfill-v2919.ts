// ============================================================
// Backfill v2.9.19 — پیش‌بینی بودجه دو-نما + حکم گروهی عیدی/پاداش
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱۹
//  ۳) پاکسازی کش وضعیت آپدیت
// زمینه: پیش‌بینی بودجه حقوق دو نما گرفت (دیتای کلی ماهانه + لیست ریز افراد
//  با نام دپارتمان)، محاسبه معکوس مبنای «عدد پایه اداره کار» گرفت (پایه =
//  حداقل دستمزد؛ مابالفاوت = سایر مزایا) و ماژول «حکم گروهی» عیدی/پاداش
//  (خالص هدف گروهی → معکوس از روی حقوق پایه هر نفر → صدور حکم → لحاظ در
//  پیش‌بینی بودجه) اضافه شد.
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2919.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2919 = {
  version: "2.9.19",
  title: "تازه‌های نسخه ۲.۹.۱۹",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "پیش‌بینی بودجه حقوق با دو نما: ماهانه + لیست ریز افراد",
      desc: "در «پیش‌بینی بودجه حقوق» خروجی دو نما دارد: «دیتای کلی ماهانه» (جدول ماه‌به‌ماه و تفکیک دپارتمان) و «لیست ریز افراد» — سطر به سطر همه کارکنان با نام دپارتمان و سطحشان، حقوق ماهانه، حقوق پایه (عدد اداره کار)، سایر مزایا (مابالفاوت)، ناخالص، خالص و جمع هزینه هر نفر در بازه. خروجی اکسل هم پنج شیت شد (ماهانه، ریز افراد، دپارتمان‌ها، احکام، سناریوهای جذب) و دکمه «تا آخر سال» اضافه شد.",
    },
    {
      tag: "NEW",
      title: "حکم گروهی عیدی/پاداش پایان سال",
      desc: "در ماژول پاداش، تب «حکم گروهی»: خالص دریافتی هر نفر را به‌صورت گروهی تعیین کنید؛ سامانه برای هر کارمند نرخ مالیات نهایی او را از حقوق پایه دستی‌اش درمی‌آورد، مبلغ ناخالص حکم را معکوس حل می‌کند (معافیت عیدی = ۲× حداقل دستمزد؛ مالیات فقط بر مازادِ معافیت) و حکم گروهی با «ضریب نسبت به حقوق پایه» هر نفر صادر می‌شود. احکام قابل ابطال‌اند و در ماه پرداختِ آنها به بودجه اضافه می‌شوند.",
    },
    {
      tag: "NEW",
      title: "محاسبه معکوس با مبنای «عدد پایه اداره کار»",
      desc: "در محاسبه معکوس، انتخاب مبنای تفکیک اضافه شد: «عدد پایه اداره کار» (حداقل دستمزد ۱۴۰۵ در «حقوق پایه» می‌نشیند و مابالفاوت در «سایر مزایا»؛ اقلام قانونی علاوه می‌شود) یا «حقوق پایه ثابت سطح» (رفتار قبلی). در پیش‌بینی بودجه هم ستون‌های حقوق پایه/سایر مزایا با همین مبنا نمایش داده می‌شوند.",
    },
    {
      tag: "NEW",
      title: "پیش‌بینی بودجه شامل احکام صادرشده",
      desc: "«پیش‌بینی بودجه حقوق» از این پس احکام گروهی صادرشده (عیدی/پاداش) را در ماه پرداختِ آنها به بودجه اضافه می‌کند — با کلید قابل خاموش/روشن کردن. جواب «چقدر بودجه تا آخر سال می‌خواهم» با دکمه «تا آخر سال» یک کلیکی درمی‌آید.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2919) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱۹» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.19") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2919) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱۹» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.15 — کارت خالص پرداختی: مبنا = جدول ثبت‌شده (۱۴۰۵)
//  ۱) خاموش‌کردن صریح «افزایش قانونی مزد ۱۴۰۵» در SystemSetting «legal_params»
//     (جدول طبقه‌بندی کاربر با ارقام ۱۴۰۵ ثبت شده — افزایش دوباره‌کار بود و
//      اعداد کارت را متورم می‌کرد؛ از v2.9.15 پیش‌فرض موتور هم خاموش است)
//  ۲) مهر نسخه در دیتابیس (SystemSetting «app_version»)
// ۳) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱۵
// ۴) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2915.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// بازگشت‌پذیر: هر وقت خواستید از «تنظیمات ← اطلاعات پایه ← افزایش قانونی مزد ۱۴۰۵» دوباره فعال کنید
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2915 = {
  version: "2.9.15",
  title: "تازه‌های نسخه ۲.۹.۱۵",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIXED",
      title: "کارت «خالص پرداختی (۱۴۰۵)» طبقه‌بندی مشاغل — مبنا مستقیماً از جدول ثبت‌شده",
      desc: "«افزایش قانونی مزد ۱۴۰۵» (۴۵٪ + مبلغ ثابت ماهانه) از این نسخه به‌صورت پیش‌فرض خاموش است و کارت خالص پرداختی هر سطح، مستقیماً از بازه حقوق ثبت‌شده همان جدول محاسبه می‌شود: خالص = حقوق پایه + حق مسکن + بن کارگری − بیمه ۷٪ (پایه + مسکن + بن) − مالیات پلکانی ماده ۸۵. این اصلاح برای کارگاه‌هایی است که جدول طبقه‌بندی‌شان را از ابتدا با ارقام ۱۴۰۵ ثبت کرده‌اند — در نسخه‌های قبل، افزایش قانونی روی این ارقام دوباره اعمال می‌شد و مبنا و خالص کارت متورم نمایش داده می‌شد. اگر جدول شما با ارقام سال قبل (۱۴۰۴) ثبت شده است، همان تبدیل را می‌توانید از «تنظیمات ← اطلاعات پایه ← افزایش قانونی مزد ۱۴۰۵» دوباره فعال کنید (درصد و مبلغ ثابت قابل ویرایش‌اند). فیش حقوقی کارکنان تغییری نکرده و همچنان از حقوق ثبت‌شده پرونده هر نفر محاسبه می‌شود.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. خاموش‌کردن صریح افزایش قانونی در legal_params ----------
  // فقط کلید legalIncreaseEnabled → false؛ بقیهٔ پارامترها (درصد/ثابت/سایر) دست‌نخورده می‌مانند
  // تا در صورت فعال‌سازی مجدد، همان مقادیر بخشنامه (۴۵٪ + ۱۵,۵۸۶,۴۷۰) در دسترس باشند.
  // اگر سطر legal_params اصلاً وجود نداشته باشد، پیش‌فرض موتور (اکنون false) اعمال می‌شود — کاری نمی‌کنیم.
  const lp = await db.systemSetting.findUnique({ where: { key: "legal_params" } });
  if (lp) {
    let stored: Record<string, unknown> = {};
    let parseOk = true;
    try { stored = JSON.parse(lp.value); } catch { parseOk = false; }
    if (parseOk) {
      if (stored.legalIncreaseEnabled === false) {
        console.log("• افزایش قانونی همین حالا خاموش است — legal_params دست نخورد");
      } else {
        stored.legalIncreaseEnabled = false;
        await db.systemSetting.update({ where: { key: "legal_params" }, data: { value: JSON.stringify(stored) } });
        console.log("✓ «افزایش قانونی مزد ۱۴۰۵» در legal_params خاموش شد (بقیهٔ پارامترها حفظ شد)");
      }
    } else {
      console.log("⚠ legal_params قابل تجزیه نیست — دست نخورد (پیش‌فرض موتور: خاموش)");
    }
  } else {
    console.log("• سطر legal_params وجود ندارد — پیش‌فرض موتور (خاموش) اعمال می‌شود");
  }

  // ---------- ۲. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۳. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2915) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱۵» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.15") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2915) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱۵» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۴. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

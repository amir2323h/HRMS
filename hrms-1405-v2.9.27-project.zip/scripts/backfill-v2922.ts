// ============================================================
// Backfill v2.9.22 — رفع نمایش اطلاعات نفر قبلی در ویرایش پرونده
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۲
//  ۳) پاکسازی کش وضعیت آپدیت
// زمینه: فرم ویرایش کارمند فقط هنگام «بستن» دیالوگ مقداردهی
// می‌شد؛ در نتیجه اولین بازکردنِ ویرایشِ نفر جدید، اطلاعات نفر
// قبلی را نشان می‌داد و تنها پس از بستن/بازکردن، دادهٔ خود فرد
// لود می‌شد. اکنون فرم هر بار که دیالوگ باز شود (یا هدف عوض
// شود) بلافاصله از دادهٔ تازه همان کارمند مقداردهی می‌شود.
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2922.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2922 = {
  version: "2.9.22",
  title: "تازه‌های نسخه ۲.۹.۲۲",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIX",
      title: "رفع نمایش اطلاعات نفر قبلی در ویرایش پرونده کارمند",
      desc: "در «مدیریت کارکنان» هنگام باز کردن فرم ویرایشِ یک کارمند، در اولین بازکردن ممکن بود اطلاعات کارمندِ قبلاً باز/ویرایش‌شده نمایش داده شود و تنها پس از بستن و بازکردنِ مجدد، اطلاعات خودِ کارمند بارگذاری می‌شد. اکنون فرم هر بار که دیالوگ باز می‌شود (یا هدف ویرایش عوض می‌شود) بلافاصله از داده‌های تازه همان کارمند مقداردهی می‌شود — بدون نیاز به بستن و بازکردن.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2922) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۲» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.22") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2922) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۲» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

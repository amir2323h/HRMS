// ============================================================
// Backfill v2.9.20 — حکم حقوق فردی + یکسان‌سازی معکوس/پیش‌بینی + ریز محاسبات اکسل
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۰
//  ۳) پاکسازی کش وضعیت آپدیت
// زمینه: در «موتور محاسبه معکوس» حالت «کارمند مشخص» اضافه شد (کانتکس واقعی
// پرونده + ماه اجرا + دکمه «صدور حکم حقوق» با اعمال اختیاری روی پرونده)؛
// اعداد معکوس و پیش‌بینی بودجه دقیقاً یکی شد (هر دو از contextFromEmployee)؛
// شیت اکسل «ریز افراد» پیش‌بینی ریز محاسبات کامل گرفت (سنوات، فرزند، تاهل،
// بن، مسکن، جذب، بیمه ۷٪، مالیات پلکانی، هزینه کارفرما).
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2920.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2920 = {
  version: "2.9.20",
  title: "تازه‌های نسخه ۲.۹.۲۰",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "حکم حقوق فردی — از محاسبه معکوس با یک دکمه",
      desc: "در «موتور محاسبه معکوس» کارمند و «ماه اجرا» را انتخاب کنید؛ کانتکس واقعی پرونده او (فرزند، تاهل، سنوات از تاریخ استخدام، طبقه، حق جذب، شیفت) خودکار بارگذاری می‌شود، خالص هدف را وارد و محاسبه کنید و با دکمه «صدور حکم حقوق» حکم صادر می‌گردد. حقوق جدید می‌تواند هم‌زمان روی پرونده کارمند اعمال شود (ثبت در «سابقه تغییرات حقوق» و لاگ حسابرسی) و ریز کامل فیش ماه اول در جزئیات حکم نگه داشته می‌شود. ابطال حکم با امکان بازگردانی حقوق به مقدار قبل ممکن است.",
    },
    {
      tag: "FIX",
      title: "اعداد «محاسبه معکوس» و «پیش‌بینی بودجه» دقیقاً یکی شد",
      desc: "ریشه اختلاف قبلی، ورودی دستی فرزند/سنوات/تاهل/طبقه در موتور معکوس در برابر داده واقعی پرونده در پیش‌بینی بودجه بود. اکنون در حالت «کارمند مشخص» هر دو مسیر از یک کانتکس می‌سازند (سنوات همیشه از تاریخ استخدام تا پایان ماه اجرا محاسبه می‌شود) و خروجی‌ها معکوس دقیق یکدیگرند — برای هر ۱۱۹ کارمند فعلی با اختلاف صفر ریال راستی‌آزمایی شد. هر دو مسیر از یک موتور قانونی استفاده می‌کنند (بیمه ۷٪/۲۳٪، مالیات پلکانی ماده ۸۵ بودجه ۱۴۰۵، معافیت بن ماده ۹۱، جدول تجمیعی سنوات ۱۴۰۵).",
    },
    {
      tag: "NEW",
      title: "شیت اکسل «ریز افراد» با ریز محاسبات کامل",
      desc: "در خروجی اکسل پیش‌بینی بودجه، شیت «ریز افراد» حالا تمام جزئیات هر نفر را شامل است: فرزند، تاهل، سابقه (سال)، حقوق ماهانه، حقوق پایه (عدد اداره کار)، سایر مزایا (مابالفاوت)، حق سنوات، حق تاهل، حق مسکن، بن کارگری، حق اولاد، حق جذب، حق شیفت، جمع ناخالص، مشمول بیمه، کسور بیمه ۷٪، درآمد مشمول مالیات، کسور مالیات، خالص پرداختی، بیمه سهم کارفرما ۲۳٪، هزینه کل کارفرما، ماه‌های همکاری و جمع هزینه در بازه. در جدول «لیست ریز افراد» هم هر سطر با کلیک باز می‌شود و همین ریز را نشان می‌دهد.",
    },
    {
      tag: "FIX",
      title: "تفکیک احکام در بودجه و تخمین دقیق هزینه جذب",
      desc: "حکم‌های حقوق فردی (ناشی از معکوس) دیگر به‌عنوان هزینه یک‌باره در پیش‌بینی بودجه حساب نمی‌شوند — تغییر حقوق از طریق پرونده به‌روز شده کارمند لحاظ می‌شود (بدون دوباره‌شماری). تخمین «هزینه ماهانه سرِ نفر» در سناریوهای جذب هم دقیقاً از همان موتور پیش‌بینی محاسبه می‌شود (شامل حق جذب طبقه و کف بیمه حداقل دستمزد).",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2920) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۰» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.20") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2920) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۰» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

// ============================================================
// Backfill v2.9.26 — چاپ قراردادها: کاغذ A4/A5 واقعی + امضای طرفین در پایین هر صفحه
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۲۶
//  ۳) پاکسازی کش وضعیت آپدیت
// قابلیت‌های جدید:
//  • انتخاب سایز کاغذ چاپ (A4/A5) در فهرست قراردادها و پنجره «مشاهده
//    و چاپ» — سند دقیقاً با همان کاغذ ساخته می‌شود (@page واقعی؛
//    ابعاد برگه در پیش‌نمایش و چاپ یکسان است).
//  • صفحه‌بندی خودکار متن قراردادهای چندصفحه‌ای بین برگه‌ها؛ محل
//    امضای «طرف اول (کارفرما)» و «طرف دوم (کارمند)» در انتهای
//    «هر صفحه» درج می‌شود (فاصله خطوط بلوک امضا ۱.۱۵) و متن هرگز
//    زیر امضا نمی‌رود.
//  • شماره و تاریخ قرارداد مطابق نامه‌های رسمی به بالا-سمت-چپ
//    انتقال یافت و در همه صفحات تکرار می‌شود.
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2926.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2926 = {
  version: "2.9.26",
  title: "تازه‌های نسخه ۲.۹.۲۶",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "NEW",
      title: "چاپ قراردادها: کاغذ A4/A5 واقعی + امضای طرفین در پایین هر صفحه",
      desc: "در ماژول قراردادها، انتخاب سایز کاغذ چاپ (A4 یا A5) به فهرست قراردادها و پنجره «مشاهده و چاپ» اضافه شد و سند چاپی دقیقاً با همان کاغذ ساخته می‌شود (اندازه صفحه در چاپ و PDF همان سایز انتخابی است). متن قراردادهای چندصفحه‌ای به‌صورت خودکار بین برگه‌ها توزیع می‌شود و محل امضای «طرف اول (کارفرما)» و «طرف دوم (کارمند)» در انتهای «هر صفحه» درج می‌گردد (فاصله خطوط بلوک امضا ۱.۱۵) و متن هرگز زیر امضا نمی‌رود. شماره و تاریخ قرارداد نیز مطابق نامه‌های رسمی به بالای سمت چپ صفحه انتقال یافت و در همه صفحات تکرار می‌شود تا هر برگه به‌تنهایی قابل شناسایی باشد.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2926) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۲۶» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.26") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2926) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۲۶» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

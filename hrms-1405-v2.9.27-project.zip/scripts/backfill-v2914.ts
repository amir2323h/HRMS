// ============================================================
// Backfill v2.9.14 — همسان‌سازی مبنای بیمه فیش حقوقی با فرمول رسمی
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version») — fallback فوتر/پنل آپدیت
// ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱۴
// ۳) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2914.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// بدون تغییر داده یا مهاجرت اسکیما (محاسبه در موتور اصلاح شد).
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2914 = {
  version: "2.9.14",
  title: "تازه‌های نسخه ۲.۹.۱۴",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "FIXED",
      title: "مبنای بیمه فیش حقوقی — فرمول رسمی لیست بیمه (ماده ۳۰ قانون تأمین اجتماعی)",
      desc: "حق بیمه سهم کارگر اکنون ۷٪ × (حقوق پایه + حق مسکن + بن کارگری + مزایای ناشی از کار مانند اضافه‌کاری، شب‌کاری، جمعه‌کاری، تعطیل‌کاری، شیفت، مأموریت، حق مسولیت و شایستگی) محاسبه می‌شود — مطابق ماده ۳۰ قانون تأمین اجتماعی (اصلاحی ۱۳۹۴) که حق مسکن و بن کارگری را جزء «مزد و مزایای مربوط به کار» و مشمول بیمه می‌داند. پیش از این، بیمه فقط ۷٪ حقوق ماهانه بود. اقلام غیرمشمول (سنوات، حق اولاد، حق تاهل، حق جذب و سایر مزایا) طبق قانون بیمه‌ناپذیر باقی می‌مانند. با این تغییر، فیش حقوقی و کارت «خالص پرداختی (۱۴۰۵)» طبقه‌بندی مشاغل کاملاً همسو شدند — نمونه صحت (حداقل‌بگیر مجرد ۱۴۰۵): مبنای بیمه ۲۱۸,۲۵۵,۵۰۰؛ بیمه ۱۵,۲۷۷,۸۸۵؛ خالص ۲۰۲,۹۷۷,۶۱۵ ریال. توجه: فیش‌های دوره‌های محاسبه‌شده قبلی با مبنای قدیمی ذخیره شده‌اند — برای اعمال فرمول جدید، دوره را بازمحاسبه کنید (حقوق و دستمزد → دوره‌ها → بازمحاسبه).",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2914) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱۴» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.14") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2914) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱۴» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

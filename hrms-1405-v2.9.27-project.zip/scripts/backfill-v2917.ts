// ============================================================
// Backfill v2.9.17 — تفکیک حقوق ماهانه سطح: حقوق پایه ثابت + سایر مزایا
//  ۱) تبدیل دفاعی تفکیک درصدی قدیمی (در صورت وجود ستون‌های قدیمی و جدید
//     همزمان — یعنی اجرای backfill قبل از db push):
//     حقوق پایه ثابت = حداقل بازه سطح × درصد پایه (فقط سطوح دارای تفکیک)
//  ۲) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۳) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۱۷
//  ۴) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2917.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2917 = {
  version: "2.9.17",
  title: "تازه‌های نسخه ۲.۹.۱۷",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "UPDATED",
      title: "تفکیک حقوق ماهانه سطح — حقوق پایه عدد ثابت + سایر مزایا",
      desc: "در «طبقه‌بندی مشاغل»، مدل درصدی (پایه/مسولیت/شایستگی) جای خود را به مدل عدد ثابت داد: برای هر سطح یک «حقوق پایه ثابت» ماهانه (ریال) تعیین می‌کنید؛ هر چه از حقوق ماهانه هر کارمند مازاد بر آن باشد، خودکار در فیلد «سایر مزایا» می‌نشیند و مشمول بیمه و مالیات است. اضافه‌کاری، مأموریت، شب/جمعه/تعطیل‌کاری و غیبت فقط از حقوق پایه ثابت محاسبه می‌شوند. سطوح بدون عدد ثابت مثل قبل بدون تفکیک می‌مانند (کل حقوق ماهانه = حقوق پایه).",
    },
    {
      tag: "UPDATED",
      title: "محاسبات پیش‌بینی بودجه و معکوس هم‌خوان با مدل جدید",
      desc: "موتور محاسبه معکوس (خالص هدف ← حقوق ماهانه)، پیش‌بینی بودجه حقوق (کارکنان فعلی + سناریوهای جذب) و مدیریت تغییرات حقوق، اکنون حقوق پایه ثابت سطح را لحاظ می‌کنند. فیش حقوقی هم ردیف «سایر مزایا» را جدا از «حقوق پایه» نمایش می‌دهد؛ فیش‌های قدیمی دارای حق مسولیت/شایستگی دست‌نخورده باقی می‌مانند.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. تبدیل دفاعی تفکیک درصدی قدیمی ----------
  // فقط وقتی هر دو ستون قدیمی (respPercent/meritPercent/basePercent) و جدید
  // (fixedBaseSalary) همزمان وجود دارند (اجرای backfill قبل از db push).
  const cols = (await db.$queryRawUnsafe<{ name: string }[]>("PRAGMA table_info(job_grades)")) as { name: string }[];
  const names = cols.map((c) => c.name);
  const hasOld = names.includes("respPercent") && names.includes("basePercent");
  const hasNew = names.includes("fixedBaseSalary");
  if (hasOld && hasNew) {
    const changed = await db.$executeRawUnsafe(
      `UPDATE job_grades SET fixedBaseSalary = CAST(ROUND(minBaseSalary * basePercent / 100.0) AS INTEGER)
       WHERE (COALESCE(respPercent, 0) + COALESCE(meritPercent, 0)) > 0 AND COALESCE(fixedBaseSalary, 0) = 0`
    );
    console.log(`✓ تفکیک درصدی ${changed} سطح به حقوق پایه ثابت تبدیل شد (حداقل بازه × درصد پایه)`);
  } else {
    console.log("• ستون‌های قدیمی تفکیک حذف شده‌اند یا ستون جدید موجود نیست — تبدیل لازم نیست");
  }

  // ---------- ۲. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۳. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2917) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۱۷» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.17") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2917) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۹.۱۷» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۴. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

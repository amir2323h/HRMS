#!/usr/bin/env bash
# ================================================================
#   نصب‌کننده تمام‌خودکار — سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵
#   تک‌فایل (سورس داخل همین اسکریپت) — بدون نیاز به هیچ کار دستی
#   اجرا:  sudo bash install-hrms.sh [--port 3000] [--dir /opt/hrms] [--no-demo] [--domain hrms.example.com]
#   سازگار: Ubuntu 20.04+ / Debian 11+ / RHEL 9+ / Rocky / Alma (amd64 و arm64)
#   آپدیت: اجرای مجدد روی نصب موجود = به‌روزرسانی امن (داده‌ها و کلید نشست حفظ می‌شوند)
#   پس از نصب: تایپ کنید  hrms  (یا HRMS)  ←  منوی مدیریتی: آپدیت از گیت‌هاب / حذف اطلاعات
#   نمونه / نصب مجدد / حذف اسکریپت — فهرست نسخه‌ها خودکار از مخزن گیت‌هاب می‌آید
# ================================================================
set -euo pipefail

# ---------- نسخه بسته ----------
APP_VERSION="2.5.0"
APP_VERSION_FA="۲.۵.۰"

# ---------- رنگ‌ها ----------
if command -v tput >/dev/null 2>&1 && [ -t 1 ]; then
  B=$(tput bold); R=$(tput setaf 1); G=$(tput setaf 2); Y=$(tput setaf 3); C=$(tput setaf 6); N=$(tput sgr0)
else
  B=""; R=""; G=""; Y=""; C=""; N=""
fi
info()  { echo -e "${C}◈${N} $*"; }
ok()    { echo -e "${G}✓${N} $*"; }
warn()  { echo -e "${Y}⚠${N} $*"; }
fail()  { echo -e "${R}✗${N} $*" >&2; exit 1; }

# ---------- پارامترها ----------
PORT=3000
APP_DIR=/opt/hrms
DEMO=1
DOMAIN=""
while [ $# -gt 0 ]; do
  case "$1" in
    --port)     PORT="$2"; shift 2 ;;
    --dir)      APP_DIR="$2"; shift 2 ;;
    --no-demo)  DEMO=0; shift ;;
    --domain)   DOMAIN="$2"; shift 2 ;;
    -h|--help)
      sed -n '2,9p' "$0"; exit 0 ;;
    *) fail "آرگومان ناشناخته: $1 (برای راهنما: --help)" ;;
  esac
done
# اعتبارسنجی دامنه — فقط حروف/عدد/نقطه/خط تیره
if [ -n "$DOMAIN" ]; then
  echo "$DOMAIN" | grep -Eq '^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$' \
    || fail "دامنه نامعتبر است: $DOMAIN (نمونه صحیح: hrms.example.com)"
fi

echo -e "${B}${C}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   نصب خودکار سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵   ║"
echo "║        HRMS 1405 — نسخه ${APP_VERSION} — نصب یک‌مرحله‌ای        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${N}"
info "نسخه: ${B}${APP_VERSION}${N} | پوشه نصب: ${B}${APP_DIR}${N} | پورت: ${B}${PORT}${N} | کاربران نمونه: $([ $DEMO -eq 1 ] && echo 'بله' || echo 'خیر') (داده پرسنلی: هیچ)${DOMAIN:+ | دامنه: ${B}${DOMAIN}${N}}"

# ================================================================
# ۱) بررسی ریشه و سیستم‌عامل
# ================================================================
[ "$(id -u)" -eq 0 ] || fail "این اسکریپت باید با ریشه اجرا شود: sudo bash $0"
OS_ID=$(. /etc/os-release 2>/dev/null && echo "${ID:-}" || echo "")
OS_VER=$(. /etc/os-release 2>/dev/null && echo "${VERSION_ID:-}" || echo "")
info "سیستم‌عامل تشخیص داده شد: ${OS_ID:-نامشخص} ${OS_VER}"

PKG=""
if command -v apt-get >/dev/null 2>&1; then PKG="apt"
elif command -v dnf >/dev/null 2>&1; then PKG="dnf"
else fail "پکیج‌منیجر پشتیبانی‌نشده — فقط apt/dnf (Ubuntu/Debian/RHEL) پشتیبانی می‌شود."
fi

# ================================================================
# ۲) نصب پیش‌نیازهای سیستمی (خودکار)
# ================================================================
info "نصب پیش‌نیازهای سیستمی (curl, sqlite3, openssl, tar)…"
export DEBIAN_FRONTEND=noninteractive
if [ "$PKG" = "apt" ]; then
  apt-get update -qq || warn "apt update با هشدار ادامه یافت"
  apt-get install -y -qq curl ca-certificates sqlite3 openssl tar gzip >/dev/null 2>&1 || \
    apt-get install -y curl ca-certificates sqlite3 openssl tar gzip
elif [ "$PKG" = "dnf" ]; then
  dnf install -y -q curl ca-certificates sqlite openssl tar gzip || \
    dnf install -y curl sqlite openssl tar gzip
fi
ok "پیش‌نیازهای سیستمی نصب شدند"

# ================================================================
# ۳) نصب Node.js ≥ 20 (خودکار)
# ================================================================
NODE_MAJOR=0
if command -v node >/dev/null 2>&1; then
  NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)
fi
if [ "$NODE_MAJOR" -lt 20 ]; then
  info "Node.js ≥ ۲۰ یافت نشد (نسخه فعلی: ${NODE_MAJOR:-ندارد}) — نصب Node 22 از مخزن رسمی…"
  if [ "$PKG" = "apt" ]; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null 2>&1 || true
    apt-get install -y -qq nodejs >/dev/null 2>&1 || apt-get install -y nodejs
  else
    curl -fsSL https://rpm.nodesource.com/setup_22.x | bash - >/dev/null 2>&1 || true
    dnf install -y -q nodejs || dnf module install -y nodejs:22 || fail "نصب Node.js ناموفق بود"
  fi
  NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)
fi
[ "$NODE_MAJOR" -ge 20 ] || fail "Node.js ≥ ۲۰ در دسترس نیست — لطفاً دستی نصب کنید و دوباره اجرا کنید"
ok "Node.js $(node --version) آماده است"

# ================================================================
# ۴) حافظه کم؟ swap خودکار (ساخت Next.js به ≥۱GB نیاز دارد)
# ================================================================
MEM_MB=$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 2048)
SWAP_MB=$(awk '/SwapTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 0)
if [ "$MEM_MB" -lt 900 ] && [ "$SWAP_MB" -lt 500 ]; then
  info "حافظه کم (${MEM_MB}MB) — ساخت ۲GB swap برای موفقیت بیلد…"
  if ! swapon --show 2>/dev/null | grep -q . && [ ! -f /swapfile ]; then
    fallocate -l 2G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
    chmod 600 /swapfile && mkswap -q /swapfile && swapon /swapfile
    grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
    ok "swap فعال شد"
  else
    warn "swap از قبل موجود است — ادامه"
  fi
fi

# ================================================================
# ۵) استخراج سورس از داخل همین فایل (خودکار — بدون اکسترکت دستی)
# ================================================================
info "استخراج سورس سامانه در ${APP_DIR}…"
mkdir -p "$APP_DIR"

# ---------- تشخیص حالت به‌روزرسانی: نصب موجود با کاربر واقعی؟ ----------
# دیتابیس جزو بسته نیست → نصب مجدد سورس آن را حذف نمی‌کند؛
# اگر کاربر وجود دارد، این اجرا «به‌روزرسانی» است: داده/کلید نشست حفظ و seed اجرا نمی‌شود.
UPDATE_MODE=0
DB_FILE="${APP_DIR}/db/custom.db"
if [ -s "$DB_FILE" ]; then
  USERS_N=$(sqlite3 "$DB_FILE" "SELECT COUNT(*) FROM users;" 2>/dev/null || echo 0)
  if [ "${USERS_N:-0}" -gt 0 ] 2>/dev/null; then
    UPDATE_MODE=1
    info "نصب موجود تشخیص داده شد (${USERS_N} کاربر) — به‌روزرسانی امن: داده‌ها حفظ می‌شوند"
  fi
fi

MARKER='__PAYLOAD_B64__'
if ! grep -q "^${MARKER}$" "$0"; then
  fail "بسته سورس داخل اسکریپت یافت نشد — فایل نصب‌کننده را دوباره دانلود کنید"
fi
awk "f{print} /^${MARKER}$/{f=1}" "$0" | base64 -d | tar -xzf - -C "$APP_DIR"
[ -f "$APP_DIR/package.json" ] || fail "استخراج سورس ناموفق بود"
ok "سورس استخراج شد"

# ================================================================
# ۶) پیکربندی محیط (کلید امنیتی تصادفی + مسیر دیتابیس)
#    در حالت به‌روزرسانی: کلید نشست قبلی حفظ می‌شود (نشست‌های باز معتبر می‌مانند)
# ================================================================
info "تولید پیکربندی امن…"
OLD_SECRET=""
if [ "$UPDATE_MODE" -eq 1 ] && [ -f "$APP_DIR/.env" ]; then
  OLD_SECRET=$(grep -E '^AUTH_SECRET=' "$APP_DIR/.env" | head -1 | cut -d= -f2- || true)
  [ -n "$OLD_SECRET" ] && ok "کلید نشست موجود حفظ شد"
fi
AUTH_SECRET="${OLD_SECRET:-$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')}"
mkdir -p "$APP_DIR/db"
cat > "$APP_DIR/.env" <<ENVEOF
DATABASE_URL=file:${APP_DIR}/db/custom.db
AUTH_SECRET=${AUTH_SECRET}
NODE_ENV=production
PORT=${PORT}
HOSTNAME=0.0.0.0
ENVEOF
chmod 600 "$APP_DIR/.env"
ok ".env تولید شد (کلید نشست ۶۴ نویسه تصادفی)"

# ================================================================
# ۷) نصب بسته‌های npm + آماده‌سازی دیتابیس
# ================================================================
cd "$APP_DIR"
info "نصب بسته‌ها از npm (چند دقیقه صبر کنید)…"
npm install --no-audit --no-fund --loglevel=error >/dev/null 2>&1 || npm install --no-audit --no-fund
ok "بسته‌ها نصب شدند"

info "آماده‌سازی دیتابیس SQLite (پرایسما)…"
# متغیر محیطی صریح — اولویت بر .env (در برابر DATABASE_URL والد/غیرمنتظره مقاوم است)
DB_URL="file:${APP_DIR}/db/custom.db"
DATABASE_URL="$DB_URL" npx --yes prisma generate >/dev/null 2>&1 || DATABASE_URL="$DB_URL" npx prisma generate
DATABASE_URL="$DB_URL" npx --yes prisma db push --accept-data-loss >/dev/null 2>&1 || DATABASE_URL="$DB_URL" npx prisma db push --accept-data-loss
[ -s "$APP_DIR/db/custom.db" ] || fail "ساخت دیتابیس ناموفق بود"
ok "دیتابیس ساخته شد: ${APP_DIR}/db/custom.db"

# ================================================================
# ۸) داده اولیه — اجرات TS با bun یا tsx (خودکار)
# ================================================================
RUNTS=""
if command -v bun >/dev/null 2>&1; then
  RUNTS="bun"
elif npm install -g bun >/dev/null 2>&1 && command -v bun >/dev/null 2>&1; then
  RUNTS="bun"
fi
if [ -z "$RUNTS" ]; then
  info "bun در دسترس نیست — استفاده از tsx…"
  RUNTS="npx --yes tsx"
fi

if [ "$UPDATE_MODE" -eq 1 ]; then
  info "به‌روزرسانی: داده‌های موجود و کاربران حفظ می‌شوند (seed اجرا نمی‌شود)…"
  # ارتقای داده‌ها: قالب‌نامه‌های خودکار + مجوزهای حضور و غیب (idempotent)
  if [ -f scripts/backfill-v8.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v8.ts >/dev/null 2>&1 || true
    ok "قالب‌نامه‌های خودکار و مجوزهای حضور و غیب اضافه شد"
  fi
  # مجوزهای «مدیریت تغییرات حقوق» (پیش‌نویس/گروهی/معکوس/آرشیو) — v2.2.0
  if [ -f scripts/backfill-v9.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v9.ts >/dev/null 2>&1 || true
    ok "مجوزهای مدیریت تغییرات حقوق به نقش‌ها اضافه شد"
  fi
  # پاداش اور تارگت +۲ پایه (سیاست جدید — فقط اگر مقدار پیش‌فرض قدیمی ۱ باشد) — v2.3.0
  if [ -f scripts/backfill-v10.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v10.ts >/dev/null 2>&1 || true
    ok "قاعده پاداش اور تارگت (+۲ پایه — قابل ویرایش) به‌روزرسانی شد"
  fi
  ok "داده‌های فعلی بدون تغییر ماند"
elif [ "$DEMO" -eq 1 ]; then
  info "بارگذاری داده پایه (پارامترهای قانونی، ساختار سازمانی، طبقه‌بندی مشاغل، کاربران نمونه) — بدون هیچ داده پرسنلی…"
  DATABASE_URL="$DB_URL" $RUNTS prisma/seed.ts >/dev/null 2>&1 || DATABASE_URL="$DB_URL" $RUNTS prisma/seed.ts
  # نقش‌های سیستمی + رفاهیات + قالب نامه‌ها + مدیر واحدها
  if [ -f scripts/backfill-v4.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v4.ts >/dev/null 2>&1 || true
  fi
  # کارشناس اداری + تنظیمات شماره‌گذاری نامه‌ها (ZDX_AD_0507019)
  if [ -f scripts/backfill-v5.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v5.ts >/dev/null 2>&1 || true
  fi
  # مجوزهای مدیریت تغییرات حقوق (idempotent)
  if [ -f scripts/backfill-v9.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v9.ts >/dev/null 2>&1 || true
  fi
  # پاداش اور تارگت +۲ پایه — پیش‌فرض seed جدید خودکار است؛ backfill برای اطمینان (idempotent)
  if [ -f scripts/backfill-v10.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v10.ts >/dev/null 2>&1 || true
  fi
  ok "داده پایه بارگذاری شد — بدون هیچ داده پرسنلی (کارکنان را از ماژول «کارکنان» یا ایمپورت اکسل وارد کنید)"
else
  info "نصب تمیز (بدون کاربران نمونه) — ساخت مدیر اولیه…"
  cat > "$APP_DIR/bootstrap.mjs" <<'BOOTEOF'
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
const db = new PrismaClient();
const salt = randomBytes(16).toString("hex");
const hash = scryptSync("admin123", salt, 64).toString("hex");
const role = await db.role.upsert({
  where: { key: "SUPER_ADMIN" },
  update: {},
  create: { key: "SUPER_ADMIN", name: "مدیر کل سیستم", description: "دسترسی کامل", permissions: "[\"*\"]" },
});
await db.user.upsert({
  where: { username: "admin" },
  update: { roleId: role.id },
  create: { username: "admin", passwordHash: `${salt}:${hash}`, fullName: "مدیر کل سیستم", role: "SUPER_ADMIN", roleId: role.id, isActive: true },
});
await db.systemSetting.upsert({
  where: { key: "display" },
  update: {},
  create: { key: "display", value: "{\"unit\":\"TOMAN\"}" },
});
await db.$disconnect();
console.log("bootstrap-ok");
BOOTEOF
  DATABASE_URL="$DB_URL" node "$APP_DIR/bootstrap.mjs" >/dev/null 2>&1 || DATABASE_URL="$DB_URL" node "$APP_DIR/bootstrap.mjs"
  rm -f "$APP_DIR/bootstrap.mjs"
  ok "کاربر مدیر ساخته شد: admin / admin123"
fi

# قالب‌نامه‌های خودکار (گواهی اشتغال/معرفی به بانک/معرفی‌نامه) — در همه حالت‌های نصب
if [ -f scripts/backfill-v8.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v8.ts >/dev/null 2>&1 || true
  ok "قالب‌نامه‌های آماده (LT-010…LT-012) در دسترس است"
fi

# ================================================================
# ۹) بیلد نسخه تولیدی (standalone)
# ================================================================
info "بیلد نسخه تولیدی Next.js (طولانی‌ترین مرحله)…"
export DATABASE_URL="${DB_URL}"
export AUTH_SECRET="$AUTH_SECRET"
export NEXT_TELEMETRY_DISABLED=1
npm run build >/dev/null 2>&1 || npm run build
[ -f "$APP_DIR/.next/standalone/server.js" ] || fail "بیلد ناموفق بود — لاگ: cd $APP_DIR && npm run build"
ok "بیلد standalone آماده شد"

# ================================================================
# ۱۰) سرویس systemd (اجرای دائمی + راه‌اندازی خودکار پس از ریبوت)
# ================================================================
SERVICE=hrms
# آیا systemd واقعاً در حال اجراست؟ (نه فقط نصب — مثلاً WSL بدون systemd)
SYSTEMD_RUNNING=0
if command -v systemctl >/dev/null 2>&1; then
  if [ -d /run/systemd/system ] || systemctl is-system-running >/dev/null 2>&1; then
    SYSTEMD_RUNNING=1
  fi
fi
if [ "$SYSTEMD_RUNNING" -eq 1 ]; then
  info "نصب سرویس systemd…"
  cat > /etc/systemd/system/${SERVICE}.service <<UNITEOF
[Unit]
Description=HRMS 1405 — سامانه جامع منابع انسانی و حقوق و دستمزد
After=network.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
Environment=NODE_ENV=production
Environment=PORT=${PORT}
Environment=HOSTNAME=0.0.0.0
Environment=DATABASE_URL=${DB_URL}
Environment=AUTH_SECRET=${AUTH_SECRET}
ExecStart=$(command -v node) ${APP_DIR}/.next/standalone/server.js
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNITEOF
  systemctl daemon-reload
  systemctl enable ${SERVICE} >/dev/null 2>&1 || true
  systemctl restart ${SERVICE}
  ok "سرویس ${SERVICE} فعال شد (راه‌اندازی خودکار پس از ریبوت)"
else
  warn "systemd فعال نیست — اجرای مستقیم با nohup…"
  ( cd "$APP_DIR" && DATABASE_URL="${DB_URL}" AUTH_SECRET="$AUTH_SECRET" PORT="$PORT" HOSTNAME=0.0.0.0 nohup node .next/standalone/server.js > server.log 2>&1 & )
fi

# فایروال: باز کردن پورت (اگر ufw فعال است) — با دامنه، ۸۰/۴۴۳ برای HTTPS هم باز می‌شود
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PORT}/tcp" >/dev/null 2>&1 || true
  if [ -n "$DOMAIN" ]; then
    ufw allow 80/tcp >/dev/null 2>&1 || true
    ufw allow 443/tcp >/dev/null 2>&1 || true
    ok "پورت‌های ${PORT} و 80/443 (HTTPS) در فایروال (ufw) باز شدند"
  else
    ok "پورت ${PORT} در فایروال (ufw) باز شد"
  fi
fi

# ================================================================
# ۱۱) بررسی سلامت — انتظار برای پاسخ HTTP
# ================================================================
info "بررسی سلامت سامانه (حداکثر ۶۰ ثانیه)…"
HEALTHY=0
for i in $(seq 1 30); do
  if curl -fs -o /dev/null --max-time 3 "http://127.0.0.1:${PORT}/api/branding" 2>/dev/null; then
    HEALTHY=1; break
  fi
  sleep 2
done
[ "$HEALTHY" -eq 1 ] || fail "سامانه پاسخ نداد — لاگ: journalctl -u ${SERVICE} -n 50"

# ================================================================
# ۱۱.۵) دامنه + HTTPS خودکار (Caddy) — فقط با پرچم --domain
#   پیش‌نیازها: رکورد A دامنه ← آی‌پی عمومی سرور + باز بودن 80/443 از اینترنت
#   گواهی Let's Encrypt به‌طور خودکار صادر و تمدید می‌شود
# ================================================================
if [ -n "$DOMAIN" ]; then
  info "پیکربندی دامنه ${DOMAIN} با Caddy (HTTPS خودکار)…"
  if ! command -v caddy >/dev/null 2>&1; then
    if [ "$PKG" = "apt" ]; then
      apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https >/dev/null 2>&1 || true
      curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null || true
      curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.sh' | bash >/dev/null 2>&1 || true
      apt-get install -y -qq caddy >/dev/null 2>&1 || apt-get install -y caddy
    else
      dnf install -y -q 'dnf-command(copr)' >/dev/null 2>&1 || true
      dnf copr enable -y @caddy/caddy >/dev/null 2>&1 || true
      dnf install -y -q caddy || dnf install -y caddy
    fi
  fi
  if command -v caddy >/dev/null 2>&1; then
    mkdir -p /etc/caddy
    cat > /etc/caddy/Caddyfile <<CADDYEOF
# HRMS 1405 — reverse proxy to local service
${DOMAIN} {
    encode zstd gzip
    reverse_proxy 127.0.0.1:${PORT}
}
CADDYEOF
    systemctl enable caddy >/dev/null 2>&1 || true
    systemctl restart caddy >/dev/null 2>&1 || systemctl restart caddy || true
    ok "Caddy فعال شد — سامانه روی ${C}https://${DOMAIN}${N} با گواهی خودکار در دسترس است"
    warn "اگر دامنه هنوز به این سرور اشاره نکرده باشد، صدور گواهی کمی بعد (پس از تنظیم DNS) خودکار انجام می‌شود — لاگ: journalctl -u caddy -f"
  else
    warn "نصب Caddy ناموفق بود — پیکربندی دستی: هر وب‌سروری که به 127.0.0.1:${PORT} پروکسی کند + گواهی SSL"
  fi
fi

# ================================================================
# ۱۱.۶) ذخیره نسخه‌ای از نصب‌کننده (برای «نصب مجدد» آفلاین از فرمان hrms)
# ================================================================
info "ذخیره نسخه‌ای از نصب‌کننده برای نصب مجدد آفلاین…"
if [ -f "$0" ] && grep -q '^__PAYLOAD_B64__$' "$0" 2>/dev/null; then
  mkdir -p "${APP_DIR}/installer"
  cp -f "$0" "${APP_DIR}/installer/install-hrms-v${APP_VERSION}.sh"
  chmod 700 "${APP_DIR}/installer/install-hrms-v${APP_VERSION}.sh"
  ok "ذخیره شد: ${APP_DIR}/installer/install-hrms-v${APP_VERSION}.sh (hrms ← نصب مجدد ← منبع محلی)"
else
  warn "فایل نصب‌کننده اصلی در دسترس نیست — نصب مجدد آفلاین در دسترس نخواهد بود (از گیت‌هاب امکان‌پذیر است)"
fi

# ================================================================
# ۱۱.۷) فرمان مدیریتی hrms — منوی آپدیت/حذف داده نمونه/نصب مجدد/حذف اسکریپت
#   پس از نصب، کاربر در خط فرمان تایپ می‌کند:  hrms  (یا  HRMS)
#   میان‌برها: hrms update | purge | reinstall | remove | status | versions | help
#   فهرست نسخه‌ها از مخزن گیت‌هاب (زیپ‌های hrms-1405-v*-project.zip در ریشه ریپو)
#   نوشتن اتمیک (فایل موقت + mv) تا جایگزینی حین اجرای خودِ فرمان امن باشد
# ================================================================
info "نصب فرمان مدیریتی hrms…"
CLI_TMP="/usr/local/bin/.hrms-cli.tmp.$$"
cat > "$CLI_TMP" <<'HRMS_CLI_EOF'
#!/usr/bin/env bash
# ================================================================
#  hrms — فرمان مدیریتی سامانه جامع منابع انسانی ۱۴۰۵
#  ساخته‌شده توسط install-hrms.sh — با هر نصب/به‌روزرسانی بازنویسی می‌شود
#  استفاده:  hrms           → منوی تعاملی (آپدیت/حذف داده نمونه/نصب مجدد/حذف)
#            hrms update     → به‌روزرسانی — فهرست نسخه‌های گیت‌هاب + انتخاب
#            hrms purge      → حذف اطلاعات نمونه (تراکنشی یا کامل)
#            hrms reinstall  → نصب مجدد (تعمیر با حفظ داده یا نصب تمیز)
#            hrms remove     → حذف اسکریپت / حذف کامل سامانه
#            hrms status     → وضعیت سرویس/سلامت/آخرین نسخه گیت‌هاب
#            hrms versions   → فقط فهرست نسخه‌های موجود در گیت‌هاب
# ================================================================
APP_DIR="__APP_DIR__"
PORT="__PORT__"
SERVICE="hrms"
INSTALLED_VERSION="__APP_VERSION__"
GITHUB_REPO="amir2323h/HRMS"
GITHUB_BRANCH="main"
HRMS_ARGS=("$@")

# ---------- رنگ‌ها و پیام‌ها ----------
if command -v tput >/dev/null 2>&1 && [ -t 1 ]; then
  B=$(tput bold); R=$(tput setaf 1); G=$(tput setaf 2); Y=$(tput setaf 3); C=$(tput setaf 6); N=$(tput sgr0)
else
  B=""; R=""; G=""; Y=""; C=""; N=""
fi
info()  { echo -e "${C}◈${N} $*"; }
ok()    { echo -e "${G}✓${N} $*"; }
warn()  { echo -e "${Y}⚠${N} $*"; }
fail()  { echo -e "${R}✗${N} $*" >&2; }
trap 'echo ""; info "خروج"; exit 130' INT TERM

confirm() {
  local ans
  while true; do
    read -r -p "$1 [بله/خیر]: " ans || exit 130
    case "$ans" in
      بله|y|Y|yes|YES) return 0 ;;
      خیر|n|N|no|NO)  return 1 ;;
      *) echo "لطفاً «بله» یا «خیر» وارد کنید" ;;
    esac
  done
}

ensure_root() {
  if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
      info "این عملیات نیاز به دسترسی ریشه دارد — اجرای مجدد با sudo…"
      exec sudo bash "$0" "${HRMS_ARGS[@]}"
    fi
    fail "این عملیات باید با ریشه اجرا شود: sudo hrms $1"
    exit 1
  fi
}

systemd_ok() {
  command -v systemctl >/dev/null 2>&1 && { [ -d /run/systemd/system ] || systemctl is-system-running >/dev/null 2>&1; }
}

svc_restart() {
  if systemd_ok; then
    systemctl restart "$SERVICE" >/dev/null 2>&1 && ok "سرویس ${SERVICE} ری‌استارت شد" || warn "ری‌استارت سرویس ناموفق بود"
  else
    warn "systemd فعال نیست — اگر سرویس با nohup اجرا شده، دستی ری‌استارت کنید"
  fi
}

fa_ver() { echo "$1" | sed 's/0/۰/g;s/1/۱/g;s/2/۲/g;s/3/۳/g;s/4/۴/g;s/5/۵/g;s/6/۶/g;s/7/۷/g;s/8/۸/g;s/9/۹/g'; }

db_file() { echo "${APP_DIR}/db/custom.db"; }

# اگر پورت در .env نصب تغییر کرده باشد، همان به‌کار رود
if [ -f "${APP_DIR}/.env" ]; then
  _P="$(grep -E '^PORT=' "${APP_DIR}/.env" 2>/dev/null | head -n 1 | cut -d= -f2-)"
  [ -n "$_P" ] && PORT="$_P"
  unset _P
fi

# ---------- فهرست نسخه‌ها از گیت‌هاب ----------
# سه روش پشت‌سرهم (اولین موفق برنده): صفحه ریپو (بدون محدودیت نرخ) ←
# API محتویات ← فید ریلیزها (برای انتشارهای رسمی آینده)
fetch_versions() {
  local tmp page
  tmp="$(mktemp)"
  page="$(curl -fsSL --max-time 25 "https://github.com/${GITHUB_REPO}" 2>/dev/null || true)"
  if [ -n "$page" ]; then
    printf '%s\n' "$page" | grep -oE 'hrms-1405-v[0-9]+(\.[0-9]+)*-project\.zip' \
      | sort -uV | sed -E 's/^hrms-1405-v([0-9.]+)-project\.zip$/\1/' > "$tmp"
  fi
  if [ ! -s "$tmp" ]; then
    curl -fsSL --max-time 20 "https://api.github.com/repos/${GITHUB_REPO}/contents" 2>/dev/null \
      | grep -oE '"name":[[:space:]]*"hrms-1405-v[0-9]+(\.[0-9]+)*-project\.zip"' \
      | sed -E 's/.*hrms-1405-v([0-9.]+)-project\.zip.*/\1/' | sort -uV > "$tmp" || true
  fi
  if [ ! -s "$tmp" ]; then
    curl -fsSL --max-time 20 "https://github.com/${GITHUB_REPO}/releases.atom" 2>/dev/null \
      | grep -oE '<title>v?[0-9]+(\.[0-9]+)*</title>' \
      | sed -E 's/<title>v?([0-9.]+)<\/title>/\1/' | sort -uV > "$tmp" || true
  fi
  cat "$tmp"
  rm -f "$tmp"
}

pick_version() {
  local vers sel i v arr
  info "دریافت فهرست نسخه‌ها از گیت‌هاب (${GITHUB_REPO})…"
  vers="$(fetch_versions)"
  if [ -z "$(printf '%s' "$vers" | tr -d '[:space:]')" ]; then
    warn "دریافت فهرست از گیت‌هاب ناموفق بود (شبکه/آفلاین؟)"
    read -r -p "شماره نسخه را دستی وارد کنید (مثلاً 2.5.0 — خالی = انصراف): " sel || return 0
    [ -n "$sel" ] && printf '%s\n' "$sel"
    return 0
  fi
  arr=()
  while IFS= read -r v; do [ -n "$v" ] && arr=("$v" "${arr[@]}"); done <<<"$vers"
  echo ""
  echo -e "${B}نسخه‌های موجود در گیت‌هاب (جدیدترین در بالا):${N}"
  for i in "${!arr[@]}"; do
    v="${arr[$i]}"
    if [ "$i" -eq 0 ] && [ "$v" = "$INSTALLED_VERSION" ]; then
      echo "  $((i+1))) ${B}${v}${N}  ${G}(جدیدترین)${N} ${C}← نسخه نصب‌شده فعلی${N}"
    elif [ "$i" -eq 0 ]; then
      echo "  $((i+1))) ${B}${v}${N}  ${G}(جدیدترین)${N}"
    elif [ "$v" = "$INSTALLED_VERSION" ]; then
      echo "  $((i+1))) ${B}${v}${N}  ${C}← نسخه نصب‌شده فعلی${N}"
    else
      echo "  $((i+1))) ${B}${v}${N}"
    fi
  done
  read -r -p "شماره گزینه یا شماره نسخه را وارد کنید (l = جدیدترین، خالی = انصراف): " sel || return 0
  [ -z "$sel" ] && return 0
  if [ "$sel" = "l" ] || [ "$sel" = "L" ]; then
    printf '%s\n' "${arr[0]}"
  elif [[ "$sel" =~ ^[0-9]+$ ]] && [ "$sel" -ge 1 ] && [ "$sel" -le "${#arr[@]}" ]; then
    printf '%s\n' "${arr[$((sel-1))]}"
  elif [[ "$sel" =~ ^[0-9]+(\.[0-9]+)*$ ]]; then
    printf '%s\n' "$sel"
  else
    warn "ورودی نامعتبر بود"
  fi
  return 0
}

cleanup_upd() {  # حذف امن پوشه موقت آپدیت (فقط مسیرهای mktemp خودمان)
  case "$1" in /tmp/hrms-upd-*) rm -rf "$1" ;; esac
}

build_installer() {  # $1=نسخه → چاپ مسیر نصب‌کننده ساخته‌شده (خطا = خروج 1)
  local ver="$1" tmpd zip url out probe
  tmpd="$(mktemp -d /tmp/hrms-upd-XXXXXX)"
  zip="${tmpd}/hrms.zip"
  out="${tmpd}/install-hrms-v${ver}.sh"
  url="https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/hrms-1405-v${ver}-project.zip"
  info "دانلود بسته نسخه ${ver} از گیت‌هاب…"
  if ! curl -fSL --max-time 300 -o "$zip" "$url" 2>/dev/null; then
    url="https://github.com/${GITHUB_REPO}/raw/${GITHUB_BRANCH}/hrms-1405-v${ver}-project.zip"
    curl -fSL --max-time 300 -o "$zip" "$url" || { rm -rf "$tmpd"; fail "دانلود نسخه ${ver} از گیت‌هاب ناموفق بود"; return 1; }
  fi
  [ -s "$zip" ] || { rm -rf "$tmpd"; fail "فایل دانلودشده خالی است"; return 1; }
  info "استخراج بسته…"
  mkdir -p "${tmpd}/x"
  if command -v unzip >/dev/null 2>&1; then
    unzip -q "$zip" -d "${tmpd}/x"
  elif command -v python3 >/dev/null 2>&1; then
    python3 -m zipfile -e "$zip" "${tmpd}/x"
  else
    apt-get install -y -qq unzip >/dev/null 2>&1 && unzip -q "$zip" -d "${tmpd}/x" \
      || { rm -rf "$tmpd"; fail "ابزار استخراج زیپ در دسترس نیست (unzip/python3)"; return 1; }
  fi
  [ -f "${tmpd}/x/scripts/installer-template.sh" ] \
    || { rm -rf "$tmpd"; fail "قالب نصب‌کننده در بسته نسخه ${ver} یافت نشد"; return 1; }
  info "ساخت نصب‌کننده تک‌فایل…"
  (
    cd "${tmpd}/x" || exit 1
    items=(./src ./public ./prisma)
    for f in scripts/backfill-*.ts scripts/purge-demo.ts; do [ -f "$f" ] && items+=("./$f"); done
    for f in package.json bun.lock next.config.ts tsconfig.json tailwind.config.ts postcss.config.mjs components.json next-env.d.ts; do
      [ -f "$f" ] && items+=("./$f")
    done
    {
      sed "s|^APP_VERSION=\".*\"|APP_VERSION=\"${ver}\"|; s|^APP_VERSION_FA=\".*\"|APP_VERSION_FA=\"$(fa_ver "${ver}")\"|" scripts/installer-template.sh
      echo ""
      echo "# ================== پی‌لود بسته (سورس، base64) =================="
      echo "# این بخش توسط اسکریپت استخراج می‌شود — دستکاری نکنید"
      echo "__PAYLOAD_B64__"
      tar -czf "${tmpd}/p.tgz" "${items[@]}" && base64 -w 76 "${tmpd}/p.tgz" && rm -f "${tmpd}/p.tgz"
    } > "${out}"
  )
  rm -f "${tmpd}/hrms.zip"
  chmod +x "${out}"
  # راستی‌آزمایی: مارکر + سینتکس + استخراج پی‌لود
  grep -q '^__PAYLOAD_B64__$' "${out}" || { rm -rf "$tmpd"; fail "ساخت نصب‌کننده ناموفق بود (مارکر پی‌لود)"; return 1; }
  bash -n "${out}" || { rm -rf "$tmpd"; fail "نصب‌کننده ساخته‌شده خطای سینتکس دارد"; return 1; }
  probe="$(mktemp -d)"
  awk 'f{print} /^__PAYLOAD_B64__$/{f=1}' "${out}" | base64 -d | tar -xzf - -C "$probe" 2>/dev/null
  if [ ! -f "${probe}/package.json" ] || [ ! -f "${probe}/prisma/schema.prisma" ]; then
    rm -rf "$probe" "$tmpd"; fail "راستی‌آزمایی پی‌لود نصب‌کننده ناموفق بود"; return 1
  fi
  rm -rf "$probe"
  printf '%s\n' "${out}"
}

do_update() {
  ensure_root update
  echo ""
  echo -e "${B}${C}────────────── به‌روزرسانی از گیت‌هاب ──────────────${N}"
  local ver inst rc latest_inst
  ver="$(pick_version)"
  [ -z "$ver" ] && { info "انصراف از به‌روزرسانی"; return 0; }
  latest_inst="$(printf '%s\n' "$ver" "$INSTALLED_VERSION" | sort -V | tail -n 1)"
  if [ "$ver" != "$INSTALLED_VERSION" ] && [ "$latest_inst" = "$INSTALLED_VERSION" ]; then
    warn "نسخه ${ver} قدیمی‌تر از نسخه نصب‌شده (${INSTALLED_VERSION}) است — ممکن است دیتابیس ناسازگار شود"
    confirm "به‌هرحال ادامه می‌دهید؟" || return 0
  elif [ "$ver" = "$INSTALLED_VERSION" ]; then
    info "نسخه انتخابی همان نسخه نصب‌شده است — نصب تعمیری انجام می‌شود (داده‌ها حفظ می‌شوند)"
  fi
  if [ -f "$(db_file)" ]; then
    confirm "پیش از شروع، از دیتابیس پشتیبان گرفته شود؟ (پیشنهاد: بله)" && {
      local bk="${HOME}/hrms-backup-$(date +%F-%H%M).db"
      cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
    }
  fi
  inst="$(build_installer "$ver")" || return 1
  echo ""
  warn "عملیات چند دقیقه طول می‌کشد (نصب بسته‌ها + بیلد) — سرویس در پایان خودکار ری‌استارت می‌شود"
  confirm "به‌روزرسانی به نسخه ${ver} شروع شود؟" || { cleanup_upd "$(dirname "$inst")"; info "انصراف"; return 0; }
  bash "$inst"
  rc=$?
  cleanup_upd "$(dirname "$inst")"
  if [ "$rc" -eq 0 ]; then
    ok "به‌روزرسانی کامل شد — فرمان hrms هم به نسخه جدید ارتقا یافت"
    echo -e "برای دیدن وضعیت: ${B}hrms status${N}"
    exit 0
  else
    fail "به‌روزرسانی با خطا پایان یافت — لاگ: journalctl -u ${SERVICE} -n 50"
    exit "$rc"
  fi
}

do_purge() {
  ensure_root purge
  echo ""
  echo -e "${B}${C}────────────── حذف اطلاعات نمونه ──────────────${N}"
  [ -d "$APP_DIR" ] || { fail "پوشه نصب یافت نشد: ${APP_DIR}"; exit 1; }
  [ -f "$(db_file)" ] || { fail "دیتابیس یافت نشد: $(db_file)"; exit 1; }
  [ -f "${APP_DIR}/scripts/purge-demo.ts" ] || { fail "اسکریپت purge-demo.ts در نصب موجود نیست — ابتدا آپدیت کنید (hrms update)"; exit 1; }
  echo "  1) حذف داده تراکنشی نمونه — کارکنان/فیش/نامه/درخواست/حضور و غیاب (تنظیمات و کاربران می‌مانند)"
  echo "  2) حذف کامل (--full) — همه داده‌ها جز تنظیمات/نقش‌ها/مدیر admin"
  local m fl rc bk db_url
  read -r -p "انتخاب [1]: " m || return 0
  m="${m:-1}"
  case "$m" in
    1) fl="" ;;
    2) fl="--full" ;;
    *) info "انصراف"; return 0 ;;
  esac
  confirm "از دیتابیس پشتیبان گرفته شود؟ (پیشنهاد: بله)" && {
    bk="${HOME}/hrms-backup-$(date +%F-%H%M).db"
    cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
  }
  confirm "حذف قطعی انجام شود؟ (بازگشت فقط با بازیابی پشتیبان)" || { info "انصراف"; return 0; }
  db_url="file:${APP_DIR}/db/custom.db"
  info "اجرای پاک‌سازی…"
  (
    cd "$APP_DIR" || exit 1
    if command -v bun >/dev/null 2>&1; then
      DATABASE_URL="$db_url" bun scripts/purge-demo.ts $fl
    else
      DATABASE_URL="$db_url" npx --yes tsx scripts/purge-demo.ts $fl
    fi
  )
  rc=$?
  if [ "$rc" -eq 0 ]; then
    svc_restart
    ok "پاک‌سازی کامل شد"
  else
    fail "پاک‌سازی با خطا مواجه شد (کد ${rc})"
  fi
}

do_reinstall() {
  ensure_root reinstall
  echo ""
  echo -e "${B}${C}────────────── نصب مجدد ──────────────${N}"
  echo "  1) نصب مجدد با حفظ داده‌ها و کاربران — بازسازی سورس/بیلد (تعمیر)"
  echo "  2) نصب تمیز از صفر — دیتابیس فعلی حذف (با پشتیبان) و نصب جدید با داده پایه"
  local m inst src ver rc bk
  read -r -p "انتخاب [1]: " m || return 0
  m="${m:-1}"
  case "$m" in 1|2) ;; *) info "انصراف"; return 0 ;; esac
  echo ""
  echo "  منبع نصب‌کننده:"
  echo "    a) نسخه ذخیره‌شده محلی — همان نسخه فعلی، بدون نیاز به اینترنت"
  echo "    b) دانلود از گیت‌هاب — انتخاب نسخه از فهرست"
  echo "    c) مسیر فایل نصب‌کننده روی دیسک"
  read -r -p "انتخاب [a]: " src || return 0
  src="${src:-a}"
  case "$src" in
    a)
      inst="$(ls -1v "${APP_DIR}"/installer/install-hrms-*.sh 2>/dev/null | tail -n 1)"
      if [ -z "$inst" ] || [ ! -f "$inst" ]; then
        warn "نسخه ذخیره‌شده‌ای یافت نشد (${APP_DIR}/installer/) — از گزینه b یا c استفاده کنید"
        return 0
      fi
      ok "نصب‌کننده محلی: ${inst}"
      ;;
    b)
      ver="$(pick_version)"
      [ -z "$ver" ] && { info "انصراف"; return 0; }
      inst="$(build_installer "$ver")" || return 1
      ;;
    c)
      read -r -p "مسیر فایل نصب‌کننده: " inst || return 0
      [ -f "$inst" ] || { fail "فایل یافت نشد: ${inst}"; return 1; }
      ;;
    *) info "انصراف"; return 0 ;;
  esac
  if [ "$m" = "2" ]; then
    warn "دیتابیس حذف می‌شود: کارکنان/فیش‌ها/نامه‌ها/تنظیمات واردشده از بین می‌روند"
    if [ -f "$(db_file)" ]; then
      confirm "از دیتابیس فعلی پشتیبان گرفته شود؟ (پیشنهاد: بله)" && {
        bk="${HOME}/hrms-backup-$(date +%F-%H%M).db"
        cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
      }
    fi
    confirm "نصب تمیز شروع شود؟" || { [ "$src" = "b" ] && cleanup_upd "$(dirname "$inst")"; info "انصراف"; return 0; }
    rm -f "${APP_DIR}/db/custom.db" "${APP_DIR}/db/custom.db-wal" "${APP_DIR}/db/custom.db-shm"
  else
    confirm "نصب مجدد (حفظ داده‌ها) شروع شود؟" || { [ "$src" = "b" ] && cleanup_upd "$(dirname "$inst")"; info "انصراف"; return 0; }
  fi
  # در محیط بدون systemd فرایند قدیمی nohup را می‌بندیم تا پورت آزاد شود
  systemd_ok || pkill -f "${APP_DIR}/.next/standalone/server.js" >/dev/null 2>&1 || true
  warn "این عملیات چند دقیقه طول می‌کشد (نصب بسته‌ها + بیلد)"
  bash "$inst"
  rc=$?
  [ "$src" = "b" ] && cleanup_upd "$(dirname "$inst")"
  if [ "$rc" -eq 0 ]; then
    ok "نصب مجدد کامل شد"
    exit 0
  else
    fail "نصب مجدد با خطا پایان یافت"
    exit "$rc"
  fi
}

do_remove() {
  ensure_root remove
  echo ""
  echo -e "${B}${C}────────────── حذف اسکریپت / حذف کامل ──────────────${N}"
  echo "  1) فقط فرمان مدیریتی hrms حذف شود — سامانه و داده‌ها دست‌نخورده می‌مانند"
  echo "  2) حذف کامل — فرمان + سرویس + پوشه نصب (ابتدا پشتیبان دیتابیس)"
  local m bk
  read -r -p "انتخاب [1]: " m || return 0
  m="${m:-1}"
  case "$m" in
    1)
      confirm "فرمان hrms (و HRMS) از /usr/local/bin حذف شود؟" || { info "انصراف"; return 0; }
      rm -f /usr/local/bin/hrms /usr/local/bin/HRMS
      ok "فرمان hrms حذف شد — سامانه همچنان فعال است"
      echo -e "بازگردانی بعدی: هر نصب‌کننده جدید دوباره این فرمان را می‌سازد"
      exit 0
      ;;
    2)
      confirm "ابتدا از دیتابیس پشتیبان گرفته شود؟ (پیشنهاد قوی: بله)" && {
        if [ -f "$(db_file)" ]; then
          bk="${HOME}/hrms-backup-final-$(date +%F-%H%M).db"
          cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
        fi
      }
      confirm "حذف کامل و غیرقابل بازگشت: سرویس ${SERVICE} + پوشه ${APP_DIR}؟" || { info "انصراف"; return 0; }
      if systemd_ok; then
        systemctl disable --now "$SERVICE" >/dev/null 2>&1 || true
      fi
      pkill -f "${APP_DIR}/.next/standalone/server.js" >/dev/null 2>&1 || true
      rm -f "/etc/systemd/system/${SERVICE}.service"
      { systemd_ok && systemctl daemon-reload >/dev/null 2>&1; } || true
      rm -rf "$APP_DIR"
      rm -f /usr/local/bin/hrms /usr/local/bin/HRMS
      ok "حذف کامل انجام شد"
      echo -e "برای نصب مجدد: فرمان یک‌خطی گیت‌هاب از README یا فایل install-hrms-*.sh"
      exit 0
      ;;
    *) info "انصراف" ;;
  esac
}

do_status() {
  echo ""
  echo -e "${B}${C}────────────── وضعیت سامانه ──────────────${N}"
  info "نسخه نصب‌شده: ${B}${INSTALLED_VERSION}${N} | پوشه: ${APP_DIR} | پورت: ${PORT}"
  [ -f "$(db_file)" ] && info "دیتابیس: $(db_file) ($(du -h "$(db_file)" | cut -f1))"
  if systemd_ok; then
    if systemctl is-active --quiet "$SERVICE" 2>/dev/null; then
      ok "سرویس ${SERVICE}: فعال (در حال اجرا)"
    else
      warn "سرویس ${SERVICE}: غیرفعال — شروع: systemctl start ${SERVICE}"
    fi
  else
    if pgrep -f "${APP_DIR}/.next/standalone/server.js" >/dev/null 2>&1; then
      ok "فرایند سرویس در حال اجراست"
    else
      warn "فرایند سرویس دیده نشد (اجرای nohup؟)"
    fi
  fi
  if curl -fs -o /dev/null --max-time 5 "http://127.0.0.1:${PORT}/api/branding" 2>/dev/null; then
    ok "پاسخ HTTP سالم (پورت ${PORT})"
  else
    warn "سامانه روی پورت ${PORT} پاسخ نداد"
  fi
  local latest
  latest="$(fetch_versions | tail -n 1)"
  if [ -n "$latest" ]; then
    if [ "$latest" = "$INSTALLED_VERSION" ]; then
      ok "آخرین نسخه گیت‌هاب: ${latest} — به‌روز هستید"
    else
      info "آخرین نسخه گیت‌هاب: ${B}${latest}${N} — برای به‌روزرسانی: hrms update"
    fi
  else
    warn "فهرست نسخه‌های گیت‌هاب دریافت نشد"
  fi
}

menu() {
  while true; do
    echo ""
    echo -e "${B}${C}════════ HRMS 1405 — مدیریت استقرار (نسخه نصب‌شده: ${INSTALLED_VERSION}) ════════${N}"
    echo ""
    echo "  ۱) آپدیت — فهرست نسخه‌های گیت‌هاب + به‌روزرسانی امن (داده‌ها حفظ می‌شوند)"
    echo "  ۲) حذف اطلاعات نمونه — پاک‌سازی داده تراکنشی یا کامل"
    echo "  ۳) نصب مجدد — تعمیر با حفظ داده یا نصب تمیز از صفر"
    echo "  ۴) حذف اسکریپت — فقط فرمان hrms یا حذف کامل سامانه"
    echo "  ۵) وضعیت — سرویس/سلامت/آخرین نسخه گیت‌هاب"
    echo "  ۰) خروج"
    echo ""
    local ch
    read -r -p "گزینه موردنظر را انتخاب کنید: " ch || { echo ""; break; }
    case "$ch" in
      1|۱) do_update ;;
      2|۲) do_purge ;;
      3|۳) do_reinstall ;;
      4|۴) do_remove ;;
      5|۵) do_status ;;
      0|۰|q|Q) break ;;
      *) warn "گزینه نامعتبر: $ch" ;;
    esac
    # عملیات‌های ۱/۳/۴ در پایان خودشان exit می‌کنند
  done
  info "پایان"
}

usage() {
  cat <<USAGEEOF
فرمان مدیریتی HRMS 1405 (نسخه نصب‌شده: ${INSTALLED_VERSION})

استفاده:
  hrms               منوی تعاملی — آپدیت / حذف اطلاعات نمونه / نصب مجدد / حذف اسکریپت
  hrms update        به‌روزرسانی — فهرست نسخه‌های گیت‌هاب + انتخاب + به‌روزرسانی امن
  hrms purge         حذف اطلاعات نمونه (تراکنشی یا کامل)
  hrms reinstall     نصب مجدد (تعمیر با حفظ داده یا نصب تمیز از صفر)
  hrms remove        حذف فرمان hrms یا حذف کامل سامانه
  hrms status        وضعیت سرویس/سلامت/آخرین نسخه گیت‌هاب
  hrms versions      فقط فهرست نسخه‌های موجود در گیت‌هاب
  hrms help          همین راهنما
USAGEEOF
}

case "${1:-}" in
  update|up)        do_update ;;
  purge|clean)      do_purge ;;
  reinstall|re)     do_reinstall ;;
  remove|uninstall) do_remove ;;
  status|st)        do_status ;;
  versions|ver)
    V="$(fetch_versions)"
    if [ -n "$(printf '%s' "$V" | tr -d '[:space:]')" ]; then
      echo "نسخه‌های موجود در گیت‌هاب (جدیدترین در بالا):"
      printf '%s\n' "$V" | sort -rV
    else
      warn "دریافت فهرست نسخه‌ها از گیت‌هاب ناموفق بود (شبکه/آفلاین؟)"
    fi
    ;;
  help|-h|--help)   usage ;;
  "")               menu ;;
  *)                warn "گزینه ناشناخته: $1"; echo ""; usage; exit 1 ;;
esac

HRMS_CLI_EOF
sed -i "s|__APP_DIR__|${APP_DIR}|g; s|__PORT__|${PORT}|g; s|__APP_VERSION__|${APP_VERSION}|g" "$CLI_TMP"
chmod 755 "$CLI_TMP"
bash -n "$CLI_TMP" || { rm -f "$CLI_TMP"; fail "خطای سینتکس در فرمان مدیریتی hrms"; }
mv -f "$CLI_TMP" /usr/local/bin/hrms
ln -sf hrms /usr/local/bin/HRMS 2>/dev/null || true
ok "فرمان مدیریتی نصب شد — برای مدیریت سامانه تایپ کنید: ${B}hrms${N} (یا HRMS)"

# ================================================================
# ۱۲) خلاصه نهایی
# ================================================================
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
[ -n "$IP" ] || IP="آدرس-سرور"
echo -e "${B}${G}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    ${N}${B}نصب با موفقیت کامل شد ✓${G}                        ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  نسخه نصب‌شده:  HRMS 1405 — v${APP_VERSION} (نسخه ${APP_VERSION_FA})"
if [ -n "$DOMAIN" ]; then
  echo "║  نشانی سامانه:   ${C}https://${DOMAIN}${G}  (و http://${IP}:${PORT})"
else
  echo "║  نشانی سامانه:   ${C}http://${IP}:${PORT}${G}"
fi
if [ "$UPDATE_MODE" -eq 1 ]; then
  echo "║  حالت:           به‌روزرسانی نصب موجود — داده‌ها/کاربران/کلید نشست حفظ شد"
fi
echo "║  کاربران نمونه:  admin/admin123  •  hr/hr123  •  emp/emp123  •  edari/edari123 (کارشناس اداری)"
echo "║  داده پرسنلی:    هیچ — از ۲.۱.۰ نصب بدون کارمند/فیش/نامه نمونه است (کارکنان واقعی را خودتان وارد کنید)"
echo "║  جدید ۲.۵.۰:     فرمان مدیریتی hrms (یا HRMS) — آپدیت از گیت‌هاب + حذف داده"
echo "║                   نمونه + نصب مجدد + حذف اسکریپت، همه از خط فرمان"
echo "║  جدید ۲.۴.۰:     لاگ تغییرات پرونده + بازگردانی یک‌کلیکی + ایمپورت هوشمند"
echo "║  دیتابیس:        ${APP_DIR}/db/custom.db"
echo "║  سورس:           ${APP_DIR}"
echo "╠══════════════════════════════════════════════════════════════╣${N}"
echo "  دستورات مدیریتی:"
echo "    منوی مدیریت:   ${C}hrms${N}  (یا HRMS) — آپدیت/حذف داده نمونه/نصب مجدد/حذف اسکریپت"
echo "    وضعیت سریع:     hrms status   |   فهرست نسخه‌های گیت‌هاب:   hrms versions"
echo "    وضعیت سرویس:   systemctl status ${SERVICE}"
echo "    ری‌استارت:      systemctl restart ${SERVICE}"
echo "    لاگ زنده:       journalctl -u ${SERVICE} -f"
echo "    پشتیبان‌گیری:    cp ${APP_DIR}/db/custom.db ~/hrms-backup-\$(date +%F).db"
if [ "$DEMO" -eq 1 ]; then
  echo ""
  echo "  حذف داده تراکنشی (هر زمان که بخواهید شروع تازه کنید):"
  echo "    سریع‌ترین راه:   فرمان hrms ← گزینه ۲ «حذف اطلاعات نمونه»"
  echo "    از سامانه:      تنظیمات ← تب «داده نمونه» ← دکمه حذف"
  echo "    از خط فرمان:    cd ${APP_DIR} && DATABASE_URL='file:${APP_DIR}/db/custom.db' npx --yes tsx scripts/purge-demo.ts"
  echo "    حالت کامل:      همین دستور با پرچم --full (فقط تنظیمات + نقش‌ها + admin باقی می‌ماند)"
fi
echo ""
echo -e "  ${Y}⚠ امنیت:${N} بلافاصله وارد شوید و رمز admin را از «تنظیمات ← کاربران» تغییر دهید."
echo -e "  ${Y}⚠ امنیت:${N} فایل ${APP_DIR}/.env حاوی کلید نشست است — آن را افشا نکنید."
echo ""
[ "$DEMO" -eq 1 ] && echo -e "  ${Y}نکته:${N} از ۲.۱.۰ هیچ داده پرسنلی نمونه‌ای نصب نمی‌شود — کاربران نمونه فقط برای آزمایش دسترسی نقش‌ها هستند. با --no-demo فقط کاربر admin ساخته می‌شود."
echo ""
ok "سامانه جامع منابع انسانی ۱۴۰۵ آماده بهره‌برداری است"
exit 0

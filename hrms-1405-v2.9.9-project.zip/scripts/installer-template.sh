#!/usr/bin/env bash
# ================================================================
#   نصب‌کننده تمام‌خودکار — سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵
#   تک‌فایل (سورس داخل همین اسکریپت) — بدون نیاز به هیچ کار دستی
#   اجرا:  sudo bash install-hrms.sh [--port 3000] [--dir /opt/hrms] [--no-demo] [--domain hrms.example.com]
#   سازگار: Ubuntu 20.04+ / Debian 11+ / RHEL 9+ / Rocky / Alma (amd64 و arm64)
#   آپدیت: اجرای مجدد روی نصب موجود = به‌روزرسانی امن (داده‌ها و کلید نشست حفظ می‌شوند)
#   پس از نصب: تایپ کنید  hrms  (یا HRMS)  ←  منوی مدیریتی تعاملی با کلیدهای جهت‌دار:
#   آپدیت از گیت‌هاب / وضعیت زنده / مدیریت سرویس / پشتیبان‌گیری / حذف اطلاعات
#   نمونه / نصب مجدد / حذف اسکریپت — فهرست نسخه‌ها خودکار از مخزن گیت‌هاب می‌آید
# ================================================================
set -euo pipefail

# ---------- نسخه بسته ----------
APP_VERSION="2.9.5"
APP_VERSION_FA="۲.۹.۱"

# ---------- رنگ‌ها ----------
if command -v tput >/dev/null 2>&1 && [ -t 1 ]; then
  B=$(tput bold); R=$(tput setaf 1); G=$(tput setaf 2); Y=$(tput setaf 3); C=$(tput setaf 6); N=$(tput sgr0)
else
  B=""; R=""; G=""; Y=""; C=""; N=""
fi
info()  { echo -e "${C}◈${N} $*"; }
ok()    { echo -e "${G}✓${N} $*"; }
warn()  { echo -e "${Y}⚠${N} $*"; }
fail()  { echo -e "${R}✗${N} $*" >&2; exit 1; }

# ---------- پارامترها ----------
PORT=3000
APP_DIR=/opt/hrms
DEMO=1
DOMAIN=""
while [ $# -gt 0 ]; do
  case "$1" in
    --port)     PORT="$2"; shift 2 ;;
    --dir)      APP_DIR="$2"; shift 2 ;;
    --no-demo)  DEMO=0; shift ;;
    --domain)   DOMAIN="$2"; shift 2 ;;
    -h|--help)
      sed -n '2,9p' "$0"; exit 0 ;;
    *) fail "آرگومان ناشناخته: $1 (برای راهنما: --help)" ;;
  esac
done
# اعتبارسنجی دامنه — فقط حروف/عدد/نقطه/خط تیره
if [ -n "$DOMAIN" ]; then
  echo "$DOMAIN" | grep -Eq '^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$' \
    || fail "دامنه نامعتبر است: $DOMAIN (نمونه صحیح: hrms.example.com)"
fi

echo -e "${B}${C}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║   نصب خودکار سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵   ║"
echo "║        HRMS 1405 — نسخه ${APP_VERSION} — نصب یک‌مرحله‌ای        ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo -e "${N}"
info "نسخه: ${B}${APP_VERSION}${N} | پوشه نصب: ${B}${APP_DIR}${N} | پورت: ${B}${PORT}${N} | کاربران نمونه: $([ $DEMO -eq 1 ] && echo 'بله' || echo 'خیر') (داده پرسنلی: هیچ)${DOMAIN:+ | دامنه: ${B}${DOMAIN}${N}}"

# ================================================================
# ۱) بررسی ریشه و سیستم‌عامل
# ================================================================
[ "$(id -u)" -eq 0 ] || fail "این اسکریپت باید با ریشه اجرا شود: sudo bash $0"
OS_ID=$(. /etc/os-release 2>/dev/null && echo "${ID:-}" || echo "")
OS_VER=$(. /etc/os-release 2>/dev/null && echo "${VERSION_ID:-}" || echo "")
info "سیستم‌عامل تشخیص داده شد: ${OS_ID:-نامشخص} ${OS_VER}"

PKG=""
if command -v apt-get >/dev/null 2>&1; then PKG="apt"
elif command -v dnf >/dev/null 2>&1; then PKG="dnf"
else fail "پکیج‌منیجر پشتیبانی‌نشده — فقط apt/dnf (Ubuntu/Debian/RHEL) پشتیبانی می‌شود."
fi

# ================================================================
# ۲) نصب پیش‌نیازهای سیستمی (خودکار)
# ================================================================
info "نصب پیش‌نیازهای سیستمی (curl, sqlite3, openssl, tar)…"
export DEBIAN_FRONTEND=noninteractive
if [ "$PKG" = "apt" ]; then
  apt-get update -qq || warn "apt update با هشدار ادامه یافت"
  apt-get install -y -qq curl ca-certificates sqlite3 openssl tar gzip >/dev/null 2>&1 || \
    apt-get install -y curl ca-certificates sqlite3 openssl tar gzip
elif [ "$PKG" = "dnf" ]; then
  dnf install -y -q curl ca-certificates sqlite openssl tar gzip || \
    dnf install -y curl sqlite openssl tar gzip
fi
ok "پیش‌نیازهای سیستمی نصب شدند"

# ================================================================
# ۳) نصب Node.js ≥ 20 (خودکار)
# ================================================================
NODE_MAJOR=0
if command -v node >/dev/null 2>&1; then
  NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)
fi
if [ "$NODE_MAJOR" -lt 20 ]; then
  info "Node.js ≥ ۲۰ یافت نشد (نسخه فعلی: ${NODE_MAJOR:-ندارد}) — نصب Node 22 از مخزن رسمی…"
  if [ "$PKG" = "apt" ]; then
    curl -fsSL https://deb.nodesource.com/setup_22.x | bash - >/dev/null 2>&1 || true
    apt-get install -y -qq nodejs >/dev/null 2>&1 || apt-get install -y nodejs
  else
    curl -fsSL https://rpm.nodesource.com/setup_22.x | bash - >/dev/null 2>&1 || true
    dnf install -y -q nodejs || dnf module install -y nodejs:22 || fail "نصب Node.js ناموفق بود"
  fi
  NODE_MAJOR=$(node -e "console.log(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)
fi
[ "$NODE_MAJOR" -ge 20 ] || fail "Node.js ≥ ۲۰ در دسترس نیست — لطفاً دستی نصب کنید و دوباره اجرا کنید"
ok "Node.js $(node --version) آماده است"

# ================================================================
# ۴) حافظه کم؟ swap خودکار (ساخت Next.js به ≥۱GB نیاز دارد)
# ================================================================
MEM_MB=$(awk '/MemTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 2048)
SWAP_MB=$(awk '/SwapTotal/ {printf "%d", $2/1024}' /proc/meminfo 2>/dev/null || echo 0)
if [ "$MEM_MB" -lt 900 ] && [ "$SWAP_MB" -lt 500 ]; then
  info "حافظه کم (${MEM_MB}MB) — ساخت ۲GB swap برای موفقیت بیلد…"
  if ! swapon --show 2>/dev/null | grep -q . && [ ! -f /swapfile ]; then
    fallocate -l 2G /swapfile 2>/dev/null || dd if=/dev/zero of=/swapfile bs=1M count=2048 status=none
    chmod 600 /swapfile && mkswap -q /swapfile && swapon /swapfile
    grep -q '/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
    ok "swap فعال شد"
  else
    warn "swap از قبل موجود است — ادامه"
  fi
fi

# ================================================================
# ۵) استخراج سورس از داخل همین فایل (خودکار — بدون اکسترکت دستی)
# ================================================================
info "استخراج سورس سامانه در ${APP_DIR}…"
mkdir -p "$APP_DIR"

# ---------- تشخیص حالت به‌روزرسانی: نصب موجود با کاربر واقعی؟ ----------
# دیتابیس جزو بسته نیست → نصب مجدد سورس آن را حذف نمی‌کند؛
# اگر کاربر وجود دارد، این اجرا «به‌روزرسانی» است: داده/کلید نشست حفظ و seed اجرا نمی‌شود.
UPDATE_MODE=0
DB_FILE="${APP_DIR}/db/custom.db"
if [ -s "$DB_FILE" ]; then
  USERS_N=$(sqlite3 "$DB_FILE" "SELECT COUNT(*) FROM users;" 2>/dev/null || echo 0)
  if [ "${USERS_N:-0}" -gt 0 ] 2>/dev/null; then
    UPDATE_MODE=1
    info "نصب موجود تشخیص داده شد (${USERS_N} کاربر) — به‌روزرسانی امن: داده‌ها حفظ می‌شوند"
  fi
fi

MARKER='__PAYLOAD_B64__'
if ! grep -q "^${MARKER}$" "$0"; then
  fail "بسته سورس داخل اسکریپت یافت نشد — فایل نصب‌کننده را دوباره دانلود کنید"
fi
awk "f{print} /^${MARKER}$/{f=1}" "$0" | base64 -d | tar -xzf - -C "$APP_DIR"
[ -f "$APP_DIR/package.json" ] || fail "استخراج سورس ناموفق بود"
ok "سورس استخراج شد"

# ================================================================
# ۶) پیکربندی محیط (کلید امنیتی تصادفی + مسیر دیتابیس)
#    در حالت به‌روزرسانی: کلید نشست قبلی حفظ می‌شود (نشست‌های باز معتبر می‌مانند)
# ================================================================
info "تولید پیکربندی امن…"
OLD_SECRET=""
if [ "$UPDATE_MODE" -eq 1 ] && [ -f "$APP_DIR/.env" ]; then
  OLD_SECRET=$(grep -E '^AUTH_SECRET=' "$APP_DIR/.env" | head -1 | cut -d= -f2- || true)
  [ -n "$OLD_SECRET" ] && ok "کلید نشست موجود حفظ شد"
fi
AUTH_SECRET="${OLD_SECRET:-$(openssl rand -hex 32 2>/dev/null || head -c 32 /dev/urandom | od -An -tx1 | tr -d ' \n')}"
mkdir -p "$APP_DIR/db"
cat > "$APP_DIR/.env" <<ENVEOF
DATABASE_URL=file:${APP_DIR}/db/custom.db
AUTH_SECRET=${AUTH_SECRET}
NODE_ENV=production
PORT=${PORT}
HOSTNAME=0.0.0.0
APP_VERSION=${APP_VERSION}
ENVEOF
chmod 600 "$APP_DIR/.env"
ok ".env تولید شد (کلید نشست ۶۴ نویسه تصادفی + نسخه ${APP_VERSION} برای نمایش در پنل)"

# ================================================================
# ۷) نصب بسته‌های npm + آماده‌سازی دیتابیس
# ================================================================
cd "$APP_DIR"
info "نصب بسته‌ها از npm (چند دقیقه صبر کنید)…"
# ⚠ نکته حیاتی: اگر این اسکریپت از «دکمه به‌روزرسانی پنل» اجرا شود، NODE_ENV=production
# از سرویس وب به ارث می‌رسد؛ npm (و bun) در آن حالت devDependencies را نصب نمی‌کنند و
# بیلد Turbopack با خطای «Cannot find module '@tailwindcss/postcss'» شکست می‌خورد.
# → همیشه با env پاک + --include=dev نصب می‌کنیم و نتیجه را راستی‌آزمایی می‌کنیم.
npm_install() { env -u NODE_ENV npm install --include=dev --no-audit --no-fund "$@"; }
if ! npm_install --loglevel=error >/dev/null 2>&1; then
  warn "نصب بی‌صدا ناموفق بود — تلاش مجدد با نمایش خروجی…"
  npm_install || fail "نصب بسته‌ها ناموفق بود — اتصال اینترنت/آینه npm را بررسی و دوباره اجرا کنید"
fi
# راستی‌آزمایی بسته‌های ضروری بیلد (پلاگین Tailwind/PostCSS از devDependencies)
node -e "require.resolve('@tailwindcss/postcss')" >/dev/null 2>&1 \
  || npm_install >/dev/null 2>&1 \
  || fail "بسته‌های توسعه (devDependencies) نصب نشدند — دوباره اجرا کنید"
ok "بسته‌ها نصب شدند (شامل بسته‌های بیلد)"

info "آماده‌سازی دیتابیس SQLite (پرایسما)…"
# متغیر محیطی صریح — اولویت بر .env (در برابر DATABASE_URL والد/غیرمنتظره مقاوم است)
DB_URL="file:${APP_DIR}/db/custom.db"
DATABASE_URL="$DB_URL" npx --yes prisma generate >/dev/null 2>&1 || DATABASE_URL="$DB_URL" npx prisma generate
DATABASE_URL="$DB_URL" npx --yes prisma db push --accept-data-loss >/dev/null 2>&1 || DATABASE_URL="$DB_URL" npx prisma db push --accept-data-loss
[ -s "$APP_DIR/db/custom.db" ] || fail "ساخت دیتابیس ناموفق بود"
ok "دیتابیس ساخته شد: ${APP_DIR}/db/custom.db"

# ================================================================
# ۸) داده اولیه — اجرات TS با bun یا tsx (خودکار)
# ================================================================
RUNTS=""
if command -v bun >/dev/null 2>&1; then
  RUNTS="bun"
elif npm install -g bun >/dev/null 2>&1 && command -v bun >/dev/null 2>&1; then
  RUNTS="bun"
fi
if [ -z "$RUNTS" ]; then
  info "bun در دسترس نیست — استفاده از tsx…"
  RUNTS="npx --yes tsx"
fi

if [ "$UPDATE_MODE" -eq 1 ]; then
  info "به‌روزرسانی: داده‌های موجود و کاربران حفظ می‌شوند (seed اجرا نمی‌شود)…"
  # ارتقای داده‌ها: قالب‌نامه‌های خودکار + مجوزهای حضور و غیب (idempotent)
  if [ -f scripts/backfill-v8.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v8.ts >/dev/null 2>&1 || true
    ok "قالب‌نامه‌های خودکار و مجوزهای حضور و غیب اضافه شد"
  fi
  # مجوزهای «مدیریت تغییرات حقوق» (پیش‌نویس/گروهی/معکوس/آرشیو) — v2.2.0
  if [ -f scripts/backfill-v9.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v9.ts >/dev/null 2>&1 || true
    ok "مجوزهای مدیریت تغییرات حقوق به نقش‌ها اضافه شد"
  fi
  # پاداش اور تارگت +۲ پایه (سیاست جدید — فقط اگر مقدار پیش‌فرض قدیمی ۱ باشد) — v2.3.0
  if [ -f scripts/backfill-v10.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v10.ts >/dev/null 2>&1 || true
    ok "قاعده پاداش اور تارگت (+۲ پایه — قابل ویرایش) به‌روزرسانی شد"
  fi
  # اطلاعیه «تازه‌های نسخه ۲.۷.۰» + پاک‌سازی کش چک آپدیت — v2.7.0 (idempotent)
  if [ -f scripts/backfill-v27.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v27.ts >/dev/null 2>&1 || true
    ok "اطلاعیه تازه‌های نسخه ۲.۷.۰ آماده شد (پاپ‌آپ یک‌باره برای کاربران)"
  fi
  # ارتقای اطلاعیه به ۲.۷.۱ + کش چک نسخه تازه — v2.7.1 (idempotent)
  if [ -f scripts/backfill-v271.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v271.ts >/dev/null 2>&1 || true
    ok "اطلاعیه تازه‌های نسخه ۲.۷.۱ آماده شد + کش چک نسخه پاک شد"
  fi
  # ارتقای اطلاعیه به ۲.۷.۲ + کش چک نسخه تازه — v2.7.2 (idempotent)
  if [ -f scripts/backfill-v272.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v272.ts >/dev/null 2>&1 || true
    ok "اطلاعیه تازه‌های نسخه ۲.۷.۲ آماده شد + کش چک نسخه پاک شد"
  fi
  # ارتقای اطلاعیه به ۲.۷.۳ + کش چک نسخه تازه — v2.7.3 (idempotent)
  if [ -f scripts/backfill-v273.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v273.ts >/dev/null 2>&1 || true
    ok "اطلاعیه تازه‌های نسخه ۲.۷.۳ آماده شد + کش چک نسخه پاک شد"
  fi
  # تعطیلات رسمی ۱۴۰۵ + شیفت‌ها و ساعت استاندارد دوره — v2.8.0 (idempotent)
  if [ -f scripts/backfill-v28.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v28.ts >/dev/null 2>&1 || true
    ok "تعطیلات رسمی ۱۴۰۵ و جدول شیفت‌ها بارگذاری شد (۲.۸.۰)"
  fi
  # پشتیبان‌گیری/بازیابی داده‌ها — v2.8.1 (idempotent)
  if [ -f scripts/backfill-v281.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v281.ts >/dev/null 2>&1 || true
    ok "اطلاعیه تازه‌های نسخه ۲.۸.۱ آماده شد (پشتیبان‌گیری و بازیابی)"
  fi
  # مدیریت کار: ماتریس آیزنهاور + زنجیره واگذاری — v2.9.0 (idempotent)
  if [ -f scripts/backfill-v29.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v29.ts >/dev/null 2>&1 || true
    ok "مجوز «مدیریت کار» به همه نقش‌ها اضافه شد + اطلاعیه تازه‌های نسخه ۲.۹.۰ (ماتریس آیزنهاور + نمای زنجیره واگذاری)"
  fi
  # رفع شکست بیلد به‌روزرسانی + قفل نسخه بسته‌ها — v2.9.1 (idempotent)
  if [ -f scripts/backfill-v291.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v291.ts >/dev/null 2>&1 || true
    ok "اطلاعیه تازه‌های نسخه ۲.۹.۱ آماده شد + کش چک نسخه پاک شد"
  fi
  # رفع باگ سوئیچ RTL + پشتیبانی داکر — v2.9.2 (idempotent)
  if [ -f scripts/backfill-v292.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v292.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v293.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v293.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v294.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v294.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v295.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v295.ts >/dev/null 2>&1 || true
    ok "اطلاعیه تازه‌های نسخه ۲.۹.۵ آماده شد + کش چک نسخه پاک شد"
  fi
  # مهر نسخه در دیتابیس + اطلاعیه ۲.۹.۶ — v2.9.6 (idempotent)
  if [ -f scripts/backfill-v296.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v296.ts >/dev/null 2>&1 || true
    ok "مهر نسخه ۲.۹.۶ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۶"
  fi
  # مهر نسخه + اطلاعیه ۲.۹.۷ — v2.9.7 (idempotent)
  if [ -f scripts/backfill-v297.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v297.ts >/dev/null 2>&1 || true
    ok "مهر نسخه ۲.۹.۷ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۷ (ماندگاری دیتا روی داکپلوی)"
  fi
  # رفع کرش RoleEditor + اطلاعیه ۲.۹.۸ — v2.9.8 (idempotent)
  if [ -f scripts/backfill-v298.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v298.ts >/dev/null 2>&1 || true
    ok "مهر نسخه ۲.۹.۸ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۸ (رفع خطای نقش‌ها و مجوزها)"
  fi
  # مدل دوم پاداش (برآورد بودجه) + اطلاعیه ۲.۹.۹ — v2.9.9 (idempotent)
  if [ -f scripts/backfill-v299.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v299.ts >/dev/null 2>&1 || true
    ok "مهر نسخه ۲.۹.۹ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۹ (مدل دوم پاداش — برآورد بودجه)"
  fi
  ok "داده‌های فعلی بدون تغییر ماند"
elif [ "$DEMO" -eq 1 ]; then
  info "بارگذاری داده پایه (پارامترهای قانونی، ساختار سازمانی، طبقه‌بندی مشاغل، کاربران نمونه) — بدون هیچ داده پرسنلی…"
  DATABASE_URL="$DB_URL" $RUNTS prisma/seed.ts >/dev/null 2>&1 || DATABASE_URL="$DB_URL" $RUNTS prisma/seed.ts
  # نقش‌های سیستمی + رفاهیات + قالب نامه‌ها + مدیر واحدها
  if [ -f scripts/backfill-v4.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v4.ts >/dev/null 2>&1 || true
  fi
  # کارشناس اداری + تنظیمات شماره‌گذاری نامه‌ها (ZDX_AD_0507019)
  if [ -f scripts/backfill-v5.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v5.ts >/dev/null 2>&1 || true
  fi
  # مجوزهای مدیریت تغییرات حقوق (idempotent)
  if [ -f scripts/backfill-v9.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v9.ts >/dev/null 2>&1 || true
  fi
  # پاداش اور تارگت +۲ پایه — پیش‌فرض seed جدید خودکار است؛ backfill برای اطمینان (idempotent)
  if [ -f scripts/backfill-v10.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v10.ts >/dev/null 2>&1 || true
  fi
  # اطلاعیه «تازه‌های نسخه» — seed خودکار می‌سازد؛ backfill برای اطمینان (idempotent)
  if [ -f scripts/backfill-v27.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v27.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v271.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v271.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v272.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v272.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v273.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v273.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v28.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v28.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v281.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v281.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v29.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v29.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v291.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v291.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v292.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v292.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v293.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v293.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v294.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v294.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v295.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v295.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v296.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v296.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v297.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v297.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v298.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v298.ts >/dev/null 2>&1 || true
  fi
  if [ -f scripts/backfill-v299.ts ]; then
    DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v299.ts >/dev/null 2>&1 || true
  fi
  ok "داده پایه بارگذاری شد — بدون هیچ داده پرسنلی (کارکنان را از ماژول «کارکنان» یا ایمپورت اکسل وارد کنید)"
else
  info "نصب تمیز (بدون کاربران نمونه) — ساخت مدیر اولیه…"
  cat > "$APP_DIR/bootstrap.mjs" <<'BOOTEOF'
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
const db = new PrismaClient();
const salt = randomBytes(16).toString("hex");
const hash = scryptSync("admin123", salt, 64).toString("hex");
const role = await db.role.upsert({
  where: { key: "SUPER_ADMIN" },
  update: {},
  create: { key: "SUPER_ADMIN", name: "مدیر کل سیستم", description: "دسترسی کامل", permissions: "[\"*\"]" },
});
await db.user.upsert({
  where: { username: "admin" },
  update: { roleId: role.id },
  create: { username: "admin", passwordHash: `${salt}:${hash}`, fullName: "مدیر کل سیستم", role: "SUPER_ADMIN", roleId: role.id, isActive: true },
});
await db.systemSetting.upsert({
  where: { key: "display" },
  update: {},
  create: { key: "display", value: "{\"unit\":\"TOMAN\"}" },
});
// مهر نسخه در دیتابیس — fallback فوتر/پنل آپدیت وقتی env APP_VERSION نیست (PaaS)
const stampVer = String(process.env.APP_VERSION || "").trim();
if (stampVer) {
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: stampVer },
    create: { key: "app_version", value: stampVer },
  });
}
await db.$disconnect();
console.log("bootstrap-ok");
BOOTEOF
  APP_VERSION="$APP_VERSION" DATABASE_URL="$DB_URL" node "$APP_DIR/bootstrap.mjs" >/dev/null 2>&1 || APP_VERSION="$APP_VERSION" DATABASE_URL="$DB_URL" node "$APP_DIR/bootstrap.mjs"
  rm -f "$APP_DIR/bootstrap.mjs"
  ok "کاربر مدیر ساخته شد: admin / admin123"
fi

# قالب‌نامه‌های خودکار (گواهی اشتغال/معرفی به بانک/معرفی‌نامه) — در همه حالت‌های نصب
if [ -f scripts/backfill-v8.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v8.ts >/dev/null 2>&1 || true
  ok "قالب‌نامه‌های آماده (LT-010…LT-012) در دسترس است"
fi

# تعطیلات رسمی ۱۴۰۵ + شیفت‌ها و ساعت استاندارد دوره — در همه حالت‌های نصب (idempotent)
if [ -f scripts/backfill-v28.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v28.ts >/dev/null 2>&1 || true
  ok "تعطیلات رسمی ۱۴۰۵ و جدول شیفت‌ها بارگذاری شد"
fi

# پشتیبان‌گیری/بازیابی داده‌ها — در همه حالت‌های نصب (idempotent)
if [ -f scripts/backfill-v281.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v281.ts >/dev/null 2>&1 || true
  ok "اطلاعیه تازه‌های نسخه ۲.۸.۱ آماده شد (پشتیبان‌گیری و بازیابی)"
fi

# مدیریت کار (ماتریس آیزنهاور + زنجیره واگذاری) — در همه حالت‌های نصب (idempotent)
if [ -f scripts/backfill-v29.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v29.ts >/dev/null 2>&1 || true
  ok "مجوز «مدیریت کار» به همه نقش‌ها اضافه شد + اطلاعیه تازه‌های نسخه ۲.۹.۰"
fi

# رفع باگ سوئیچ RTL + اطلاعیه — در همه حالت‌های نصب (idempotent)
if [ -f scripts/backfill-v291.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v291.ts >/dev/null 2>&1 || true
  ok "اطلاعیه تازه‌های نسخه ۲.۹.۱ آماده شد + کش چک نسخه پاک شد"
fi
if [ -f scripts/backfill-v292.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v292.ts >/dev/null 2>&1 || true
fi
if [ -f scripts/backfill-v293.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v293.ts >/dev/null 2>&1 || true
fi
if [ -f scripts/backfill-v294.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v294.ts >/dev/null 2>&1 || true
fi
if [ -f scripts/backfill-v295.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v295.ts >/dev/null 2>&1 || true
  ok "اطلاعیه تازه‌های نسخه ۲.۹.۵ آماده شد + کش چک نسخه پاک شد"
fi
if [ -f scripts/backfill-v296.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v296.ts >/dev/null 2>&1 || true
  ok "مهر نسخه ۲.۹.۶ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۶"
fi
if [ -f scripts/backfill-v297.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v297.ts >/dev/null 2>&1 || true
  ok "مهر نسخه ۲.۹.۷ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۷"
fi
if [ -f scripts/backfill-v298.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v298.ts >/dev/null 2>&1 || true
  ok "مهر نسخه ۲.۹.۸ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۸ (رفع خطای نقش‌ها و مجوزها)"
fi
if [ -f scripts/backfill-v299.ts ] && [ "$UPDATE_MODE" -eq 0 ]; then
  DATABASE_URL="$DB_URL" $RUNTS scripts/backfill-v299.ts >/dev/null 2>&1 || true
  ok "مهر نسخه ۲.۹.۹ در دیتابیس ثبت شد + اطلاعیه تازه‌های نسخه ۲.۹.۹ (مدل دوم پاداش — برآورد بودجه)"
fi

# ================================================================
# ۹) بیلد نسخه تولیدی (standalone)
#    ⚠ next build پوشه .next را از ابتدا پاک می‌کند — یعنی بیلدِ در حال سرویس‌دهی
#    (server.js + CSS/فونت‌های استاتیک) حذف می‌شود. اگر بیلد شکست بخورد و سرویس
#    ری‌استارت نشود، سایتِ در حال اجرا بدون CSS/فونت می‌ماند (باگ گزارش‌شده).
#    راه‌حل: بیلد فعلی را کنار می‌گذاریم؛ در صورت شکست همان‌جا بازگردانی می‌شود
#    تا سرویس در حال اجرا بدون وقفه (و بدون ری‌استارت) سالم بماند.
# ================================================================
info "بیلد نسخه تولیدی Next.js (طولانی‌ترین مرحله)…"
export DATABASE_URL="${DB_URL}"
export AUTH_SECRET="$AUTH_SECRET"
export NEXT_TELEMETRY_DISABLED=1
NEXT_BAK="${APP_DIR}/.next.prev"
rm -rf "$NEXT_BAK"
if [ -d "${APP_DIR}/.next" ]; then
  mv -f "${APP_DIR}/.next" "$NEXT_BAK" || true
fi
if ! npm run build >/dev/null 2>&1; then
  if ! npm run build; then
    # بیلد شکست خورد — بازگردانی بیلد قبلی برای سلامت فوری سرویس در حال اجرا
    if [ -d "$NEXT_BAK" ] && [ ! -f "${APP_DIR}/.next/standalone/server.js" ]; then
      rm -rf "${APP_DIR}/.next"
      mv -f "$NEXT_BAK" "${APP_DIR}/.next"
      ok "بیلد قبلی بازگردانی شد — سرویس در حال اجرا بدون وقفه به کار ادامه می‌دهد"
    fi
    fail "بیلد ناموفق بود — لاگ: cd $APP_DIR && npm run build"
  fi
fi
rm -rf "$NEXT_BAK"
[ -f "$APP_DIR/.next/standalone/server.js" ] || fail "بیلد ناموفق بود — لاگ: cd $APP_DIR && npm run build"
ok "بیلد standalone آماده شد"

# ================================================================
# ۱۰) سرویس systemd (اجرای دائمی + راه‌اندازی خودکار پس از ریبوت)
# ================================================================
SERVICE=hrms
# آیا systemd واقعاً در حال اجراست؟ (نه فقط نصب — مثلاً WSL بدون systemd)
SYSTEMD_RUNNING=0
if command -v systemctl >/dev/null 2>&1; then
  if [ -d /run/systemd/system ] || systemctl is-system-running >/dev/null 2>&1; then
    SYSTEMD_RUNNING=1
  fi
fi
if [ "$SYSTEMD_RUNNING" -eq 1 ]; then
  info "نصب سرویس systemd…"
  cat > /etc/systemd/system/${SERVICE}.service <<UNITEOF
[Unit]
Description=HRMS 1405 — سامانه جامع منابع انسانی و حقوق و دستمزد
After=network.target

[Service]
Type=simple
WorkingDirectory=${APP_DIR}
Environment=NODE_ENV=production
Environment=PORT=${PORT}
Environment=HOSTNAME=0.0.0.0
Environment=DATABASE_URL=${DB_URL}
Environment=AUTH_SECRET=${AUTH_SECRET}
Environment=APP_VERSION=${APP_VERSION}
ExecStart=$(command -v node) ${APP_DIR}/.next/standalone/server.js
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNITEOF
  systemctl daemon-reload
  systemctl enable ${SERVICE} >/dev/null 2>&1 || true
  systemctl restart ${SERVICE}
  ok "سرویس ${SERVICE} فعال شد (راه‌اندازی خودکار پس از ریبوت)"
else
  warn "systemd فعال نیست — اجرای مستقیم با nohup…"
  ( cd "$APP_DIR" && DATABASE_URL="${DB_URL}" AUTH_SECRET="$AUTH_SECRET" PORT="$PORT" HOSTNAME=0.0.0.0 APP_VERSION="${APP_VERSION}" nohup node .next/standalone/server.js > server.log 2>&1 & )
fi

# فایروال: باز کردن پورت (اگر ufw فعال است) — با دامنه، ۸۰/۴۴۳ برای HTTPS هم باز می‌شود
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${PORT}/tcp" >/dev/null 2>&1 || true
  if [ -n "$DOMAIN" ]; then
    ufw allow 80/tcp >/dev/null 2>&1 || true
    ufw allow 443/tcp >/dev/null 2>&1 || true
    ok "پورت‌های ${PORT} و 80/443 (HTTPS) در فایروال (ufw) باز شدند"
  else
    ok "پورت ${PORT} در فایروال (ufw) باز شد"
  fi
fi

# ================================================================
# ۱۱) بررسی سلامت — انتظار برای پاسخ HTTP
# ================================================================
info "بررسی سلامت سامانه (حداکثر ۶۰ ثانیه)…"
HEALTHY=0
for i in $(seq 1 30); do
  if curl -fs -o /dev/null --max-time 3 "http://127.0.0.1:${PORT}/api/branding" 2>/dev/null; then
    HEALTHY=1; break
  fi
  sleep 2
done
[ "$HEALTHY" -eq 1 ] || fail "سامانه پاسخ نداد — لاگ: journalctl -u ${SERVICE} -n 50"

# ================================================================
# ۱۱.۵) دامنه + HTTPS خودکار (Caddy) — فقط با پرچم --domain
#   پیش‌نیازها: رکورد A دامنه ← آی‌پی عمومی سرور + باز بودن 80/443 از اینترنت
#   گواهی Let's Encrypt به‌طور خودکار صادر و تمدید می‌شود
# ================================================================
if [ -n "$DOMAIN" ]; then
  info "پیکربندی دامنه ${DOMAIN} با Caddy (HTTPS خودکار)…"
  if ! command -v caddy >/dev/null 2>&1; then
    if [ "$PKG" = "apt" ]; then
      apt-get install -y -qq debian-keyring debian-archive-keyring apt-transport-https >/dev/null 2>&1 || true
      curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null || true
      curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.sh' | bash >/dev/null 2>&1 || true
      apt-get install -y -qq caddy >/dev/null 2>&1 || apt-get install -y caddy
    else
      dnf install -y -q 'dnf-command(copr)' >/dev/null 2>&1 || true
      dnf copr enable -y @caddy/caddy >/dev/null 2>&1 || true
      dnf install -y -q caddy || dnf install -y caddy
    fi
  fi
  if command -v caddy >/dev/null 2>&1; then
    mkdir -p /etc/caddy
    cat > /etc/caddy/Caddyfile <<CADDYEOF
# HRMS 1405 — reverse proxy to local service
${DOMAIN} {
    encode zstd gzip
    reverse_proxy 127.0.0.1:${PORT}
}
CADDYEOF
    systemctl enable caddy >/dev/null 2>&1 || true
    systemctl restart caddy >/dev/null 2>&1 || systemctl restart caddy || true
    ok "Caddy فعال شد — سامانه روی ${C}https://${DOMAIN}${N} با گواهی خودکار در دسترس است"
    warn "اگر دامنه هنوز به این سرور اشاره نکرده باشد، صدور گواهی کمی بعد (پس از تنظیم DNS) خودکار انجام می‌شود — لاگ: journalctl -u caddy -f"
  else
    warn "نصب Caddy ناموفق بود — پیکربندی دستی: هر وب‌سروری که به 127.0.0.1:${PORT} پروکسی کند + گواهی SSL"
  fi
fi

# ================================================================
# ۱۱.۶) ذخیره نسخه‌ای از نصب‌کننده (برای «نصب مجدد» آفلاین از فرمان hrms)
# ================================================================
info "ذخیره نسخه‌ای از نصب‌کننده برای نصب مجدد آفلاین…"
if [ -f "$0" ] && grep -q '^__PAYLOAD_B64__$' "$0" 2>/dev/null; then
  mkdir -p "${APP_DIR}/installer"
  cp -f "$0" "${APP_DIR}/installer/install-hrms-v${APP_VERSION}.sh"
  chmod 700 "${APP_DIR}/installer/install-hrms-v${APP_VERSION}.sh"
  ok "ذخیره شد: ${APP_DIR}/installer/install-hrms-v${APP_VERSION}.sh (hrms ← نصب مجدد ← منبع محلی)"
else
  warn "فایل نصب‌کننده اصلی در دسترس نیست — نصب مجدد آفلاین در دسترس نخواهد بود (از گیت‌هاب امکان‌پذیر است)"
fi

# ================================================================
# ۱۱.۷) فرمان مدیریتی hrms — رابط TUI بازطراحی‌شده (v2.6.0)
#   پس از نصب، کاربر در خط فرمان تایپ می‌کند:  hrms  (یا  HRMS)
#   ناوبری: کلیدهای جهت‌دار ↑↓ + Enter + اعداد سریع (در ترمینال غیرتعاملی: ورودی عددی)
#   کارت وضعیت زنده در بالای منو: نسخه/سرویس/پورت/دیتابیس/به‌روز بودن
#   میان‌برها: update purge backup start stop restart log status versions reinstall remove help
#   پرچم‌ها: --yes --latest --full --clean --self --all --fast --fresh --raw
#   کش نسخه‌های گیت‌هاب (۱۰ دقیقه) + اسپینر عملیات شبکه + خروجی UI به /dev/tty
#   نوشتن اتمیک (فایل موقت + mv) تا جایگزینی حین اجرای خودِ فرمان امن باشد
# ================================================================
info "نصب فرمان مدیریتی hrms…"
CLI_TMP="/usr/local/bin/.hrms-cli.tmp.$$"
cat > "$CLI_TMP" <<'HRMS_CLI_EOF'
#!/usr/bin/env bash
# ================================================================
#  hrms — فرمان مدیریتی سامانه جامع منابع انسانی ۱۴۰۵ (نسخه ۲)
#  بازطراحی کامل: ناوبری با کلیدهای جهت‌دار، کارت وضعیت زنده در منو،
#  پشتیبان‌گیری سریع، مدیریت سرویس و مشاهده لاگ — همه از خط فرمان
#  ساخته‌شده توسط install-hrms.sh — با هر نصب/به‌روزرسانی بازنویسی می‌شود
#  استفاده:
#    hrms                      منوی تعاملی (↑↓ + Enter + اعداد سریع)
#    hrms update [نسخه|-l]     آپدیت از گیت‌هاب     |  hrms status [--fast]
#    hrms backup [مسیر]        پشتیبان دیتابیس      |  hrms versions [--raw]
#    hrms start|stop|restart   مدیریت سرویس        |  hrms log [خطوط]
#    hrms purge / reinstall / remove / help
# ================================================================
APP_DIR="__APP_DIR__"
PORT="__PORT__"
SERVICE="hrms"
INSTALLED_VERSION="__APP_VERSION__"
GITHUB_REPO="amir2323h/HRMS"
GITHUB_BRANCH="main"
HRMS_ARGS=("$@")

# ---------- رنگ‌ها ----------
UI_TTY=""
if [ -c /dev/tty ] && ( : >/dev/tty ) 2>/dev/null; then UI_TTY=/dev/tty; fi
if command -v tput >/dev/null 2>&1 && [ "${TERM:-dumb}" != "dumb" ] && { [ -t 1 ] || [ -t 2 ] || [ -n "$UI_TTY" ]; }; then
  B=$(tput bold); R=$(tput setaf 1); G=$(tput setaf 2); Y=$(tput setaf 3); C=$(tput setaf 6); M=$(tput setaf 5); N=$(tput sgr0)
else
  B=""; R=""; G=""; Y=""; C=""; M=""; N=""
fi
D="$(tput dim 2>/dev/null || true)"
[ -n "$D" ] || D=""

# LRM (نویسه نامرئی چپ‌به‌راست) در ابتدای هر سطر رابط → پاراگراف LTR پایدار:
# پرانتزها آینه نمی‌شوند، جای نسخه‌ها/نشانی‌های لاتین ثابت می‌ماند و چیدمان
# در همه ترمینال‌ها (با/بدون پشتیبانی bidi) یکسان رندر می‌شود.
LRM="$(printf '\342\200\216')"

# سطرهای «رابط» به ترمینال واقعی می‌روند (نه stdout قابل‌کپچر) —
# stdout فقط برای «داده» است (نسخه انتخابی، فهرست خام) تا اسکریپت‌ها تمیز بمانند
# و پیشرفت عملیات حین $() از دید کاربر پنهان نشود.
ui()  { if [ -n "$UI_TTY" ]; then printf '%s%s\n' "$LRM" "$*" >"$UI_TTY"; else printf '%s%s\n' "$LRM" "$*" >&2; fi; }
uie() { if [ -n "$UI_TTY" ]; then printf '%b' "$1" >"$UI_TTY"; else printf '%b' "$1" >&2; fi; }
outln() { printf '%s%s\n' "$LRM" "$*"; }
info()    { ui "${C}◈${N} $*"; }
ok()      { ui "${G}✓${N} $*"; }
warn()    { ui "${Y}⚠${N} $*"; }
fail()    { ui "${R}✗${N} $*"; }
section() { ui ""; ui "${B}${C}── $1${N}"; }

trap 'printf "\e[?25h" >/dev/null 2>&1; stty sane 2>/dev/null; echo ""; info "خروج"; exit 130' INT TERM
trap 'printf "\e[?25h" >/dev/null 2>&1' EXIT

confirm() {
  [ "${ASSUME_YES:-0}" = "1" ] && return 0
  local ans
  while :; do
    read -r -p "$(printf '%s' "${LRM}${Y}؟${N} ${B}$1${N} ${D}[بله/خیر]${N}: ")" ans || return 1
    case "$ans" in
      بله|y|Y|yes|YES) return 0 ;;
      خیر|n|N|no|NO)  return 1 ;;
      *) ui "پاسخ را با «بله» یا «خیر» وارد کنید" ;;
    esac
  done
}

menu_pause() {
  tty_ok || return 0
  local _p
  read -r -p "$(printf '%s' "${LRM}${D}  ↵ برای بازگشت به منو…${N}")" _p 2>/dev/null || true
}

ensure_root() {
  if [ "$(id -u)" -ne 0 ]; then
    if command -v sudo >/dev/null 2>&1; then
      info "این عملیات نیاز به دسترسی ریشه دارد — اجرای مجدد با sudo…"
      exec sudo bash "$0" "${HRMS_ARGS[@]}"
    fi
    fail "این عملیات باید با ریشه اجرا شود: sudo hrms $1"
    exit 1
  fi
}

systemd_ok() {
  command -v systemctl >/dev/null 2>&1 && { [ -d /run/systemd/system ] || systemctl is-system-running >/dev/null 2>&1; }
}

svc_is_active() {
  if systemd_ok; then systemctl is-active --quiet "$SERVICE" 2>/dev/null
  else pgrep -f "${APP_DIR}/.next/standalone/server.js" >/dev/null 2>&1
  fi
}

# ---------- ابزار ارقام فارسی ----------
FA=(۰ ۱ ۲ ۳ ۴ ۵ ۶ ۷ ۸ ۹)
fa_ver() {
  local s="$1"
  s="${s//0/۰}"; s="${s//1/۱}"; s="${s//2/۲}"; s="${s//3/۳}"; s="${s//4/۴}"
  s="${s//5/۵}"; s="${s//6/۶}"; s="${s//7/۷}"; s="${s//8/۸}"; s="${s//9/۹}"
  printf '%s' "$s"
}
fa2en() {
  local s="$1"
  s="${s//۰/0}"; s="${s//۱/1}"; s="${s//۲/2}"; s="${s//۳/3}"; s="${s//۴/4}"
  s="${s//۵/5}"; s="${s//۶/6}"; s="${s//۷/7}"; s="${s//۸/8}"; s="${s//۹/9}"
  printf '%s' "$s"
}

db_file() { printf '%s\n' "${APP_DIR}/db/custom.db"; }

# اگر پورت در .env نصب تغییر کرده باشد، همان به‌کار رود
if [ -f "${APP_DIR}/.env" ]; then
  _P="$(grep -E '^PORT=' "${APP_DIR}/.env" 2>/dev/null | head -n 1 | cut -d= -f2-)"
  [ -n "$_P" ] && PORT="$_P"
  unset _P
fi

# ---------- ناوبری تعاملی (کلیدهای جهت‌دار) ----------
# نکته: stdout داخل $() (جایگزینی فرمان) همیشه pipe است — پس معیار «تعاملی»
# باید stdin (منبع کلیدها) و امکان ترسیم روی ترمینال باشد، نه stdout
tty_ok() { [ -t 0 ] && { [ -n "$UI_TTY" ] || [ -t 2 ]; } && [ "${TERM:-dumb}" != "dumb" ] && command -v tput >/dev/null 2>&1; }

read_key() {  # نماد کلید را در stdout چاپ می‌کند؛ خروج ناموفق = پایان ورودی
  local k s c
  IFS= read -rsn1 k || return 1
  if [ -z "$k" ]; then printf 'ENTER\n'; return 0; fi
  if [ "$k" = $'\x1b' ]; then
    if IFS= read -rsn1 -t 0.05 s; then
      if [ "$s" = "[" ] || [ "$s" = "O" ]; then
        if IFS= read -rsn1 -t 0.05 c; then
          case "$c" in
            A) printf 'UP\n' ;;     B) printf 'DOWN\n' ;;
            C) printf 'RIGHT\n' ;; D) printf 'LEFT\n' ;;
            H) printf 'HOME\n' ;;   F) printf 'END\n' ;;
            *) printf 'ESC\n' ;;
          esac
          return 0
        fi
      fi
      printf 'ESC\n'; return 0
    fi
    printf 'ESC\n'; return 0
  fi
  printf '%s\n' "$k"
}

CHOOSE_HINTS=""
choose() {  # $1=عنوان  $2=زیرعنوان  بقیه=گزینه‌ها → stdout: شماره گزینه (۱..n)؛ rc=1 = انصراف
  local title="$1" sub="$2"; shift 2
  local -a opts=("$@")
  local n=${#opts[@]} sel=0 i key d
  [ "$n" -gt 0 ] || return 1
  local -a hints=()
  if [ -n "${CHOOSE_HINTS:-}" ]; then IFS='|' read -r -a hints <<<"$CHOOSE_HINTS"; fi

  if ! tty_ok; then
    ui "${B}${C}${title}${N}"
    for i in "${!opts[@]}"; do ui "   ${FA[$(( (i + 1) % 10 ))]}  ${opts[$i]}"; done
    ui "${D}شماره گزینه را وارد کنید (خالی یا q = انصراف)${N}"
    local ans
    while :; do
      read -r -p "$(printf '%s' "${LRM}${Y}❯${N} انتخاب: ")" ans || return 1
      ans="$(printf '%s' "$ans" | tr -d '[:space:]')"
      case "$ans" in ''|q|Q) return 1 ;; esac
      ans="$(fa2en "$ans")"
      if [ "$ans" = "0" ]; then return 1; fi
      if [[ "$ans" =~ ^[0-9]+$ ]] && [ "$ans" -ge 1 ] && [ "$ans" -le "$n" ]; then
        printf '%s\n' "$ans"
        return 0
      fi
      warn "ورودی نامعتبر — عددی بین ۱ تا ${n} وارد کنید"
    done
  fi

  uie '\e[?25l'
  ui "${B}${C}${title}${N}"
  [ -n "$sub" ] && ui "${D}${sub}${N}"
  local drawn=0
  _ch_cancel() { uie '\e[?25h'; ui "${D}انصراف${N}"; }
  _ch_draw() {
    local i
    if [ "$drawn" -gt 0 ]; then uie "\e[$((n + 1))A"; fi
    for i in "${!opts[@]}"; do
      uie '\r\e[K'
      if [ "$i" -eq "$sel" ]; then
        ui " ${Y}${B}❯${N}  ${B}${FA[$(( (i + 1) % 10 ))]}${N}  ${B}${opts[$i]}${N}"
      else
        ui " ${D}·${N}  ${FA[$(( (i + 1) % 10 ))]}  ${opts[$i]}"
      fi
    done
    uie '\r\e[K'
    if [ "${#hints[@]}" -gt 0 ] && [ -n "${hints[$sel]:-}" ]; then
      ui "  ${D}${hints[$sel]}${N}"
    else
      ui "  ${D}↑↓ حرکت · Enter انتخاب · اعداد = انتخاب سریع · q انصراف${N}"
    fi
    drawn=$((n + 1))
  }
  _ch_draw
  uie '\n'
  while :; do
    key="$(read_key)" || { _ch_cancel; return 1; }
    case "$key" in
      UP|k|K|LEFT|h)              sel=$(( (sel - 1 + n) % n )); _ch_draw ;;
      DOWN|j|J|RIGHT|l|L|$'\t')   sel=$(( (sel + 1) % n )); _ch_draw ;;
      HOME|g)                     sel=0; _ch_draw ;;
      END|G)                      sel=$((n - 1)); _ch_draw ;;
      ENTER|' ')                  break ;;
      q|Q|ESC)                    _ch_cancel; return 1 ;;
      *)
        d="$(fa2en "$key")"
        if [[ "$d" =~ ^[0-9]+$ ]] && [ "$d" -ge 1 ] && [ "$d" -le "$n" ]; then
          sel=$((d - 1)); break
        elif [ "$d" = "0" ]; then
          _ch_cancel; return 1
        fi ;;
    esac
  done
  uie '\e[?25h'
  printf '%s\n' $((sel + 1))
  return 0
}

# ---------- اسپینر (در حین عملیات شبکه) ----------
spin_run() {  # $1=پیام، بقیه=دستور — خروجی دستور دست‌نخورده می‌ماند
  local msg="$1"; shift
  if [ -n "$UI_TTY" ] && [ -z "${HRMS_NO_SPIN:-}" ] && [ -t 0 ]; then
    local -a fr=( '⠋' '⠙' '⠹' '⠸' '⠼' '⠴' '⠦' '⠧' '⠇' '⠏' )
    local i=0
    ( while :; do
        printf '\r%s%s %s   ' "$LRM" "${fr[$((i % 10))]}" "$msg" >"$UI_TTY" 2>/dev/null || exit
        i=$((i + 1)); sleep 0.1
      done ) &
    local sp=$!
    "$@"
    local rc=$?
    kill "$sp" 2>/dev/null
    wait "$sp" 2>/dev/null
    printf '\r\e[K' >"$UI_TTY" 2>/dev/null
    return "$rc"
  fi
  "$@"
}

# ---------- فهرست نسخه‌ها از گیت‌هاب (با کش) ----------
VER_CACHE="/var/tmp/hrms-versions.cache"
VER_TTL=600
fetch_versions() {  # $1: '' = کش تازه یا واکشی | fresh = همیشه واکشی | only = فقط کش (بدون شبکه)
  local mode="${1:-}" tmp
  if [ "$mode" != "fresh" ] && [ -f "$VER_CACHE" ]; then
    local mtime now
    mtime="$(stat -c %Y "$VER_CACHE" 2>/dev/null || echo -1)"
    now="$(date +%s)"
    if [ "$mode" = "only" ] || { [ "$mtime" -gt 0 ] && [ $((now - mtime)) -lt "$VER_TTL" ]; }; then
      cat "$VER_CACHE"
      return 0
    fi
  fi
  [ "$mode" = "only" ] && return 0
  tmp="$(mktemp)"
  spin_run "دریافت فهرست نسخه‌ها از گیت‌هاب…" _fetch_all "$tmp" || true
  if [ -s "$tmp" ]; then
    { cat "$tmp" > "${VER_CACHE}.w.$$" 2>/dev/null && mv -f "${VER_CACHE}.w.$$" "$VER_CACHE"; } 2>/dev/null || true
    rm -f "${VER_CACHE}.w.$$" 2>/dev/null
    cat "$tmp"
  elif [ -f "$VER_CACHE" ]; then
    cat "$VER_CACHE"
  fi
  rm -f "$tmp"
}
_fetch_all() {  # $1=فایل خروجی — سه روش پشت‌سرهم (اولین موفق برنده)
  local tmp="$1" page
  page="$(curl -fsSL --max-time 25 "https://github.com/${GITHUB_REPO}" 2>/dev/null || true)"
  if [ -n "$page" ]; then
    printf '%s\n' "$page" | grep -oE 'hrms-1405-v[0-9]+(\.[0-9]+)*-project\.zip' \
      | sort -uV | sed -E 's/^hrms-1405-v([0-9.]+)-project\.zip$/\1/' > "$tmp"
  fi
  if [ ! -s "$tmp" ]; then
    curl -fsSL --max-time 20 "https://api.github.com/repos/${GITHUB_REPO}/contents" 2>/dev/null \
      | grep -oE '"name":[[:space:]]*"hrms-1405-v[0-9]+(\.[0-9]+)*-project\.zip"' \
      | sed -E 's/.*hrms-1405-v([0-9.]+)-project\.zip.*/\1/' | sort -uV > "$tmp" || true
  fi
  if [ ! -s "$tmp" ]; then
    curl -fsSL --max-time 20 "https://github.com/${GITHUB_REPO}/releases.atom" 2>/dev/null \
      | grep -oE '<title>v?[0-9]+(\.[0-9]+)*</title>' \
      | sed -E 's/<title>v?([0-9.]+)<\/title>/\1/' | sort -uV > "$tmp" || true
  fi
  [ -s "$tmp" ]
}

pick_version() {  # stdout: نسخه انتخابی (خالی = انصراف)
  local vers v i pick
  vers="$(fetch_versions fresh)"
  if [ -z "$(printf '%s' "$vers" | tr -d '[:space:]')" ]; then
    warn "دریافت فهرست از گیت‌هاب ناموفق بود (شبکه/آفلاین؟)"
    local sel
    read -r -p "$(printf '%s' "${LRM}شماره نسخه را دستی وارد کنید (مثلاً 2.6.0 — خالی = انصراف): ")" sel || true
    printf '%s' "$(printf '%s' "${sel:-}" | tr -d '[:space:]')"
    return 0
  fi
  local -a arr=() labels=()
  while IFS= read -r v; do [ -n "$v" ] && arr=("$v" "${arr[@]}"); done <<<"$vers"
  for i in "${!arr[@]}"; do
    v="${arr[$i]}"
    local tag=""
    [ "$i" -eq 0 ] && tag="جدیدترین"
    [ "$v" = "$INSTALLED_VERSION" ] && tag="${tag:+${tag} · }نصب‌شده (فعلی)"
    labels+=("v${v}${tag:+  —  ${tag}}")
  done
  CHOOSE_HINTS="Enter = نصب نسخه هایلایت‌شده (جدیدترین) · اعداد = انتخاب سریع · q = انصراف"
  pick="$(choose "انتخاب نسخه برای نصب" "" "${labels[@]}")" || return 0
  printf '%s\n' "${arr[$((pick - 1))]}"
}

cleanup_upd() {  # حذف امن پوشه موقت آپدیت (فقط مسیرهای mktemp خودمان)
  case "$1" in /tmp/hrms-upd-*) rm -rf "$1" ;; esac
}
build_installer() {  # $1=نسخه → چاپ مسیر نصب‌کننده ساخته‌شده (خطا = خروج 1)
  local ver="$1" tmpd zip url out probe
  tmpd="$(mktemp -d /tmp/hrms-upd-XXXXXX)"
  zip="${tmpd}/hrms.zip"
  out="${tmpd}/install-hrms-v${ver}.sh"
  url="https://raw.githubusercontent.com/${GITHUB_REPO}/${GITHUB_BRANCH}/hrms-1405-v${ver}-project.zip"
  info "دانلود بسته نسخه ${ver} از گیت‌هاب…"
  if ! spin_run "دانلود بسته نسخه ${ver}…" curl -fsSL --max-time 300 -o "$zip" "$url"; then
    url="https://github.com/${GITHUB_REPO}/raw/${GITHUB_BRANCH}/hrms-1405-v${ver}-project.zip"
    curl -fSL --max-time 300 -o "$zip" "$url" || { rm -rf "$tmpd"; fail "دانلود نسخه ${ver} از گیت‌هاب ناموفق بود"; return 1; }
  fi
  [ -s "$zip" ] || { rm -rf "$tmpd"; fail "فایل دانلودشده خالی است"; return 1; }
  info "استخراج بسته…"
  mkdir -p "${tmpd}/x"
  if command -v unzip >/dev/null 2>&1; then
    unzip -q "$zip" -d "${tmpd}/x"
  elif command -v python3 >/dev/null 2>&1; then
    python3 -m zipfile -e "$zip" "${tmpd}/x"
  else
    apt-get install -y -qq unzip >/dev/null 2>&1 && unzip -q "$zip" -d "${tmpd}/x" \
      || { rm -rf "$tmpd"; fail "ابزار استخراج زیپ در دسترس نیست (unzip/python3)"; return 1; }
  fi
  [ -f "${tmpd}/x/scripts/installer-template.sh" ] \
    || { rm -rf "$tmpd"; fail "قالب نصب‌کننده در بسته نسخه ${ver} یافت نشد"; return 1; }
  info "ساخت نصب‌کننده تک‌فایل…"
  (
    cd "${tmpd}/x" || exit 1
    items=(./src ./public ./prisma)
    for f in scripts/backfill-*.ts scripts/purge-demo.ts; do [ -f "$f" ] && items+=("./$f"); done
    for f in package.json package-lock.json bun.lock next.config.ts tsconfig.json tailwind.config.ts postcss.config.mjs components.json next-env.d.ts; do
      [ -f "$f" ] && items+=("./$f")
    done
    {
      sed "s|^APP_VERSION=\".*\"|APP_VERSION=\"${ver}\"|; s|^APP_VERSION_FA=\".*\"|APP_VERSION_FA=\"$(fa_ver "${ver}")\"|" scripts/installer-template.sh
      echo ""
      echo "# ================== پی‌لود بسته (سورس، base64) =================="
      echo "# این بخش توسط اسکریپت استخراج می‌شود — دستکاری نکنید"
      echo "__PAYLOAD_B64__"
      tar -czf "${tmpd}/p.tgz" "${items[@]}" && base64 -w 76 "${tmpd}/p.tgz" && rm -f "${tmpd}/p.tgz"
    } > "${out}"
  )
  rm -f "${tmpd}/hrms.zip"
  chmod +x "${out}"
  # راستی‌آزمایی: مارکر + سینتکس + استخراج پی‌لود
  grep -q '^__PAYLOAD_B64__$' "${out}" || { rm -rf "$tmpd"; fail "ساخت نصب‌کننده ناموفق بود (مارکر پی‌لود)"; return 1; }
  bash -n "${out}" || { rm -rf "$tmpd"; fail "نصب‌کننده ساخته‌شده خطای سینتکس دارد"; return 1; }
  probe="$(mktemp -d)"
  awk 'f{print} /^__PAYLOAD_B64__$/{f=1}' "${out}" | base64 -d | tar -xzf - -C "$probe" 2>/dev/null
  if [ ! -f "${probe}/package.json" ] || [ ! -f "${probe}/prisma/schema.prisma" ]; then
    rm -rf "$probe" "$tmpd"; fail "راستی‌آزمایی پی‌لود نصب‌کننده ناموفق بود"; return 1
  fi
  rm -rf "$probe"
  printf '%s\n' "${out}"
}

# ---------- عملیات‌ها ----------
do_update() {
  local ver="${1:-}" inst rc latest_inst bk
  ensure_root update
  section "به‌روزرسانی از گیت‌هاب"
  if [ -n "$ver" ] && ! [[ "$ver" =~ ^[0-9]+(\.[0-9]+)*$ ]]; then
    warn "شماره نسخه نامعتبر: ${ver}"
    return 1
  fi
  if [ "$WANT_LATEST" = "1" ]; then
    ver="$(fetch_versions fresh | tail -n 1)"
    if [ -z "$ver" ]; then
      warn "دریافت فهرست نسخه‌ها ناموفق بود — انتخاب دستی:"
    else
      ok "جدیدترین نسخه گیت‌هاب: ${B}${ver}${N}"
    fi
  fi
  [ -n "$ver" ] || ver="$(pick_version)"
  [ -n "$ver" ] || { info "انصراف از به‌روزرسانی"; return 0; }
  latest_inst="$(printf '%s\n' "$ver" "$INSTALLED_VERSION" | sort -V | tail -n 1)"
  if [ "$ver" != "$INSTALLED_VERSION" ] && [ "$latest_inst" = "$INSTALLED_VERSION" ]; then
    warn "نسخه ${ver} قدیمی‌تر از نسخه نصب‌شده (${INSTALLED_VERSION}) است — ممکن است دیتابیس ناسازگار شود"
    confirm "به‌هرحال ادامه می‌دهید؟" || return 0
  elif [ "$ver" = "$INSTALLED_VERSION" ]; then
    info "نسخه انتخابی همان نسخه نصب‌شده است — نصب تعمیری انجام می‌شود (داده‌ها حفظ می‌شوند)"
  fi
  if [ -f "$(db_file)" ]; then
    confirm "پیش از شروع، از دیتابیس پشتیبان گرفته شود؟ (پیشنهاد: بله)" && {
      bk="${HOME}/hrms-backup-$(date +%F-%H%M).db"
      cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
    }
  fi
  inst="$(build_installer "$ver")" || return 1
  warn "عملیات چند دقیقه طول می‌کشد (نصب بسته‌ها + بیلد) — سرویس در پایان خودکار ری‌استارت می‌شود"
  confirm "به‌روزرسانی به نسخه ${ver} شروع شود؟" || { cleanup_upd "$(dirname "$inst")"; info "انصراف"; return 0; }
  bash "$inst"
  rc=$?
  cleanup_upd "$(dirname "$inst")"
  if [ "$rc" -eq 0 ]; then
    ok "به‌روزرسانی کامل شد — فرمان hrms هم به نسخه ${ver} ارتقا یافت"
    info "برای دیدن وضعیت: hrms status"
    exit 0
  else
    fail "به‌روزرسانی با خطا پایان یافت — لاگ: journalctl -u ${SERVICE} -n 50"
    exit "$rc"
  fi
}

do_backup() {
  local dest="${1:-}" rc db use_cp
  db="$(db_file)"
  [ -f "$db" ] || { warn "دیتابیس یافت نشد: ${db} — ابتدا سامانه را نصب کنید"; return 1; }
  [ -z "$dest" ] && dest="${HOME}/hrms-backup-$(date +%F-%H%M).db"
  section "پشتیبان‌گیری از دیتابیس"
  info "مقصد: ${B}${dest}${N}"
  mkdir -p "$(dirname "$dest")" 2>/dev/null || true
  use_cp=0
  case "$dest" in *\'*) use_cp=1 ;; esac
  if [ "$use_cp" = "0" ] && command -v sqlite3 >/dev/null 2>&1; then
    if sqlite3 "$db" ".backup '${dest}'" 2>/dev/null; then
      rc=0
    else
      warn "پشتیبان‌گیری sqlite3 ناموفق بود — کپی خام فایل…"
      cp -f "$db" "$dest" && rc=0 || rc=1
    fi
  else
    cp -f "$db" "$dest" && rc=0 || rc=1
  fi
  if [ "$rc" = "0" ]; then
    ok "پشتیبان ساخته شد — حجم: $(du -h "$dest" 2>/dev/null | cut -f1)"
    ui "${D}بازیابی: sudo systemctl stop ${SERVICE} && sudo cp '${dest}' '${db}' && sudo systemctl start ${SERVICE}${N}"
  else
    fail "پشتیبان‌گیری ناموفق بود"
    return 1
  fi
}

do_purge() {
  ensure_root purge
  section "حذف اطلاعات نمونه"
  [ -d "$APP_DIR" ] || { fail "پوشه نصب یافت نشد: ${APP_DIR}"; exit 1; }
  [ -f "$(db_file)" ] || { fail "دیتابیس یافت نشد: $(db_file)"; exit 1; }
  [ -f "${APP_DIR}/scripts/purge-demo.ts" ] || { fail "اسکریپت purge-demo.ts در نصب موجود نیست — ابتدا آپدیت کنید (hrms update)"; exit 1; }
  local mode fl rc bk db_url
  if [ "$PURGE_FULL" = "1" ]; then
    mode=2
  else
    CHOOSE_HINTS="تنظیمات و کاربران می‌مانند|فقط تنظیمات/نقش‌ها/مدیر admin باقی می‌ماند|خروج بدون تغییر"
    mode="$(choose "حالت پاک‌سازی" "" \
      "حذف داده تراکنشی نمونه — کارکنان/فیش/نامه/درخواست/حضور و غیاب" \
      "حذف کامل (--full) — همه داده‌ها جز تنظیمات/نقش‌ها/مدیر admin" \
      "انصراف")" || { info "انصراف"; return 0; }
  fi
  [ "$mode" = "3" ] && { info "انصراف"; return 0; }
  fl=""; [ "$mode" = "2" ] && fl="--full"
  confirm "از دیتابیس پشتیبان گرفته شود؟ (پیشنهاد: بله)" && {
    bk="${HOME}/hrms-backup-$(date +%F-%H%M).db"
    cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
  }
  confirm "حذف قطعی انجام شود؟ (بازگشت فقط با بازیابی پشتیبان)" || { info "انصراف"; return 0; }
  db_url="file:${APP_DIR}/db/custom.db"
  info "اجرای پاک‌سازی…"
  (
    cd "$APP_DIR" || exit 1
    if command -v bun >/dev/null 2>&1; then
      DATABASE_URL="$db_url" bun scripts/purge-demo.ts $fl
    else
      DATABASE_URL="$db_url" npx --yes tsx scripts/purge-demo.ts $fl
    fi
  )
  rc=$?
  if [ "$rc" -eq 0 ]; then
    svc_op restart
    ok "پاک‌سازی کامل شد"
  else
    fail "پاک‌سازی با خطا مواجه شد (کد ${rc})"
  fi
}

do_reinstall() {
  ensure_root reinstall
  section "نصب مجدد"
  local mode inst src ver rc bk
  if [ "$RE_CLEAN" = "1" ]; then
    mode=2
  else
    CHOOSE_HINTS="بازسازی سورس/بیلد بدون دست‌زدن به داده‌ها|پشتیبان + حذف دیتابیس + داده پایه|خروج بدون تغییر"
    mode="$(choose "حالت نصب مجدد" "" \
      "تعمیر — نصب مجدد با حفظ داده‌ها و کاربران" \
      "نصب تمیز — از صفر (پشتیبان + حذف دیتابیس + داده پایه)" \
      "انصراف")" || { info "انصراف"; return 0; }
  fi
  [ "$mode" = "3" ] && { info "انصراف"; return 0; }
  CHOOSE_HINTS="بدون نیاز به اینترنت|فهرست نسخه‌های گیت‌هاب|فایل نصب‌کننده دانلودشده/منتقل‌شده"
  src="$(choose "منبع نصب‌کننده" "" \
    "نسخه ذخیره‌شده محلی (${INSTALLED_VERSION})" \
    "دانلود از گیت‌هاب — انتخاب نسخه" \
    "مسیر فایل نصب‌کننده روی دیسک" \
    "انصراف")" || { info "انصراف"; return 0; }
  case "$src" in
    1)
      inst="$(ls -1v "${APP_DIR}"/installer/install-hrms-*.sh 2>/dev/null | tail -n 1)"
      if [ -z "$inst" ] || [ ! -f "$inst" ]; then
        warn "نسخه ذخیره‌شده‌ای یافت نشد (${APP_DIR}/installer/) — از گزینه‌های دیگر استفاده کنید"
        return 0
      fi
      ok "نصب‌کننده محلی: ${inst}" ;;
    2)
      ver="$(pick_version)"
      [ -n "$ver" ] || { info "انصراف"; return 0; }
      inst="$(build_installer "$ver")" || return 1 ;;
    3)
      read -r -p "$(printf '%s' "${LRM}مسیر فایل نصب‌کننده: ")" inst || return 0
      [ -f "$inst" ] || { fail "فایل یافت نشد: ${inst}"; return 1; } ;;
    4) info "انصراف"; return 0 ;;
  esac
  if [ "$mode" = "2" ]; then
    warn "دیتابیس حذف می‌شود: کارکنان/فیش‌ها/نامه‌ها/تنظیمات واردشده از بین می‌روند"
    if [ -f "$(db_file)" ]; then
      confirm "از دیتابیس فعلی پشتیبان گرفته شود؟ (پیشنهاد: بله)" && {
        bk="${HOME}/hrms-backup-$(date +%F-%H%M).db"
        cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
      }
    fi
    confirm "نصب تمیز شروع شود؟" || { [ "$src" = "2" ] && cleanup_upd "$(dirname "$inst")"; info "انصراف"; return 0; }
    rm -f "${APP_DIR}/db/custom.db" "${APP_DIR}/db/custom.db-wal" "${APP_DIR}/db/custom.db-shm"
  else
    confirm "نصب مجدد (حفظ داده‌ها) شروع شود؟" || { [ "$src" = "2" ] && cleanup_upd "$(dirname "$inst")"; info "انصراف"; return 0; }
  fi
  systemd_ok || pkill -f "${APP_DIR}/.next/standalone/server.js" >/dev/null 2>&1 || true
  warn "این عملیات چند دقیقه طول می‌کشد (نصب بسته‌ها + بیلد)"
  bash "$inst"
  rc=$?
  [ "$src" = "2" ] && cleanup_upd "$(dirname "$inst")"
  if [ "$rc" -eq 0 ]; then
    ok "نصب مجدد کامل شد"
    exit 0
  else
    fail "نصب مجدد با خطا پایان یافت"
    exit "$rc"
  fi
}

do_remove() {
  ensure_root remove
  section "حذف اسکریپت / حذف کامل"
  local mode bk
  if [ "$RM_SELF" = "1" ]; then
    mode=1
  elif [ "$RM_ALL" = "1" ]; then
    mode=2
  else
    CHOOSE_HINTS="سامانه و داده‌ها دست‌نخورده می‌مانند|پشتیبان نهایی + حذف سرویس و پوشه نصب|خروج بدون تغییر"
    mode="$(choose "دامنه حذف" "" \
      "فقط فرمان مدیریتی hrms حذف شود" \
      "حذف کامل — فرمان + سرویس + پوشه نصب (ابتدا پشتیبان)" \
      "انصراف")" || { info "انصراف"; return 0; }
  fi
  case "$mode" in
    1)
      confirm "فرمان hrms (و HRMS) از /usr/local/bin حذف شود؟" || { info "انصراف"; return 0; }
      rm -f /usr/local/bin/hrms /usr/local/bin/HRMS
      ok "فرمان hrms حذف شد — سامانه همچنان فعال است"
      info "هر نصب‌کننده جدید دوباره این فرمان را می‌سازد"
      exit 0 ;;
    2)
      confirm "ابتدا از دیتابیس پشتیبان گرفته شود؟ (پیشنهاد قوی: بله)" && {
        if [ -f "$(db_file)" ]; then
          bk="${HOME}/hrms-backup-final-$(date +%F-%H%M).db"
          cp "$(db_file)" "$bk" && ok "پشتیبان: ${bk}"
        fi
      }
      confirm "حذف کامل و غیرقابل بازگشت: سرویس ${SERVICE} + پوشه ${APP_DIR}؟" || { info "انصراف"; return 0; }
      if systemd_ok; then
        systemctl disable --now "$SERVICE" >/dev/null 2>&1 || true
      fi
      pkill -f "${APP_DIR}/.next/standalone/server.js" >/dev/null 2>&1 || true
      rm -f "/etc/systemd/system/${SERVICE}.service"
      { systemd_ok && systemctl daemon-reload >/dev/null 2>&1; } || true
      rm -rf "$APP_DIR"
      rm -f /usr/local/bin/hrms /usr/local/bin/HRMS
      ok "حذف کامل انجام شد"
      info "برای نصب مجدد: فرمان یک‌خطی گیت‌هاب از README یا فایل install-hrms-*.sh"
      exit 0 ;;
    *) info "انصراف" ;;
  esac
}

do_status() {
  section "وضعیت سامانه"
  outln "  نسخه نصب‌شده:   ${B}${INSTALLED_VERSION}${N}"
  outln "  مسیر نصب:       ${APP_DIR}"
  outln "  پورت:           $(fa_ver "$PORT")"
  local ip; ip="$(hostname -I 2>/dev/null | awk '{print $1}')"; [ -n "$ip" ] || ip="SERVER-IP"
  outln "  نشانی:          ${C}http://${ip}:${PORT}${N}"
  local db; db="$(db_file)"
  if [ -f "$db" ]; then
    outln "  دیتابیس:        $(du -h "$db" 2>/dev/null | cut -f1) — آخرین تغییر: $(date -r "$db" '+%F %H:%M' 2>/dev/null || echo '—')"
  else
    outln "  دیتابیس:        ${Y}یافت نشد${N}"
  fi
  local lastbk; lastbk="$(ls -t "${HOME}"/hrms-backup-*.db 2>/dev/null | head -n 1)"
  if [ -n "$lastbk" ]; then
    outln "  آخرین پشتیبان:  ${lastbk} ($(du -h "$lastbk" 2>/dev/null | cut -f1))"
  fi
  if systemd_ok; then
    if svc_is_active; then
      local since; since="$(systemctl show "$SERVICE" -p ActiveEnterTimestamp --value 2>/dev/null)"
      outln "  سرویس:          ${G}● فعال${N}${since:+ — از ${since}}"
    else
      outln "  سرویس:          ${R}○ متوقف${N} — شروع: hrms start"
    fi
  elif svc_is_active; then
    outln "  سرویس:          ${G}● فعال${N} ${D}(فرایند بدون systemd)${N}"
  else
    outln "  سرویس:          ${R}○ متوقف${N} — شروع: hrms start"
  fi
  local t code latency ms
  t="$(curl -s -o /dev/null -w '%{http_code} %{time_total}' --max-time 5 "http://127.0.0.1:${PORT}/api/branding" 2>/dev/null || true)"
  code="${t%% *}"; latency="${t##* }"
  if [ -n "$code" ] && [ "$code" != "000" ]; then
    ms="$(printf '%s' "$latency" | awk '{printf "%.0f", $1 * 1000}' 2>/dev/null)"
    outln "  سلامت HTTP:     ${G}✓${N} پاسخ ${code} در $(fa_ver "${ms:-?}") میلی‌ثانیه"
  else
    outln "  سلامت HTTP:     ${Y}⚠${N} پاسخی روی پورت $(fa_ver "$PORT") دریافت نشد"
  fi
  if [ "$FAST" != "1" ]; then
    local latest
    latest="$(fetch_versions "" | tail -n 1)"
    if [ -n "$latest" ]; then
      if [ "$latest" = "$INSTALLED_VERSION" ]; then
        outln "  نسخه گیت‌هاب:   ${G}✓${N} آخرین نسخه (${latest}) نصب است"
      else
        outln "  نسخه گیت‌هاب:   ${Y}⬆${N} ${B}${latest}${N} منتشر شده — ${C}hrms update${N} برای ارتقا"
      fi
    else
      outln "  نسخه گیت‌هاب:   ${D}دریافت نشد (شبکه؟)${N}"
    fi
  fi
}

do_versions() {
  local mode=""; [ "$FRESH" = "1" ] && mode="fresh"
  local vers v newest tag
  vers="$(fetch_versions "$mode")"
  if [ -z "$(printf '%s' "$vers" | tr -d '[:space:]')" ]; then
    warn "دریافت فهرست نسخه‌ها از گیت‌هاب ناموفق بود (شبکه/آفلاین؟)"
    return 0
  fi
  newest="$(printf '%s\n' "$vers" | sort -V | tail -n 1)"
  if [ "$RAW" = "1" ]; then
    printf '%s\n' "$vers" | sort -rV
    return 0
  fi
  echo ""
  outln "${B}نسخه‌های موجود در گیت‌هاب (جدیدترین در بالا):${N}"
  while IFS= read -r v; do
    [ -n "$v" ] || continue
    tag=""
    [ "$v" = "$newest" ] && tag="${G}جدیدترین${N}"
    [ "$v" = "$INSTALLED_VERSION" ] && tag="${tag:+${tag} · }${C}نصب‌شده${N}"
    if [ "$v" = "$INSTALLED_VERSION" ]; then
      outln "  ${B}${v}${N}${tag:+   ${tag}}"
    else
      outln "  ${v}${tag:+   ${tag}}"
    fi
  done <<<"$(printf '%s\n' "$vers" | sort -rV)"
}

# ---------- مدیریت سرویس ----------
svc_start_manual() {
  [ -x "${APP_DIR}/.next/standalone/server.js" ] || { warn "فایل سرویس یافت نشد — ابتدا نصب/نصب مجدد کنید"; return 1; }
  local envf="${APP_DIR}/.env" p="$PORT" sec="" dbu="file:${APP_DIR}/db/custom.db" d
  if [ -f "$envf" ]; then
    d="$(grep -E '^PORT=' "$envf" 2>/dev/null | head -n 1 | cut -d= -f2-)"; [ -n "$d" ] && p="$d"
    sec="$(grep -E '^AUTH_SECRET=' "$envf" 2>/dev/null | head -n 1 | cut -d= -f2-)"
    d="$(grep -E '^DATABASE_URL=' "$envf" 2>/dev/null | head -n 1 | cut -d= -f2-)"; [ -n "$d" ] && dbu="$d"
  fi
  ( cd "$APP_DIR" && DATABASE_URL="$dbu" AUTH_SECRET="$sec" PORT="$p" HOSTNAME=0.0.0.0 nohup node .next/standalone/server.js >> server.log 2>&1 & )
  ok "فرایند سرویس اجرا شد (بدون systemd) — لاگ: ${APP_DIR}/server.log"
}
svc_stop_manual() {
  if pkill -f "${APP_DIR}/.next/standalone/server.js" >/dev/null 2>&1; then
    ok "فرایند سرویس متوقف شد"
  else
    warn "فرایند سرویس در حال اجرا دیده نشد"
  fi
}
svc_op() {  # $1=start|stop|restart
  local op="$1"
  ensure_root "$op"
  section "عملیات سرویس: ${op}"
  if systemd_ok; then
    case "$op" in
      start)   systemctl start "$SERVICE" && ok "سرویس شروع شد" || warn "شروع ناموفق بود" ;;
      stop)    systemctl stop "$SERVICE" && ok "سرویس متوقف شد" || warn "توقف ناموفق بود" ;;
      restart) systemctl restart "$SERVICE" && ok "سرویس ری‌استارت شد" || warn "ری‌استارت ناموفق بود" ;;
    esac
  else
    case "$op" in
      stop)    svc_stop_manual ;;
      restart) svc_stop_manual; sleep 1; svc_start_manual ;;
      start)   svc_start_manual ;;
    esac
  fi
  sleep 1
  if svc_is_active; then ok "وضعیت فعلی: ${G}● فعال${N}"; else warn "وضعیت فعلی: متوقف"; fi
}
svc_log() {
  local n="${1:-60}"
  [[ "$n" =~ ^[0-9]+$ ]] || n=60
  section "لاگ سرویس — ${n} خط آخر"
  if systemd_ok; then
    journalctl -u "$SERVICE" -n "$n" --no-pager 2>/dev/null || warn "خواندن journalctl ناموفق بود"
  else
    local logf="${APP_DIR}/server.log"
    if [ -f "$logf" ]; then
      tail -n "$n" "$logf"
    else
      warn "فایل لاگ یافت نشد: ${logf}"
    fi
  fi
}
svc_log_live() {
  section "لاگ زنده سرویس (خروج: Ctrl+C)"
  if systemd_ok; then
    trap '' INT
    journalctl -u "$SERVICE" -f --no-pager
    trap 'printf "\e[?25h" >/dev/null 2>&1; stty sane 2>/dev/null; echo ""; info "خروج"; exit 130' INT TERM
  else
    local logf="${APP_DIR}/server.log"
    if [ -f "$logf" ]; then
      trap '' INT
      tail -n 30 -f "$logf"
      trap 'printf "\e[?25h" >/dev/null 2>&1; stty sane 2>/dev/null; echo ""; info "خروج"; exit 130' INT TERM
    else
      warn "فایل لاگ یافت نشد: ${logf}"
    fi
  fi
  ui ""
  info "پایان نمایش لاگ زنده"
}
do_service() {
  while :; do
    local op
    CHOOSE_HINTS="قطعه‌ای از کار نمی‌افتد|در محیط بدون systemd هم کار می‌کند|قطعه‌ای از کار می‌افتد|۶۰ خط آخر لاگ سرویس|پایان با Ctrl+C و بازگشت به همین منو|بازگشت به منوی اصلی"
    op="$(choose "مدیریت سرویس ${SERVICE}" "" \
      "ری‌استارت سرویس" \
      "شروع سرویس" \
      "توقف سرویس" \
      "لاگ‌های اخیر — ۶۰ خط آخر" \
      "لاگ زنده — خروج با Ctrl+C" \
      "بازگشت به منوی اصلی")" || return 0
    case "$op" in
      1) svc_op restart; menu_pause ;;
      2) svc_op start; menu_pause ;;
      3) svc_op stop; menu_pause ;;
      4) svc_log 60; menu_pause ;;
      5) svc_log_live ;;
      6) return 0 ;;
    esac
  done
}

# ---------- کارت وضعیت + منوی اصلی ----------
draw_card() {
  local cols w bar i
  cols="${COLUMNS:-0}"
  [ "$cols" -ge 1 ] 2>/dev/null || cols="$(tput cols 2>/dev/null || echo 0)"
  [ "$cols" -lt 44 ] && cols=44
  w=$((cols - 2)); [ "$w" -gt 58 ] && w=58
  bar=""
  for ((i = 0; i < w - 2; i++)); do bar="${bar}─"; done
  local svc_txt="نامشخص" svc_col="$Y" svc_dot="○"
  if svc_is_active; then svc_txt="فعال"; svc_col="$G"; svc_dot="●"; else svc_txt="متوقف"; svc_col="$R"; svc_dot="○"; fi
  local db_txt="—"
  [ -f "$(db_file)" ] && db_txt="$(du -h "$(db_file)" 2>/dev/null | cut -f1)"
  local ip; ip="$(hostname -I 2>/dev/null | awk '{print $1}')"; [ -n "$ip" ] || ip="SERVER-IP"
  local upd_txt="" latest newest
  latest="$(fetch_versions only | tail -n 1)"
  if [ -n "$latest" ]; then
    if [ "$latest" = "$INSTALLED_VERSION" ]; then
      upd_txt="${G}✓ به‌روز هستید${N}"
    else
      newest="$(printf '%s\n' "$latest" "$INSTALLED_VERSION" | sort -V | tail -n 1)"
      [ "$newest" = "$latest" ] && upd_txt="${Y}⬆ نسخه $(fa_ver "$latest") موجود است — گزینه ۱${N}"
    fi
  fi
  ui ""
  ui "${C}╭${bar}╮${N}"
  ui "  ${B}سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵${N}"
  ui "  ${D}مدیریت استقرار — hrms${N}"
  ui "  ${D}نسخه${N} ${B}$(fa_ver "$INSTALLED_VERSION")${N}    ${svc_col}${svc_dot} ${svc_txt}${N}    ${D}پورت${N} $(fa_ver "$PORT")"
  ui "  ${D}دیتابیس${N} ${db_txt}    ${D}نشانی${N} ${C}http://${ip}:${PORT}${N}"
  if [ -n "$upd_txt" ]; then ui "  ${upd_txt}"; fi
  ui "${C}╰${bar}╯${N}"
}

MENU_ITEMS=(
  "به‌روزرسانی از گیت‌هاب"
  "وضعیت تفصیلی سامانه"
  "مدیریت سرویس — شروع/توقف/ری‌استارت/لاگ"
  "پشتیبان‌گیری از دیتابیس"
  "حذف اطلاعات نمونه"
  "نصب مجدد — تعمیر یا نصب تمیز"
  "حذف اسکریپت / حذف کامل سامانه"
  "خروج"
)
MENU_HINTS="فهرست نسخه‌های گیت‌هاب + نصب امن — داده‌ها و کاربران حفظ می‌شوند|نسخه، سرویس، سلامت HTTP، دیتابیس و آخرین پشتیبان|شروع، توقف، ری‌استارت و مشاهده لاگ‌های سرویس|تهیه نسخه پشتیبان سالم از دیتابیس در پوشه خانه|پاک‌سازی داده تراکنشی یا کامل — با پشتیبان اختیاری|بازسازی سورس و بیلد — تعمیر با حفظ داده یا نصب تمیز از صفر|حذف فقط فرمان hrms یا حذف کامل سامانه از سرور|خروج از منو — سامانه همچنان فعال می‌ماند"

menu() {
  # پیش‌بارگیری پس‌زمینه فهرست نسخه‌ها — منو بی‌درنگ باز می‌شود
  ( HRMS_NO_SPIN=1 fetch_versions fresh >/dev/null 2>&1 ) &
  while :; do
    draw_card
    local ch
    CHOOSE_HINTS="$MENU_HINTS"
    ch="$(choose "منوی مدیریت" "با ↑↓ حرکت کنید، Enter بزنید یا شماره گزینه را فشار دهید" "${MENU_ITEMS[@]}")" || break
    case "$ch" in
      1) do_update ;;
      2) do_status; menu_pause ;;
      3) do_service ;;
      4) do_backup; menu_pause ;;
      5) do_purge; menu_pause ;;
      6) do_reinstall ;;
      7) do_remove ;;
      8) break ;;
    esac
  done
  ui ""
  info "پایان — سرویس سامانه مستقل از این منو فعال می‌ماند"
}

usage() {
  cat <<USAGEEOF
فرمان مدیریتی HRMS 1405 — نسخه ${INSTALLED_VERSION}

استفاده:
  hrms                      منوی تعاملی — کلیدهای ↑↓ + Enter + اعداد سریع

عملیات‌ها:
  hrms update [نسخه]        به‌روزرسانی از گیت‌هاب (بدون آرگومان: انتخاب از فهرست)
  hrms update --latest      آپدیت مستقیم به جدیدترین نسخه
  hrms status [--fast]      وضعیت سرویس/سلامت/نسخه‌ها (--fast = بدون بررسی گیت‌هاب)
  hrms versions [--raw]     فهرست نسخه‌های گیت‌هاب (--raw = فقط اعداد، برای اسکریپت)
  hrms backup [مسیر]        پشتیبان‌گیری فوری از دیتابیس
  hrms start|stop|restart   مدیریت سرویس
  hrms log [خطوط]           لاگ‌های اخیر سرویس (پیش‌فرض ۶۰ خط)
  hrms purge [--full]       حذف اطلاعات نمونه (تراکنشی یا کامل)
  hrms reinstall [--clean]  نصب مجدد (تعمیر با حفظ داده یا نصب تمیز)
  hrms remove [--self|--all]  حذف فرمان hrms یا حذف کامل سامانه

پرچم‌های مشترک:
  --yes    تأیید خودکار پرسش‌ها (اتوماسیون/اسکریپت)
  --latest | --full | --clean | --self | --all | --fast | --fresh | --raw

نمونه‌ها:
  hrms update --latest          آپدیت به جدیدترین نسخه منتشرشده
  hrms update 2.4.0             آپدیت به نسخه مشخص
  hrms backup ~/hrms-db.db      پشتیبان در مسیر دلخواه
  hrms status --fast            وضعیت سریع بدون بررسی شبکه
  hrms log 200                  ۲۰۰ خط آخر لاگ سرویس
USAGEEOF
}

# ---------- پردازش آرگومان‌ها ----------
ASSUME_YES=0 WANT_LATEST=0 PURGE_FULL=0 FAST=0 FRESH=0 RAW=0 RE_CLEAN=0 RM_SELF=0 RM_ALL=0
POS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --yes|-y)    ASSUME_YES=1 ;;
    --latest|-l) WANT_LATEST=1 ;;
    --full)      PURGE_FULL=1 ;;
    --clean)     RE_CLEAN=1 ;;
    --self)      RM_SELF=1 ;;
    --all)       RM_ALL=1 ;;
    --fast)      FAST=1 ;;
    --fresh)     FRESH=1 ;;
    --raw)       RAW=1 ;;
    -h|--help)   usage; exit 0 ;;
    --*)         warn "پرچم ناشناخته: $1"; echo ""; usage; exit 1 ;;
    *)           POS+=("$1") ;;
  esac
  shift
done

CMD="${POS[0]:-}"
case "$CMD" in
  update|up)        do_update "${POS[1]:-}" ;;
  purge|clean)      do_purge ;;
  backup|bk)        do_backup "${POS[1]:-}" ;;
  start)            svc_op start ;;
  stop)             svc_op stop ;;
  restart|reload)   svc_op restart ;;
  log|logs)         svc_log "${POS[1]:-60}" ;;
  status|st)        do_status ;;
  versions|ver)     do_versions ;;
  reinstall|re)     do_reinstall ;;
  remove|uninstall) do_remove ;;
  menu)             menu ;;
  help)             usage ;;
  "")               menu ;;
  *)                warn "گزینه ناشناخته: $CMD"; echo ""; usage; exit 1 ;;
esac
HRMS_CLI_EOF
sed -i "s|__APP_DIR__|${APP_DIR}|g; s|__PORT__|${PORT}|g; s|__APP_VERSION__|${APP_VERSION}|g" "$CLI_TMP"
chmod 755 "$CLI_TMP"
bash -n "$CLI_TMP" || { rm -f "$CLI_TMP"; fail "خطای سینتکس در فرمان مدیریتی hrms"; }
mv -f "$CLI_TMP" /usr/local/bin/hrms
ln -sf hrms /usr/local/bin/HRMS 2>/dev/null || true
ok "فرمان مدیریتی hrms نصب شد — تایپ کنید: ${B}hrms${N} (منوی تعاملی با کلیدهای جهت‌دار و کارت وضعیت زنده)"

# ================================================================
# ۱۲) خلاصه نهایی
# ================================================================
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
[ -n "$IP" ] || IP="آدرس-سرور"
echo -e "${B}${G}"
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    ${N}${B}نصب با موفقیت کامل شد ✓${G}                        ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║  نسخه نصب‌شده:  HRMS 1405 — v${APP_VERSION} (نسخه ${APP_VERSION_FA})"
if [ -n "$DOMAIN" ]; then
  echo "║  نشانی سامانه:   ${C}https://${DOMAIN}${G}  (و http://${IP}:${PORT})"
else
  echo "║  نشانی سامانه:   ${C}http://${IP}:${PORT}${G}"
fi
if [ "$UPDATE_MODE" -eq 1 ]; then
  echo "║  حالت:           به‌روزرسانی نصب موجود — داده‌ها/کاربران/کلید نشست حفظ شد"
fi
echo "║  کاربران نمونه:  admin/admin123  •  hr/hr123  •  emp/emp123  •  edari/edari123 (کارشناس اداری)"
echo "║  داده پرسنلی:    هیچ — از ۲.۱.۰ نصب بدون کارمند/فیش/نامه نمونه است (کارکنان واقعی را خودتان وارد کنید)"
echo "║  جدید ۲.۸.۱:     پشتیبان‌گیری و بازیابی داده‌های پنل — اسنپ‌شات یک‌کلیکی"
echo "║                   بدون توقف سرویس، دانلود/انتقال فایل، بازیابی امن با"
echo "║                   پشتیبان خودکار از وضعیت فعلی + پشتیبان خودکار پیش از به‌روزرسانی"
echo "║  جدید ۲.۸.۰:     تعطیلات رسمی ۱۴۰۵ (۲۶ روز) + شیفت‌های استاندارد (روزکار ۰۸–۱۷،"
echo "║                   صبح ۰۸–۱۶، عصر ۱۶–۲۴) + تعطیلی پنجشنبه/جمعه روزکار +"
echo "║                   ساعت استاندارد دوره با کسر تعطیلات + دریافت تعطیلات از وب‌سرویس"
echo "║  جدید ۲.۷.۳:     رفع شکست بیلد هنگام به‌روزرسانی از پنل — نصب npm همیشه"
echo "║                   شامل بسته‌های توسعه (devDependencies) است؛ اگر بیلد شکست"
echo "║                   بخورد بیلد قبلی خودکار بازگردانی می‌شود (سایت/فونت‌ها سالم می‌مانند)"
echo "║  جدید ۲.۷.۲:     وضعیت نسخه/به‌روزرسانی فقط برای مدیر کل + چاپ و دانلود"
echo "║                   قراردادها با فونت B Nazanin سایز ۱۲ و فاصله سطر ۱.۱۵"
echo "║                   (هدرها بولد — فایل دانلودی فونت را داخل خود دارد)"
echo "║  جدید ۲.۷.۱:     رفع اشکال — بررسی نسخه از گیت‌هاب با سه منبع موازی (API/فید/زیپ مخزن)؛"
echo "║                   حتی با محدودیت نرخ یا نبود release هم نسخه جدید پیدا می‌شود"
echo "║                   نمایش QR فعال‌سازی ورود دو مرحله‌ای + تاریخ شمسی انتشار نسخه"
echo "║  جدید ۲.۷.۰:     تفکیک حقوق هر سطح (پایه/حق مسولیت/شایستگی) — مبنای اضافه‌کاری و"
echo "║                   مأموریت فقط حقوق پایه است؛ فیش سه جزء را جدا نشان می‌دهد"
echo "║                   امضای نامه در کارتابل امضاکننده (انتخاب نفر از فهرست کاربران)"
echo "║                   پاپ‌آپ «تازه‌های نسخه» با هدف‌گیری نقش/کاربر + نسخه در فوتر"
echo "║                   دکمه آپدیت در پنل: چک خودکار نسخه جدید هر ۲ روز از گیت‌هاب +"
echo "║                   ارتقای یک‌کلیکی با لاگ زنده (تنظیمات ← اطلاعیه نسخه / دکمه در نوار بالا)"
echo "║  جدید ۲.۶.۰:     منوی hrms بازطراحی شد — ناوبری با کلیدهای جهت‌دار (↑↓ + Enter)"
echo "║                   کارت وضعیت زنده + پشتیبان‌گیری سریع + مدیریت سرویس/لاگ از خط فرمان"
echo "║  جدید ۲.۵.۰:     فرمان مدیریتی hrms (یا HRMS) — آپدیت از گیت‌هاب + حذف داده"
echo "║                   نمونه + نصب مجدد + حذف اسکریپت، همه از خط فرمان"
echo "║  جدید ۲.۴.۰:     لاگ تغییرات پرونده + بازگردانی یک‌کلیکی + ایمپورت هوشمند"
echo "║  دیتابیس:        ${APP_DIR}/db/custom.db"
echo "║  سورس:           ${APP_DIR}"
echo "╠══════════════════════════════════════════════════════════════╣${N}"
echo "  دستورات مدیریتی:"
echo "    منوی مدیریت:   ${C}hrms${N}  (یا HRMS) — ناوبری با ↑↓ و Enter، وضعیت زنده در منو"
echo "    وضعیت سریع:     hrms status   |   بدون بررسی گیت‌هاب:   hrms status --fast"
echo "    پشتیبان‌گیری:    hrms backup   |   فهرست نسخه‌های گیت‌هاب:   hrms versions"
echo "    مدیریت سرویس:   hrms restart / start / stop / log"
echo "    وضعیت سرویس:   systemctl status ${SERVICE}"
echo "    لاگ زنده:       journalctl -u ${SERVICE} -f"
if [ "$DEMO" -eq 1 ]; then
  echo ""
  echo "  حذف داده تراکنشی (هر زمان که بخواهید شروع تازه کنید):"
  echo "    سریع‌ترین راه:   فرمان hrms ← گزینه ۵ «حذف اطلاعات نمونه»"
  echo "    از سامانه:      تنظیمات ← تب «داده نمونه» ← دکمه حذف"
  echo "    از خط فرمان:    cd ${APP_DIR} && DATABASE_URL='file:${APP_DIR}/db/custom.db' npx --yes tsx scripts/purge-demo.ts"
  echo "    حالت کامل:      همین دستور با پرچم --full (فقط تنظیمات + نقش‌ها + admin باقی می‌ماند)"
fi
echo ""
echo -e "  ${Y}⚠ امنیت:${N} بلافاصله وارد شوید و رمز admin را از «تنظیمات ← کاربران» تغییر دهید."
echo -e "  ${Y}⚠ امنیت:${N} فایل ${APP_DIR}/.env حاوی کلید نشست است — آن را افشا نکنید."
echo ""
[ "$DEMO" -eq 1 ] && echo -e "  ${Y}نکته:${N} از ۲.۱.۰ هیچ داده پرسنلی نمونه‌ای نصب نمی‌شود — کاربران نمونه فقط برای آزمایش دسترسی نقش‌ها هستند. با --no-demo فقط کاربر admin ساخته می‌شود."
echo ""
ok "سامانه جامع منابع انسانی ۱۴۰۵ آماده بهره‌برداری است"
exit 0

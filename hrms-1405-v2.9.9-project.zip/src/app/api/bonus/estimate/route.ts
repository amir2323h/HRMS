import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { getBonusConfig, monthsPresent, TIER_KEYS, tierByKey } from "@/lib/bonus";
import { todayJalaliStr } from "@/lib/jalali";

// ============================================================
// مدل دوم پاداش — برآورد بودجه بر اساس توزیع نفرات در چهار وضعیت
// GET /api/bonus/estimate?referenceDateJ=1405/12/29
//   مبنا: «تعداد بونس» (ماه پاداش) ثبت‌شده هر طبقه در تنظیمات پاداش
//   برای هر کارمند فعال، مبلغ پاداش در هر چهار تیر محاسبه می‌شود؛
//   میانگین/حداقل/حداکثر هر تیر + جمع سناریوی «همه در این وضعیت»
//   برگردانده می‌شود تا کلاینت با تعداد نفرات، بودجه را برآورد کند.
//   فقط خواندنی — چیزی ذخیره نمی‌شود (bonus:view)
// ============================================================

interface TierStat {
  key: string;
  label: string;
  minRatio: number;
  paymentPercent: number;
  extraMonths: number;
  headcount: number; // همه کارکنان فعال (مبنای میانگین)
  avgPerPerson: number; // ریال
  minPerPerson: number;
  maxPerPerson: number;
  totalIfAll: number; // بودجه اگر همه فعال‌ها در این وضعیت بودند (ریال)
}

interface LevelStat {
  level: number; // 0 = بدون طبقه
  title: string;
  headcount: number;
  avgBaseSalary: number; // ریال
  bonusMonths: number; // ماه پاداش ثبت‌شده طبقه
  perTier: Record<string, number>; // میانگین پاداش هر نفر در هر تیر (ریال)
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "bonus:view");

    const year = +todayJalaliStr().slice(0, 4);
    const q = req.nextUrl.searchParams.get("referenceDateJ") || "";
    const referenceDateJ = /^\d{4}\/\d{2}\/\d{2}$/.test(q) ? q : `${year}/12/29`;

    const cfg = await getBonusConfig();
    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      select: { baseSalary: true, jobGradeId: true, hireDateJ: true },
    });
    const grades = await db.jobGrade.findMany();
    const gradeMap = new Map(grades.map((g) => [g.id, { level: g.level, title: g.title }]));

    // مبلغ پاداش یک نفر در تیر مشخص (همان فرمول computeSchemeLines)
    const amountIn = (base: number, level: number, present: number, tierExtra: number, tierPercent: number) => {
      const levelMonths = level >= 1 && level <= 7 ? cfg.levels[String(level)] ?? 0 : 0;
      const months = levelMonths + tierExtra;
      return Math.round(base * months * (present / 12) * (tierPercent / 100));
    };

    // ---------- آمار هر تیر ----------
    const tiers: TierStat[] = TIER_KEYS.map((key) => {
      const t = tierByKey(cfg, key);
      const amounts: number[] = [];
      for (const e of employees) {
        const grade = e.jobGradeId ? gradeMap.get(e.jobGradeId) || null : null;
        const level = grade?.level || 0;
        const present = monthsPresent(e.hireDateJ || "", referenceDateJ);
        const base = Number(e.baseSalary || BigInt(0));
        amounts.push(amountIn(base, level, present, t.extraMonths || 0, t.paymentPercent || 0));
      }
      const headcount = amounts.length;
      const sum = amounts.reduce((s, v) => s + v, 0);
      return {
        key: t.key,
        label: t.label,
        minRatio: t.minRatio,
        paymentPercent: t.paymentPercent || 0,
        extraMonths: t.extraMonths || 0,
        headcount,
        avgPerPerson: headcount > 0 ? Math.round(sum / headcount) : 0,
        minPerPerson: headcount > 0 ? Math.min(...amounts) : 0,
        maxPerPerson: headcount > 0 ? Math.max(...amounts) : 0,
        totalIfAll: sum,
      };
    });

    // ---------- تفکیک طبقات ----------
    const byLevel = new Map<number, { title: string; count: number; baseSum: number; tierSums: Record<string, number> }>();
    for (const e of employees) {
      const grade = e.jobGradeId ? gradeMap.get(e.jobGradeId) || null : null;
      const level = grade?.level || 0;
      const present = monthsPresent(e.hireDateJ || "", referenceDateJ);
      const base = Number(e.baseSalary || BigInt(0));
      let row = byLevel.get(level);
      if (!row) {
        row = { title: grade?.title || "", count: 0, baseSum: 0, tierSums: Object.fromEntries(TIER_KEYS.map((k) => [k, 0])) };
        byLevel.set(level, row);
      }
      row.count++;
      row.baseSum += base;
      for (const key of TIER_KEYS) {
        const t = tierByKey(cfg, key);
        row.tierSums[key] += amountIn(base, level, present, t.extraMonths || 0, t.paymentPercent || 0);
      }
    }
    const levels: LevelStat[] = Array.from(byLevel.entries())
      .sort((a, b) => a[0] - b[0])
      .map(([level, r]) => ({
        level,
        title: level > 0 ? r.title : "بدون طبقه",
        headcount: r.count,
        avgBaseSalary: r.count > 0 ? Math.round(r.baseSum / r.count) : 0,
        bonusMonths: level >= 1 && level <= 7 ? cfg.levels[String(level)] ?? 0 : 0,
        perTier: Object.fromEntries(
          TIER_KEYS.map((k) => [k, r.count > 0 ? Math.round(r.tierSums[k] / r.count) : 0]),
        ),
      }));

    return {
      referenceDateJ,
      headcount: employees.length,
      config: {
        levels: cfg.levels,
        tiers: cfg.tiers.map((t) => ({
          key: t.key,
          label: t.label,
          minRatio: t.minRatio,
          paymentPercent: t.paymentPercent,
          extraMonths: t.extraMonths,
        })),
      },
      tiers,
      levels,
      generatedAtJ: todayJalaliStr(),
    };
  });
}

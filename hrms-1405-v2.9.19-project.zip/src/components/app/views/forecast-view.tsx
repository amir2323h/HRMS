"use client";

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { TrendingUp, Plus, Trash2, Users, Download, Info, Building2, Wallet, UserPlus, Coins, ListOrdered, ScrollText } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits, JALALI_MONTHS } from "@/lib/jalali";
import { groupFa } from "@/lib/format";
import { downloadExcelSheets } from "@/lib/excel";
import { MoneyInput, Money } from "../money-input";
import { TrendChart } from "../charts";

// ============================================================
// پیش‌بینی بودجه حقوق و دستمزد — بازه زمانی + سناریوهای جذب + احکام صادرشده
// دو نما: «دیتای کلی ماهانه» و «لیست ریز افراد» (با نام دپارتمان هر نفر)
// ============================================================

interface GradeLite {
  id: string;
  level: number;
  title: string;
  departmentId: string | null;
  departmentName: string | null;
  minBaseSalary: number;
  maxBaseSalary: number;
  fixedBaseSalary: number;
}

interface DeptLite {
  id: string;
  name: string;
  code: string;
}

interface ForecastBase {
  departments: DeptLite[];
  grades: GradeLite[];
  today: { y: number; m: number };
  legal: { year: number; minWage: number; housing: number; grocery: number; employerSsoRate: number; unemploymentRate: number };
  current: {
    headcount: number;
    monthlyGross: number;
    monthlyCost: number;
    byDept: { id: string; name: string; headcount: number; monthlyCost: number }[];
  };
  issuedDecrees: { count: number; totalGross: number };
}

type Basis = "MIN" | "AVG" | "MAX" | "CUSTOM";

const BASIS_LABELS: Record<Basis, string> = {
  MIN: "حداقل بازه سطح",
  AVG: "میانگین بازه سطح",
  MAX: "حداکثر بازه سطح",
  CUSTOM: "مبلغ دلخواه",
};

interface HireDraft {
  key: number;
  departmentId: string;
  gradeId: string;
  count: number;
  startY: number;
  startM: number;
  basis: Basis;
  customToman: number; // تومان
}

interface RosterRow {
  kind: "EMPLOYEE" | "HIRE";
  name: string;
  personnelCode: string;
  department: string;
  level: number;
  levelTitle: string;
  baseSalary: number;
  legalBase: number;
  legalOther: number;
  gross: number;
  net: number;
  employerCost: number;
  monthsCount: number;
  totalCost: number;
}

interface DecreeRow {
  id: string;
  decreeNo: string;
  title: string;
  payLabel: string;
  scopeLabel: string;
  levelLabel: string;
  headcount: number;
  targetNetPerPerson: number;
  totalGross: number;
  totalTax: number;
  totalNet: number;
}

interface ForecastResult {
  months: {
    y: number; m: number; label: string;
    currentHeadcount: number; currentCost: number;
    newHires: number; plannedHeadcount: number; plannedCost: number;
    decreeCost: number;
    totalHeadcount: number; totalCost: number;
  }[];
  totals: {
    monthsCount: number;
    currentCost: number;
    plannedCost: number;
    decreesCost: number;
    totalCost: number;
    avgMonthly: number;
    finalHeadcount: number;
    totalNewHires: number;
  };
  roster: RosterRow[];
  decrees: DecreeRow[];
  byDept: { id: string; name: string; finalHeadcount: number; currentCost: number; plannedCost: number; decreeCost: number; totalCost: number }[];
  hires: { departmentName: string; gradeLabel: string; count: number; startLabel: string; basis: Basis; salary: number }[];
  assumptions: {
    annualRaisePercent: number; includeEmployerSso: boolean; includeDecrees: boolean; decreesCount: number;
    note: string; decreeNote: string; rosterNote: string;
  };
}

let hireKeySeq = 1;

export function ForecastView() {
  const { toast } = useToast();
  const base = useApi<ForecastBase>("/api/salary/forecast");
  const today = base.data?.today;

  // —— بازه پیش‌بینی (پیش‌فرض: ماه جاری تا ۵ ماه بعد) ——
  const [fromY, setFromY] = useState<number>(0);
  const [fromM, setFromM] = useState<number>(0);
  const [toY, setToY] = useState<number>(0);
  const [toM, setToM] = useState<number>(0);
  // مقداردهی اولیه پس از دریافت تاریخ جاری از سرور
  const [inited, setInited] = useState(false);
  if (!inited && today) {
    setInited(true);
    const endM = today.m + 5;
    setFromY(today.y);
    setFromM(today.m);
    setToY(today.y + Math.floor((endM - 1) / 12));
    setToM(((endM - 1) % 12) + 1);
  }

  const [annualRaise, setAnnualRaise] = useState(0); // درصد
  const [includeEmployerSso, setIncludeEmployerSso] = useState(true);
  const [includeDecrees, setIncludeDecrees] = useState(true);
  const [hires, setHires] = useState<HireDraft[]>([]);
  const [result, setResult] = useState<ForecastResult | null>(null);
  const [computing, setComputing] = useState(false);
  const [rosterQ, setRosterQ] = useState("");

  const yearOptions = useMemo(() => {
    const y0 = (today?.y || 1405) - 1;
    return [0, 1, 2, 3, 4].map((i) => y0 + i);
  }, [today]);

  const grades = base.data?.grades || [];
  const departments = base.data?.departments || [];

  /** سطح‌های قابل انتخاب برای یک دپارتمان: سراسری + سطح‌بندی همان دپارتمان */
  function gradesForDept(deptId: string): GradeLite[] {
    return grades.filter((g) => !g.departmentId || g.departmentId === deptId);
  }

  function addHire() {
    setHires((prev) => [
      ...prev,
      {
        key: hireKeySeq++,
        departmentId: "",
        gradeId: "",
        count: 1,
        startY: fromY || today?.y || 1405,
        startM: fromM || 1,
        basis: "AVG",
        customToman: 0,
      },
    ]);
  }

  function updateHire(key: number, patch: Partial<HireDraft>) {
    setHires((prev) => prev.map((h) => (h.key === key ? { ...h, ...patch } : h)));
  }

  function removeHire(key: number) {
    setHires((prev) => prev.filter((h) => h.key !== key));
  }

  /** مبنای حقوق یک سناریو (ریال) برای نمایش سرِ ردیف */
  function hireSalaryRial(h: HireDraft): number {
    const g = grades.find((x) => x.id === h.gradeId);
    if (!g) return 0;
    if (h.basis === "CUSTOM") return Math.round(h.customToman * 10);
    const min = g.minBaseSalary;
    const max = g.maxBaseSalary;
    if (max <= 0) return 0;
    if (h.basis === "MIN") return Math.max(0, min);
    if (h.basis === "MAX") return max;
    return Math.round((Math.max(0, min) + max) / 2);
  }

  /** تخمین سریع هزینه ماهانه سرِ نفر (حقوق + مسکن + بن + بیمه کارفرما) */
  function quickPerHead(h: HireDraft): number {
    const s = hireSalaryRial(h);
    if (!s || !base.data) return 0;
    const { housing, grocery, employerSsoRate, unemploymentRate } = base.data.legal;
    return Math.round((s + housing + grocery) * (1 + (includeEmployerSso ? employerSsoRate + unemploymentRate : 0)));
  }

  async function compute() {
    if (!fromY || !fromM || !toY || !toM) {
      toast({ title: "بازه پیش‌بینی را کامل کنید", variant: "destructive" });
      return;
    }
    if (toY * 12 + toM < fromY * 12 + fromM) {
      toast({ title: "ماه پایان باید بعد از ماه شروع باشد", variant: "destructive" });
      return;
    }
    for (const [i, h] of hires.entries()) {
      if (!h.departmentId || !h.gradeId) {
        toast({ title: `سناریوی جذب ${toFaDigits(i + 1)}: دپارتمان و سطح شغلی را انتخاب کنید`, variant: "destructive" });
        return;
      }
      if (!h.count || h.count < 1) {
        toast({ title: `سناریوی جذب ${toFaDigits(i + 1)}: تعداد نفرات نامعتبر است`, variant: "destructive" });
        return;
      }
    }
    setComputing(true);
    try {
      const d = await api<ForecastResult>("/api/salary/forecast", {
        method: "POST",
        json: {
          from: { y: fromY, m: fromM },
          to: { y: toY, m: toM },
          annualRaisePercent: annualRaise,
          includeEmployerSso,
          includeDecrees,
          hires: hires.map((h) => ({
            departmentId: h.departmentId,
            gradeId: h.gradeId,
            count: h.count,
            start: { y: h.startY, m: h.startM },
            basis: h.basis,
            customSalary: h.basis === "CUSTOM" ? Math.round(h.customToman * 10) : undefined,
          })),
        },
      });
      setResult(d);
      toast({
        title: "پیش‌بینی محاسبه شد",
        description: `${toFaDigits(d.totals.monthsCount)} ماه — جمع بودجه: ${groupFa(Math.round(d.totals.totalCost / 10))} تومان`,
      });
    } catch (e) {
      toast({ title: "خطا در محاسبه پیش‌بینی", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setComputing(false);
    }
  }

  function exportExcel() {
    if (!result) return;
    const monthRows = result.months.map((mo) => ({
      "ماه": `${JALALI_MONTHS[mo.m - 1]} ${toFaDigits(mo.y)}`,
      "نیروی فعلی": mo.currentHeadcount,
      "جذب جدید (همین ماه)": mo.newHires,
      "جمع نفرات": mo.totalHeadcount,
      "هزینه کارکنان فعلی (تومان)": Math.round(mo.currentCost / 10),
      "هزینه جذب جدید (تومان)": Math.round(mo.plannedCost / 10),
      "عیدی/احکام صادرشده (تومان)": Math.round(mo.decreeCost / 10),
      "جمع هزینه ماه (تومان)": Math.round(mo.totalCost / 10),
    }));
    const deptRows = result.byDept.map((d) => ({
      "دپارتمان": d.name,
      "نیروی پایان بازه": d.finalHeadcount,
      "هزینه کارکنان فعلی (تومان)": Math.round(d.currentCost / 10),
      "هزینه جذب جدید (تومان)": Math.round(d.plannedCost / 10),
      "عیدی/احکام (تومان)": Math.round(d.decreeCost / 10),
      "جمع (تومان)": Math.round(d.totalCost / 10),
    }));
    const rosterRows = result.roster.map((r) => ({
      "نوع": r.kind === "HIRE" ? "جذب جدید" : "کارمند",
      "نام / برنامه": r.name,
      "کد پرسنلی": r.personnelCode,
      "دپارتمان": r.department,
      "سطح": r.levelTitle,
      "حقوق ماهانه (تومان)": Math.round(r.baseSalary / 10),
      "حقوق پایه — عدد اداره کار (تومان)": Math.round(r.legalBase / 10),
      "سایر مزایا — مابالفاوت (تومان)": Math.round(r.legalOther / 10),
      "جمع حقوق و مزایا (تومان)": Math.round(r.gross / 10),
      "خالص (تومان)": Math.round(r.net / 10),
      "هزینه کارفرما (تومان)": Math.round(r.employerCost / 10),
      "ماه‌های همکاری": r.monthsCount,
      "جمع هزینه در بازه (تومان)": Math.round(r.totalCost / 10),
    }));
    const decreeRows = result.decrees.map((d) => ({
      "شماره حکم": d.decreeNo,
      "عنوان": d.title,
      "ماه پرداخت": d.payLabel,
      "دامنه": d.scopeLabel,
      "سطح": d.levelLabel,
      "نفرات": d.headcount,
      "خالص هدف هر نفر (تومان)": Math.round(d.targetNetPerPerson / 10),
      "جمع مبلغ احکام (تومان)": Math.round(d.totalGross / 10),
      "مالیات (تومان)": Math.round(d.totalTax / 10),
      "خالص پرداختی (تومان)": Math.round(d.totalNet / 10),
    }));
    const hireRows = result.hires.map((h) => ({
      "دپارتمان": h.departmentName,
      "سطح شغلی": h.gradeLabel,
      "تعداد": h.count,
      "ماه شروع": h.startLabel,
      "مبنای برآورد": BASIS_LABELS[h.basis],
      "حقوق مبنا (تومان)": Math.round(h.salary / 10),
    }));
    const fname = `پیش‌بینی-بودجه-حقوق-${fromY}-${String(fromM).padStart(2, "0")}-تا-${toY}-${String(toM).padStart(2, "0")}.xlsx`;
    downloadExcelSheets(fname, [
      { name: "ماهانه", rows: monthRows },
      { name: "ریز افراد", rows: rosterRows },
      { name: "دپارتمان‌ها", rows: deptRows },
      { name: "احکام", rows: decreeRows },
      { name: "سناریوهای جذب", rows: hireRows },
    ]);
    toast({ title: "خروجی اکسل آماده شد", description: "پنج شیت: ماهانه، ریز افراد، دپارتمان‌ها، احکام و سناریوهای جذب." });
  }

  if (base.loading) {
    return (
      <div className="space-y-3">
        {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}
      </div>
    );
  }
  if (base.error) {
    return (
      <Card className="rounded-2xl">
        <CardContent className="py-10 text-center text-sm text-muted-foreground">{base.error}</CardContent>
      </Card>
    );
  }

  const current = base.data?.current;
  const issued = base.data?.issuedDecrees;
  const chartData = (result?.months || []).map((mo) => ({
    label: JALALI_MONTHS[mo.m - 1] || "",
    value: Math.round(mo.totalCost / 10), // تومان
  }));

  const rosterFiltered = (result?.roster || []).filter((r) => {
    if (!rosterQ.trim()) return true;
    const q = rosterQ.trim();
    return r.name.includes(q) || r.department.includes(q) || r.personnelCode.includes(q) || r.levelTitle.includes(q);
  });

  return (
    <div className="space-y-4">
      {/* هدر — توضیح و وضعیت فعلی */}
      <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
        <CardContent className="p-4 flex items-start gap-3 flex-wrap">
          <TrendingUp className="w-8 h-8 text-teal-600 shrink-0 mt-1" />
          <div className="flex-1 min-w-[260px]">
            <p className="font-bold text-slate-800">پیش‌بینی بودجه حقوق و دستمزد</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              بودجه موردنیاز حقوق را برای بازه دلخواه (تا «آخر سال») برآورد کنید — بر مبنای <b>کارکنان فعلی</b> (فیش استاندارد: حقوق + مزایای ثابت + سنوات
              {includeEmployerSso ? " + بیمه سهم کارفرما ۲۳٪" : ""}) به‌علاوه <b>سناریوهای جذب آینده</b> و <b>احکام صادرشده</b> (عیدی/پاداش).
              خروجی دو نما دارد: «دیتای کلی ماهانه» و «لیست ریز افراد» با نام دپارتمان هر نفر.
            </p>
            {current && (
              <div className="flex flex-wrap items-center gap-2 mt-2.5">
                <Badge variant="outline" className="gap-1"><Users className="w-3 h-3" /> {toFaDigits(current.headcount)} نیروی فعال</Badge>
                <Badge variant="outline" className="gap-1"><Wallet className="w-3 h-3" /> هزینه ماه جاری: <Money amount={current.monthlyCost} short /></Badge>
                <Badge variant="outline" className="gap-1"><Building2 className="w-3 h-3" /> {toFaDigits(current.byDept.length)} دپارتمان</Badge>
                {issued && issued.count > 0 && (
                  <Badge variant="outline" className="gap-1 border-amber-300 text-amber-800 bg-amber-50">
                    <ScrollText className="w-3 h-3" /> {toFaDigits(issued.count)} حکم صادرشده: <Money amount={issued.totalGross} short />
                  </Badge>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* تنظیمات بازه */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-teal-600" /> بازه و فرض‌های پیش‌بینی
          </CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">از ماه</Label>
            <div className="flex gap-2">
              <Select value={String(fromM)} onValueChange={(v) => setFromM(+v)}>
                <SelectTrigger className="w-[104px]"><SelectValue /></SelectTrigger>
                <SelectContent>{JALALI_MONTHS.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={String(fromY)} onValueChange={(v) => setFromY(+v)}>
                <SelectTrigger className="w-[96px]"><SelectValue /></SelectTrigger>
                <SelectContent>{yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{toFaDigits(y)}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تا ماه</Label>
            <div className="flex gap-2">
              <Select value={String(toM)} onValueChange={(v) => setToM(+v)}>
                <SelectTrigger className="w-[104px]"><SelectValue /></SelectTrigger>
                <SelectContent>{JALALI_MONTHS.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={String(toY)} onValueChange={(v) => setToY(+v)}>
                <SelectTrigger className="w-[96px]"><SelectValue /></SelectTrigger>
                <SelectContent>{yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{toFaDigits(y)}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <p className="text-[10px] text-muted-foreground">حداکثر ۳۶ ماه</p>
              {today && (
                <button
                  type="button"
                  className="text-[10px] text-teal-700 hover:text-teal-800 underline underline-offset-2"
                  onClick={() => { setToY(today.y); setToM(12); }}
                >
                  تا آخر سال {toFaDigits(today.y)}
                </button>
              )}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">افزایش سالانه حقوق (٪)</Label>
            <div className="flex items-center gap-1.5">
              <Input
                dir="ltr" type="number" min={0} max={200} step={1}
                className="text-left tabular-nums h-9 w-[96px]"
                value={annualRaise}
                onChange={(e) => setAnnualRaise(Math.min(200, Math.max(0, +e.target.value || 0)))}
              />
              <span className="text-sm font-bold text-slate-600">٪</span>
            </div>
            <p className="text-[10px] text-muted-foreground leading-4">از سال دومِ بازه اعمال می‌شود (مثلاً مصوبه مزد سالانه)</p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">بیمه سهم کارفرما (۲۳٪)</Label>
            <div className="flex items-center gap-2 h-9">
              <Switch checked={includeEmployerSso} onCheckedChange={setIncludeEmployerSso} id="sso-switch" />
              <span className="text-xs text-muted-foreground">{includeEmployerSso ? "محاسبه می‌شود" : "فقط حقوق و مزایا"}</span>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">احکام صادرشده (عیدی/پاداش)</Label>
            <div className="flex items-center gap-2 h-9">
              <Switch checked={includeDecrees} onCheckedChange={setIncludeDecrees} id="decree-switch" />
              <span className="text-xs text-muted-foreground">
                {issued && issued.count > 0
                  ? includeDecrees ? `${toFaDigits(issued.count)} حکم در ماه پرداخت لحاظ می‌شود` : "حکمی لحاظ نمی‌شود"
                  : "حکمی صادر نشده"}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* سناریوهای جذب */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <UserPlus className="w-4 h-4 text-teal-600" /> سناریوهای جذب نیروی جدید
            {hires.length > 0 && <Badge variant="outline">{toFaDigits(hires.reduce((a, h) => a + h.count, 0))} نفر در {toFaDigits(hires.length)} سناریو</Badge>}
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1 leading-5">
            برای هر برنامه جذب مشخص کنید: <b>کدام تیم</b>، <b>کدام سطح شغلی</b> (سطح‌بندی سراسری یا اختصاصی همان دپارتمان)، <b>چند نفر</b> و <b>از چه ماهی</b> —
            مبنای برآورد حقوق از بازه همان سطح (حداقل/میانگین/حداکثر) یا مبلغ دلخواه است.
          </p>
        </CardHeader>
        <CardContent className="space-y-3">
          {hires.length === 0 && (
            <div className="rounded-xl border border-dashed p-5 text-center">
              <UserPlus className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">هنوز برنامه جذبی تعریف نشده — پیش‌بینی فقط بر مبنای کارکنان فعلی و احکام صادرشده خواهد بود.</p>
            </div>
          )}
          {hires.map((h, i) => {
            const g = grades.find((x) => x.id === h.gradeId);
            return (
              <div key={h.key} className="rounded-xl border bg-slate-50/60 p-3.5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-teal-700 flex items-center gap-1.5">
                    <UserPlus className="w-3.5 h-3.5" /> برنامه جذب {toFaDigits(i + 1)}
                  </span>
                  <button type="button" className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-500" title="حذف سناریو" onClick={() => removeHire(h.key)}>
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-6 gap-3 items-end">
                  <div className="space-y-1.5">
                    <Label className="text-[11px] text-muted-foreground">دپارتمان (تیم)</Label>
                    <Select
                      value={h.departmentId || "none"}
                      onValueChange={(v) => {
                        const deptId = v === "none" ? "" : v;
                        // اگر سطح انتخاب‌شده مخصوص دپارتمان دیگری است، پاک شود
                        const stillOk = gradesForDept(deptId).some((x) => x.id === h.gradeId);
                        updateHire(h.key, { departmentId: deptId, gradeId: stillOk ? h.gradeId : "" });
                      }}
                    >
                      <SelectTrigger className="h-9"><SelectValue placeholder="انتخاب تیم" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">— انتخاب تیم —</SelectItem>
                        {departments.map((d) => <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[11px] text-muted-foreground">سطح شغلی</Label>
                    <Select value={h.gradeId || "none"} onValueChange={(v) => updateHire(h.key, { gradeId: v === "none" ? "" : v })} disabled={!h.departmentId}>
                      <SelectTrigger className="h-9"><SelectValue placeholder="انتخاب سطح" /></SelectTrigger>
                      <SelectContent className="max-h-56">
                        <SelectItem value="none">— انتخاب سطح —</SelectItem>
                        {gradesForDept(h.departmentId).map((x) => (
                          <SelectItem key={x.id} value={x.id}>
                            سطح {toFaDigits(x.level)} — {x.title}{x.departmentName ? ` (${x.departmentName})` : ""}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[11px] text-muted-foreground">تعداد نفرات</Label>
                    <Input
                      type="number" min={1} max={100} className="h-9 tabular-nums"
                      value={h.count}
                      onChange={(e) => updateHire(h.key, { count: Math.min(100, Math.max(1, Math.round(+e.target.value || 1))) })}
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[11px] text-muted-foreground">شروع همکاری</Label>
                    <div className="flex gap-1.5">
                      <Select value={String(h.startM)} onValueChange={(v) => updateHire(h.key, { startM: +v })}>
                        <SelectTrigger className="h-9 w-[88px]"><SelectValue /></SelectTrigger>
                        <SelectContent>{JALALI_MONTHS.map((m, ix) => <SelectItem key={m} value={String(ix + 1)}>{m}</SelectItem>)}</SelectContent>
                      </Select>
                      <Select value={String(h.startY)} onValueChange={(v) => updateHire(h.key, { startY: +v })}>
                        <SelectTrigger className="h-9 w-[78px]"><SelectValue /></SelectTrigger>
                        <SelectContent>{yearOptions.map((y) => <SelectItem key={y} value={String(y)}>{toFaDigits(y)}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[11px] text-muted-foreground">مبنای برآورد حقوق</Label>
                    <Select value={h.basis} onValueChange={(v) => updateHire(h.key, { basis: v as Basis })}>
                      <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {(Object.keys(BASIS_LABELS) as Basis[]).map((bk) => <SelectItem key={bk} value={bk}>{BASIS_LABELS[bk]}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    {h.basis === "CUSTOM" ? (
                      <>
                        <Label className="text-[11px] text-muted-foreground">حقوق ماهانه (دلخواه)</Label>
                        <MoneyInput value={h.customToman} onChange={(v) => updateHire(h.key, { customToman: v })} />
                      </>
                    ) : g ? (
                      <div className="h-9 rounded-lg border bg-white px-3 flex items-center text-[11px] leading-4 text-muted-foreground">
                        بازه سطح: <Money amount={g.minBaseSalary} short className="mx-1" /> تا <Money amount={g.maxBaseSalary} short className="mx-1" />
                      </div>
                    ) : (
                      <div className="h-9" />
                    )}
                  </div>
                </div>
                {h.gradeId && (
                  <div className="flex flex-wrap items-center gap-2 text-[11px] bg-white rounded-lg border px-3 py-2">
                    <Coins className="w-3.5 h-3.5 text-teal-600" />
                    <span className="text-muted-foreground">حقوق مبنا:</span>
                    <b className="tabular-nums">{hireSalaryRial(h) ? <Money amount={hireSalaryRial(h)} short /> : "—"}</b>
                    {g && g.fixedBaseSalary > 0 && (
                      <>
                        <span className="text-muted-foreground">• حقوق پایه ثابت سطح:</span>
                        <b className="tabular-nums"><Money amount={g.fixedBaseSalary} short /></b>
                        <span className="text-muted-foreground">(+ سایر مزایا = باقیمانده)</span>
                      </>
                    )}
                    {hireSalaryRial(h) > 0 && (
                      <>
                        <span className="text-muted-foreground">• هزینه ماهانه سرِ نفر (تخمینی):</span>
                        <b className="tabular-nums"><Money amount={quickPerHead(h)} short /></b>
                        <span className="text-muted-foreground">• جمع ماهانه {toFaDigits(h.count)} نفر:</span>
                        <b className="tabular-nums"><Money amount={quickPerHead(h) * h.count} short /></b>
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" className="gap-1.5" onClick={addHire}>
              <Plus className="w-4 h-4" /> افزودن برنامه جذب
            </Button>
            <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={compute} disabled={computing}>
              <TrendingUp className="w-4 h-4" /> {computing ? "در حال محاسبه..." : "محاسبه پیش‌بینی"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* نتایج */}
      {result && (
        <>
          {/* کارت‌های خلاصه */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Card className="rounded-2xl bg-teal-600 border-teal-600 text-white">
              <CardContent className="p-4">
                <p className="text-xs opacity-90 flex items-center gap-1"><Wallet className="w-3.5 h-3.5" /> جمع بودجه بازه</p>
                <p className="text-lg font-black mt-1.5"><Money amount={result.totals.totalCost} short /></p>
                <p className="text-[10px] opacity-80 mt-1">
                  {toFaDigits(result.totals.monthsCount)} ماه — میانگین ماهانه: <Money amount={result.totals.avgMonthly} short />
                  {result.totals.decreesCost > 0 && <> (شامل عیدی/احکام: <Money amount={result.totals.decreesCost} short />)</>}
                </p>
              </CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground flex items-center gap-1"><Users className="w-3.5 h-3.5" /> نیروی پایان بازه</p>
                <p className="text-lg font-black mt-1.5 tabular-nums">{toFaDigits(result.totals.finalHeadcount)} نفر</p>
                <p className="text-[10px] text-muted-foreground mt-1">شامل {toFaDigits(result.totals.totalNewHires)} نفر جذب جدید</p>
              </CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground flex items-center gap-1"><Users className="w-3.5 h-3.5" /> هزینه کارکنان فعلی</p>
                <p className="text-lg font-black mt-1.5"><Money amount={result.totals.currentCost} short /></p>
                <p className="text-[10px] text-muted-foreground mt-1">جمع {toFaDigits(result.totals.monthsCount)} ماه</p>
              </CardContent>
            </Card>
            <Card className="rounded-2xl">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <UserPlus className="w-3.5 h-3.5" /> هزینه جذب جدید
                  {result.totals.decreesCost > 0 && <span className="text-amber-700">+ عیدی/احکام</span>}
                </p>
                <p className="text-lg font-black mt-1.5"><Money amount={result.totals.plannedCost} short /></p>
                <p className="text-[10px] text-muted-foreground mt-1">
                  {result.hires.length > 0 ? `${toFaDigits(result.hires.length)} برنامه جذب` : "بدون برنامه جذب"}
                  {result.totals.decreesCost > 0 && <> • احکام: <Money amount={result.totals.decreesCost} short /></>}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* دو نما: ماهانه / ریز افراد */}
          <Tabs defaultValue="monthly" dir="rtl">
            <div className="flex flex-wrap items-center gap-2 justify-between">
              <TabsList>
                <TabsTrigger value="monthly" className="text-xs gap-1">
                  <Coins className="w-3.5 h-3.5" /> دیتای کلی ماهانه
                </TabsTrigger>
                <TabsTrigger value="roster" className="text-xs gap-1">
                  <ListOrdered className="w-3.5 h-3.5" /> لیست ریز افراد
                </TabsTrigger>
              </TabsList>
              <Button size="sm" variant="outline" className="gap-1.5" onClick={exportExcel}>
                <Download className="w-4 h-4" /> خروجی اکسل (۵ شیت)
              </Button>
            </div>

            {/* ————— نمای ۱: دیتای کلی ماهانه ————— */}
            <TabsContent value="monthly" className="space-y-4 mt-4">
              {/* نمودار روند */}
              <Card className="rounded-2xl">
                <CardHeader className="pb-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-teal-600" /> روند هزینه ماهانه (تومان)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {chartData.length > 1 ? (
                    <TrendChart data={chartData} height={230} />
                  ) : (
                    <p className="text-xs text-muted-foreground py-6 text-center">برای نمایش نمودار، بازه حداقل ۲ ماه انتخاب کنید.</p>
                  )}
                </CardContent>
              </Card>

              {/* جدول ماه‌به‌ماه */}
              <Card className="rounded-2xl overflow-hidden">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">جدول پیش‌بینی ماه‌به‌ماه</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="max-h-96 overflow-y-auto">
                    <Table>
                      <TableHeader className="sticky top-0 z-10">
                        <TableRow className="bg-slate-50/95 backdrop-blur">
                          <TableHead className="text-right">ماه</TableHead>
                          <TableHead className="text-center">نیروی فعلی</TableHead>
                          <TableHead className="text-center">جذب این ماه</TableHead>
                          <TableHead className="text-center">جمع نفرات</TableHead>
                          <TableHead className="text-left">هزینه کارکنان فعلی</TableHead>
                          <TableHead className="text-left">هزینه جذب جدید</TableHead>
                          <TableHead className="text-left">عیدی/احکام</TableHead>
                          <TableHead className="text-left">جمع هزینه ماه</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {result.months.map((mo, i) => (
                          <TableRow key={i} className={mo.newHires > 0 ? "bg-emerald-50/50" : mo.decreeCost > 0 ? "bg-amber-50/40" : ""}>
                            <TableCell className="font-medium whitespace-nowrap">{JALALI_MONTHS[mo.m - 1]} {toFaDigits(mo.y)}</TableCell>
                            <TableCell className="text-center tabular-nums">{toFaDigits(mo.currentHeadcount)}</TableCell>
                            <TableCell className="text-center tabular-nums">
                              {mo.newHires > 0 ? <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">+{toFaDigits(mo.newHires)}</Badge> : "—"}
                            </TableCell>
                            <TableCell className="text-center tabular-nums font-semibold">{toFaDigits(mo.totalHeadcount)}</TableCell>
                            <TableCell className="text-left"><Money amount={mo.currentCost} short /></TableCell>
                            <TableCell className="text-left">{mo.plannedCost > 0 ? <Money amount={mo.plannedCost} short /> : "—"}</TableCell>
                            <TableCell className="text-left">{mo.decreeCost > 0 ? <span className="text-amber-800"><Money amount={mo.decreeCost} short /></span> : "—"}</TableCell>
                            <TableCell className="text-left font-semibold"><Money amount={mo.totalCost} short /></TableCell>
                          </TableRow>
                        ))}
                        <TableRow className="bg-teal-600 text-white hover:bg-teal-600">
                          <TableCell className="font-bold">جمع بازه</TableCell>
                          <TableCell className="text-center">—</TableCell>
                          <TableCell className="text-center tabular-nums font-bold">{toFaDigits(result.totals.totalNewHires)}</TableCell>
                          <TableCell className="text-center">—</TableCell>
                          <TableCell className="text-left font-bold"><Money amount={result.totals.currentCost} short /></TableCell>
                          <TableCell className="text-left font-bold"><Money amount={result.totals.plannedCost} short /></TableCell>
                          <TableCell className="text-left font-bold"><Money amount={result.totals.decreesCost} short /></TableCell>
                          <TableCell className="text-left font-bold"><Money amount={result.totals.totalCost} short /></TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* به تفکیک دپارتمان */}
              {result.byDept.length > 0 && (
                <Card className="rounded-2xl overflow-hidden">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Building2 className="w-4 h-4 text-teal-600" /> بودجه به تفکیک دپارتمان (کل بازه)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-slate-50/80">
                            <TableHead className="text-right">دپارتمان</TableHead>
                            <TableHead className="text-center">نیروی پایان بازه</TableHead>
                            <TableHead className="text-left">هزینه کارکنان فعلی</TableHead>
                            <TableHead className="text-left">هزینه جذب جدید</TableHead>
                            <TableHead className="text-left">عیدی/احکام</TableHead>
                            <TableHead className="text-left">جمع</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {result.byDept.map((d) => (
                            <TableRow key={d.id} className="hover:bg-teal-50/40">
                              <TableCell className="font-medium">{d.name}</TableCell>
                              <TableCell className="text-center tabular-nums">{toFaDigits(d.finalHeadcount)}</TableCell>
                              <TableCell className="text-left"><Money amount={d.currentCost} short /></TableCell>
                              <TableCell className="text-left">{d.plannedCost > 0 ? <Money amount={d.plannedCost} short /> : "—"}</TableCell>
                              <TableCell className="text-left">{d.decreeCost > 0 ? <span className="text-amber-800"><Money amount={d.decreeCost} short /></span> : "—"}</TableCell>
                              <TableCell className="text-left font-semibold"><Money amount={d.totalCost} short /></TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* ————— نمای ۲: لیست ریز افراد ————— */}
            <TabsContent value="roster" className="space-y-4 mt-4">
              <Card className="rounded-2xl overflow-hidden">
                <CardHeader className="pb-3 flex-row items-center justify-between flex-wrap gap-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <ListOrdered className="w-4 h-4 text-teal-600" /> ریز افراد به تفکیک دپارتمان
                    <Badge variant="outline" className="font-normal">
                      {toFaDigits(result.roster.filter((r) => r.kind === "EMPLOYEE").length)} کارمند
                      {result.roster.some((r) => r.kind === "HIRE") && <> + {toFaDigits(result.roster.filter((r) => r.kind === "HIRE").length)} برنامه جذب</>}
                    </Badge>
                  </CardTitle>
                  <Input
                    value={rosterQ}
                    onChange={(e) => setRosterQ(e.target.value)}
                    placeholder="جستجوی نام / دپارتمان / سطح..."
                    className="h-9 w-full sm:w-64"
                  />
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto max-h-[28rem] overflow-y-auto">
                    <Table>
                      <TableHeader className="sticky top-0 z-10">
                        <TableRow className="bg-slate-50/95 backdrop-blur">
                          <TableHead className="text-right">کارمند / برنامه جذب</TableHead>
                          <TableHead className="text-right">دپارتمان</TableHead>
                          <TableHead className="text-right">سطح</TableHead>
                          <TableHead className="text-left">حقوق ماهانه</TableHead>
                          <TableHead className="text-left">حقوق پایه</TableHead>
                          <TableHead className="text-left">سایر مزایا</TableHead>
                          <TableHead className="text-left">ناخالص</TableHead>
                          <TableHead className="text-left">خالص</TableHead>
                          <TableHead className="text-center">ماه‌ها</TableHead>
                          <TableHead className="text-left">جمع هزینه بازه</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rosterFiltered.map((r, i) => (
                          <TableRow key={i} className={r.kind === "HIRE" ? "bg-emerald-50/40" : "hover:bg-teal-50/30"}>
                            <TableCell className="font-medium text-sm">
                              {r.kind === "HIRE" ? (
                                <span className="flex items-center gap-1.5 text-emerald-800">
                                  <UserPlus className="w-3.5 h-3.5" /> {r.name}
                                </span>
                              ) : (
                                <>
                                  {r.name}
                                  <span className="block text-[10px] text-muted-foreground tabular-nums">{r.personnelCode}</span>
                                </>
                              )}
                            </TableCell>
                            <TableCell className="text-sm">{r.department}</TableCell>
                            <TableCell className="text-xs">{r.levelTitle}</TableCell>
                            <TableCell className="text-left"><Money amount={r.baseSalary} short /></TableCell>
                            <TableCell className="text-left" title="عدد پایه اداره کار">
                              <Money amount={r.legalBase} short />
                            </TableCell>
                            <TableCell className="text-left" title="مابالفاوت حقوق ماهانه">
                              <Money amount={r.legalOther} short />
                            </TableCell>
                            <TableCell className="text-left"><Money amount={r.gross} short /></TableCell>
                            <TableCell className="text-left text-emerald-700 font-medium"><Money amount={r.net} short /></TableCell>
                            <TableCell className="text-center tabular-nums">
                              {toFaDigits(r.monthsCount)}
                              {r.kind === "HIRE" && <span className="block text-[9px] text-muted-foreground">نفر×ماه</span>}
                            </TableCell>
                            <TableCell className="text-left font-semibold"><Money amount={r.totalCost} short /></TableCell>
                          </TableRow>
                        ))}
                        {rosterFiltered.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={10} className="text-center text-sm text-muted-foreground py-10">
                              موردی با این جستجو یافت نشد.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>

              {/* احکام صادرشده در بازه */}
              {result.decrees.length > 0 && (
                <Card className="rounded-2xl overflow-hidden border-amber-200/70">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <ScrollText className="w-4 h-4 text-amber-600" /> احکام صادرشده در این بازه
                      <Badge variant="outline" className="font-normal border-amber-300 text-amber-800">
                        {toFaDigits(result.decrees.length)} حکم — <Money amount={result.totals.decreesCost} short />
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-slate-50/80">
                            <TableHead className="text-right">شماره حکم</TableHead>
                            <TableHead className="text-right">عنوان</TableHead>
                            <TableHead className="text-center">ماه پرداخت</TableHead>
                            <TableHead className="text-right">دامنه</TableHead>
                            <TableHead className="text-center">نفرات</TableHead>
                            <TableHead className="text-left">خالص هدف هر نفر</TableHead>
                            <TableHead className="text-left">جمع مبلغ احکام</TableHead>
                            <TableHead className="text-left">مالیات</TableHead>
                            <TableHead className="text-left">خالص پرداختی</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {result.decrees.map((d) => (
                            <TableRow key={d.id} className="hover:bg-amber-50/40">
                              <TableCell className="text-xs font-bold text-amber-800 whitespace-nowrap">{d.decreeNo}</TableCell>
                              <TableCell className="text-sm font-medium">
                                {d.title}
                                <span className="block text-[10px] text-muted-foreground">{d.levelLabel}</span>
                              </TableCell>
                              <TableCell className="text-center text-xs">{d.payLabel}</TableCell>
                              <TableCell className="text-xs">{d.scopeLabel}</TableCell>
                              <TableCell className="text-center tabular-nums">{toFaDigits(d.headcount)}</TableCell>
                              <TableCell className="text-left"><Money amount={d.targetNetPerPerson} short /></TableCell>
                              <TableCell className="text-left font-semibold"><Money amount={d.totalGross} short /></TableCell>
                              <TableCell className="text-left"><Money amount={d.totalTax} short /></TableCell>
                              <TableCell className="text-left text-emerald-700 font-medium"><Money amount={d.totalNet} short /></TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>

          {/* فرض‌ها */}
          <Card className="rounded-2xl border-teal-200/70 bg-teal-50/40">
            <CardContent className="p-4 flex items-start gap-2.5">
              <Info className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <div className="text-xs text-teal-900 leading-5">
                <b>فرض‌های محاسبه:</b> {result.assumptions.note}.
                سناریوهای جذب مجرد و بدون فرزند فرض می‌شوند و سنوات آن‌ها از سال دوم همکاری (جدول تجمیعی ۱۴۰۵) به هزینه اضافه می‌شود.
                {result.assumptions.annualRaisePercent > 0 && <> افزایش سالانه <b>{toFaDigits(Math.round(result.assumptions.annualRaisePercent * 100))}٪</b> از سال دومِ بازه روی هزینه‌های ماهانه اعمال شده است.</>}
                {!result.assumptions.includeEmployerSso && <> بیمه سهم کارفرما در این محاسبه لحاظ نشده است.</>}
                {result.assumptions.includeDecrees && result.assumptions.decreesCount > 0 && <> {result.assumptions.decreeNote}</>}
                {result.roster.length > 0 && <> {result.assumptions.rosterNote}</>}
                حقوق و مزایای رفاهی/بیمه تکمیلی و اقلام متغیر (اضافه‌کاری، مأموریت و…) در این برآورد لحاظ نمی‌شوند.
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

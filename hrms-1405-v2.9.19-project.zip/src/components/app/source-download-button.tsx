"use client";

// ============================================================
// دکمه دانلود بسته کامل سورس پروژه (زیپ آماده گیت‌هاب)
//  • فقط برای مدیر کل سیستم (SUPER_ADMIN) رندر می‌شود
//  • فایل از مسیر استاتیک public/downloads سرو می‌شود؛
//    اگر بسته در دسترس نباشد (استقرار واقعی روی سرور)،
//    دکمه به‌صورت خودکار مخفی می‌شود.
// ============================================================
import { useEffect, useState } from "react";
import { FileArchive } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ZIP_URL = "/downloads/hrms-1405-v2.9.19-project.zip";
const ZIP_NAME = "hrms-1405-v2.9.19-project.zip";
const ZIP_SIZE_FA = "۱٫۵ مگابایت";

export function SourceDownloadButton() {
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [available, setAvailable] = useState<boolean | null>(null);

  // بررسی یک‌بارهٔ موجود بودن بسته — در استقرار بدون بسته، دکمه مخفی می‌شود
  useEffect(() => {
    let alive = true;
    fetch(ZIP_URL, { method: "HEAD" })
      .then((res) => { if (alive) setAvailable(res.ok); })
      .catch(() => { if (alive) setAvailable(false); });
    return () => { alive = false; };
  }, []);

  async function handleClick() {
    // بررسی موجود بودن فایل قبل از دانلود — پیام واضح به‌جای خطای خام مرورگر
    setBusy(true);
    try {
      const res = await fetch(ZIP_URL, { method: "HEAD" });
      if (!res.ok) throw new Error();
      const a = document.createElement("a");
      a.href = ZIP_URL;
      a.download = ZIP_NAME;
      document.body.appendChild(a);
      a.click();
      a.remove();
      toast({
        title: "دانلود بسته سورس آغاز شد",
        description: `فایل ${ZIP_NAME} (${ZIP_SIZE_FA}) — کامل و آماده ارسال به گیت‌هاب`,
      });
    } catch {
      toast({
        title: "فایل زیپ در دسترس نیست",
        description: "بسته سورس روی سرور یافت نشد — با پشتیبانی هماهنگ کنید.",
        variant: "destructive",
      });
    } finally {
      setBusy(false);
    }
  }

  // بسته موجود نیست (استقرار سرور) — هیچ رندر نکن
  if (available === false) return null;

  return (
    <button
      className="relative p-2 rounded-lg text-slate-500 hover:text-teal-700 hover:bg-teal-50 transition-colors"
      onClick={handleClick}
      disabled={busy || available === null}
      title="دانلود بسته کامل سورس پروژه (زیپ گیت‌هاب)"
      aria-label="دانلود بسته کامل سورس پروژه"
    >
      <FileArchive className="w-5 h-5" />
      {available === null ? null : (
        <span className="absolute -top-0.5 -left-0.5 w-2.5 h-2.5 rounded-full bg-teal-500 animate-pulse" aria-hidden="true" />
      )}
    </button>
  );
}

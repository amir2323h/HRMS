import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit, num } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import { computeDecreeLines } from "@/lib/decree";
import { todayJalaliStr } from "@/lib/jalali";

// ============================================================
// احکام گروهی (عیدی/پاداش پایان سال)
//  GET  : لیست احکام + پارامترهای قانونی (برای فرم صدور)
//  POST : محاسبه و صدور حکم گروهی — dryRun=true فقط پیش‌نمایش بدون ذخیره
// جریان: خالص هدف هر نفر → معکوس با نرخ مالیات نهاییِ همان نفر
// (از روی حقوق پایه دستی او) → حکم گروهی؛ پیش‌بینی بودجه، احکام
// صادرشده را در ماه پرداختِ آنها لحاظ می‌کند.
// ============================================================

function serializeLine(l: {
  employeeName: string; personnelCode: string; department: string;
  jobLevel: number; jobLevelTitle: string; baseSalary: bigint | number;
  marginalRate: number; targetNet: bigint | number; taxAmount: bigint | number;
  grossAmount: bigint | number; netAmount: bigint | number; coefficient: number;
}) {
  return {
    employeeName: l.employeeName,
    personnelCode: l.personnelCode,
    department: l.department,
    jobLevel: l.jobLevel,
    jobLevelTitle: l.jobLevelTitle,
    baseSalary: num(l.baseSalary as bigint),
    marginalRate: l.marginalRate,
    targetNet: num(l.targetNet as bigint),
    taxAmount: num(l.taxAmount as bigint),
    grossAmount: num(l.grossAmount as bigint),
    netAmount: num(l.netAmount as bigint),
    coefficient: l.coefficient,
  };
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "bonus:view");

    const [decrees, params] = await Promise.all([
      db.salaryDecree.findMany({ orderBy: { createdAt: "desc" } }),
      getLegalParams(),
    ]);
    const lineCounts = await db.salaryDecreeLine.groupBy({ by: ["decreeId"], _count: { decreeId: true } });
    const countMap = new Map(lineCounts.map((c) => [c.decreeId, c._count.decreeId]));

    const today = todayJalaliStr(); // YYYY/MM/DD
    const ty = Number(today.split("/")[0]);

    return {
      decrees: decrees.map((d) => ({
        id: d.id,
        decreeNo: d.decreeNo,
        year: d.year,
        title: d.title,
        kind: d.kind,
        payMonthY: d.payMonthY,
        payMonthM: d.payMonthM,
        scope: d.scope,
        scopeDeptName: d.scopeDeptName,
        levelTitle: d.levelTitle,
        targetNetPerPerson: num(d.targetNetPerPerson),
        taxExempt: num(d.taxExempt),
        headcount: d.headcount,
        totalGross: num(d.totalGross),
        totalTax: num(d.totalTax),
        totalNet: num(d.totalNet),
        status: d.status,
        notes: d.notes,
        createdBy: d.createdBy,
        createdAt: d.createdAt,
        lineCount: countMap.get(d.id) || 0,
      })),
      legal: {
        year: params.year,
        minWage: params.minWage,
        defaultTaxExempt: params.minWage * 2, // معافیت عیدی = ۲× حداقل دستمزد
        taxBrackets: params.taxBrackets,
      },
      defaults: {
        // پیش‌فرض فرم: عیدی پایان سال جاری (اسفند)
        payMonthY: ty,
        payMonthM: 12,
        title: `عیدی و پاداش پایان سال ${ty}`,
      },
      today,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "bonus:manage");
    const b = await req.json();

    // ——— ورودی‌ها ———
    const targetNet = Math.round(+b?.targetNetPerPerson || 0); // ریال
    if (!(targetNet > 0)) {
      return Response.json({ error: "خالص هدف هر نفر را وارد کنید (باید مثبت باشد)." }, { status: 400 });
    }
    const payMonthY = Math.round(+b?.payMonthY || 0);
    const payMonthM = Math.round(+b?.payMonthM || 0);
    if (!payMonthY || payMonthM < 1 || payMonthM > 12) {
      return Response.json({ error: "ماه پرداخت حکم نامعتبر است." }, { status: 400 });
    }

    const params = await getLegalParams(true);
    // معافیت مالیاتی عیدی — پیش‌فرض ۲× حداقل دستمزد (صفر/منفی = همان پیش‌فرض)
    let taxExempt = Math.round(+b?.taxExempt || 0);
    if (!(taxExempt > 0)) taxExempt = params.minWage * 2;

    // ——— دامنه: دپارتمان + سطح (اختیاری) ———
    let scopeDeptId: string | null = null;
    let scopeDeptName = "همه دپارتمان‌ها";
    if (b?.scopeDeptId) {
      const dept = await db.department.findUnique({ where: { id: String(b.scopeDeptId) } });
      if (!dept) return Response.json({ error: "دپارتمان انتخاب‌شده یافت نشد." }, { status: 400 });
      scopeDeptId = dept.id;
      scopeDeptName = dept.name;
    }
    let levelId: string | null = null;
    let levelTitle = "همه سطوح";
    if (b?.levelId) {
      const grade = await db.jobGrade.findUnique({ where: { id: String(b.levelId) } });
      if (!grade) return Response.json({ error: "سطح انتخاب‌شده یافت نشد." }, { status: 400 });
      levelId = grade.id;
      levelTitle = `سطح ${grade.level} — ${grade.title}`;
    }

    // ——— محاسبه خطوط ———
    const calc = await computeDecreeLines({
      params,
      scopeDeptId,
      levelId,
      targetNet,
      taxExempt,
      payMonthY,
      payMonthM,
    });
    if ("error" in calc) return Response.json({ error: calc.error }, { status: 400 });

    const title = String(b?.title || "").trim() || `عیدی و پاداش پایان سال ${payMonthY}`;
    const dryRun = b?.dryRun === true;

    // ——— پیش‌نمایش — بدون ذخیره ———
    if (dryRun) {
      return {
        dryRun: true,
        title,
        payLabel: `${payMonthY}/${String(payMonthM).padStart(2, "0")}`,
        scopeLabel: scopeDeptName,
        levelLabel: levelTitle,
        meta: {
          targetNetPerPerson: targetNet,
          taxExempt,
          payMonthY,
          payMonthM,
        },
        lines: calc.lines.map(serializeLine),
        totals: calc.totals,
      };
    }

    // ——— صدور حکم ———
    const year = payMonthY;
    const existingCount = await db.salaryDecree.count({ where: { year } });
    const seq = existingCount + 1;

    const data = {
      year,
      title,
      kind: "BONUS",
      payMonthY,
      payMonthM,
      scope: (scopeDeptId ? "DEPT" : "ALL") as string,
      scopeDeptId,
      scopeDeptName,
      levelId,
      levelTitle,
      targetNetPerPerson: BigInt(targetNet),
      taxExempt: BigInt(taxExempt),
      headcount: calc.totals.headcount,
      totalGross: BigInt(calc.totals.totalGross),
      totalTax: BigInt(calc.totals.totalTax),
      totalNet: BigInt(calc.totals.totalNet),
      status: "ISSUED",
      notes: String(b?.notes || ""),
      createdBy: session.fullName,
    };

    let decree;
    try {
      decree = await db.salaryDecree.create({
        data: { ...data, decreeNo: `حکم-${year}-${String(seq).padStart(3, "0")}` },
      });
    } catch {
      // برخورد شماره (هم‌زمانی) — یک شماره جلوتر
      decree = await db.salaryDecree.create({
        data: { ...data, decreeNo: `حکم-${year}-${String(seq + 1).padStart(3, "0")}` },
      });
    }

    for (const l of calc.lines) {
      await db.salaryDecreeLine.create({
        data: {
          decreeId: decree.id,
          employeeId: l.employeeId,
          employeeName: l.employeeName,
          personnelCode: l.personnelCode,
          department: l.department,
          jobLevel: l.jobLevel,
          jobLevelTitle: l.jobLevelTitle,
          baseSalary: BigInt(l.baseSalary),
          marginalRate: l.marginalRate,
          targetNet: BigInt(l.targetNet),
          taxAmount: BigInt(l.taxAmount),
          grossAmount: BigInt(l.grossAmount),
          netAmount: BigInt(l.netAmount),
          coefficient: l.coefficient,
        },
      });
    }

    await audit(
      session,
      "ISSUE",
      "SALARY_DECREE",
      decree.id,
      `صدور حکم گروهی «${title}» ${decree.decreeNo} — ${calc.totals.headcount} نفر، خالص هدف هر نفر ${targetNet.toLocaleString("en-US")} ریال، جمع احکام ${calc.totals.totalGross.toLocaleString("en-US")} ریال (پرداخت ${payMonthY}/${payMonthM})`,
      undefined,
      { targetNet, taxExempt, headcount: calc.totals.headcount, totalGross: calc.totals.totalGross },
    );

    return {
      dryRun: false,
      decree: {
        id: decree.id,
        decreeNo: decree.decreeNo,
        title: decree.title,
        payMonthY: decree.payMonthY,
        payMonthM: decree.payMonthM,
        scopeDeptName: decree.scopeDeptName,
        levelTitle: decree.levelTitle,
        targetNetPerPerson: targetNet,
        taxExempt,
        headcount: decree.headcount,
        totalGross: calc.totals.totalGross,
        totalTax: calc.totals.totalTax,
        totalNet: calc.totals.totalNet,
        status: decree.status,
      },
      lines: calc.lines.map(serializeLine),
      totals: calc.totals,
    };
  });
}

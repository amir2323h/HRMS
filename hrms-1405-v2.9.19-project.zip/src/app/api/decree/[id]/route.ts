import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit, num } from "@/lib/api-helpers";

// ============================================================
// جزئیات/ابطال حکم گروهی
//  GET   : حکم + خطوط نفر به نفر
//  PATCH : { action: "cancel" } — ابطال حکم صادرشده
// ============================================================

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(req, "bonus:view");
    const { id } = await params;
    const decree = await db.salaryDecree.findUnique({ where: { id } });
    if (!decree) return Response.json({ error: "حکم یافت نشد." }, { status: 404 });
    const lines = await db.salaryDecreeLine.findMany({
      where: { decreeId: id },
      orderBy: [{ department: "asc" }, { jobLevel: "desc" }, { employeeName: "asc" }],
    });
    return {
      decree: {
        id: decree.id,
        decreeNo: decree.decreeNo,
        year: decree.year,
        title: decree.title,
        payMonthY: decree.payMonthY,
        payMonthM: decree.payMonthM,
        scope: decree.scope,
        scopeDeptName: decree.scopeDeptName,
        levelTitle: decree.levelTitle,
        targetNetPerPerson: num(decree.targetNetPerPerson),
        taxExempt: num(decree.taxExempt),
        headcount: decree.headcount,
        totalGross: num(decree.totalGross),
        totalTax: num(decree.totalTax),
        totalNet: num(decree.totalNet),
        status: decree.status,
        notes: decree.notes,
        createdBy: decree.createdBy,
        createdAt: decree.createdAt,
      },
      lines: lines.map((l) => ({
        id: l.id,
        employeeName: l.employeeName,
        personnelCode: l.personnelCode,
        department: l.department,
        jobLevel: l.jobLevel,
        jobLevelTitle: l.jobLevelTitle,
        baseSalary: num(l.baseSalary),
        marginalRate: l.marginalRate,
        targetNet: num(l.targetNet),
        taxAmount: num(l.taxAmount),
        grossAmount: num(l.grossAmount),
        netAmount: num(l.netAmount),
        coefficient: l.coefficient,
      })),
    };
  });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "bonus:manage");
    const { id } = await params;
    const b = await req.json().catch(() => ({}));

    if (b?.action !== "cancel") {
      return Response.json({ error: "عملیات نامعتبر است." }, { status: 400 });
    }
    const decree = await db.salaryDecree.findUnique({ where: { id } });
    if (!decree) return Response.json({ error: "حکم یافت نشد." }, { status: 404 });
    if (decree.status !== "ISSUED") {
      return Response.json({ error: "این حکم قبلاً ابطال شده است." }, { status: 400 });
    }
    const before = { status: decree.status };
    await db.salaryDecree.update({ where: { id }, data: { status: "CANCELLED" } });
    await audit(
      session,
      "CANCEL",
      "SALARY_DECREE",
      id,
      `ابطال حکم گروهی ${decree.decreeNo} «${decree.title}» — ${decree.headcount} نفر، جمع ${num(decree.totalGross).toLocaleString("en-US")} ریال`,
      before,
      { status: "CANCELLED" },
    );
    return { ok: true };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getLegalParams } from "@/lib/settings";
import { todayJalali, daysInJalaliMonth, formatMonthJ } from "@/lib/jalali";
import { computePaysheet, contextFromEmployee, shiftRateOf, type LegalParams } from "@/lib/payroll/engine";

// ============================================================
// پیش‌بینی بودجه حقوق و دستمزد — بازه زمانی انتخابی
//  GET  : داده پایه (دپارتمان‌ها، سطح‌ها، پارامترهای قانونی، وضعیت فعلی)
//  POST : محاسبه پیش‌بینی — کارکنان فعلی + سناریوهای جذب آینده
//         (کدام تیم، کدام سطح، چند نفر، از چه ماهی)
//
// هزینه ماهانه هر نفر = فیش استاندارد (بدون اقلام متغیر اضافه‌کاری/
// مأموریت/غیبت) + بیمه سهم کارفرما (۲۳٪) — مطابق موتور محاسبه رسمی
// ============================================================

type Basis = "MIN" | "AVG" | "MAX" | "CUSTOM";

interface HireInput {
  departmentId: string;
  gradeId: string;
  count: number;
  start: { y: number; m: number };
  basis: Basis;
  customSalary?: number; // ریال
}

interface MonthKey {
  y: number;
  m: number;
}

const ym = (k: MonthKey) => k.y * 12 + (k.m - 1);
const pad2 = (n: number) => String(n).padStart(2, "0");
const monthStartJ = (k: MonthKey) => `${k.y}/${pad2(k.m)}/01`;
const monthEndJ = (k: MonthKey) => `${k.y}/${pad2(k.m)}/${pad2(daysInJalaliMonth(k.y, k.m))}`;
const keyOf = (idx: number): MonthKey => ({ y: Math.floor(idx / 12), m: (idx % 12) + 1 });

/** فیش استاندارد ماهانه (بدون اقلام متغیر) — مبنای پیش‌بینی بودجه */
function standardMonthlyCost(
  baseSalary: number,
  empLike: {
    childCount: number;
    maritalStatus: string;
    hireDateJ: string;
    employmentType?: string;
    shiftPattern?: string;
  },
  grade: { seniorityBase: bigint | number; attraction: bigint | number; fixedBaseSalary?: bigint | number | null } | null,
  atDateJ: string,
  params: LegalParams,
  shiftRate: number,
): { gross: number; employerTotalCost: number } {
  const ctx = contextFromEmployee(
    { baseSalary, childCount: empLike.childCount || 0, maritalStatus: empLike.maritalStatus, overtimeHours: 0, hireDateJ: empLike.hireDateJ, employmentType: empLike.employmentType, shiftPattern: empLike.shiftPattern },
    grade,
    atDateJ,
    { overtimeHours: 0, otherAllowance: 0, otherDeduction: 0, nightHours: 0, fridayHours: 0, holidayHours: 0, absentDays: 0, missionDays: 0, shiftRate },
  );
  const sheet = computePaysheet(baseSalary, ctx, params);
  return { gross: sheet.gross, employerTotalCost: sheet.employerTotalCost };
}

/** مبنای حقوق یک سناریوی جذب از بازه سطح — ریال */
function basisSalary(
  grade: { minBaseSalary: bigint; maxBaseSalary: bigint },
  basis: Basis,
  customSalary: number | undefined,
): { salary: number } | { error: string } {
  if (basis === "CUSTOM") {
    const s = Math.round(Number(customSalary) || 0);
    if (s <= 0) return { error: "مبلغ دلخواه حقوق باید مثبت باشد." };
    return { salary: s };
  }
  const min = Number(grade.minBaseSalary);
  const max = Number(grade.maxBaseSalary);
  if (max <= 0) return { error: "بازه حقوق این سطح تعریف نشده — مبلغ دلخواه وارد کنید یا بازه سطح را از «طبقه‌بندی مشاغل» تکمیل کنید." };
  if (basis === "MIN") return { salary: Math.max(0, min) };
  if (basis === "MAX") return { salary: max };
  return { salary: Math.round((Math.max(0, min) + max) / 2) };
}

/** آیا کارمند در ماه idx مشغول به کار است؟ (استخدام‌شده و ترک‌نکرده) */
function employedIn(emp: { status: string; hireDateJ: string; leaveDateJ: string }, hireYm: number | null, leaveYm: number | null, idx: number): boolean {
  if (hireYm !== null && hireYm > idx) return false; // هنوز استخدام نشده
  if (emp.status === "ACTIVE") return true;
  if (leaveYm === null) return false; // غیرفعال/قطع‌شده بدون تاریخ ترک → خارج از محاسبه
  return leaveYm >= idx; // تا ماه ترک (شامل همان ماه) مشغول است
}

function parseYm(dateJ: string): number | null {
  const p = (dateJ || "").split("/").map(Number);
  if (p.length !== 3 || isNaN(p[0]) || isNaN(p[1]) || !p[0]) return null;
  return ym({ y: p[0], m: p[1] });
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "payroll:view");

    const [departments, grades, params] = await Promise.all([
      db.department.findMany({ orderBy: { code: "asc" }, select: { id: true, name: true, code: true } }),
      db.jobGrade.findMany({
        include: { department: { select: { id: true, name: true } } },
        orderBy: [{ departmentId: "asc" }, { level: "asc" }],
      }),
      getLegalParams(),
    ]);

    // ——— وضعیت فعلی: هزینه ماهانه استاندارد کارکنان فعال (ماه جاری) ———
    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      include: {
        jobGrade: true,
        departments: { include: { department: { select: { id: true, name: true } } }, orderBy: { allocationPercent: "desc" } },
      },
    });
    const t = todayJalali();
    const nowIdx = ym({ y: t.jy, m: t.jm });
    const endJ = monthEndJ({ y: t.jy, m: t.jm });
    let headcount = 0;
    let monthlyGross = 0;
    let monthlyCost = 0;
    const byDept = new Map<string, { id: string; name: string; headcount: number; monthlyCost: number }>();
    for (const e of employees) {
      const hireYm = parseYm(e.hireDateJ);
      if (hireYm !== null && hireYm > nowIdx) continue; // استخدام در آینده
      headcount += 1;
      const cost = standardMonthlyCost(Number(e.baseSalary), e, e.jobGrade, endJ, params, shiftRateOf(e.employmentType, e.shiftPattern, params));
      monthlyGross += cost.gross;
      monthlyCost += cost.employerTotalCost;
      const dept = e.departments?.[0]?.department;
      const key = dept?.id || "NONE";
      const agg = byDept.get(key) || { id: key, name: dept?.name || "بدون دپارتمان", headcount: 0, monthlyCost: 0 };
      agg.headcount += 1;
      agg.monthlyCost += cost.employerTotalCost;
      byDept.set(key, agg);
    }

    return {
      departments,
      grades: grades.map((g) => ({
        id: g.id,
        level: g.level,
        title: g.title,
        departmentId: g.departmentId,
        departmentName: g.department?.name || null,
        minBaseSalary: Number(g.minBaseSalary),
        maxBaseSalary: Number(g.maxBaseSalary),
        seniorityBase: Number(g.seniorityBase),
        attraction: Number(g.attraction),
        fixedBaseSalary: Number(g.fixedBaseSalary),
      })),
      today: { y: t.jy, m: t.jm, label: formatMonthJ(t.jy, t.jm) },
      legal: {
        year: params.year,
        minWage: params.minWage,
        housing: params.housing,
        grocery: params.grocery,
        employerSsoRate: params.employerSsoRate,
        unemploymentRate: params.unemploymentRate,
      },
      current: {
        headcount,
        monthlyGross,
        monthlyCost,
        byDept: [...byDept.values()].sort((a, b) => b.monthlyCost - a.monthlyCost),
      },
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "payroll:view");
    const b = await req.json();

    const from: MonthKey = { y: Math.round(+b?.from?.y), m: Math.round(+b?.from?.m) };
    const to: MonthKey = { y: Math.round(+b?.to?.y), m: Math.round(+b?.to?.m) };
    if (!from.y || from.m < 1 || from.m > 12 || !to.y || to.m < 1 || to.m > 12) {
      return Response.json({ error: "بازه زمانی نامعتبر است." }, { status: 400 });
    }
    if (ym(to) < ym(from)) return Response.json({ error: "ماه پایان باید بعد از ماه شروع باشد." }, { status: 400 });
    const totalMonths = ym(to) - ym(from) + 1;
    if (totalMonths > 36) return Response.json({ error: "بازه پیش‌بینی حداکثر ۳۶ ماه است." }, { status: 400 });

    const annualRaisePercent = Math.min(200, Math.max(0, +b?.annualRaisePercent || 0)) / 100;
    const includeEmployerSso = b?.includeEmployerSso !== false; // پیش‌فرض: با بیمه کارفرما

    const hireInputs: HireInput[] = Array.isArray(b?.hires) ? b.hires.slice(0, 50) : [];

    const [departments, grades, params] = await Promise.all([
      db.department.findMany({ select: { id: true, name: true } }),
      db.jobGrade.findMany(),
      getLegalParams(),
    ]);
    const deptMap = new Map(departments.map((d) => [d.id, d]));
    const gradeMap = new Map(grades.map((g) => [g.id, g]));

    // ——— اعتبارسنجی سناریوها ———
    const hires: {
      departmentId: string;
      departmentName: string;
      gradeId: string;
      gradeLabel: string;
      count: number;
      start: MonthKey;
      salary: number;
      basis: Basis;
    }[] = [];
    for (const [i, h] of hireInputs.entries()) {
      const label = `سناریوی جذب ${toFa(i + 1)}`;
      const dept = deptMap.get(String(h?.departmentId || ""));
      if (!dept) return Response.json({ error: `${label}: دپارتمان انتخاب نشده است.` }, { status: 400 });
      const grade = gradeMap.get(String(h?.gradeId || ""));
      if (!grade) return Response.json({ error: `${label}: سطح شغلی انتخاب نشده است.` }, { status: 400 });
      if (grade.departmentId && grade.departmentId !== dept.id) {
        const gDept = deptMap.get(grade.departmentId);
        return Response.json({ error: `${label}: سطح انتخاب‌شده مخصوص دپارتمان «${gDept?.name || ""}» است — برای تیم «${dept.name}» سطح سراسری یا سطح همان دپارتمان را انتخاب کنید.` }, { status: 400 });
      }
      const count = Math.round(+h?.count);
      if (!count || count < 1 || count > 100) return Response.json({ error: `${label}: تعداد نفرات باید بین ۱ تا ۱۰۰ باشد.` }, { status: 400 });
      const start: MonthKey = { y: Math.round(+h?.start?.y), m: Math.round(+h?.start?.m) };
      if (!start.y || start.m < 1 || start.m > 12) return Response.json({ error: `${label}: ماه شروع جذب نامعتبر است.` }, { status: 400 });
      const basis: Basis = ["MIN", "AVG", "MAX", "CUSTOM"].includes(h?.basis) ? h.basis : "AVG";
      const bs = basisSalary(grade, basis, h?.customSalary);
      if ("error" in bs) return Response.json({ error: `${label}: ${bs.error}` }, { status: 400 });
      hires.push({
        departmentId: dept.id,
        departmentName: dept.name,
        gradeId: grade.id,
        gradeLabel: `سطح ${grade.level} — ${grade.title}`,
        count,
        start,
        salary: bs.salary,
        basis,
      });
    }

    // ——— کارکنان فعلی (فعال + ترک‌کارِ دارای تاریخ) ———
    const employees = await db.employee.findMany({
      where: { status: { in: ["ACTIVE", "INACTIVE"] } },
      include: {
        jobGrade: true,
        departments: { include: { department: { select: { id: true, name: true } } }, orderBy: { allocationPercent: "desc" } },
      },
    });
    const empCtx = employees.map((e) => {
      const dept = e.departments?.[0]?.department;
      return {
        emp: e,
        hireYm: parseYm(e.hireDateJ),
        leaveYm: parseYm(e.leaveDateJ),
        deptId: dept?.id || "NONE",
        deptName: dept?.name || "بدون دپارتمان",
        shiftRate: shiftRateOf(e.employmentType, e.shiftPattern, params),
      };
    });

    // ——— محاسبه ماه‌به‌ماه ———
    const fromIdx = ym(from);
    const toIdx = ym(to);
    const months: {
      y: number; m: number; label: string;
      currentHeadcount: number; currentCost: number;
      newHires: number; plannedHeadcount: number; plannedCost: number;
      totalHeadcount: number; totalCost: number;
    }[] = [];

    for (let idx = fromIdx; idx <= toIdx; idx++) {
      const key = keyOf(idx);
      const endJ = monthEndJ(key);
      // ضریب افزایش سالانه — از سال دومِ بازه
      const raiseFactor = Math.pow(1 + annualRaisePercent, Math.max(0, key.y - from.y));

      let currentHeadcount = 0;
      let currentCost = 0;
      for (const e of empCtx) {
        if (!employedIn(e.emp, e.hireYm, e.leaveYm, idx)) continue;
        currentHeadcount += 1;
        const cost = standardMonthlyCost(Number(e.emp.baseSalary), e.emp, e.emp.jobGrade, endJ, params, e.shiftRate);
        currentCost += includeEmployerSso ? cost.employerTotalCost : cost.gross;
      }
      currentCost = Math.round(currentCost * raiseFactor);

      let newHires = 0;
      let plannedHeadcount = 0;
      let plannedCost = 0;
      for (const h of hires) {
        const sIdx = ym(h.start);
        if (sIdx > idx) continue; // هنوز شروع نشده
        if (sIdx === idx) newHires += h.count;
        plannedHeadcount += h.count;
        // تاریخ شروع همکاری = ماه شروع سناریو → سنوات از سال دوم محاسبه می‌شود
        const cost = standardMonthlyCost(
          h.salary,
          { childCount: 0, maritalStatus: "SINGLE", hireDateJ: monthStartJ(h.start), employmentType: "DAILY" },
          gradeMap.get(h.gradeId)!,
          endJ,
          params,
          0,
        );
        plannedCost += (includeEmployerSso ? cost.employerTotalCost : cost.gross) * h.count;
      }
      plannedCost = Math.round(plannedCost * raiseFactor);

      months.push({
        y: key.y,
        m: key.m,
        label: formatMonthJ(key.y, key.m),
        currentHeadcount,
        currentCost,
        newHires,
        plannedHeadcount,
        plannedCost,
        totalHeadcount: currentHeadcount + plannedHeadcount,
        totalCost: currentCost + plannedCost,
      });
    }

    // ——— تجمیع کل بازه به تفکیک دپارتمان ———
    const deptTotals = new Map<string, { id: string; name: string; finalHeadcount: number; currentCost: number; plannedCost: number }>();
    for (let idx = fromIdx; idx <= toIdx; idx++) {
      const key = keyOf(idx);
      const raiseFactor = Math.pow(1 + annualRaisePercent, Math.max(0, key.y - from.y));
      for (const e of empCtx) {
        if (!employedIn(e.emp, e.hireYm, e.leaveYm, idx)) continue;
        const agg = deptTotals.get(e.deptId) || { id: e.deptId, name: e.deptName, finalHeadcount: 0, currentCost: 0, plannedCost: 0 };
        if (idx === toIdx) agg.finalHeadcount += 1; // نیروی فعلی پایان بازه
        const cost = standardMonthlyCost(Number(e.emp.baseSalary), e.emp, e.emp.jobGrade, monthEndJ(key), params, e.shiftRate);
        agg.currentCost += Math.round((includeEmployerSso ? cost.employerTotalCost : cost.gross) * raiseFactor);
        deptTotals.set(e.deptId, agg);
      }
      for (const h of hires) {
        if (ym(h.start) > idx) continue;
        const agg = deptTotals.get(h.departmentId) || { id: h.departmentId, name: h.departmentName, finalHeadcount: 0, currentCost: 0, plannedCost: 0 };
        if (idx === toIdx) agg.finalHeadcount += h.count; // نیروی جذب‌شده پایان بازه
        const cost = standardMonthlyCost(
          h.salary,
          { childCount: 0, maritalStatus: "SINGLE", hireDateJ: monthStartJ(h.start), employmentType: "DAILY" },
          gradeMap.get(h.gradeId)!,
          monthEndJ(key),
          params,
          0,
        );
        agg.plannedCost += Math.round((includeEmployerSso ? cost.employerTotalCost : cost.gross) * h.count * raiseFactor);
        deptTotals.set(h.departmentId, agg);
      }
    }

    const totalCostAll = months.reduce((a, x) => a + x.totalCost, 0);
    const totals = {
      monthsCount: totalMonths,
      currentCost: months.reduce((a, x) => a + x.currentCost, 0),
      plannedCost: months.reduce((a, x) => a + x.plannedCost, 0),
      totalCost: totalCostAll,
      avgMonthly: Math.round(totalCostAll / totalMonths),
      finalHeadcount: months.length ? months[months.length - 1].totalHeadcount : 0,
      totalNewHires: hires.reduce((a, h) => a + (ym(h.start) >= fromIdx && ym(h.start) <= toIdx ? h.count : 0), 0),
    };

    await audit(session, "VIEW", "FORECAST", "salary-budget", `پیش‌بینی بودجه حقوق ${months[0]?.label || ""} تا ${months[months.length - 1]?.label || ""} — جمع ${totals.totalCost} ریال (${hires.length} سناریو جذب)`);

    return {
      months,
      totals,
      byDept: [...deptTotals.values()]
        .map((d) => ({ ...d, totalCost: d.currentCost + d.plannedCost }))
        .sort((a, b) => b.totalCost - a.totalCost),
      hires: hires.map((h) => ({
        departmentId: h.departmentId,
        departmentName: h.departmentName,
        gradeId: h.gradeId,
        gradeLabel: h.gradeLabel,
        count: h.count,
        startLabel: formatMonthJ(h.start.y, h.start.m),
        basis: h.basis,
        salary: h.salary,
      })),
      assumptions: {
        annualRaisePercent,
        includeEmployerSso,
        note:
          "هزینه هر نفر = فیش استاندارد ماهانه (حقوق + مزایای ثابت قانونی + سنوات) بدون اقلام متغیر (اضافه‌کاری، مأموریت، شب/جمعه‌کاری، غیبت)" +
          (includeEmployerSso ? " + بیمه سهم کارفرما (۲۰٪ + ۳٪)" : ""),
      },
    };
  });
}

function toFa(n: number): string {
  return String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
}

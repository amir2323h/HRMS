"use client";

// ============================================================
// دروازه احراز هویت — تعیین وضعیت نشست سمت کلاینت
// به‌جای رندر سمت سرور (که فقط به کوکی وابسته بود)، نشست از
// /api/auth/me خوانده می‌شود که هم کوکی و هم توکن Bearer را می‌پذیرد.
// ============================================================
import { useCallback, useEffect, useState } from "react";
import { api, AUTH_EVENT } from "@/lib/client";
import { useBranding } from "./use-branding";
import { LoginScreen } from "./login-screen";
import { AppRoot, type SessionInfo } from "./app-root";

type Phase = "boot" | "login" | "app";

export function AuthGate() {
  const [phase, setPhase] = useState<Phase>("boot");
  const [user, setUser] = useState<SessionInfo | null>(null);
  // برندینگ از همان لحظه بوت — لوگو/عنوان تنظیمات با کش آنی نمایش داده می‌شود
  const { brand } = useBranding();

  const recheck = useCallback(async () => {
    try {
      const d = await api<{ user: SessionInfo | null }>("/api/auth/me");
      if (d && d.user) {
        setUser(d.user);
        setPhase("app");
        return;
      }
    } catch {
      /* خطای شبکه/سرور — ورود به صفحه لاگین */
    }
    setUser(null);
    setPhase("login");
  }, []);

  useEffect(() => {
    // بررسی اولیه نشست — فراخوانی async؛ تغییر state فقط پس از اتمام I/O رخ می‌دهد
    // (الگوی استاندارد بارگذاری داده در effect، نه مشتق‌سازی همگام state)
    // eslint-disable-next-line react-hooks/set-state-in-effect
    void recheck();
    const onAuthChange = () => void recheck();
    window.addEventListener(AUTH_EVENT, onAuthChange);
    return () => window.removeEventListener(AUTH_EVENT, onAuthChange);
  }, [recheck]);

  if (phase === "boot") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-teal-950 via-slate-900 to-teal-900 gap-5">
        {brand?.logo ? (
          <img src={brand.logo} alt="لوگو" className="w-20 h-20 rounded-2xl object-contain bg-white/10 p-2 backdrop-blur border border-white/20 shadow-2xl" />
        ) : (
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-2xl shadow-teal-500/30">
            <svg viewBox="0 0 24 24" className="w-11 h-11 text-white" fill="none" stroke="currentColor" strokeWidth="1.8">
              <path d="M12 2L20 6v5c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V6l8-4z" strokeLinejoin="round" />
              <path d="M12 8v4l3 2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        )}
        <p className="text-teal-200/80 text-sm">{brand?.title || "در حال بارگذاری سامانه…"}</p>
        <div className="w-40 h-1 rounded-full bg-white/10 overflow-hidden">
          <div className="h-full w-1/2 bg-teal-400 rounded-full animate-pulse" />
        </div>
      </div>
    );
  }

  if (phase === "login" || !user) {
    return <LoginScreen />;
  }

  return <AppRoot user={user} />;
}

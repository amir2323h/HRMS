"use client";

// ============================================================
// ورودی مبلغ — قالب‌بندی «زنده» هنگام تایپ:
//   • ارقام فارسی (۱۲۵۰۰۰ → ۱۲۵,۰۰۰)
//   • جداکننده سه‌رقمی سه‌رقم سه‌رقم به‌صورت خودکار
//   • پذیرش ارقام فارسی/عربی/لاتین و ویرگول/کاما
// قرارداد: value و onChange هر دو به «تومان» — بدون تبدیل واحد
// (فرم‌ها خودشان هنگام ارسال ×۱۰ می‌کنند)
// ============================================================
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { groupFa, fa, toEnDigits } from "@/lib/format";

/** پاکسازی ورودی خام: ارقام فارسی/عربی → لاتین، فقط رقم و حداکثر یک ممیز */
export function sanitizeMoneyInput(raw: string): string {
  let en = toEnDigits(raw).replace(/[٫]/g, ".").replace(/[^\d.]/g, "");
  const dot = en.indexOf(".");
  if (dot !== -1) en = en.slice(0, dot + 1) + en.slice(dot + 1).replace(/\./g, "");
  return en;
}

/** نمایش زنده: ۱۲,۵۰۰,۰۰۰ یا ۱۲,۵۰۰,۰۰۰.۵ */
export function formatMoneyLive(en: string): string {
  if (!en) return "";
  const [int, frac] = en.split(".");
  const grouped = (int || "").replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return fa(grouped + (frac !== undefined ? "." + frac : ""));
}

/** ورودی مبلغ تومانی: نمایش ۱۲,۵۰۰,۰۰۰ → مقدار 12500000 (تومان) */
export function MoneyInput({ value, onChange, placeholder = "۰", unit = "تومان", id, disabled, className }: {
  value: number; // تومان
  onChange: (tomanValue: number) => void;
  placeholder?: string;
  unit?: string;
  id?: string;
  disabled?: boolean;
  className?: string;
}) {
  const [text, setText] = useState(() => (value ? groupFa(value) : ""));
  const [prevValue, setPrevValue] = useState(value);

  // همگام‌سازی هنگام رندر وقتی مقدار بیرونی تغییر کرده باشد (الگوی رسمی React)
  if (value !== prevValue) {
    setPrevValue(value);
    setText(value ? groupFa(value) : "");
  }

  return (
    <div className={`relative ${className || ""}`}>
      <Input
        id={id}
        inputMode="decimal"
        data-numeric="true"
        className="pr-3 pl-14 font-medium tabular-nums"
        placeholder={placeholder}
        value={text}
        disabled={disabled}
        onChange={(e) => {
          // پاکسازی و قالب‌بندی زنده: هر تایپی فوراً به ارقام فارسی + جداکننده تبدیل می‌شود
          const en = sanitizeMoneyInput(e.target.value);
          setText(formatMoneyLive(en));
          const n = parseFloat(en) || 0;
          setPrevValue(n);
          onChange(n);
        }}
      />
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground pointer-events-none">{unit}</span>
    </div>
  );
}

/** نمایش مبلغ با واحد (تومان/ریال) به‌صورت یکنواخت — بدون «.0» اضافه */
export function Money({ amount, unit = "TOMAN", className = "", short = false }: {
  amount: number | null | undefined;
  unit?: "RIAL" | "TOMAN";
  className?: string;
  short?: boolean;
}) {
  if (amount === null || amount === undefined) return <span className={className}>—</span>;
  const v = unit === "RIAL" ? amount : amount / 10;
  const text = short
    ? v >= 1_000_000_000
      ? `${groupFa(round1(v / 1_000_000_000))} میلیارد`
      : v >= 1_000_000
        ? `${groupFa(round1(v / 1_000_000))} میلیون`
        : groupFa(Math.round(v))
    : groupFa(Math.round(v));
  return (
    <span className={`tabular-nums ${className}`}>
      {text} <span className="text-[0.72em] text-muted-foreground font-normal">{unit === "RIAL" ? "ریال" : "تومان"}</span>
    </span>
  );
}

/** گرد به یک رقم اعشار بدون «.0»: 2.0 → 2، 2.5 → 2.5 */
function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

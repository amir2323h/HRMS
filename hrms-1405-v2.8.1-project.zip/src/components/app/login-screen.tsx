"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { api, setAuthToken, notifyAuthChanged, useApi } from "@/lib/client";
import { qrCodeSvg } from "@/lib/qrcode";
import { toFaDigits } from "@/lib/jalali";
import { useBranding } from "./use-branding";

const DEMO_USERS = [
  { username: "admin", password: "admin123", label: "مدیر کل سیستم", color: "bg-rose-500" },
  { username: "hr", password: "hr123", label: "مدیر منابع انسانی", color: "bg-teal-600" },
  { username: "payroll", password: "pay123", label: "کارشناس حقوق", color: "bg-amber-500" },
  { username: "dept", password: "dept123", label: "مدیر دپارتمان", color: "bg-emerald-600" },
  { username: "emp", password: "emp123", label: "کارمند (پرتال)", color: "bg-slate-500" },
];

/** پاسخ‌های ورود دو مرحله‌ای — قبل از نشست کامل */
interface Login2faState {
  kind: "need2fa" | "enroll";
  username: string;
  secret?: string; // فقط در ثبت‌نام
  otpauthUrl?: string;
}

export function LoginScreen() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [totp, setTotp] = useState("");
  const [twoFa, setTwoFa] = useState<Login2faState | null>(null);
  const [loading, setLoading] = useState(false);
  // برندینگ پویا (عنوان/لوگو از تنظیمات — با کش آنی بدون فلش)
  const { brand } = useBranding();
  // دکمه ورود Mattermost (OAuth 2.0)
  const mm = useApi<{ enabled: boolean; buttonLabel: string }>("/api/auth/mattermost/config");
  const mmEnabled = !!mm.data?.enabled;
  // دکمه ورود گوگل (OAuth 2.0 / OpenID Connect)
  const gg = useApi<{ enabled: boolean; buttonLabel: string; allowedDomain?: string }>("/api/auth/google/config");
  const ggEnabled = !!gg.data?.enabled;

  // خطای بازگشتی از callback ماترموست/گوگل (localStorage — توسط صفحه callback ست می‌شود)
  // خواندن در اولین رندر (اینیشیالایزر lazy) — نه در effect
  const [error, setError] = useState<string | null>(() => {
    try {
      if (typeof window === "undefined") return null;
      const mmErr = window.localStorage.getItem("hrms_mm_error");
      if (mmErr) {
        window.localStorage.removeItem("hrms_mm_error");
        return `ورود ناموفق بود: ${mmErr}`;
      }
    } catch { /* private browsing */ }
    return null;
  });

  async function startMattermostLogin() {
    setError(null);
    try {
      const d = await api<{ url: string }>("/api/auth/mattermost/url");
      if (d?.url) window.location.href = d.url;
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در شروع ورود Mattermost");
    }
  }

  async function startGoogleLogin() {
    setError(null);
    try {
      const d = await api<{ url: string }>("/api/auth/google/url");
      if (d?.url) window.location.href = d.url;
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا در شروع ورود با گوگل");
    }
  }

  async function doLogin(u: string, p: string, code?: string) {
    setLoading(true);
    setError(null);
    try {
      const d = await api<
        | { user: unknown; token?: string }
        | { need2fa: true; username: string }
        | { enroll: true; username: string; secret: string; otpauthUrl: string }
      >("/api/auth/login", {
        method: "POST",
        json: { username: u, password: p, ...(code ? { totp: code } : {}) },
      });
      // حالت ۲ — درخواست کد دو مرحله‌ای
      if (d && "need2fa" in d) {
        setTwoFa({ kind: "need2fa", username: u });
        setTotp("");
        setLoading(false);
        return;
      }
      // حالت ۳ — ثبت‌نام 2FA: QR/راز نمایش داده می‌شود و ورود با اولین کد موفق کامل می‌شود
      if (d && "enroll" in d) {
        setTwoFa({ kind: "enroll", username: u, secret: d.secret, otpauthUrl: d.otpauthUrl });
        setTotp("");
        setLoading(false);
        return;
      }
      // ورود موفق — ذخیره توکن برای حالت iframe (کوکی مسدود) — در حالت عادی کوکی هم ست می‌شود
      if (d && typeof d.token === "string" && d.token) {
        setAuthToken(d.token);
      }
      // هر کاربر پس از ورود، ابتدا صفحه پیش‌فرض خود را ببیند (داشبورد/پرتال) —
      // هش جلسه قبلی (مثلاً #/settings کاربر قبل) پاک می‌شود
      try {
        window.history.replaceState(null, "", window.location.pathname + window.location.search);
      } catch { /* قدیمی‌ترین مرورگرها */ }
      setTwoFa(null);
      notifyAuthChanged("login"); // AuthGate نشست را دوباره بررسی و داشبورد را نمایش می‌دهد
    } catch (e) {
      const msg = e instanceof Error ? e.message : "خطا در ورود";
      setError(msg);
      // خطای کد نادرست — حالت 2FA حفظ می‌شود تا کاربر کد جدید وارد کند
      if (twoFa && /کد تأیید نادرست/.test(msg)) {
        setTotp("");
      } else if (/کد تأیید نادرست/.test(msg)) {
        // کد نادرست در فرایند ثبت‌نام — پاسخ خطا همراه enroll برمی‌گردد؛ فرم ثابت می‌ماند
        setTotp("");
      } else {
        setTwoFa(null);
      }
      setLoading(false);
    }
  }

  // ---------- حالت ورود دو مرحله‌ای (2FA) ----------
  if (twoFa) {
    const enroll = twoFa.kind === "enroll";
    let qr = "";
    if (enroll && twoFa.otpauthUrl) {
      try {
        qr = qrCodeSvg(twoFa.otpauthUrl, { dark: "#0f172a" });
      } catch {
        qr = ""; // متن بیش‌ازحد بلند — نمایش راز کافی است
      }
    }
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-950 via-slate-900 to-teal-900 p-4">
        <div className="w-full max-w-md">
          <div className="flex flex-col items-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-2xl shadow-teal-500/30 mb-4">
              <svg viewBox="0 0 24 24" className="w-9 h-9 text-white" fill="none" stroke="currentColor" strokeWidth="1.8">
                <rect x="3" y="11" width="18" height="10" rx="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" strokeLinecap="round" />
              </svg>
            </div>
            <h1 className="text-xl font-bold text-white text-center">ورود دو مرحله‌ای (2FA)</h1>
            <p className="text-xs text-teal-200/80 mt-1.5" dir="ltr">{twoFa.username}</p>
          </div>

          <Card className="border-white/10 bg-white/95 backdrop-blur shadow-2xl">
            <CardContent className="p-6 space-y-5">
              {error && (
                <div className="rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-sm px-4 py-3" role="alert">
                  {error}
                </div>
              )}

              {enroll ? (
                <div className="space-y-4">
                  <div className="rounded-xl border border-teal-200 bg-teal-50/60 p-4 space-y-3">
                    <p className="text-sm font-bold text-teal-900 leading-6">
                      ورود دو مرحله‌ای برای حساب شما فعال شده است — اپ احرازکننده خود را راه‌اندازی کنید:
                    </p>
                    <ol className="text-xs leading-6 text-slate-700 list-decimal mr-5 space-y-0.5">
                      <li>اپ Google Authenticator یا هر اپ احرازکننده استاندارد (Microsoft/Authy) را نصب کنید.</li>
                      <li>QR زیر را اسکن کنید یا راز را دستی وارد کنید.</li>
                      <li>کد ۶ رقمی نمایش‌داده‌شده در اپ را در کادر پایین وارد کنید.</li>
                    </ol>
                  </div>
                  {qr && (
                    <div className="flex justify-center">
                      <div
                        className="w-48 h-48 bg-white border rounded-xl p-2.5 shadow-sm [&>svg]:block [&>svg]:w-full [&>svg]:h-full"
                        dangerouslySetInnerHTML={{ __html: qr }}
                      />
                    </div>
                  )}
                  {twoFa.secret && (
                    <div className="rounded-lg border bg-slate-50 px-3 py-2 text-center">
                      <p className="text-[10px] text-muted-foreground mb-1">کلید دستی (Base32):</p>
                      <p className="font-mono text-sm tracking-wider select-all text-slate-800" dir="ltr">{twoFa.secret}</p>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-sm text-slate-700 leading-6">
                  کد ۶ رقمی نرم‌افزار احرازکننده خود را وارد کنید. کد هر ۳۰ ثانیه تغییر می‌کند.
                </p>
              )}

              <form
                className="space-y-4"
                onSubmit={(e) => {
                  e.preventDefault();
                  doLogin(twoFa.username, password, totp);
                }}
              >
                <div className="space-y-2">
                  <Label htmlFor="totp">کد تأیید (۶ رقم)</Label>
                  <Input
                    id="totp"
                    dir="ltr"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    className="text-center text-lg font-bold tracking-[0.5em] tabular-nums"
                    value={totp}
                    onChange={(e) => setTotp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                    autoFocus
                  />
                </div>
                <Button type="submit" className="w-full h-11 text-base font-semibold" disabled={loading || totp.length !== 6}>
                  {loading ? "در حال بررسی..." : enroll ? "تأیید و ورود" : "ورود به سامانه"}
                </Button>
              </form>

              <Button
                type="button"
                variant="ghost"
                className="w-full text-xs text-muted-foreground"
                disabled={loading}
                onClick={() => {
                  setTwoFa(null);
                  setTotp("");
                  setError(null);
                }}
              >
                بازگشت به فرم ورود
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // ---------- فرم ورود عادی ----------
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-teal-950 via-slate-900 to-teal-900 p-4">
      <div className="w-full max-w-md">
        {/* لوگو */}
        <div className="flex flex-col items-center mb-8">
          {brand?.logo ? (
             
            <img src={brand.logo} alt="لوگو" className="w-20 h-20 rounded-2xl object-contain bg-white/10 p-2 backdrop-blur border border-white/20 shadow-2xl mb-4" />
          ) : (
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-2xl shadow-teal-500/30 mb-4">
              <svg viewBox="0 0 24 24" className="w-11 h-11 text-white" fill="none" stroke="currentColor" strokeWidth="1.8">
                <path d="M12 2L20 6v5c0 5-3.5 8.5-8 11-4.5-2.5-8-6-8-11V6l8-4z" strokeLinejoin="round" />
                <path d="M12 8v4l3 2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          )}
          <h1 className="text-2xl font-bold text-white text-center">{brand?.title || "سامانه جامع منابع انسانی"}</h1>
        </div>

        <Card className="border-white/10 bg-white/95 backdrop-blur shadow-2xl">
          <CardContent className="p-6 space-y-5">
            {error && (
              <div className="rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-sm px-4 py-3" role="alert">
                {error}
              </div>
            )}
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                doLogin(username, password);
              }}
            >
              <div className="space-y-2">
                <Label htmlFor="username">نام کاربری</Label>
                <Input
                  id="username"
                  dir="ltr"
                  className="text-left font-medium"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  autoComplete="username"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">رمز عبور</Label>
                <Input
                  id="password"
                  type="password"
                  dir="ltr"
                  className="text-left font-medium"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete="current-password"
                />
              </div>
              <Button type="submit" className="w-full h-11 text-base font-semibold" disabled={loading}>
                {loading ? "در حال ورود..." : "ورود به سامانه"}
              </Button>
            </form>

            {(mmEnabled || ggEnabled) && (
              <div className="space-y-3">
                <div className="flex items-center gap-3 text-[11px] text-muted-foreground">
                  <span className="flex-1 border-t" />
                  یا
                  <span className="flex-1 border-t" />
                </div>
                <div className="space-y-2.5">
                  {ggEnabled && (
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full h-11 text-sm font-semibold gap-2.5 border-slate-300 text-slate-700 hover:bg-slate-50"
                      onClick={startGoogleLogin}
                    >
                      {/* لوگوی رسمی گوگل — ۴ رنگ برند */}
                      <svg viewBox="0 0 24 24" className="w-5 h-5 shrink-0">
                        <path fill="#4285F4" d="M23.5 12.3c0-.9-.1-1.5-.2-2.2H12v4.2h6.5c-.1 1.1-.8 2.7-2.4 3.8l3.7 2.9c2.2-2 3.7-5 3.7-8.7z" />
                        <path fill="#34A853" d="M12 24c3.2 0 6-1.1 8-2.9l-3.7-2.9c-1 .7-2.4 1.2-4.3 1.2-3.3 0-6.1-2.2-7.1-5.2l-3.9 3C3 21.3 7.2 24 12 24z" />
                        <path fill="#FBBC05" d="M4.9 14.2c-.2-.7-.4-1.5-.4-2.2s.1-1.5.4-2.2l-3.9-3C.4 8.3 0 10.1 0 12s.4 3.7 1 5.2l3.9-3z" />
                        <path fill="#EA4335" d="M12 4.7c2.3 0 3.9 1 4.8 1.8l3.5-3.4C18.1 1.2 15.2 0 12 0 7.2 0 3 2.7 1 6.8l3.9 3c1-3 3.8-5.1 7.1-5.1z" />
                      </svg>
                      {gg.data?.buttonLabel || "ورود با Gmail"}
                    </Button>
                  )}
                  {mmEnabled && (
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full h-11 text-sm font-semibold gap-2 border-indigo-300 text-indigo-800 hover:bg-indigo-50"
                      onClick={startMattermostLogin}
                    >
                      <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
                        <path d="M5.6 9.6 12 4l6.4 5.6v6.1c0 .8-.6 1.4-1.4 1.4H15l-3-2.4-3 2.4H7c-.8 0-1.4-.6-1.4-1.4V9.6Z" opacity="0" />
                        <path d="M12 3.2 3.8 9.9v6.4c0 1.1.9 2 2 2h3.4l2.8-2.3 2.8 2.3h3.4c1.1 0 2-.9 2-2V9.9L12 3.2Zm0 2.5 6.2 5.1v5.5c0 .3-.2.5-.5.5h-2.6L12 14.7l-3.1 2.1H6.3c-.3 0-.5-.2-.5-.5v-5.5L12 5.7Z" />
                      </svg>
                      {mm.data?.buttonLabel || "ورود با Mattermost"}
                    </Button>
                  )}
                </div>
                {ggEnabled && gg.data?.allowedDomain ? (
                  <p className="text-[10px] text-muted-foreground text-center">فقط ایمیل‌های دامنه {gg.data.allowedDomain} مجاز هستند.</p>
                ) : null}
              </div>
            )}

            {/* حساب‌های نمونه — فقط وقتی «حالت دمو» در تنظیمات فعال باشد */}
            {brand?.demoMode === true && (
              <div className="border-t border-slate-200 pt-4">
                <p className="text-xs text-muted-foreground mb-3 text-center">کاربران نمونه (برای ورود سریع کلیک کنید):</p>
                <div className="grid grid-cols-1 gap-2">
                  {DEMO_USERS.map((u) => (
                    <button
                      key={u.username}
                      type="button"
                      disabled={loading}
                      onClick={() => {
                        setUsername(u.username);
                        setPassword(u.password);
                        doLogin(u.username, u.password);
                      }}
                      className="flex items-center gap-3 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 hover:border-teal-300 transition-all px-3 py-2 text-sm text-right disabled:opacity-50"
                    >
                      <span className={`w-2.5 h-2.5 rounded-full ${u.color} shrink-0`} />
                      <span className="font-medium text-slate-700">{u.label}</span>
                      <span dir="ltr" className="mr-auto text-xs text-muted-foreground font-mono">
                        {u.username} / {u.password}
                      </span>
                    </button>
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground mt-3 text-center">حالت دمو فعال است — از «تنظیمات ← برندینگ» قابل خاموش‌کردن است.</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* نسخه نصب‌شده — از env (نصب‌کننده)؛ خالی در حالت توسعه */}
        <p className="text-[11px] text-teal-200/60 text-center tabular-nums">
          {brand?.subtitle || "مدیریت کارکنان، حقوق و دستمزد و محاسبه معکوس — سال ۱۴۰۵"}
          {brand?.version ? ` • نسخه ${toFaDigits(brand.version)}` : ""}
        </p>
      </div>
    </div>
  );
}

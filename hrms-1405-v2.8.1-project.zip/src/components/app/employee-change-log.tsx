"use client";

// ============================================================
// سابقه تغییرات پرونده کارمند — خط زمانی همه تغییرات
// (سطح، پایه حقوق، شغل، قرارداد، اطلاعات فردی، دپارتمان، ...)
// + بازگردانی هر تغییر با یک کلیک (با تأییدیه)
// ============================================================
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { api, useApi } from "@/lib/client";
import { formatDateJ, isoToJalaliStr, toFaDigits } from "@/lib/jalali";
import { History, Undo2, RotateCcw, User, Info } from "lucide-react";

// انواع از کتابخانه سرور — فقط type (در بیلد حذف می‌شود، بدون کشیدن Prisma به کلاینت)
import type { ChangeEntry, EmployeeChangeLogRecord } from "@/lib/employee-changelog";

// برچسب منشأها (نسخه کلاینت — هم‌ارز CHANGE_SOURCE_LABELS سرور)
const SOURCE_LABELS: Record<string, string> = {
  CREATE: "ثبت اولیه پرونده",
  EDIT: "ویرایش پرونده",
  IMPORT: "ایمپورت اکسل",
  REVERT: "بازگردانی تغییر",
  SALARY: "اعمال تغییر حقوق",
};

const SOURCE_BADGE: Record<string, string> = {
  CREATE: "bg-teal-100 text-teal-700 hover:bg-teal-100",
  EDIT: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  IMPORT: "bg-violet-100 text-violet-700 hover:bg-violet-100",
  REVERT: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  SALARY: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
};

function timeFa(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  return toFaDigits(`${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`);
}

interface Props {
  employeeId: string;
  canRevert: boolean; // مجوز employees:edit
  onReverted?: () => void; // بازخوانی پرونده پس از بازگردانی
}

export function EmployeeChangeLogTimeline({ employeeId, canRevert, onReverted }: Props) {
  const logs = useApi<{ logs: EmployeeChangeLogRecord[]; stats: { total: number; reverted: number } }>(
    `/api/employee-changelog?employeeId=${employeeId}&limit=200`,
    [employeeId]
  );
  const [confirming, setConfirming] = useState<EmployeeChangeLogRecord | null>(null);
  const [reverting, setReverting] = useState(false);
  const { toast } = useToast();

  async function doRevert() {
    if (!confirming) return;
    setReverting(true);
    try {
      const res = await api<{ ok: boolean; revertedFields: string[] }>(`/api/employee-changelog/${confirming.id}/revert`, {
        method: "POST",
      });
      toast({
        title: "تغییر بازگردانی شد",
        description: `${res.revertedFields.length > 0 ? `فیلدهای بازگردانی‌شده: ${res.revertedFields.join("، ")}` : "پرونده به حالت قبل بازگشت."}`,
      });
      setConfirming(null);
      logs.refetch();
      onReverted?.();
    } catch (e) {
      toast({ title: "بازگردانی انجام نشد", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setReverting(false);
    }
  }

  if (logs.loading) {
    return <div className="space-y-2">{[0, 1, 2].map((i) => <Skeleton key={i} className="h-20 rounded-xl" />)}</div>;
  }
  if (logs.error) {
    return <div className="rounded-xl bg-rose-50 border border-rose-200 text-rose-700 p-4 text-sm">{logs.error}</div>;
  }

  const entries = logs.data?.logs || [];
  if (entries.length === 0) {
    return (
      <div className="py-10 text-center">
        <History className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-muted-foreground">تغییری برای این کارمند ثبت نشده است</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* آمار */}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <Badge className="bg-slate-100 text-slate-600 hover:bg-slate-100">
          {toFaDigits(logs.data?.stats.total || 0)} تغییر ثبت‌شده
        </Badge>
        {(logs.data?.stats.reverted || 0) > 0 && (
          <Badge className="bg-amber-50 text-amber-700 hover:bg-amber-50 border border-amber-200">
            {toFaDigits(logs.data?.stats.reverted || 0)} بازگردانی‌شده
          </Badge>
        )}
        <span className="text-muted-foreground flex items-center gap-1">
          <Info className="w-3.5 h-3.5" />
          هر تغییری که در پرونده این کارمند انجام شده — با امکان بازگردانی
        </span>
      </div>

      {/* خط زمانی */}
      <div className="space-y-3">
        {entries.map((l) => {
          const reverted = !!l.revertedAt;
          const isCreate = l.source === "CREATE";
          const canRevertThis = canRevert && !reverted && !isCreate;
          return (
            <div
              key={l.id}
              className={`rounded-xl border p-4 transition-colors ${
                reverted
                  ? "border-slate-200 bg-slate-50/60 opacity-70"
                  : l.source === "REVERT"
                  ? "border-amber-200 bg-amber-50/40"
                  : "border-slate-200 hover:border-teal-200"
              }`}
            >
              {/* سربرگ */}
              <div className="flex flex-wrap items-center gap-2 mb-3">
                <Badge className={SOURCE_BADGE[l.source] || "bg-slate-100 text-slate-600"}>
                  {SOURCE_LABELS[l.source] || l.source}
                </Badge>
                <span className="text-xs text-muted-foreground tabular-nums">
                  {formatDateJ(isoToJalaliStr(l.performedAt))} — {timeFa(l.performedAt)}
                </span>
                <span className="text-xs text-muted-foreground flex items-center gap-1">
                  <User className="w-3 h-3" /> {l.performedByName || "سیستم"}
                </span>
                {reverted && (
                  <Badge className="bg-slate-200 text-slate-500 hover:bg-slate-200">
                    <RotateCcw className="w-3 h-3 ml-1" />
                    بازگردانی‌شده{l.revertedByName ? ` (${l.revertedByName})` : ""}
                  </Badge>
                )}
              </div>

              {/* فیلدهای تغییر */}
              <div className="space-y-1.5">
                {l.changes.map((c, i) => (
                  <div key={`${l.id}-${c.field}-${i}`} className="flex flex-wrap items-baseline gap-x-2 text-sm">
                    <span className="text-xs text-muted-foreground min-w-[110px]">{c.label}:</span>
                    {isCreate ? (
                      <span className="font-medium">{c.toDisplay}</span>
                    ) : (
                      <>
                        <span className="text-slate-500 line-through decoration-slate-300">{c.fromDisplay}</span>
                        <span className="text-slate-400">←</span>
                        <span className={`font-medium ${c.kind === "money" ? "tabular-nums text-teal-700" : ""}`}>
                          {c.toDisplay}
                        </span>
                      </>
                    )}
                  </div>
                ))}
              </div>

              {/* دلیل */}
              {l.reason && <p className="text-[11px] text-muted-foreground mt-2">دلیل: {l.reason}</p>}

              {/* بازگردانی */}
              {canRevertThis && (
                <div className="mt-3 pt-2 border-t border-dashed">
                  <Button size="sm" variant="outline" className="gap-1.5 h-7 text-xs" onClick={() => setConfirming(l)}>
                    <Undo2 className="w-3.5 h-3.5" /> بازگردانی این تغییر
                  </Button>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* تأییدیه بازگردانی */}
      <AlertDialog open={!!confirming} onOpenChange={(v) => !v && setConfirming(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>بازگردانی این تغییر؟</AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-3 leading-6">
                <p>
                  مقادیر زیر به حالت <b>قبل از این تغییر</b> برمی‌گردند
                  {confirming?.source === "REVERT" ? " (بازگردانیِ بازگردانی — تغییر دوباره اعمال می‌شود)" : ""}:
                </p>
                <div className="rounded-lg bg-slate-50 border border-slate-200 p-3 space-y-1.5 max-h-56 overflow-y-auto">
                  {(confirming?.changes || []).map((c, i) => (
                    <div key={i} className="flex flex-wrap items-baseline gap-x-2 text-sm">
                      <span className="text-xs text-muted-foreground min-w-[110px]">{c.label}:</span>
                      <span className="text-slate-500 line-through decoration-slate-300">{c.toDisplay}</span>
                      <span className="text-slate-400">←</span>
                      <span className="font-medium text-teal-700">{c.fromDisplay}</span>
                    </div>
                  ))}
                </div>
                <p className="text-[11px] text-muted-foreground">
                  این عملیات در «سابقه تغییرات» به‌صورت رکورد بازگردانی ثبت می‌شود و خودش نیز قابل بازگردانی است.
                  {confirming?.changes.some((c) => ["baseSalary", "overtimeHours", "jobGradeId"].includes(c.field))
                    ? " تغییر حقوق در آرشیو تغییرات حقوق نیز ثبت می‌شود."
                    : ""}
                </p>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction
              disabled={reverting}
              onClick={(e) => {
                e.preventDefault();
                void doRevert();
              }}
              className="bg-amber-600 hover:bg-amber-700 gap-1.5"
            >
              <Undo2 className="w-4 h-4" />
              {reverting ? "در حال بازگردانی..." : "بله، بازگردانی کن"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

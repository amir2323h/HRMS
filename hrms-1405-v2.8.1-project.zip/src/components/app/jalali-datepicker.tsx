"use client";

// ============================================================
// انتخاب‌گر تاریخ جلالی — کامپوننت بومی، بدون وابستگی خارجی
// ============================================================
import { useMemo, useState } from "react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, CalendarDays } from "lucide-react";
import {
  JALALI_MONTHS, JALALI_WEEKDAYS_SHORT, daysInJalaliMonth, todayJalali,
  parseJalali, formatJStr, jalaliWeekdayIndex, toFaDigits,
} from "@/lib/jalali";

export function JalaliDatePicker({ value, onChange, placeholder = "۱۴۰۵/۰۱/۰۱", disabled }: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const today = todayJalali();
  const parsed = parseJalali(value);
  const [view, setView] = useState(() => ({ jy: parsed?.jy || today.jy, jm: parsed?.jm || today.jm }));

  const grid = useMemo(() => {
    const first = view.jm === 1 && 1;
    void first;
    const days = daysInJalaliMonth(view.jy, view.jm);
    // روز هفته اول ماه (شنبه=0)
    const startIdx = jalaliWeekdayIndex(view.jy, view.jm, 1);
    const cells: (number | null)[] = Array.from({ length: startIdx }, () => null);
    for (let d = 1; d <= days; d++) cells.push(d);
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }, [view]);

  const years = useMemo(() => {
    const ys: number[] = [];
    for (let y = today.jy - 40; y <= today.jy + 5; y++) ys.push(y);
    return ys;
  }, [today.jy]);

  function select(d: number) {
    onChange(formatJStr(view.jy, view.jm, d));
    setOpen(false);
  }

  function shiftMonth(delta: number) {
    let { jy, jm } = view;
    jm += delta;
    if (jm < 1) { jm = 12; jy -= 1; }
    if (jm > 12) { jm = 1; jy += 1; }
    setView({ jy, jm });
  }

  const display = parsed ? toFaDigits(formatJStr(parsed.jy, parsed.jm, parsed.jd)) : "";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          disabled={disabled}
          className="w-full justify-start font-normal h-10 text-right"
          type="button"
        >
          <CalendarDays className="w-4 h-4 text-muted-foreground shrink-0 ml-0 mr-2" />
          {display ? <span className="tabular-nums">{display}</span> : <span className="text-muted-foreground">{placeholder}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0 z-[60]" align="start">
        <div className="p-3" dir="rtl">
          {/* نوار ناوبری ماه */}
          <div className="flex items-center gap-2 mb-3">
            <button type="button" className="p-1.5 rounded-lg hover:bg-slate-100" onClick={() => shiftMonth(-1)} aria-label="ماه قبل">
              <ChevronRight className="w-4 h-4" />
            </button>
            <select
              className="text-sm font-medium bg-transparent border rounded-md px-2 py-1 cursor-pointer focus:outline-none focus:ring-1 focus:ring-teal-500 tabular-nums"
              value={view.jm}
              onChange={(e) => setView((v) => ({ ...v, jm: +e.target.value }))}
              aria-label="ماه"
            >
              {JALALI_MONTHS.map((m, i) => (
                <option key={m} value={i + 1}>{toFaDigits(String(i + 1).padStart(2, "0"))}</option>
              ))}
            </select>
            <select
              className="text-sm font-medium bg-transparent border rounded-md px-2 py-1 cursor-pointer focus:outline-none focus:ring-1 focus:ring-teal-500 tabular-nums"
              value={view.jy}
              onChange={(e) => setView((v) => ({ ...v, jy: +e.target.value }))}
              aria-label="سال"
            >
              {years.map((y) => (
                <option key={y} value={y}>{toFaDigits(y)}</option>
              ))}
            </select>
            <button type="button" className="p-1.5 rounded-lg hover:bg-slate-100 mr-auto" onClick={() => shiftMonth(1)} aria-label="ماه بعد">
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
          {/* روزهای هفته */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {JALALI_WEEKDAYS_SHORT.map((d, i) => (
              <div key={i} className={`text-center text-[11px] font-medium py-1 ${i === 6 ? "text-rose-500" : "text-slate-400"}`}>{d}</div>
            ))}
          </div>
          {/* روزها */}
          <div className="grid grid-cols-7 gap-1">
            {grid.map((d, i) => {
              if (d === null) return <div key={i} />;
              const isToday = today.jy === view.jy && today.jm === view.jm && today.jd === d;
              const isSelected = parsed && parsed.jy === view.jy && parsed.jm === view.jm && parsed.jd === d;
              const isFriday = i % 7 === 6;
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => select(d)}
                  className={`h-8 w-9 text-sm rounded-lg tabular-nums transition-colors ${
                    isSelected
                      ? "bg-teal-600 text-white font-bold shadow"
                      : isToday
                        ? "bg-teal-100 text-teal-800 font-bold"
                        : isFriday
                          ? "text-rose-500 hover:bg-rose-50"
                          : "text-slate-700 hover:bg-slate-100"
                  }`}
                >
                  {toFaDigits(d)}
                </button>
              );
            })}
          </div>
          <div className="flex gap-2 mt-3 pt-2 border-t">
            <Button variant="outline" size="sm" className="h-8 text-xs flex-1" onClick={() => { onChange(formatJStr(today.jy, today.jm, today.jd)); setOpen(false); }}>
              امروز
            </Button>
            <Button variant="ghost" size="sm" className="h-8 text-xs flex-1" onClick={() => { onChange(""); setOpen(false); }}>
              پاک کردن
            </Button>
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
}

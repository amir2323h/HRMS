"use client";

// ============================================================
// دیالوگ ایمپورت اکسل — عمومی برای مشاغل، کاربران و ...
// مراحل: انتخاب فایل → پیش‌نمایش و اعتبارسنجی → ایمپورت → گزارش
// ============================================================
import { useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { FileSpreadsheet, Upload, Download, CheckCircle2, AlertTriangle, Loader2, RefreshCw } from "lucide-react";
import { api } from "@/lib/client";
import { readExcelRows, downloadExcel } from "@/lib/excel";
import { toFaDigits } from "@/lib/jalali";

export interface ImportRowResult<T> {
  data: T;
  errors: string[];
}

export interface ImportRowOutcome {
  name: string;
  nationalId?: string;
  personnelCode?: string;
  action: "created" | "updated";
  changedFields?: string[];
}

export interface ImportOutcome {
  created: number;
  updated: number;
  failed: number;
  errors: string[];
  results?: ImportRowOutcome[];
}

interface Props<T> {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  description: string;
  endpoint: string;
  templateFilename: string;
  sheetName: string;
  headers: string[];
  sampleRows: Record<string, unknown>[];
  parseRow: (row: Record<string, unknown>) => ImportRowResult<T>;
  onImported: (outcome: ImportOutcome) => void;
}

export function ExcelImportDialog<T>({ open, onOpenChange, title, description, endpoint, templateFilename, sheetName, headers, sampleRows, parseRow, onImported }: Props<T>) {
  const { toast } = useToast();
  const fileRef = useRef<HTMLInputElement>(null);
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [parsed, setParsed] = useState<ImportRowResult<T>[]>([]);
  const [rowErrors, setRowErrors] = useState<string[]>([]);
  const [importing, setImporting] = useState(false);
  const [outcome, setOutcome] = useState<ImportOutcome | null>(null);

  const validRows = parsed.filter((p) => p.errors.length === 0);

  function reset() {
    setRows([]);
    setParsed([]);
    setRowErrors([]);
    setOutcome(null);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function onPickFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setOutcome(null);
    try {
      const raw = await readExcelRows(file);
      if (raw.length === 0) {
        toast({ title: "فایل خالی است", description: "هیچ ردیفی در فایل اکسل پیدا نشد.", variant: "destructive" });
        reset();
        return;
      }
      const results = raw.map((r) => parseRow(r));
      const errs: string[] = [];
      results.forEach((r, i) => {
        if (r.errors.length) errs.push(`ردیف ${toFaDigits(i + 2)}: ${r.errors.join(" ")}`);
      });
      setRows(raw);
      setParsed(results);
      setRowErrors(errs);
    } catch (err) {
      toast({ title: "خطا در خواندن فایل", description: err instanceof Error ? err.message : "", variant: "destructive" });
      reset();
    }
  }

  async function doImport() {
    if (validRows.length === 0) return;
    setImporting(true);
    try {
      const res = await api<ImportOutcome>(endpoint, {
        method: "POST",
        json: { rows: validRows.map((r) => r.data) },
      });
      setOutcome(res);
      onImported(res);
      if (res.failed === 0) {
        toast({
          title: "ایمپورت کامل شد",
          description:
            res.updated > 0
              ? `${toFaDigits(res.created)} مورد جدید ثبت و ${toFaDigits(res.updated)} مورد موجود (کد ملی تکراری) به‌روزرسانی شد.`
              : `${toFaDigits(res.created)} مورد جدید ثبت شد.`,
        });
      } else {
        toast({ title: "ایمپورت با خطا انجام شد", description: `${toFaDigits(res.failed)} ردیف ناموفق — جزئیات در گزارش پایین.`, variant: "destructive" });
      }
    } catch (e) {
      toast({ title: "خطا در ایمپورت", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setImporting(false);
    }
  }

  function downloadTpl() {
    downloadExcel(templateFilename, sheetName, sampleRows);
    void headers;
  }

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) reset(); }}>
      <DialogContent className="sm:max-w-[50.4rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><FileSpreadsheet className="w-5 h-5 text-teal-600" /> {title}</DialogTitle>
          <p className="text-xs text-muted-foreground leading-5 mt-1">{description}</p>
        </DialogHeader>

        <div className="space-y-4">
          {/* قالب نمونه */}
          <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-3.5 space-y-2.5">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <div>
                <p className="text-xs font-bold">۱. دریافت فایل قالب</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">ستون‌های موردنیاز: {headers.join(" | ")}</p>
              </div>
              <Button size="sm" variant="outline" className="gap-1.5" onClick={downloadTpl}>
                <Download className="w-3.5 h-3.5" /> دانلود قالب
              </Button>
            </div>
          </div>

          {/* انتخاب فایل */}
          <div className="rounded-xl border border-slate-200 p-3.5 space-y-2.5">
            <p className="text-xs font-bold">۲. انتخاب فایل اکسل</p>
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="block w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-medium file:bg-teal-50 file:text-teal-700 hover:file:bg-teal-100 cursor-pointer"
              onChange={onPickFile}
            />
          </div>

          {/* پیش‌نمایش */}
          {rows.length > 0 && !outcome && (
            <div className="rounded-xl border border-slate-200 p-3.5 space-y-2">
              <p className="text-xs font-bold">۳. پیش‌نمایش و اعتبارسنجی</p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-slate-100 text-slate-700 hover:bg-slate-100">کل ردیف‌ها: {toFaDigits(rows.length)}</Badge>
                <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">معتبر: {toFaDigits(validRows.length)}</Badge>
                {rowErrors.length > 0 && <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100">نامعتبر: {toFaDigits(rowErrors.length)}</Badge>}
              </div>
              {rowErrors.length > 0 && (
                <div className="rounded-lg bg-rose-50 border border-rose-200 p-2.5 max-h-32 overflow-y-auto">
                  {rowErrors.slice(0, 8).map((e, i) => (
                    <p key={i} className="text-[11px] text-rose-700 leading-5 flex items-start gap-1">
                      <AlertTriangle className="w-3 h-3 mt-1 shrink-0" /> {e}
                    </p>
                  ))}
                  {rowErrors.length > 8 && <p className="text-[11px] text-rose-500 mt-1">... و {toFaDigits(rowErrors.length - 8)} خطای دیگر</p>}
                </div>
              )}
              {validRows.length > 0 && (
                <p className="text-[11px] text-muted-foreground">فقط {toFaDigits(validRows.length)} ردیف معتبر ایمپورت می‌شوند.</p>
              )}
            </div>
          )}

          {/* گزارش نتیجه */}
          {outcome && (
            <div className="rounded-xl border border-slate-200 p-3.5 space-y-2">
              <p className="text-xs font-bold flex items-center gap-1.5">
                {outcome.failed === 0 ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertTriangle className="w-4 h-4 text-amber-600" />}
                گزارش ایمپورت
              </p>
              <div className="flex flex-wrap gap-2">
                <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">ایجادشده: {toFaDigits(outcome.created)}</Badge>
                <Badge className="bg-sky-100 text-sky-700 hover:bg-sky-100">به‌روزرسانی‌شده: {toFaDigits(outcome.updated)}</Badge>
                {outcome.failed > 0 && <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100">ناموفق: {toFaDigits(outcome.failed)}</Badge>}
              </div>
              {(outcome.updated > 0 || outcome.created > 0) && (
                <p className="text-[11px] text-muted-foreground leading-5">
                  ردیف‌ها بر اساس کد ملی تطبیق داده می‌شوند — کد ملی موجود = به‌روزرسانی همان پرونده (نه ثبت تکراری).
                </p>
              )}
              {/* جزئیات به‌روزرسانی — پیام صریح «چه کسی به‌روزرسانی شد» */}
              {(outcome.results || []).filter((r) => r.action === "updated").length > 0 && (
                <div className="rounded-lg bg-sky-50 border border-sky-200 p-2.5 max-h-36 overflow-y-auto">
                  <p className="text-[11px] font-bold text-sky-800 mb-1">کارکنان به‌روزرسانی‌شده (کد ملی از قبل موجود):</p>
                  {(outcome.results || []).filter((r) => r.action === "updated").map((r, i) => (
                    <p key={i} className="text-[11px] text-sky-700 leading-5 flex items-start gap-1">
                      <RefreshCw className="w-3 h-3 mt-1 shrink-0" />
                      <span>
                        <b>{r.name}</b> ({r.personnelCode || r.nationalId})
                        {r.changedFields && r.changedFields.length > 0 ? <> — تغییر: {r.changedFields.join("، ")}</> : " — بدون تغییر مادی"}
                      </span>
                    </p>
                  ))}
                </div>
              )}
              {(outcome.results || []).filter((r) => r.action === "created").length > 0 && (
                <div className="rounded-lg bg-emerald-50 border border-emerald-200 p-2.5 max-h-28 overflow-y-auto">
                  <p className="text-[11px] font-bold text-emerald-800 mb-1">کارکنان جدید:</p>
                  {(outcome.results || []).filter((r) => r.action === "created").map((r, i) => (
                    <p key={i} className="text-[11px] text-emerald-700 leading-5">{r.name} ({r.personnelCode})</p>
                  ))}
                </div>
              )}
              {outcome.errors.length > 0 && (
                <div className="rounded-lg bg-rose-50 border border-rose-200 p-2.5 max-h-32 overflow-y-auto">
                  {outcome.errors.slice(0, 8).map((e, i) => (
                    <p key={i} className="text-[11px] text-rose-700 leading-5">{e}</p>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="mt-2 gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>بستن</Button>
          <Button onClick={doImport} disabled={importing || validRows.length === 0} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            {importing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
            {importing ? "در حال ایمپورت..." : `ایمپورت ${validRows.length > 0 ? `(${toFaDigits(validRows.length)} ردیف)` : ""}`}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

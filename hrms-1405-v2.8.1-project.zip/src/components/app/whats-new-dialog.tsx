"use client";

// ============================================================
// پاپ‌آپ «تازه‌های نسخه» — آخرین تغییرات محصول
// نمایش هدف‌مند: فقط کاربران هدف (نقش/کاربر انتخابی مدیر) و تا وقتی
// نسخه اطلاعیه را ندیده باشند (POST /api/changelog ثبت «دیده شد»)
// ============================================================
import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, CheckCircle2, ArrowUpCircle, Wrench, PartyPopper } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";
import { useBranding } from "./use-branding";

interface ChangelogItem {
  tag: "NEW" | "IMPROVED" | "FIXED";
  title: string;
  desc: string;
}

interface ChangelogData {
  version: string;
  title: string;
  items: ChangelogItem[];
  currentVersion?: string;
}

const TAG_META: Record<ChangelogItem["tag"], { label: string; icon: typeof CheckCircle2; cls: string }> = {
  NEW: { label: "جدید", icon: Sparkles, cls: "bg-teal-100 text-teal-700" },
  IMPROVED: { label: "بهبود", icon: ArrowUpCircle, cls: "bg-sky-100 text-sky-700" },
  FIXED: { label: "رفع اشکال", icon: Wrench, cls: "bg-amber-100 text-amber-700" },
};

export function WhatsNewDialog() {
  const { data } = useApi<{ show: boolean; data: ChangelogData | null }>("/api/changelog");
  const [open, setOpen] = useState(false);
  const [closing, setClosing] = useState(false);
  const { brand } = useBranding();

  // باز شدن خودکار وقتی سرور گفت «نمایش بده» — فقط یک بار در هر نشست
  useEffect(() => {
    if (data?.show && data.data && !closing) setOpen(true);
  }, [data, closing]);

  async function dismiss() {
    setClosing(true);
    setOpen(false);
    try {
      await api("/api/changelog", { method: "POST" });
    } catch {
      /* خطای شبکه — دفعه بعد دوباره نمایش داده می‌شود */
    }
  }

  const info = data?.data;
  if (!info) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) dismiss(); }}>
      <DialogContent className="sm:max-w-[34rem] p-0 overflow-hidden gap-0" dir="rtl">
        {/* سربرگ گرادیانی */}
        <div className="relative bg-gradient-to-bl from-teal-600 via-teal-700 to-cyan-800 px-6 pt-7 pb-6 text-white overflow-hidden">
          <div className="absolute -left-10 -top-10 w-40 h-40 rounded-full bg-white/10" aria-hidden="true" />
          <div className="absolute left-16 top-14 w-16 h-16 rounded-full bg-white/5" aria-hidden="true" />
          <div className="relative flex items-start gap-4">
            {brand?.logo ? (
              <img src={brand.logo} alt="لوگو" className="w-12 h-12 rounded-xl object-contain bg-white/15 p-1.5 shrink-0 backdrop-blur" />
            ) : (
              <div className="w-12 h-12 rounded-xl bg-white/15 flex items-center justify-center shrink-0 backdrop-blur">
                <PartyPopper className="w-6 h-6 text-teal-100" />
              </div>
            )}
            <div className="min-w-0">
              <DialogTitle className="text-lg font-bold leading-7 text-white">{info.title}</DialogTitle>
              <p className="text-xs text-teal-100/90 mt-1">
                نسخه {toFaDigits(info.version)} منتشر شد{info.currentVersion && info.currentVersion !== info.version ? ` — نسخه نصب‌شده: ${toFaDigits(info.currentVersion)}` : ""}
              </p>
            </div>
          </div>
        </div>

        {/* فهرست تغییرات */}
        <div className="px-6 py-5 max-h-[46vh] overflow-y-auto space-y-3">
          {info.items.length === 0 && (
            <p className="text-sm text-muted-foreground text-center py-6">تغییری در این نسخه ثبت نشده است.</p>
          )}
          {info.items.map((it, i) => {
            const meta = TAG_META[it.tag] || TAG_META.NEW;
            const Icon = meta.icon;
            return (
              <div key={i} className="flex gap-3 rounded-xl border bg-slate-50/60 p-3.5">
                <div className="w-9 h-9 rounded-lg bg-white border flex items-center justify-center shrink-0">
                  <Icon className={`w-4.5 h-4.5 ${it.tag === "NEW" ? "text-teal-600" : it.tag === "IMPROVED" ? "text-sky-600" : "text-amber-600"}`} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge className={`${meta.cls} hover:${meta.cls} text-[10px] px-1.5 py-0`}>{meta.label}</Badge>
                    <p className="text-sm font-bold text-slate-800 leading-6">{it.title}</p>
                  </div>
                  {it.desc && <p className="text-xs text-muted-foreground leading-6 mt-1">{it.desc}</p>}
                </div>
              </div>
            );
          })}
        </div>

        {/* پابرگ */}
        <div className="px-6 py-4 border-t bg-white flex items-center justify-center">
          <Button onClick={dismiss} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            <CheckCircle2 className="w-4 h-4" /> متوجه شدم
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

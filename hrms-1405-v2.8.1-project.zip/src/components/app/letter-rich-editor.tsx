"use client";

// ============================================================
// ادیتور متن غنی «نامه دستی» — پشتیبانی جدول راست‌به‌چپ
//  • درج جدول با تعداد ستون/سطر دلخواه + عنوان جدول + تیتر هر ستون
//    (قابل‌ویرایش در فرم درج و همچنین در خود جدول پس از درج)
//  • شماره‌گذاری خودکار ستون «ردیف» (اولین ستون = منتهی‌الیه راست)
//  • افزودن/حذف ردیف و ستون روی جدول زیر مکان‌نما
//  • چسباندن از اکسل/ورد/گوگل‌شیت: جدول HTML پاک‌سازی و درج می‌شود؛
//    متن ساده جداشده با Tab به جدول تبدیل می‌شود.
//  • قالب‌بندی مقدماتی: درشت/مورب/زیرخط + پاک‌کردن قالب
// همه‌چیز با لیست سفید (src/lib/rich-html) پاک‌سازی می‌شود — هم موقع
// درج (کلاینت) و هم موقع ذخیره (سرور).
// ============================================================

import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { sanitizeLetterHtml, htmlToPlainText } from "@/lib/rich-html";
import {
  Bold, Italic, Underline, Eraser, Table2, Rows3, Columns3, Trash2,
  ListOrdered, Plus, Minus, IndentIncrease,
} from "lucide-react";

/** استایل مشترک محتوای غنی (ادیتور + پیش‌نمایش) — مطابق قالب چاپی نامه
 *  فونت متن: B Nazanin + جفت لاتین (کلاس letter-body-font از globals.css) */
const LETTER_RICH_CSS = `
.lre { line-height: 2.2; font-size: 13px; color: #1f2937; font-family: 'B Nazanin', 'LetterLatin', 'Vazirmatn', serif; }
.lre:empty::before { content: attr(data-ph); color: #94a3b8; }
.lre p { margin: 0 0 8px; }
.lre ul, .lre ol { margin: 4px 18px 10px 0; padding-right: 14px; }
.lre li { margin-bottom: 2px; }
.lre b, .lre strong { font-weight: 700; }
.lre table { direction: rtl; width: 100%; border-collapse: collapse; margin: 6px 0 12px; border: 1px solid #c6c6c6; }
.lre thead th { background: #dcdcdc; font-weight: 700; font-size: 12px; padding: 5px 8px; border: 1px solid #bfbfbf; text-align: center; }
.lre td { font-size: 12px; padding: 4px 8px; border: 1px solid #cccccc; vertical-align: middle; min-width: 24px; }
.lre td:empty::after, .lre th:empty::after { content: "\\2003"; }
.lre blockquote { border-right: 3px solid #cbd5e1; margin: 6px 0 8px; padding: 2px 10px 2px 0; color: #475569; }
.lre h3, .lre h4 { font-weight: 700; margin: 8px 0 6px; }
`;

export function LetterRichStyles() {
  return <style dangerouslySetInnerHTML={{ __html: LETTER_RICH_CSS }} />;
}

// ---------- ابزارهای جدول (روی DOM ادیتور) ----------

function closestTag(el: Node | null, tag: string): HTMLElement | null {
  let n: Node | null = el;
  while (n && n !== document.body) {
    if (n instanceof HTMLElement && n.tagName.toLowerCase() === tag) return n;
    n = n.parentNode;
  }
  return null;
}

/** سلول و جدول زیر مکان‌نمای فعلی */
function cellContext(root: HTMLElement): { table: HTMLTableElement; row: HTMLTableRowElement; cell: HTMLTableCellElement } | null {
  const sel = window.getSelection();
  if (!sel || !sel.anchorNode || !root.contains(sel.anchorNode)) return null;
  const cell = closestTag(sel.anchorNode, "td") || closestTag(sel.anchorNode, "th");
  if (!cell) return null;
  const row = closestTag(cell, "tr");
  const table = closestTag(cell, "table");
  if (!row || !table) return null;
  return { table: table as HTMLTableElement, row: row as HTMLTableRowElement, cell: cell as HTMLTableCellElement };
}

const NBSP = "\u00a0";

function makeCell(tag: "td" | "th", text: string): HTMLTableCellElement {
  const c = document.createElement(tag);
  c.innerHTML = text || NBSP;
  return c;
}

/** اگر اولین ستون سربرگ جدول «ردیف» باشد، سلول‌های آن را ۱..n بازشماره می‌کند */
function renumberRows(table: HTMLTableElement) {
  const header = table.querySelector("thead tr th");
  if (!header || (header.textContent || "").trim() !== "ردیف") return;
  const rows = [...table.querySelectorAll("tbody tr")];
  rows.forEach((tr, i) => {
    const first = tr.querySelector("td");
    if (first) first.innerHTML = String(i + 1);
  });
}

function exec(cmd: string, value?: string) {
  try {
    document.execCommand(cmd, false, value);
  } catch { /* noop */ }
}

// ---------- ادیتور ----------

export function LetterRichEditor({
  value,
  onChange,
  placeholder = "با سلام و احترام،…",
  minHeight = 190,
}: {
  value: string;
  onChange: (html: string, plain: string) => void;
  placeholder?: string;
  minHeight?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const inTableRef = useRef(false);
  const [inTable, setInTable] = useState(false);
  const [tableForm, setTableForm] = useState(false);
  const [cols, setCols] = useState(3);
  const [rows, setRows] = useState(3);
  const [withHeader, setWithHeader] = useState(true);
  const [autoNumber, setAutoNumber] = useState(true);
  const [tableTitle, setTableTitle] = useState("");
  /** تیتر هر ستون — قابل‌ویرایش؛ پس از درج هم سلول‌های سربرگ قابل ویرایش‌اند */
  const [colTitles, setColTitles] = useState<string[]>(["", "", ""]);

  function setColsSafe(n: number) {
    const c = Math.min(12, Math.max(1, n || 1));
    setCols(c);
    // آرایه متراکم با طول c — گسترش با .length حفره می‌سازد و map آن‌ها را رد می‌کند
    setColTitles((t) => Array.from({ length: c }, (_, i) => t[i] || ""));
  }

  // مقدار اولیه — فقط یک بار (ادیتور uncontrolled تا مکان‌نما نپرد)
  useEffect(() => {
    if (ref.current && !ref.current.innerHTML) {
      ref.current.innerHTML = value || "";
    }
  }, []);

  // همگام‌سازی مقدار بیرونی وقتی ادیتور فوکوس نیست (مثلاً ریست فرم)
  useEffect(() => {
    if (ref.current && document.activeElement !== ref.current && ref.current.innerHTML !== (value || "")) {
      ref.current.innerHTML = value || "";
    }
  }, [value]);

  function pushChange() {
    const html = ref.current?.innerHTML || "";
    onChange(html, htmlToPlainText(html));
  }

  function refreshCtx() {
    const ctx = cellContext(ref.current!);
    inTableRef.current = !!ctx;
    setInTable((prev) => prev !== !!ctx ? !!ctx : prev);
  }

  function run(fn: () => void) {
    ref.current?.focus();
    fn();
    pushChange();
    refreshCtx();
  }

  // ---------- درج جدول ----------
  function buildTableHtml(): string {
    const headerCells: string[] = [];
    if (autoNumber) headerCells.push("<th>ردیف</th>");
    for (let c = 0; c < cols; c++) {
      const t = (colTitles[c] || "").trim();
      headerCells.push(`<th>${t ? escHtml(t) : NBSP}</th>`);
    }
    const bodyRows: string[] = [];
    for (let r = 0; r < rows; r++) {
      const cells: string[] = [];
      if (autoNumber) cells.push(`<td>${r + 1}</td>`);
      for (let c = 0; c < cols; c++) cells.push(`<td>${NBSP}</td>`);
      bodyRows.push(`<tr>${cells.join("")}</tr>`);
    }
    const caption = tableTitle.trim()
      ? `<p><b>${escHtml(tableTitle.trim())}</b></p>`
      : "";
    return `${caption}<table dir="rtl">${withHeader ? `<thead><tr>${headerCells.join("")}</tr></thead>` : ""}<tbody>${bodyRows.join("")}</tbody></table><p><br /></p>`;
  }

  function insertTable() {
    setTableForm(false);
    const html = buildTableHtml();
    run(() => {
      const sel = window.getSelection();
      const hasCaret = sel && ref.current!.contains(sel.anchorNode);
      if (!hasCaret) {
        // مکان‌نما داخل ادیتور نیست → درج در انتها
        ref.current!.insertAdjacentHTML("beforeend", html);
      } else {
        exec("insertHTML", html);
      }
    });
  }

  // ---------- عملیات ردیف/ستون ----------
  function currentCtx() {
    return cellContext(ref.current!);
  }

  function addRow(before: boolean) {
    const ctx = currentCtx();
    if (!ctx) return;
    run(() => {
      const tr = document.createElement("tr");
      const n = ctx.row.cells.length;
      for (let i = 0; i < n; i++) tr.appendChild(makeCell("td", ""));
      ctx.row.parentNode!.insertBefore(tr, before ? ctx.row : ctx.row.nextSibling);
      renumberRows(ctx.table);
    });
  }

  function addCol(visuallyRight: boolean) {
    const ctx = currentCtx();
    if (!ctx) return;
    run(() => {
      const idx = ctx.cell.cellIndex + (visuallyRight ? 0 : 1); // ستون ۰ = منتهی‌الیه راست
      const allRows = [...ctx.table.querySelectorAll("tr")];
      for (const tr of allRows) {
        const refCell = tr.cells[Math.min(idx, tr.cells.length - 1)];
        const cell = makeCell(tr.parentElement!.tagName.toLowerCase() === "thead" ? "th" : "td", "");
        if (refCell) tr.insertBefore(cell, visuallyRight ? refCell : refCell.nextSibling);
        else tr.appendChild(cell);
      }
    });
  }

  function delRow() {
    const ctx = currentCtx();
    if (!ctx) return;
    run(() => {
      const body = ctx.table.querySelector("tbody");
      if (body && body.rows.length <= 1) return; // حداقل یک ردیف بماند
      ctx.row.remove();
      renumberRows(ctx.table);
    });
  }

  function delCol() {
    const ctx = currentCtx();
    if (!ctx) return;
    run(() => {
      const idx = ctx.cell.cellIndex;
      if (ctx.table.rows[0] && ctx.table.rows[0].cells.length <= 1) return; // حداقل یک ستون بماند
      for (const tr of [...ctx.table.querySelectorAll("tr")]) {
        if (tr.cells[idx]) tr.cells[idx].remove();
      }
    });
  }

  function delTable() {
    const ctx = currentCtx();
    if (!ctx) return;
    run(() => ctx.table.remove());
  }

  function renumber() {
    const ctx = currentCtx();
    if (!ctx) return;
    run(() => renumberRows(ctx.table));
  }

  // ---------- چسباندن ----------
  function onPaste(e: React.ClipboardEvent) {
    e.preventDefault();
    const dt = e.clipboardData;
    const html = dt.getData("text/html");
    if (html) {
      const clean = sanitizeLetterHtml(html);
      if (clean) {
        exec("insertHTML", clean);
        pushChange();
        refreshCtx();
        return;
      }
    }
    const text = dt.getData("text/plain");
    if (!text) return;
    // متن جداشده با Tab (کپی اکسل بدون HTML) → جدول
    const lines = text.replace(/\r/g, "").split("\n").filter((l) => l.trim() !== "");
    if (lines.length > 1 && lines.filter((l) => l.includes("\t")).length >= Math.ceil(lines.length / 2)) {
      const rowsHtml = lines
        .map((l) => {
          const cells = l.split("\t").map((c) => `<td>${escHtml(c.trim() || NBSP)}</td>`).join("");
          return `<tr>${cells}</tr>`;
        })
        .join("");
      exec("insertHTML", `<table dir="rtl"><tbody>${rowsHtml}</tbody></table><p><br /></p>`);
    } else {
      const paras = text.split(/\n{2,}/).map((p) => `<p>${escHtml(p).replace(/\n/g, "<br />")}</p>`).join("");
      exec("insertHTML", paras || `<p>${escHtml(text)}</p>`);
    }
    pushChange();
    refreshCtx();
  }

  function escHtml(s: string): string {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  function toFaDigitsLocal(n: number): string {
    return String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
  }

  const btn = "h-7 min-w-7 px-1.5 text-[11px] gap-1 shrink-0";

  return (
    <div className="rounded-xl border border-input focus-within:ring-2 focus-within:ring-ring overflow-hidden">
      <LetterRichStyles />
      {/* نوار ابزار */}
      <div className="flex items-center gap-1 flex-wrap px-2 py-1.5 bg-slate-50 border-b border-slate-200" dir="rtl">
        <Button type="button" size="sm" variant="ghost" title="درشت (Ctrl+B)" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => run(() => exec("bold"))}><Bold className="w-3.5 h-3.5" /></Button>
        <Button type="button" size="sm" variant="ghost" title="مورب (Ctrl+I)" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => run(() => exec("italic"))}><Italic className="w-3.5 h-3.5" /></Button>
        <Button type="button" size="sm" variant="ghost" title="زیرخط (Ctrl+U)" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => run(() => exec("underline"))}><Underline className="w-3.5 h-3.5" /></Button>
        <span className="w-px h-5 bg-slate-200 mx-0.5" />
        <Button type="button" size="sm" variant="ghost" title="فهرست شماره‌دار" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => run(() => exec("insertOrderedList"))}><ListOrdered className="w-3.5 h-3.5" /></Button>
        <Button type="button" size="sm" variant="ghost" title="پاک‌کردن قالب‌بندی" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => run(() => exec("removeFormat"))}><Eraser className="w-3.5 h-3.5" /></Button>
        <span className="w-px h-5 bg-slate-200 mx-0.5" />
        <Button
          type="button"
          size="sm"
          className={`${btn} bg-blue-600 hover:bg-blue-700 text-white hover:text-white`}
          title="درج جدول در متن نامه"
          onClick={() => setTableForm((v) => !v)}
        >
          <Table2 className="w-3.5 h-3.5" /> جدول
        </Button>
        {inTable && (
          <>
            <span className="w-px h-5 bg-slate-200 mx-0.5" />
            <Button type="button" size="sm" variant="ghost" title="ردیف جدید بالای ردیف فعلی" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => addRow(true)}><Rows3 className="w-3 h-3 rotate-180" /></Button>
            <Button type="button" size="sm" variant="ghost" title="ردیف جدید زیر ردیف فعلی" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => addRow(false)}><Rows3 className="w-3 h-3" /></Button>
            <Button type="button" size="sm" variant="ghost" title="حذف ردیف فعلی" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={delRow}><Minus className="w-3 h-3" /><Rows3 className="w-3 h-3" /></Button>
            <span className="w-px h-5 bg-slate-200 mx-0.5" />
            <Button type="button" size="sm" variant="ghost" title="ستون جدید سمت راست ستون فعلی" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => addCol(true)}><Columns3 className="w-3 h-3 rotate-180" /></Button>
            <Button type="button" size="sm" variant="ghost" title="ستون جدید سمت چپ ستون فعلی" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={() => addCol(false)}><Columns3 className="w-3 h-3" /></Button>
            <Button type="button" size="sm" variant="ghost" title="حذف ستون فعلی" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={delCol}><Minus className="w-3 h-3" /><Columns3 className="w-3 h-3" /></Button>
            <Button type="button" size="sm" variant="ghost" title="شماره‌گذاری مجدد ستون ردیف" className={btn} onMouseDown={(e) => e.preventDefault()} onClick={renumber}><IndentIncrease className="w-3 h-3" /></Button>
            <Button type="button" size="sm" variant="ghost" title="حذف کل جدول" className={`${btn} text-rose-600 hover:text-rose-700`} onMouseDown={(e) => e.preventDefault()} onClick={delTable}><Trash2 className="w-3 h-3" /></Button>
          </>
        )}
        <span className="text-[10px] text-muted-foreground mr-auto hidden sm:block">مکان‌نما را داخل جدول بگذارید تا ابزارهای ردیف/ستون فعال شوند</span>
      </div>

      {/* فرم درج جدول */}
      {tableForm && (
        <div className="px-3 py-2.5 bg-blue-50/70 border-b border-blue-100 space-y-2" dir="rtl">
          <div className="flex items-end gap-3 flex-wrap">
            <div className="w-24 space-y-1">
              <Label className="text-[10px]">تعداد ستون</Label>
              <Input type="number" min={1} max={12} className="h-8 text-xs" value={cols} onChange={(e) => setColsSafe(parseInt(e.target.value) || 1)} />
            </div>
            <div className="w-24 space-y-1">
              <Label className="text-[10px]">تعداد ردیف</Label>
              <Input type="number" min={1} max={60} className="h-8 text-xs" value={rows} onChange={(e) => setRows(Math.min(60, Math.max(1, parseInt(e.target.value) || 1)))} />
            </div>
            <div className="flex-1 min-w-[180px] space-y-1">
              <Label className="text-[10px]">عنوان جدول (اختیاری — بالای جدول درج می‌شود)</Label>
              <Input className="h-8 text-xs" value={tableTitle} onChange={(e) => setTableTitle(e.target.value)} placeholder="مثال: فهرست اشخاص موضوع نامه" />
            </div>
            <label className="flex items-center gap-1.5 text-[11px] cursor-pointer pb-2">
              <input type="checkbox" className="accent-blue-600 w-3.5 h-3.5" checked={withHeader} onChange={(e) => setWithHeader(e.target.checked)} />
              سطر سربرگ
            </label>
            <label className="flex items-center gap-1.5 text-[11px] cursor-pointer pb-2">
              <input type="checkbox" className="accent-blue-600 w-3.5 h-3.5" checked={autoNumber} onChange={(e) => setAutoNumber(e.target.checked)} />
              ستون «ردیف» خودکار
            </label>
            <Button size="sm" className="h-8 gap-1 bg-blue-600 hover:bg-blue-700" onClick={insertTable}><Plus className="w-3.5 h-3.5" /> درج جدول</Button>
          </div>
          {withHeader && (
            <div className="space-y-1">
              <Label className="text-[10px] text-blue-800">
                تیتر ستون‌ها (اختیاری — از راست به چپ{autoNumber ? "؛ ستون «ردیف» خودکار اضافه می‌شود" : ""}) — پس از درج هم قابل ویرایش
              </Label>
              <div className="flex items-stretch gap-1.5 flex-wrap">
                {colTitles.slice(0, cols).map((t, i) => (
                  <Input
                    key={i}
                    className="h-8 text-xs flex-1 min-w-[80px] text-center"
                    value={t}
                    onChange={(e) => {
                      const next = [...colTitles];
                      next[i] = e.target.value;
                      setColTitles(next);
                    }}
                    placeholder={`ستون ${toFaDigitsLocal(i + 1)}`}
                  />
                ))}
              </div>
            </div>
          )}
          <p className="text-[10px] text-muted-foreground leading-4">
            راهنما: جدول راست‌به‌چپ درج می‌شود؛ تیترها و سلول‌ها در متن نامه قابل ویرایش‌اند. جدول از اکسل/ورد/گوگل‌شیت هم قابل کپی-پیست است.
          </p>
        </div>
      )}

      {/* بوم متن */}
      <div
        ref={ref}
        className="lre px-4 py-3 outline-none bg-white text-right"
        dir="rtl"
        contentEditable
        suppressContentEditableWarning
        data-ph={placeholder}
        style={{ minHeight }}
        onInput={pushChange}
        onKeyUp={refreshCtx}
        onClick={refreshCtx}
        onMouseUp={refreshCtx}
        onPaste={onPaste}
        onBlur={pushChange}
      />
    </div>
  );
}

// ---------- پیش‌نمایش متن غنی (دیالوگ‌های مشاهده) ----------

export function LetterRichBodyPreview({ html, plain }: { html?: string | null; plain: string }) {
  const clean = sanitizeLetterHtml(html || "");
  if (!clean) {
    return <div className="rounded-xl border bg-white p-5 text-[13px] leading-8 whitespace-pre-wrap">{plain}</div>;
  }
  return (
    <div className="rounded-xl border bg-white p-4 overflow-x-auto">
      <LetterRichStyles />
      <div className="lre" dir="rtl" dangerouslySetInnerHTML={{ __html: clean }} />
    </div>
  );
}

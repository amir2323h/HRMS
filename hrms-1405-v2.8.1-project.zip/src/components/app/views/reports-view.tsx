"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { FileDown, Landmark, Receipt, Building, PieChart, Printer } from "lucide-react";
import { useApi } from "@/lib/client";
import { groupFa } from "@/lib/format";
import { periodTitle, toFaDigits } from "@/lib/jalali";
import { Money } from "../money-input";
import { BarList } from "../charts";

interface PeriodRow { id: string; year: number; month: number; status: string; payslipCount: number }
interface CostRow {
  departmentId: string; name: string; code: string; costCenterCode: string; parentId: string | null;
  headcount: number; gross: number; baseSalary: number; housing: number; grocery: number; childAllowance: number;
  seniority: number; attraction: number; overtimeAmount: number; employeeSso: number; employerSso: number;
  incomeTax: number; netPay: number; totalCost: number;
}
interface CostData {
  period: { year: number; month: number };
  rows: CostRow[];
  totals: Omit<CostRow, "departmentId" | "name" | "code" | "costCenterCode" | "parentId">;
}

const BANKS = [
  { id: "pasargad", name: "بانک پارسیان", format: "CSV (شبا، مبلغ، شناسه واریز)" },
  { id: "saman", name: "بانک سامان", format: "متن عرض‌ثابت (شبا ۲۶ + مبلغ ۱۵ + شناسه ۱۰ + نام ۴۰)" },
  { id: "mellat", name: "بانک ملت", format: "متن عرض‌ثابت استاندارد" },
  { id: "tejarat", name: "بانک تجارت", format: "CSV با ردیف و شرح واریز" },
];

export function ReportsView() {
  const periods = useApi<{ periods: PeriodRow[] }>("/api/payroll/periods");
  const [periodId, setPeriodId] = useState("");
  const selected = (periods.data?.periods || []).find((p) => p.id === periodId);
  const cost = useApi<CostData>(periodId ? `/api/reports/cost?periodId=${periodId}` : null, [periodId]);
  const { toast } = useToast();

  const activePeriods = (periods.data?.periods || []).filter((p) => p.payslipCount > 0);

  return (
    <div className="space-y-4">
      {/* انتخاب دوره */}
      <Card className="rounded-2xl">
        <CardContent className="p-4 flex flex-wrap items-center gap-3">
          <p className="text-sm font-medium">دوره گزارش:</p>
          <Select value={periodId} onValueChange={setPeriodId}>
            <SelectTrigger className="w-[220px]"><SelectValue placeholder="انتخاب دوره حقوق" /></SelectTrigger>
            <SelectContent>
              {activePeriods.map((p) => (
                <SelectItem key={p.id} value={p.id}>{periodTitle(p.year, p.month)} — {toFaDigits(p.payslipCount)} فیش</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {selected && (
            <Badge variant="outline" className="tabular-nums">
              {periodTitle(selected.year, selected.month)}
            </Badge>
          )}
          <p className="text-xs text-muted-foreground mr-auto">همه فایل‌ها با کدگذاری UTF-8 (BOM برای اکسل) و مبالغ ریالی تولید می‌شوند.</p>
        </CardContent>
      </Card>

      {/* کارت‌های خروجی */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <ExportCard
          icon={<Landmark className="w-5 h-5" />}
          title="دیسکت بیمه (سازمان تأمین اجتماعی)"
          desc="فایل رکوردهای عرض‌ثابت مطابق ساختار نسخه دیسکت: سرآیند کارگاه + رکورد هر بیمه‌شده (شماره بیمه، کد ملی، روز کارکرد، مشمول، ۷٪، ۲۰٪، ۳٪) + رکورد پایانی."
          href={periodId ? `/api/reports/sso?periodId=${periodId}` : null}
          fileName="SSO-List.txt"
          onMissing={() => toast({ title: "ابتدا دوره را انتخاب کنید" })}
        />
        <ExportCard
          icon={<Receipt className="w-5 h-5" />}
          title="فایل مالیاتی (INTA)"
          desc="گزارش ماهانه مالیات حقوق برای سامانه سازمان امور مالیاتی: کد ملی، درآمد مشمول مالیات و مالیات پرداختی هر کارمند + جمع کل."
          href={periodId ? `/api/reports/tax?periodId=${periodId}` : null}
          fileName="Tax.csv"
          onMissing={() => toast({ title: "ابتدا دوره را انتخاب کنید" })}
        />
        {BANKS.map((b) => (
          <ExportCard
            key={b.id}
            icon={<Building className="w-5 h-5" />}
            title={`فایل پرداخت ${b.name}`}
            desc={b.format}
            href={periodId ? `/api/reports/bank/${b.id}?periodId=${periodId}` : null}
            fileName={`Bank-${b.id}`}
            onMissing={() => toast({ title: "ابتدا دوره را انتخاب کنید" })}
          />
        ))}
      </div>

      {/* گزارش هزینه مراکز */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <PieChart className="w-4 h-4 text-teal-600" />
            گزارش تخصیص هزینه نیروی کار به تفکیک مرکز هزینه
            {cost.data && <Badge variant="outline">{periodTitle(cost.data.period.year, cost.data.period.month)}</Badge>}
            <Button size="sm" variant="outline" className="mr-auto gap-1.5" onClick={() => window.print()}>
              <Printer className="w-3.5 h-3.5" /> چاپ گزارش
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!periodId && <p className="text-sm text-muted-foreground py-8 text-center">برای مشاهده، دوره حقوق را انتخاب کنید.</p>}
          {periodId && cost.loading && <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-10" />)}</div>}
          {cost.data && (
            <>
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                <div className="lg:col-span-2">
                  <p className="text-sm font-bold mb-4">سهم مراکز از هزینه کل</p>
                  <BarList data={cost.data.rows.filter((r) => r.headcount > 0).map((r) => ({ label: r.name, value: r.totalCost, sub: `${r.costCenterCode}` }))} />
                </div>
                <div className="lg:col-span-3 overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50/80">
                        <TableHead className="text-right">مرکز هزینه / دپارتمان</TableHead>
                        <TableHead className="text-center">نیرو</TableHead>
                        <TableHead className="text-left">ناخالص</TableHead>
                        <TableHead className="text-left">بیمه کارفرما</TableHead>
                        <TableHead className="text-left">هزینه کل</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {cost.data.rows.filter((r) => r.headcount > 0).map((r) => (
                        <TableRow key={r.departmentId}>
                          <TableCell>
                            <p className="font-medium text-sm">{r.name}</p>
                            <p className="text-[11px] text-muted-foreground tabular-nums">{r.code} — {r.costCenterCode}</p>
                          </TableCell>
                          <TableCell className="text-center tabular-nums">{toFaDigits(r.headcount)}</TableCell>
                          <TableCell className="text-left tabular-nums text-sm"><Money amount={r.gross} short /></TableCell>
                          <TableCell className="text-left tabular-nums text-sm text-amber-700"><Money amount={r.employerSso} short /></TableCell>
                          <TableCell className="text-left tabular-nums text-sm font-bold"><Money amount={r.totalCost} short /></TableCell>
                        </TableRow>
                      ))}
                      <TableRow className="bg-slate-100 font-bold">
                        <TableCell>جمع کل سازمان</TableCell>
                        <TableCell className="text-center tabular-nums">{toFaDigits(cost.data.totals.headcount)}</TableCell>
                        <TableCell className="text-left tabular-nums"><Money amount={cost.data.totals.gross} short /></TableCell>
                        <TableCell className="text-left tabular-nums text-amber-700"><Money amount={cost.data.totals.employerSso} short /></TableCell>
                        <TableCell className="text-left tabular-nums"><Money amount={cost.data.totals.totalCost} short /></TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>

              {/* جزئیات اجزا */}
              <div className="mt-6 pt-5 border-t">
                <p className="text-sm font-bold mb-3">جزئیات اجزای هزینه (کل سازمان)</p>
                <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3">
                  <CostChip label="حقوق پایه" amount={cost.data.totals.baseSalary} />
                  <CostChip label="حق مسکن" amount={cost.data.totals.housing} />
                  <CostChip label="بن کارگری" amount={cost.data.totals.grocery} />
                  <CostChip label="حق اولاد" amount={cost.data.totals.childAllowance} />
                  <CostChip label="سنوات + جذب" amount={cost.data.totals.seniority + cost.data.totals.attraction} />
                  <CostChip label="اضافه‌کاری" amount={cost.data.totals.overtimeAmount} />
                  <CostChip label="بیمه کارفرما ۲۳٪" amount={cost.data.totals.employerSso} color="text-amber-700" />
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ExportCard({ icon, title, desc, href, fileName, onMissing }: {
  icon: React.ReactNode; title: string; desc: string; href: string | null; fileName: string; onMissing: () => void;
}) {
  return (
    <Card className="rounded-2xl h-full hover:shadow-md transition-shadow">
      <CardContent className="p-5 flex flex-col h-full">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">{icon}</div>
          <h3 className="font-bold text-sm text-slate-800">{title}</h3>
        </div>
        <p className="text-xs text-muted-foreground leading-5 flex-1">{desc}</p>
        <Button
          className="mt-4 w-full gap-1.5 bg-teal-600 hover:bg-teal-700"
          disabled={!href}
          onClick={() => {
            if (href) {
              const a = document.createElement("a");
              a.href = href;
              a.download = fileName;
              a.click();
            } else onMissing();
          }}
        >
          <FileDown className="w-4 h-4" /> دانلود فایل
        </Button>
      </CardContent>
    </Card>
  );
}

function CostChip({ label, amount, color = "text-slate-800" }: { label: string; amount: number; color?: string }) {
  return (
    <div className="rounded-xl bg-slate-50 border border-slate-200/70 p-3">
      <p className="text-[11px] text-muted-foreground">{label}</p>
      <p className={`text-sm font-bold mt-1 tabular-nums ${color}`}><Money amount={amount} short /></p>
    </div>
  );
}

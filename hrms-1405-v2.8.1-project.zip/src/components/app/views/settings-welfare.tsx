"use client";

// ============================================================
// مدیریت آیتم‌های رفاهی — تعریف در تنظیمات، انتخاب در فرم کارمند
// ============================================================
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Gift, Plus, Pencil, Trash2 } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";

interface WelfareRow {
  id: string; code: string; title: string; description: string; isActive: boolean; usageCount: number;
}

export function WelfareManager({ canEdit }: { canEdit: boolean }) {
  const list = useApi<{ items: WelfareRow[] }>("/api/welfare");
  const [editing, setEditing] = useState<WelfareRow | null>(null);
  const [creating, setCreating] = useState(false);
  const { toast } = useToast();
  const items = list.data?.items || [];

  async function remove(w: WelfareRow) {
    if (!confirm(`حذف «${w.title}»؟ ${w.usageCount > 0 ? `${w.usageCount} کارمند به آن متصل است و اتصالشان حذف می‌شود.` : ""}`)) return;
    try {
      await api(`/api/welfare/${w.id}`, { method: "DELETE" });
      await list.refetch();
      toast({ title: "آیتم رفاهی حذف شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function toggleActive(w: WelfareRow) {
    try {
      await api(`/api/welfare/${w.id}`, { method: "PATCH", json: { isActive: !w.isActive } });
      await list.refetch();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-violet-50 to-white border-violet-200">
        <CardContent className="p-4 flex items-start gap-3 flex-wrap">
          <Gift className="w-6 h-6 text-violet-600 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-[200px]">
            <p className="font-bold text-sm text-slate-800">آیتم‌های رفاهی کارکنان</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              رفاهیاتی که کارکنان می‌توانند استفاده کنند (زودکس پی، غذای سازمانی، بیمه تکمیلی، سرویس و ...).
              این آیتم‌ها در فرم کارمند به‌صورت چک‌باکس انتخاب می‌شوند.
            </p>
          </div>
          {canEdit && (
            <Button className="bg-violet-600 hover:bg-violet-700 gap-1.5 shrink-0" onClick={() => setCreating(true)}>
              <Plus className="w-4 h-4" /> آیتم جدید
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {list.loading && [0, 1, 2].map((i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}
        {items.map((w) => (
          <Card key={w.id} className="rounded-2xl">
            <CardContent className="p-4 space-y-2.5">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-bold text-sm flex-1">{w.title}</p>
                <Badge variant="outline" className="text-[10px] font-mono" dir="ltr">{w.code}</Badge>
              </div>
              {w.description && <p className="text-xs text-muted-foreground leading-5">{w.description}</p>}
              <div className="flex items-center gap-2 flex-wrap">
                <Badge className={w.isActive ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                  {w.isActive ? "فعال" : "غیرفعال"}
                </Badge>
                <Badge variant="outline" className="text-[10px]">{toFaDigits(w.usageCount)} کارمند</Badge>
                {canEdit && (
                  <div className="mr-auto flex gap-1.5 items-center">
                    <Switch checked={w.isActive} onCheckedChange={() => toggleActive(w)} />
                    <Button size="sm" variant="outline" className="h-7 w-7 p-0" onClick={() => setEditing(w)}><Pencil className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant="destructive" className="h-7 w-7 p-0" onClick={() => remove(w)}><Trash2 className="w-3.5 h-3.5" /></Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {(creating || editing) && (
        <WelfareEditor
          item={editing}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={() => { list.refetch(); setCreating(false); setEditing(null); toast({ title: editing ? "آیتم به‌روزرسانی شد" : "آیتم رفاهی ساخته شد" }); }}
        />
      )}
    </div>
  );
}

function WelfareEditor({ item, onClose, onSaved }: { item: WelfareRow | null; onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const [title, setTitle] = useState(item?.title || "");
  const [description, setDescription] = useState(item?.description || "");
  const [saving, setSaving] = useState(false);

  async function save() {
    if (!title.trim()) {
      toast({ title: "عنوان آیتم الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (item) {
        await api(`/api/welfare/${item.id}`, { method: "PATCH", json: { title: title.trim(), description } });
      } else {
        await api("/api/welfare", { method: "POST", json: { title: title.trim(), description } });
      }
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[39.2rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Gift className="w-5 h-5 text-violet-600" /> {item ? `ویرایش ${item.title}` : "آیتم رفاهی جدید"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثلاً: غذای سازمانی" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">توضیحات (اختیاری)</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="مثلاً: وعده ناهار در محل کار" />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-700">{saving ? "..." : item ? "ذخیره" : "ایجاد"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

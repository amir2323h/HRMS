"use client";

// ============================================================
// پیکربندی پاداش — ماه پاداش هر طبقه + پارامتر تیرها
// همه چیز در تنظیمات ذخیره می‌شود (بدون هارد‌کد)
// ============================================================
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Save, Gift } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { fmtPercent, BONUS_TIER_LABELS } from "@/lib/format";
import { toFaDigits } from "@/lib/jalali";

interface BonusConfig {
  levels: Record<string, number>;
  tiers: { key: string; label: string; minRatio: number; paymentPercent: number; extraMonths: number }[];
}

export function BonusConfigEditor({ canEdit }: { canEdit: boolean }) {
  const cfg = useApi<{ config: BonusConfig }>("/api/bonus-config");
  const [f, setF] = useState<BonusConfig | null>(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    if (cfg.data?.config) setF(structuredClone(cfg.data.config));
  }, [cfg.data]);

  if (cfg.loading || !f) return <div className="space-y-3"><Skeleton className="h-40 rounded-2xl" /><Skeleton className="h-56 rounded-2xl" /></div>;

  function setLevel(lv: string, v: string) {
    const n = v === "" ? 0 : parseInt(v.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/\D/g, ""), 10);
    setF({ ...f, levels: { ...f.levels, [lv]: isNaN(n) ? 0 : n } });
  }
  function setTier(idx: number, field: "paymentPercent" | "extraMonths" | "minRatio", v: string) {
    const n = parseFloat(v.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/[^\d.]/g, ""));
    const tiers = [...f.tiers];
    tiers[idx] = { ...tiers[idx], [field]: isNaN(n) ? 0 : n };
    setF({ ...f, tiers });
  }

  async function save() {
    // اعتبارسنجی
    for (const [lv, m] of Object.entries(f.levels)) {
      if (m < 0 || m > 24) {
        toast({ title: `ماه پاداش طبقه ${toFaDigits(lv)} باید بین ۰ تا ۲۴ باشد`, variant: "destructive" });
        return;
      }
    }
    for (const t of f.tiers) {
      if (t.paymentPercent < 0 || t.paymentPercent > 100) {
        toast({ title: `درصد پرداخت تیر «${BONUS_TIER_LABELS[t.key]}» باید بین ۰ تا ۱۰۰ باشد`, variant: "destructive" });
        return;
      }
      if (t.extraMonths < 0 || t.extraMonths > 12) {
        toast({ title: "ماه پاداش اضافه باید بین ۰ تا ۱۲ باشد", variant: "destructive" });
        return;
      }
    }
    setSaving(true);
    try {
      await api("/api/bonus-config", { method: "PUT", json: f });
      await cfg.refetch();
      toast({ title: "پیکربندی پاداش ذخیره شد", description: "طرح‌های جدید از این قواعد استفاده می‌کنند." });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-amber-50 to-white border-amber-200">
        <CardContent className="p-4 flex items-start gap-3 flex-wrap">
          <Gift className="w-6 h-6 text-amber-600 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-[200px]">
            <p className="font-bold text-sm text-slate-800">قواعد پاداش/سود سالانه</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              ماه پاداش هر طبقه معادل «حقوق پایه بدون اضافات قانونی» است. چهار وضعیت تارگت با درصد پرداخت و پایه اضافه تعریف می‌شود —
              در اور تارگت، «پایه اضافه» روی ماه طبقه (حالت روی تارگت) اضافه می‌شود (پیش‌فرض سیاست سازمان: ۲ پایه).
              طرح‌های صادرشده پیش‌تر، اسنپ‌شات قواعد خود را حفظ می‌کنند.
            </p>
          </div>
          {canEdit && (
            <Button className="bg-amber-600 hover:bg-amber-700 gap-1.5 shrink-0" onClick={save} disabled={saving}>
              <Save className="w-4 h-4" /> {saving ? "..." : "ذخیره قواعد"}
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* ماه پاداش طبقات */}
        <Card className="rounded-2xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">ماه پاداش هر طبقه (معادل حقوق پایه)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {[1, 2, 3, 4, 5, 6, 7].map((lv) => (
              <div key={lv} className="flex items-center gap-3">
                <Badge variant="outline" className="w-20 justify-center">طبقه {toFaDigits(lv)}</Badge>
                <Input
                  className="w-28 text-center tabular-nums"
                  value={String(f.levels[String(lv)] ?? 0)}
                  onChange={(e) => canEdit && setLevel(String(lv), e.target.value)}
                  disabled={!canEdit}
                  inputMode="numeric"
                />
                <span className="text-xs text-muted-foreground">ماه پاداش</span>
                {(f.levels[String(lv)] ?? 0) === 0 && <Badge className="bg-slate-100 text-slate-500 hover:bg-slate-100 text-[10px]">بدون پاداش</Badge>}
              </div>
            ))}
            <p className="text-[11px] text-muted-foreground pt-2 border-t leading-5">
              مقدار پیش‌فرض سیاست سازمان: طبقه ۱ بدون پاداش، ۲-۳ سه ماه، ۴ پنج ماه، ۵ شش ماه، ۷ هفت ماه و ۷ نه ماه.
            </p>
          </CardContent>
        </Card>

        {/* تیرها */}
        <Card className="rounded-2xl">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">وضعیت‌های چهارگانه تارگت</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {f.tiers.map((t, idx) => (
              <div key={t.key} className="rounded-xl border p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Badge className="w-full justify-center text-[11px]">{BONUS_TIER_LABELS[t.key]}</Badge>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <Label className="text-[10px]">حداقل نسبت</Label>
                    <Input className="h-8 text-center tabular-nums text-xs" value={String(t.minRatio)} onChange={(e) => canEdit && setTier(idx, "minRatio", e.target.value)} disabled={!canEdit} inputMode="decimal" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">درصد پرداخت</Label>
                    <Input className="h-8 text-center tabular-nums text-xs" value={String(t.paymentPercent)} onChange={(e) => canEdit && setTier(idx, "paymentPercent", e.target.value)} disabled={!canEdit} inputMode="numeric" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-[10px]">پایه اضافه (ماه)</Label>
                    <Input className="h-8 text-center tabular-nums text-xs" value={String(t.extraMonths)} onChange={(e) => canEdit && setTier(idx, "extraMonths", e.target.value)} disabled={!canEdit} inputMode="numeric" />
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground leading-4">
                  {t.key === "BELOW_80" && "کمتر از حداقل نسبت → پاداش پرداخت نمی‌شود."}
                  {t.key === "AT_80" && "دوره ۸۰٪ تا ۱۰۰٪ → درصد مبلغ پاداش پرداخت می‌شود (پیش‌فرض ۸۰٪)."}
                  {t.key === "AT_100" && "تحقق کامل → پرداخت کامل."}
                  {t.key === "OVER_120" && `اور تارگت → پرداخت کامل + ${toFaDigits(t.extraMonths)} پایه اضافه روی حالت روی تارگت (ماه پاداش = ماه طبقه + ${toFaDigits(t.extraMonths)}).`}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl bg-slate-50">
        <CardContent className="p-4 text-xs text-muted-foreground leading-6">
          <p className="font-bold text-slate-700 mb-1">فرمول محاسبه پاداش هر نفر:</p>
          <p dir="rtl" className="font-mono text-[11px] bg-white border rounded-lg p-2 inline-block">
            پاداش = حقوق پایه × (ماه طبقه + ماه اضافه تیر) × (ماه حضور در سال ÷ ۱۲) × (درصد پرداخت ÷ ۱۰۰)
          </p>
          <p className="mt-2">اگر «مقیاس‌بندی بودجه» در طرح فعال باشد و جمع از بودجه بیشتر شود، سهم همه به‌نسبت کاهش می‌یابد. ماه حضور از تاریخ استخدام تا تاریخ مرجع طرح محاسبه می‌شود.</p>
        </CardContent>
      </Card>
    </div>
  );
}

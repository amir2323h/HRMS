"use client";

// ============================================================
// ورود یکپارانه با Mattermost — پیکربندی OAuth 2.0
// مطابق مستندات رسمی (System Console → Integrations → OAuth 2.0 Applications)
// ============================================================
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Save, MessageSquare, ExternalLink, CheckCircle2 } from "lucide-react";
import { api, useApi } from "@/lib/client";

interface MmConfig {
  enabled: boolean;
  serverUrl: string;
  clientId: string;
  clientSecret: string;
  autoCreate: boolean;
  defaultRoleKey: string;
  buttonLabel: string;
  callbackBaseUrl: string; // مسیر فال‌بک Callback — آدرس پایه عمومی سامانه
}

export function MattermostSettings({ canEdit, roles }: { canEdit: boolean; roles: { key: string; name: string }[] }) {
  const { toast } = useToast();
  const [f, setF] = useState<MmConfig | null>(null);
  const [saving, setSaving] = useState(false);
  // آدرس callback نمایش‌داده‌شده — اگر مسیر فال‌بک تنظیم شده باشد همان نمایش داده می‌شود
  const originUrl = typeof window !== "undefined" ? `${window.location.origin}/api/auth/mattermost/callback` : "";
  const callbackUrl = f?.callbackBaseUrl ? `${f.callbackBaseUrl.replace(/\/+$/, "")}/api/auth/mattermost/callback` : originUrl;

  // خواندن پیکربندی از سرور (تنظیمات محافظت‌شده)
  useEffect(() => {
    (async () => {
      try {
        const d = await api<{ config: MmConfig }>("/api/settings/mattermost");
        setF(d.config);
      } catch {
        setF({ enabled: false, serverUrl: "", clientId: "", clientSecret: "", autoCreate: true, defaultRoleKey: "EMPLOYEE", buttonLabel: "ورود با Mattermost", callbackBaseUrl: "" });
      }
    })();
  }, []);

  if (!f) return <Skeleton className="h-64 rounded-2xl" />;

  async function save() {
    if (f.enabled && (!f.serverUrl.trim() || !f.clientId.trim() || !f.clientSecret.trim())) {
      toast({ title: "برای فعال‌سازی، آدرس سرور، Client ID و Client Secret الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/settings/mattermost", { method: "PUT", json: f });
      toast({ title: "پیکربندی Mattermost ذخیره شد", description: f.enabled ? "دکمه ورود در صفحه لاگین نمایش داده می‌شود." : "ورود یکپارانه غیرفعال است." });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-indigo-50 to-white border-indigo-200">
        <CardContent className="p-4 flex items-start gap-3 flex-wrap">
          <MessageSquare className="w-6 h-6 text-indigo-600 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-[200px]">
            <p className="font-bold text-sm text-slate-800 flex items-center gap-2">
              ورود یکپارانه با Mattermost (OAuth 2.0)
              <Badge className={f.enabled ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                {f.enabled ? "فعال" : "غیرفعال"}
              </Badge>
            </p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              جریان استاندارد Authorization Code: سامانه به‌عنوان اپلیکیشن OAuth در Mattermost ثبت می‌شود و کاربران با حساب Mattermost وارد می‌شوند.
            </p>
          </div>
          {canEdit && (
            <Button className="bg-indigo-600 hover:bg-indigo-700 gap-1.5 shrink-0" onClick={save} disabled={saving}>
              <Save className="w-4 h-4" /> {saving ? "..." : "ذخیره"}
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="rounded-2xl">
          <CardHeader className="pb-3"><CardTitle className="text-sm">پارامترهای اتصال</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-xl border p-3">
              <div>
                <p className="text-sm font-medium">فعال‌سازی ورود با Mattermost</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">نمایش دکمه در صفحه ورود</p>
              </div>
              <Switch checked={f.enabled} onCheckedChange={(v) => canEdit && setF({ ...f, enabled: v })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">آدرس سرور Mattermost</Label>
              <Input dir="ltr" value={f.serverUrl} onChange={(e) => setF({ ...f, serverUrl: e.target.value })} placeholder="https://mattermost.example.com" disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Client ID</Label>
              <Input dir="ltr" value={f.clientId} onChange={(e) => setF({ ...f, clientId: e.target.value })} placeholder="از System Console → Integrations → OAuth 2.0" disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Client Secret</Label>
              <Input dir="ltr" type="password" value={f.clientSecret} onChange={(e) => setF({ ...f, clientSecret: e.target.value })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">متن دکمه ورود</Label>
              <Input value={f.buttonLabel} onChange={(e) => setF({ ...f, buttonLabel: e.target.value })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">آدرس فال‌بک Callback (اختیاری)</Label>
              <Input
                dir="ltr"
                value={f.callbackBaseUrl}
                onChange={(e) => setF({ ...f, callbackBaseUrl: e.target.value })}
                placeholder="https://hr.example.com"
                disabled={!canEdit}
              />
              <p className="text-[11px] text-muted-foreground leading-5">
                اگر سامانه از چند دامنه/پورت (localhost، IP، دامنه پراکسی) باز می‌شود، این آدرس را تنظیم کنید تا مسیر بازگشت OAuth همیشه ثابت بماند.
                خالی = استخراج خودکار از آدرس جاری ({originUrl ? "مبدأ درخواست" : "هدرها"}).
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader className="pb-3"><CardTitle className="text-sm">ساخت کاربر و نقش پیش‌فرض</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-xl border p-3">
              <div>
                <p className="text-sm font-medium">ساخت خودکار کاربر جدید</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 leading-4">
                  اگر کاربری با حساب Mattermost شناسایی نشود (نه اتصال موجود، نه تطبیق ایمیل) حساب جدید ساخته شود.
                </p>
              </div>
              <Switch checked={f.autoCreate} onCheckedChange={(v) => canEdit && setF({ ...f, autoCreate: v })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">نقش کاربران جدید</Label>
              <select
                className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm"
                value={f.defaultRoleKey}
                onChange={(e) => setF({ ...f, defaultRoleKey: e.target.value })}
                disabled={!canEdit}
                dir="rtl"
              >
                {roles.length === 0 && <option value="EMPLOYEE">کارمند</option>}
                {roles.map((r) => <option key={r.key} value={r.key}>{r.name}</option>)}
              </select>
              <p className="text-[11px] text-muted-foreground">نقش را می‌توان بعداً از «کاربران و دسترسی» تغییر داد.</p>
            </div>

            {/* راهنمای ثبت اپلیکیشن در Mattermost */}
            <div className="rounded-xl border border-indigo-200 bg-indigo-50/50 p-3 text-[11px] leading-6 text-slate-700">
              <p className="font-bold mb-1 flex items-center gap-1"><ExternalLink className="w-3.5 h-3.5" /> ثبت اپلیکیشن در Mattermost:</p>
              <ol className="list-decimal mr-4 space-y-0.5">
                <li>در Mattermost به <b>System Console → Integrations → OAuth 2.0 Applications</b> بروید.</li>
                <li>«Add OAuth 2.0 Application» را بزنید و Redirect URI زیر را ثبت کنید.</li>
                <li>Client ID و Client Secret دریافتی را در فرم روبه‌رو وارد کنید.</li>
              </ol>
              <div className="mt-2 bg-white border rounded-lg p-2 font-mono text-[10px] break-all select-all" dir="ltr">
                {callbackUrl}
              </div>
              {f.callbackBaseUrl ? (
                <p className="mt-1.5 text-emerald-700">✓ مسیر فال‌بک فعال است — این آدرس ثابت در هر دو مرحله مجوز و تبادل توکن استفاده می‌شود.</p>
              ) : (
                <p className="mt-1.5 text-muted-foreground">مسیر فال‌بک تنظیم نشده — آدرس از مبدأ جاری درخواست استخراج می‌شود.</p>
              )}
            </div>
            {f.enabled && f.serverUrl && f.clientId && f.clientSecret && (
              <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-[11px] text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                پیکربندی کامل است — دکمه «{f.buttonLabel}» در صفحه ورود نمایش داده می‌شود.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* جریان استاندارد */}
      <Card className="rounded-2xl bg-slate-50">
        <CardContent className="p-4 text-[11px] text-muted-foreground leading-6">
          <p className="font-bold text-slate-700 mb-1">جریان استاندارد OAuth 2.0 (Authorization Code):</p>
          <p className="font-mono bg-white border rounded-lg p-2 inline-block" dir="ltr">
            GET /oauth/authorize → redirect ?code → POST /oauth/token → GET /api/v4/users/me → نشست سامانه
          </p>
          <p className="mt-1.5">
            state تصادفی برای محافظت CSRF در کوکی کوتاه‌مدت ذخیره می‌شود؛ نشست پس از تبادل توکن با کوکی امن + Bearer ایجاد می‌گردد
            (سازگار با iframe). کاربران Mattermost با ایمیل متناظر پروفایل کارکنان به‌طور خودکار به پرونده‌شان متصل می‌شوند.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

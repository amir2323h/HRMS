"use client";

// ============================================================
// پشتیبان‌گیری و بازیابی داده‌های پنل — فقط مدیر کل (مجوز «*»)
//   ۱) ایجاد پشتیبان تازه (اسنپ‌شات سالم VACUUM — بدون توقف سرویس)
//   ۲) فهرست/دانلود/حذف/بازیابی فایل‌های پشتیبان (حداکثر ۱۰ نسخه)
//   ۳) بازیابی از فایل خارجی (آپلود .db)
// بازیابی ایمن است: پیش از جایگزینی، خودکار از وضعیت فعلی پشتیبان
// گرفته می‌شود (pre-restore) و سرویس ری‌استارت نمی‌شود.
// ============================================================

import { useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { api, useApi, getAuthToken } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";
import { DatabaseBackup, Download, Trash2, ArchiveRestore, ShieldAlert, Upload, HardDrive } from "lucide-react";

interface BackupRow {
  name: string;
  sizeBytes: number;
  createdAt: string;
  createdAtJ: string;
}

interface BackupStats {
  dbPath: string;
  dbSizeBytes: number;
  backupsDir: string;
  backups: BackupRow[];
  backupCount: number;
  totalBackupBytes: number;
  maxBackups: number;
}

type RestoreTarget =
  | { kind: "existing"; name: string; sizeBytes: number; createdAtJ: string }
  | { kind: "upload"; file: File };

function fmtSize(bytes: number): string {
  if (bytes >= 1024 * 1024) return `${toFaDigits((bytes / 1024 / 1024).toFixed(1))} مگابایت`;
  if (bytes >= 1024) return `${toFaDigits(Math.round(bytes / 1024))} کیلوبایت`;
  return `${toFaDigits(bytes)} بایت`;
}

export function BackupManager() {
  const { data, loading, refetch } = useApi<BackupStats>("/api/settings/backup");
  const [creating, setCreating] = useState(false);
  const [downloading, setDownloading] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [restoreTarget, setRestoreTarget] = useState<RestoreTarget | null>(null);
  const [busy, setBusy] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  async function createBackup() {
    setCreating(true);
    try {
      const r = await api<{ ok: boolean; backup: BackupRow }>("/api/settings/backup", { method: "POST", json: {} });
      toast({
        title: "پشتیبان ساخته شد",
        description: `فایل ${r.backup.name} با حجم ${fmtSize(r.backup.sizeBytes)} ذخیره شد.`,
      });
      refetch();
    } catch (e) {
      toast({ title: "خطا در پشتیبان‌گیری", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setCreating(false);
    }
  }

  async function download(name: string) {
    setDownloading(name);
    try {
      const token = getAuthToken();
      const res = await fetch(`/api/settings/backup/download?file=${encodeURIComponent(name)}`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        cache: "no-store",
      });
      if (!res.ok) {
        let msg = `خطای ${res.status}`;
        try {
          const j = (await res.json()) as { error?: string };
          if (j?.error) msg = j.error;
        } catch { /* بدون JSON */ }
        throw new Error(msg);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast({ title: "دانلود آغاز شد", description: name });
    } catch (e) {
      toast({ title: "خطا در دانلود", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setDownloading(null);
    }
  }

  async function remove(name: string) {
    setDeleting(name);
    try {
      await api(`/api/settings/backup?file=${encodeURIComponent(name)}`, { method: "DELETE" });
      toast({ title: "فایل پشتیبان حذف شد", description: name });
      refetch();
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setDeleting(null);
    }
  }

  async function doRestore() {
    if (!restoreTarget) return;
    setBusy(true);
    try {
      const opts =
        restoreTarget.kind === "upload"
          ? { method: "POST", body: (() => { const fd = new FormData(); fd.append("file", restoreTarget.file); return fd; })() }
          : { method: "POST", json: { file: restoreTarget.name } };
      const r = await api<{ ok: boolean; safety: { name: string }; validation: { employees: number; users: number } }>(
        "/api/settings/backup/restore",
        opts
      );
      toast({
        title: "بازیابی انجام شد",
        description: `داده‌های پنل بازیابی شد (${toFaDigits(r.validation.employees)} کارمند، ${toFaDigits(r.validation.users)} کاربر) — پشتیبان ایمنی وضعیت قبل: ${r.safety.name}. صفحه تازه‌سازی می‌شود…`,
      });
      setRestoreTarget(null);
      setTimeout(() => window.location.reload(), 1800);
    } catch (e) {
      toast({ title: "خطا در بازیابی", description: e instanceof Error ? e.message : "", variant: "destructive" });
      setBusy(false);
    }
  }

  function onPickFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ""; // اجازه انتخاب مجدد همان فایل
    if (!file) return;
    if (!/\.db$/i.test(file.name)) {
      toast({ title: "فرمت فایل نامعتبر", description: "فایل پشتیبان باید با پسوند .db باشد.", variant: "destructive" });
      return;
    }
    setRestoreTarget({ kind: "upload", file });
  }

  if (loading || !data) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-28 rounded-2xl" />
        <Skeleton className="h-52 rounded-2xl" />
        <Skeleton className="h-40 rounded-2xl" />
      </div>
    );
  }

  const backups = data.backups || [];

  return (
    <div className="space-y-4">
      {/* راهنما */}
      <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
        <CardContent className="p-4 flex items-start gap-3">
          <DatabaseBackup className="w-6 h-6 text-teal-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-sm text-slate-800">پشتیبان‌گیری و بازیابی داده‌های پنل</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              «ایجاد پشتیبان» یک اسنپ‌شات کامل و سالم از تمام داده‌های پنل (کارکنان، فیش‌ها، قراردادها، نامه‌ها، تنظیمات و…) می‌سازد،
              بدون توقف سرویس. حداکثر {toFaDigits(data.maxBackups)} نسخه نگه داشته می‌شود (قدیمی‌ترین خودکار حذف می‌شود) و پیش از هر
              به‌روزرسانی سامانه نیز به‌صورت خودکار پشتیبان گرفته می‌شود.
            </p>
            <p className="text-[11px] text-muted-foreground mt-2 flex items-center gap-1.5 flex-wrap">
              <HardDrive className="w-3.5 h-3.5" />
              دیتابیس فعلی: <code className="font-mono bg-slate-100 rounded px-1 text-[10px]" dir="ltr">{data.dbPath}</code>
              ({fmtSize(data.dbSizeBytes)})
            </p>
          </div>
        </CardContent>
      </Card>

      {/* ایجاد پشتیبان */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <DatabaseBackup className="w-4 h-4 text-teal-600" />
            ایجاد پشتیبان تازه
            <Badge className="bg-slate-100 text-slate-700 hover:bg-slate-100">{toFaDigits(data.backupCount)} فایل — {fmtSize(data.totalBackupBytes)}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-3">
            <Button
              onClick={createBackup}
              disabled={creating || busy}
              className="h-11 gap-2 bg-teal-600 hover:bg-teal-700 px-6 font-bold"
            >
              <DatabaseBackup className="w-4 h-4" />
              {creating ? "در حال ایجاد…" : "ایجاد پشتیبان"}
            </Button>
            <Button
              onClick={() => fileInputRef.current?.click()}
              disabled={busy || creating}
              variant="outline"
              className="h-11 gap-2 border-amber-300 text-amber-800 hover:bg-amber-50 px-6"
            >
              <Upload className="w-4 h-4" />
              بازیابی از فایل خارجی…
            </Button>
            <input ref={fileInputRef} type="file" accept=".db" className="hidden" onChange={onPickFile} />
          </div>
          <p className="text-[11px] text-muted-foreground leading-5">
            فایل پشتیبان قابل انتقال به سرور دیگر است (مسیر ذخیره: <code className="font-mono bg-slate-100 rounded px-1 text-[10px]" dir="ltr">{data.backupsDir}</code>).
            برای انتقال کامل، فایل را دانلود و روی مقصد با «بازیابی از فایل خارجی» بازیابی کنید.
          </p>
        </CardContent>
      </Card>

      {/* فهرست پشتیبان‌ها */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-slate-600" />
            فایل‌های پشتیبان
          </CardTitle>
        </CardHeader>
        <CardContent>
          {backups.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground text-sm">
              هنوز فایل پشتیبانی وجود ندارد — با دکمه «ایجاد پشتیبان» اولین نسخه را بسازید.
            </div>
          ) : (
            <div className="overflow-x-auto -mx-2 px-2">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">نام فایل</TableHead>
                    <TableHead className="text-right whitespace-nowrap">تاریخ ایجاد</TableHead>
                    <TableHead className="text-right whitespace-nowrap">حجم</TableHead>
                    <TableHead className="text-right">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {backups.map((b) => (
                    <TableRow key={b.name}>
                      <TableCell className="font-mono text-[11px] text-slate-700" dir="ltr">{b.name}</TableCell>
                      <TableCell className="whitespace-nowrap text-xs">{b.createdAtJ}</TableCell>
                      <TableCell className="whitespace-nowrap text-xs tabular-nums">{fmtSize(b.sizeBytes)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <Button
                            variant="outline" size="sm"
                            className="h-8 gap-1.5 px-2.5"
                            disabled={downloading === b.name || busy}
                            onClick={() => download(b.name)}
                          >
                            <Download className="w-3.5 h-3.5" />
                            {downloading === b.name ? "…" : "دانلود"}
                          </Button>
                          <Button
                            variant="outline" size="sm"
                            className="h-8 gap-1.5 px-2.5 border-amber-300 text-amber-800 hover:bg-amber-50"
                            disabled={busy || creating}
                            onClick={() => setRestoreTarget({ kind: "existing", name: b.name, sizeBytes: b.sizeBytes, createdAtJ: b.createdAtJ })}
                          >
                            <ArchiveRestore className="w-3.5 h-3.5" />
                            بازیابی
                          </Button>
                          <Button
                            variant="outline" size="sm"
                            className="h-8 gap-1.5 px-2.5 border-rose-300 text-rose-700 hover:bg-rose-50"
                            disabled={deleting === b.name || busy}
                            onClick={() => remove(b.name)}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            {deleting === b.name ? "…" : "حذف"}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* تأیید بازیابی */}
      <AlertDialog open={!!restoreTarget} onOpenChange={(v) => !v && !busy && setRestoreTarget(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-600" />
              بازیابی داده‌های پنل از پشتیبان؟
            </AlertDialogTitle>
            <AlertDialogDescription className="leading-6 text-right">
              {restoreTarget?.kind === "upload" ? (
                <>
                  فایل <b dir="ltr" className="font-mono">{restoreTarget.file.name}</b> ({fmtSize(restoreTarget.file.size)}) بارگذاری و
                  پس از اعتبارسنجی جایگزین داده‌های فعلی می‌شود.
                </>
              ) : restoreTarget ? (
                <>
                  نسخه <b dir="ltr" className="font-mono">{restoreTarget.name}</b> ({restoreTarget.createdAtJ} — {fmtSize(restoreTarget.sizeBytes)})
                  جایگزین داده‌های فعلی پنل می‌شود.
                </>
              ) : null}
              <span className="block mt-2">پیش از جایگزینی، به‌صورت خودکار از وضعیت فعلی پشتیبان ایمنی گرفته می‌شود؛ در صورت مشکل می‌توانید آن را بازیابی کنید.</span>
              <span className="block text-rose-700 font-medium mt-2">
                همه داده‌های فعلی (کارکنان، فیش‌ها، نامه‌ها، تنظیمات و…) با محتوای فایل پشتیبان جایگزین می‌شود.
                اگر حساب کاربری شما در پشتیبان موجود نباشد، از سامانه خارج می‌شوید و باید با کاربر مدیر کل پشتیبان دوباره وارد شوید.
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              disabled={busy}
              className="bg-amber-600 hover:bg-amber-700"
              onClick={(e) => { e.preventDefault(); doRestore(); }}
            >
              {busy ? "در حال بازیابی…" : "بله، بازیابی کن"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

"use client";

// ============================================================
// مدیریت عناوین شغلی — در تنظیمات
// CRUD + ایمپورت/اکسپورت اکسل — قابل انتخاب در فرم کارمند
// ============================================================
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Plus, Search, Briefcase, Upload, Download, Trash2, Edit3 } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";
import { ExcelImportDialog, type ImportOutcome } from "../excel-import-dialog";
import { downloadExcel, pick, cellStr, cellBool, cellInt } from "@/lib/excel";

export interface JobRow {
  id: string;
  code: string;
  title: string;
  jobGradeId: string | null;
  gradeLevel: number | null;
  gradeTitle: string;
  description: string;
  isActive: boolean;
  employeeCount: number;
}

interface GradeRow { id: string; level: number; title: string }

export function JobsManager({ canEdit }: { canEdit: boolean }) {
  const { toast } = useToast();
  const [q, setQ] = useState("");
  const list = useApi<{ jobs: JobRow[] }>("/api/jobs");
  const grades = useApi<{ grades: GradeRow[] }>("/api/grades");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<JobRow | null>(null);
  const [importOpen, setImportOpen] = useState(false);

  const rows = useMemo(() => {
    const all = list.data?.jobs || [];
    if (!q.trim()) return all;
    const t = q.trim();
    return all.filter((j) => j.title.includes(t) || j.code.toLowerCase().includes(t.toLowerCase()) || j.description.includes(t));
  }, [list.data, q]);

  async function toggleActive(job: JobRow) {
    try {
      await api(`/api/jobs/${job.id}`, { method: "PATCH", json: { isActive: !job.isActive } });
      list.refetch();
      toast({ title: job.isActive ? "عنوان شغل غیرفعال شد" : "عنوان شغل فعال شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function remove(job: JobRow) {
    try {
      await api(`/api/jobs/${job.id}`, { method: "DELETE" });
      list.refetch();
      toast({ title: "عنوان شغل حذف شد" });
    } catch (e) {
      toast({ title: "حذف ممکن نیست", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  function exportExcel() {
    const rows = (list.data?.jobs || []).map((j) => ({
      "عنوان شغل": j.title,
      "کد": j.code,
      "سطح": j.gradeLevel || "",
      "توضیحات": j.description,
      "فعال": j.isActive ? "بله" : "خیر",
    }));
    downloadExcel("مشاغل.xlsx", "مشاغل", rows);
  }

  function parseJobRow(row: Record<string, unknown>): { data: { title: string; code: string; gradeLevel: number | null; description: string; isActive: boolean }; errors: string[] } {
    const errors: string[] = [];
    const title = cellStr(pick(row, ["عنوان شغل", "عنوان", "شغل"]));
    const code = cellStr(pick(row, ["کد", "کد شغل"]));
    const levelRaw = pick(row, ["سطح", "طبقه", "سطح شغلی"]);
    const gradeLevel = levelRaw === undefined || cellStr(levelRaw) === "" ? null : cellInt(levelRaw);
    const description = cellStr(pick(row, ["توضیحات", "شرح"]));
    const isActive = cellBool(pick(row, ["فعال", "وضعیت"]), true);

    if (!title) errors.push("عنوان شغل خالی است.");
    if (gradeLevel !== null && (gradeLevel < 1 || gradeLevel > 7)) errors.push("سطح باید بین ۱ تا ۷ باشد.");
    return { data: { title, code, gradeLevel, description, isActive }, errors };
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2 flex-wrap">
            <Briefcase className="w-4 h-4 text-teal-600" /> عناوین شغلی
            <Badge variant="outline">{toFaDigits(rows.length)} عنوان</Badge>
            {!canEdit && <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">فقط مشاهده</Badge>}
          </CardTitle>
          <p className="text-xs text-muted-foreground mt-1 leading-5">
            عناوین شغلی در این بخش تعریف می‌شوند و هنگام ثبت/ویرایش کارمند به‌صورت لیست انتخاب در اختیار شما قرار می‌گیرند.
            با ایمپورت اکسل می‌توانید گروهی از مشاغل را بارگذاری کنید.
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* نوار ابزار */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <Input className="pr-9" placeholder="جستجو: عنوان یا کد شغل..." value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <Button variant="outline" className="gap-1.5" onClick={exportExcel}>
              <Download className="w-4 h-4" /> خروجی اکسل
            </Button>
            {canEdit && (
              <Button variant="outline" className="gap-1.5" onClick={() => setImportOpen(true)}>
                <Upload className="w-4 h-4" /> ایمپورت اکسل
              </Button>
            )}
            {canEdit && (
              <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
                <Plus className="w-4 h-4" /> شغل جدید
              </Button>
            )}
          </div>

          {/* جدول */}
          {list.loading ? (
            <div className="space-y-2">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-11" />)}</div>
          ) : rows.length === 0 ? (
            <div className="py-10 text-center">
              <Briefcase className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">عنوان شغلی تعریف نشده است</p>
              {canEdit && <p className="text-xs text-muted-foreground mt-1">با «شغل جدید» یا «ایمپورت اکسل» شروع کنید</p>}
            </div>
          ) : (
            <div className="overflow-x-auto rounded-xl border">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    <TableHead className="text-right">کد</TableHead>
                    <TableHead className="text-right">عنوان شغل</TableHead>
                    <TableHead className="text-center">طبقه (سطح)</TableHead>
                    <TableHead className="text-center">کارکنان</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    {canEdit && <TableHead className="text-center">عملیات</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((j) => (
                    <TableRow key={j.id} className="hover:bg-teal-50/40">
                      <TableCell className="tabular-nums text-xs text-muted-foreground" dir="ltr">{j.code}</TableCell>
                      <TableCell className="font-medium">
                        {j.title}
                        {j.description && <span className="block text-[11px] text-muted-foreground font-normal">{j.description}</span>}
                      </TableCell>
                      <TableCell className="text-center text-sm">
                        {j.gradeLevel ? <Badge variant="outline">سطح {toFaDigits(j.gradeLevel)} — {j.gradeTitle}</Badge> : <span className="text-muted-foreground text-xs">—</span>}
                      </TableCell>
                      <TableCell className="text-center tabular-nums text-sm">{j.employeeCount > 0 ? toFaDigits(j.employeeCount) : <span className="text-muted-foreground">—</span>}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={j.isActive ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                          {j.isActive ? "فعال" : "غیرفعال"}
                        </Badge>
                      </TableCell>
                      {canEdit && (
                        <TableCell className="text-center">
                          <div className="flex justify-center gap-1">
                            <button className="p-1.5 rounded-lg hover:bg-amber-100 text-amber-600" title="ویرایش" onClick={() => { setEditing(j); setFormOpen(true); }}>
                              <Edit3 className="w-4 h-4" />
                            </button>
                            <button
                              className={`p-1.5 rounded-lg ${j.isActive ? "hover:bg-slate-100 text-slate-500" : "hover:bg-emerald-100 text-emerald-600"}`}
                              title={j.isActive ? "غیرفعال کردن" : "فعال کردن"}
                              onClick={() => toggleActive(j)}
                            >
                              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2">
                                {j.isActive ? <path d="M18.36 6.64A9 9 0 1 1 5.64 6.64M12 2v10" strokeLinecap="round" /> : <path d="M12 2v10m6.36-5.36A9 9 0 1 1 5.64 6.64" strokeLinecap="round" />}
                              </svg>
                            </button>
                            <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title="حذف" onClick={() => remove(j)}>
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* فرم تعریف/ویرایش */}
      <JobForm
        open={formOpen}
        onOpenChange={setFormOpen}
        editing={editing}
        grades={grades.data?.grades || []}
        onSaved={() => { list.refetch(); toast({ title: editing ? "عنوان شغل به‌روزرسانی شد" : "عنوان شغل جدید تعریف شد", description: "در لاگ حسابرسی ثبت گردید." }); }}
      />

      {/* ایمپورت اکسل */}
      {canEdit && (
        <ExcelImportDialog
          open={importOpen}
          onOpenChange={setImportOpen}
          title="ایمپورت عناوین شغلی از اکسل"
          description="فایل اکسل شامل عناوین شغلی را انتخاب کنید. ردیف‌ها بر اساس کد (یا عنوان) به‌روزرسانی یا ایجاد می‌شوند."
          endpoint="/api/jobs/import"
          templateFilename="قالب-مشاغل.xlsx"
          sheetName="مشاغل"
          headers={["عنوان شغل", "کد (اختیاری)", "سطح ۱ تا ۷ (اختیاری)", "توضیحات", "فعال (بله/خیر)"]}
          sampleRows={[
            { "عنوان شغل": "کارشناس منابع انسانی", "کد": "JOB-101", "سطح": 3, "توضیحات": "جذب و استخدام", "فعال": "بله" },
            { "عنوان شغل": "حسابدار ارشد", "کد": "JOB-102", "سطح": 4, "توضیحات": "حسابداری مالی", "فعال": "بله" },
            { "عنوان شغل": "برنامه‌نویس ارشد", "کد": "JOB-103", "سطح": 5, "توضیحات": "توسعه نرم‌افزار", "فعال": "بله" },
          ]}
          parseRow={parseJobRow}
          onImported={(_outcome: ImportOutcome) => list.refetch()}
        />
      )}
    </div>
  );
}

// ================= فرم شغل =================
function JobForm({ open, onOpenChange, editing, grades, onSaved }: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editing: JobRow | null;
  grades: GradeRow[];
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [f, setF] = useState(() => ({
    title: editing?.title || "",
    code: editing?.code || "",
    jobGradeId: editing?.jobGradeId || "none",
    description: editing?.description || "",
    isActive: editing?.isActive ?? true,
  }));
  const [lastKey, setLastKey] = useState(editing?.id || "new");
  const key = editing?.id || "new";
  if (lastKey !== key) {
    setLastKey(key);
    setF({
      title: editing?.title || "",
      code: editing?.code || "",
      jobGradeId: editing?.jobGradeId || "none",
      description: editing?.description || "",
      isActive: editing?.isActive ?? true,
    });
  }

  async function save() {
    if (!f.title.trim()) {
      toast({ title: "عنوان شغل الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: f.title.trim(),
        code: f.code.trim(),
        jobGradeId: f.jobGradeId === "none" ? null : f.jobGradeId,
        description: f.description.trim(),
        isActive: f.isActive,
      };
      if (editing) {
        await api(`/api/jobs/${editing.id}`, { method: "PATCH", json: payload });
      } else {
        await api("/api/jobs", { method: "POST", json: payload });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? `ویرایش عنوان شغل — ${editing.title}` : "تعریف عنوان شغل جدید"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان شغل <span className="text-rose-600">*</span></Label>
            <Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="مثلاً: کارشناس منابع انسانی" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs">کد (اختیاری)</Label>
              <Input dir="ltr" className="text-left" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} placeholder="خودکار: JOB-001" disabled={!!editing} />
              <p className="text-[10px] text-muted-foreground">{editing ? "کد قابل تغییر نیست" : "خالی بگذارید تا سیستمی تولید شود"}</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">طبقه شغلی (اختیاری)</Label>
              <Select value={f.jobGradeId} onValueChange={(v) => setF({ ...f, jobGradeId: v })}>
                <SelectTrigger><SelectValue placeholder="بدون طبقه" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون طبقه</SelectItem>
                  {grades.map((g) => <SelectItem key={g.id} value={g.id}>سطح {toFaDigits(g.level)} — {g.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">توضیحات</Label>
            <Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          </div>
          <div className="flex items-center justify-between rounded-xl border px-3.5 py-2.5">
            <div>
              <p className="text-sm font-medium">فعال</p>
              <p className="text-[11px] text-muted-foreground">عناوین غیرفعال در فرم کارمند نمایش داده نمی‌شوند</p>
            </div>
            <Switch checked={f.isActive} onCheckedChange={(v) => setF({ ...f, isActive: v })} />
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">{saving ? "..." : "ذخیره"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

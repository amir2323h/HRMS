"use client";

// ============================================================
// مستندات فنی سامانه — ۴ سند: معماری، دیتابیس، الگوریتم معکوس، UI/UX
// ============================================================
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Database, Calculator, Layout, Server } from "lucide-react";

function Code({ children }: { children: string }) {
  return (
    <pre className="text-[11.5px] leading-6 bg-slate-900 text-teal-100 rounded-xl p-4 overflow-x-auto my-3" dir="ltr">
      <code>{children}</code>
    </pre>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="space-y-3">
      <h3 className="font-bold text-slate-800 text-[15px] border-r-3 border-teal-500 pr-3">{title}</h3>
      <div className="text-sm text-slate-600 leading-7 space-y-3">{children}</div>
    </section>
  );
}

export function DocsView() {
  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-slate-800 to-teal-900 text-white">
        <CardContent className="p-5 flex items-center gap-4 flex-wrap">
          <BookOpen className="w-10 h-10 text-teal-300 shrink-0" />
          <div className="flex-1 min-w-[240px]">
            <h2 className="font-bold text-lg">مستندات فنی سامانه</h2>
            <p className="text-sm text-teal-100/80 mt-1">معماری سیستم، طراحی دیتابیس، مشخصات الگوریتم محاسبه معکوس و راهنمای UI/UX</p>
          </div>
          <Badge className="bg-teal-500/20 text-teal-200 hover:bg-teal-500/20 border border-teal-400/30">نسخه ۱.۰ — مهر ۱۴۰۵</Badge>
        </CardContent>
      </Card>

      <Tabs defaultValue="arch" dir="rtl">
        <TabsList className="w-full flex-wrap h-auto">
          <TabsTrigger value="arch" className="gap-1.5 flex-1"><Server className="w-3.5 h-3.5" /> معماری و پشته فناوری</TabsTrigger>
          <TabsTrigger value="db" className="gap-1.5 flex-1"><Database className="w-3.5 h-3.5" /> طراحی دیتابیس</TabsTrigger>
          <TabsTrigger value="algo" className="gap-1.5 flex-1"><Calculator className="w-3.5 h-3.5" /> الگوریتم معکوس</TabsTrigger>
          <TabsTrigger value="ui" className="gap-1.5 flex-1"><Layout className="w-3.5 h-3.5" /> راهنمای UI/UX</TabsTrigger>
        </TabsList>

        {/* ================= معماری ================= */}
        <TabsContent value="arch" className="mt-4 space-y-5">
          <Card className="rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-base">۱. معماری کلی سامانه</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <Section title="الگوی معماری">
                <p>
                  سامانه بر پایه معماری <b>یکپارچه تمام‌پشته (Full-Stack Monolith)</b> با تفکیک لایه‌ای ساخته شده است. لایه نمایش (SPA تک‌صفحه‌ای)،
                  لایه API (مسیرهای REST سرور Next.js) و لایه دسترسی داده (Prisma ORM) در یک پروژه واحد نگهداری می‌شوند؛ این انتخاب برای تیم‌های کوچک تا متوسط،
                  استقرار ساده و هزینه نگهداری پایین بهینه است. مسیریابی داخلی با الگوی Hash Router انجام می‌شود تا کل تجربه کاربری در یک مسیر ارائه شود.
                </p>
                {/* دیاگرام لایه‌ای */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 my-4" dir="rtl">
                  {[
                    { t: "لایه نمایش", d: "React 19 + Tailwind 4 + shadcn/ui — RTL کامل", c: "from-teal-500 to-teal-600" },
                    { t: "لایه API", d: "Next.js Route Handlers (REST) + اعتبارسنجی ورودی + RBAC", c: "from-teal-600 to-cyan-700" },
                    { t: "موتور محاسبه", d: "موتور حقوق مستقیم + موتور معکوس دو-بخشی (Pure TS)", c: "from-cyan-700 to-teal-800" },
                    { t: "لایه داده", d: "Prisma ORM + SQLite (قابل تبدیل به Postgres)", c: "from-slate-700 to-teal-900" },
                  ].map((l, i) => (
                    <div key={i} className={`rounded-xl bg-gradient-to-b ${l.c} text-white p-4 text-center`}>
                      <p className="font-bold text-sm">{l.t}</p>
                      <p className="text-[11px] opacity-80 mt-1.5 leading-4">{l.d}</p>
                    </div>
                  ))}
                </div>
              </Section>

              <Section title="۲. پشته فناوری پیشنهادی (پیاده‌سازی فعلی و مسیر تولید)">
                <div className="overflow-x-auto rounded-xl border">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 text-slate-600">
                      <tr>
                        <th className="p-2.5 text-right font-medium">لایه</th>
                        <th className="p-2.5 text-right font-medium">فناوری نسخه نمایشی</th>
                        <th className="p-2.5 text-right font-medium">توصیه تولید (Scale)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {[
                        ["فرانت‌اند", "Next.js 16 (App Router) + React 19 + TypeScript 5", "همان + SSR برای SEO پرتال"],
                        ["استایل", "Tailwind CSS 4 + shadcn/ui + فونت لوکال Vazirmatn", "همان (Asset‌ها لوکال serve شوند)"],
                        ["API", "Route Handlers داخلی /api/*", "NestJS یا Go برای تفکیک خدمت‌محور"],
                        ["موتور محاسبه", "TypeScript خالص (engine.ts / reverse.ts)", "همان + تست واحد جامع + نسخه‌بندی قانون سالانه"],
                        ["دیتابیس", "SQLite (فایل محلی)", "PostgreSQL 16 (مالکیت چند-مستأجری Row-Level)"],
                        ["احراز هویت", "کوکی امضاشده HMAC + scrypt", "OAuth2/OIDC + JWT + Refresh Token"],
                        ["لاگ حسابرسی", "جدول AuditLog + ثبت در هر جهش", "Append-only + WORM ذخیره‌سازی"],
                      ].map((r, i) => (
                        <tr key={i}>
                          <td className="p-2.5 font-medium text-slate-700">{r[0]}</td>
                          <td className="p-2.5 text-slate-600">{r[1]}</td>
                          <td className="p-2.5 text-slate-600">{r[2]}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </Section>

              <Section title="۳. چرخه محاسبه حقوق (Data Flow)">
                <Code>{`کارمند (پرونده) + طبقه شغلی + پارامترهای قانونی ۱۴۰۵ (جدول TaxBracket + SystemSetting)
        │
        ▼
  موتور محاسبه مستقیم  computePaysheet(base, ctx, params)
        │   حقوق پایه + سنوات + مسکن + بن + اولاد + جذب + اضافه‌کاری(×۱.۴)
        │   ├─ مشمول بیمه = پایه + اضافه‌کاری  →  کف: حداقل دستمزد ۱۶۶,۲۵۵,۵۰۰ ریال
        │   ├─ بیمه کارمند ۷٪ / کارفرما ۲۰٪ + ۳٪
        │   ├─ درآمد مشمول مالیات = Σ(اقلام مشمول) − بیمه کارمند (ماده ۹۲ ق.م.م)
        │   └─ مالیات = پله‌ای ۶ گانه ماده ۸۵ بودجه ۱۴۰۵
        ▼
  Payslip (ذخیره در دوره PayrollPeriod)  ──►  خروجی‌ها:
        │                                        ├─ دیسکت بیمه (SSO)
        │                                        ├─ فایل مالیاتی (INTA)
        │                                        ├─ فایل ۴ بانک (شبا/مبلغ)
        │                                        └─ گزارش مرکز هزینه (تجمیع دپارتمانی)
        ▼
  لاگ حسابرسی: هر محاسبه/تغییر با کاربر و مهر زمانی`}</Code>
              </Section>

              <Section title="۴. چند-مستأجری (Multi-Tenant)">
                <p>
                  اسکیمای فعلی با کلیدهای خارجی آماده چند-مستأجری است: کافی است جدول <b>Company</b> معرفی و ستون <b>companyId</b> به
                  جداول Employee، PayrollPeriod و SystemSetting افزوده شود؛ در PostgreSQL با <b>Row-Level Security</b> ایزوله‌سازی در سطح
                  دیتابیس و در لایه برنامه با فیلتر نشست کاربر انجام می‌شود. نسخه نمایشی برای سادگی، تک-مستأجر با یک شرکت فعال است.
                </p>
              </Section>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ================= دیتابیس ================= */}
        <TabsContent value="db" className="mt-4 space-y-5">
          <Card className="rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-base">۲. طراحی دیتابیس — ۱۲ جدول</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <Section title="نمودار رابطه موجودیت‌ها (ERD)">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px]" dir="rtl">
                  <div className="space-y-3">
                    <ErdBox title="User" fields={["username 🔑", "passwordHash", "role (RBAC)", "employeeId → Employee"]} accent="border-rose-300" />
                    <ErdBox title="Department" fields={["code 🔑", "name", "parentId ↺ (درخت)", "costCenterCode"]} accent="border-teal-300" />
                    <ErdBox title="EmployeeDepartment" fields={["employeeId", "departmentId", "allocationPercent"]} accent="border-teal-300" />
                  </div>
                  <div className="space-y-3">
                    <ErdBox title="Employee" fields={["personnelCode 🔑", "nationalId, ssoNumber", "hireDateJ, contractEndJ", "probationEndDateJ", "baseSalary (ریال)", "jobGradeId → JobGrade", "iban, bankName"]} accent="border-emerald-300" />
                    <ErdBox title="JobGrade (۷ سطح)" fields={["level 🔑 ۱..۷", "min/maxBaseSalary", "seniorityBase", "attraction"]} accent="border-emerald-300" />
                    <ErdBox title="Document" fields={["employeeId →", "type (قرارداد/سفته/چک)", "data (باینری امن)"]} accent="border-slate-300" />
                  </div>
                  <div className="space-y-3">
                    <ErdBox title="PayrollPeriod" fields={["(year,month) 🔑", "status (محاسبه/تأیید/پرداخت)"]} accent="border-amber-300" />
                    <ErdBox title="Payslip" fields={["periodId →, employeeId →", "اجزا: پایه/سنوات/مسکن/بن/اولاد/جذب/اضافه‌کاری", "gross, insurableBase", "بیمه ۷٪/۲۰٪/۳٪", "taxableIncome, incomeTax", "netPay", "isReverse, targetNet"]} accent="border-amber-300" />
                    <ErdBox title="TaxBracket + SystemSetting" fields={["پله‌های ماده ۸۵", "پارامترهای ۱۴۰۵ (JSON)"]} accent="border-indigo-300" />
                    <ErdBox title="AuditLog + Leave/AdvanceRequest" fields={["user, action, before/after JSON", "درخواست‌های خودخدماتی"]} accent="border-slate-300" />
                  </div>
                </div>
              </Section>

              <Section title="تصمیمات کلیدی طراحی">
                <ul className="space-y-2 list-disc pr-5">
                  <li><b>واحد پول ریال به‌صورت BigInt:</b> مبالغ تا ده‌ها میلیارد ریال بدون خطای گرد‌کردن float ذخیره می‌شوند؛ نمایش در UI به تومان تبدیل و با ارقام فارسی جداکننده‌دار ارائه می‌شود.</li>
                  <li><b>تاریخ‌های جلالی به‌صورت رشته YYYY/MM/DD:</b> خوانایی انسانی، مرتب‌سازی واژه‌نامه‌ای درست و عدم نیاز به تبدیل در کوئری‌های گزارش؛ الگوریتم تبدیل جلالی↔میلادی در lib/jalali.ts به‌صورت بومی (بدون وابستگی) پیاده شده است.</li>
                  <li><b>جزء‌محوری فیش حقوقی:</b> هر Payslip اجزای مستقل دارد؛ افزودن مزایای جدید (حق جذب منطقه‌ای، ایاب‌ذهاب و…) بدون تغییر اسکیما ممکن است.</li>
                  <li><b>جداسازی پارامترهای قانونی از کد:</b> پله‌های مالیاتی و مزایا در جداول TaxBracket/SystemSetting نگهداری و سالانه قابل به‌روزرسانی هستند — بدون نیاز به تغییر نرم‌افزار.</li>
                  <li><b>لاگ حسابرسی با قبل/بعد:</b> ستون‌های before/after مقادیر JSON دارند تا تغییرات حقوق و پارامترها قابل ردیابی قضایی باشند.</li>
                </ul>
              </Section>

              <Section title="DDL نمونه (PostgreSQL)">
                <Code>{`CREATE TABLE employees (
  id               TEXT PRIMARY KEY,
  personnel_code   TEXT UNIQUE NOT NULL,
  first_name       TEXT NOT NULL,
  last_name        TEXT NOT NULL,
  national_id      CHAR(10),
  sso_number       TEXT,
  hire_date_j      TEXT NOT NULL,          -- '1405/01/15'
  probation_end_j  TEXT,
  contract_type    TEXT NOT NULL,          -- PERMANENT|FIXED|TEMPORARY|PROBATION
  contract_end_j   TEXT,
  job_grade_id     TEXT REFERENCES job_grades(id),
  base_salary      BIGINT NOT NULL,        -- ریال
  child_count      SMALLINT DEFAULT 0,
  iban             TEXT,
  status           TEXT DEFAULT 'ACTIVE'
);

CREATE TABLE payslips (
  id                TEXT PRIMARY KEY,
  period_id         TEXT REFERENCES payroll_periods(id) ON DELETE CASCADE,
  employee_id       TEXT REFERENCES employees(id) ON DELETE CASCADE,
  base_salary       BIGINT NOT NULL,
  housing           BIGINT DEFAULT 0,
  grocery           BIGINT DEFAULT 0,
  child_allowance   BIGINT DEFAULT 0,
  overtime_amount   BIGINT DEFAULT 0,
  gross             BIGINT NOT NULL,
  insurable_base    BIGINT NOT NULL,
  employee_sso      BIGINT NOT NULL,        -- ۷٪
  employer_sso20    BIGINT NOT NULL,        -- ۲۰٪
  unemployment_sso3 BIGINT NOT NULL,        -- ۳٪
  taxable_income    BIGINT NOT NULL,
  income_tax        BIGINT NOT NULL,
  net_pay           BIGINT NOT NULL,
  is_reverse        BOOLEAN DEFAULT FALSE,
  target_net        BIGINT
);
CREATE INDEX idx_payslips_period ON payslips(period_id);
CREATE INDEX idx_payslips_employee ON payslips(employee_id);`}</Code>
              </Section>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ================= الگوریتم معکوس ================= */}
        <TabsContent value="algo" className="mt-4 space-y-5">
          <Card className="rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-base">۳. مشخصات ریاضی و الگوریتم موتور معکوس</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <Section title="تعریف مسئله">
                <p>
                  در محاسبه معمولی، از حقوق پایه به خالص می‌رسیم. در <b>محاسبه معکوس</b>، خالص پرداختی هدف (N*) داده می‌شود و باید
                  <b> حقوق پایه (B)</b> و تمام اجزای واسط چنین به دست آیند که خالص دقیقاً برابر هدف باشد. این مسئله به دلیل ماهیت
                  <b> پلکانی مالیات</b>، معادله‌ای غیرخطی و تکه‌ای-خطی است و جواب تحلیلی بسته ساده ندارد؛ اما ساختار ریاضی آن حل عددی پایدار را ممکن می‌کند.
                </p>
              </Section>

              <Section title="مدل ریاضی (متغیر B = حقوق پایه، ریال)">
                <Code>{`gross(B)  = B + S + H + G + C + A + OT          (S=سنوات, H=مسکن, G=بن, C=اولاد, A=جذب, OT=اضافه‌کاری)

insurable(B) = max(B + OT, W_min)              (W_min = حداقل دستمزد ۱۴۰۵ = ۱۶۶,۲۵۵,۵۰۰ ریال)

sso_emp(B) = 7% × insurable(B)                  (ماده ۲۸ قانون تأمین اجتماعی)

taxable(B) = gross(B) − sso_emp(B)              (ماده ۹۲ ق.م.م — کسر حق بیمه کارمند)

tax(x) = Σₖ  rateₖ × max(0, min(x, capₖ) − floorₖ)     (پله‌های ماده ۸۵ بودجه ۱۴۰۵)

net(B)   = gross(B) − sso_emp(B) − tax(taxable(B))

══════════ معادله معکوس: یافتن B به‌طوری‌که net(B) = N* ══════════`}</Code>
              </Section>

              <Section title="تحلیل یکتایی و همگرایی">
                <ul className="space-y-2 list-disc pr-5">
                  <li><b>پیوستگی و اکیداً صعودی بودن:</b> با ثابت بودن مزایای غیرپایه، gross و sso_emp نسبت به B خطی و نایاب‌کاهنده‌اند؛ tax نیز نایاب‌کاهنده است؛ در نتیجه net(B) <b>اکیداً صعودی</b> است ⇒ جواب حداکثر یکتاست.</li>
                  <li><b>باند شیب:</b> در بدترین حالت (پله ۳۰٪)، شیب خالص نسبت به پایه برابر ۰.۹۳ × (۱−۰.۳) ≈ <b>۰.۶۵</b> است؛ یعنی هر ۱۰۰ ریال افزایش پایه، حداقل ۶۵ ریال خالص می‌افزاید — ضریب اطمینان همگرایی.</li>
                  <li><b>نرخ همگرایی دو-بخشی:</b> بازه جستجو (۰ تا ~۱۶۰ میلیارد ریال) با ~<b>۳۷ تکرار</b> به دقت ۱ ریال می‌رسد (۲³⁷ ≈ ۱.۴×۱۰¹¹)؛ در عمل با شرط توقف |net−N*|≤1 حدود ۲۹ تا ۳۵ تکرار.</li>
                </ul>
              </Section>

              <Section title="شبه‌کد الگوریتم (Bisection)">
                <Code>{`function computeReverse(targetNet N*, ctx, params):
    if N* < net(base=0):        # کمتر از خالصِ مزایای ثابت
        return FAIL("هدف زیر حد قابل‌تحقق")

    lo ← 0
    hi ← max(12 × W_min, 4 × N*, 10⁹)
    while net(hi) < N*:  hi ← hi × 2            # گسترش کران بالا

    repeat (حداکثر ۲۰۰ بار):
        mid ← ⌊(lo + hi) / 2⌋
        err ← net(mid) − N*                    # محاسبه مستقیم کامل فیش
        log(step, lo, hi, mid, net(mid), err)  # جدول شفافیت تکرار
        if err == 0: break
        if err < 0: lo ← mid                   # خالص کمتر از هدف ⇒ افزایش پایه
        else:        hi ← mid
        if hi − lo ≤ 1: choose nearest(lo, hi); break

    round B به مضرب اختیاری (مثلاً ۱۰ هزار تومان)
    recompute فیش کامل در B نهایی → گزارش اختلاف residual
    warn اگر B خارج از باند طبقه یا کمتر از حداقل دستمزد`}</Code>
              </Section>

              <Section title="چرا دو-بخشی و نه روش‌های دیگر؟">
                <p>
                  ۱) <b>استحکام در برابر تغییر قانون:</b> هر تغییری در پله‌ها، نرخ‌ها یا کف بیمه فقط net(·) را عوض می‌کند؛ الگوریتم بدون هیچ تغییری همچنان معتبر است.
                  ۲) <b>دقت صحیح عددی:</b> همه محاسبات با اعداد صحیح ریالی انجام می‌شود (بدون float) — خطا حداکثر ۱ ریال ناشی از گرد کردن بیمه است.
                  ۳) <b>شفافیت قابل ارائه:</b> جدول تکرارها در UI نمایش داده می‌شود و مسیر رسیدن به جواب برای کارشناس حقوق قابل ممیزی است.
                  ۴) <b>سرعت کافی:</b> هر تکرار فقط یک محاسبه ساده O(تعداد پله) است؛ کل حل زیر چند میلی‌ثانیه — نیازی به مشتق‌گیری (Newton) یا جستجوی خطی ۱۰⁸تایی نیست.
                </p>
              </Section>

              <Section title="نمونه عددی واقعی (خروجی موتور)">
                <div className="overflow-x-auto rounded-xl border">
                  <table className="w-full text-xs">
                    <thead className="bg-slate-50 text-slate-600">
                      <tr>
                        <th className="p-2.5 text-right">خالص هدف (تومان)</th>
                        <th className="p-2.5 text-left">حقوق پایه معکوس (تومان)</th>
                        <th className="p-2.5 text-left">بیمه ۷٪</th>
                        <th className="p-2.5 text-left">مالیات</th>
                        <th className="p-2.5 text-center">خطا (ریال)</th>
                        <th className="p-2.5 text-center">تکرار</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y tabular-nums">
                      {[
                        ["۲۰,۰۰۰,۰۰۰", "۱۴,۳۰۱,۲۳۳", "۱,۱۶۳,۷۸۸", "۰", "۰", "۳۰"],
                        ["۵۰,۰۰۰,۰۰۰", "۴۷,۳۱۶,۲۴۹", "۳,۳۱۲,۱۳۷", "۸۶۶,۶۶۶", "۰", "۳۱"],
                        ["۸۰,۰۰۰,۰۰۰", "۸۳,۲۸۵,۰۴۵", "۵,۸۲۹,۹۵۳", "۴,۳۱۷,۶۴۷", "۰", "۲۹"],
                        ["۲۰۰,۰۰۰,۰۰۰", "۲۵۸,۸۸۸,۱۸۹", "۱۸,۱۲۲,۱۷۳", "۴۷,۶۲۸,۵۷۱", "۰", "۲۹"],
                      ].map((r, i) => (
                        <tr key={i}>
                          <td className="p-2.5 font-bold">{r[0]}</td>
                          <td className="p-2.5 text-left">{r[1]}</td>
                          <td className="p-2.5 text-left text-amber-700">{r[2]}</td>
                          <td className="p-2.5 text-left text-rose-700">{r[3]}</td>
                          <td className="p-2.5 text-center text-emerald-600">{r[4]}</td>
                          <td className="p-2.5 text-center">{r[5]}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-muted-foreground">سناریو: بدون طبقه، بدون فرزند، با مسکن و بن ۱۴۰۵ — خطای صفر ریال تأیید رفت‌وبرگشت دقیق موتور است.</p>
              </Section>

              <Section title="حالات خاص پوشش‌داده‌شده">
                <ul className="space-y-2 list-disc pr-5">
                  <li>هدف کمتر از کمینه خالصِ مزایای ثابت → پیام «قابل‌تحقق نیست» با کمینه ممکن</li>
                  <li>حقوق پایه زیر حداقل دستمزد یا خارج از باند طبقه → هشدار (نه خطا) + ادامه محاسبه</li>
                  <li>گرد کردن پایه به مضرب دلخواه → محاسبه مجدد خالص واقعی و نمایش اختلاف</li>
                  <li>اثر کف بیمه (پایه &lt; حداقل) و سقب اختیاری مشمول بیمه</li>
                </ul>
              </Section>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ================= UI/UX ================= */}
        <TabsContent value="ui" className="mt-4 space-y-5">
          <Card className="rounded-2xl">
            <CardHeader className="pb-2"><CardTitle className="text-base">۴. راهنمای طراحی UI/UX و وایرفریم‌ها</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <Section title="اصول حاکم بر طراحی">
                <ul className="space-y-2 list-disc pr-5">
                  <li><b>RTL بومی:</b> سایدبار سمت راست، آیکون‌های جهت‌دار قرینه (rtl-flip)، اعداد فارسی با فونت Vazirmatn (لوکال، بدون CDN) و ارقام هم‌عرض (tnum) در جداول مالی.</li>
                  <li><b>زبان یکدست تخصصی:</b> واژگان دقیق حوزه منابع انسانی ایران (خالص پرداختی، مشمول بیمه، حق بیمه سهم کارفرما، پله مالیاتی).</li>
                  <li><b>رنگ‌های معنایی:</b> فیروزه‌ای = عمل اصلی/تأکید؛ سبز = خالص/تأیید؛ کهربایی = بیمه/هشدار متوسط؛ قرمز = مالیات/کسورات/خطای فوری.</li>
                  <li><b>قانون طلایی اعداد:</b> هر مبلغ همیشه با واحد (تومان/ریال)، جداکننده هزارگان فارسی و در جداول هم‌تراز (tabular-nums).</li>
                  <li><b>دسترس‌پذیری:</b> ARIA فارسی روی کنترل‌ها، هدف لمسی ≥ ۴۴px، کنتراست AA، ناوبری کامل با کیبورد.</li>
                </ul>
              </Section>

              <Section title="وایرفریم ۱ — داشبورد مدیریتی">
                <Wireframe title="داشبورد">
                  <div className="grid grid-cols-4 gap-2 mb-2">
                    {[0, 1, 2, 3].map((i) => <div key={i} className="h-14 rounded-lg border-2 border-dashed border-teal-300 bg-teal-50/50 flex items-center justify-center text-[10px] text-teal-700">KPI {i + 1}</div>)}
                  </div>
                  <div className="grid grid-cols-5 gap-2">
                    <div className="col-span-3 h-24 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">روند هزینه ۷ ماه (Area Chart)</div>
                    <div className="col-span-2 h-24 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">BarList هزینه دپارتمان‌ها</div>
                    <div className="col-span-2 h-16 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">توزیع ۷ طبقه</div>
                    <div className="col-span-3 h-16 rounded-lg border-2 border-dashed border-amber-300 bg-amber-50/50 flex items-center justify-center text-[10px] text-amber-700">لیست هشدارها (آزمایشی/قرارداد)</div>
                  </div>
                </Wireframe>
              </Section>

              <Section title="وایرفریم ۲ — ماژول محاسبه معکوس">
                <Wireframe title="محاسبه معکوس">
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-2">
                      <div className="h-10 rounded-lg border-2 border-dashed border-teal-400 bg-teal-50/60 flex items-center justify-center text-[10px] text-teal-700 font-bold">خالص هدف (ورودی بزرگ + Preset)</div>
                      <div className="h-8 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">طبقه + فرزند + سنوات</div>
                      <div className="h-8 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">سوئیچ مسکن/بن + گرد کردن</div>
                      <div className="h-9 rounded-lg bg-teal-600 flex items-center justify-center text-[10px] text-white font-bold">دکمه «محاسبه معکوس»</div>
                    </div>
                    <div className="col-span-2 space-y-2">
                      <div className="grid grid-cols-3 gap-2">
                        <div className="h-14 rounded-lg bg-gradient-to-br from-teal-600 to-teal-700 flex items-center justify-center text-[10px] text-white font-bold">حقوق پایه معکوس</div>
                        <div className="h-14 rounded-lg border-2 border-dashed border-emerald-300 bg-emerald-50/50 flex items-center justify-center text-[10px] text-emerald-700">خالص محقق + هدف</div>
                        <div className="h-14 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">خطا + تعداد تکرار</div>
                      </div>
                      <div className="h-20 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">تب‌ها: تجزیه حقوق | پله‌های مالیات | جدول تکرار الگوریتم</div>
                      <div className="h-6 rounded-lg border-2 border-dashed border-amber-300 bg-amber-50/50 flex items-center justify-center text-[10px] text-amber-700">StackBar ترکیب هزینه + دکمه «ذخیره فیش»</div>
                    </div>
                  </div>
                </Wireframe>
              </Section>

              <Section title="وایرفریم ۳ — گزارش هزینه مراکز">
                <Wireframe title="گزارش مراکز هزینه">
                  <div className="h-8 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500 mb-2">انتخاب دوره + کارت‌های خروجی (بیمه/مالیات/۴ بانک)</div>
                  <div className="grid grid-cols-5 gap-2">
                    <div className="col-span-2 h-20 rounded-lg border-2 border-dashed border-teal-300 bg-teal-50/50 flex items-center justify-center text-[10px] text-teal-700">BarList سهم مراکز</div>
                    <div className="col-span-3 h-20 rounded-lg border-2 border-dashed border-slate-300 bg-slate-50/50 flex items-center justify-center text-[10px] text-slate-500">جدول: مرکز | نیرو | ناخالص | بیمه کارفرما | هزینه کل + ردیف جمع</div>
                  </div>
                </Wireframe>
              </Section>

              <Section title="فیش حقوقی چاپی">
                <p>
                  قالب کلاسیک دو ستونه «حقوق و مزایا | کسورات» با سربرگ کارفرما (شناسه ملی/کد کارگاه)، مشخصات بیمه‌شده، جمع مشمول بیمه،
                  درآمد مشمول مالیات و کادر متمایز خالص پرداختی؛ استایل چاپ A4 با <b>window.print()</b> و مخفی‌سازی پوسته — قابل ارائه به کارمند و بایگانی فیزیکی.
                </p>
              </Section>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ErdBox({ title, fields, accent }: { title: string; fields: string[]; accent: string }) {
  return (
    <div className={`rounded-xl border-2 ${accent} bg-white p-3 shadow-sm`}>
      <p className="font-bold text-slate-800 text-xs mb-2 pb-1.5 border-b">{title}</p>
      <ul className="space-y-1">
        {fields.map((f, i) => (
          <li key={i} className="text-[10.5px] text-slate-600 tabular-nums" dir="auto">{f}</li>
        ))}
      </ul>
    </div>
  );
}

function Wireframe({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-xl border bg-white p-3">
      <div className="flex items-center gap-2 mb-2">
        <span className="w-2 h-2 rounded-full bg-rose-400" />
        <span className="w-2 h-2 rounded-full bg-amber-400" />
        <span className="w-2 h-2 rounded-full bg-emerald-400" />
        <span className="text-[10px] text-slate-400 font-mono">{title}</span>
      </div>
      {children}
    </div>
  );
}

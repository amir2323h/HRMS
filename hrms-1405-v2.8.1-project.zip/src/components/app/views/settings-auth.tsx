"use client";

// ============================================================
// تنظیمات ورود و امنیت — ورود دو مرحله‌ای (2FA/TOTP) + ورود با گوگل
// کنترل از منوی تنظیمات (درخواست کاربر — موارد ۵ و ۷)
// ============================================================
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { Save, ShieldCheck, Smartphone, ExternalLink, CheckCircle2, KeyRound, Globe } from "lucide-react";
import { api } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";

// ============================ ورود دو مرحله‌ای (2FA) ============================
export function TwoFactorSettings({ canEdit }: { canEdit: boolean }) {
  const { toast } = useToast();
  const [enabled, setEnabled] = useState(false);
  const [stats, setStats] = useState<{ enrolled: number; total: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const d = await api<{ enabled: boolean; enrolled: number; total: number }>("/api/settings/auth2fa");
        setEnabled(d.enabled);
        setStats({ enrolled: d.enrolled, total: d.total });
      } catch {
        setEnabled(false);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function save(next: boolean) {
    setSaving(true);
    try {
      const d = await api<{ enabled: boolean; enrolled: number; total: number }>("/api/settings/auth2fa", {
        method: "PUT",
        json: { enabled: next },
      });
      setEnabled(d.enabled);
      setStats({ enrolled: d.enrolled, total: d.total });
      toast({
        title: d.enabled ? "ورود دو مرحله‌ای فعال شد" : "ورود دو مرحله‌ای غیرفعال شد",
        description: d.enabled
          ? "کاربران هنگام ورود با نام کاربری/رمز، کد ۶ رقمی اپ احرازکننده می‌خواهند — کاربران هنوز ثبت‌نام‌نشده در اولین ورود QR راهنما می‌بینند."
          : "ورود با نام کاربری/رمز مستقیماً انجام می‌شود.",
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <Skeleton className="h-56 rounded-2xl" />;

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2 flex-wrap">
          <Smartphone className="w-4 h-4 text-teal-600" />
          ورود دو مرحله‌ای (2FA)
          <Badge className={enabled ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
            {enabled ? "فعال" : "غیرفعال"}
          </Badge>
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          ورود دو مرحله‌ای مبتنی بر TOTP (استاندارد RFC 6238) — سازگار با Google Authenticator، Microsoft Authenticator
          و همه اپ‌های احرازکننده استاندارد. با فعال‌سازی، ورود با نام کاربری/رمز به کد ۶ رقمی نیاز دارد.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between rounded-xl border p-3">
          <div>
            <p className="text-sm font-medium">فعال‌سازی ورود دو مرحله‌ای برای همه کاربران</p>
            <p className="text-[11px] text-muted-foreground mt-0.5 leading-4">
              کاربران ثبت‌نام‌نشده در اولین ورود، QR راه‌اندازی اپ احرازکننده را می‌بینند و با اولین کد موفق ثبت‌نام می‌کنند.
            </p>
          </div>
          <Switch checked={enabled} onCheckedChange={(v) => canEdit && !saving && save(v)} disabled={!canEdit || saving} />
        </div>

        {stats && (
          <div className="rounded-xl border bg-slate-50/70 p-3 flex items-center gap-3 flex-wrap text-xs">
            <CheckCircle2 className={`w-4 h-4 shrink-0 ${stats.enrolled === stats.total && stats.total > 0 ? "text-emerald-600" : "text-amber-500"}`} />
            <span>
              وضعیت ثبت‌نام 2FA کاربران فعال: <b>{toFaDigits(stats.enrolled)}</b> از <b>{toFaDigits(stats.total)}</b>
              {enabled && stats.enrolled < stats.total ? " — کاربران ثبت‌نام‌نشده در ورود بعدی راهنمای راه‌اندازی می‌بینند." : ""}
            </span>
          </div>
        )}

        <div className="rounded-xl border border-teal-200 bg-teal-50/40 p-3 text-[11px] leading-6 text-slate-700 space-y-1">
          <p className="font-bold flex items-center gap-1"><KeyRound className="w-3.5 h-3.5" /> نکات مهم:</p>
          <p>• ورود یکپارچه با گوگل/Mattermost مشمول 2FA سامانه نیست — این سرویس‌ها 2FA خودشان را دارند.</p>
          <p>• اگر کاربر اپ احرازکننده‌اش را گم کند، مدیر از «تنظیمات ← کاربران ← بازنشانی 2FA» راز او را پاک می‌کند تا دوباره ثبت‌نام کند.</p>
          <p>• کد هر ۳۰ ثانیه تغییر می‌کند و تا ۳۰ ثانیه اختلاف ساعت سرور پذیرفته می‌شود.</p>
        </div>
      </CardContent>
    </Card>
  );
}

// ============================ ورود با حساب گوگل (Gmail) ============================
interface GoogleCfg {
  enabled: boolean;
  clientId: string;
  clientSecret: string;
  autoCreate: boolean;
  defaultRoleKey: string;
  buttonLabel: string;
  callbackBaseUrl: string;
  allowedDomain: string;
}

const GOOGLE_DEFAULTS: GoogleCfg = {
  enabled: false,
  clientId: "",
  clientSecret: "",
  autoCreate: true,
  defaultRoleKey: "EMPLOYEE",
  buttonLabel: "ورود با Gmail",
  callbackBaseUrl: "",
  allowedDomain: "",
};

export function GoogleLoginSettings({ canEdit, roles }: { canEdit: boolean; roles: { key: string; name: string }[] }) {
  const { toast } = useToast();
  const [f, setF] = useState<GoogleCfg | null>(null);
  const [saving, setSaving] = useState(false);
  const originUrl = typeof window !== "undefined" ? `${window.location.origin}/api/auth/google/callback` : "";
  const callbackUrl = f?.callbackBaseUrl ? `${f.callbackBaseUrl.replace(/\/+$/, "")}/api/auth/google/callback` : originUrl;

  useEffect(() => {
    (async () => {
      try {
        const d = await api<{ config: GoogleCfg }>("/api/settings/google");
        setF(d.config);
      } catch {
        setF({ ...GOOGLE_DEFAULTS });
      }
    })();
  }, []);

  if (!f) return <Skeleton className="h-64 rounded-2xl" />;

  async function save() {
    if (!f) return;
    if (f.enabled && (!f.clientId.trim() || !f.clientSecret.trim())) {
      toast({ title: "برای فعال‌سازی، Client ID و Client Secret الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const d = await api<{ config: GoogleCfg }>("/api/settings/google", { method: "PUT", json: f });
      setF(d.config);
      toast({
        title: "پیکربندی ورود گوگل ذخیره شد",
        description: d.config.enabled ? "دکمه «ورود با Gmail» در صفحه ورود نمایش داده می‌شود." : "ورود با گوگل غیرفعال است.",
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-sky-50 to-white border-sky-200">
        <CardContent className="p-4 flex items-start gap-3 flex-wrap">
          <Globe className="w-6 h-6 text-sky-600 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-[200px]">
            <p className="font-bold text-sm text-slate-800 flex items-center gap-2">
              ورود با حساب گوگل (Gmail) — OAuth 2.0 / OpenID Connect
              <Badge className={f.enabled ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>
                {f.enabled ? "فعال" : "غیرفعال"}
              </Badge>
            </p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              کاربران با حساب گوگل وارد می‌شوند — فقط ایمیل و نام خوانده می‌شود (دامنه‌ها: openid email profile).
              ورود با دامنه Gmail و دامنه سازمانی Google Workspace پشتیبانی می‌شود.
            </p>
          </div>
          {canEdit && (
            <Button className="bg-sky-600 hover:bg-sky-700 gap-1.5 shrink-0" onClick={save} disabled={saving}>
              <Save className="w-4 h-4" /> {saving ? "..." : "ذخیره"}
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="rounded-2xl">
          <CardHeader className="pb-3"><CardTitle className="text-sm">پارامترهای اتصال</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-xl border p-3">
              <div>
                <p className="text-sm font-medium">فعال‌سازی ورود با گوگل</p>
                <p className="text-[11px] text-muted-foreground mt-0.5">نمایش دکمه در صفحه ورود</p>
              </div>
              <Switch checked={f.enabled} onCheckedChange={(v) => canEdit && setF({ ...f, enabled: v })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Client ID</Label>
              <Input dir="ltr" value={f.clientId} onChange={(e) => setF({ ...f, clientId: e.target.value })} placeholder="xxxxx.apps.googleusercontent.com" disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Client Secret</Label>
              <Input dir="ltr" type="password" value={f.clientSecret} onChange={(e) => setF({ ...f, clientSecret: e.target.value })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">متن دکمه ورود</Label>
              <Input value={f.buttonLabel} onChange={(e) => setF({ ...f, buttonLabel: e.target.value })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">آدرس فال‌بک Callback (اختیاری)</Label>
              <Input
                dir="ltr"
                value={f.callbackBaseUrl}
                onChange={(e) => setF({ ...f, callbackBaseUrl: e.target.value })}
                placeholder="https://hr.example.com"
                disabled={!canEdit}
              />
              <p className="text-[11px] text-muted-foreground leading-5">
                اگر سامانه از چند دامنه/پورت باز می‌شود، این آدرس را تنظیم کنید تا مسیر بازگشت OAuth همیشه ثابت بماند.
                خالی = استخراج خودکار از آدرس جاری.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl">
          <CardHeader className="pb-3"><CardTitle className="text-sm">ساخت کاربر، نقش و محدودیت دامنه</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between rounded-xl border p-3">
              <div>
                <p className="text-sm font-medium">ساخت خودکار کاربر جدید</p>
                <p className="text-[11px] text-muted-foreground mt-0.5 leading-4">
                  اگر کاربری با حساب گوگل شناسایی نشود (نه اتصال موجود، نه تطبیق ایمیل) حساب جدید ساخته شود.
                </p>
              </div>
              <Switch checked={f.autoCreate} onCheckedChange={(v) => canEdit && setF({ ...f, autoCreate: v })} disabled={!canEdit} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">نقش کاربران جدید</Label>
              <select
                className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm"
                value={f.defaultRoleKey}
                onChange={(e) => setF({ ...f, defaultRoleKey: e.target.value })}
                disabled={!canEdit}
                dir="rtl"
              >
                {roles.length === 0 && <option value="EMPLOYEE">کارمند</option>}
                {roles.map((r) => <option key={r.key} value={r.key}>{r.name}</option>)}
              </select>
              <p className="text-[11px] text-muted-foreground">نقش را می‌توان بعداً از «کاربران و دسترسی» تغییر داد.</p>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">محدودیت دامنه ایمیل (اختیاری)</Label>
              <Input
                dir="ltr"
                value={f.allowedDomain}
                onChange={(e) => setF({ ...f, allowedDomain: e.target.value })}
                placeholder="company.com"
                disabled={!canEdit}
              />
              <p className="text-[11px] text-muted-foreground leading-5">
                فقط ایمیل‌های این دامنه (سازمانی Google Workspace) اجازه ورود دارند — خالی = همه ایمیل‌های گوگل.
              </p>
            </div>

            {/* راهنمای ثبت اپلیکیشن در کنسول گوگل */}
            <div className="rounded-xl border border-sky-200 bg-sky-50/50 p-3 text-[11px] leading-6 text-slate-700">
              <p className="font-bold mb-1 flex items-center gap-1"><ExternalLink className="w-3.5 h-3.5" /> ثبت اپلیکیشن در Google Cloud Console:</p>
              <ol className="list-decimal mr-4 space-y-0.5">
                <li>در <b>console.cloud.google.com</b> یک پروژه بسازید و به <b>APIs &amp; Services → OAuth consent screen</b> بروید (نوع External، دامنه‌های email/profile).</li>
                <li>از <b>Credentials → Create Credentials → OAuth Client ID</b> نوع <b>Web application</b> بسازید.</li>
                <li>در «Authorized redirect URIs» آدرس زیر را ثبت کنید.</li>
                <li>Client ID و Client Secret دریافتی را در فرم روبه‌رو وارد کنید.</li>
              </ol>
              <div className="mt-2 bg-white border rounded-lg p-2 font-mono text-[10px] break-all select-all" dir="ltr">
                {callbackUrl}
              </div>
              {f.callbackBaseUrl ? (
                <p className="mt-1.5 text-emerald-700">✓ مسیر فال‌بک فعال است — این آدرس ثابت در هر دو مرحله مجوز و تبادل توکن استفاده می‌شود.</p>
              ) : (
                <p className="mt-1.5 text-muted-foreground">مسیر فال‌بک تنظیم نشده — آدرس از مبدأ جاری درخواست استخراج می‌شود.</p>
              )}
            </div>
            {f.enabled && f.clientId && f.clientSecret && (
              <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-3 text-[11px] text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                پیکربندی کامل است — دکمه «{f.buttonLabel}» در صفحه ورود نمایش داده می‌شود.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="rounded-2xl bg-slate-50">
        <CardContent className="p-4 text-[11px] text-muted-foreground leading-6">
          <p className="font-bold text-slate-700 mb-1 flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> جریان استاندارد OAuth 2.0:</p>
          <p className="font-mono bg-white border rounded-lg p-2 inline-block" dir="ltr">
            accounts.google.com/o/oauth2/v2/auth → redirect ?code → oauth2.googleapis.com/token → openidconnect…/v1/userinfo → نشست سامانه
          </p>
          <p className="mt-1.5">
            state تصادفی برای محافظت CSRF در کوکی کوتاه‌مدت ذخیره می‌شود؛ نشست پس از تبادل توکن با کوکی امن + Bearer ایجاد می‌گردد.
            کاربران گوگل با ایمیل متناظر پروفایل کارکنان به‌طور خودکار به پرونده‌شان متصل می‌شوند.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

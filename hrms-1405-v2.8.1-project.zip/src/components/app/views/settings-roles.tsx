"use client";

// ============================================================
// مدیریت نقش‌ها و مجوزها — RBAC داینامیک
// نقش = مجموعه مجوزها → کاربر به نقش متصل می‌شود
// ============================================================
import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { ShieldCheck, Plus, Pencil, Trash2, Lock } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";

interface RoleRow {
  id: string; key: string; name: string; description: string;
  isSystem: boolean; permissions: string[]; userCount: number;
}
interface CatalogGroup {
  group: string;
  items: { key: string; label: string }[];
}

export function RolesManager() {
  const list = useApi<{ roles: RoleRow[]; catalog: CatalogGroup[] }>("/api/roles");
  const [editing, setEditing] = useState<RoleRow | null>(null);
  const [creating, setCreating] = useState(false);
  const { toast } = useToast();
  const roles = list.data?.roles || [];

  async function remove(r: RoleRow) {
    if (!confirm(`حذف نقش «${r.name}»؟`)) return;
    try {
      await api(`/api/roles/${r.id}`, { method: "DELETE" });
      await list.refetch();
      toast({ title: "نقش حذف شد" });
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-sky-50 to-white border-sky-200">
        <CardContent className="p-4 flex items-start gap-3">
          <ShieldCheck className="w-6 h-6 text-sky-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-sm text-slate-800">نقش‌ها و مجوزهای دسترسی</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              هر نقش مجموعه‌ای از مجوزهاست. نقش را به کاربران اختصاص دهید تا دسترسی‌ها ایجاد شود.
              نقش «مدیر کل سیستم» دسترسی کامل دارد و قابل حذف نیست. پس از تغییر نقش یک کاربر، نشست او تا ورود مجدد معتبر می‌ماند.
            </p>
          </div>
          <Button className="bg-sky-600 hover:bg-sky-700 gap-1.5 shrink-0" onClick={() => setCreating(true)}>
            <Plus className="w-4 h-4" /> نقش جدید
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {list.loading && [0, 1, 2].map((i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
        {roles.map((r) => (
          <Card key={r.id} className="rounded-2xl flex flex-col">
            <CardContent className="p-4 flex-1 space-y-3">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-bold text-sm flex-1">{r.name}</p>
                {r.isSystem && <Badge className="bg-slate-100 text-slate-500 hover:bg-slate-100 gap-1 text-[10px]"><Lock className="w-3 h-3" /> سیستمی</Badge>}
              </div>
              <p className="text-[11px] text-muted-foreground font-mono" dir="ltr">{r.key}</p>
              {r.description && <p className="text-xs text-muted-foreground leading-5">{r.description}</p>}
              <div className="flex flex-wrap gap-1">
                {r.permissions.includes("*") ? (
                  <Badge className="bg-rose-100 text-rose-700 hover:bg-rose-100">دسترسی کامل (*)</Badge>
                ) : (
                  <Badge variant="outline" className="text-[10px]">{toFaDigits(r.permissions.length)} مجوز</Badge>
                )}
                <Badge variant="outline" className="text-[10px]">{toFaDigits(r.userCount)} کاربر</Badge>
              </div>
              <div className="flex gap-1.5 pt-1">
                <Button size="sm" variant="outline" className="gap-1 h-8 flex-1" onClick={() => setEditing(r)}>
                  <Pencil className="w-3.5 h-3.5" /> مجوزها
                </Button>
                <Button size="sm" variant="destructive" className="h-8" disabled={r.isSystem || r.userCount > 0} onClick={() => remove(r)} title={r.userCount > 0 ? "ابتدا نقش کاربران را تغییر دهید" : ""}>
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {(creating || editing) && (
        <RoleEditor
          role={editing}
          catalog={list.data?.catalog || []}
          existingKeys={roles.map((r) => r.key)}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={() => { list.refetch(); setCreating(false); setEditing(null); }}
        />
      )}
    </div>
  );
}

function RoleEditor({ role, catalog, existingKeys, onClose, onSaved }: {
  role: RoleRow | null;
  catalog: CatalogGroup[];
  existingKeys: string[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [key, setKey] = useState(role?.key || "");
  const [name, setName] = useState(role?.name || "");
  const [description, setDescription] = useState(role?.description || "");
  const [perms, setPerms] = useState<Set<string>>(new Set(role?.permissions || []));
  const [saving, setSaving] = useState(false);
  const isSuper = (role?.key || key) === "SUPER_ADMIN";

  useEffect(() => {
    if (isSuper) setPerms(new Set(["*"]));
  }, [isSuper]);

  function toggle(p: string) {
    const next = new Set(perms);
    if (next.has(p)) next.delete(p);
    else next.add(p);
    setPerms(next);
  }

  function toggleGroup(g: CatalogGroup) {
    const keys = g.items.map((i) => i.key);
    const allOn = keys.every((k) => perms.has(k));
    const next = new Set(perms);
    for (const k of keys) {
      if (allOn) next.delete(k);
      else next.add(k);
    }
    setPerms(next);
  }

  async function save() {
    if (!name.trim()) {
      toast({ title: "نام نقش الزامی است", variant: "destructive" });
      return;
    }
    if (!role) {
      const k = key.trim().toUpperCase().replace(/[^A-Z0-9_]/g, "_");
      if (k.length < 2) {
        toast({ title: "کلید نقش باید حداقل ۲ نویسه لاتین باشد", variant: "destructive" });
        return;
      }
      if (existingKeys.includes(k)) {
        toast({ title: "کلید نقش تکراری است", variant: "destructive" });
        return;
      }
      setSaving(true);
      try {
        await api("/api/roles", { method: "POST", json: { key: k, name: name.trim(), description, permissions: Array.from(perms) } });
        toast({ title: "نقش ساخته شد", description: "حالا می‌توانید آن را به کاربران اختصاص دهید." });
        onSaved();
      } catch (e) {
        toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
      } finally {
        setSaving(false);
      }
      return;
    }
    setSaving(true);
    try {
      await api(`/api/roles/${role.id}`, { method: "PATCH", json: { name: name.trim(), description, permissions: Array.from(perms) } });
      toast({ title: "مجوزهای نقش به‌روزرسانی شد", description: "کاربران پس از ورود مجدد دسترسی جدید را می‌بینند." });
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[67.2rem] max-h-[88vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-sky-600" />
            {role ? `مجوزهای نقش — ${role.name}` : "نقش جدید"}
          </DialogTitle>
        </DialogHeader>

        {!role && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs">کلید نقش (لاتین — مثلاً BRANCH_MANAGER)</Label>
              <Input value={key} onChange={(e) => setKey(e.target.value)} dir="ltr" placeholder="BRANCH_MANAGER" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">نام نمایشی نقش</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مدیر شعبه" />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label className="text-xs">توضیحات (اختیاری)</Label>
              <Input value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
          </div>
        )}
        {role && (
          <div className="space-y-1.5">
            <Label className="text-xs">نام نمایشی نقش</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
        )}

        {isSuper ? (
          <div className="rounded-xl border border-rose-200 bg-rose-50 p-3 text-xs text-rose-700 leading-5">
            نقش مدیر کل سیستم به‌طور پیش‌فرض دسترسی کامل (*) دارد و مجوزهایش قابل محدودکردن نیست.
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold">ماتریس مجوزها ({toFaDigits(perms.size)} فعال):</p>
              <div className="flex gap-1.5">
                <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setPerms(new Set(catalog.flatMap((g) => g.items.map((i) => i.key))))}>انتخاب همه</Button>
                <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => setPerms(new Set())}>پاک‌سازی</Button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {catalog.map((g) => {
                const keys = g.items.map((i) => i.key);
                const allOn = keys.every((k) => perms.has(k));
                return (
                  <div key={g.group} className="rounded-xl border p-3">
                    <button className="flex items-center gap-2 w-full mb-2" onClick={() => toggleGroup(g)}>
                      <Checkbox checked={allOn} />
                      <span className="text-xs font-bold">{g.group}</span>
                    </button>
                    <div className="space-y-1.5">
                      {g.items.map((i) => (
                        <label key={i.key} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-slate-50 rounded px-1 py-0.5">
                          <Checkbox checked={perms.has(i.key)} onCheckedChange={() => toggle(i.key)} />
                          <span>{i.label}</span>
                          <span className="mr-auto text-[9px] font-mono text-muted-foreground" dir="ltr">{i.key}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-sky-600 hover:bg-sky-700">{saving ? "..." : role ? "ذخیره مجوزها" : "ایجاد نقش"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

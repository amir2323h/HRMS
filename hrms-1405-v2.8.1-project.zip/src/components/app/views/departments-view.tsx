"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Building2, Plus, Edit3, ChevronDown, Users, Coins, Trash2, UserRoundCog } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa } from "@/lib/format";
import { toFaDigits } from "@/lib/jalali";
import { Money } from "../money-input";

interface DeptRow {
  id: string; code: string; name: string; description: string; costCenterCode: string;
  parentId: string | null; managerEmployeeId: string | null;
  manager?: { id: string; fullName: string; personnelCode: string } | null;
  employeeCount: number; totalBaseSalary: number;
}

export function DepartmentsView() {
  const { data, loading, refetch } = useApi<{ departments: DeptRow[] }>("/api/departments");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<DeptRow | null>(null);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});
  const { toast } = useToast();

  const depts = data?.departments || [];
  const roots = depts.filter((d) => !d.parentId);
  const childrenOf = (id: string) => depts.filter((d) => d.parentId === id);

  if (loading) return <div className="space-y-3"><Skeleton className="h-20 rounded-2xl" />{[0, 1, 2].map((i) => <Skeleton key={i} className="h-24 rounded-2xl" />)}</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <p className="text-sm text-muted-foreground">ساختار درختی واحدهای سازمانی و مراکز هزینه — {toFaDigits(depts.length)} دپارتمان</p>
        <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
          <Plus className="w-4 h-4" /> دپارتمان جدید
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {roots.map((d) => {
          const kids = childrenOf(d.id);
          const isCollapsed = collapsed[d.id];
          const totalWithKids = d.employeeCount + kids.reduce((a, k) => a + k.employeeCount, 0);
          return (
            <Card key={d.id} className="rounded-2xl overflow-hidden">
              <CardContent className="p-0">
                <div className="p-4 flex items-start gap-3 bg-gradient-to-l from-slate-50 to-white border-b border-slate-100">
                  <div className="w-11 h-11 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-bold text-slate-800">{d.name}</h3>
                      <Badge variant="outline" className="tabular-nums">{d.code}</Badge>
                      <Badge className="bg-teal-100 text-teal-700 hover:bg-teal-100 tabular-nums">مرکز هزینه: {d.costCenterCode || "—"}</Badge>
                    </div>
                    {d.description && <p className="text-xs text-muted-foreground mt-1">{d.description}</p>}
                    {d.manager && (
                      <p className="text-[11px] text-teal-700 mt-1 flex items-center gap-1">
                        <UserRoundCog className="w-3 h-3" /> مدیر واحد: <b>{d.manager.fullName}</b>
                        <span className="text-muted-foreground tabular-nums" dir="ltr">({d.manager.personnelCode})</span>
                      </p>
                    )}
                    <div className="flex gap-4 mt-2 text-xs">
                      <span className="flex items-center gap-1 text-slate-600"><Users className="w-3.5 h-3.5" /> {toFaDigits(totalWithKids)} نفر</span>
                      <span className="flex items-center gap-1 text-slate-600"><Coins className="w-3.5 h-3.5" /> <Money amount={d.totalBaseSalary + kids.reduce((a, k) => a + k.totalBaseSalary, 0)} short /></span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1 shrink-0">
                    <button className="p-1.5 rounded-lg hover:bg-amber-100 text-amber-600" title="ویرایش" onClick={() => { setEditing(d); setFormOpen(true); }}>
                      <Edit3 className="w-4 h-4" />
                    </button>
                    {kids.length > 0 && (
                      <button className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500" onClick={() => setCollapsed((c) => ({ ...c, [d.id]: !c[d.id] }))} title={isCollapsed ? "نمایش زیرمجموعه" : "جمع کردن"}>
                        <ChevronDown className={`w-4 h-4 transition-transform ${isCollapsed ? "-rotate-90" : ""}`} />
                      </button>
                    )}
                  </div>
                </div>
                {kids.length > 0 && !isCollapsed && (
                  <div className="divide-y bg-slate-50/40">
                    {kids.map((k) => (
                      <div key={k.id} className="px-4 py-2.5 flex items-center gap-3 hover:bg-white transition-colors">
                        <span className="w-1.5 h-1.5 rounded-full bg-teal-400" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-slate-700 truncate">{k.name} <span className="text-[11px] text-muted-foreground tabular-nums">({k.code} — {k.costCenterCode})</span></p>
                          {k.manager && <p className="text-[10px] text-teal-700 mt-0.5">مدیر واحد: {k.manager.fullName}</p>}
                        </div>
                        <span className="text-xs text-muted-foreground">{toFaDigits(k.employeeCount)} نفر</span>
                        <Money amount={k.totalBaseSalary} short className="text-xs text-muted-foreground" />
                        <button className="p-1 rounded-lg hover:bg-amber-100 text-amber-600" onClick={() => { setEditing(k); setFormOpen(true); }}>
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <DeptForm open={formOpen} onOpenChange={setFormOpen} editing={editing} departments={depts} onSaved={() => { refetch(); toast({ title: editing ? "دپارتمان به‌روزرسانی شد" : "دپارتمان ایجاد شد" }); }} onDelete={async (id) => {
        try {
          await api(`/api/departments?id=${id}`, { method: "DELETE" });
          refetch();
          toast({ title: "دپارتمان حذف شد" });
        } catch (e) {
          toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
        }
      }} />
    </div>
  );
}

function DeptForm({ open, onOpenChange, editing, departments, onSaved, onDelete }: {
  open: boolean; onOpenChange: (v: boolean) => void; editing: DeptRow | null;
  departments: DeptRow[]; onSaved: () => void; onDelete: (id: string) => void;
}) {
  const employees = useApi<{ employees: { id: string; fullName: string; personnelCode: string }[] }>(open ? "/api/employees" : null);
  const [f, setF] = useState(() => ({
    code: editing?.code || "", name: editing?.name || "", description: editing?.description || "",
    costCenterCode: editing?.costCenterCode || "", parentId: editing?.parentId || "",
    managerEmployeeId: editing?.managerEmployeeId || "",
  }));
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const key = editing?.id || "new";

  // ریست فرم وقتی هدف عوض می‌شود
  const [lastKey, setLastKey] = useState(key);
  if (lastKey !== key) {
    setLastKey(key);
    setF({
      code: editing?.code || "", name: editing?.name || "", description: editing?.description || "",
      costCenterCode: editing?.costCenterCode || "", parentId: editing?.parentId || "",
      managerEmployeeId: editing?.managerEmployeeId || "",
    });
  }

  async function save() {
    if (!f.name.trim() || !f.code.trim()) {
      toast({ title: "نام و کد الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      if (editing) {
        await api("/api/departments", { method: "PATCH", json: { id: editing.id, ...f, parentId: f.parentId || null, managerEmployeeId: f.managerEmployeeId || null } });
      } else {
        await api("/api/departments", { method: "POST", json: { ...f, parentId: f.parentId || null, managerEmployeeId: f.managerEmployeeId || null } });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[39.2rem]" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? `ویرایش «${editing.name}»` : "دپارتمان جدید"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label className="text-xs">نام دپارتمان</Label>
              <Input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">کد</Label>
              <Input dir="ltr" className="text-left" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} placeholder="D600" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">کد مرکز هزینه</Label>
            <Input dir="ltr" className="text-left" value={f.costCenterCode} onChange={(e) => setF({ ...f, costCenterCode: e.target.value })} placeholder="CC-610" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">دپارتمان والد</Label>
            <Select value={f.parentId || "none"} onValueChange={(v) => setF({ ...f, parentId: v === "none" ? "" : v })}>
              <SelectTrigger><SelectValue placeholder="بدون والد (سطح اول)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">بدون والد (سطح اول)</SelectItem>
                {departments.filter((d) => d.id !== editing?.id).map((d) => (
                  <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">مدیر واحد (تأیید مرحله اول درخواست‌ها)</Label>
            <Select value={f.managerEmployeeId || "none"} onValueChange={(v) => setF({ ...f, managerEmployeeId: v === "none" ? "" : v })}>
              <SelectTrigger><SelectValue placeholder="بدون مدیر" /></SelectTrigger>
              <SelectContent className="max-h-64">
                <SelectItem value="none">بدون مدیر</SelectItem>
                {(employees.data?.employees || []).map((e) => (
                  <SelectItem key={e.id} value={e.id}>{e.fullName} — {e.personnelCode}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground">درخواست‌های مرخصی/مساعده اعضای این واحد به مدیر انتخاب‌شده می‌رود.</p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">توضیحات</Label>
            <Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          </div>
        </div>
        <DialogFooter className="gap-2">
          {editing && (
            <Button variant="destructive" className="gap-1.5 mr-auto" onClick={() => { onDelete(editing.id); onOpenChange(false); }}>
              <Trash2 className="w-4 h-4" /> حذف
            </Button>
          )}
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">{saving ? "..." : "ذخیره"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

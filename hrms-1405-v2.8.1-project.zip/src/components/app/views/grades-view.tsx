"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Layers, Edit3, TrendingUp, Coins, Gauge, PieChart, Info } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";
import { MoneyInput, Money } from "../money-input";

interface GradeRow {
  id: string; level: number; code: string; title: string; description: string;
  minBaseSalary: number; maxBaseSalary: number; seniorityBase: number; attraction: number; employeeCount: number;
  basePercent: number; respPercent: number; meritPercent: number;
}

const LEVEL_COLORS = [
  "from-slate-400 to-slate-500", "from-teal-400 to-teal-500", "from-cyan-500 to-teal-600",
  "from-emerald-500 to-teal-600", "from-teal-600 to-emerald-700", "from-teal-700 to-cyan-800", "from-slate-700 to-teal-900",
];

export function GradesView() {
  const { data, loading, refetch } = useApi<{ grades: GradeRow[] }>("/api/grades");
  const [editing, setEditing] = useState<GradeRow | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const { toast } = useToast();

  if (loading) return <div className="space-y-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}</div>;
  const grades = data?.grades || [];

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
        <CardContent className="p-4 flex items-center gap-3 flex-wrap">
          <Layers className="w-8 h-8 text-teal-600 shrink-0" />
          <div className="flex-1 min-w-[240px]">
            <p className="font-bold text-slate-800">ماتریس طبقه‌بندی مشاغل — ۷ سطح</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              حداقل/حداکثر حقوق ماهانه، پایه سنوات سالانه و حق جذب هر سطح — مبنای موتور محاسبه و معکوس.
              برای هر سطح می‌توانید تعیین کنید چند درصد حقوق ماهانه به «حقوق پایه»، «حق مسولیت» و «شایستگی» برود —
              اضافه‌کاری، مأموریت و فوق‌العاده‌ها فقط از حقوق پایه محاسبه می‌شوند.
            </p>
          </div>
          <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5" onClick={() => { setEditing(null); setFormOpen(true); }}>
            <Edit3 className="w-4 h-4" /> سطح جدید
          </Button>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {grades.map((g) => (
          <Card key={g.id} className="rounded-2xl overflow-hidden hover:shadow-md transition-shadow">
            <CardContent className="p-0">
              <div className="flex items-stretch">
                {/* نوار سطح */}
                <div className={`w-24 shrink-0 bg-gradient-to-b ${LEVEL_COLORS[g.level - 1] || LEVEL_COLORS[0]} text-white flex flex-col items-center justify-center gap-1 py-4`}>
                  <span className="text-2xl font-black tabular-nums">{toFaDigits(g.level)}</span>
                  <span className="text-[10px] opacity-80">{g.code}</span>
                </div>
                <div className="flex-1 p-4 grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                  <div>
                    <p className="font-bold text-slate-800">{g.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{g.description}</p>
                    <Badge variant="outline" className="mt-2 tabular-nums">{toFaDigits(g.employeeCount)} کارمند فعال</Badge>
                  </div>
                  <div>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1"><Gauge className="w-3 h-3" /> بازه حقوق ماهانه</p>
                    <p className="text-sm font-medium mt-1 tabular-nums"><Money amount={g.minBaseSalary} short /></p>
                    <p className="text-xs text-muted-foreground tabular-nums">تا <Money amount={g.maxBaseSalary} short /></p>
                  </div>
                  <div>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1"><TrendingUp className="w-3 h-3" /> پایه سنوات (هر سال)</p>
                    <p className="text-sm font-medium mt-1"><Money amount={g.seniorityBase} short /></p>
                  </div>
                  <div>
                    <p className="text-[11px] text-muted-foreground flex items-center gap-1"><PieChart className="w-3 h-3" /> تفکیک حقوق ماهانه</p>
                    {(g.respPercent || 0) + (g.meritPercent || 0) > 0 ? (
                      <div className="mt-1.5 space-y-0.5">
                        <div className="w-full h-2 rounded-full overflow-hidden flex" dir="ltr">
                          <div className="bg-teal-500" style={{ width: `${g.basePercent}%` }} title={`حقوق پایه ${g.basePercent}٪`} />
                          <div className="bg-sky-400" style={{ width: `${g.respPercent}%` }} title={`حق مسولیت ${g.respPercent}٪`} />
                          <div className="bg-violet-400" style={{ width: `${g.meritPercent}%` }} title={`شایستگی ${g.meritPercent}٪`} />
                        </div>
                        <p className="text-[10px] text-muted-foreground tabular-nums leading-4">
                          پایه {toFaDigits(g.basePercent)}٪ • مسولیت {toFaDigits(g.respPercent)}٪ • شایستگی {toFaDigits(g.meritPercent)}٪
                        </p>
                      </div>
                    ) : (
                      <p className="text-xs text-muted-foreground mt-1">بدون تفکیک — کل حقوق = پایه</p>
                    )}
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <p className="text-[11px] text-muted-foreground flex items-center gap-1"><Coins className="w-3 h-3" /> حق جذب</p>
                      <p className="text-sm font-medium mt-1"><Money amount={g.attraction} short /></p>
                    </div>
                    <Button size="sm" variant="outline" className="gap-1" onClick={() => { setEditing(g); setFormOpen(true); }}>
                      <Edit3 className="w-3.5 h-3.5" /> ویرایش
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <GradeForm
        open={formOpen}
        onOpenChange={setFormOpen}
        editing={editing}
        onSaved={() => { refetch(); toast({ title: editing ? "سطح به‌روزرسانی شد" : "سطح جدید ایجاد شد", description: "تغییرات در لاگ حسابرسی ثبت گردید." }); }}
      />
    </div>
  );
}

function GradeForm({ open, onOpenChange, editing, onSaved }: {
  open: boolean; onOpenChange: (v: boolean) => void; editing: GradeRow | null; onSaved: () => void;
}) {
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [f, setF] = useState(() => ({
    level: editing?.level || 1,
    title: editing?.title || "",
    code: editing?.code || "",
    description: editing?.description || "",
    minBaseSalary: Math.round((editing?.minBaseSalary || 0) / 10),
    maxBaseSalary: Math.round((editing?.maxBaseSalary || 0) / 10),
    seniorityBase: Math.round((editing?.seniorityBase || 0) / 10),
    attraction: Math.round((editing?.attraction || 0) / 10),
    respPercent: editing?.respPercent ?? 0,
    meritPercent: editing?.meritPercent ?? 0,
  }));
  const [lastKey, setLastKey] = useState(editing?.id || "new");
  const key = editing?.id || "new";
  if (lastKey !== key) {
    setLastKey(key);
    setF({
      level: editing?.level || 1,
      title: editing?.title || "",
      code: editing?.code || "",
      description: editing?.description || "",
      minBaseSalary: Math.round((editing?.minBaseSalary || 0) / 10),
      maxBaseSalary: Math.round((editing?.maxBaseSalary || 0) / 10),
      seniorityBase: Math.round((editing?.seniorityBase || 0) / 10),
      attraction: Math.round((editing?.attraction || 0) / 10),
      respPercent: editing?.respPercent ?? 0,
      meritPercent: editing?.meritPercent ?? 0,
    });
  }

  const basePercent = Math.max(0, 100 - (f.respPercent || 0) - (f.meritPercent || 0));
  const splitSum = (f.respPercent || 0) + (f.meritPercent || 0);

  async function save() {
    if (!f.title.trim()) {
      toast({ title: "عنوان سطح الزامی است", variant: "destructive" });
      return;
    }
    if (splitSum > 100) {
      toast({ title: "جمع درصد حق مسولیت و شایستگی نباید بیش از ۱۰۰ باشد", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...f,
        minBaseSalary: f.minBaseSalary * 10,
        maxBaseSalary: f.maxBaseSalary * 10,
        seniorityBase: f.seniorityBase * 10,
        attraction: f.attraction * 10,
        respPercent: f.respPercent || 0,
        meritPercent: f.meritPercent || 0,
      };
      if (editing) {
        await api("/api/grades", { method: "PATCH", json: { id: editing.id, ...payload } });
      } else {
        await api("/api/grades", { method: "POST", json: payload });
      }
      onOpenChange(false);
      onSaved();
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[44.8rem] max-h-[85vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle>{editing ? `ویرایش سطح ${toFaDigits(editing.level)}` : "سطح جدید طبقه‌بندی"}</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">شماره سطح (۱ تا ۷)</Label>
            <Input type="number" min={1} max={7} className="tabular-nums" value={f.level} onChange={(e) => setF({ ...f, level: Math.min(7, Math.max(1, +e.target.value || 1)) })} disabled={!!editing} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">کد</Label>
            <Input dir="ltr" className="text-left" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} placeholder="L5" />
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label className="text-xs">عنوان سطح</Label>
            <Input value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="مثلاً: کارشناس ارشد" />
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label className="text-xs">توضیحات</Label>
            <Input value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حداقل حقوق پایه (ماهانه)</Label>
            <MoneyInput value={f.minBaseSalary} onChange={(v) => setF({ ...f, minBaseSalary: v })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حداکثر حقوق پایه</Label>
            <MoneyInput value={f.maxBaseSalary} onChange={(v) => setF({ ...f, maxBaseSalary: v })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">پایه سنوات (هر سال خدمت)</Label>
            <MoneyInput value={f.seniorityBase} onChange={(v) => setF({ ...f, seniorityBase: v })} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حق جذب</Label>
            <MoneyInput value={f.attraction} onChange={(v) => setF({ ...f, attraction: v })} />
          </div>
          {/* ---- تفکیک حقوق ماهانه سطح ---- */}
          <div className="col-span-2 rounded-xl border border-teal-200 bg-teal-50/40 p-3 space-y-3">
            <div className="flex items-center gap-2">
              <PieChart className="w-4 h-4 text-teal-600" />
              <p className="text-xs font-bold text-teal-800">تفکیک حقوق ماهانه این سطح</p>
              <Badge className={splitSum <= 100 ? "bg-teal-100 text-teal-700 hover:bg-teal-100" : "bg-rose-100 text-rose-700 hover:bg-rose-100"}>
                جمع: {toFaDigits(splitSum <= 100 ? 100 : splitSum)}٪
              </Badge>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground">حقوق پایه (خودکار)</Label>
                <Input className="h-9 tabular-nums" value={toFaDigits(basePercent)} disabled />
                <p className="text-[10px] text-muted-foreground leading-4">مبنای اضافه‌کاری، مأموریت، شب/جمعه/تعطیل‌کاری و غیبت</p>
              </div>
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground">حق مسولیت (٪)</Label>
                <Input type="number" min={0} max={100} step={0.5} className="h-9 tabular-nums" value={f.respPercent} onChange={(e) => setF({ ...f, respPercent: Math.min(100, Math.max(0, +e.target.value || 0)) })} placeholder="0" />
              </div>
              <div className="space-y-1">
                <Label className="text-[11px] text-muted-foreground">پاداش شایستگی (٪)</Label>
                <Input type="number" min={0} max={100} step={0.5} className="h-9 tabular-nums" value={f.meritPercent} onChange={(e) => setF({ ...f, meritPercent: Math.min(100, Math.max(0, +e.target.value || 0)) })} placeholder="0" />
              </div>
            </div>
            <div className="w-full h-2.5 rounded-full overflow-hidden flex border border-teal-100" dir="ltr">
              <div className="bg-teal-500 transition-all" style={{ width: `${basePercent}%` }} />
              <div className="bg-sky-400 transition-all" style={{ width: `${f.respPercent}%` }} />
              <div className="bg-violet-400 transition-all" style={{ width: `${f.meritPercent}%` }} />
            </div>
            <p className="text-[10px] text-muted-foreground leading-5 flex gap-1">
              <Info className="w-3 h-3 shrink-0 mt-0.5 text-teal-600" />
              مثال: حقوق ماهانه ۳۰۰ میلیون ریال در این سطح با ۵۰٪ پایه / ۳۰٪ مسولیت / ۲۰٪ شایستگی →
              ۱۵۰M حقوق پایه + 90M حق مسولیت + 60M شایستگی. هر سه جزو بیمه و مالیات؛ فقط پایه مبنای فوق‌العاده‌هاست.
            </p>
          </div>
        </div>
        <DialogFooter className="mt-2">
          <Button variant="outline" onClick={() => onOpenChange(false)}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700">{saving ? "..." : "ذخیره"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

"use client";

// ============================================================
// تنظیمات ← تعطیلات و شیفت‌ها
//  ۱) جدول شیفت‌های کاری: روزکار ۰۸–۱۷ (ناهار) | صبح ۰۸–۱۶ | عصر/شب ۱۶–۲۴ | شب ۲۴–۰۸
//     + سیاست تعطیلی هفتگی (روزکار: پنجشنبه+جمعه | شیفتی: جمعه)
//  ۲) مدیریت تعطیلات رسمی/سازمانی: افزودن/ویرایش/حذف + درون‌ریزی از کتابخانه/وب‌سرویس
//  ۳) جدول ۱۲ ماه سال: تعطیلات، روزهای کاری و ساعت استاندارد دوره به تفکیک روزکار/شیفتی
// ============================================================
import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { CalendarDays, Clock, Plus, Pencil, Trash2, Download, CalendarClock, Info } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits, todayJalaliStr, parseJalali, JALALI_MONTHS } from "@/lib/jalali";
import { JalaliDatePicker } from "../jalali-datepicker";

interface ShiftDefUI { title: string; start: string; end: string; breakMinutes: number }
interface ScheduleUI {
  daily: ShiftDefUI;
  morning: ShiftDefUI;
  evening: ShiftDefUI;
  night: ShiftDefUI;
  weekend: { DAILY: number[]; SHIFT: number[] };
}
interface HolidayRow {
  id: string;
  dateJ: string;
  title: string;
  kind: string;
  source: string;
  weekdayName: string;
}
interface MonthStatsUI {
  month: number;
  totalDays: number;
  thursdays: number;
  fridays: number;
  officialHolidays: number;
  holidayList: { dateJ: string; day: number; weekday: number; title: string; onWeekend: boolean }[];
  daily: { weekendDays: number; workingDays: number; standardHours: number };
  shift: { weekendDays: number; workingDays: number; standardHours: number };
}
interface HolidaysData {
  year: number;
  holidays: HolidayRow[];
  months: MonthStatsUI[];
  schedule: ScheduleUI;
}

const WEEKDAY_OPTIONS = [
  { idx: 0, label: "شنبه" },
  { idx: 1, label: "یکشنبه" },
  { idx: 2, label: "دوشنبه" },
  { idx: 3, label: "سه‌شنبه" },
  { idx: 4, label: "چهارشنبه" },
  { idx: 5, label: "پنجشنبه" },
  { idx: 6, label: "جمعه" },
];

function toMin(t: string): number {
  const m = t.match(/^(\d{1,2}):(\d{2})$/);
  return m ? +m[1] * 60 + +m[2] : 0;
}
function effHours(sh: ShiftDefUI): number {
  let dur = toMin(sh.end) - toMin(sh.start);
  if (dur <= 0) dur += 24 * 60;
  return Math.max(0, (dur - sh.breakMinutes) / 60);
}
function timeValid(t: string): boolean {
  return /^([01]\d|2[0-3]):[0-5]\d$/.test(t);
}

export function HolidaysManager() {
  const { toast } = useToast();
  const today = parseJalali(todayJalaliStr())!;
  const [year, setYear] = useState(today.jy);
  const [scheduleDraft, setScheduleDraft] = useState<ScheduleUI | null>(null);
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [editHoliday, setEditHoliday] = useState<Partial<HolidayRow> | null>(null);
  const [deleteHoliday, setDeleteHoliday] = useState<HolidayRow | null>(null);
  const [importing, setImporting] = useState(false);
  const [importUrl, setImportUrl] = useState("");

  const years = [today.jy - 1, today.jy, today.jy + 1];
  const dataApi = useApi<HolidaysData>(`/api/holidays?year=${year}`, [year]);
  const data = dataApi.data;
  const schedule = scheduleDraft || data?.schedule || null;

  const holidaysByMonth = useMemo(() => {
    const map = new Map<number, HolidayRow[]>();
    for (const h of data?.holidays || []) {
      const m = +h.dateJ.slice(5, 7);
      if (!map.has(m)) map.set(m, []);
      map.get(m)!.push(h);
    }
    return map;
  }, [data?.holidays]);

  // ---------- ذخیره شیفت‌ها ----------
  async function saveSchedule() {
    if (!scheduleDraft) return;
    for (const key of ["daily", "morning", "evening", "night"] as const) {
      const sh = scheduleDraft[key];
      if (!timeValid(sh.start) || !timeValid(sh.end)) {
        toast({ title: "خطا", description: `ساعت شیفت «${sh.title}» نامعتبر است (قالب HH:MM).`, variant: "destructive" });
        return;
      }
    }
    setSavingSchedule(true);
    try {
      await api("/api/holidays/schedule", { method: "PUT", json: { schedule: scheduleDraft } });
      await dataApi.refetch();
      setScheduleDraft(null);
      toast({ title: "شیفت‌ها ذخیره شد", description: "ساعت استاندارد دوره‌ها با تأخیر حداکثر ۱۵ ثانیه (کش) در نمای حضور به‌روز می‌شود." });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSavingSchedule(false);
    }
  }

  // ---------- درون‌ریزی ----------
  async function importHolidays(fromUrl?: string) {
    setImporting(true);
    try {
      const body = fromUrl ? { url: fromUrl } : { year };
      const r = await api<{ created: number; updated: number; skipped: number; source: string }>("/api/holidays/import", {
        method: "POST",
        json: body,
      });
      await dataApi.refetch();
      setImportUrl("");
      toast({
        title: "تعطیلات درون‌ریزی شد",
        description: `${r.source}: ${toFaDigits(r.created)} تعطیل جدید، ${toFaDigits(r.updated)} به‌روزرسانی، ${toFaDigits(r.skipped)} بدون تغییر.`,
      });
    } catch (e) {
      toast({ title: "درون‌ریزی ناموفق", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setImporting(false);
    }
  }

  // ---------- CRUD تعطیل ----------
  async function saveHoliday() {
    if (!editHoliday) return;
    const dateJ = editHoliday.dateJ || "";
    const title = (editHoliday.title || "").trim();
    if (!dateJ || !title) {
      toast({ title: "تاریخ و عنوان الزامی است", variant: "destructive" });
      return;
    }
    try {
      const body = { id: editHoliday.id || "", dateJ, title, kind: editHoliday.kind || "OFFICIAL" };
      await api("/api/holidays", { method: editHoliday.id ? "PATCH" : "POST", json: body });
      setEditHoliday(null);
      await dataApi.refetch();
      toast({ title: editHoliday.id ? "تعطیل ویرایش شد" : "تعطیل ثبت شد", description: `${dateJ} — ${title}` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  async function removeHoliday() {
    if (!deleteHoliday) return;
    try {
      await api(`/api/holidays/${deleteHoliday.id}`, { method: "DELETE" });
      setDeleteHoliday(null);
      await dataApi.refetch();
      toast({ title: "تعطیل حذف شد", description: `${deleteHoliday.dateJ} — ${deleteHoliday.title}` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  if (dataApi.loading && !data) {
    return <div className="space-y-3"><Skeleton className="h-40 rounded-2xl" /><Skeleton className="h-72 rounded-2xl" /></div>;
  }

  const dirty = !!scheduleDraft;

  return (
    <div className="space-y-4">
      {/* ---------- شیفت‌ها و ساعت کاری ---------- */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex flex-wrap items-center gap-2">
            <Clock className="w-4.5 h-4.5 text-teal-600" /> شیفت‌ها و ساعت کاری استاندارد
            {dirty && <Badge className="bg-amber-100 text-amber-700 hover:bg-amber-100">ذخیره نشده</Badge>}
            {dirty && (
              <div className="mr-auto flex gap-2">
                <Button size="sm" variant="outline" onClick={() => setScheduleDraft(null)}>واگردانی</Button>
                <Button size="sm" className="bg-teal-600 hover:bg-teal-700" onClick={saveSchedule} disabled={savingSchedule}>
                  {savingSchedule ? "در حال ذخیره…" : "ذخیره شیفت‌ها"}
                </Button>
              </div>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {schedule && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
                {(["daily", "morning", "evening", "night"] as const).map((key) => {
                  const sh = schedule[key];
                  const isShiftCard = key !== "daily";
                  return (
                    <div key={key} className={`rounded-xl border p-3 space-y-2 ${isShiftCard ? "border-violet-200 bg-violet-50/30" : "border-teal-200 bg-teal-50/40"}`}>
                      <div className="flex items-center justify-between">
                        <Label className="text-xs font-bold">{sh.title}</Label>
                        <Badge variant="outline" className="text-[10px] tabular-nums">{toFaDigits(effHours(sh))} ساعت مؤثر</Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-1">
                          <Label className="text-[10px]">شروع</Label>
                          <Input
                            dir="ltr"
                            className="h-8 text-center text-xs"
                            value={sh.start}
                            onChange={(e) => setScheduleDraft({ ...schedule, [key]: { ...sh, start: e.target.value } })}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-[10px]">پایان</Label>
                          <Input
                            dir="ltr"
                            className="h-8 text-center text-xs"
                            value={sh.end}
                            onChange={(e) => setScheduleDraft({ ...schedule, [key]: { ...sh, end: e.target.value } })}
                          />
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Label className="text-[10px]">استراحت/ناهار (دقیقه)</Label>
                        <Input
                          dir="ltr"
                          inputMode="numeric"
                          className="h-8 text-center text-xs"
                          value={String(sh.breakMinutes)}
                          onChange={(e) => setScheduleDraft({ ...schedule, [key]: { ...sh, breakMinutes: Math.max(0, Math.min(240, +e.target.value || 0)) } })}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* تعطیلی هفتگی */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {(["DAILY", "SHIFT"] as const).map((et) => {
                  const label = et === "DAILY" ? "روزکار (اداری)" : "شیفتی (نوبتی‌کاری)";
                  const selectedDays = schedule.weekend[et];
                  return (
                    <div key={et} className="rounded-xl border p-3 space-y-2">
                      <Label className="text-xs font-bold">روزهای تعطیل هفتگی — {label}</Label>
                      <div className="flex flex-wrap gap-1.5">
                        {WEEKDAY_OPTIONS.map((w) => {
                          const on = selectedDays.includes(w.idx);
                          return (
                            <button
                              key={w.idx}
                              type="button"
                              onClick={() =>
                                setScheduleDraft({
                                  ...schedule,
                                  weekend: {
                                    ...schedule.weekend,
                                    [et]: on ? selectedDays.filter((x) => x !== w.idx) : [...selectedDays, w.idx].sort((a, b) => a - b),
                                  },
                                })
                              }
                              className={`px-2.5 py-1 rounded-lg text-xs border transition-colors ${
                                on ? "bg-rose-100 text-rose-700 border-rose-200 font-bold" : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                              }`}
                            >
                              {w.label}
                            </button>
                          );
                        })}
                      </div>
                      <p className="text-[10px] text-muted-foreground leading-4">
                        {et === "DAILY"
                          ? "پیش‌فرض: پنجشنبه و جمعه — ساعت استاندارد دوره روزکار با کسر این روزها و تعطیلات رسمی محاسبه می‌شود."
                          : "پیش‌فرض: جمعه — شیفت‌بندی نوبتی معمولاً پنجشنبه کاری است؛ در صورت کارکرد چرخشی می‌توانید همه روزها را کاری کنید."}
                      </p>
                    </div>
                  );
                })}
              </div>
              <p className="text-[11px] text-muted-foreground leading-5 flex items-start gap-1.5">
                <Info className="w-3.5 h-3.5 mt-0.5 shrink-0" />
                ساعت کاری استاندارد: روزکار ۰۸:۰۰–۱۷:۰۰ با ۶۰ دقیقه ناهار (۸ ساعت مؤثر) • شیفت صبح ۰۸:۰۰–۱۶:۰۰ و شیفت عصر/شب ۱۶:۰۰–۲۴:۰۰ • شیفت شب ۲۴:۰۰–۰۸:۰۰ برای الگوی سه‌شیفت. تغییر شیفت‌ها بر محاسبه سطل‌های ساعتِ ترددهای بعدی و ساعت استاندارد دوره‌ها اثر می‌گذارد.
              </p>
            </>
          )}
        </CardContent>
      </Card>

      {/* ---------- مدیریت تعطیلات ---------- */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex flex-wrap items-center gap-2">
            <CalendarDays className="w-4.5 h-4.5 text-amber-600" /> تعطیلات رسمی سال {toFaDigits(year)}
            <div className="w-28">
              <Select value={String(year)} onValueChange={(v) => setYear(+v)}>
                <SelectTrigger className="h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {years.map((y) => <SelectItem key={y} value={String(y)}>{toFaDigits(y)}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Badge variant="outline">{toFaDigits(data?.holidays.length || 0)} روز تعطیل</Badge>
            <div className="mr-auto flex flex-wrap gap-2">
              {year === 1405 && (
                <Button size="sm" variant="outline" className="gap-1.5" onClick={() => importHolidays()} disabled={importing}>
                  <Download className="w-3.5 h-3.5" /> {importing ? "در حال درون‌ریزی…" : "درون‌ریزی تقویم رسمی ۱۴۰۵"}
                </Button>
              )}
              <Button size="sm" className="gap-1.5 bg-teal-600 hover:bg-teal-700" onClick={() => setEditHoliday({ dateJ: `${year}/01/01`, title: "", kind: "OFFICIAL" })}>
                <Plus className="w-3.5 h-3.5" /> تعطیل جدید
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* درون‌ریزی از وب‌سرویس */}
          <div className="rounded-xl border border-sky-200 bg-sky-50/40 p-3 space-y-2">
            <Label className="text-xs font-bold text-sky-900">دریافت تعطیلات از وب‌سرویس (سال‌های آینده)</Label>
            <div className="flex flex-wrap gap-2">
              <Input
                dir="ltr"
                className="flex-1 min-w-64 h-9 text-xs"
                placeholder="https://example.com/holidays-1406.json"
                value={importUrl}
                onChange={(e) => setImportUrl(e.target.value)}
              />
              <Button size="sm" variant="outline" className="gap-1.5" onClick={() => importHolidays(importUrl)} disabled={importing || !importUrl}>
                <Download className="w-3.5 h-3.5" /> دریافت از وب‌سرویس
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground leading-4">
              وب‌سرویس باید آرایه JSON از تعطیلات برگرداند: <code dir="ltr" className="bg-white rounded px-1">[{"{ \"dateJ\": \"1406/01/01\", \"title\": \"عید نوروز\" }"}]</code> — تعطیلات موجود بازنویسی نمی‌شوند و تعطیلات ثبت‌شده دستی حفظ می‌شوند.
            </p>
          </div>

          {/* فهرست تعطیلات به تفکیک ماه */}
          {(data?.holidays.length || 0) === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground space-y-2">
              <p>برای سال {toFaDigits(year)} تعطیلی ثبت نشده است.</p>
              {year === 1405 && <p>با دکمه «درون‌ریزی تقویم رسمی ۱۴۰۵»، ۲۶ تعطیل رسمی تأییدشده را دریافت کنید.</p>}
            </div>
          ) : (
            <div className="space-y-3">
              {JALALI_MONTHS.map((mName, i) => {
                const list = holidaysByMonth.get(i + 1) || [];
                if (list.length === 0) return null;
                return (
                  <div key={mName} className="rounded-xl border overflow-hidden">
                    <div className="bg-slate-50 px-3 py-2 text-xs font-bold flex items-center gap-2">
                      <CalendarDays className="w-3.5 h-3.5 text-amber-600" /> {mName} {toFaDigits(year)}
                      <Badge variant="outline" className="text-[10px]">{toFaDigits(list.length)} تعطیل</Badge>
                    </div>
                    <div className="divide-y">
                      {list.map((h) => (
                        <div key={h.id} className="px-3 py-2 flex flex-wrap items-center gap-2 text-sm hover:bg-slate-50/60">
                          <span className="tabular-nums text-xs w-24 text-slate-600">{toFaDigits(h.dateJ)}</span>
                          <Badge variant="outline" className="text-[10px] w-16 justify-center">{h.weekdayName}</Badge>
                          <span className="flex-1 min-w-40">{h.title}</span>
                          <Badge className={h.kind === "CUSTOM" ? "bg-violet-100 text-violet-700 hover:bg-violet-100" : "bg-amber-100 text-amber-700 hover:bg-amber-100"}>
                            {h.kind === "CUSTOM" ? "سازمانی" : "رسمی"}
                          </Badge>
                          <div className="flex gap-1">
                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0" title="ویرایش" onClick={() => setEditHoliday({ ...h })}>
                              <Pencil className="w-3.5 h-3.5" />
                            </Button>
                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-rose-600 hover:text-rose-700" title="حذف" onClick={() => setDeleteHoliday(h)}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* ---------- جدول ۱۲ ماه: ساعت استاندارد دوره ---------- */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <CalendarClock className="w-4.5 h-4.5 text-teal-600" /> ساعت استاندارد دوره‌های سال {toFaDigits(year)}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-slate-50 text-[11px] text-slate-600">
                  <th className="py-2.5 px-3 text-right font-medium">ماه</th>
                  <th className="py-2.5 px-2 text-center font-medium">روز ماه</th>
                  <th className="py-2.5 px-2 text-center font-medium">پنجشنبه</th>
                  <th className="py-2.5 px-2 text-center font-medium">جمعه</th>
                  <th className="py-2.5 px-2 text-center font-medium">تعطیل رسمی مؤثر</th>
                  <th className="py-2.5 px-2 text-center font-medium">روز کاری روزکار</th>
                  <th className="py-2.5 px-2 text-center font-medium text-teal-700">ساعت استاندارد روزکار</th>
                  <th className="py-2.5 px-2 text-center font-medium">روز کاری شیفتی</th>
                  <th className="py-2.5 px-2 text-center font-medium text-violet-700">ساعت استاندارد شیفتی</th>
                </tr>
              </thead>
              <tbody>
                {(data?.months || []).map((m) => (
                  <tr key={m.month} className="border-b last:border-0 hover:bg-slate-50/60">
                    <td className="py-2.5 px-3 font-medium">{JALALI_MONTHS[m.month - 1]}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits(m.totalDays)}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits(m.thursdays)}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits(m.fridays)}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">
                      {m.officialHolidays > 0 ? (
                        <span className="text-amber-700 font-bold" title={m.holidayList.map((h) => `${toFaDigits(h.day)} ${h.title}`).join("\n")}>
                          {toFaDigits(m.officialHolidays)}
                        </span>
                      ) : (
                        "۰"
                      )}
                    </td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits(m.daily.workingDays)}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums font-bold text-teal-700">{toFaDigits(m.daily.standardHours)}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits(m.shift.workingDays)}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums font-bold text-violet-700">{toFaDigits(m.shift.standardHours)}</td>
                  </tr>
                ))}
                {(data?.months.length || 0) > 0 && (
                  <tr className="bg-slate-50 font-bold">
                    <td className="py-2.5 px-3">جمع سال</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits((data?.months || []).reduce((a, m) => a + m.totalDays, 0))}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits((data?.months || []).reduce((a, m) => a + m.thursdays, 0))}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits((data?.months || []).reduce((a, m) => a + m.fridays, 0))}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits((data?.months || []).reduce((a, m) => a + m.officialHolidays, 0))}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits((data?.months || []).reduce((a, m) => a + m.daily.workingDays, 0))}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums text-teal-700">{toFaDigits((data?.months || []).reduce((a, m) => a + m.daily.standardHours, 0))}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums">{toFaDigits((data?.months || []).reduce((a, m) => a + m.shift.workingDays, 0))}</td>
                    <td className="py-2.5 px-2 text-center tabular-nums text-violet-700">{toFaDigits((data?.months || []).reduce((a, m) => a + m.shift.standardHours, 0))}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* ---------- فرم تعطیل ---------- */}
      <Dialog open={!!editHoliday} onOpenChange={(v) => !v && setEditHoliday(null)}>
        <DialogContent className="sm:max-w-[28rem]" dir="rtl">
          {editHoliday && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <CalendarDays className="w-5 h-5 text-amber-600" />
                  {editHoliday.id ? "ویرایش تعطیل" : "تعطیل جدید"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                <div className="space-y-1.5">
                  <Label className="text-xs">تاریخ (جلالی)</Label>
                  <JalaliDatePicker value={editHoliday.dateJ || ""} onChange={(v) => setEditHoliday({ ...editHoliday, dateJ: v })} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">عنوان مناسبت</Label>
                  <Input value={editHoliday.title || ""} onChange={(e) => setEditHoliday({ ...editHoliday, title: e.target.value })} placeholder="مثلاً: عید سعید قربان" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">نوع</Label>
                  <Select value={editHoliday.kind || "OFFICIAL"} onValueChange={(v) => setEditHoliday({ ...editHoliday, kind: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="OFFICIAL">تعطیل رسمی (تقویم کشور)</SelectItem>
                      <SelectItem value="CUSTOM">تعطیل سازمانی (اختیاری کارفرما)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setEditHoliday(null)}>انصراف</Button>
                <Button onClick={saveHoliday} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
                  <Plus className="w-4 h-4" /> ذخیره تعطیل
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* ---------- تأیید حذف ---------- */}
      <AlertDialog open={!!deleteHoliday} onOpenChange={(v) => !v && setDeleteHoliday(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف تعطیل</AlertDialogTitle>
            <AlertDialogDescription>
              آیا از حذف «{deleteHoliday?.title}» در {toFaDigits(deleteHoliday?.dateJ || "")} مطمئن هستید؟ ساعت استاندارد دوره‌های مرتبط بازمحاسبه می‌شود.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>انصراف</AlertDialogCancel>
            <AlertDialogAction className="bg-rose-600 hover:bg-rose-700" onClick={removeHoliday}>حذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

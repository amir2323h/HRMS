"use client";

// ============================================================
// مدیریت داده نمونه — پاک‌سازی امن داده‌های دمو (فقط مدیر کل)
//   حالت استاندارد: حذف کارکنان/فیش/دوره/قرارداد/نامه/درخواست/پاداش
//   حالت کامل: + دپارتمان/شغل/رفاهیات/قالب‌ها/کاربران غیر ادمین/لاگ
// این تب فقط برای مدیر کل (مجوز «*») نمایش داده می‌شود.
// ============================================================

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";
import { Trash2, DatabaseZap, ShieldAlert, HardDriveDownload } from "lucide-react";

interface PurgeCountsInfo {
  employees: number; payslips: number; periods: number; contracts: number;
  letters: number; requests: number; bonus: number;
  departments: number; jobTitles: number; users: number; auditLogs: number;
}

function Stat({ label, value, danger }: { label: string; value: number; danger?: boolean }) {
  return (
    <div className={`rounded-lg border px-3 py-2 text-center ${danger ? "border-rose-200 bg-rose-50" : "bg-slate-50"}`}>
      <p className={`text-base font-bold tabular-nums ${danger ? "text-rose-700" : "text-slate-800"}`}>{toFaDigits(value)}</p>
      <p className="text-[10px] text-muted-foreground mt-0.5">{label}</p>
    </div>
  );
}

export function PurgeDemoManager() {
  const { data, loading, refetch } = useApi<{ counts: PurgeCountsInfo }>("/api/settings/purge-demo");
  const [confirming, setConfirming] = useState<"demo" | "full" | null>(null);
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();
  const counts = data?.counts;

  async function run() {
    if (!confirming) return;
    setBusy(true);
    try {
      const r = await api<{ ok: boolean; counts: Record<string, number> }>("/api/settings/purge-demo", {
        method: "POST",
        json: { confirm: "PURGE", full: confirming === "full" },
      });
      const c = r.counts;
      toast({
        title: "داده نمونه پاک‌سازی شد",
        description: `${toFaDigits(c.employees || 0)} کارمند، ${toFaDigits(c.payslips || 0)} فیش، ${toFaDigits(c.letters || 0)} نامه و ${toFaDigits(c.contracts || 0)} قرارداد حذف شد — تنظیمات و نقش‌ها دست‌نخورده ماند.`,
      });
      setConfirming(null);
      refetch();
    } catch (e) {
      toast({ title: "خطا در پاک‌سازی", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  }

  if (loading || !counts) return <div className="space-y-3"><Skeleton className="h-32 rounded-2xl" /><Skeleton className="h-40 rounded-2xl" /></div>;

  const empty = counts.employees === 0 && counts.payslips === 0 && counts.letters === 0 && counts.contracts === 0 && counts.bonus === 0;

  return (
    <div className="space-y-4">
      {/* هشدار و راهنما */}
      <Card className="rounded-2xl bg-gradient-to-l from-rose-50 to-white border-rose-200">
        <CardContent className="p-4 flex items-start gap-3">
          <ShieldAlert className="w-6 h-6 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-sm text-slate-800">حذف داده‌های نمونه (دمو)</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              برای رفتن به بهره‌برداری واقعی، می‌توانید همه داده‌های نمونه را پاک کنید. حالت «استاندارد» فقط داده‌های پرسنلی و تراکنشی را حذف می‌کند و
              ساختار سازمانی، قالب‌ها، کاربران و لاگ‌ها را نگه می‌دارد؛ حالت «کامل» سامانه را به حالت اولیه (فقط تنظیمات + نقش‌ها + یک مدیر کل) برمی‌گرداند.
              پارامترهای قانونی ۱۴۰۵، برندینگ، تنظیمات پاداش، طبقه‌بندی ۷ سطحی و پله‌های مالیاتی در هر دو حالت حفظ می‌شوند.
            </p>
            <p className="text-[11px] text-rose-700 mt-2 flex items-center gap-1.5">
              <HardDriveDownload className="w-3.5 h-3.5" />
              پیش از اجرا از فایل دیتابیس پشتیبان بگیرید (مسیر پیش‌فرض: db/custom.db).
            </p>
          </div>
        </CardContent>
      </Card>

      {/* شمارش داده فعلی */}
      <Card className="rounded-2xl">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <DatabaseZap className="w-4 h-4 text-slate-600" />
            داده‌های موجود
            {empty && <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">دیتابیس تمیز — داده نمونه‌ای نیست</Badge>}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-3 sm:grid-cols-4 xl:grid-cols-7 gap-2">
            <Stat label="کارمند" value={counts.employees} />
            <Stat label="فیش حقوقی" value={counts.payslips} />
            <Stat label="دوره حقوق" value={counts.periods} />
            <Stat label="قرارداد" value={counts.contracts} />
            <Stat label="درخواست‌نامه" value={counts.letters} />
            <Stat label="مساعده/مرخصی" value={counts.requests} />
            <Stat label="طرح پاداش" value={counts.bonus} />
          </div>
          <p className="text-[11px] text-muted-foreground">
            سایر رکوردهای نمونه: {toFaDigits(counts.departments)} دپارتمان، {toFaDigits(counts.jobTitles)} عنوان شغلی، {toFaDigits(counts.users)} کاربر، {toFaDigits(counts.auditLogs)} رکورد لاگ حسابرسی
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <Button
              variant="outline"
              className="h-11 gap-2 border-rose-300 text-rose-700 hover:bg-rose-50 hover:text-rose-800"
              disabled={empty || busy}
              onClick={() => setConfirming("demo")}
            >
              <Trash2 className="w-4 h-4" /> حذف داده نمونه (استاندارد)
            </Button>
            <Button
              variant="destructive"
              className="h-11 gap-2"
              disabled={empty && counts.users <= 1 && counts.departments === 0 || busy}
              onClick={() => setConfirming("full")}
            >
              <DatabaseZap className="w-4 h-4" /> بازنشانی کامل (فقط تنظیمات + مدیر کل)
            </Button>
          </div>
          <p className="text-[10px] text-muted-foreground leading-5">
            معادل خط فرمان: <code className="font-mono bg-slate-100 rounded px-1" dir="ltr">npm run purge-demo</code>
            {" "}| حالت کامل: <code className="font-mono bg-slate-100 rounded px-1" dir="ltr">npm run purge-demo -- --full</code>
          </p>
        </CardContent>
      </Card>

      {/* تأیید نهایی */}
      <AlertDialog open={!!confirming} onOpenChange={(v) => !v && !busy && setConfirming(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-600" />
              {confirming === "full" ? "بازنشانی کامل سامانه؟" : "حذف داده نمونه؟"}
            </AlertDialogTitle>
            <AlertDialogDescription className="leading-6 text-right">
              {confirming === "full" ? (
                <>
                  همه کارکنان ({toFaDigits(counts.employees)})، فیش‌ها ({toFaDigits(counts.payslips)})، قراردادها ({toFaDigits(counts.contracts)})، نامه‌ها ({toFaDigits(counts.letters)})،
                  دپارتمان‌ها ({toFaDigits(counts.departments)})، عناوین شغلی ({toFaDigits(counts.jobTitles)})، آیتم‌های رفاهی، قالب نامه/قرارداد،
                  کاربران غیر از یک مدیر کل ({toFaDigits(Math.max(0, counts.users - 1))} کاربر) و لاگ حسابرسی ({toFaDigits(counts.auditLogs)} رکورد) حذف می‌شوند.
                  فقط کاربر «admin» (قدیمی‌ترین مدیر کل)، تنظیمات، نقش‌ها و طبقه‌بندی باقی می‌مانند.
                </>
              ) : (
                <>
                  همه کارکنان ({toFaDigits(counts.employees)})، فیش‌های حقوقی ({toFaDigits(counts.payslips)})، دوره‌ها ({toFaDigits(counts.periods)})، قراردادهای صادرشده
                  ({toFaDigits(counts.contracts)})، درخواست‌نامه‌ها ({toFaDigits(counts.letters)})، درخواست‌های مساعده/مرخصی ({toFaDigits(counts.requests)}) و
                  طرح‌های پاداش ({toFaDigits(counts.bonus)}) حذف می‌شوند.
                  ساختار سازمانی، قالب‌ها، کاربران و لاگ‌ها حفظ می‌شوند.
                </>
              )}
              <span className="block text-rose-700 font-medium mt-2">این عملیات برگشت‌پذیر نیست — از دیتابیس پشتیبان بگیرید.</span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>انصراف</AlertDialogCancel>
            <AlertDialogAction
              disabled={busy}
              className={confirming === "full" ? "bg-rose-600 hover:bg-rose-700" : "bg-slate-800 hover:bg-slate-900"}
              onClick={(e) => { e.preventDefault(); run(); }}
            >
              {busy ? "در حال اجرا…" : confirming === "full" ? "بله، بازنشانی کامل" : "بله، حذف کن"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

"use client";

// ============================================================
// مدیریت قالب درخواست‌نامه — فیلدهای داینامیک + نقش تأییدکننده
// ============================================================
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { FileText, Plus, Pencil, Trash2, Braces, Save, ShieldCheck, ListOrdered, ArrowLeft, Lock } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { toFaDigits } from "@/lib/jalali";

interface FieldDef {
  key: string; label: string; type: "text" | "number" | "date" | "select" | "textarea";
  options?: string[]; required?: boolean;
}
interface TemplateRow {
  id: string; code: string; title: string; category: string; description: string;
  fields: FieldDef[]; bodyTemplate: string; approverRole: string; isActive: boolean;
  version: number; requestCount: number;
}

const CATEGORY_LABELS: Record<string, string> = { GENERAL: "عمومی", HR: "منابع انسانی", FINANCE: "مالی و اداری", ADMIN: "اداری" };

const EMPLOYEE_VARS = [
  { name: "employee_name", desc: "نام کامل کارمند" },
  { name: "employee_personnel_code", desc: "کد پرسنلی" },
  { name: "employee_national_id", desc: "کد ملی" },
  { name: "employee_job_title", desc: "عنوان شغل" },
  { name: "employee_grade", desc: "طبقه شغلی" },
  { name: "employee_hire_date", desc: "تاریخ استخدام" },
  { name: "employee_mobile", desc: "موبایل" },
  { name: "base_salary_toman", desc: "حقوق پایه (تومان)" },
  { name: "company_name", desc: "نام شرکت" },
  { name: "letter_number", desc: "شماره سیستمی نامه" },
  { name: "today_date", desc: "تاریخ امروز" },
];

export function LetterTemplatesManager({ canEdit, roles }: { canEdit: boolean; roles: { key: string; name: string }[] }) {
  const list = useApi<{ templates: TemplateRow[] }>("/api/letters/templates");
  const [editing, setEditing] = useState<TemplateRow | null>(null);
  const [creating, setCreating] = useState(false);
  const { toast } = useToast();
  const templates = list.data?.templates || [];

  async function remove(t: TemplateRow) {
    if (!confirm(`حذف قالب «${t.title}»؟`)) return;
    try {
      await api(`/api/letters/templates/${t.id}`, { method: "DELETE" });
      await list.refetch();
      toast({ title: "قالب حذف شد" });
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4">
      <Card className="rounded-2xl bg-gradient-to-l from-cyan-50 to-white border-cyan-200">
        <CardContent className="p-4 flex items-start gap-3 flex-wrap">
          <FileText className="w-6 h-6 text-cyan-600 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-[200px]">
            <p className="font-bold text-sm text-slate-800">قالب درخواست‌نامه‌ها</p>
            <p className="text-xs text-muted-foreground mt-1 leading-5">
              هر قالب فیلدهای اختصاصی دارد که کارمند هنگام ثبت نامه پر می‌کند؛ متن با متغیرهای
              <code className="bg-slate-100 rounded px-1 mx-0.5 text-[10px]" dir="ltr">{"{{field_کلید}}"}</code>
              و متغیرهای کارمند پر می‌شود و برای تأیید به نقش مربوطه می‌رود.
            </p>
          </div>
          {canEdit && (
            <Button className="bg-cyan-600 hover:bg-cyan-700 gap-1.5 shrink-0" onClick={() => setCreating(true)}>
              <Plus className="w-4 h-4" /> قالب جدید
            </Button>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {list.loading && [0, 1, 2].map((i) => <Skeleton key={i} className="h-40 rounded-2xl" />)}
        {templates.map((t) => (
          <Card key={t.id} className="rounded-2xl flex flex-col">
            <CardContent className="p-4 flex-1 space-y-2.5">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-bold text-sm flex-1">{t.title}</p>
                <Badge variant="outline" className="text-[10px] font-mono" dir="ltr">{t.code}</Badge>
              </div>
              <div className="flex flex-wrap gap-1">
                <Badge className="bg-cyan-50 text-cyan-700 hover:bg-cyan-50 text-[10px]">{CATEGORY_LABELS[t.category] || t.category}</Badge>
                <Badge variant="outline" className="text-[10px]">{toFaDigits(t.fields.length)} فیلد</Badge>
                <Badge variant="outline" className="text-[10px]">نسخه {toFaDigits(t.version)}</Badge>
                <Badge variant="outline" className="text-[10px]">{toFaDigits(t.requestCount)} صدور</Badge>
                <Badge className={t.isActive ? "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" : "bg-slate-100 text-slate-500 hover:bg-slate-100"}>{t.isActive ? "فعال" : "غیرفعال"}</Badge>
              </div>
              {t.description && <p className="text-xs text-muted-foreground leading-5 line-clamp-2">{t.description}</p>}
              <p className="text-[11px] text-muted-foreground">تأییدکننده: {roles.find((r) => r.key === t.approverRole)?.name || t.approverRole}</p>
              {canEdit && (
                <div className="flex gap-1.5 pt-1">
                  <Button size="sm" variant="outline" className="gap-1 h-8 flex-1" onClick={() => setEditing(t)}><Pencil className="w-3.5 h-3.5" /> ویرایش</Button>
                  <Button size="sm" variant="destructive" className="h-8 w-8 p-0" disabled={t.requestCount > 0} onClick={() => remove(t)} title={t.requestCount > 0 ? "پیش‌تر استفاده شده — غیرفعال کنید" : ""}>
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {(creating || editing) && (
        <LetterTemplateEditor
          template={editing}
          roles={roles}
          onClose={() => { setCreating(false); setEditing(null); }}
          onSaved={() => { list.refetch(); setCreating(false); setEditing(null); toast({ title: editing ? "قالب به‌روزرسانی شد (نسخه جدید)" : "قالب نامه ساخته شد" }); }}
        />
      )}
    </div>
  );
}

function LetterTemplateEditor({ template, roles, onClose, onSaved }: {
  template: TemplateRow | null;
  roles: { key: string; name: string }[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const { toast } = useToast();
  const [title, setTitle] = useState(template?.title || "");
  const [category, setCategory] = useState(template?.category || "GENERAL");
  const [description, setDescription] = useState(template?.description || "");
  const [approverRole, setApproverRole] = useState(template?.approverRole || "HR_MANAGER");
  const [isActive, setIsActive] = useState(template?.isActive ?? true);
  const [body, setBody] = useState(template?.bodyTemplate || DEFAULT_LETTER_BODY);
  const [fields, setFields] = useState<FieldDef[]>(template?.fields || []);
  const [saving, setSaving] = useState(false);

  function addField() {
    setFields([...fields, { key: "", label: "", type: "text", required: false }]);
  }
  function updField(idx: number, patch: Partial<FieldDef>) {
    const next = [...fields];
    next[idx] = { ...next[idx], ...patch };
    setFields(next);
  }
  function delField(idx: number) {
    setFields(fields.filter((_, i) => i !== idx));
  }

  async function save() {
    if (!title.trim() || !body.trim()) {
      toast({ title: "عنوان و متن قالب الزامی است", variant: "destructive" });
      return;
    }
    const cleaned = fields.filter((f) => f.key.trim() && f.label.trim());
    for (const f of cleaned) {
      if (!/^[a-z][a-z0-9_]*$/i.test(f.key.trim())) {
        toast({ title: `کلید فیلد «${f.label}» نامعتبر است`, description: "باید با حرف شروع شود و فقط حروف/عدد/زیرخط داشته باشد.", variant: "destructive" });
        return;
      }
    }
    const dup = cleaned.map((f) => f.key).filter((k, i, a) => a.indexOf(k) !== i);
    if (dup.length) {
      toast({ title: `کلید فیلد تکراری: ${dup.join("، ")}`, variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: title.trim(), category, description, approverRole, isActive,
        bodyTemplate: body, fields: cleaned,
      };
      if (template) {
        await api(`/api/letters/templates/${template.id}`, { method: "PATCH", json: payload });
      } else {
        await api("/api/letters/templates", { method: "POST", json: payload });
      }
      onSaved();
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[78.4rem] max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><FileText className="w-5 h-5 text-cyan-600" /> {template ? `ویرایش قالب — ${template.title}` : "قالب نامه جدید"}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">عنوان نامه</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="درخواست تمدید قرارداد" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">دسته</Label>
            <select className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm" value={category} onChange={(e) => setCategory(e.target.value)} dir="rtl">
              {Object.entries(CATEGORY_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">نقش تأییدکننده (اداری یا سرمایه انسانی)</Label>
            <select className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm" value={approverRole} onChange={(e) => setApproverRole(e.target.value)} dir="rtl">
              {roles.map((r) => <option key={r.key} value={r.key}>{r.name}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">توضیح کوتاه (نمایش به کارمند)</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div className="flex items-center gap-2 sm:col-span-2 rounded-xl border p-3">
            <Switch checked={isActive} onCheckedChange={setIsActive} id="lt-active" />
            <label htmlFor="lt-active" className="text-xs cursor-pointer">فعال — قابل انتخاب توسط کارکنان</label>
          </div>
        </div>

        {/* فیلدهای داینامیک */}
        <div className="rounded-xl border bg-slate-50/60 p-3 space-y-2">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold">فیلدهای مورد نیاز نامه (فرم داینامیک کارمند)</p>
            <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={addField}><Plus className="w-3 h-3" /> افزودن فیلد</Button>
          </div>
          {fields.length === 0 && <p className="text-[11px] text-muted-foreground">فیلدی تعریف نشده — نامه فقط با متغیرهای کارمند پر می‌شود.</p>}
          {fields.map((f, idx) => (
            <div key={idx} className="grid grid-cols-12 gap-2 items-end bg-white border rounded-lg p-2">
              <div className="col-span-3 space-y-1">
                <Label className="text-[10px]">کلید (لاتین)</Label>
                <Input className="h-8 text-xs" dir="ltr" value={f.key} onChange={(e) => updField(idx, { key: e.target.value })} placeholder="amount" />
              </div>
              <div className="col-span-3 space-y-1">
                <Label className="text-[10px]">برچسب فارسی</Label>
                <Input className="h-8 text-xs" value={f.label} onChange={(e) => updField(idx, { label: e.target.value })} placeholder="مبلغ درخواستی" />
              </div>
              <div className="col-span-2 space-y-1">
                <Label className="text-[10px]">نوع</Label>
                <select className="w-full h-8 rounded-md border bg-transparent px-1.5 text-xs" value={f.type} onChange={(e) => updField(idx, { type: e.target.value as FieldDef["type"] })} dir="rtl">
                  <option value="text">متن</option>
                  <option value="number">عدد</option>
                  <option value="date">تاریخ</option>
                  <option value="select">انتخابی</option>
                  <option value="textarea">متن بلند</option>
                </select>
              </div>
              <div className="col-span-3 space-y-1">
                <Label className="text-[10px]">گزینه‌ها (با «،» جدا — برای انتخابی)</Label>
                <Input className="h-8 text-xs" value={(f.options || []).join("، ")} onChange={(e) => updField(idx, { options: e.target.value ? e.target.value.split(/[،,]/).map((s) => s.trim()).filter(Boolean) : undefined })} placeholder="۶، ۱۲، ۲۴" disabled={f.type !== "select"} />
              </div>
              <div className="col-span-1 flex flex-col items-center gap-1">
                <label className="text-[9px] text-center leading-3">اجباری</label>
                <input type="checkbox" className="accent-cyan-600 w-4 h-4" checked={!!f.required} onChange={(e) => updField(idx, { required: e.target.checked })} />
              </div>
              <div className="col-span-12 flex justify-start">
                <Button size="sm" variant="ghost" className="h-6 text-rose-600 text-[10px] gap-0.5" onClick={() => delField(idx)}><Trash2 className="w-3 h-3" /> حذف فیلد</Button>
              </div>
            </div>
          ))}
        </div>

        {/* متغیرها */}
        <div className="rounded-xl border bg-slate-50/60 p-3">
          <p className="text-xs font-bold mb-2 flex items-center gap-1"><Braces className="w-3.5 h-3.5" /> متغیرها — در متن قالب استفاده کنید:</p>
          <div className="flex flex-wrap gap-1.5">
            {EMPLOYEE_VARS.map((v) => (
              <button key={v.name} type="button" title={v.desc} onClick={() => setBody((b) => b + `{{${v.name}}}`)} className="text-[10px] font-mono bg-white border hover:border-cyan-400 hover:bg-cyan-50 rounded-md px-1.5 py-0.5" dir="ltr">
                {v.name}
              </button>
            ))}
            {fields.filter((f) => f.key.trim()).map((f) => (
              <button key={f.key} type="button" title={f.label} onClick={() => setBody((b) => b + `{{field_${f.key.trim()}}}`)} className="text-[10px] font-mono bg-cyan-50 border border-cyan-300 hover:bg-cyan-100 rounded-md px-1.5 py-0.5" dir="ltr">
                field_{f.key.trim()}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1.5">
          <Label className="text-xs">متن قالب نامه</Label>
          <Textarea dir="rtl" className="min-h-[240px] text-[13px] leading-8" value={body} onChange={(e) => setBody(e.target.value)} placeholder="متن نامه با متغیرها..." />
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-cyan-600 hover:bg-cyan-700">{saving ? "..." : template ? "ذخیره (نسخه جدید)" : "ایجاد قالب"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

const DEFAULT_LETTER_BODY = `خدمات مدیریت محترم شرکت {{company_name}},

اینجانب {{employee_name}} (کد پرسنلی {{employee_personnel_code}}) در سمت {{employee_job_title}}، به موجب این نامه درخواست زیر را دارم:

شرح درخواست:
{{field_reason}}

خواهشمند است بررسی و اعلام نتیجه فرمایید.

با تشکر — {{employee_name}}
شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`;

// ============================================================
// سیاست دسترسی چاپ/دانلود نامه برای کارمند درخواست‌کننده
// پیش‌فرض: کارمند هیچ دسترسی ندارد — فعال‌سازی + انتخاب دسته‌ها/انواع نسخه
// ============================================================

const POLICY_CATEGORY_LABELS: Record<string, string> = { GENERAL: "عمومی", HR: "منابع انسانی", FINANCE: "مالی", ADMIN: "اداری" };
const POLICY_VARIANT_LABELS: Record<string, string> = {
  PRINT_LH: "چاپ با سربرگ",
  PRINT_PLAIN: "چاپ بدون سربرگ",
  DOWNLOAD_LH: "دانلود با سربرگ",
  DOWNLOAD_PLAIN: "دانلود بدون سربرگ",
};
const POLICY_VARIANTS = Object.keys(POLICY_VARIANT_LABELS);
const POLICY_CATEGORIES = Object.keys(POLICY_CATEGORY_LABELS);

interface DownloadPolicyState {
  employeeCanDownload: boolean;
  categories: string[];
  variants: string[];
}

export function LetterDownloadPolicyCard({ canEdit }: { canEdit: boolean }) {
  const { toast } = useToast();
  const settings = useApi<{ letters: { downloadPolicy: DownloadPolicyState } }>("/api/settings");
  const [policy, setPolicy] = useState<DownloadPolicyState>({ employeeCanDownload: false, categories: [], variants: [] });
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings.data?.letters?.downloadPolicy && !loaded) {
      setPolicy(settings.data.letters.downloadPolicy);
      setLoaded(true);
    }
  }, [settings.data, loaded]);

  function toggleCategory(cat: string) {
    setPolicy((p) => ({
      ...p,
      categories: p.categories.includes(cat) ? p.categories.filter((c) => c !== cat) : [...p.categories, cat],
    }));
  }
  function toggleVariant(v: string) {
    setPolicy((p) => ({
      ...p,
      variants: p.variants.includes(v) ? p.variants.filter((x) => x !== v) : [...p.variants, v],
    }));
  }

  async function save() {
    if (policy.employeeCanDownload && (policy.categories.length === 0 || policy.variants.length === 0)) {
      toast({ title: "برای فعال‌سازی، حداقل یک دسته نامه و یک نوع نسخه انتخاب کنید", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/settings", { method: "PUT", json: { letters: { downloadPolicy: policy } } });
      toast({
        title: "سیاست دسترسی دانلود ذخیره شد",
        description: policy.employeeCanDownload
          ? "کارکنان می‌توانند نسخه رسمی نامه‌های دسته‌های انتخابی را با انواع مجاز دریافت کنند."
          : "کارکنان دسترسی چاپ/دانلود ندارند — دریافت فقط از واحد اداری.",
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Lock className="w-4 h-4 text-amber-600" />
          دسترسی چاپ/دانلود نامه برای کارمند درخواست‌کننده
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          پیش‌فرض: کارمند درخواست‌کننده <b>هیچ دسترسی چاپ/دانلودی ندارد</b> و نسخه رسمی فقط از طریق واحد اداری صادر می‌شود.
          با فعال‌سازی، انتخاب می‌کنید چه دسته نامه‌ای و چه نوع نسخه‌ای برای کارمند در پرتال قابل دریافت باشد.
          مدیران و کارشناسان اداری (مجوز تأیید/ثبت نامه) همیشه دسترسی کامل دارند.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between rounded-xl border p-3">
          <div>
            <p className="text-sm font-medium">فعال‌سازی دریافت نسخه رسمی توسط کارمند</p>
            <p className="text-[11px] text-muted-foreground mt-0.5">نمایش دکمه‌های چاپ/دانلود در پرتال کارمند برای نامه‌های تأییدشده</p>
          </div>
          <Switch
            checked={policy.employeeCanDownload}
            onCheckedChange={(v) => canEdit && setPolicy({ ...policy, employeeCanDownload: v })}
            disabled={!canEdit}
          />
        </div>

        {policy.employeeCanDownload && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="rounded-xl border bg-slate-50/60 p-3 space-y-2">
              <p className="text-xs font-bold">دسته‌های نامه مجاز</p>
              <p className="text-[10px] text-muted-foreground">فقط نامه‌های تأییدشده این دسته‌ها برای کارمند قابل دریافت است</p>
              <div className="grid grid-cols-2 gap-1.5">
                {POLICY_CATEGORIES.map((cat) => (
                  <label key={cat} className={`flex items-center gap-2 rounded-lg border bg-white px-2.5 py-1.5 text-xs cursor-pointer transition-colors ${policy.categories.includes(cat) ? "border-teal-400 bg-teal-50/50" : ""} ${canEdit ? "" : "opacity-60"}`}>
                    <input
                      type="checkbox"
                      className="accent-teal-600 w-4 h-4"
                      checked={policy.categories.includes(cat)}
                      disabled={!canEdit}
                      onChange={() => toggleCategory(cat)}
                    />
                    {POLICY_CATEGORY_LABELS[cat]}
                  </label>
                ))}
              </div>
            </div>
            <div className="rounded-xl border bg-slate-50/60 p-3 space-y-2">
              <p className="text-xs font-bold">انواع نسخه مجاز</p>
              <p className="text-[10px] text-muted-foreground">کدام دکمه‌ها در پرتال کارمند نمایش داده شود</p>
              <div className="space-y-1.5">
                {POLICY_VARIANTS.map((v) => (
                  <label key={v} className={`flex items-center gap-2 rounded-lg border bg-white px-2.5 py-1.5 text-xs cursor-pointer transition-colors ${policy.variants.includes(v) ? "border-teal-400 bg-teal-50/50" : ""} ${canEdit ? "" : "opacity-60"}`}>
                    <input
                      type="checkbox"
                      className="accent-teal-600 w-4 h-4"
                      checked={policy.variants.includes(v)}
                      disabled={!canEdit}
                      onChange={() => toggleVariant(v)}
                    />
                    {POLICY_VARIANT_LABELS[v]}
                  </label>
                ))}
              </div>
            </div>
          </div>
        )}

        {canEdit && (
          <div className="flex justify-start">
            <Button onClick={save} disabled={saving} className="bg-amber-600 hover:bg-amber-700 gap-1.5">
              <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره سیاست دسترسی"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// ============================================================
// روال‌های تأیید داینامیک نامه‌ها — به ازای دسته نامه
// هر روال: دنباله مراحل (نقش‌ها) — تعیین‌شده برای هر دسته؛
// دسته بدون روال = تک‌مرحله‌ای با «نقش تأییدکننده» قالب (رفتار قدیمی)
// ============================================================
interface FlowState {
  id: string;
  name: string;
  steps: string[];
}

export function LetterApprovalFlowsCard({ canEdit, roles }: { canEdit: boolean; roles: { key: string; name: string }[] }) {
  const { toast } = useToast();
  const settings = useApi<{ letters: { approvalFlows: FlowState[]; categoryFlows: Record<string, string> } }>("/api/settings");
  const [flows, setFlows] = useState<FlowState[]>([]);
  const [catFlows, setCatFlows] = useState<Record<string, string>>({});
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const d = settings.data?.letters;
    if (d && !loaded) {
      setFlows((d.approvalFlows || []).map((f) => ({ ...f, steps: [...(f.steps || [])] })));
      setCatFlows({ ...(d.categoryFlows || {}) });
      setLoaded(true);
    }
  }, [settings.data, loaded]);

  function newId(): string {
    return `flow_${Date.now().toString(36)}${Math.floor(Math.random() * 1000).toString(36)}`;
  }

  function addFlow() {
    if (flows.length >= 10) return;
    setFlows([...flows, { id: newId(), name: "", steps: [""] }]);
  }
  function updFlow(idx: number, patch: Partial<FlowState>) {
    const next = [...flows];
    next[idx] = { ...next[idx], ...patch };
    setFlows(next);
  }
  function delFlow(idx: number) {
    const removed = flows[idx];
    const nextCats: Record<string, string> = {};
    for (const [cat, fid] of Object.entries(catFlows)) {
      nextCats[cat] = fid === removed.id ? "" : fid;
    }
    setFlows(flows.filter((_, i) => i !== idx));
    setCatFlows(nextCats);
  }

  async function save() {
    const cleaned = flows
      .map((f) => ({ id: f.id, name: f.name.trim(), steps: f.steps.map((s) => s.trim()).filter(Boolean) }))
      .filter((f) => f.name && f.steps.length > 0);
    if (flows.some((f) => f.name.trim() && f.steps.filter((s) => s.trim()).length === 0)) {
      toast({ title: "هر روال باید حداقل یک مرحله (نقش) داشته باشد", variant: "destructive" });
      return;
    }
    if (flows.some((f) => !f.name.trim() && f.steps.some((s) => s.trim()))) {
      toast({ title: "نام همه روال‌ها را تکمیل کنید", variant: "destructive" });
      return;
    }
    // اعتبارسنجی: مراحل = کلید نقش‌های موجود
    const roleKeys = new Set(roles.map((r) => r.key));
    for (const f of cleaned) {
      for (const s of f.steps) {
        if (!roleKeys.has(s)) {
          toast({ title: `نقش «${s}» در روال «${f.name}» یافت نشد`, variant: "destructive" });
          return;
        }
      }
    }
    setSaving(true);
    try {
      const cats: Record<string, string> = {};
      for (const cat of POLICY_CATEGORIES) {
        const fid = catFlows[cat] || "";
        if (fid && cleaned.some((f) => f.id === fid)) cats[cat] = fid;
      }
      await api("/api/settings", { method: "PUT", json: { letters: { approvalFlows: cleaned, categoryFlows: cats } } });
      setFlows(cleaned.map((f) => ({ ...f, steps: [...f.steps] })));
      setCatFlows(cats);
      toast({
        title: "روال‌های تأیید ذخیره شد",
        description: `اکنون ${toFaDigits(cleaned.length)} روال تعریف شده — نامه‌های جدید دسته‌های دارای روال، از مسیر چندمرحله‌ای خود عبور می‌کنند.`,
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  const roleOptions = roles.length ? roles : [{ key: "HR_MANAGER", name: "مدیر منابع انسانی" }];

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <ListOrdered className="w-4 h-4 text-violet-600" />
          روال‌های تأیید داینامیک نامه‌ها
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          برای هر دسته نامه (اداری، منابع انسانی، مالی، عمومی) می‌توانید روال تأیید اختصاصی تعریف کنید:
          دنباله‌ای از مراحل که هر مرحله با یک نقش تأیید می‌شود — نامه فقط بعد از تأیید همه مراحل، امضای دیجیتال می‌گیرد.
          دسته بدون روال = تک‌مرحله‌ای با «نقش تأییدکننده» قالب (رفتار قبلی).
          نامه‌های در جریان از اسنپ‌شات روال زمان ثبت خود پیروی می‌کنند.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* فهرست روال‌ها */}
        <div className="space-y-2">
          {flows.length === 0 && (
            <p className="text-[11px] text-muted-foreground rounded-lg border border-dashed p-3 text-center">
              هنوز روالی تعریف نشده — با «افزودن روال» شروع کنید (مثال: مدیر دپارتمان ← منابع انسانی ← مدیر عامل).
            </p>
          )}
          {flows.map((f, idx) => (
            <div key={f.id} className="bg-slate-50/70 border rounded-xl p-3 space-y-2.5">
              <div className="flex items-center gap-2">
                <Input
                  className="h-8 text-xs flex-1"
                  value={f.name}
                  disabled={!canEdit}
                  onChange={(e) => updFlow(idx, { name: e.target.value })}
                  placeholder="نام روال (مثل: اداری دو مرحله‌ای)"
                />
                <Badge variant="outline" className="text-[10px] shrink-0">{toFaDigits(f.steps.filter(Boolean).length)} مرحله</Badge>
                {canEdit && (
                  <Button size="sm" variant="ghost" className="h-8 w-8 p-0 text-rose-600 shrink-0" onClick={() => delFlow(idx)} title="حذف روال">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                )}
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                {f.steps.map((s, si) => (
                  <span key={si} className="inline-flex items-center gap-1">
                    <select
                      className="h-8 rounded-md border bg-white px-2 text-[11px]"
                      value={s}
                      disabled={!canEdit}
                      onChange={(e) => {
                        const next = [...f.steps];
                        next[si] = e.target.value;
                        updFlow(idx, { steps: next });
                      }}
                      dir="rtl"
                    >
                      <option value="">— انتخاب نقش —</option>
                      {roleOptions.map((r) => (
                        <option key={r.key} value={r.key}>{r.name}</option>
                      ))}
                    </select>
                    {canEdit && (
                      <button
                        type="button"
                        className="text-rose-500 hover:text-rose-700 text-[10px] p-0.5"
                        title="حذف مرحله"
                        onClick={() => updFlow(idx, { steps: f.steps.filter((_, i) => i !== si) })}
                      >
                        ×
                      </button>
                    )}
                    {si < f.steps.length - 1 ? <ArrowLeft className="w-3 h-3 text-slate-400" /> : null}
                  </span>
                ))}
                {canEdit && f.steps.length < 8 && (
                  <Button size="sm" variant="outline" className="h-7 text-[10px] gap-0.5 px-2" onClick={() => updFlow(idx, { steps: [...f.steps, ""] })}>
                    <Plus className="w-3 h-3" /> مرحله
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* تخصیص روال به دسته‌ها */}
        <div className="rounded-xl border bg-violet-50/40 p-3 space-y-2">
          <p className="text-xs font-bold text-violet-900">روال تأیید هر دسته نامه</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {POLICY_CATEGORIES.map((cat) => (
              <div key={cat} className="flex items-center gap-2 bg-white border rounded-lg px-2.5 py-1.5">
                <span className="text-xs font-medium w-28 shrink-0">{POLICY_CATEGORY_LABELS[cat]}</span>
                <select
                  className="h-8 flex-1 rounded-md border bg-transparent px-2 text-[11px]"
                  value={catFlows[cat] || ""}
                  disabled={!canEdit}
                  onChange={(e) => setCatFlows({ ...catFlows, [cat]: e.target.value })}
                  dir="rtl"
                >
                  <option value="">تک‌مرحله‌ای (نقش تأییدکننده قالب)</option>
                  {flows.filter((f) => f.name.trim() && f.steps.filter(Boolean).length > 0).map((f) => (
                    <option key={f.id} value={f.id}>{f.name} ({toFaDigits(f.steps.filter(Boolean).length)} مرحله)</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>

        {canEdit && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-1" onClick={addFlow} disabled={flows.length >= 10}>
              <Plus className="w-3.5 h-3.5" /> افزودن روال
            </Button>
            <Button size="sm" onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-700 gap-1.5">
              <Save className="w-3.5 h-3.5" /> {saving ? "در حال ذخیره..." : "ذخیره روال‌ها"}
            </Button>
          </div>
        )}
        <p className="text-[10px] text-muted-foreground leading-5 flex items-start gap-1.5">
          <ShieldCheck className="w-3.5 h-3.5 mt-0.5 shrink-0 text-violet-500" />
          حداکثر ۱۰ روال و ۸ مرحله در هر روال. رد در هر مرحله = رد کل نامه. مدیر کل سیستم در همه مراحل مجاز است.
          مسیر طی‌شده هر نامه در پرتال کارمند و صندوق تأیید نمایش داده می‌شود.
        </p>
      </CardContent>
    </Card>
  );
}

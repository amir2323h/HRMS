"use client";

// ============================================================
// ماژول پاداش/سود سالانه — لِول‌بندی ۷ طبقه + تارگت + بودجه
// فرمول: حقوق پایه × ماه طبقه (+۱ اورتارگت) × (ماه حضور ÷ ۱۲) × درصد تیر
// ============================================================
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Gift, Plus, Trash2, CheckCircle2, Printer, Search, Eye, RefreshCw, Banknote, Target } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa, fmtPercent, BONUS_TIER_LABELS, BONUS_SCHEME_STATUS_LABELS } from "@/lib/format";
import { toFaDigits, todayJalaliStr } from "@/lib/jalali";
import { MoneyInput, Money } from "../money-input";
import { JalaliDatePicker } from "../jalali-datepicker";
import { NativeSelect } from "../native-select";

interface SchemeRow {
  id: string; year: number; title: string;
  targetAmount: number; actualAmount: number; achievementRatio: number;
  tier: string; tierMode: string; manualTier: string;
  budget: number; scaleToBudget: boolean; referenceDateJ: string;
  status: string; notes: string; totalComputed: number; totalFinal: number;
  lineCount: number; createdBy: string; createdAt: string;
}
interface LineRow {
  id: string; employeeId: string; employeeName: string; personnelCode: string; department: string;
  jobLevel: number; jobLevelTitle: string; baseSalary: number; bonusMonths: number;
  monthsPresent: number; paymentPercent: number; computedAmount: number; finalAmount: number;
}

const TIER_BADGE: Record<string, string> = {
  BELOW_80: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  AT_80: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  AT_100: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  OVER_120: "bg-teal-100 text-teal-800 hover:bg-teal-100",
};

export function BonusView({ canManage }: { canManage: boolean }) {
  const [creating, setCreating] = useState(false);
  const [viewingId, setViewingId] = useState<string | null>(null);
  const list = useApi<{ schemes: SchemeRow[] }>("/api/bonus");
  const config = useApi<{ config: { levels: Record<string, number>; tiers: { key: string; label: string; paymentPercent: number; extraMonths: number }[] } }>("/api/bonus-config");
  const schemes = list.data?.schemes || [];

  return (
    <div className="space-y-4">
      {/* کارت راهنمای قواعد */}
      <Card className="rounded-2xl bg-gradient-to-l from-teal-50 to-white border-teal-200">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Target className="w-6 h-6 text-teal-600 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-slate-800">پاداش سالانه بر اساس لِول‌بندی</p>
              <p className="text-xs text-muted-foreground mt-1 leading-5">
                هر پاداش = یک ماه حقوق پایه (بدون اضافات قانونی). ماه پاداش هر طبقه و درصد پرداخت تیرها در تنظیمات تعریف می‌شود؛
                در صورت تحقق ۱۲۰٪+ تارگت، یک پله (یک ماه) به پاداش اضافه می‌شود و در تحقق ۸۰٪، ۸۰٪ مبلغ پرداخت می‌گردد.
                ماه حضور در سال طرح به‌صورت خودکار از تاریخ استخدام محاسبه می‌شود.
              </p>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {Object.entries(config.data?.config.levels || {}).map(([lv, m]) => (
                  <Badge key={lv} variant="outline" className="text-[10px]">
                    طبقه {toFaDigits(lv)}: {toFaDigits(m)} ماه
                  </Badge>
                ))}
              </div>
            </div>
            {canManage && (
              <Button className="bg-teal-600 hover:bg-teal-700 gap-1.5 shrink-0" onClick={() => setCreating(true)}>
                <Plus className="w-4 h-4" /> طرح پاداش جدید
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* لیست طرح‌ها */}
      <Card className="rounded-2xl overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2"><Gift className="w-4 h-4 text-teal-600" /> طرح‌های پاداش</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {list.loading ? (
            <div className="p-4 space-y-2">{[0, 1].map((i) => <Skeleton key={i} className="h-12" />)}</div>
          ) : schemes.length === 0 ? (
            <div className="py-16 text-center">
              <Gift className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">هنوز طرح پاداشی ثبت نشده — با «طرح پاداش جدید» شروع کنید.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    <TableHead className="text-right">عنوان طرح</TableHead>
                    <TableHead className="text-center">تارگت / تحقق</TableHead>
                    <TableHead className="text-center">وضعیت تارگت</TableHead>
                    <TableHead className="text-center">بودجه / جمع پرداختی</TableHead>
                    <TableHead className="text-center">نفرات</TableHead>
                    <TableHead className="text-center">وضعیت</TableHead>
                    <TableHead className="text-center">عملیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {schemes.map((s) => (
                    <TableRow key={s.id} className="hover:bg-teal-50/40">
                      <TableCell className="font-medium text-sm">
                        {s.title}
                        <span className="block text-[11px] text-muted-foreground">سال {toFaDigits(s.year)} • مرجع: {toFaDigits(s.referenceDateJ)}</span>
                      </TableCell>
                      <TableCell className="text-xs tabular-nums text-center">
                        <Money amount={s.targetAmount} />
                        <span className="block text-muted-foreground">↓ <Money amount={s.actualAmount} /></span>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge className={TIER_BADGE[s.tier] || ""}>{BONUS_TIER_LABELS[s.tier] || s.tier}</Badge>
                        <span className="block text-[10px] text-muted-foreground mt-1 tabular-nums">
                          {s.achievementRatio >= 99 ? "≥" : ""}{fmtPercent(Math.min(s.achievementRatio, 9.99), 1)}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs tabular-nums text-center">
                        <Money amount={s.budget} />
                        <span className="block text-emerald-700 font-medium">↑ <Money amount={s.totalFinal} /></span>
                      </TableCell>
                      <TableCell className="text-center text-xs tabular-nums">{toFaDigits(s.lineCount)}</TableCell>
                      <TableCell className="text-center">
                        <Badge className={s.status === "DRAFT" ? "bg-slate-100 text-slate-600 hover:bg-slate-100" : s.status === "CONFIRMED" ? "bg-amber-100 text-amber-700 hover:bg-amber-100" : "bg-emerald-100 text-emerald-700 hover:bg-emerald-100"}>
                          {BONUS_SCHEME_STATUS_LABELS[s.status]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <div className="flex justify-center gap-1">
                          <button className="p-1.5 rounded-lg hover:bg-teal-100 text-teal-600" title="جزئیات و محاسبه" onClick={() => setViewingId(s.id)}>
                            <Eye className="w-4 h-4" />
                          </button>
                          {canManage && s.status === "DRAFT" && (
                            <>
                              <button className="p-1.5 rounded-lg hover:bg-emerald-100 text-emerald-600" title="تأیید نهایی طرح" onClick={() => confirmScheme(s)}>
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                              <button className="p-1.5 rounded-lg hover:bg-rose-100 text-rose-600" title="حذف پیش‌نویس" onClick={() => removeScheme(s)}>
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {canManage && s.status === "CONFIRMED" && (
                            <button className="p-1.5 rounded-lg hover:bg-emerald-100 text-emerald-600" title="ثبت پرداخت" onClick={() => payScheme(s)}>
                              <Banknote className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {canManage && creating && (
        <SchemeEditor
          onClose={() => setCreating(false)}
          onSaved={() => { setCreating(false); list.refetch(); toast2() }}
        />
      )}

      {viewingId && (
        <SchemeDetail id={viewingId} canManage={canManage} onClose={() => setViewingId(null)} onChanged={() => list.refetch()} />
      )}
    </div>
  );

  function toast2() {
    // placeholder — toast در SchemeEditor خودش نمایش می‌دهد
  }

  async function confirmScheme(s: SchemeRow) {
    try {
      await api(`/api/bonus/${s.id}`, { method: "PATCH", json: { status: "CONFIRMED" } });
      await list.refetch();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    }
  }
  async function payScheme(s: SchemeRow) {
    try {
      await api(`/api/bonus/${s.id}`, { method: "PATCH", json: { status: "PAID" } });
      await list.refetch();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    }
  }
  async function removeScheme(s: SchemeRow) {
    if (!confirm(`حذف طرح «${s.title}»؟`)) return;
    try {
      await api(`/api/bonus/${s.id}`, { method: "DELETE" });
      await list.refetch();
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    }
  }
}

// ================= ساخت/ویرایش طرح =================
function SchemeEditor({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const year = +todayJalaliStr().slice(0, 4);
  const [title, setTitle] = useState(`پاداش سال ${toFaDigits(year)}`);
  const [targetToman, setTargetToman] = useState(50_000_000_000); // ۵۰ میلیارد تومان
  const [actualToman, setActualToman] = useState(0);
  const [budgetToman, setBudgetToman] = useState(20_000_000_000);
  const [tierMode, setTierMode] = useState("AUTO");
  const [manualTier, setManualTier] = useState("AT_100");
  const [scaleToBudget, setScaleToBudget] = useState(true);
  const [referenceDateJ, setReferenceDateJ] = useState(`${year}/12/29`);
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  // پیش‌نمایش تیر
  const ratio = targetToman > 0 ? actualToman / targetToman : 0;
  const previewTier = tierMode === "MANUAL" ? manualTier : ratio >= 1.2 ? "OVER_120" : ratio >= 1 ? "AT_100" : ratio >= 0.8 ? "AT_80" : "BELOW_80";

  async function save() {
    if (!title.trim()) {
      toast({ title: "عنوان طرح الزامی است", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      await api("/api/bonus", {
        method: "POST",
        json: {
          year,
          title,
          targetAmount: Math.round(targetToman * 10), // تومان → ریال
          actualAmount: Math.round(actualToman * 10),
          budget: Math.round(budgetToman * 10),
          tierMode,
          manualTier,
          scaleToBudget,
          referenceDateJ,
          notes,
        },
      });
      toast({ title: "طرح پاداش محاسبه شد", description: "خطوط هر نفر بر اساس طبقه، ماه حضور و تیر محاسبه شد." });
      onSaved();
    } catch (e) {
      toast({ title: "خطا در محاسبه طرح", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[58.8rem] max-h-[88vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Plus className="w-5 h-5 text-teal-600" /> طرح پاداش جدید — سال {toFaDigits(year)}</DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5 sm:col-span-2">
            <Label className="text-xs">عنوان طرح</Label>
            <Input value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تارگت (هدف) — تومان</Label>
            <MoneyInput value={targetToman} onChange={setTargetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تحقق واقعی — تومان</Label>
            <MoneyInput value={actualToman} onChange={setActualToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">بودجه پاداش — تومان</Label>
            <MoneyInput value={budgetToman} onChange={setBudgetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تاریخ مرجع محاسبه ماه حضور</Label>
            <JalaliDatePicker value={referenceDateJ} onChange={setReferenceDateJ} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تعیین وضعیت تارگت</Label>
            <NativeSelect value={tierMode} onChange={setTierMode} ariaLabel="حالت تیر">
              <option value="AUTO">خودکار — از نسبت تحقق ({fmtPercent(Math.min(ratio, 9.99), 1)})</option>
              <option value="MANUAL">انتخاب دستی وضعیت</option>
            </NativeSelect>
          </div>
          {tierMode === "MANUAL" && (
            <div className="space-y-1.5">
              <Label className="text-xs">وضعیت (چهار حالت)</Label>
              <NativeSelect value={manualTier} onChange={setManualTier} ariaLabel="وضعیت تارگت">
                {Object.entries(BONUS_TIER_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </NativeSelect>
            </div>
          )}
          <div className="flex items-center gap-2 sm:col-span-2 rounded-xl border p-3">
            <Checkbox id="scale" checked={scaleToBudget} onCheckedChange={(v) => setScaleToBudget(!!v)} />
            <label htmlFor="scale" className="text-xs leading-5 cursor-pointer">
              مقیاس‌بندی خطی برای جا شدن در بودجه — اگر جمع پاداش از بودجه بیشتر شود، سهم همه به‌نسبت بودجه کاهش می‌یابد.
            </label>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label className="text-xs">یادداشت (اختیاری)</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>

        <div className={`rounded-xl border p-3 text-xs leading-6 ${previewTier === "OVER_120" ? "bg-teal-50 border-teal-200 text-teal-800" : previewTier === "AT_100" ? "bg-emerald-50 border-emerald-200 text-emerald-800" : previewTier === "AT_80" ? "bg-amber-50 border-amber-200 text-amber-800" : "bg-rose-50 border-rose-200 text-rose-800"}`}>
          <b>پیش‌نمایش وضعیت: {BONUS_TIER_LABELS[previewTier]}</b>
          {previewTier === "BELOW_80" && " — پاداشی پرداخت نمی‌شود (نرسیدن به ۸۰٪ تارگت)."}
          {previewTier === "AT_80" && " — ۸۰٪ مبلغ پاداش هر نفر پرداخت می‌شود."}
          {previewTier === "AT_100" && " — پاداش کامل طبقه هر نفر پرداخت می‌شود."}
          {previewTier === "OVER_120" && " — پاداش کامل + یک ماه پاداش اضافه برای هر نفر."}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
            <RefreshCw className={`w-4 h-4 ${saving ? "animate-spin" : ""}`} /> {saving ? "در حال محاسبه..." : "محاسبه و ذخیره"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ================= جزئیات طرح =================
function SchemeDetail({ id, canManage, onClose, onChanged }: { id: string; canManage: boolean; onClose: () => void; onChanged: () => void }) {
  const { toast } = useToast();
  const detail = useApi<{ scheme: SchemeRow & { levels: Record<string, number>; tiers: { key: string; label: string; paymentPercent: number; extraMonths: number }[] }; lines: LineRow[] }>(`/api/bonus/${id}`);
  const [recomputeOpen, setRecomputeOpen] = useState(false);

  if (detail.loading || !detail.data) return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent dir="rtl">
        {/* عنوان لازم برای دسترسی‌پذیری Radix (بدون آن TitleWarning کنسول خطا می‌دهد) */}
        <DialogHeader>
          <DialogTitle className="text-sm">در حال بارگذاری جزئیات طرح پاداش…</DialogTitle>
        </DialogHeader>
        <Skeleton className="h-64 rounded-xl" />
      </DialogContent>
    </Dialog>
  );
  const s = detail.data.scheme;
  const lines = detail.data.lines;
  const overBudget = s.budget > 0 && s.totalFinal > s.budget;
  const budgetUsage = s.budget > 0 ? Math.min(100, (s.totalFinal / s.budget) * 100) : 0;
  // سهم طبقات — محاسبه مستقیم (بدون hook تا بعد از early-return)
  const levelMap = new Map<number, { count: number; total: number }>();
  for (const l of lines) {
    const cur = levelMap.get(l.jobLevel) || { count: 0, total: 0 };
    cur.count++;
    cur.total += l.finalAmount;
    levelMap.set(l.jobLevel, cur);
  }
  const byLevel = Array.from(levelMap.entries()).sort((a, b) => b[0] - a[0]);

  function exportCsv() {
    const header = ["کد پرسنلی", "نام", "واحد", "طبقه", "حقوق پایه (تومان)", "ماه پاداش", "ماه حضور", "درصد پرداخت", "محاسبه‌شده (تومان)", "پرداخت نهایی (تومان)"];
    const rows = lines.map((l) => [
      l.personnelCode, l.employeeName, l.department, String(l.jobLevel),
      String(Math.round(l.baseSalary / 10)), String(l.bonusMonths), String(l.monthsPresent),
      String(l.paymentPercent), String(Math.round(l.computedAmount / 10)), String(Math.round(l.finalAmount / 10)),
    ]);
    const csv = "\uFEFF" + [header, ...rows].map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `bonus-${s.year}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async function recompute(patch: Record<string, unknown>) {
    try {
      await api(`/api/bonus/${id}`, { method: "PATCH", json: patch });
      await detail.refetch();
      onChanged();
      setRecomputeOpen(false);
      toast({ title: "طرح بازمحاسبه شد" });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[89.6rem] max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap text-base">
            <Gift className="w-5 h-5 text-teal-600" /> {s.title}
            <Badge className={TIER_BADGE[s.tier]}>{BONUS_TIER_LABELS[s.tier]}</Badge>
            <Badge variant="outline">{BONUS_SCHEME_STATUS_LABELS[s.status]}</Badge>
            {s.scaleToBudget && <Badge className="bg-slate-100 text-slate-600 hover:bg-slate-100">مقیاس‌بندی بودجه</Badge>}
          </DialogTitle>
        </DialogHeader>

        {/* کارت‌های خلاصه */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard label="تارگت" value={<Money amount={s.targetAmount} />} />
          <StatCard label="تحقق" value={<Money amount={s.actualAmount} />} sub={fmtPercent(Math.min(s.achievementRatio, 9.99), 1)} />
          <StatCard label="بودجه پاداش" value={<Money amount={s.budget} />} sub={overBudget ? `عبور: ${fmtPercent(budgetUsage)}` : `مصرف: ${fmtPercent(budgetUsage)}`} />
          <StatCard label="جمع پرداخت نهایی" value={<Money amount={s.totalFinal} />} sub={`${toFaDigits(lines.length)} نفر`} highlight />
        </div>

        {/* نوار بودجه */}
        {s.budget > 0 && (
          <div className="rounded-xl border p-3">
            <div className="flex justify-between text-[11px] mb-1.5">
              <span className="text-muted-foreground">مصرف بودجه</span>
              <span className="tabular-nums font-medium">{fmtPercent(budgetUsage)}</span>
            </div>
            <div className="h-2.5 rounded-full bg-slate-100 overflow-hidden">
              <div className={`h-full rounded-full ${overBudget ? "bg-rose-500" : "bg-teal-500"}`} style={{ width: `${Math.min(100, budgetUsage)}%` }} />
            </div>
            {overBudget && !s.scaleToBudget && (
              <p className="text-[11px] text-rose-600 mt-2">جمع پاداش از بودجه عبور کرده — «مقیاس‌بندی بودجه» فعال نیست؛ برای جا شدن در بودجه فعالش کنید.</p>
            )}
          </div>
        )}

        {/* سهم طبقات */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="rounded-xl">
            <CardHeader className="pb-2"><CardTitle className="text-xs">سهم هر طبقه</CardTitle></CardHeader>
            <CardContent className="space-y-1.5">
              {byLevel.map(([lv, v]) => (
                <div key={lv} className="flex items-center gap-2 text-xs">
                  <Badge variant="outline" className="w-16 justify-center">طبقه {toFaDigits(lv)}</Badge>
                  <span className="text-muted-foreground tabular-nums">{toFaDigits(v.count)} نفر</span>
                  <span className="mr-auto tabular-nums font-medium"><Money amount={v.total} /></span>
                </div>
              ))}
            </CardContent>
          </Card>
          <Card className="rounded-xl">
            <CardHeader className="pb-2"><CardTitle className="text-xs">قواعد اعمال‌شده (اسنپ‌شات)</CardTitle></CardHeader>
            <CardContent className="space-y-1.5">
              {s.tiers.map((t) => (
                <div key={t.key} className="flex items-center gap-2 text-xs">
                  <Badge className={`${TIER_BADGE[t.key]} ${t.key !== s.tier ? "opacity-40" : ""}`}>{BONUS_TIER_LABELS[t.key]}</Badge>
                  <span className="text-muted-foreground">پرداخت {fmtPercent(t.paymentPercent / 100)}</span>
                  {t.extraMonths > 0 && <Badge variant="outline" className="text-[10px]">+{toFaDigits(t.extraMonths)} ماه</Badge>}
                  {t.key === s.tier && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mr-auto" />}
                </div>
              ))}
              <p className="text-[10px] text-muted-foreground pt-1 border-t">ماه پاداش طبقات: {Object.entries(s.levels).map(([l, m]) => `${toFaDigits(l)}→${toFaDigits(m)}`).join("، ")}</p>
            </CardContent>
          </Card>
        </div>

        {/* جدول خطوط */}
        <div className="rounded-xl border overflow-hidden">
          <div className="flex items-center justify-between px-3 py-2 bg-slate-50 border-b">
            <p className="text-xs font-bold">پاداش به تفکیک هر نفر</p>
            <div className="flex gap-1.5">
              <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={exportCsv}><Printer className="w-3 h-3" /> خروجی CSV</Button>
              {canManage && s.status === "DRAFT" && (
                <>
                  <Button size="sm" variant="outline" className="h-7 gap-1 text-xs" onClick={() => setRecomputeOpen(true)}><RefreshCw className="w-3 h-3" /> ویرایش و بازمحاسبه</Button>
                  <Button size="sm" className="h-7 gap-1 text-xs bg-teal-600 hover:bg-teal-700" onClick={() => recompute({ status: "CONFIRMED" })}>تأیید نهایی</Button>
                </>
              )}
              {canManage && s.status === "CONFIRMED" && (
                <Button size="sm" className="h-7 gap-1 text-xs bg-emerald-600 hover:bg-emerald-700" onClick={() => recompute({ status: "PAID" })}><Banknote className="w-3 h-3" /> ثبت پرداخت</Button>
              )}
            </div>
          </div>
          <div className="max-h-80 overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-slate-50/60">
                  <TableHead className="text-right">کارمند</TableHead>
                  <TableHead className="text-right">واحد</TableHead>
                  <TableHead className="text-center">طبقه</TableHead>
                  <TableHead className="text-center">حقوق پایه</TableHead>
                  <TableHead className="text-center">ماه پاداش</TableHead>
                  <TableHead className="text-center">ماه حضور</TableHead>
                  <TableHead className="text-center">%</TableHead>
                  <TableHead className="text-center">پرداخت نهایی</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lines.map((l) => (
                  <TableRow key={l.id} className="hover:bg-teal-50/40">
                    <TableCell className="text-xs font-medium">
                      {l.employeeName}
                      <span className="block text-[10px] text-muted-foreground tabular-nums" dir="ltr">{l.personnelCode}</span>
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{l.department}</TableCell>
                    <TableCell className="text-center"><Badge variant="outline" className="text-[10px]">{toFaDigits(l.jobLevel)}</Badge></TableCell>
                    <TableCell className="text-xs tabular-nums text-center"><Money amount={l.baseSalary} /></TableCell>
                    <TableCell className="text-xs tabular-nums text-center">{toFaDigits(l.bonusMonths)}</TableCell>
                    <TableCell className="text-xs tabular-nums text-center">{toFaDigits(l.monthsPresent)}</TableCell>
                    <TableCell className="text-xs tabular-nums text-center">{fmtPercent(l.paymentPercent / 100)}</TableCell>
                    <TableCell className="text-xs tabular-nums text-center font-bold text-emerald-700"><Money amount={l.finalAmount} /></TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-teal-50/60 font-bold">
                  <TableCell colSpan={7} className="text-xs">جمع کل — {toFaDigits(lines.length)} نفر</TableCell>
                  <TableCell className="text-xs tabular-nums text-center text-teal-800"><Money amount={s.totalFinal} /></TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </div>

        {recomputeOpen && (
          <RecomputeDialog scheme={s} onClose={() => setRecomputeOpen(false)} onRecompute={recompute} />
        )}
      </DialogContent>
    </Dialog>
  );
}

function RecomputeDialog({ scheme, onClose, onRecompute }: { scheme: SchemeRow; onClose: () => void; onRecompute: (patch: Record<string, unknown>) => void }) {
  const [targetToman, setTargetToman] = useState(Math.round(scheme.targetAmount / 10));
  const [actualToman, setActualToman] = useState(Math.round(scheme.actualAmount / 10));
  const [budgetToman, setBudgetToman] = useState(Math.round(scheme.budget / 10));
  const [tierMode, setTierMode] = useState(scheme.tierMode);
  const [manualTier, setManualTier] = useState(scheme.manualTier || scheme.tier);
  const [scaleToBudget, setScaleToBudget] = useState(scheme.scaleToBudget);

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-[44.8rem]" dir="rtl">
        <DialogHeader><DialogTitle className="text-sm">ویرایش و بازمحاسبه طرح</DialogTitle></DialogHeader>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs">تارگت — تومان</Label>
            <MoneyInput value={targetToman} onChange={setTargetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">تحقق — تومان</Label>
            <MoneyInput value={actualToman} onChange={setActualToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">بودجه — تومان</Label>
            <MoneyInput value={budgetToman} onChange={setBudgetToman} />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs">حالت تیر</Label>
            <NativeSelect value={tierMode} onChange={setTierMode} ariaLabel="حالت تیر">
              <option value="AUTO">خودکار از تحقق</option>
              <option value="MANUAL">دستی</option>
            </NativeSelect>
          </div>
          {tierMode === "MANUAL" && (
            <div className="space-y-1.5">
              <Label className="text-xs">وضعیت</Label>
              <NativeSelect value={manualTier} onChange={setManualTier} ariaLabel="وضعیت">
                {Object.entries(BONUS_TIER_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </NativeSelect>
            </div>
          )}
          <div className="flex items-center gap-2 sm:col-span-2 rounded-xl border p-3">
            <Checkbox id="scale2" checked={scaleToBudget} onCheckedChange={(v) => setScaleToBudget(!!v)} />
            <label htmlFor="scale2" className="text-xs cursor-pointer">مقیاس‌بندی خطی برای جا شدن در بودجه</label>
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onClose}>انصراف</Button>
          <Button
            className="bg-teal-600 hover:bg-teal-700 gap-1.5"
            onClick={() => onRecompute({
              targetAmount: Math.round(targetToman * 10),
              actualAmount: Math.round(actualToman * 10),
              budget: Math.round(budgetToman * 10),
              tierMode,
              manualTier,
              scaleToBudget,
            })}
          >
            <RefreshCw className="w-4 h-4" /> بازمحاسبه
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function StatCard({ label, value, sub, highlight }: { label: string; value: React.ReactNode; sub?: string; highlight?: boolean }) {
  return (
    <div className={`rounded-xl border p-3 ${highlight ? "bg-teal-50/60 border-teal-200" : "bg-white"}`}>
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className={`text-sm font-bold mt-1 tabular-nums ${highlight ? "text-teal-800" : ""}`}>{value}</p>
      {sub && <p className="text-[10px] text-muted-foreground mt-0.5 tabular-nums">{sub}</p>}
    </div>
  );
}

"use client";

// ============================================================
// سلکت بومی RTL — جایگزین مطمئن Radix Select در فرم‌های دیالوگی
// ریشه‌کار باگ RTL رادیکس (پرش فوکوس به کنترل بعدی پس از انتخاب)
// ============================================================
import { ChevronDown } from "lucide-react";

export function NativeSelect({
  value,
  onChange,
  placeholder,
  children,
  className = "",
  disabled,
  ariaLabel,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
  ariaLabel?: string;
}) {
  return (
    <div className={`relative ${className}`}>
      <select
        aria-label={ariaLabel}
        dir="rtl"
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        className="w-full h-9 rounded-md border border-input bg-transparent px-3 pl-8 text-sm whitespace-nowrap shadow-xs outline-none transition-[color,box-shadow] focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 appearance-none cursor-pointer"
        style={{ fontFamily: "inherit" }}
      >
        {placeholder !== undefined && <option value="">{placeholder}</option>}
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 opacity-50" />
    </div>
  );
}

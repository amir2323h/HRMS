import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { getBranding } from "@/lib/settings";

// عنوان و آیکون صفحه از تنظیمات برندینگ خوانده می‌شوند (قابل تغییر توسط مدیر کل)
export async function generateMetadata(): Promise<Metadata> {
  let title = "سامانه جامع منابع انسانی و حقوق و دستمزد | ۱۴۰۵";
  let icon: string | undefined;
  try {
    const branding = await getBranding();
    if (branding.title) title = `${branding.title} | ۱۴۰۵`;
    if (branding.favicon) icon = branding.favicon;
  } catch {
    /* مقادیر پیش‌فرض */
  }
  return {
    title,
    description:
      "سامانه یکپارچه مدیریت منابع انسانی، طبقه‌بندی مشاغل، لیست حقوق، محاسبه معکوس حقوق، صدور قرارداد و گزارش‌های قانونی مطابق مقررات ۱۴۰۵",
    keywords: ["منابع انسانی", "حقوق و دستمزد", "محاسبه معکوس حقوق", "بیمه تأمین اجتماعی", "مالیات حقوق ۱۴۰۵", "صدور قرارداد", "HRMS"],
    ...(icon ? { icons: { icon } } : {}),
  };
}

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#0f766e",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-background text-foreground font-sans">
        {children}
        <Toaster />
      </body>
    </html>
  );
}

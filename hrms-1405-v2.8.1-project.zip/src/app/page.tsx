import { AuthGate } from "@/components/app/auth-gate";

// رندر سمت کلاینت — نشست از /api/auth/me خوانده می‌شود که هم کوکی و هم
// توکن Bearer را می‌پذیرد (سازگار با iframe پیش‌نمایش که کوکی‌های SameSite را مسدود می‌کند)
export default function Home() {
  return <AuthGate />;
}

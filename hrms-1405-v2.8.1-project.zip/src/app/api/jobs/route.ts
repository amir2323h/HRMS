import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// عناوین شغلی — تعریف در تنظیمات و انتخاب در فرم کارمند
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "employees:view");
    const jobs = await db.jobTitle.findMany({
      include: { jobGrade: true, _count: { select: { employees: true } } },
      orderBy: [{ isActive: "desc" }, { code: "asc" }],
    });
    return {
      jobs: jobs.map((j) => ({
        id: j.id,
        code: j.code,
        title: j.title,
        jobGradeId: j.jobGradeId || null,
        gradeLevel: j.jobGrade?.level ?? null,
        gradeTitle: j.jobGrade?.title || "",
        description: j.description,
        isActive: j.isActive,
        employeeCount: j._count.employees,
      })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "jobs:manage");
    const b = await req.json();

    const title = String(b.title || "").trim();
    if (!title) return Response.json({ error: "عنوان شغل الزامی است." }, { status: 400 });

    // اعتبارسنجی طبقه شغلی
    let jobGradeId: string | null = null;
    if (b.jobGradeId) {
      const grade = await db.jobGrade.findUnique({ where: { id: b.jobGradeId } });
      if (!grade) return Response.json({ error: "طبقه شغلی یافت نشد." }, { status: 400 });
      jobGradeId = grade.id;
    }

    // کد: دستی یا سیستمی JOB-###
    let code = String(b.code || "").trim();
    if (code) {
      const dup = await db.jobTitle.findUnique({ where: { code } });
      if (dup) return Response.json({ error: `کد «${code}» قبلاً ثبت شده است.` }, { status: 400 });
    } else {
      const count = await db.jobTitle.count();
      for (let i = 1; ; i++) {
        const candidate = `JOB-${String(count + i).padStart(3, "0")}`;
        const clash = await db.jobTitle.findUnique({ where: { code: candidate } });
        if (!clash) { code = candidate; break; }
      }
    }

    const job = await db.jobTitle.create({
      data: {
        code,
        title,
        jobGradeId,
        description: String(b.description || "").trim(),
        isActive: b.isActive === false ? false : true,
      },
    });
    await audit(session, "CREATE", "JOB_TITLE", job.id, `تعریف عنوان شغلی «${title}» (${code})`, null, { title, code });
    return { job: { ...job, employeeCount: 0 } };
  });
}

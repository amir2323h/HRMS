import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// ویرایش/حذف عنوان شغلی
// ============================================================

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "jobs:manage");
    const { id } = await ctx.params;
    const before = await db.jobTitle.findUnique({ where: { id }, include: { jobGrade: true } });
    if (!before) return Response.json({ error: "عنوان شغلی یافت نشد." }, { status: 404 });

    const b = await req.json();
    const data: Record<string, unknown> = {};

    if (b.title !== undefined) {
      const title = String(b.title).trim();
      if (!title) return Response.json({ error: "عنوان شغل الزامی است." }, { status: 400 });
      data.title = title;
    }
    if (b.code !== undefined) {
      const code = String(b.code).trim();
      if (!code) return Response.json({ error: "کد نمی‌تواند خالی باشد." }, { status: 400 });
      const dup = await db.jobTitle.findFirst({ where: { code, id: { not: id } } });
      if (dup) return Response.json({ error: `کد «${code}» قبلاً ثبت شده است.` }, { status: 400 });
      data.code = code;
    }
    if (b.jobGradeId !== undefined) {
      if (b.jobGradeId) {
        const grade = await db.jobGrade.findUnique({ where: { id: b.jobGradeId } });
        if (!grade) return Response.json({ error: "طبقه شغلی یافت نشد." }, { status: 400 });
        data.jobGradeId = grade.id;
      } else {
        data.jobGradeId = null;
      }
    }
    if (b.description !== undefined) data.description = String(b.description).trim();
    if (b.isActive !== undefined) data.isActive = !!b.isActive;

    await db.jobTitle.update({ where: { id }, data });

    // همگام‌سازی اسنپ‌شات عنوان در پرونده کارکنانِ این شغل
    if (data.title !== undefined && data.title !== before.title) {
      await db.employee.updateMany({ where: { jobTitleId: id }, data: { jobTitle: String(data.title) } });
    }

    const after = await db.jobTitle.findUnique({ where: { id } });
    await audit(session, "UPDATE", "JOB_TITLE", id, `ویرایش عنوان شغلی «${before.title}»`, { title: before.title, code: before.code, isActive: before.isActive }, { title: after?.title, code: after?.code, isActive: after?.isActive });
    return { job: after };
  });
}

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "jobs:manage");
    const { id } = await ctx.params;
    const job = await db.jobTitle.findUnique({ where: { id }, include: { _count: { select: { employees: true } } } });
    if (!job) return Response.json({ error: "عنوان شغلی یافت نشد." }, { status: 404 });

    // استاندارد حذف: عنوان دارای کارمند فعال قابل حذف نیست — غیرفعالسازی کنید
    if (job._count.employees > 0) {
      return Response.json(
        { error: `این عنوان به ${job._count.employees} کارمند اختصاص دارد و قابل حذف نیست — آن را غیرفعال کنید.` },
        { status: 400 }
      );
    }

    await db.jobTitle.delete({ where: { id } });
    await audit(session, "DELETE", "JOB_TITLE", id, `حذف عنوان شغلی «${job.title}» (${job.code})`);
    return { ok: true };
  });
}

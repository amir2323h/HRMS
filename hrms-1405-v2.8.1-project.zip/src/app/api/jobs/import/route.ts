import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// ایمپورت گروهی عناوین شغلی از اکسل
// ردیف‌ها از سمت کلاینت پارس و اعتبارسنجی شده‌اند
// منطق: upsert بر اساس کد (و در نبود کد، عنوان)
// ============================================================

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "jobs:manage");
    const body = await req.json();
    const rows: { title: string; code: string; gradeLevel: number | null; description: string; isActive: boolean }[] = body?.rows || [];

    if (!Array.isArray(rows) || rows.length === 0) {
      return Response.json({ error: "ردیفی برای ایمپورت ارسال نشده است." }, { status: 400 });
    }
    if (rows.length > 1000) {
      return Response.json({ error: "حداکثر ۱۰۰۰ ردیف در هر نوبت." }, { status: 400 });
    }

    // نقشه سطح → id طبقه
    const grades = await db.jobGrade.findMany();
    const gradeByLevel = new Map(grades.map((g) => [g.level, g.id]));

    let created = 0;
    let updated = 0;
    let failed = 0;
    const errors: string[] = [];

    // شمارنده کد سیستمی
    const count = await db.jobTitle.count();

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      try {
        const title = String(r.title || "").trim();
        if (!title) {
          failed++;
          errors.push(`ردیف ${i + 1}: عنوان شغل خالی است.`);
          continue;
        }
        const gradeLevel = r.gradeLevel ? Number(r.gradeLevel) : null;
        if (gradeLevel !== null && !gradeByLevel.has(gradeLevel)) {
          failed++;
          errors.push(`ردیف ${i + 1}: سطح ${gradeLevel} در طبقه‌بندی ۷گانه وجود ندارد.`);
          continue;
        }
        const jobGradeId = gradeLevel !== null ? gradeByLevel.get(gradeLevel) || null : null;

        let code = String(r.code || "").trim();
        // یافتن رکورد موجود: اولویت کد، سپس عنوان
        let existing = code ? await db.jobTitle.findUnique({ where: { code } }) : null;
        if (!existing) {
          existing = await db.jobTitle.findFirst({ where: { title } });
        }

        if (existing) {
          await db.jobTitle.update({
            where: { id: existing.id },
            data: {
              title,
              jobGradeId,
              description: String(r.description || "").trim(),
              isActive: r.isActive !== false,
            },
          });
          // همگام‌سازی اسنپ‌شات عنوان کارکنان این شغل
          if (title !== existing.title) {
            await db.employee.updateMany({ where: { jobTitleId: existing.id }, data: { jobTitle: title } });
          }
          updated++;
        } else {
          // کد یکتا در صورت خالی بودن
          if (!code) {
            for (let k = 1; ; k++) {
              const candidate = `JOB-${String(count + created + k).padStart(3, "0")}`;
              const clash = await db.jobTitle.findUnique({ where: { code: candidate } });
              if (!clash) { code = candidate; break; }
            }
          } else {
            const dupCode = await db.jobTitle.findUnique({ where: { code } });
            if (dupCode) {
              failed++;
              errors.push(`ردیف ${i + 1}: کد «${code}» به عنوان شغل دیگری («${dupCode.title}») اختصاص دارد.`);
              continue;
            }
          }
          await db.jobTitle.create({
            data: {
              code,
              title,
              jobGradeId,
              description: String(r.description || "").trim(),
              isActive: r.isActive !== false,
            },
          });
          created++;
        }
      } catch (e) {
        failed++;
        errors.push(`ردیف ${i + 1}: ${e instanceof Error ? e.message : "خطای ناشناخته"}`);
      }
    }

    await audit(session, "CREATE", "JOB_TITLE", "import", `ایمپورت اکسل عناوین شغلی — ${created} جدید، ${updated} به‌روزرسانی، ${failed} ناموفق`);
    return { created, updated, failed, errors };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { getCompanyInfo } from "@/lib/settings";
import { buildVariables, renderTemplate, extractPlaceholders } from "@/lib/contracts";
import { todayJalaliStr } from "@/lib/jalali";

/** پیش‌نمایش رندر قرارداد بدون ذخیره — برای بازبینی قبل از صدور */
export async function POST(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "contracts:manage");
    const b = await req.json();
    const templateId = String(b.templateId || "");
    const employeeId = String(b.employeeId || "");

    const template = await db.contractTemplate.findUnique({ where: { id: templateId } });
    if (!template) return Response.json({ error: "قالب قرارداد یافت نشد." }, { status: 400 });
    const employee = await db.employee.findUnique({ where: { id: employeeId }, include: { jobGrade: true, insuranceDependents: true } });
    if (!employee) return Response.json({ error: "کارمند یافت نشد." }, { status: 400 });

    const issueDateJ = String(b.issueDateJ || todayJalaliStr());
    const startDateJ = String(b.startDateJ || employee.contractStartJ || "");
    const endDateJ = String(b.endDateJ || "");
    const company = await getCompanyInfo();

    const vars = buildVariables({
      employee: { ...employee, baseSalary: employee.baseSalary },
      company,
      contractNumber: "(پیش‌نمایش)",
      issueDateJ,
      startDateJ,
      endDateJ,
    });
    const allowed = new Set(extractPlaceholders(template.body));
    if (b.variables && typeof b.variables === "object") {
      for (const [k, v] of Object.entries(b.variables as Record<string, unknown>)) {
        if (allowed.has(k)) vars[k] = String(v ?? "");
      }
    }

    const body = renderTemplate(template.body, vars);
    return {
      preview: body,
      placeholders: extractPlaceholders(template.body),
      variables: vars,
    };
  });
}

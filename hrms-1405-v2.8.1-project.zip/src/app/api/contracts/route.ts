import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeContract } from "@/lib/serializers";
import { getCompanyInfo } from "@/lib/settings";
import { buildVariables, renderTemplate, nextContractNumber, extractPlaceholders } from "@/lib/contracts";
import { todayJalaliStr, isValidJalali } from "@/lib/jalali";

/** لیست قراردادهای صادرشده */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "contracts:view");
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() || "";
    const status = searchParams.get("status") || "";
    const employeeId = searchParams.get("employeeId") || "";

    const contracts = await db.contract.findMany({
      where: {
        AND: [
          q
            ? {
                OR: [
                  { contractNumber: { contains: q } },
                  { employeeName: { contains: q } },
                  { title: { contains: q } },
                ],
              }
            : {},
          status ? { status } : {},
          employeeId ? { employeeId } : {},
        ],
      },
      include: { employee: { select: { firstName: true, lastName: true } } },
      orderBy: { createdAt: "desc" },
    });
    return { contracts: contracts.map((c) => serializeContract(c as never)) };
  });
}

/** صدور قرارداد از قالب — شماره سیستمی خودکار + اسنپ‌شات متن رندرشده */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "contracts:manage");
    const b = await req.json();
    const templateId = String(b.templateId || "");
    const employeeId = String(b.employeeId || "");

    const template = await db.contractTemplate.findUnique({ where: { id: templateId } });
    if (!template) return Response.json({ error: "قالب قرارداد یافت نشد." }, { status: 400 });
    if (!template.isActive) return Response.json({ error: "این قالب غیرفعال است." }, { status: 400 });

    const employee = await db.employee.findUnique({ where: { id: employeeId }, include: { jobGrade: true, insuranceDependents: true } });
    if (!employee) return Response.json({ error: "کارمند یافت نشد." }, { status: 400 });

    // تاریخ‌ها
    const issueDateJ = String(b.issueDateJ || todayJalaliStr());
    const startDateJ = String(b.startDateJ || employee.contractStartJ || "");
    const endDateJ = String(b.endDateJ || "");
    for (const [f, v] of Object.entries({ issueDateJ, startDateJ, endDateJ })) {
      if (v && !isValidJalali(v)) return Response.json({ error: `قالب تاریخ ${f} نامعتبر است.` }, { status: 400 });
    }

    const company = await getCompanyInfo();
    const contractNumber = await nextContractNumber();

    // ساخت متغیرها + بازنویسی دستی کاربر (متغیرهای سفارشی)
    const vars = buildVariables({
      employee: {
        ...employee,
        baseSalary: employee.baseSalary,
      },
      company,
      contractNumber,
      issueDateJ,
      startDateJ,
      endDateJ,
    });
    // متغیرهای اضافی که کاربر در فرم وارد کرده (فقط نام‌های معتبر قالب)
    const allowed = new Set(extractPlaceholders(template.body));
    if (b.variables && typeof b.variables === "object") {
      for (const [k, v] of Object.entries(b.variables as Record<string, unknown>)) {
        if (allowed.has(k)) vars[k] = String(v ?? "");
      }
    }

    const body = renderTemplate(template.body, vars);
    const title = String(b.title || "").trim() || `${template.title} — ${employee.firstName} ${employee.lastName}`;

    const contract = await db.contract.create({
      data: {
        contractNumber,
        templateId: template.id,
        templateTitle: template.title,
        templateVersion: template.version,
        employeeId: employee.id,
        employeeName: `${employee.firstName} ${employee.lastName}`,
        personnelCode: employee.personnelCode,
        title,
        body,
        contractType: template.contractType,
        status: "ISSUED",
        issueDateJ,
        startDateJ,
        endDateJ,
        variablesJson: JSON.stringify(vars),
        createdBy: session.fullName,
      },
      include: { employee: { select: { firstName: true, lastName: true } } },
    });

    await audit(
      session,
      "CREATE",
      "CONTRACT",
      contract.id,
      `صدور قرارداد ${contractNumber} برای ${contract.employeeName} از قالب «${template.title}» (نسخه ${template.version})`,
      null,
      { contractNumber, template: template.title, templateVersion: template.version, employee: contract.employeeName, status: "ISSUED" }
    );

    return { contract: serializeContract(contract as never) };
  });
}

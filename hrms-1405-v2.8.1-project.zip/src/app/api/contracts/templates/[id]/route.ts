import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeContractTemplate } from "@/lib/serializers";

/** جزئیات یک قالب */
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(req, "contracts:view");
    const { id } = await ctx.params;
    const template = await db.contractTemplate.findUnique({ where: { id } });
    if (!template) return Response.json({ error: "قالب یافت نشد." }, { status: 404 });
    const issued = await db.contract.count({ where: { templateId: id } });
    return { template: serializeContractTemplate(template as never, issued) };
  });
}

/** ویرایش قالب — نسخه قالب یک واحد افزایش می‌یابد (نسخه‌بندی استاندارد) */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "contracts:manage");
    const { id } = await ctx.params;
    const before = await db.contractTemplate.findUnique({ where: { id } });
    if (!before) return Response.json({ error: "قالب یافت نشد." }, { status: 404 });

    const b = await req.json();
    const data: Record<string, unknown> = {};
    if (b.title !== undefined) {
      const t = String(b.title).trim();
      if (!t) return Response.json({ error: "عنوان قالب الزامی است." }, { status: 400 });
      data.title = t;
    }
    if (b.body !== undefined) {
      const body = String(b.body);
      if (body.trim().length < 20) return Response.json({ error: "متن قالب بسیار کوتاه است." }, { status: 400 });
      if (body.length > 60000) return Response.json({ error: "متن قالب حداکثر ۶۰ هزار نویسه است." }, { status: 400 });
      data.body = body;
    }
    if (b.contractType !== undefined && ["EMPLOYMENT", "FIXED", "PROBATION", "TEMPORARY", "INTERN", "NDA", "OTHER"].includes(b.contractType)) data.contractType = b.contractType;
    if (b.notes !== undefined) data.notes = String(b.notes);
    if (b.isActive !== undefined) data.isActive = !!b.isActive;

    // تغییر متن یا عنوان → نسخه جدید
    const contentChanged = (data.body !== undefined && data.body !== before.body) || (data.title !== undefined && data.title !== before.title);
    if (contentChanged) data.version = before.version + 1;

    const template = await db.contractTemplate.update({ where: { id }, data });
    await audit(
      session,
      "UPDATE",
      "CONTRACT_TEMPLATE",
      id,
      `ویرایش قالب قرارداد «${template.title}»${contentChanged ? ` — نسخه ${template.version}` : ""}`,
      { title: before.title, version: before.version },
      { title: template.title, version: template.version }
    );
    const issued = await db.contract.count({ where: { templateId: id } });
    return { template: serializeContractTemplate(template as never, issued) };
  });
}

/** حذف قالب — فقط وقتی قراردادی از آن صادر نشده */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "contracts:manage");
    const { id } = await ctx.params;
    const template = await db.contractTemplate.findUnique({ where: { id } });
    if (!template) return Response.json({ error: "قالب یافت نشد." }, { status: 404 });
    const issued = await db.contract.count({ where: { templateId: id } });
    if (issued > 0) {
      return Response.json({ error: `این قالب برای ${issued} قرارداد صادرشده استفاده شده و قابل حذف نیست — آن را غیرفعال کنید.` }, { status: 400 });
    }
    await db.contractTemplate.delete({ where: { id } });
    await audit(session, "DELETE", "CONTRACT_TEMPLATE", id, `حذف قالب قرارداد «${template.title}»`);
    return { ok: true };
  });
}

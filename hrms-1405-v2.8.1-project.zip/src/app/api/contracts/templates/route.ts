import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeContractTemplate } from "@/lib/serializers";

/** لیست قالب‌های قرارداد */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "contracts:view");
    const templates = await db.contractTemplate.findMany({ orderBy: { createdAt: "desc" } });
    const counts = await db.contract.groupBy({ by: ["templateId"], _count: { id: true } });
    const countMap: Record<string, number> = {};
    for (const c of counts) if (c.templateId) countMap[c.templateId] = c._count.id;
    return {
      templates: templates.map((t) => serializeContractTemplate(t as never, countMap[t.id] || 0)),
    };
  });
}

/** ایجاد قالب جدید */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "contracts:manage");
    const b = await req.json();
    const title = String(b.title || "").trim();
    const body = String(b.body || "");
    const contractType = ["EMPLOYMENT", "FIXED", "PROBATION", "TEMPORARY", "INTERN", "NDA", "OTHER"].includes(b.contractType) ? b.contractType : "EMPLOYMENT";
    if (!title) return Response.json({ error: "عنوان قالب الزامی است." }, { status: 400 });
    if (body.trim().length < 20) return Response.json({ error: "متن قالب بسیار کوتاه است (حداقل ۲۰ نویسه)." }, { status: 400 });
    if (body.length > 60000) return Response.json({ error: "متن قالب حداکثر ۶۰ هزار نویسه است." }, { status: 400 });

    const template = await db.contractTemplate.create({
      data: {
        title,
        contractType,
        body,
        notes: String(b.notes || ""),
        isActive: b.isActive === false ? false : true,
        version: 1,
        createdBy: session.fullName,
      },
    });
    await audit(session, "CREATE", "CONTRACT_TEMPLATE", template.id, `ایجاد قالب قرارداد «${title}»`, null, { title, contractType, version: 1 });
    return { template: serializeContractTemplate(template as never, 0) };
  });
}

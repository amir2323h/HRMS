import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getCompanyInfo, getLegalParams } from "@/lib/settings";
import { periodTitle } from "@/lib/jalali";

/**
 * خروجی دیسکت بیمه (لیست بیمه ماهانه) — ساختار رکوردهای عرض‌ثابت
 * مشابه نسخه دیسکت سازمان تأمین اجتماعی:
 *   رکورد ۱ (سرآیند) + رکوردهای ۲ (به ازای هر بیمه‌شده) + رکورد ۳ (پایانی)
 * همه مبالغ: ریال
 */
function pad(value: string | number, len: number, padChar = "0", align: "right" | "left" = "right"): string {
  const s = String(value);
  if (align === "right") return s.padStart(len, padChar);
  return s.padEnd(len, padChar);
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "reports:view");
    const { searchParams } = new URL(req.url);
    const periodId = searchParams.get("periodId");
    if (!periodId) return Response.json({ error: "انتخاب دوره الزامی است." }, { status: 400 });

    const period = await db.payrollPeriod.findUnique({
      where: { id: periodId },
      include: { payslips: { include: { employee: true }, orderBy: { employeeId: "asc" } } },
    });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });

    const [company, legal] = await Promise.all([getCompanyInfo(), getLegalParams()]);
    const ssoCode = company.ssoCode.replace(/-/g, "");
    const branch = ssoCode.slice(0, 6) || "000000";
    const workshop = ssoCode.slice(6).padStart(10, "0");

    const rows: string[] = [];
    // ---- رکورد سرآیند ----
    const recordCount = period.payslips.length;
    const totalInsurable = period.payslips.reduce((a, p) => a + Number(p.insurableBase), 0);
    const totalEmpSso = period.payslips.reduce((a, p) => a + Number(p.employeeSso), 0);
    const totalErSso = period.payslips.reduce((a, p) => a + Number(p.employerSso20) + Number(p.unemploymentSso3), 0);
    rows.push(
      ["1", pad(branch, 6), pad(workshop, 10), pad(period.year, 2), pad(period.month, 2),
       pad(recordCount, 4), pad(totalInsurable, 15), pad(totalEmpSso, 15), pad(totalErSso, 15)].join("")
    );

    // ---- رکوردهای بیمه‌شده ----
    let idx = 0;
    for (const p of period.payslips) {
      idx += 1;
      const e = p.employee;
      rows.push(
        ["2",
         pad(idx, 4),                                        // ردیف
         pad(e.ssoNumber || "0000000000", 10),               // شماره بیمه
         pad(e.nationalId || "0000000000", 10),              // کد ملی
         pad(30, 2),                                          // روز کارکرد
         pad(p.insurableBase, 15),                            // مجموع حقوق و مزایای مشمول (مشخصه 9020)
         pad(p.employeeSso, 13),                              // حق بیمه ۷٪ سهم بیمه‌شده
         pad(p.employerSso20, 13),                            // حق بیمه ۲۰٪ سهم کارفرما
         pad(p.unemploymentSso3, 13),                         // بیمه بیکاری ۳٪
         "0".repeat(13),                                      // بدون تغییر وضعیت
        ].join("")
      );
    }

    // ---- رکورد پایانی ----
    rows.push(
      ["3", pad(recordCount, 4), pad(totalInsurable, 15), pad(totalEmpSso, 15), pad(totalErSso, 15)].join("")
    );

    const content = rows.join("\r\n") + "\r\n";
    const fileName = `SSO-List-${period.year}-${String(period.month).padStart(2, "0")}.txt`;

    await audit(session, "EXPORT", "SSO", periodId, `دریافت دیسکت بیمه — دوره ${periodTitle(period.year, period.month)} (${recordCount} رکورد)`);

    return new Response(content, {
      headers: {
        "Content-Type": "text/plain; charset=windows-1256",
        "Content-Disposition": `attachment; filename="${fileName}"`,
      },
    });
  });
}

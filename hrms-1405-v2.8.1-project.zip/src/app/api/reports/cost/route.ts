import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { periodTitle } from "@/lib/jalali";

/** گزارش تخصیص هزینه نیروی کار به تفکیک دپارتمان/مرکز هزینه */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "reports:view");
    const { searchParams } = new URL(req.url);
    const periodId = searchParams.get("periodId");
    if (!periodId) return Response.json({ error: "انتخاب دوره الزامی است." }, { status: 400 });

    const period = await db.payrollPeriod.findUnique({ where: { id: periodId } });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });

    const departments = await db.department.findMany({ orderBy: { code: "asc" } });
    const links = await db.employeeDepartment.findMany({ include: { department: true } });
    const deptById: Record<string, { id: string; name: string; code: string; costCenterCode: string; parentId: string | null }> = {};
    for (const d of departments) deptById[d.id] = { id: d.id, name: d.name, code: d.code, costCenterCode: d.costCenterCode, parentId: d.parentId };
    const empToDept: Record<string, string> = {};
    for (const l of links) empToDept[l.employeeId] = l.departmentId;

    const payslips = await db.payslip.findMany({ where: { periodId }, include: { employee: true } });

    // تجمیع به تفکیک دپارتمان
    const agg: Record<string, {
      departmentId: string; name: string; code: string; costCenterCode: string; parentId: string | null;
      headcount: number; gross: number; baseSalary: number; housing: number; grocery: number; childAllowance: number;
      seniority: number; attraction: number; overtimeAmount: number; employeeSso: number; employerSso: number;
      incomeTax: number; netPay: number; totalCost: number;
    }> = {};
    for (const d of departments) {
      agg[d.id] = {
        departmentId: d.id, name: d.name, code: d.code, costCenterCode: d.costCenterCode, parentId: d.parentId,
        headcount: 0, gross: 0, baseSalary: 0, housing: 0, grocery: 0, childAllowance: 0,
        seniority: 0, attraction: 0, overtimeAmount: 0, employeeSso: 0, employerSso: 0, incomeTax: 0, netPay: 0, totalCost: 0,
      };
    }
    for (const p of payslips) {
      const deptId = empToDept[p.employeeId];
      if (!deptId || !agg[deptId]) continue;
      const a = agg[deptId];
      a.headcount += 1;
      a.gross += Number(p.gross);
      a.baseSalary += Number(p.baseSalary);
      a.housing += Number(p.housing);
      a.grocery += Number(p.grocery);
      a.childAllowance += Number(p.childAllowance);
      a.seniority += Number(p.seniority);
      a.attraction += Number(p.attraction);
      a.overtimeAmount += Number(p.overtimeAmount);
      a.employeeSso += Number(p.employeeSso);
      a.employerSso += Number(p.employerSso20) + Number(p.unemploymentSso3);
      a.incomeTax += Number(p.incomeTax);
      a.netPay += Number(p.netPay);
      a.totalCost += Number(p.gross) + Number(p.employerSso20) + Number(p.unemploymentSso3);
    }

    await audit(session, "EXPORT", "COST_REPORT", periodId, `مشاهده گزارش هزینه مراکز — دوره ${periodTitle(period.year, period.month)}`);

    return {
      period: { id: period.id, year: period.year, month: period.month, status: period.status },
      rows: Object.values(agg).sort((a, b) => b.totalCost - a.totalCost),
      totals: {
        headcount: payslips.length,
        gross: payslips.reduce((a, p) => a + Number(p.gross), 0),
        baseSalary: payslips.reduce((a, p) => a + Number(p.baseSalary), 0),
        housing: payslips.reduce((a, p) => a + Number(p.housing), 0),
        grocery: payslips.reduce((a, p) => a + Number(p.grocery), 0),
        childAllowance: payslips.reduce((a, p) => a + Number(p.childAllowance), 0),
        seniority: payslips.reduce((a, p) => a + Number(p.seniority), 0),
        attraction: payslips.reduce((a, p) => a + Number(p.attraction), 0),
        overtimeAmount: payslips.reduce((a, p) => a + Number(p.overtimeAmount), 0),
        employeeSso: payslips.reduce((a, p) => a + Number(p.employeeSso), 0),
        employerSso: payslips.reduce((a, p) => a + Number(p.employerSso20) + Number(p.unemploymentSso3), 0),
        incomeTax: payslips.reduce((a, p) => a + Number(p.incomeTax), 0),
        netPay: payslips.reduce((a, p) => a + Number(p.netPay), 0),
        totalCost: payslips.reduce((a, p) => a + Number(p.gross) + Number(p.employerSso20) + Number(p.unemploymentSso3), 0),
      },
    };
  });
}

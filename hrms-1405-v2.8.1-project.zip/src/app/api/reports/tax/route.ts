import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getCompanyInfo } from "@/lib/settings";
import { periodTitle } from "@/lib/jalali";

/** خروجی فایل مالیاتی (سازمان امور مالیاتی) — CSV با BOM برای سازگاری اکسل فارسی */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "reports:view");
    const { searchParams } = new URL(req.url);
    const periodId = searchParams.get("periodId");
    if (!periodId) return Response.json({ error: "انتخاب دوره الزامی است." }, { status: 400 });

    const period = await db.payrollPeriod.findUnique({
      where: { id: periodId },
      include: { payslips: { include: { employee: true }, orderBy: { employeeId: "asc" } } },
    });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });
    const company = await getCompanyInfo();

    const header = "ردیف,کد ملی,نام,نام خانوادگی,شماره پرسنلی,درآمد مشمول مالیات (ریال),مالیات حقوق (ریال),جمع حقوق و مزایا (ریال),خالص پرداختی (ریال)";
    const lines = [header];
    let idx = 0;
    let totalTaxable = 0;
    let totalTax = 0;
    period.payslips.forEach((p) => {
      idx += 1;
      totalTaxable += Number(p.taxableIncome);
      totalTax += Number(p.incomeTax);
      lines.push(
        [
          idx,
          p.employee.nationalId || "-",
          p.employee.firstName,
          p.employee.lastName,
          p.employee.personnelCode,
          Number(p.taxableIncome),
          Number(p.incomeTax),
          Number(p.gross),
          Number(p.netPay),
        ].join(",")
      );
    });
    lines.push(`,شناسه کارفرما: ${company.taxId},,,,جمع کل,${totalTaxable},${totalTax},,`);

    const content = "\uFEFF" + lines.join("\r\n") + "\r\n"; // BOM
    const fileName = `Tax-${period.year}-${String(period.month).padStart(2, "0")}.csv`;
    await audit(session, "EXPORT", "TAX", periodId, `دریافت فایل مالیاتی — دوره ${periodTitle(period.year, period.month)} (${idx} رکورد، جمع مالیات ${totalTax.toLocaleString("en-US")} ریال)`);

    return new Response(content, {
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${fileName}"`,
      },
    });
  });
}

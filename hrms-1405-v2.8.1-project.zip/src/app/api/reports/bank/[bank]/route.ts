import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getCompanyInfo } from "@/lib/settings";
import { periodTitle } from "@/lib/jalali";

/**
 * فایل پرداخت بانکی — ۴ بانک: پارسیان، سامان، ملت، تجارت
 * فرمت‌ها (نمونه رایج):
 *   پارسیان / تجارت → CSV (شبا، مبلغ، شناسه، نام)
 *   سامان / ملت     → متن عرض‌ثابت (شبا 26 + مبلغ 15 + شناسه 10 + نام 40)
 * همه مبالغ: ریال
 */
const BANKS: Record<string, { title: string; format: "CSV" | "FIXED"; ext: string }> = {
  pasargad: { title: "بانک پارسیان", format: "CSV", ext: "csv" },
  saman: { title: "بانک سامان", format: "FIXED", ext: "txt" },
  mellat: { title: "بانک ملت", format: "FIXED", ext: "txt" },
  tejarat: { title: "بانک تجارت", format: "CSV", ext: "csv" },
};

function pad(s: string | number, len: number, char = "0", align: "right" | "left" = "right") {
  const str = String(s);
  return align === "right" ? str.padStart(len, char).slice(-len) : str.padEnd(len, " ").slice(0, len);
}

export async function GET(req: NextRequest, ctx: { params: Promise<{ bank: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "reports:view");
    const { bank } = await ctx.params;
    const conf = BANKS[bank];
    if (!conf) return Response.json({ error: "بانک پشتیبانی‌شده نیست." }, { status: 404 });

    const { searchParams } = new URL(req.url);
    const periodId = searchParams.get("periodId");
    if (!periodId) return Response.json({ error: "انتخاب دوره الزامی است." }, { status: 400 });

    const period = await db.payrollPeriod.findUnique({
      where: { id: periodId },
      include: { payslips: { include: { employee: true }, orderBy: { employeeId: "asc" } } },
    });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });
    const company = await getCompanyInfo();

    const payable = period.payslips.filter((p) => p.employee.iban && Number(p.netPay) > 0);
    const refBase = `${period.year}${String(period.month).padStart(2, "0")}`;

    let content: string;
    let contentType: string;
    if (conf.format === "CSV") {
      const lines = ["ردیف,شماره شبا,مبلغ (ریال),شناسه واریز,نام و نام خانوادگی,شرح"];
      payable.forEach((p, i) => {
        lines.push(
          [i + 1, p.employee.iban, Number(p.netPay), `${refBase}${pad(i + 1, 4)}`,
           `${p.employee.firstName} ${p.employee.lastName}`,
           `حقوق ${periodTitle(period.year, period.month)} — ${company.name}`].join(",")
        );
      });
      content = "\uFEFF" + lines.join("\r\n") + "\r\n";
      contentType = "text/csv; charset=utf-8";
    } else {
      // عرض‌ثابت: شبا(26) + مبلغ(15) + شناسه(10) + نام(40)
      const rows: string[] = [];
      payable.forEach((p, i) => {
        rows.push(
          pad(p.employee.iban, 26, " ", "left") +
            pad(Number(p.netPay), 15) +
            pad(`${refBase}${pad(i + 1, 4)}`, 10) +
            pad(`${p.employee.firstName} ${p.employee.lastName}`, 40, " ", "left")
        );
      });
      content = rows.join("\r\n") + "\r\n";
      contentType = "text/plain; charset=utf-8";
    }

    const fileName = `Bank-${bank}-${period.year}-${String(period.month).padStart(2, "0")}.${conf.ext}`;
    await audit(session, "EXPORT", "BANK", periodId, `دریافت فایل پرداخت ${conf.title} — دوره ${periodTitle(period.year, period.month)} (${payable.length} فقره)`);

    return new Response(content, {
      headers: {
        "Content-Type": contentType,
        "Content-Disposition": `attachment; filename="${fileName}"`,
      },
    });
  });
}

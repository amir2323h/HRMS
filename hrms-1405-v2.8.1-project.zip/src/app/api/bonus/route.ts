import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit, num } from "@/lib/api-helpers";
import { getBonusConfig, resolveTier, tierByKey, computeSchemeLines, scaleLinesToBudget } from "@/lib/bonus";
import { todayJalaliStr } from "@/lib/jalali";

/** طرح‌های پاداش — GET لیست / POST ساخت با محاسبه (bonus:view / bonus:manage) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "bonus:view");
    const schemes = await db.bonusScheme.findMany({ orderBy: [{ year: "desc" }, { createdAt: "desc" }] });
    const lineCounts = await db.bonusLine.groupBy({ by: ["schemeId"], _count: { schemeId: true } });
    const countMap = new Map(lineCounts.map((c) => [c.schemeId, c._count.schemeId]));
    return {
      schemes: schemes.map((s) => ({
        id: s.id,
        year: s.year,
        title: s.title,
        targetAmount: num(s.targetAmount),
        actualAmount: num(s.actualAmount),
        achievementRatio: s.achievementRatio,
        tier: s.tier,
        tierMode: s.tierMode,
        manualTier: s.manualTier,
        budget: num(s.budget),
        scaleToBudget: s.scaleToBudget,
        referenceDateJ: s.referenceDateJ,
        status: s.status,
        notes: s.notes,
        totalComputed: num(s.totalComputed),
        totalFinal: num(s.totalFinal),
        lineCount: countMap.get(s.id) || 0,
        createdBy: s.createdBy,
        createdAt: s.createdAt,
      })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "bonus:manage");
    const b = await req.json();
    const year = Math.round(+b.year || 1405);
    const title = String(b.title || "").trim();
    if (!title) return Response.json({ error: "عنوان طرح الزامی است." }, { status: 400 });
    const targetAmount = Math.round(+b.targetAmount || 0);
    const actualAmount = Math.round(+b.actualAmount || 0);
    const budget = Math.round(+b.budget || 0);
    if (targetAmount < 0 || actualAmount < 0 || budget < 0) {
      return Response.json({ error: "مبالغ نمی‌توانند منفی باشند." }, { status: 400 });
    }
    const tierMode = b.tierMode === "MANUAL" ? "MANUAL" : "AUTO";
    const cfg = await getBonusConfig();
    const ratio = targetAmount > 0 ? actualAmount / targetAmount : actualAmount > 0 ? Infinity : 0;
    const tier = tierMode === "MANUAL" ? tierByKey(cfg, String(b.manualTier || "BELOW_80")) : resolveTier(cfg, isFinite(ratio) ? ratio : 999);
    const referenceDateJ = String(b.referenceDateJ || `${year}/12/29`);
    if (!/^\d{4}\/\d{2}\/\d{2}$/.test(referenceDateJ)) {
      return Response.json({ error: "تاریخ مرجع نامعتبر است." }, { status: 400 });
    }

    // داده کارکنان + دپارتمان + طبقه
    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      select: { id: true, firstName: true, lastName: true, personnelCode: true, baseSalary: true, jobGradeId: true, hireDateJ: true, status: true },
    });
    const links = await db.employeeDepartment.findMany({ include: { department: { select: { name: true } } } });
    const deptOf = new Map<string, string>();
    for (const l of links) if (!deptOf.has(l.employeeId)) deptOf.set(l.employeeId, l.department.name);
    const grades = await db.jobGrade.findMany();
    const gradeMap = new Map(grades.map((g) => [g.id, { level: g.level, title: g.title }]));

    const { lines, totalComputed, totalFinal } = computeSchemeLines(
      cfg,
      tier,
      referenceDateJ,
      employees,
      (empId) => deptOf.get(empId) || "—",
      (gradeId) => (gradeId ? gradeMap.get(gradeId) || null : null),
    );
    const scaled = b.scaleToBudget && budget > 0 ? scaleLinesToBudget(lines, BigInt(budget)) : lines;
    let totalFinal2 = BigInt(0);
    for (const l of scaled) totalFinal2 += l.finalAmount;

    const scheme = await db.bonusScheme.create({
      data: {
        year,
        title,
        targetAmount: BigInt(targetAmount),
        actualAmount: BigInt(actualAmount),
        achievementRatio: isFinite(ratio) ? Math.round(ratio * 1000) / 1000 : 99.99,
        tier: tier.key,
        tierMode,
        manualTier: tierMode === "MANUAL" ? tier.key : "",
        budget: BigInt(budget),
        scaleToBudget: !!b.scaleToBudget,
        referenceDateJ,
        levelsJson: JSON.stringify(cfg.levels),
        tiersJson: JSON.stringify(cfg.tiers),
        totalComputed,
        totalFinal: totalFinal2,
        status: "DRAFT",
        notes: String(b.notes || ""),
        createdBy: session.fullName,
      },
    });
    for (const l of scaled) {
      await db.bonusLine.create({
        data: {
          schemeId: scheme.id,
          employeeId: l.employeeId,
          employeeName: l.employeeName,
          personnelCode: l.personnelCode,
          department: l.department,
          jobLevel: l.jobLevel,
          jobLevelTitle: l.jobLevelTitle,
          baseSalary: l.baseSalary,
          bonusMonths: l.bonusMonths,
          monthsPresent: l.monthsPresent,
          paymentPercent: l.paymentPercent,
          computedAmount: l.computedAmount,
          finalAmount: l.finalAmount,
        },
      });
    }
    await audit(session, "CALC", "BONUS_SCHEME", scheme.id, `ایجاد طرح پاداش «${title}» سال ${year} — تیر ${tier.key}، ${scaled.length} نفر، جمع ${num(totalFinal2)} ریال`);
    return { scheme: { ...scheme, totalComputed: num(totalComputed), totalFinal: num(totalFinal2), budget, targetAmount, actualAmount } };
  });
}

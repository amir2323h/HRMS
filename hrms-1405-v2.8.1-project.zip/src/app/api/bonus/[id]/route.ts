import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit, num } from "@/lib/api-helpers";
import { getBonusConfig, resolveTier, tierByKey, computeSchemeLines, scaleLinesToBudget } from "@/lib/bonus";

/** جزئیات طرح پاداش — GET با خطوط / PATCH بازمحاسبه یا تغییر وضعیت / DELETE فقط پیش‌نویس */
export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(req, "bonus:view");
    const { id } = await params;
    const scheme = await db.bonusScheme.findUnique({ where: { id } });
    if (!scheme) return Response.json({ error: "طرح یافت نشد." }, { status: 404 });
    const lines = await db.bonusLine.findMany({ where: { schemeId: id }, orderBy: [{ jobLevel: "desc" }, { employeeName: "asc" }] });
    return {
      scheme: {
        ...scheme,
        targetAmount: num(scheme.targetAmount),
        actualAmount: num(scheme.actualAmount),
        budget: num(scheme.budget),
        totalComputed: num(scheme.totalComputed),
        totalFinal: num(scheme.totalFinal),
        levels: JSON.parse(scheme.levelsJson || "{}"),
        tiers: JSON.parse(scheme.tiersJson || "[]"),
      },
      lines: lines.map((l) => ({
        id: l.id,
        employeeId: l.employeeId,
        employeeName: l.employeeName,
        personnelCode: l.personnelCode,
        department: l.department,
        jobLevel: l.jobLevel,
        jobLevelTitle: l.jobLevelTitle,
        baseSalary: num(l.baseSalary),
        bonusMonths: l.bonusMonths,
        monthsPresent: l.monthsPresent,
        paymentPercent: l.paymentPercent,
        computedAmount: num(l.computedAmount),
        finalAmount: num(l.finalAmount),
      })),
    };
  });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "bonus:manage");
    const { id } = await params;
    const b = await req.json();
    const scheme = await db.bonusScheme.findUnique({ where: { id } });
    if (!scheme) return Response.json({ error: "طرح یافت نشد." }, { status: 404 });

    // تغییر وضعیت
    if (b.status !== undefined && Object.keys(b).length === 1) {
      const to = String(b.status);
      const transitions: Record<string, string[]> = { DRAFT: ["CONFIRMED"], CONFIRMED: ["PAID"], PAID: [] };
      if (!(transitions[scheme.status] || []).includes(to)) {
        return Response.json({ error: `گذار وضعیت ${scheme.status} → ${to} مجاز نیست.` }, { status: 400 });
      }
      await db.bonusScheme.update({ where: { id }, data: { status: to } });
      await audit(session, "UPDATE", "BONUS_SCHEME", id, `وضعیت طرح «${scheme.title}» به ${to} تغییر کرد`, { status: scheme.status }, { status: to });
      return { ok: true };
    }

    // بازمحاسبه — فقط پیش‌نویس
    if (scheme.status !== "DRAFT") {
      return Response.json({ error: "بازمحاسبه فقط برای طرح‌های پیش‌نویس امکان‌پذیر است." }, { status: 400 });
    }
    const year = b.year !== undefined ? Math.round(+b.year) : scheme.year;
    const title = b.title !== undefined ? String(b.title).trim() : scheme.title;
    const targetAmount = b.targetAmount !== undefined ? Math.round(+b.targetAmount) : num(scheme.targetAmount);
    const actualAmount = b.actualAmount !== undefined ? Math.round(+b.actualAmount) : num(scheme.actualAmount);
    const budget = b.budget !== undefined ? Math.round(+b.budget) : num(scheme.budget);
    const tierMode = b.tierMode !== undefined ? (b.tierMode === "MANUAL" ? "MANUAL" : "AUTO") : scheme.tierMode;
    const manualTier = b.manualTier !== undefined ? String(b.manualTier) : scheme.manualTier;
    const scaleToBudget = b.scaleToBudget !== undefined ? !!b.scaleToBudget : scheme.scaleToBudget;
    const referenceDateJ = b.referenceDateJ !== undefined ? String(b.referenceDateJ) : scheme.referenceDateJ;
    if (!/^\d{4}\/\d{2}\/\d{2}$/.test(referenceDateJ || "")) {
      return Response.json({ error: "تاریخ مرجع نامعتبر است." }, { status: 400 });
    }

    const cfg = await getBonusConfig();
    const ratio = targetAmount > 0 ? actualAmount / targetAmount : actualAmount > 0 ? Infinity : 0;
    const tier = tierMode === "MANUAL" ? tierByKey(cfg, manualTier || "BELOW_80") : resolveTier(cfg, isFinite(ratio) ? ratio : 999);

    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      select: { id: true, firstName: true, lastName: true, personnelCode: true, baseSalary: true, jobGradeId: true, hireDateJ: true, status: true },
    });
    const links = await db.employeeDepartment.findMany({ include: { department: { select: { name: true } } } });
    const deptOf = new Map<string, string>();
    for (const l of links) if (!deptOf.has(l.employeeId)) deptOf.set(l.employeeId, l.department.name);
    const grades = await db.jobGrade.findMany();
    const gradeMap = new Map(grades.map((g) => [g.id, { level: g.level, title: g.title }]));

    const { lines, totalComputed } = computeSchemeLines(
      cfg, tier, referenceDateJ, employees,
      (empId) => deptOf.get(empId) || "—",
      (gradeId) => (gradeId ? gradeMap.get(gradeId) || null : null),
    );
    const scaled = scaleToBudget && budget > 0 ? scaleLinesToBudget(lines, BigInt(budget)) : lines;
    let totalFinal = BigInt(0);
    for (const l of scaled) totalFinal += l.finalAmount;

    await db.bonusLine.deleteMany({ where: { schemeId: id } });
    for (const l of scaled) {
      await db.bonusLine.create({
        data: {
          schemeId: id,
          employeeId: l.employeeId,
          employeeName: l.employeeName,
          personnelCode: l.personnelCode,
          department: l.department,
          jobLevel: l.jobLevel,
          jobLevelTitle: l.jobLevelTitle,
          baseSalary: l.baseSalary,
          bonusMonths: l.bonusMonths,
          monthsPresent: l.monthsPresent,
          paymentPercent: l.paymentPercent,
          computedAmount: l.computedAmount,
          finalAmount: l.finalAmount,
        },
      });
    }
    const updated = await db.bonusScheme.update({
      where: { id },
      data: {
        year, title,
        targetAmount: BigInt(targetAmount),
        actualAmount: BigInt(actualAmount),
        achievementRatio: isFinite(ratio) ? Math.round(ratio * 1000) / 1000 : 99.99,
        tier: tier.key, tierMode,
        manualTier: tierMode === "MANUAL" ? tier.key : "",
        budget: BigInt(budget), scaleToBudget, referenceDateJ,
        levelsJson: JSON.stringify(cfg.levels),
        tiersJson: JSON.stringify(cfg.tiers),
        totalComputed, totalFinal,
        notes: b.notes !== undefined ? String(b.notes) : scheme.notes,
      },
    });
    await audit(session, "CALC", "BONUS_SCHEME", id, `بازمحاسبه طرح «${title}» — تیر ${tier.key}، ${scaled.length} نفر`);
    return { scheme: { ...updated, targetAmount, actualAmount, budget, totalComputed: num(totalComputed), totalFinal: num(totalFinal) } };
  });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "bonus:manage");
    const { id } = await params;
    const scheme = await db.bonusScheme.findUnique({ where: { id } });
    if (!scheme) return Response.json({ error: "طرح یافت نشد." }, { status: 404 });
    if (scheme.status !== "DRAFT") return Response.json({ error: "فقط طرح‌های پیش‌نویس قابل حذف‌اند." }, { status: 400 });
    await db.bonusScheme.delete({ where: { id } });
    await audit(session, "DELETE", "BONUS_SCHEME", id, `حذف طرح پاداش «${scheme.title}»`);
    return { ok: true };
  });
}

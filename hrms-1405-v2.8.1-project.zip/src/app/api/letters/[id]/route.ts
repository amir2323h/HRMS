import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { computeLetterSignatureCode, parseLetterFlowSteps, parseLetterTrail, type LetterTrailEntry, type LetterFlowStep } from "@/lib/letters";
import { hasPerm } from "@/lib/permissions";

/** تأیید/رد نامه — letters:approve (مراحل نقشی) یا letters:sign (مرحله امضای شخصی)
 *  سه مود تأیید:
 *   الف) روال داینامیک (flowSnapshot روی نامه): هر مرحله = یک نقش؛ تأیید هر مرحله
 *       پیش می‌رود و «تأیید نهایی» (آخرین مرحله) امضای دیجیتال را صادر می‌کند.
 *   ب) مرحله امضای شخص خاص (role="SIGNER" + userId/username): فقط خود امضاکننده
 *       (یا مدیر کل) می‌تواند تأیید کند — نامه در کارتابل خود اوست.
 *   ج) تک‌مرحله‌ای (قدیمی): نامه قالبی با نقش قالب (approverRole)، نامه دستی با
 *       مدیر منابع انسانی؛ مدیر کل همیشه مجاز است */
/** پاسخ PATCH — فیلدهای JSON روال/سابقه به شکل آرایه قابل استفاده کلاینت */
function letterWithFlow(row: { approvalTrail: string; flowSnapshot: string; pendingStep: number }): { approvalTrail: LetterTrailEntry[]; flowSteps: LetterFlowStep[]; pendingStep: number } {
  return {
    approvalTrail: parseLetterTrail(row.approvalTrail),
    flowSteps: parseLetterFlowSteps(row.flowSnapshot),
    pendingStep: row.pendingStep,
  };
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requireAuth(req);
    const { id } = await params;
    const b = await req.json();
    const to = String(b.status || "");
    if (!["APPROVED", "REJECTED"].includes(to)) {
      return Response.json({ error: "وضعیت نامعتبر است (APPROVED/REJECTED)." }, { status: 400 });
    }
    const row = await db.letterRequest.findUnique({ where: { id }, include: { template: true } });
    if (!row) return Response.json({ error: "نامه یافت نشد." }, { status: 404 });
    if (row.status !== "PENDING") return Response.json({ error: "این نامه قبلاً تعیین تکلیف شده است." }, { status: 400 });

    const flowSteps = parseLetterFlowSteps(row.flowSnapshot);
    const isSuper = (session.perms || []).includes("*");
    const canApprove = hasPerm(session.perms, "letters:approve");
    const canSign = hasPerm(session.perms, "letters:sign");
    if (!isSuper && !canApprove && !canSign) {
      return Response.json({ error: "شما به تعیین‌تکلیف نامه دسترسی ندارید." }, { status: 403 });
    }
    const note = String(b.note || "");
    const now = new Date();

    if (flowSteps.length > 0) {
      // ---------- مود روال چندمرحله‌ای ----------
      const stepIdx = Math.min(Math.max(row.pendingStep, 1), flowSteps.length); // مرحله جاری (۱ مبنا)
      const step = flowSteps[stepIdx - 1];
      if (step.userId || step.username) {
        // مرحله امضای شخص خاص — فقط خود امضاکننده (یا مدیر کل)
        const isTheSigner =
          !!(step.username && step.username === session.username) ||
          !!(step.userId && step.userId === session.uid);
        if (!isSuper && !isTheSigner) {
          return Response.json(
            {
              error: `این نامه برای امضای «${step.roleName || "امضاکننده"}» به کارتابل خود او ارجاع شده است — تأیید این مرحله فقط توسط خود امضاکننده انجام می‌شود.`,
            },
            { status: 403 }
          );
        }
      } else {
        // مرحله نقشی — نیاز به مجوز تأیید نامه + تطبیق نقش
        if (!isSuper && !canApprove) {
          return Response.json({ error: "شما مجوز تأیید نامه (letters:approve) ندارید." }, { status: 403 });
        }
        if (!isSuper && session.role !== step.role) {
          return Response.json(
            {
              error: `اکنون نوبت نقش «${step.roleName || step.role}» (مرحله ${stepIdx} از ${flowSteps.length}) است — کاربر فعلی نقش «${session.roleName || session.role}» دارد.`,
            },
            { status: 403 }
          );
        }
      }

      const trail = parseLetterTrail(row.approvalTrail);
      const entry: LetterTrailEntry = {
        step: stepIdx,
        role: step.role,
        by: session.fullName,
        at: now.toISOString(),
        action: to === "APPROVED" ? "APPROVED" : "REJECTED",
        note: note || undefined,
      };
      const nextTrail = [...trail, entry];

      if (to === "REJECTED") {
        // رد در هر مرحله = رد کل نامه
        const updated = await db.letterRequest.update({
          where: { id },
          data: {
            status: "REJECTED",
            decidedBy: session.fullName,
            decidedAt: now,
            decisionNote: note,
            approvalTrail: JSON.stringify(nextTrail),
          },
        });
        await audit(
          session,
          "UPDATE",
          "LETTER_REQUEST",
          id,
          `رد ${row.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه"} «${row.title}» (${row.number}) در مرحله ${stepIdx} از ${flowSteps.length}${row.employeeName ? ` — ${row.employeeName}` : ""}`,
          { status: row.status, step: stepIdx },
          { status: "REJECTED", step: stepIdx, note }
        );
        return { letter: { ...updated, ...letterWithFlow(updated) }, advanced: false };
      }

      if (stepIdx < flowSteps.length) {
        // تأیید میانی — پیشروی به مرحله بعد؛ نامه همچنان PENDING
        const updated = await db.letterRequest.update({
          where: { id },
          data: {
            status: "PENDING",
            pendingStep: stepIdx + 1,
            approvalTrail: JSON.stringify(nextTrail),
            decisionNote: note,
          },
        });
        await audit(
          session,
          "APPROVE",
          "LETTER_REQUEST",
          id,
          `تأیید مرحله ${stepIdx} از ${flowSteps.length} «${row.title}» (${row.number}) توسط ${session.fullName} — در انتظار «${flowSteps[stepIdx].roleName || flowSteps[stepIdx].role}»`,
          { step: stepIdx },
          { step: stepIdx + 1, pendingStep: stepIdx + 1 }
        );
        return { letter: { ...updated, ...letterWithFlow(updated) }, advanced: true };
      }

      // تأیید نهایی (آخرین مرحله) — امضای دیجیتال صادر می‌شود
      const signatureCode = computeLetterSignatureCode({
        number: row.number,
        employeeName: row.employeeName,
        personnelCode: row.personnelCode,
        title: row.title,
        body: row.body,
        decidedBy: session.fullName,
        decidedAt: now,
        recipient: row.recipient,
        items: row.itemsJson,
        signerName: row.signerName,
        signerTitle: row.signerTitle,
        bodyHtml: row.bodyHtml,
      });
      const updated = await db.letterRequest.update({
        where: { id },
        data: {
          status: "APPROVED",
          decidedBy: session.fullName,
          decidedAt: now,
          decisionNote: note,
          signatureCode,
          approvalTrail: JSON.stringify(nextTrail),
        },
      });
      await audit(
        session,
        "APPROVE",
        "LETTER_REQUEST",
        id,
        `تأیید نهایی (مرحله ${stepIdx} از ${stepIdx}) ${row.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه"} «${row.title}» (${row.number})${row.employeeName ? ` — ${row.employeeName}` : ""} | امضای دیجیتال: ${signatureCode}`,
        { status: row.status, step: stepIdx },
        { status: "APPROVED", signatureCode }
      );
      return { letter: { ...updated, ...letterWithFlow(updated) }, advanced: false };
    }

    // ---------- مود تک‌مرحله‌ای (رفتار قدیمی) ----------
    // نقش تأییدکننده — نامه قالبی: مطابق قالب؛ نامه دستی: مدیر منابع انسانی
    if (!isSuper && !canApprove) {
      return Response.json({ error: "شما مجوز تأیید نامه (letters:approve) ندارید." }, { status: 403 });
    }
    const requiredRole = row.source === "MANUAL" ? "HR_MANAGER" : row.template?.approverRole || "HR_MANAGER";
    if (!isSuper && requiredRole && session.role !== requiredRole) {
      return Response.json(
        { error: `این نامه باید توسط نقش «${requiredRole}» تأیید شود — کاربر فعلی نقش «${session.role}» دارد.` },
        { status: 403 }
      );
    }

    // امضای دیجیتال: هنگام تأیید روی محتوای نامه قفل می‌شود (HMAC-SHA256)
    const decidedAt = new Date();
    const signatureCode =
      to === "APPROVED"
        ? computeLetterSignatureCode({
            number: row.number,
            employeeName: row.employeeName,
            personnelCode: row.personnelCode,
            title: row.title,
            body: row.body,
            decidedBy: session.fullName,
            decidedAt,
            recipient: row.recipient,
            items: row.itemsJson,
            signerName: row.signerName,
            signerTitle: row.signerTitle,
            bodyHtml: row.bodyHtml,
          })
        : null;

    const updated = await db.letterRequest.update({
      where: { id },
      data: {
        status: to,
        decidedBy: session.fullName,
        decidedAt,
        decisionNote: String(b.note || ""),
        signatureCode,
      },
    });
    await audit(
      session,
      to === "APPROVED" ? "APPROVE" : "UPDATE",
      "LETTER_REQUEST",
      id,
      `${to === "APPROVED" ? "تأیید" : "رد"} ${row.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه"} «${row.title}» (${row.number})${row.employeeName ? ` — ${row.employeeName}` : ""}` +
        (signatureCode ? ` | امضای دیجیتال: ${signatureCode}` : ""),
      { status: row.status },
      { status: to, note: b.note || "", signatureCode }
    );
    return { letter: { ...updated, ...letterWithFlow(updated) }, advanced: false };
  });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "letters:approve");
    const { id } = await params;
    const row = await db.letterRequest.findUnique({ where: { id } });
    if (!row) return Response.json({ error: "نامه یافت نشد." }, { status: 404 });
    // درخواست‌نامه در انتظار: قابل حذف توسط تأییدکننده
    // نامه دستی صادرشده: قابل حذف فقط توسط دارنده مجوز ثبت نامه دستی (ابطال نامه ثبت‌شده اشتباه)
    if (row.status !== "PENDING" && !(row.source === "MANUAL" && hasPerm(session.perms, "letters:manual"))) {
      return Response.json({ error: "نامه تعیین‌تکلیف‌شده قابل حذف نیست." }, { status: 400 });
    }
    await db.letterRequest.delete({ where: { id } });
    await audit(
      session,
      "DELETE",
      "LETTER_REQUEST",
      id,
      `حذف ${row.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه"} «${row.title}» (${row.number})${row.signatureCode ? " — امضای دیجیتال باطل شد" : ""}`
    );
    return { ok: true };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { handle } from "@/lib/api-helpers";
import { verifyLetterSignature } from "@/lib/letters";
import { isoToJalaliStr, formatDateJ } from "@/lib/jalali";

/**
 * راستی‌آزمایی عمومی نامه با کد امضای دیجیتال — بدون نیاز به ورود.
 * کد امضا (XXXX-XXXX-XXXX-XXXX) پای سند چاپی درج شده است؛ دریافت‌کننده نامه
 * (بانک، سازمان، کارفرمای جدید و…) می‌تواند اصالت آن را از این مسیر بررسی کند.
 * پاسخ: JSON برای فراخوانی سیستمی، صفحه HTML فارسی برای مرورگر (بر اساس Accept).
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const url = new URL(req.url);
    const raw = (url.searchParams.get("code") || "").trim().toUpperCase().replace(/[^A-F0-9]/g, "");
    if (raw.length !== 16) {
      return verifyResult(req, null, false, "فرمت کد نامعتبر است — کد امضا ۱۶ نویسه است (مثال: A1B2-C3D4-E5F6-7890).");
    }
    const formatted = `${raw.slice(0, 4)}-${raw.slice(4, 8)}-${raw.slice(8, 12)}-${raw.slice(12, 16)}`;

    // کد یکتاست (خروجی HMAC) — جستجو با هر دو شکل
    const row =
      (await db.letterRequest.findFirst({ where: { signatureCode: formatted } })) ||
      (await db.letterRequest.findFirst({ where: { signatureCode: raw } }));

    if (!row) {
      return verifyResult(req, null, false, "نامه‌ای با این کد امضا یافت نشد.");
    }

    // بازمحاسبه امضا از محتوای فعلی — تطابق = اصالت حفظ شده، عدم تطابق = دستکاری پس از تأیید
    const intact = verifyLetterSignature({
      number: row.number,
      employeeName: row.employeeName,
      personnelCode: row.personnelCode,
      title: row.title,
      body: row.body,
      decidedBy: row.decidedBy,
      decidedAt: row.decidedAt,
      recipient: row.recipient,
      items: row.itemsJson,
      signerName: row.signerName,
      signerTitle: row.signerTitle,
      bodyHtml: row.bodyHtml,
      signatureCode: row.signatureCode,
    });

    if (row.status !== "APPROVED") {
      return verifyResult(req, row, false, "این نامه در وضعیت «تأییدشده» نیست.");
    }

    return verifyResult(
      req,
      row,
      intact,
      intact
        ? "نامه معتبر است — محتوای ثبت‌شده هنگام تأیید، بدون تغییر باقی مانده است."
        : "هشدار: محتوای این نامه پس از تأیید تغییر کرده است — کد امضا با محتوای فعلی مطابقت ندارد."
    );
  });
}

interface LetterSummary {
  number: string; title: string; employeeName: string; personnelCode: string;
  department: string; status: string; decidedBy: string; decidedAt: Date | null;
  source: string; recipient: string; signerName: string; signerTitle: string;
}

function verifyResult(req: NextRequest, row: LetterSummary | null, valid: boolean, message: string) {
  const wantsHtml = (req.headers.get("accept") || "").includes("text/html");
  const summary = row
    ? {
        number: row.number,
        title: row.title,
        employeeName: row.employeeName,
        personnelCode: row.personnelCode,
        department: row.department,
        status: row.status,
        decidedBy: row.decidedBy,
        decidedAt: row.decidedAt,
        decidedAtJ: row.decidedAt ? formatDateJ(isoToJalaliStr(row.decidedAt)) : "",
        source: row.source,
        recipient: row.recipient,
        signerName: row.signerName,
        signerTitle: row.signerTitle,
      }
    : null;

  if (wantsHtml) {
    return new Response(verifyHtml(valid, message, summary), { headers: { "content-type": "text/html; charset=utf-8" } });
  }
  return Response.json({ valid, message, letter: summary });
}

function esc(s: string): string {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

interface SummaryView {
  number: string; title: string; employeeName: string; personnelCode: string;
  department: string; decidedBy: string; decidedAtJ: string;
  source: string; recipient: string; signerName: string; signerTitle: string;
}

function verifyHtml(valid: boolean, message: string, summary: SummaryView | null): string {
  const color = valid ? "#059669" : "#dc2626";
  const icon = valid ? "✓" : "✕";
  const rows = summary
    ? `
      <tr><th>شماره نامه</th><td dir="ltr" class="mono">${esc(summary.number)}</td></tr>
      <tr><th>موضوع</th><td>${esc(summary.title)}</td></tr>
      ${summary.recipient ? `<tr><th>گیرنده</th><td>${esc(summary.recipient)}</td></tr>` : ""}
      ${summary.source === "MANUAL"
        ? `<tr><th>نوع نامه</th><td>ثبت دستی (کارشناس اداری)</td></tr>`
        : `<tr><th>کارمند</th><td>${esc(summary.employeeName)} — کد پرسنلی ${esc(summary.personnelCode)}</td></tr>
           <tr><th>واحد سازمانی</th><td>${esc(summary.department || "—")}</td></tr>`}
      ${summary.signerName ? `<tr><th>امضاکننده</th><td>${esc(summary.signerName)}${summary.signerTitle ? ` — ${esc(summary.signerTitle)}` : ""}</td></tr>` : ""}
      <tr><th>صادرکننده</th><td>${esc(summary.decidedBy)}</td></tr>
      <tr><th>تاریخ صدور</th><td>${esc(summary.decidedAtJ || "—")}</td></tr>`
    : "";
  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>راستی‌آزمایی نامه</title>
<style>
@font-face { font-family: 'Vazirmatn'; src: url('/fonts/Vazirmatn-Regular.woff2') format('woff2'); font-weight: 400; font-display: block; }
@font-face { font-family: 'Vazirmatn'; src: url('/fonts/Vazirmatn-Bold.woff2') format('woff2'); font-weight: 700; font-display: block; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Vazirmatn', 'Segoe UI', Tahoma, sans-serif; background: #f1f5f9; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; direction: rtl; }
.card { background: #fff; border-radius: 18px; box-shadow: 0 8px 30px rgba(15,23,42,.09); max-width: 520px; width: 100%; overflow: hidden; }
.head { padding: 26px 24px; text-align: center; border-bottom: 1px solid #e2e8f0; }
.badge { width: 58px; height: 58px; border-radius: 50%; background: ${color}15; color: ${color}; font-size: 28px; font-weight: 700; display: flex; align-items: center; justify-content: center; margin: 0 auto 12px; border: 2px solid ${color}40; }
h1 { font-size: 17px; color: #0f172a; }
.msg { font-size: 12.5px; color: #475569; margin-top: 6px; line-height: 2; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 10px 24px; font-size: 12.5px; text-align: right; border-bottom: 1px solid #f1f5f9; }
th { color: #64748b; font-weight: 400; width: 130px; }
td { color: #1e293b; font-weight: 600; }
.mono { font-family: ui-monospace, monospace; letter-spacing: .5px; }
.foot { padding: 14px 24px; font-size: 10.5px; color: #94a3b8; text-align: center; background: #f8fafc; }
</style>
</head>
<body>
  <div class="card">
    <div class="head">
      <div class="badge">${icon}</div>
      <h1>${valid ? "نامه معتبر است" : "نامه معتبر نیست"}</h1>
      <p class="msg">${esc(message)}</p>
    </div>
    ${rows ? `<table>${rows}</table>` : ""}
    <div class="foot">راستی‌آزمایی امضای دیجیتال — سامانه جامع منابع انسانی</div>
  </div>
</body>
</html>`;
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { parseLetterFields } from "@/lib/letters";

/** قالب نامه‌ها — GET (لاگین‌شده؛ فقط فعال برای کاربر عادی) / POST (letters:templates) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const includeInactive = session.perms?.includes("*") || session.perms?.includes("letters:templates");
    const templates = await db.letterTemplate.findMany({
      where: includeInactive ? {} : { isActive: true },
      orderBy: { createdAt: "asc" },
    });
    const counts = await db.letterRequest.groupBy({ by: ["templateId"], _count: { templateId: true } });
    const countMap = new Map(counts.map((c) => [c.templateId, c._count.templateId]));
    return {
      templates: templates.map((t) => ({
        id: t.id,
        code: t.code,
        title: t.title,
        category: t.category,
        description: t.description,
        fields: parseLetterFields(t.fieldsJson),
        bodyTemplate: t.bodyTemplate,
        approverRole: t.approverRole,
        isActive: t.isActive,
        version: t.version,
        requestCount: countMap.get(t.id) || 0,
      })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "letters:templates");
    const b = await req.json();
    const title = String(b.title || "").trim();
    const bodyTemplate = String(b.bodyTemplate || "").trim();
    if (!title || !bodyTemplate) return Response.json({ error: "عنوان و متن قالب الزامی است." }, { status: 400 });
    // اعتبارسنجی فیلدها
    const fields = Array.isArray(b.fields) ? b.fields : [];
    for (const f of fields) {
      if (!f || typeof f.key !== "string" || !/^[a-z][a-z0-9_]*$/i.test(f.key)) {
        return Response.json({ error: "کلید فیلد باید با حرف شروع شده و فقط شامل حروف/عدد/زیرخط باشد." }, { status: 400 });
      }
      if (!String(f.label || "").trim()) return Response.json({ error: "برچسب همه فیلدها الزامی است." }, { status: 400 });
    }
    const dupKeys = fields.map((f: { key: string }) => f.key).filter((k: string, i: number, a: string[]) => a.indexOf(k) !== i);
    if (dupKeys.length) return Response.json({ error: `کلید فیلد تکراری: ${dupKeys.join(", ")}` }, { status: 400 });

    const count = await db.letterTemplate.count();
    let code = "";
    for (let i = count + 1; ; i++) {
      code = `LT-${String(i).padStart(3, "0")}`;
      if (!(await db.letterTemplate.findUnique({ where: { code } }))) break;
    }
    const tpl = await db.letterTemplate.create({
      data: {
        code,
        title,
        category: ["GENERAL", "HR", "FINANCE", "ADMIN"].includes(b.category) ? b.category : "GENERAL",
        description: String(b.description || ""),
        fieldsJson: JSON.stringify(fields),
        bodyTemplate,
        approverRole: String(b.approverRole || "HR_MANAGER"),
        isActive: b.isActive === false ? false : true,
        createdBy: session.fullName,
      },
    });
    await audit(session, "CREATE", "LETTER_TEMPLATE", tpl.id, `ایجاد قالب نامه «${title}» (${code})`);
    return { template: { ...tpl, fields } };
  });
}

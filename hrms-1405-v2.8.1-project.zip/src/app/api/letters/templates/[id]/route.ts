import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { parseLetterFields } from "@/lib/letters";

/** ویرایش/حذف قالب نامه — letters:templates */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "letters:templates");
    const { id } = await params;
    const b = await req.json();
    const tpl = await db.letterTemplate.findUnique({ where: { id } });
    if (!tpl) return Response.json({ error: "قالب یافت نشد." }, { status: 404 });

    const data: Record<string, unknown> = {};
    if (b.title !== undefined) {
      const t = String(b.title).trim();
      if (!t) return Response.json({ error: "عنوان الزامی است." }, { status: 400 });
      data.title = t;
    }
    if (b.bodyTemplate !== undefined) {
      const t = String(b.bodyTemplate).trim();
      if (!t) return Response.json({ error: "متن قالب الزامی است." }, { status: 400 });
      data.bodyTemplate = t;
    }
    if (b.category !== undefined && ["GENERAL", "HR", "FINANCE", "ADMIN"].includes(b.category)) data.category = b.category;
    if (b.description !== undefined) data.description = String(b.description);
    if (b.approverRole !== undefined) data.approverRole = String(b.approverRole);
    if (b.isActive !== undefined) data.isActive = !!b.isActive;
    if (Array.isArray(b.fields)) {
      for (const f of b.fields) {
        if (!f || typeof f.key !== "string" || !/^[a-z][a-z0-9_]*$/i.test(f.key)) {
          return Response.json({ error: "کلید فیلد نامعتبر است." }, { status: 400 });
        }
      }
      data.fieldsJson = JSON.stringify(b.fields);
    }
    // هر ویرایش معنایی → افزایش نسخه
    if (b.bodyTemplate !== undefined || b.fields !== undefined) data.version = tpl.version + 1;
    if (Object.keys(data).length === 0) return Response.json({ error: "چیزی برای ویرایش نیست." }, { status: 400 });

    const updated = await db.letterTemplate.update({ where: { id }, data });
    await audit(session, "UPDATE", "LETTER_TEMPLATE", id, `ویرایش قالب نامه «${updated.title}» (نسخه ${updated.version})`, tpl, updated);
    return { template: { ...updated, fields: parseLetterFields(updated.fieldsJson) } };
  });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "letters:templates");
    const { id } = await params;
    const tpl = await db.letterTemplate.findUnique({ where: { id } });
    if (!tpl) return Response.json({ error: "قالب یافت نشد." }, { status: 404 });
    const used = await db.letterRequest.count({ where: { templateId: id } });
    if (used > 0) return Response.json({ error: "این قالب پیش‌تر استفاده شده — به‌جای حذف، غیرفعالش کنید." }, { status: 400 });
    await db.letterTemplate.delete({ where: { id } });
    await audit(session, "DELETE", "LETTER_TEMPLATE", id, `حذف قالب نامه «${tpl.title}»`);
    return { ok: true };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { hasPerm } from "@/lib/permissions";

/** شمارش سبک نامه‌ها — نشان منو/داشبورد (letters:approve یا letters:manual یا letters:sign)
 *  pending: در انتظار تأیید | issued: صادره (تأییدشده با امضای دیجیتال)
 *  برای کاربر با فقط letters:sign (امضاکننده): شمارش نامه‌های ارجاعی به کارتابل خودش */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const canSeeAll =
      hasPerm(session.perms, "letters:approve") || hasPerm(session.perms, "letters:manual");
    const canSign = hasPerm(session.perms, "letters:sign");
    if (!canSeeAll && !canSign) {
      return Response.json({ error: "دسترسی ندارید." }, { status: 403 });
    }
    if (canSeeAll) {
      const [pending, issued] = await Promise.all([
        db.letterRequest.count({ where: { status: "PENDING" } }),
        db.letterRequest.count({ where: { status: "APPROVED" } }),
      ]);
      return { pending, issued, pendingSign: canSign ? await db.letterRequest.count({ where: { status: "PENDING", signerUserId: session.uid } }) : 0 };
    }
    // امضاکننده — فقط نامه‌های کارتابل خودش
    const [pending, issued] = await Promise.all([
      db.letterRequest.count({ where: { status: "PENDING", signerUserId: session.uid } }),
      db.letterRequest.count({ where: { status: "APPROVED", signerUserId: session.uid } }),
    ]);
    return { pending, issued, pendingSign: pending };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { isValidJalali, diffJalaliDays } from "@/lib/jalali";
import { hasPerm } from "@/lib/permissions";

/** دپارتمان‌هایی که این نشست مدیر آن‌هاست */
async function managedDeptIds(employeeId: string | null | undefined): Promise<string[]> {
  if (!employeeId) return [];
  const depts = await db.department.findMany({ where: { managerEmployeeId: employeeId }, select: { id: true } });
  return depts.map((d) => d.id);
}

/** آیا این کارمند در دپارتمان‌های مدیریت‌شدهٔ نشست است؟ */
async function isManagedBy(employeeId: string, managedIds: string[]): Promise<boolean> {
  if (managedIds.length === 0) return false;
  const links = await db.employeeDepartment.findMany({
    where: { employeeId, departmentId: { in: managedIds } },
    select: { employeeId: true },
  });
  return links.length > 0;
}

/**
 * درخواست‌های کارکنان (مرخصی/مساعده) — گردش تأیید دوسطحی:
 * کارمند → مدیر واحد (PENDING_DM) → مدیر منابع انسانی (PENDING_HR) → APPROVED/REJECTED
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const url = new URL(req.url);
    const status = url.searchParams.get("status") || "";
    const kind = url.searchParams.get("kind") || "";
    const q = (url.searchParams.get("q") || "").trim();

    const isSuper = hasPerm(session.perms, "*");
    const isHr = hasPerm(session.perms, "requests:approve_hr");
    const isDm = hasPerm(session.perms, "requests:approve_dept");

    // محدوده دید: مدیر واحد → واحدهای خودش | HR/مدیر کل → همه | کارمند → فقط خودش
    let visibleEmployeeIds: string[] | null = null; // null = همه
    if (!isSuper && !isHr) {
      if (isDm && session.employeeId) {
        const managed = await managedDeptIds(session.employeeId);
        if (managed.length > 0) {
          const links = await db.employeeDepartment.findMany({ where: { departmentId: { in: managed } }, select: { employeeId: true } });
          visibleEmployeeIds = Array.from(new Set([...links.map((l) => l.employeeId), session.employeeId]));
        } else {
          visibleEmployeeIds = [session.employeeId || "none"];
        }
      } else {
        visibleEmployeeIds = [session.employeeId || "none"];
      }
    }

    const leaveWhere: Record<string, unknown> = {};
    const advWhere: Record<string, unknown> = {};
    if (visibleEmployeeIds) {
      leaveWhere.employeeId = { in: visibleEmployeeIds };
      advWhere.employeeId = { in: visibleEmployeeIds };
    }
    if (status) {
      leaveWhere.status = status;
      advWhere.status = status;
    }

    const empSelect = { select: { id: true, firstName: true, lastName: true, personnelCode: true } };
    const [leaves, advances] = await Promise.all([
      kind !== "ADVANCE"
        ? db.leaveRequest.findMany({ where: leaveWhere, include: { employee: empSelect }, orderBy: { createdAt: "desc" } })
        : Promise.resolve([]),
      kind !== "LEAVE"
        ? db.advanceRequest.findMany({ where: advWhere, include: { employee: empSelect }, orderBy: { createdAt: "desc" } })
        : Promise.resolve([]),
    ]);

    // نام دپارتمان‌ها برای نمایش
    const empIds = Array.from(new Set([...leaves.map((l) => l.employeeId), ...advances.map((a) => a.employeeId)]));
    const deptLinks = empIds.length
      ? await db.employeeDepartment.findMany({ where: { employeeId: { in: empIds } }, include: { department: { select: { name: true } } } })
      : [];
    const deptOf = new Map<string, string>();
    for (const l of deptLinks) if (!deptOf.has(l.employeeId)) deptOf.set(l.employeeId, l.department.name);

    const leaveRows = leaves.map((l) => ({
      ...l,
      employeeName: `${l.employee.firstName} ${l.employee.lastName}`,
      department: deptOf.get(l.employeeId) || "—",
    }));
    const advRows = advances.map((a) => ({
      ...a,
      amount: Number(a.amount),
      employeeName: `${a.employee.firstName} ${a.employee.lastName}`,
      department: deptOf.get(a.employeeId) || "—",
    }));

    const filtered = (rows: { employeeName: string; personnelCode?: string; reason?: string }[]) =>
      !q ? rows : rows.filter((r) => (r.employeeName + " " + (r.reason || "")).includes(q));

    return {
      leaves: filtered(leaveRows),
      advances: filtered(advRows),
      counts: {
        pendingDm: leaveRows.filter((l) => l.status === "PENDING_DM").length + advRows.filter((a) => a.status === "PENDING_DM").length,
        pendingHr: leaveRows.filter((l) => l.status === "PENDING_HR").length + advRows.filter((a) => a.status === "PENDING_HR").length,
        approved: leaveRows.filter((l) => l.status === "APPROVED").length + advRows.filter((a) => a.status === "APPROVED").length,
        rejected: leaveRows.filter((l) => l.status === "REJECTED").length + advRows.filter((a) => a.status === "REJECTED").length,
      },
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "requests:create");
    const b = await req.json();
    // کارمند فقط برای خودش؛ مدیران/HR می‌توانند برای دیگران ثبت کنند
    const canForOthers = hasPerm(session.perms, "*") || hasPerm(session.perms, "requests:approve_hr") || hasPerm(session.perms, "requests:approve_dept") || hasPerm(session.perms, "employees:edit");
    const employeeId = canForOthers && b.employeeId ? String(b.employeeId) : session.employeeId || "";
    if (!employeeId) return Response.json({ error: "کارمند الزامی است." }, { status: 400 });
    const emp = await db.employee.findUnique({ where: { id: employeeId } });
    if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });

    if (b.kind === "LEAVE") {
      if (!isValidJalali(b.startDateJ) || !isValidJalali(b.endDateJ)) {
        return Response.json({ error: "تاریخ‌ها نامعتبرند." }, { status: 400 });
      }
      const days = Math.max(1, diffJalaliDays(b.startDateJ, b.endDateJ) + 1);
      const reqRow = await db.leaveRequest.create({
        data: {
          employeeId,
          type: ["ANNUAL", "SICK", "UNPAID", "HOURLY"].includes(b.type) ? b.type : "ANNUAL",
          startDateJ: b.startDateJ,
          endDateJ: b.endDateJ,
          days,
          reason: String(b.reason || ""),
          status: "PENDING_DM",
          dmStatus: "PENDING",
          hrStatus: "PENDING",
        },
      });
      await audit(session, "CREATE", "LEAVE_REQUEST", reqRow.id, `ثبت درخواست مرخصی ${days} روزه برای ${emp.firstName} ${emp.lastName} — در انتظار تأیید مدیر واحد`);
      return { request: { ...reqRow, employeeName: `${emp.firstName} ${emp.lastName}` } };
    }

    if (b.kind === "ADVANCE") {
      const amount = Math.round(+b.amount || 0);
      if (amount <= 0) return Response.json({ error: "مبلغ مساعده نامعتبر است." }, { status: 400 });
      const reqRow = await db.advanceRequest.create({
        data: {
          employeeId,
          amount: BigInt(amount),
          installments: Math.max(1, +b.installments || 1),
          reason: String(b.reason || ""),
          status: "PENDING_DM",
          dmStatus: "PENDING",
          hrStatus: "PENDING",
        },
      });
      await audit(session, "CREATE", "ADVANCE_REQUEST", reqRow.id, `ثبت درخواست مساعده برای ${emp.firstName} ${emp.lastName} — در انتظار تأیید مدیر واحد`);
      return { request: { ...reqRow, amount, employeeName: `${emp.firstName} ${emp.lastName}` } };
    }

    return Response.json({ error: "نوع درخواست نامعتبر است." }, { status: 400 });
  });
}

/** عملیات تأیید دوسطحی */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const b = await req.json();
    const action = String(b.action || b.status || "");
    if (!["APPROVED", "REJECTED"].includes(action)) {
      return Response.json({ error: "عملیات نامعتبر است." }, { status: 400 });
    }
    const note = String(b.note || "");
    const isSuper = hasPerm(session.perms, "*");
    const isHr = hasPerm(session.perms, "requests:approve_hr");
    const isDm = hasPerm(session.perms, "requests:approve_dept");

    async function decide<T extends { id: string; employeeId: string; status: string }>(
      kind: "LEAVE" | "ADVANCE",
      row: T & Record<string, unknown>,
      model: "leaveRequest" | "advanceRequest"
    ) {
      if (!row) return Response.json({ error: "درخواست یافت نشد." }, { status: 404 });
      if (row.status === "APPROVED" || row.status === "REJECTED") {
        return Response.json({ error: "این درخواست قبلاً تعیین تکلیف شده است." }, { status: 400 });
      }

      if (row.status === "PENDING_DM") {
        // مرحله ۱ — مدیر واحد (یا مدیر کل)
        if (!isSuper && !isDm) return Response.json({ error: "تأیید مرحله اول فقط توسط مدیر واحد انجام می‌شود." }, { status: 403 });
        if (!isSuper && !(await isManagedBy(row.employeeId, await managedDeptIds(session.employeeId)))) {
          return Response.json({ error: "این کارمند در واحد شما نیست." }, { status: 403 });
        }
        if (action === "APPROVED") {
          await (db[model] as typeof db.leaveRequest).update({
            where: { id: row.id },
            data: { dmStatus: "APPROVED", dmBy: session.fullName, dmAt: new Date(), status: "PENDING_HR" },
          });
          await audit(session, "APPROVE", kind === "LEAVE" ? "LEAVE_REQUEST" : "ADVANCE_REQUEST", row.id, `تأیید مرحله مدیر واحد — ارسال به منابع انسانی`, { status: "PENDING_DM" }, { status: "PENDING_HR" });
          return { ok: true, status: "PENDING_HR" };
        }
        await (db[model] as typeof db.leaveRequest).update({
          where: { id: row.id },
          data: { dmStatus: "REJECTED", dmBy: session.fullName, dmAt: new Date(), status: "REJECTED", rejectReason: note, decidedBy: session.fullName },
        });
        await audit(session, "UPDATE", kind === "LEAVE" ? "LEAVE_REQUEST" : "ADVANCE_REQUEST", row.id, `رد درخواست توسط مدیر واحد${note ? ` — ${note}` : ""}`, { status: "PENDING_DM" }, { status: "REJECTED" });
        return { ok: true, status: "REJECTED" };
      }

      // مرحله ۲ — مدیر منابع انسانی (یا مدیر کل)
      if (!isSuper && !isHr) return Response.json({ error: "تأیید مرحله دوم فقط توسط مدیر منابع انسانی انجام می‌شود." }, { status: 403 });
      if (action === "APPROVED") {
        await (db[model] as typeof db.leaveRequest).update({
          where: { id: row.id },
          data: { hrStatus: "APPROVED", hrBy: session.fullName, hrAt: new Date(), status: "APPROVED", decidedBy: session.fullName },
        });
        await audit(session, "APPROVE", kind === "LEAVE" ? "LEAVE_REQUEST" : "ADVANCE_REQUEST", row.id, `تأیید نهایی توسط منابع انسانی`, { status: "PENDING_HR" }, { status: "APPROVED" });
        return { ok: true, status: "APPROVED" };
      }
      await (db[model] as typeof db.leaveRequest).update({
        where: { id: row.id },
        data: { hrStatus: "REJECTED", hrBy: session.fullName, hrAt: new Date(), status: "REJECTED", rejectReason: note, decidedBy: session.fullName },
      });
      await audit(session, "UPDATE", kind === "LEAVE" ? "LEAVE_REQUEST" : "ADVANCE_REQUEST", row.id, `رد درخواست توسط منابع انسانی${note ? ` — ${note}` : ""}`, { status: "PENDING_HR" }, { status: "REJECTED" });
      return { ok: true, status: "REJECTED" };
    }

    if (b.kind === "LEAVE" && b.id) {
      const row = await db.leaveRequest.findUnique({ where: { id: b.id }, include: { employee: { select: { firstName: true, lastName: true } } } });
      return decide("LEAVE", row as never, "leaveRequest");
    }
    if (b.kind === "ADVANCE" && b.id) {
      const row = await db.advanceRequest.findUnique({ where: { id: b.id }, include: { employee: { select: { firstName: true, lastName: true } } } });
      return decide("ADVANCE", row as never, "advanceRequest");
    }
    return Response.json({ error: "درخواست نامعتبر است." }, { status: 400 });
  });
}

/** حذف درخواست توسط خود کارمند (فقط وقتی هنوز در انتظار است) */
export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    const kind = url.searchParams.get("kind");
    if (!id || !kind) return Response.json({ error: "شناسه و نوع الزامی است." }, { status: 400 });
    const isSuper = hasPerm(session.perms, "*") || hasPerm(session.perms, "requests:approve_hr");
    if (kind === "LEAVE") {
      const row = await db.leaveRequest.findUnique({ where: { id } });
      if (!row) return Response.json({ error: "یافت نشد." }, { status: 404 });
      if (!isSuper && row.employeeId !== session.employeeId) return Response.json({ error: "دسترسی ندارید." }, { status: 403 });
      if (row.status !== "PENDING_DM" && row.status !== "PENDING_HR") return Response.json({ error: "درخواست تعیین‌تکلیف‌شده قابل حذف نیست." }, { status: 400 });
      await db.leaveRequest.delete({ where: { id } });
    } else if (kind === "ADVANCE") {
      const row = await db.advanceRequest.findUnique({ where: { id } });
      if (!row) return Response.json({ error: "یافت نشد." }, { status: 404 });
      if (!isSuper && row.employeeId !== session.employeeId) return Response.json({ error: "دسترسی ندارید." }, { status: 403 });
      if (row.status !== "PENDING_DM" && row.status !== "PENDING_HR") return Response.json({ error: "درخواست تعیین‌تکلیف‌شده قابل حذف نیست." }, { status: 400 });
      await db.advanceRequest.delete({ where: { id } });
    } else {
      return Response.json({ error: "نوع نامعتبر است." }, { status: 400 });
    }
    await audit(session, "DELETE", kind === "LEAVE" ? "LEAVE_REQUEST" : "ADVANCE_REQUEST", id, `حذف درخواست در انتظار`);
    return { ok: true };
  });
}

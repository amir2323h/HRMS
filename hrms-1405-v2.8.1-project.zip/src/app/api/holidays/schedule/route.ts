import { NextRequest } from "next/server";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { saveWorkSchedule } from "@/lib/holidays";

// ============================================================
// ذخیره شیفت‌ها و سیاست تعطیلی هفتگی — PUT (attendance:manage)
//  { schedule: { daily, morning, evening, night, weekend } }
// ============================================================

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "attendance:manage");
    const b = (await req.json()) as { schedule?: Record<string, unknown> };
    if (!b.schedule || typeof b.schedule !== "object") {
      return Response.json({ error: "بدنه schedule الزامی است." }, { status: 400 });
    }
    const saved = await saveWorkSchedule(b.schedule as Parameters<typeof saveWorkSchedule>[0]);
    await audit(
      session,
      "UPDATE",
      "SETTINGS",
      "work_schedule",
      `به‌روزرسانی شیفت‌ها و ساعت کاری: روزکار ${saved.daily.start}–${saved.daily.end} (استراحت ${saved.daily.breakMinutes} دقیقه) | صبح ${saved.morning.start}–${saved.morning.end} | عصر/شب ${saved.evening.start}–${saved.evening.end} | تعطیل هفتگی روزکار [${saved.weekend.DAILY.join(",")}] شیفتی [${saved.weekend.SHIFT.join(",")}]`
    );
    return { schedule: saved };
  });
}

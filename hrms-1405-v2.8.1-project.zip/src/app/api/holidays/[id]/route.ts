import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

// ============================================================
// حذف تعطیل — DELETE (attendance:manage)
// ============================================================

export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "attendance:manage");
    const { id } = await ctx.params;
    const row = await db.holiday.findUnique({ where: { id } });
    if (!row) return Response.json({ error: "تعطیل یافت نشد." }, { status: 404 });
    await db.holiday.delete({ where: { id } });
    await audit(session, "DELETE", "HOLIDAY", id, `حذف تعطیل ${row.dateJ} — ${row.title}`);
    return { deleted: true };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth, requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { isValidJalali, jalaliWeekdayIndex, parseJalali } from "@/lib/jalali";
import { JALALI_WEEKDAYS } from "@/lib/jalali";
import {
  getWorkSchedule,
  getHolidaysOfYear,
  getHolidayMap,
  monthDaysInfo,
  computeMonthStats,
  type MonthStats,
} from "@/lib/holidays";

// ============================================================
// تعطیلات رسمی و ساعت استاندارد دوره
//  GET  ?year=1405              → تعطیلات سال + آمار ۱۲ ماه + جدول شیفت‌ها
//  GET  ?year=1405&month=7      → فقط آمار ماه ۷
//  POST (attendance:manage)     → افزودن تعطیل رسمی/سازمانی
//  PATCH (attendance:manage)    → ویرایش تعطیل موجود
// ============================================================

function weekdayNameOf(dateJ: string): string {
  const p = parseJalali(dateJ);
  if (!p) return "";
  return JALALI_WEEKDAYS[jalaliWeekdayIndex(p.jy, p.jm, p.jd)] || "";
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req);
    const url = new URL(req.url);
    const year = +(url.searchParams.get("year") || 0);
    const month = +(url.searchParams.get("month") || 0);
    if (!year) return Response.json({ error: "سال الزامی است." }, { status: 400 });

    const schedule = await getWorkSchedule();
    const holidays = await getHolidaysOfYear(year);

    // آمار همه ۱۲ ماه سال (یا فقط ماه درخواستی)
    const months: MonthStats[] = [];
    const monthRange = month >= 1 && month <= 12 ? [month] : Array.from({ length: 12 }, (_, i) => i + 1);
    for (const m of monthRange) {
      const hmap = await getHolidayMap(year, m);
      const days = monthDaysInfo(year, m, hmap);
      months.push(computeMonthStats(year, m, days, schedule));
    }

    const holidayRows = holidays.map((h) => ({ ...h, weekdayName: weekdayNameOf(h.dateJ) }));
    return { year, holidays: holidayRows, months, schedule };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "attendance:manage");
    const b = (await req.json()) as Record<string, unknown>;
    const dateJ = String(b.dateJ || "").trim();
    const title = String(b.title || "").trim();
    const kind = String(b.kind || "OFFICIAL").toUpperCase() === "CUSTOM" ? "CUSTOM" : "OFFICIAL";
    if (!isValidJalali(dateJ)) return Response.json({ error: "تاریخ جلالی نامعتبر است (مثال ۱۴۰۵/۰۱/۰۱)." }, { status: 400 });
    if (!title) return Response.json({ error: "عنوان مناسبت الزامی است." }, { status: 400 });

    const exists = await db.holiday.findUnique({ where: { dateJ } });
    if (exists) return Response.json({ error: `این تاریخ قبلاً به‌عنوان «${exists.title}» ثبت شده است — ابتدا آن را ویرایش یا حذف کنید.` }, { status: 409 });

    const row = await db.holiday.create({
      data: { dateJ, title: title.slice(0, 160), kind, source: "manual", createdBy: session.fullName },
    });
    await audit(session, "CREATE", "HOLIDAY", row.id, `ثبت تعطیل ${dateJ} — ${title} (${kind === "OFFICIAL" ? "رسمی" : "سازمانی"})`);
    return { holiday: row };
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "attendance:manage");
    const b = (await req.json()) as Record<string, unknown>;
    const id = String(b.id || "");
    if (!id) return Response.json({ error: "شناسه تعطیل الزامی است." }, { status: 400 });
    const row = await db.holiday.findUnique({ where: { id } });
    if (!row) return Response.json({ error: "تعطیل یافت نشد." }, { status: 404 });

    const dateJ = String(b.dateJ || row.dateJ).trim();
    const title = String(b.title || row.title).trim();
    if (!isValidJalali(dateJ)) return Response.json({ error: "تاریخ جلالی نامعتبر است." }, { status: 400 });
    if (!title) return Response.json({ error: "عنوان مناسبت الزامی است." }, { status: 400 });
    if (dateJ !== row.dateJ) {
      const dup = await db.holiday.findUnique({ where: { dateJ } });
      if (dup) return Response.json({ error: "تاریخ جدید قبلاً تعطیل ثبت شده دارد." }, { status: 409 });
    }
    const kind = String(b.kind || row.kind).toUpperCase() === "CUSTOM" ? "CUSTOM" : "OFFICIAL";
    const updated = await db.holiday.update({ where: { id }, data: { dateJ, title: title.slice(0, 160), kind } });
    await audit(session, "UPDATE", "HOLIDAY", id, `ویرایش تعطیل: ${row.dateJ} «${row.title}» ← ${dateJ} «${title}»`);
    return { holiday: updated };
  });
}

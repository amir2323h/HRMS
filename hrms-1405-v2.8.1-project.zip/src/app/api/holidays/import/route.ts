import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { builtinHolidayCatalog, fetchHolidaysFromWeb, type HolidaySeed } from "@/lib/holidays";

// ============================================================
// درون‌ریزی تعطیلات — POST (attendance:manage)
//  { year: 1405 }        → از کتابخانه داخلی (تقویم رسمی ۱۴۰۵)
//  { url: "https://…" }  → از وب‌سرویس خارجی (آرایه JSON از {dateJ, title})
//  { holidays: [...] }   → درون‌ریزی مستقیم فهرست
// همه حالت‌ها upsert هستند: تعطیلات موجود حفظ/به‌روزرسانی می‌شوند (idempotent)
// ============================================================

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "attendance:manage");
    const b = (await req.json().catch(() => ({}))) as Record<string, unknown>;

    let list: HolidaySeed[] = [];
    let sourceLabel = "";
    let sourceKind = "web";

    if (Array.isArray(b.holidays)) {
      // درون‌ریزی مستقیم
      list = (b.holidays as Record<string, unknown>[]).map((h) => ({
        dateJ: String(h.dateJ || ""),
        title: String(h.title || ""),
      }));
      sourceLabel = "درون‌ریزی مستقیم";
    } else if (typeof b.url === "string" && /^https?:\/\//i.test(b.url)) {
      // وب‌سرویس خارجی
      const r = await fetchHolidaysFromWeb(b.url);
      if (!r.ok) return Response.json({ error: r.error }, { status: 502 });
      list = r.holidays;
      sourceLabel = "وب‌سرویس خارجی";
    } else {
      // کتابخانه داخلی
      const year = +(b.year || 0);
      if (!year) return Response.json({ error: "سال یا نشانی وب‌سرویس الزامی است." }, { status: 400 });
      list = builtinHolidayCatalog(year);
      if (list.length === 0) {
        return Response.json(
          { error: `کتابخانه داخلی برای سال ${year} تعطیلی ندارد — از وب‌سرویس استفاده کنید یا تعطیلات را دستی ثبت کنید.` },
          { status: 404 }
        );
      }
      sourceLabel = "کتابخانه داخلی (تقویم رسمی)";
      sourceKind = "seed";
    }

    // پالایش و اعتبارسنجی
    const valid = list.filter((h) => /^\d{4}\/\d{2}\/\d{2}$/.test(h.dateJ) && h.title.trim());
    if (valid.length === 0) return Response.json({ error: "هیچ تعطیل معتبری برای درون‌ریزی یافت نشد." }, { status: 400 });

    let created = 0;
    let updated = 0;
    const touchedYears = new Set<string>();
    for (const h of valid) {
      touchedYears.add(h.dateJ.slice(0, 4));
      const existing = await db.holiday.findUnique({ where: { dateJ: h.dateJ } });
      if (existing) {
        // حفظ عنوان/نوع سفارشی مدیر — فقط تعطیلات منبع seed/web بازنویسی می‌شوند
        if (existing.source === "manual") continue;
        if (existing.title !== h.title) {
          await db.holiday.update({ where: { dateJ: h.dateJ }, data: { title: h.title.slice(0, 160) } });
          updated += 1;
        }
      } else {
        await db.holiday.create({
          data: { dateJ: h.dateJ, title: h.title.slice(0, 160), kind: "OFFICIAL", source: sourceKind, createdBy: session.fullName },
        });
        created += 1;
      }
    }

    await audit(
      session,
      "CREATE",
      "HOLIDAY",
      "import",
      `درون‌ریزی تعطیلات از ${sourceLabel}: ${created} تعطیل جدید، ${updated} به‌روزرسانی (${[...touchedYears].join(", ")})`
    );
    return { created, updated, skipped: valid.length - created - updated, source: sourceLabel, years: [...touchedYears] };
  });
}

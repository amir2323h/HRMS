import { NextRequest } from "next/server";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getBonusConfig, saveBonusConfig, BONUS_CONFIG_DEFAULT } from "@/lib/bonus";

/** پیکربندی پاداش (ماه هر طبقه + تیرها) — ذخیره در تنظیمات، بدون هارد‌کد */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "bonus:view");
    const cfg = await getBonusConfig();
    return { config: cfg };
  });
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "bonus:manage");
    const b = await req.json();
    const cfg = await getBonusConfig();

    // ماه پاداش طبقات ۱..۷
    if (b.levels && typeof b.levels === "object") {
      for (let lv = 1; lv <= 7; lv++) {
        const v = (b.levels as Record<string, unknown>)[String(lv)];
        if (v !== undefined && v !== null) {
          const n = +v;
          if (isNaN(n) || n < 0 || n > 24) {
            return Response.json({ error: `ماه پاداش طبقه ${lv} باید عددی بین ۰ تا ۲۴ باشد.` }, { status: 400 });
          }
          cfg.levels[String(lv)] = n;
        }
      }
    }
    // تیرها
    if (Array.isArray(b.tiers)) {
      for (const t of b.tiers) {
        const idx = cfg.tiers.findIndex((x) => x.key === t.key);
        if (idx === -1) continue;
        if (t.paymentPercent !== undefined) {
          const p = +t.paymentPercent;
          if (isNaN(p) || p < 0 || p > 100) return Response.json({ error: "درصد پرداخت باید بین ۰ تا ۱۰۰ باشد." }, { status: 400 });
          cfg.tiers[idx].paymentPercent = p;
        }
        if (t.extraMonths !== undefined) {
          const m = +t.extraMonths;
          if (isNaN(m) || m < 0 || m > 12) return Response.json({ error: "ماه پاداش اضافه باید بین ۰ تا ۱۲ باشد." }, { status: 400 });
          cfg.tiers[idx].extraMonths = m;
        }
        if (t.minRatio !== undefined) {
          const r = +t.minRatio;
          if (isNaN(r) || r < 0 || r > 10) return Response.json({ error: "حداقل نسبت تحقق نامعتبر است." }, { status: 400 });
          cfg.tiers[idx].minRatio = r;
        }
      }
    }
    await saveBonusConfig(cfg);
    await audit(session, "UPDATE", "SETTINGS", "bonus_config", "به‌روزرسانی پیکربندی پاداش (طبقات و تیرها)", undefined, cfg);
    return { config: cfg };
  });
}

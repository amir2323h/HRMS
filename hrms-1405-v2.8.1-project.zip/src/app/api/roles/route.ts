import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { ALL_PERMISSIONS, DEFAULT_ROLES } from "@/lib/permissions";

/** نقش‌ها و مجوزها — GET (مشاهده) / POST (ساخت، roles:manage) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req);
    let roles = await db.role.findMany({ orderBy: { createdAt: "asc" } });
    if (roles.length === 0) {
      // بذر نقش‌های سیستمی در اولین بارگذاری
      for (const r of DEFAULT_ROLES) {
        await db.role.create({
          data: { key: r.key, name: r.name, description: r.description, permissions: JSON.stringify(r.permissions), isSystem: true },
        });
      }
      roles = await db.role.findMany({ orderBy: { createdAt: "asc" } });
    }
    const counts = await db.user.groupBy({ by: ["roleId"], _count: { roleId: true } });
    const countMap = new Map(counts.map((c) => [c.roleId, c._count.roleId]));
    return {
      roles: roles.map((r) => ({
        id: r.id,
        key: r.key,
        name: r.name,
        description: r.description,
        isSystem: r.isSystem,
        permissions: JSON.parse(r.permissions) as string[],
        userCount: countMap.get(r.id) || 0,
        createdAt: r.createdAt,
      })),
      catalog: ALL_PERMISSIONS,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "roles:manage");
    const b = await req.json();
    const key = String(b.key || "").trim().toUpperCase().replace(/[^A-Z0-9_]/g, "_");
    const name = String(b.name || "").trim();
    const perms = Array.isArray(b.permissions) ? b.permissions.filter((p: string) => typeof p === "string") : [];
    if (!key || !name) return Response.json({ error: "کلید و نام نقش الزامی است." }, { status: 400 });
    if (key.length < 2 || key.length > 40) return Response.json({ error: "کلید نقش باید ۲ تا ۴۰ نویسه باشد." }, { status: 400 });
    const dup = await db.role.findUnique({ where: { key } });
    if (dup) return Response.json({ error: "کلید نقش تکراری است." }, { status: 400 });
    const role = await db.role.create({
      data: {
        key,
        name,
        description: String(b.description || ""),
        permissions: JSON.stringify(perms.includes("*") ? ["*"] : perms),
        isSystem: false,
      },
    });
    await audit(session, "CREATE", "ROLE", role.id, `ایجاد نقش «${name}» با ${toFa(perms.length)} مجوز`);
    return { role: { ...role, permissions: perms } };
  });
}

function toFa(n: number): string {
  return String(n).replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
}

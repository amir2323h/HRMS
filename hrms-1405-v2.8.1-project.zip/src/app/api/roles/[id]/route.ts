import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

/** ویرایش/حذف نقش — PATCH/DELETE (roles:manage) */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "roles:manage");
    const { id } = await params;
    const b = await req.json();
    const role = await db.role.findUnique({ where: { id } });
    if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 404 });

    const data: Record<string, unknown> = {};
    if (b.name !== undefined) {
      const name = String(b.name).trim();
      if (!name) return Response.json({ error: "نام نقش الزامی است." }, { status: 400 });
      data.name = name;
    }
    if (b.description !== undefined) data.description = String(b.description);
    if (b.permissions !== undefined && Array.isArray(b.permissions)) {
      if (role.key === "SUPER_ADMIN" && !b.permissions.includes("*")) {
        return Response.json({ error: "نقش مدیر کل باید دسترسی کامل (*) داشته باشد." }, { status: 400 });
      }
      const perms = b.permissions.filter((p: string) => typeof p === "string");
      data.permissions = JSON.stringify(perms.includes("*") ? ["*"] : perms);
    }
    if (Object.keys(data).length === 0) return Response.json({ error: "چیزی برای ویرایش نیست." }, { status: 400 });

    const updated = await db.role.update({ where: { id }, data });
    await audit(session, "UPDATE", "ROLE", id, `ویرایش نقش «${updated.name}»`, { permissions: role.permissions }, { permissions: updated.permissions });
    return { role: { ...updated, permissions: JSON.parse(updated.permissions) } };
  });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "roles:manage");
    const { id } = await params;
    const role = await db.role.findUnique({ where: { id } });
    if (!role) return Response.json({ error: "نقش یافت نشد." }, { status: 404 });
    if (role.isSystem) return Response.json({ error: "نقش‌های سیستمی قابل حذف نیستند." }, { status: 400 });
    const users = await db.user.count({ where: { roleId: id } });
    if (users > 0) return Response.json({ error: `این نقش به ${users} کاربر اختصاص دارد — ابتدا نقش کاربران را تغییر دهید.` }, { status: 400 });
    await db.role.delete({ where: { id } });
    await audit(session, "DELETE", "ROLE", id, `حذف نقش «${role.name}»`);
    return { ok: true };
  });
}

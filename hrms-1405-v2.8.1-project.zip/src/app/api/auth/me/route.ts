import { NextRequest } from "next/server";
import { handle } from "@/lib/api-helpers";
import { getSessionFromRequest } from "@/lib/auth";

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = getSessionFromRequest(req);
    if (!session) return { user: null };
    return {
      user: {
        uid: session.uid,
        username: session.username,
        fullName: session.fullName,
        role: session.role,
        roleName: session.roleName,
        perms: session.perms,
        employeeId: session.employeeId,
      },
    };
  });
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { signSession, verifyPassword, SESSION_COOKIE, sessionCookieOptions, buildSessionForUser } from "@/lib/auth";
import { handle, audit, clientIp } from "@/lib/api-helpers";
import { get2faEnabled } from "@/lib/settings";
import { generateTotpSecret, verifyTotp, otpauthUrl, isValidTotpSecret } from "@/lib/totp";

/**
 * ورود با نام کاربری/رمز — با پشتیبانی ورود دو مرحله‌ای (2FA/TOTP):
 *  ۱) 2FA خاموش → رفتار قبلی (ورود مستقیم)
 *  ۲) 2FA فعال + کاربر ثبت‌نام‌نشده → پاسخ { enroll, secret, otpauthUrl } —
 *     کلاینت QR/راز را نشان می‌دهد و کاربر با اولین کد موفق ثبت‌نام می‌کند
 *  ۳) 2FA فعال + ثبت‌نام‌شده → بدون totp: { need2fa } — با totp: راستی‌آزمایی و ورود
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const body = await req.json().catch(() => ({}));
    const username = String(body.username || "").trim().toLowerCase();
    const password = String(body.password || "");
    const totp = String(body.totp || "").replace(/\D/g, "");
    if (!username || !password) {
      return NextResponse.json({ error: "نام کاربری و رمز عبور الزامی است." }, { status: 400 });
    }
    const user = await db.user.findUnique({ where: { username } });
    if (!user || !user.isActive || !verifyPassword(password, user.passwordHash)) {
      return NextResponse.json({ error: "نام کاربری یا رمز عبور نادرست است." }, { status: 401 });
    }

    // ---------- مرحله ۲: ورود دو مرحله‌ای ----------
    const twoFa = await get2faEnabled();
    if (twoFa) {
      const enrolled = !!user.totpEnrolledAt && isValidTotpSecret(user.totpSecret);
      if (!enrolled) {
        // ثبت‌نام 2FA: اگر راز معتبری وجود ندارد، تولید و ذخیره می‌شود؛
        // تا تأیید اولین کد، کاربر وارد نشده و راز قابل تعویض است
        if (!isValidTotpSecret(user.totpSecret)) {
          const secret = generateTotpSecret();
          await db.user.update({ where: { id: user.id }, data: { totpSecret: secret, totpEnrolledAt: null } });
          user.totpSecret = secret;
        }
        if (!totp) {
          return NextResponse.json({
            enroll: true,
            username: user.username,
            secret: user.totpSecret,
            otpauthUrl: otpauthUrl(user.totpSecret, user.username, "HRMS"),
          });
        }
        // کد ثبت‌نام: با موفقیت، 2FA برای این کاربر فعال می‌شود
        if (!verifyTotp(user.totpSecret, totp)) {
          return NextResponse.json({ error: "کد تأیید نادرست است — از اپ احرازکننده کد جدید بگیرید." , enroll: true, username: user.username, secret: user.totpSecret, otpauthUrl: otpauthUrl(user.totpSecret, user.username, "HRMS") }, { status: 401 });
        }
        await db.user.update({ where: { id: user.id }, data: { totpEnrolledAt: new Date() } });
        await audit(
          { uid: user.id, username: user.username, fullName: user.fullName, role: user.role, perms: [], exp: 0 },
          "UPDATE",
          "USER",
          user.id,
          `فعال‌سازی ورود دو مرحله‌ای (2FA) برای ${user.fullName} (${user.username})`
        );
      } else {
        // ثبت‌نام‌شده: بدون کد → درخواست کد؛ با کد → راستی‌آزمایی
        if (!totp) {
          return NextResponse.json({ need2fa: true, username: user.username });
        }
        if (!verifyTotp(user.totpSecret, totp)) {
          return NextResponse.json({ error: "کد تأیید نادرست است — از اپ احرازکننده کد جدید بگیرید.", need2fa: true, username: user.username }, { status: 401 });
        }
      }
    }

    await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });

    const sessionData = await buildSessionForUser(user);
    const token = signSession(sessionData);
    const res = NextResponse.json({
      user: {
        uid: sessionData.uid,
        username: sessionData.username,
        fullName: sessionData.fullName,
        role: sessionData.role,
        roleName: sessionData.roleName,
        perms: sessionData.perms,
        employeeId: sessionData.employeeId,
      },
      // توکن نشست در بدنه — برای ذخیره سمت کلاینت (حالت iframe که کوکی مسدود می‌شود)
      token,
    });
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(req));
    await audit(
      { ...sessionData, exp: 0 },
      "LOGIN",
      "USER",
      user.id,
      `ورود موفق کاربر ${user.fullName} (${user.username})${twoFa ? " — با ورود دو مرحله‌ای" : ""}`,
      undefined,
      undefined
    );
    void clientIp(req);
    return res;
  });
}

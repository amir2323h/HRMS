import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { handle } from "@/lib/api-helpers";
import { getMattermostConfig, mattermostReady, buildAuthorizeUrl, callbackUrlFromRequest, STATE_COOKIE, STATE_TTL_SEC } from "@/lib/mattermost";

/** مرحله ۱ — ساخت آدرس مجوز + state ضد CSRF (ذخیره در کوکی کوتاه‌مدت) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const cfg = await getMattermostConfig();
    if (!mattermostReady(cfg)) {
      return NextResponse.json({ error: "ورود با Mattermost پیکربندی نشده است." }, { status: 400 });
    }
    const state = randomBytes(16).toString("hex");
    // مسیر فال‌بک: اگر تنظیم شده از آن استفاده می‌شود (وگرنه از هدرهای درخواست)
    const redirectUri = callbackUrlFromRequest(req, cfg);
    const url = buildAuthorizeUrl(cfg, redirectUri, state);
    const res = NextResponse.json({ url });
    res.cookies.set(STATE_COOKIE, state, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: STATE_TTL_SEC,
    });
    return res;
  });
}

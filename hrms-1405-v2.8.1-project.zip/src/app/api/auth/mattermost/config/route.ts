import { NextRequest } from "next/server";
import { handle } from "@/lib/api-helpers";
import { getMattermostConfig, mattermostReady } from "@/lib/mattermost";

/** پیکربندی عمومی دکمه ورود Mattermost — بدون افشای راز */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const cfg = await getMattermostConfig();
    return {
      enabled: mattermostReady(cfg),
      buttonLabel: cfg.buttonLabel,
      serverUrl: cfg.serverUrl,
    };
  });
}

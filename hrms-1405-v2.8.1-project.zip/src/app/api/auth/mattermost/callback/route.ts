import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { db } from "@/lib/db";
import { signSession, SESSION_COOKIE, sessionCookieOptions, hashPassword, buildSessionForUser } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getMattermostConfig, mattermostReady, exchangeMattermostToken, fetchMattermostUser, callbackUrlFromRequest, STATE_COOKIE } from "@/lib/mattermost";

/**
 * مرحله ۲ و ۳ — callback رسمی OAuth 2.0:
 *  code ↔ access_token ↔ پروفایل /api/v4/users/me
 * سپس: اتصال/ساخت کاربر + نشست (کوکی + Bearer توکن برای کلاینت)
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const cfg = await getMattermostConfig();
    if (!mattermostReady(cfg)) {
      return errorPage("ورود با Mattermost پیکربندی نشده است.");
    }
    const { searchParams } = new URL(req.url);
    const code = searchParams.get("code") || "";
    const state = searchParams.get("state") || "";
    const oauthError = searchParams.get("error") || "";

    if (oauthError) return errorPage(`Mattermost اجازه نداد: ${oauthError}`);
    if (!code) return errorPage("کد مجوز از Mattermost دریافت نشد.");

    // اعتبارسنجی state ضد CSRF
    const cookieState = req.cookies.get(STATE_COOKIE)?.value;
    if (!state || !cookieState || state !== cookieState) {
      return errorPage("نشست ورود منقضی یا نامعتبر است — دوباره تلاش کنید.");
    }

    let mmUser;
    try {
      // همان مسیر فال‌بک مرحله مجوز — redirect_uri در تبادل توکن باید یکسان باشد
      const redirectUri = callbackUrlFromRequest(req, cfg);
      const token = await exchangeMattermostToken(cfg, code, redirectUri);
      mmUser = await fetchMattermostUser(cfg, token.access_token);
    } catch (e) {
      return errorPage(e instanceof Error ? e.message : "خطا در ارتباط با Mattermost.");
    }
    if (!mmUser?.id || !mmUser?.username) return errorPage("پروفایل Mattermost نامعتبر است.");

    // یافتن کاربر: اتصال موجود → ایمیل → ساخت خودکار
    let user = await db.user.findFirst({ where: { oauthProvider: "mattermost", oauthId: mmUser.id } });
    if (!user && mmUser.email) {
      const byEmail = await db.user.findFirst({ where: { oauthEmail: mmUser.email } });
      if (byEmail) user = byEmail;
    }
    if (!user) {
      // تطبیق با ایمیل پروفایل کارکنان (اتصال به پرونده کارمندی)
      let employeeId: string | null = null;
      if (mmUser.email) {
        const emp = await db.employee.findFirst({ where: { email: mmUser.email } });
        if (emp) employeeId = emp.id;
      }
      if (!cfg.autoCreate) {
        return errorPage("حساب کاربری مرتبطی یافت نشد و ساخت خودکار غیرفعال است.");
      }
      const roleKey = cfg.defaultRoleKey || "EMPLOYEE";
      const role = await db.role.findUnique({ where: { key: roleKey } });
      if (!role) return errorPage(`نقش پیش‌فرض «${roleKey}» یافت نشد.`);
      // نام کامل از پروفایل Mattermost
      const fullName = [mmUser.first_name, mmUser.last_name].filter(Boolean).join(" ").trim() || mmUser.username;
      // نام کاربری یکتا — در صورت تکرار پسوند عددی
      let username = mmUser.username.toLowerCase().replace(/[^a-z0-9_.-]/g, "");
      if (username.length < 3) username = `mm_${mmUser.id.slice(0, 8)}`;
      let candidate = username;
      for (let i = 1; await db.user.findUnique({ where: { username: candidate } }); i++) {
        candidate = `${username}${i}`;
      }
      user = await db.user.create({
        data: {
          username: candidate,
          passwordHash: hashPassword(randomBytes(24).toString("hex")), // رمز تصادفی — ورود فقط با OAuth
          fullName,
          role: role.key,
          roleId: role.id,
          employeeId,
          isActive: true,
          oauthProvider: "mattermost",
          oauthId: mmUser.id,
          oauthEmail: mmUser.email || "",
          oauthName: fullName,
        },
      });
    } else {
      // به‌روزرسانی اطلاعات اتصال
      user = await db.user.update({
        where: { id: user.id },
        data: {
          oauthProvider: "mattermost",
          oauthId: mmUser.id,
          oauthEmail: mmUser.email || user.oauthEmail,
          oauthName: [mmUser.first_name, mmUser.last_name].filter(Boolean).join(" ").trim() || user.oauthName,
          lastLoginAt: new Date(),
        },
      });
    }
    if (!user.isActive) return errorPage("حساب کاربری شما غیرفعال است.");

    const sessionData = await buildSessionForUser(user);
    const token = signSession(sessionData);
    await audit(
      { ...sessionData, exp: 0 },
      "LOGIN",
      "USER",
      user.id,
      `ورود یکپارانه با Mattermost — ${user.fullName} (${user.username})`,
      undefined,
      undefined
    );

    // پاسخ HTML: ذخیره توکن Bearer در localStorage (حالت iframe) + کوکی نشست + بازگشت به برنامه
    const safeToken = token.replace(/</g, "\\u003c");
    const html = `<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>ورود موفق</title>
<style>
body { font-family: system-ui, Tahoma, sans-serif; background: #0f766e; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
.box { text-align: center; }
.spin { width: 42px; height: 42px; border: 4px solid #ffffff44; border-top-color: #fff; border-radius: 50%; animation: r 1s linear infinite; margin: 0 auto 18px; }
@keyframes r { to { transform: rotate(360deg); } }
</style></head>
<body><div class="box"><div class="spin"></div><p>ورود موفق — در حال بازگشت به سامانه…</p></div>
<script>
try { localStorage.setItem('hrms_token', '${safeToken}'); } catch (e) {}
try { localStorage.setItem('hrms_auth', 'login'); } catch (e) {}
location.replace('/');
</script>
</body></html>`;
    const res = new NextResponse(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
    res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(req));
    res.cookies.delete(STATE_COOKIE);
    return res;
  });
}

function errorPage(message: string): NextResponse {
  const safe = message.replace(/</g, "&lt;").replace(/'/g, "\\'");
  const html = `<!DOCTYPE html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>خطای ورود</title></head>
<body>
<script>
try { localStorage.setItem('hrms_mm_error', '${safe}'); } catch (e) {}
location.replace('/');
</script>
</body></html>`;
  return new NextResponse(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}

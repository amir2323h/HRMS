import { NextRequest } from "next/server";
import { handle } from "@/lib/api-helpers";
import { getGoogleConfig, googleReady } from "@/lib/google-oauth";

/** پیکربندی عمومی دکمه ورود گوگل — بدون افشای راز */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const cfg = await getGoogleConfig();
    return {
      enabled: googleReady(cfg),
      buttonLabel: cfg.buttonLabel,
      allowedDomain: cfg.allowedDomain,
    };
  });
}

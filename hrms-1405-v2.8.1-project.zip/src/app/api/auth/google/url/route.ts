import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "crypto";
import { handle } from "@/lib/api-helpers";
import { getGoogleConfig, googleReady, buildGoogleAuthorizeUrl, googleCallbackUrlFromRequest, GOOGLE_STATE_COOKIE, GOOGLE_STATE_TTL_SEC } from "@/lib/google-oauth";

/** مرحله ۱ — ساخت آدرس مجوز گوگل + state ضد CSRF (ذخیره در کوکی کوتاه‌مدت) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const cfg = await getGoogleConfig();
    if (!googleReady(cfg)) {
      return NextResponse.json({ error: "ورود با گوگل پیکربندی نشده است." }, { status: 400 });
    }
    const state = randomBytes(16).toString("hex");
    // مسیر فال‌بک: اگر تنظیم شده از آن استفاده می‌شود (وگرنه از هدرهای درخواست)
    const redirectUri = googleCallbackUrlFromRequest(req, cfg);
    const url = buildGoogleAuthorizeUrl(cfg, redirectUri, state);
    const res = NextResponse.json({ url });
    res.cookies.set(GOOGLE_STATE_COOKIE, state, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: GOOGLE_STATE_TTL_SEC,
    });
    return res;
  });
}

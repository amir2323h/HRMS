import { NextRequest, NextResponse } from "next/server";
import { SESSION_COOKIE, sessionCookieOptions, getSessionFromRequest } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = getSessionFromRequest(req);
    if (session) {
      await audit(session, "LOGOUT", "USER", session.uid, `خروج کاربر ${session.fullName}`);
    }
    const res = NextResponse.json({ ok: true });
    const opts = sessionCookieOptions(req);
    res.cookies.set(SESSION_COOKIE, "", { ...opts, maxAge: 0 });
    return res;
  });
}

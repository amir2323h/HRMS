import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { get2faEnabled, save2faEnabled } from "@/lib/settings";

/** تنظیمات ورود دو مرحله‌ای (2FA) — GET (settings:view) / PUT (settings:manage)
 *  آمار ثبت‌نام برای نمایش وضعیت کاربران در کارت تنظیمات */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "settings:view");
    const enabled = await get2faEnabled();
    const [total, enrolled] = await Promise.all([
      db.user.count({ where: { isActive: true } }),
      db.user.count({ where: { isActive: true, totpEnrolledAt: { not: null } } }),
    ]);
    return { enabled, enrolled, total };
  });
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:manage");
    const b = await req.json();
    const enabled = !!b.enabled;
    await save2faEnabled(enabled);
    // آمار پس از تغییر
    const [total, enrolled] = await Promise.all([
      db.user.count({ where: { isActive: true } }),
      db.user.count({ where: { isActive: true, totpEnrolledAt: { not: null } } }),
    ]);
    await audit(
      session,
      "UPDATE",
      "SETTINGS",
      "auth_2fa",
      `ورود دو مرحله‌ای (2FA) ${enabled ? "فعال" : "غیرفعال"} شد — کاربران فعال: ${enrolled}/${total} ثبت‌نام‌شده`,
      undefined,
      { enabled, enrolled, total }
    );
    return { enabled, enrolled, total };
  });
}

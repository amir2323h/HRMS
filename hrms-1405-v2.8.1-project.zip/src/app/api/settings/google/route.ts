import { NextRequest } from "next/server";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getGoogleConfig, saveGoogleConfig } from "@/lib/google-oauth";
import { hasPerm } from "@/lib/permissions";

/** پیکربندی ورود گوگل — GET (settings:view) / PUT (settings:manage) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:view");
    const cfg = await getGoogleConfig();
    // Client Secret فقط برای مدیران کامل
    if (!hasPerm(session.perms, "settings:manage")) {
      return { config: { ...cfg, clientSecret: cfg.clientSecret ? "••••••" : "" } };
    }
    return { config: cfg };
  });
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:manage");
    const b = await req.json();
    const patch: Record<string, unknown> = {};
    if (b.enabled !== undefined) patch.enabled = !!b.enabled;
    if (b.clientId !== undefined) patch.clientId = String(b.clientId).trim();
    if (b.clientSecret !== undefined && b.clientSecret !== "••••••") patch.clientSecret = String(b.clientSecret).trim();
    if (b.autoCreate !== undefined) patch.autoCreate = !!b.autoCreate;
    if (b.defaultRoleKey !== undefined) patch.defaultRoleKey = String(b.defaultRoleKey).trim() || "EMPLOYEE";
    if (b.buttonLabel !== undefined) patch.buttonLabel = String(b.buttonLabel).trim() || "ورود با Gmail";
    if (b.allowedDomain !== undefined) patch.allowedDomain = String(b.allowedDomain).trim().toLowerCase().replace(/^@/, "");
    if (b.callbackBaseUrl !== undefined) {
      const v = String(b.callbackBaseUrl).trim();
      if (v && !/^https?:\/\/[^\s\/]+\/?$/i.test(v)) {
        return Response.json({ error: "آدرس فال‌بک Callback نامعتبر است — نمونه صحیح: https://hr.example.com" }, { status: 400 });
      }
      patch.callbackBaseUrl = v.replace(/\/+$/, "");
    }
    const cfg = await saveGoogleConfig(patch);
    await audit(
      session,
      "UPDATE",
      "SETTINGS",
      "google_oauth",
      `پیکربندی ورود گوگل ${cfg.enabled ? "فعال" : "غیرفعال"} شد${cfg.allowedDomain ? ` (دامنه: ${cfg.allowedDomain})` : ""}`,
      undefined,
      { enabled: cfg.enabled, clientId: cfg.clientId, callbackBaseUrl: cfg.callbackBaseUrl, allowedDomain: cfg.allowedDomain }
    );
    return { config: cfg };
  });
}

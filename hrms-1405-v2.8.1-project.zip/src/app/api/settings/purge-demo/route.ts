import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { purgeDemoData } from "@/lib/purge";

// ============================================================
// پاک‌سازی داده نمونه — فقط مدیر کل (مجوز «*»)
//   POST { confirm: "PURGE", full?: boolean }
// حالت demo: حذف کارکنان/فیش‌ها/دوره‌ها/درخواست‌ها/نامه‌ها/قراردادها/پاداش
// حالت full: + دپارتمان‌ها/مشاغل/رفاهیات/قالب‌ها/کاربران غیر ادمین/لاگ
// همیشه حفظ: تنظیمات، نقش‌ها، طبقه ۷ سطحی، پله‌های مالیاتی، یک مدیر کل
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "*");
    const [employees, payslips, periods, contracts, letters, requests, bonus, departments, jobTitles, users, auditLogs] =
      await Promise.all([
        db.employee.count(),
        db.payslip.count(),
        db.payrollPeriod.count(),
        db.contract.count(),
        db.letterRequest.count(),
        db.leaveRequest.count(),
        db.bonusScheme.count(),
        db.department.count(),
        db.jobTitle.count(),
        db.user.count(),
        db.auditLog.count(),
      ]);
    return { counts: { employees, payslips, periods, contracts, letters, requests, bonus, departments, jobTitles, users, auditLogs } };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "*");
    const b = await req.json().catch(() => ({}));
    if (String(b.confirm || "") !== "PURGE") {
      return Response.json(
        { error: "برای اجرای پاک‌سازی، عبارت تأیید «PURGE» الزامی است — عملیات انجام نشد." },
        { status: 400 }
      );
    }
    const full = !!b.full;
    const counts = await purgeDemoData({ full });
    // لاگ حسابرسی — بعد از پاک‌سازی نوشته می‌شود تا حتی در حالت full ردپای عملیات باقی بماند
    const pieces = [
      `${counts.employees} کارمند`,
      `${counts.payslips} فیش`,
      `${counts.periods} دوره`,
      `${counts.contracts} قرارداد`,
      `${counts.letters} نامه`,
      `${counts.leaveRequests + counts.advanceRequests} درخواست`,
      `${counts.bonusSchemes} طرح پاداش`,
    ];
    if (full) {
      pieces.push(
        `${counts.departments || 0} دپارتمان`,
        `${counts.jobTitles || 0} عنوان شغلی`,
        `${counts.users || 0} کاربر غیر مدیر کل`,
        `${counts.auditLogs || 0} رکورد لاگ`
      );
    }
    await audit(
      session,
      "DELETE",
      "SYSTEM",
      "demo-data",
      `پاک‌سازی داده نمونه (${full ? "کامل" : "استاندارد"}) — حذف: ${pieces.join("، ")}`,
      { mode: "before" },
      { mode: full ? "full" : "demo", at: counts.at }
    );
    return { ok: true, counts };
  });
}

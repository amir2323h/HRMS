import { NextRequest } from "next/server";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import {
  restoreFromStaging,
  stageExistingBackup,
  stageUploadedBytes,
  cleanupStaging,
  type ValidationInfo,
  type BackupFile,
} from "@/lib/backup";

// ============================================================
// بازیابی داده‌های پنل از پشتیبان — فقط مدیر کل (مجوز «*»)
// دو حالت ورودی:
//   multipart/form-data  (فیلد file: فایل .db آپلودی)
//   application/json     ({ file: "hrms-backup-….db" } — از فهرست پشتیبان‌ها)
// جریان ایمن:
//   اعتبارسنجی کامل → پشتیبان خودکار از وضعیت فعلی (pre-restore) →
//   جایگزینی اتمی فایل → کلاینت تازه (بدون ری‌استارت سرویس)
// پس از بازیابی، اگر کاربر فعلی در پشتیبان نباشد، نشست‌ها بی‌اعتبار
// می‌شوند و کاربر باید دوباره وارد شود.
// ============================================================

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "*");
    const contentType = req.headers.get("content-type") || "";

    let staging: string | null = null;
    let sourceLabel = "";
    try {
      // ---------- ۱) آماده‌سازی فایل staging ----------
      if (contentType.includes("multipart/form-data")) {
        const form = await req.formData();
        const file = form.get("file");
        if (!(file instanceof File)) {
          return Response.json({ error: "فایل پشتیبان ارسال نشده است." }, { status: 400 });
        }
        if (file.size === 0) {
          return Response.json({ error: "فایل ارسالی خالی است." }, { status: 400 });
        }
        if (file.size > 500 * 1024 * 1024) {
          return Response.json({ error: "حجم فایل پشتیبان بیش از حد مجاز است (۵۰۰ مگابایت)." }, { status: 400 });
        }
        const bytes = new Uint8Array(await file.arrayBuffer());
        staging = stageUploadedBytes(bytes);
        sourceLabel = file.name || "فایل آپلودی";
      } else {
        const b = await req.json().catch(() => ({}));
        const name = String((b as { file?: unknown }).file || "");
        if (!name) {
          return Response.json({ error: "نام فایل پشتیبان مشخص نشده است." }, { status: 400 });
        }
        staging = stageExistingBackup(name);
        sourceLabel = name;
      }

      // ---------- ۲) بازیابی ایمن ----------
      const { safety, validation }: { safety: BackupFile; validation: ValidationInfo } = await restoreFromStaging(staging);
      staging = null; // فایل staging با rename مصرف شد

      // ---------- ۳) لاگ حسابرسی روی دیتابیس بازیابی‌شده ----------
      await audit(
        session,
        "POST",
        "SYSTEM",
        "backup-restore",
        `بازیابی داده‌های پنل از پشتیبان (${sourceLabel}) — ${validation.employees} کارمند، ${validation.users} کاربر؛ پشتیبان ایمنی: ${safety.name}`,
        undefined,
        { source: sourceLabel, safety: safety.name, validation }
      );

      return {
        ok: true,
        safety,
        validation,
        source: sourceLabel,
      };
    } catch (e) {
      cleanupStaging(staging);
      const message = e instanceof Error ? e.message : "خطا در بازیابی پشتیبان";
      return Response.json({ error: `بازیابی انجام نشد — داده‌های فعلی دست‌نخورده ماند. (${message})` }, { status: 400 });
    }
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { createBackup, listBackups, deleteBackup, dbFilePath, backupsDir, MAX_BACKUPS } from "@/lib/backup";
import * as fs from "node:fs";

// ============================================================
// پشتیبان‌گیری داده‌های پنل — فقط مدیر کل (مجوز «*»)
//   GET               فهرست پشتیبان‌ها + وضعیت دیتابیس
//   POST              ایجاد پشتیبان تازه (اسنپ‌شات VACUUM — بدون توقف سرویس)
//   DELETE ?file=     حذف یک فایل پشتیبان
// فایل‌ها در <پوشه دیتابیس>/backups — حداکثر ۱۰ نسخه نگه داشته می‌شود
// ============================================================

function diskSize(file: string): number {
  try {
    return fs.statSync(file).size;
  } catch {
    return 0;
  }
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "*");
    const backups = listBackups();
    const dbPath = dbFilePath();
    return {
      dbPath,
      dbSizeBytes: diskSize(dbPath),
      backupsDir: backupsDir(),
      backups,
      backupCount: backups.length,
      totalBackupBytes: backups.reduce((s, b) => s + b.sizeBytes, 0),
      maxBackups: MAX_BACKUPS,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "*");
    const backup = await createBackup();
    await audit(
      session,
      "POST",
      "SYSTEM",
      "backup",
      `پشتیبان‌گیری دستی از داده‌های پنل — فایل ${backup.name} (${Math.round(backup.sizeBytes / 1024)}KB)`,
      undefined,
      { name: backup.name, sizeBytes: backup.sizeBytes }
    );
    return { ok: true, backup };
  });
}

export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "*");
    const name = req.nextUrl.searchParams.get("file") || "";
    try {
      const info = deleteBackup(name);
      await audit(
        session,
        "DELETE",
        "SYSTEM",
        "backup",
        `حذف فایل پشتیبان ${info.name}`,
        { name: info.name },
        undefined
      );
      return { ok: true };
    } catch (e) {
      const message = e instanceof Error ? e.message : "خطا در حذف فایل پشتیبان";
      return Response.json({ error: message }, { status: 400 });
    }
  });
}

import { NextRequest, NextResponse } from "next/server";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { readBackup } from "@/lib/backup";

// ============================================================
// دانلود فایل پشتیبان — فقط مدیر کل (مجوز «*»)
//   GET ?file=hrms-backup-….db
// پاسخ: application/octet-stream + Content-Disposition attachment
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "*");
    const name = req.nextUrl.searchParams.get("file") || "";
    let bytes: Uint8Array;
    let sizeBytes = 0;
    try {
      const r = readBackup(name);
      bytes = r.bytes;
      sizeBytes = r.info.sizeBytes;
    } catch (e) {
      const message = e instanceof Error ? e.message : "خطا در خواندن فایل پشتیبان";
      return Response.json({ error: message }, { status: 400 });
    }
    await audit(
      session,
      "GET",
      "SYSTEM",
      "backup",
      `دانلود فایل پشتیبان ${name} (${Math.round(sizeBytes / 1024)}KB)`,
      undefined,
      { name, sizeBytes }
    );
    return new NextResponse(bytes as unknown as BodyInit, {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${name}"`,
        "Content-Length": String(sizeBytes),
        "Cache-Control": "no-store",
      },
    });
  });
}

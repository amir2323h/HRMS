import { NextRequest } from "next/server";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { getMattermostConfig, saveMattermostConfig } from "@/lib/mattermost";
import { hasPerm } from "@/lib/permissions";

/** پیکربندی Mattermost — GET (settings:view) / PUT (settings:manage) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:view");
    const cfg = await getMattermostConfig();
    // Client Secret فقط برای مدیران کامل
    if (!hasPerm(session.perms, "settings:manage")) {
      return { config: { ...cfg, clientSecret: cfg.clientSecret ? "••••••" : "" } };
    }
    return { config: cfg };
  });
}

export async function PUT(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "settings:manage");
    const b = await req.json();
    const patch: Record<string, unknown> = {};
    if (b.enabled !== undefined) patch.enabled = !!b.enabled;
    if (b.serverUrl !== undefined) patch.serverUrl = String(b.serverUrl).trim();
    if (b.clientId !== undefined) patch.clientId = String(b.clientId).trim();
    if (b.clientSecret !== undefined && b.clientSecret !== "••••••") patch.clientSecret = String(b.clientSecret).trim();
    if (b.autoCreate !== undefined) patch.autoCreate = !!b.autoCreate;
    if (b.defaultRoleKey !== undefined) patch.defaultRoleKey = String(b.defaultRoleKey).trim() || "EMPLOYEE";
    if (b.buttonLabel !== undefined) patch.buttonLabel = String(b.buttonLabel).trim() || "ورود با Mattermost";
    if (b.callbackBaseUrl !== undefined) {
      const v = String(b.callbackBaseUrl).trim();
      if (v && !/^https?:\/\/[^\s\/]+\/?$/i.test(v)) {
        return Response.json({ error: "آدرس فال‌بک Callback نامعتبر است — نمونه صحیح: https://hr.example.com" }, { status: 400 });
      }
      patch.callbackBaseUrl = v.replace(/\/+$/, "");
    }
    const cfg = await saveMattermostConfig(patch);
    await audit(
      session,
      "UPDATE",
      "SETTINGS",
      "mattermost",
      `پیکربندی ورود Mattermost ${cfg.enabled ? "فعال" : "غیرفعال"} شد (سرور: ${cfg.serverUrl || "—"})`,
      undefined,
      { enabled: cfg.enabled, serverUrl: cfg.serverUrl, clientId: cfg.clientId, callbackBaseUrl: cfg.callbackBaseUrl }
    );
    return { config: cfg };
  });
}

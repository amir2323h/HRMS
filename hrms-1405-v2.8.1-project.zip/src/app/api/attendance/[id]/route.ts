import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

/** حذف رکورد تردد — attendance:manage */
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "attendance:manage");
    const { id } = await params;
    const row = await db.attendanceRecord.findUnique({ where: { id }, include: { employee: { select: { personnelCode: true } } } });
    if (!row) return Response.json({ error: "رکورد یافت نشد." }, { status: 404 });
    await db.attendanceRecord.delete({ where: { id } });
    await audit(session, "DELETE", "ATTENDANCE", id, `حذف تردد ${row.dateJ} (${row.employee?.personnelCode || "—"})`);
    return { ok: true };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { serializePayslip } from "@/lib/serializers";
import { getCompanyInfo, getLegalParams } from "@/lib/settings";

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requireAuth(req);
    const { id } = await ctx.params;
    const payslip = await db.payslip.findUnique({
      where: { id },
      include: { employee: { include: { jobGrade: true, departments: { include: { department: true } } } }, period: true },
    });
    if (!payslip) return Response.json({ error: "فیش یافت نشد." }, { status: 404 });

    // کارمند فقط فیش خودش را می‌بیند
    if (session.role === "EMPLOYEE" && session.employeeId !== payslip.employeeId) {
      return Response.json({ error: "دسترسی غیرمجاز." }, { status: 403 });
    }

    const [company, legal] = await Promise.all([getCompanyInfo(), getLegalParams()]);
    return {
      payslip: serializePayslip(payslip as never),
      company,
      legal: {
        year: legal.year,
        employeeSsoRate: legal.employeeSsoRate,
        employerSsoRate: legal.employerSsoRate,
        unemploymentRate: legal.unemploymentRate,
      },
    };
  });
}

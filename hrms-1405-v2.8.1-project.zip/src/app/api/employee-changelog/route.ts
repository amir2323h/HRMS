import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { serializeChangeLog } from "@/lib/employee-changelog";

// ============================================================
// لاگ تغییرات پرونده پرسنل — فهرست با فیلتر
// ?employeeId= (سابقه یک کارمند) | ?source= | ?limit=
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "employees:view");
    const { searchParams } = new URL(req.url);
    const employeeId = searchParams.get("employeeId")?.trim() || "";
    const source = searchParams.get("source")?.trim() || "";
    const limit = Math.min(500, Math.max(1, Number(searchParams.get("limit")) || 200));

    const where = {
      ...(employeeId ? { employeeId } : {}),
      ...(source ? { source } : {}),
    };

    const logs = await db.employeeChangeLog.findMany({
      where,
      orderBy: [{ performedAt: "desc" }],
      take: limit,
    });

    const total = await db.employeeChangeLog.count({ where });
    const reverted = await db.employeeChangeLog.count({ where: { ...where, revertedAt: { not: null } } });
    const bySource: Record<string, number> = {};
    for (const l of logs) bySource[l.source] = (bySource[l.source] || 0) + 1;

    return {
      logs: logs.map((l) => serializeChangeLog(l as unknown as Record<string, unknown>)),
      stats: { total, reverted, bySource, shown: logs.length },
    };
  });
}

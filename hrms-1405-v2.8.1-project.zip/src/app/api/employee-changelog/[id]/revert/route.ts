import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { revertEmployeeChange, serializeChangeLog } from "@/lib/employee-changelog";
import { logDirectSalaryChange } from "@/lib/salary";

// ============================================================
// بازگردانی یک تغییر پرونده با یک کلیک (با تأییدیه سمت کلاینت)
// - مقادیر «قدیم» فیلدها دوباره اعمال می‌شود
// - رکورد REVERT ثبت و رکورد اصلی مهر «بازگردانی‌شده» می‌خورد
// - رکوردهای CREATE (ثبت اولیه) قابل بازگردانی نیستند
// - اگر حقوق/طبقه تغییر کرده باشد، در لاگ حقوق نیز ثبت می‌شود
// ============================================================

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "employees:edit");
    const { id } = await ctx.params;

    const log = await db.employeeChangeLog.findUnique({ where: { id } });
    if (!log) return Response.json({ error: "رکورد تغییر یافت نشد." }, { status: 404 });
    if (log.source === "CREATE") {
      return Response.json(
        { error: "رکورد ثبت اولیه قابل بازگردانی نیست — برای حذف کامل، پرونده کارمند را حذف کنید." },
        { status: 400 }
      );
    }

    const result = await revertEmployeeChange(session, id);
    if (!result.ok) {
      return Response.json({ error: result.error || "بازگردانی انجام نشد." }, { status: 400 });
    }

    // ——— ثبت همزمان در لاگ/آرشیو حقوق (اگر پایه/اضافه‌کاری/طبقه بازگردانی شده باشد) ———
    if (result.salaryTouched && result.before && result.employee) {
      const b = result.before;
      const a = result.employee;
      await logDirectSalaryChange(
        session,
        {
          id: log.employeeId,
          firstName: b.firstName,
          lastName: b.lastName,
          personnelCode: b.personnelCode,
          status: b.status,
          baseSalary: BigInt(Math.round(b.baseSalary)),
          overtimeHours: b.overtimeHours,
          jobGradeId: b.jobGradeId,
          jobGradeTitle: b.gradeTitle,
          childCount: b.childCount,
          maritalStatus: b.maritalStatus,
          hireDateJ: b.hireDateJ,
          employmentType: b.employmentType,
          shiftPattern: b.shiftPattern,
        },
        {
          baseSalary: BigInt(Math.round(a.baseSalary)),
          overtimeHours: a.overtimeHours,
          jobGradeId: a.jobGradeId,
          jobGradeTitle: a.gradeTitle,
        },
        {
          source: "REVERT",
          reason: `بازگردانی تغییر پرونده — ${result.revertedChanges.map((c) => c.label).join("، ")}`.slice(0, 500),
        }
      );
    }

    const updated = await db.employeeChangeLog.findUnique({ where: { id } });
    return {
      ok: true,
      log: updated ? serializeChangeLog(updated as unknown as Record<string, unknown>) : null,
      revertedFields: result.revertedChanges.map((c) => c.label),
    };
  });
}

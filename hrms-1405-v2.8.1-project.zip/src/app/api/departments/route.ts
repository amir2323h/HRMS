import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeDepartment } from "@/lib/serializers";

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "departments:view");
    const departments = await db.department.findMany({ orderBy: { code: "asc" } });
    // آمار نیرو و هزینه آخرین دوره به تفکیک دپارتمان
    const links = await db.employeeDepartment.findMany({
      include: {
        employee: { select: { id: true, status: true, baseSalary: true, jobGrade: { select: { level: true } } } },
      },
    });
    const stats: Record<string, { count: number; totalBase: number }> = {};
    for (const l of links) {
      if (l.employee.status !== "ACTIVE") continue;
      if (!stats[l.departmentId]) stats[l.departmentId] = { count: 0, totalBase: 0 };
      stats[l.departmentId].count += 1;
      stats[l.departmentId].totalBase += Number(l.employee.baseSalary);
    }
    // مدیر واحد هر دپارتمان
    const managerIds = Array.from(new Set(departments.map((d) => d.managerEmployeeId).filter(Boolean))) as string[];
    const managers = managerIds.length
      ? await db.employee.findMany({ where: { id: { in: managerIds } }, select: { id: true, firstName: true, lastName: true, personnelCode: true } })
      : [];
    const managerMap = new Map(managers.map((m) => [m.id, m]));
    return {
      departments: departments.map((d) => ({
        ...serializeDepartment(d),
        employeeCount: stats[d.id]?.count || 0,
        totalBaseSalary: stats[d.id]?.totalBase || 0,
        manager: d.managerEmployeeId
          ? (() => {
              const m = managerMap.get(d.managerEmployeeId!);
              return m ? { id: m.id, fullName: `${m.firstName} ${m.lastName}`, personnelCode: m.personnelCode } : null;
            })()
          : null,
      })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "departments:manage");
    const b = await req.json();
    if (!b.name?.trim() || !b.code?.trim()) {
      return Response.json({ error: "نام و کد دپارتمان الزامی است." }, { status: 400 });
    }
    const dup = await db.department.findUnique({ where: { code: String(b.code).trim() } });
    if (dup) return Response.json({ error: "کد دپارتمان تکراری است." }, { status: 400 });
    if (b.managerEmployeeId) {
      const mgr = await db.employee.findUnique({ where: { id: b.managerEmployeeId } });
      if (!mgr) return Response.json({ error: "کارمند مدیر یافت نشد." }, { status: 400 });
    }
    const dept = await db.department.create({
      data: {
        code: String(b.code).trim(),
        name: String(b.name).trim(),
        description: String(b.description || ""),
        costCenterCode: String(b.costCenterCode || ""),
        parentId: b.parentId || null,
        managerEmployeeId: b.managerEmployeeId || null,
      },
    });
    await audit(session, "CREATE", "DEPARTMENT", dept.id, `ایجاد دپارتمان «${b.name}» با مرکز هزینه ${b.costCenterCode || "—"}`);
    return { department: serializeDepartment(dept) };
  });
}

export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "departments:manage");
    const b = await req.json();
    if (!b.id) return Response.json({ error: "شناسه الزامی است." }, { status: 400 });
    const before = await db.department.findUnique({ where: { id: b.id } });
    if (!before) return Response.json({ error: "دپارتمان یافت نشد." }, { status: 404 });
    if (b.parentId === b.id) return Response.json({ error: "دپارتمان نمی‌تواند والد خودش باشد." }, { status: 400 });
    const data: Record<string, unknown> = {};
    for (const f of ["name", "description", "costCenterCode", "code"]) if (b[f] !== undefined) data[f] = String(b[f]).trim();
    if (b.parentId !== undefined) data.parentId = b.parentId || null;
    if (b.managerEmployeeId !== undefined) data.managerEmployeeId = b.managerEmployeeId || null;
    await db.department.update({ where: { id: b.id }, data });
    const after = await db.department.findUnique({ where: { id: b.id } });
    await audit(session, "UPDATE", "DEPARTMENT", b.id, `ویرایش دپارتمان «${after?.name}»`, before, after);
    return { department: serializeDepartment(after!) };
  });
}

export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "departments:manage");
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "شناسه الزامی است." }, { status: 400 });
    const links = await db.employeeDepartment.count({ where: { departmentId: id } });
    if (links > 0) return Response.json({ error: "ابتدا کارکنان این دپارتمان را منتقل کنید." }, { status: 400 });
    const dept = await db.department.findUnique({ where: { id } });
    await db.department.delete({ where: { id } });
    await audit(session, "DELETE", "DEPARTMENT", id, `حذف دپارتمان «${dept?.name}»`);
    return { ok: true };
  });
}

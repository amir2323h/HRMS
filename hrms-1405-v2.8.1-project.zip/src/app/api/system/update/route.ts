import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { readFile, stat } from "fs/promises";
import { spawn } from "child_process";
import { createBackup } from "@/lib/backup";

// ============================================================
// اجرای به‌روزرسانی از پنل — POST (فقط مدیر کل سیستم SUPER_ADMIN)
//  فرمان «hrms update --latest --yes» به‌صورت جدا از سرویس اجرا می‌شود
//  (detached) چون به‌روزرسانی در پایان سرویس را ری‌استارت می‌کند.
//  GET: وضعیت جاری + دنباله لاگ برای نمایش زنده در پنل
// وضعیت در SystemSetting «update_state» نگه داشته می‌شود.
//
//  ⚠ v2.7.3 — دو اصلاح حیاتی:
//  ۱) NODE_ENV=production سرویس وب نباید به زنجیره آپدیت نشت کند:
//     npm/bun با NODE_ENV=production وابستگی‌های توسعه (devDependencies)
//     را نصب نمی‌کنند → بیلد با «Cannot find module '@tailwindcss/postcss'»
//     شکست می‌خورد (علت شکست آپدیت پنل در نسخه‌های قبل).
//  ۲) تشخیص پایان موفق/ناموفق از لاگ + ثبت آن در state — پیش از این،
//     شکست آپدیت state را «در حال اجرا» رها می‌کرد و تا ۲۰ دقیقه
//     شروع مجدد از پنل بلاک می‌شد.
// ============================================================

const LOG_FILE = "/tmp/hrms-web-update.log";
const STATE_KEY = "update_state";

// نشانه‌های پایان ناموفق در لاگ (خروجی hrms/installer)
const FAIL_MARKERS = [
  "به‌روزرسانی با خطا پایان یافت", // پیام نهایی hrms CLI
  "بیلد ناموفق بود", // نصب‌کننده
  "نصب بسته‌ها ناموفق بود", // نصب‌کننده
  "بسته‌های توسعه (devDependencies) نصب نشدند", // نصب‌کننده
  "سامانه پاسخ نداد", // بررسی سلامت
];
const SUCCESS_MARKER = "به‌روزرسانی کامل شد"; // پیام نهایی hrms CLI

interface UpdateState {
  startedAt: string; // ISO
  targetVersion: string;
  startedBy: string;
  running: boolean;
  finishedAt?: string;
  lastResult?: "success" | "error";
}

async function readState(): Promise<UpdateState | null> {
  const row = await db.systemSetting.findUnique({ where: { key: STATE_KEY } });
  if (!row) return null;
  try {
    return JSON.parse(row.value) as UpdateState;
  } catch {
    return null;
  }
}

async function writeState(s: UpdateState): Promise<void> {
  await db.systemSetting.upsert({
    where: { key: STATE_KEY },
    update: { value: JSON.stringify(s) },
    create: { key: STATE_KEY, value: JSON.stringify(s) },
  });
}

/** لاگ + زمان آخرین نوشته‌اش (برای تشخیص لاگ تازه/کهنه) */
async function readLogFresh(): Promise<{ log: string; mtimeMs: number }> {
  try {
    const [log, st] = await Promise.all([readFile(LOG_FILE, "utf8"), stat(LOG_FILE)]);
    return { log, mtimeMs: st.mtimeMs };
  } catch {
    return { log: "", mtimeMs: 0 };
  }
}

/**
 * وضعیت را با لاگ هم‌گام می‌کند:
 *  • اگر state «در حال اجرا» باشد و لاگِ همین اجرا نشانه پایان موفق/ناموفق داشته باشد،
 *    پایان در state ثبت می‌شود (running=false + finishedAt + lastResult).
 *  • مبنای «همین اجرا»: زمان آخرین نوشته‌شدن لاگ ≥ زمان شروع state (با ۵ ثانیه تلرانس)
 *    تا مارکرهای لاگِ اجرای قبلی به‌اشتباه پایانِ اجرای جدید تلقی نشوند.
 */
async function syncState(): Promise<{ state: UpdateState | null; failed: boolean; log: string }> {
  let s = await readState();
  const { log, mtimeMs } = await readLogFresh();
  let failed = false;
  if (s?.running) {
    const startedMs = new Date(s.startedAt).getTime();
    const sameRun = mtimeMs >= startedMs - 5000;
    if (sameRun) {
      failed = FAIL_MARKERS.some((m) => log.includes(m));
      const succeeded = log.includes(SUCCESS_MARKER);
      if (failed || succeeded) {
        s = {
          ...s,
          running: false,
          finishedAt: new Date().toISOString(),
          lastResult: failed ? "error" : "success",
        };
        await writeState(s);
      }
    }
  }
  return { state: s, failed, log };
}

/** آیا فرمان hrms روی این سرور موجود است؟ */
async function hrmsAvailable(): Promise<boolean> {
  return new Promise((resolve) => {
    const p = spawn("bash", ["-lc", "command -v hrms >/dev/null 2>&1 && echo FOUND"], { timeout: 5000 });
    let out = "";
    p.stdout.on("data", (d) => (out += String(d)));
    p.on("error", () => resolve(false));
    p.on("close", (code) => resolve(code === 0 && out.includes("FOUND")));
  });
}

/** اجرای جدا از هم — خروجی به لاگ؛ سرویس در پایان توسط خود آپدیت ری‌استارت می‌شود */
async function launchUpdate(targetVersion: string, by: string): Promise<void> {
  // پشتیبان خودکار از داده‌های پنل پیش از به‌روزرسانی (best-effort —
  // حتی اگر شکست بخورد، به‌روزرسانی متوقف نمی‌شود؛ خطا در لاگ ثبت می‌شود)
  try {
    const safety = await createBackup("pre-update");
    console.log(`[UPDATE] پشتیبان پیش از به‌روزرسانی: ${safety.name}`);
  } catch (e) {
    console.error("[UPDATE] پشتیبان خودکار ناموفق (به‌روزرسانی ادامه می‌یابد):", e);
  }
  // ⚠ NODE_ENV را حذف می‌کنیم تا به hrms/installer/npm نشت نکند (وگرنه
  // npm وابستگی‌های توسعه را نصب نمی‌کند و بیلد شکست می‌خورد — باگ ۲.۷.۲)
  const env: NodeJS.ProcessEnv = { ...process.env, TERM: "dumb", HRMS_NO_SPIN: "1" };
  delete env.NODE_ENV;
  const child = spawn(
    "bash",
    ["-lc", `hrms update --latest --yes >"${LOG_FILE}" 2>&1`],
    { detached: true, stdio: "ignore", env }
  );
  child.unref();
  void targetVersion;
  void by;
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req, ["SUPER_ADMIN"]); // فقط مدیر کل سیستم
    const { state, failed, log } = await syncState();
    const lines = log.split("\n").filter(Boolean).slice(-60);
    return {
      state,
      failed,
      log: lines.join("\n"),
      logFile: LOG_FILE,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req, ["SUPER_ADMIN"]); // فقط مدیر کل سیستم
    const b = await req.json().catch(() => ({}) as Record<string, unknown>);
    const targetVersion = String((b as { version?: string }).version || "").trim();

    const current = (process.env.APP_VERSION || "").trim();
    if (!current) {
      return Response.json(
        { error: "نسخه نصب‌شده قابل تشخیص نیست (APP_VERSION در env نیست) — به‌روزرسانی از پنل ممکن نیست؛ از ترمینال با hrms update انجام دهید." },
        { status: 400 }
      );
    }
    if (!(await hrmsAvailable())) {
      return Response.json(
        { error: "فرمان hrms روی این سرور یافت نشد — به‌روزرسانی از پنل فقط روی سرور با نصب استاندارد (hrms در PATH) کار می‌کند." },
        { status: 400 }
      );
    }
    // state پیش از بازبوبستن باید هم‌گام شود — اگر اجرای قبلی ناموفق بوده،
    // «در حال اجرا» نیست و اجازه شروع مجدد فوری می‌دهیم (رفع قفل ۲۰ دقیقه‌ای)
    const { state: running } = await syncState();
    if (running?.running && Date.now() - new Date(running.startedAt).getTime() < 20 * 60 * 1000) {
      return Response.json({ error: "یک به‌روزرسانی هم‌اکنون در حال اجراست — چند دقیقه صبر کنید و وضعیت را دنبال کنید." }, { status: 400 });
    }

    await writeState({
      startedAt: new Date().toISOString(),
      targetVersion: targetVersion || "latest",
      startedBy: session.fullName,
      running: true,
    });
    // پشتیبان خودکار پیش از آغاز به‌روزرسانی ساخته می‌شود (داخل launchUpdate)
    await launchUpdate(targetVersion, session.fullName);
    await audit(
      session,
      "UPDATE",
      "SYSTEM",
      "update",
      `شروع به‌روزرسانی سامانه از پنل به ${targetVersion || "آخرین نسخه گیت‌هاب"} (hrms update --latest --yes)`
    );
    return { started: true, targetVersion: targetVersion || "latest", note: "فرمان به‌روزرسانی اجرا شد — سرویس در پایان خودکار ری‌استارت می‌شود." };
  });
}

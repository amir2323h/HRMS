import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { isValidNationalId } from "@/lib/format";
import { isValidJalali } from "@/lib/jalali";
import { snapshotFromEmployee, diffEmployee, logEmployeeChange, initialChanges } from "@/lib/employee-changelog";

// ============================================================
// ایمپورت گروهی کارکنان از اکسل/CSV
// ردیف‌ها سمت کلاینت پارس شده‌اند؛ اعتبارسنجی سخت سرور تکرار می‌شود
// منطق: upsert بر اساس کد ملی (کلید یکتای پرسنل)
// ============================================================

/** نگاشت متن فارسی/انگلیسی نوع قرارداد → کلید سیستمی */
const CONTRACT_TYPE_MAP: Record<string, string> = {
  "دائم": "PERMANENT",
  "دائم (رسمی)": "PERMANENT",
  "رسمی": "PERMANENT",
  "مدت دار": "FIXED",
  "مدت‌دار": "FIXED",
  "مدت دار (محدود)": "FIXED",
  "مدت‌دار (محدود)": "FIXED",
  "محدود": "FIXED",
  "موقت": "TEMPORARY",
  "آزمایشی": "PROBATION",
  "کارآموز": "INTERN",
  "کارآموزی": "INTERN",
  "PERMANENT": "PERMANENT",
  "FIXED": "FIXED",
  "TEMPORARY": "TEMPORARY",
  "PROBATION": "PROBATION",
  "INTERN": "INTERN",
};

interface ImportRow {
  firstName: string;
  lastName: string;
  nationalId: string;
  mobile: string;
  email: string;
  hireDateJ: string;
  contractType: string;
  jobTitle: string;
  gradeLevel: number | null;
  baseSalary: number; // ریال
  department: string;
  bankName: string;
  iban: string;
  maritalStatus: string;
  childCount: number;
  ssoNumber: string;
  overtimeHours: number;
}

/** شماره پرسنلی بعدی — بر اساس بزرگ‌ترین پسوند عددی موجود */
async function nextPersonnelCode(offset: number): Promise<string> {
  const employees = await db.employee.findMany({ select: { personnelCode: true } });
  let max = 1000;
  for (const e of employees) {
    const m = e.personnelCode.match(/^EMP-(\d+)$/);
    if (m) max = Math.max(max, parseInt(m[1], 10));
  }
  let candidate = `EMP-${max + 1 + offset}`;
  // اطمینان از یکتایی (پسوندهای غیرعددی یا تداخل)
  let k = offset;
  while (await db.employee.findUnique({ where: { personnelCode: candidate } })) {
    k++;
    candidate = `EMP-${max + 1 + k}`;
  }
  return candidate;
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "employees:edit");
    const body = await req.json();
    const rows: ImportRow[] = body?.rows || [];

    if (!Array.isArray(rows) || rows.length === 0) {
      return Response.json({ error: "ردیفی برای ایمپورت ارسال نشده است." }, { status: 400 });
    }
    if (rows.length > 500) {
      return Response.json({ error: "حداکثر ۵۰۰ ردیف در هر نوبت." }, { status: 400 });
    }

    // جداول مرجع (یک‌بار برای همه ردیف‌ها)
    const grades = await db.jobGrade.findMany();
    const gradeByLevel = new Map(grades.map((g) => [g.level, g.id]));
    const jobs = await db.jobTitle.findMany({ where: { isActive: true } });
    const jobByTitle = new Map(jobs.map((j) => [j.title.trim(), j]));
    const departments = await db.department.findMany();
    const deptByNameOrCode = new Map<string, typeof departments[number]>();
    for (const d of departments) {
      deptByNameOrCode.set(d.name.trim(), d);
      deptByNameOrCode.set(d.code.trim(), d);
    }
    const existingByNationalId = new Map<string, { id: string; personnelCode: string }>();
    for (const e of await db.employee.findMany({ select: { id: true, personnelCode: true, nationalId: true } })) {
      if (e.nationalId) existingByNationalId.set(e.nationalId, e);
    }

    let created = 0;
    let updated = 0;
    let failed = 0;
    const errors: string[] = [];
    // جزئیات هر ردیف — برای پیام «به‌روزرسانی شد» به کاربر
    const results: { name: string; nationalId: string; personnelCode: string; action: "created" | "updated"; changedFields: string[] }[] = [];

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      const label = `ردیف ${i + 1}`;
      try {
        // ——— اعتبارسنجی سخت سرور (هم‌تراز فرم تکمی) ———
        const firstName = String(r.firstName || "").trim();
        const lastName = String(r.lastName || "").trim();
        const nationalId = String(r.nationalId || "").replace(/\D/g, "");
        const baseSalary = Math.round(Number(r.baseSalary) || 0);

        if (!firstName) { failed++; errors.push(`${label}: نام الزامی است.`); continue; }
        if (!lastName) { failed++; errors.push(`${label}: نام خانوادگی الزامی است.`); continue; }
        if (!nationalId) { failed++; errors.push(`${label}: کد ملی الزامی است.`); continue; }
        if (!/^\d{10}$/.test(nationalId)) { failed++; errors.push(`${label}: کد ملی باید ۱۰ رقم باشد.`); continue; }
        if (!isValidNationalId(nationalId)) { failed++; errors.push(`${label}: رقم کنترل کد ملی نامعتبر است.`); continue; }
        if (!baseSalary || baseSalary <= 0) { failed++; errors.push(`${label}: حقوق پایه الزامی و باید مثبت باشد.`); continue; }

        const hireDateJ = String(r.hireDateJ || "").trim();
        if (hireDateJ && !isValidJalali(hireDateJ)) { failed++; errors.push(`${label}: قالب تاریخ استخدام نامعتبر است (مثال: 1405/01/15).`); continue; }

        const iban = String(r.iban || "").replace(/\s/g, "").toUpperCase();
        if (iban && !/^IR\d{24}$/i.test(iban)) { failed++; errors.push(`${label}: شماره شبا نامعتبر است (فرمت IR + ۲۴ رقم).`); continue; }

        const contractType = CONTRACT_TYPE_MAP[String(r.contractType || "").trim()] || "PERMANENT";
        const maritalRaw = String(r.maritalStatus || "").trim();
        const maritalStatus = /مت[اأ]هل|متاهل|married/i.test(maritalRaw) ? "MARRIED" : "SINGLE";
        const gradeLevel = r.gradeLevel ? Number(r.gradeLevel) : null;
        let jobGradeId: string | null = null;
        if (gradeLevel !== null) {
          if (!gradeByLevel.has(gradeLevel)) { failed++; errors.push(`${label}: سطح ${gradeLevel} در طبقه‌بندی ۷گانه وجود ندارد.`); continue; }
          jobGradeId = gradeByLevel.get(gradeLevel) || null;
        }

        // شغل: از مشاغل تعریف‌شده (تنظیمات) یا متن آزاد
        const jobTitleStr = String(r.jobTitle || "").trim();
        const job = jobTitleStr ? jobByTitle.get(jobTitleStr) : undefined;
        if (job) {
          if (!jobGradeId && job.jobGradeId) jobGradeId = job.jobGradeId; // طبقه هوشمند شغل
        }

        // دپارتمان: نام یا کد
        const deptStr = String(r.department || "").trim();
        const dept = deptStr ? deptByNameOrCode.get(deptStr) : undefined;

        const existing = existingByNationalId.get(nationalId);
        const commonData = {
          firstName,
          lastName,
          nationalId,
          mobile: String(r.mobile || "").trim(),
          email: String(r.email || "").trim(),
          maritalStatus,
          childCount: Math.max(0, Math.round(Number(r.childCount) || 0)),
          hireDateJ,
          contractType,
          jobGradeId,
          jobTitleId: job?.id || null,
          jobTitle: job?.title || jobTitleStr,
          baseSalary: BigInt(baseSalary),
          overtimeHours: Math.max(0, Math.round(Number(r.overtimeHours) || 0)),
          bankName: String(r.bankName || "").trim(),
          iban,
          ssoNumber: String(r.ssoNumber || "").trim(),
        };

        if (existing) {
          // ——— به‌روزرسانی پرونده موجود (بر اساس کد ملی) ———
          const empBefore = await db.employee.findUnique({
            where: { id: existing.id },
            include: { jobGrade: true, departments: { include: { department: true } } },
          });
          const emp = await db.employee.update({ where: { id: existing.id }, data: commonData });
          // بازچینش دپارتمان: اگر ردیف دپارتمان دارد، تخصیص ۱۰۰٪ قبلی با جدید جایگزین می‌شود
          if (dept) {
            await db.employeeDepartment.deleteMany({ where: { employeeId: emp.id } });
            await db.employeeDepartment.create({ data: { employeeId: emp.id, departmentId: dept.id, allocationPercent: 100 } });
          }
          // ——— لاگ تغییرات پرونده (سابقه تغییرات کارمند — منشأ ایمپورت) ———
          const empAfter = await db.employee.findUnique({
            where: { id: existing.id },
            include: { jobGrade: true, departments: { include: { department: true } } },
          });
          const changeEntries = empBefore
            ? diffEmployee(
                snapshotFromEmployee(empBefore as unknown as Record<string, unknown>),
                snapshotFromEmployee((empAfter || empBefore) as unknown as Record<string, unknown>)
              )
            : [];
          await logEmployeeChange(
            session,
            existing.id,
            changeEntries,
            "IMPORT",
            `به‌روزرسانی پرونده از ایمپورت اکسل (ردیف ${i + 1})`
          );
          results.push({
            name: `${firstName} ${lastName}`,
            nationalId,
            personnelCode: existing.personnelCode,
            action: "updated",
            changedFields: changeEntries.map((c) => c.label),
          });
          updated++;
        } else {
          // ——— ثبت کارمند جدید ———
          const personnelCode = await nextPersonnelCode(created);
          const emp = await db.employee.create({
            data: { ...commonData, personnelCode, status: "ACTIVE", contractStartJ: hireDateJ },
          });
          if (dept) {
            await db.employeeDepartment.create({ data: { employeeId: emp.id, departmentId: dept.id, allocationPercent: 100 } });
          }
          existingByNationalId.set(nationalId, { id: emp.id, personnelCode: emp.personnelCode });
          // ——— لاگ «ثبت اولیه» برای کارمند ایجادشده از ایمپورت ———
          const empFull = await db.employee.findUnique({
            where: { id: emp.id },
            include: { jobGrade: true, departments: { include: { department: true } } },
          });
          await logEmployeeChange(
            session,
            emp.id,
            initialChanges(snapshotFromEmployee((empFull || {}) as unknown as Record<string, unknown>)),
            "CREATE",
            `ثبت از ایمپورت اکسل (ردیف ${i + 1})`
          );
          results.push({
            name: `${firstName} ${lastName}`,
            nationalId,
            personnelCode: emp.personnelCode,
            action: "created",
            changedFields: [],
          });
          created++;
        }
      } catch (e) {
        failed++;
        errors.push(`${label}: ${e instanceof Error ? e.message : "خطای ناشناخته"}`);
      }
    }

    await audit(
      session,
      "CREATE",
      "EMPLOYEE",
      "import",
      `ایمپورت اکسل کارکنان — ${created} جدید، ${updated} به‌روزرسانی، ${failed} ناموفق`,
      undefined,
      { created, updated, failed }
    );
    return { created, updated, failed, errors, results };
  });
}

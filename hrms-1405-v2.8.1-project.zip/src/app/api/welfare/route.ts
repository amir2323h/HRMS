import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

/** آیتم‌های رفاهی — GET عمومی (برای فرم کارمند) / POST (welfare:manage) */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req);
    const onlyActive = new URL(req.url).searchParams.get("active") === "1";
    const items = await db.welfareItem.findMany({
      where: onlyActive ? { isActive: true } : {},
      orderBy: { createdAt: "asc" },
    });
    const usage = await db.employeeWelfare.groupBy({ by: ["welfareItemId"], _count: { welfareItemId: true } });
    const useMap = new Map(usage.map((u) => [u.welfareItemId, u._count.welfareItemId]));
    return {
      items: items.map((w) => ({ ...w, usageCount: useMap.get(w.id) || 0 })),
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "welfare:manage");
    const b = await req.json();
    const title = String(b.title || "").trim();
    if (!title) return Response.json({ error: "عنوان آیتم رفاهی الزامی است." }, { status: 400 });
    // کد ترتیبی WEL-###
    const count = await db.welfareItem.count();
    let code = "";
    for (let i = count + 1; ; i++) {
      code = `WEL-${String(i).padStart(3, "0")}`;
      if (!(await db.welfareItem.findUnique({ where: { code } }))) break;
    }
    const item = await db.welfareItem.create({
      data: { code, title, description: String(b.description || ""), isActive: b.isActive === false ? false : true },
    });
    await audit(session, "CREATE", "WELFARE_ITEM", item.id, `ایجاد آیتم رفاهی «${title}» (${code})`);
    return { item };
  });
}

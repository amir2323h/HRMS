import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

/** ویرایش/حذف آیتم رفاهی — welfare:manage */
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "welfare:manage");
    const { id } = await params;
    const b = await req.json();
    const item = await db.welfareItem.findUnique({ where: { id } });
    if (!item) return Response.json({ error: "آیتم یافت نشد." }, { status: 404 });
    const data: Record<string, unknown> = {};
    if (b.title !== undefined) {
      const t = String(b.title).trim();
      if (!t) return Response.json({ error: "عنوان الزامی است." }, { status: 400 });
      data.title = t;
    }
    if (b.description !== undefined) data.description = String(b.description);
    if (b.isActive !== undefined) data.isActive = !!b.isActive;
    const updated = await db.welfareItem.update({ where: { id }, data });
    await audit(session, "UPDATE", "WELFARE_ITEM", id, `ویرایش آیتم رفاهی «${updated.title}»`, item, updated);
    return { item: updated };
  });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "welfare:manage");
    const { id } = await params;
    const item = await db.welfareItem.findUnique({ where: { id } });
    if (!item) return Response.json({ error: "آیتم یافت نشد." }, { status: 404 });
    await db.employeeWelfare.deleteMany({ where: { welfareItemId: id } });
    await db.welfareItem.delete({ where: { id } });
    await audit(session, "DELETE", "WELFARE_ITEM", id, `حذف آیتم رفاهی «${item.title}»`);
    return { ok: true };
  });
}

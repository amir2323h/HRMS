import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { diffJalaliDays, todayJalaliStr, toFaDigits } from "@/lib/jalali";
import { getLegalParams } from "@/lib/settings";

export interface Alert {
  id: string;
  type: "PROBATION_END" | "PROBATION_ENDED" | "CONTRACT_END" | "MISSING_IBAN" | "MISSING_DOC" | "SALARY_BELOW_MIN" | "SALARY_OUT_OF_GRADE";
  severity: "high" | "medium" | "low";
  title: string;
  message: string;
  employeeId: string;
  employeeName: string;
  dateJ?: string;
  daysLeft?: number;
}

/** هشدارهای هوشمند: پایان آزمایشی، انقضای قرارداد، نقص اطلاعات */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "dashboard:view");
    const today = todayJalaliStr();
    const alerts: Alert[] = [];
    const legal = await getLegalParams();

    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      include: { jobGrade: true, documents: true },
    });

    for (const e of employees) {
      const name = `${e.firstName} ${e.lastName}`;
      // پایان دوره آزمایشی — ۳۰ روز آینده
      if (e.probationEndDateJ) {
        const d = diffJalaliDays(today, e.probationEndDateJ);
        if (d >= 0 && d <= 30) {
          alerts.push({
            id: `prob-${e.id}`,
            type: "PROBATION_END",
            severity: d <= 7 ? "high" : "medium",
            title: "پایان دوره آزمایشی",
            message: `دوره آزمایشی ${name} در ${d === 0 ? "امروز" : `${toFaDigits(d)} روز آینده`} به پایان می‌رسد — تعیین تکلیف تثبیت یا قطع همکاری لازم است.`,
            employeeId: e.id,
            employeeName: name,
            dateJ: e.probationEndDateJ,
            daysLeft: d,
          });
        }
        // دوره آزمایشی تمام‌شده (حداکثر ۳۰ روز گذشته) — اعلام در داشبورد
        if (d < 0 && d >= -30) {
          alerts.push({
            id: `prob-ended-${e.id}`,
            type: "PROBATION_ENDED",
            severity: "high",
            title: "دوره آزمایشی به پایان رسید",
            message: `دوره آزمایشی ${name} در تاریخ ${toFaDigits(e.probationEndDateJ)} (${toFaDigits(Math.abs(d))} روز پیش) به پایان رسید — وضعیت استخدام باید مشخص شود.`,
            employeeId: e.id,
            employeeName: name,
            dateJ: e.probationEndDateJ,
            daysLeft: 0,
          });
        }
      }
      // پایان قرارداد — ۶۰ روز
      if (e.contractEndJ) {
        const d = diffJalaliDays(today, e.contractEndJ);
        if (d >= 0 && d <= 60) {
          alerts.push({
            id: `contract-${e.id}`,
            type: "CONTRACT_END",
            severity: d <= 15 ? "high" : d <= 30 ? "medium" : "low",
            title: "انقضای قرارداد",
            message: `قرارداد ${name} در ${d === 0 ? "امروز" : `${d} روز آینده`} منقضی می‌شود.`,
            employeeId: e.id,
            employeeName: name,
            dateJ: e.contractEndJ,
            daysLeft: d,
          });
        }
      }
      // نبود شبا
      if (!e.iban) {
        alerts.push({
          id: `iban-${e.id}`,
          type: "MISSING_IBAN",
          severity: "medium",
          title: "نبود شماره شبا",
          message: `برای ${name} شماره شبا ثبت نشده — امکان تولید فایل بانکی وجود ندارد.`,
          employeeId: e.id,
          employeeName: name,
        });
      }
      // نبود سند قرارداد
      const hasContract = (e.documents || []).some((d) => d.type === "CONTRACT");
      if (!hasContract) {
        alerts.push({
          id: `doc-${e.id}`,
          type: "MISSING_DOC",
          severity: "low",
          title: "نبود سند قرارداد",
          message: `نسخه قرارداد ${name} در پرونده اسناد بارگذاری نشده است.`,
          employeeId: e.id,
          employeeName: name,
        });
      }
      // حقوق پایه زیر حداقل
      const base = Number(e.baseSalary);
      if (base > 0 && base < legal.minWage) {
        alerts.push({
          id: `minwage-${e.id}`,
          type: "SALARY_BELOW_MIN",
          severity: "high",
          title: "حقوق کمتر از حداقل دستمزد",
          message: `حقوق پایه ${name} کمتر از حداقل دستمزد مصوب ۱۴۰۵ است.`,
          employeeId: e.id,
          employeeName: name,
        });
      }
      // خارج از باند طبقه
      if (e.jobGrade) {
        if (base < Number(e.jobGrade.minBaseSalary) || base > Number(e.jobGrade.maxBaseSalary)) {
          alerts.push({
            id: `grade-${e.id}`,
            type: "SALARY_OUT_OF_GRADE",
            severity: "low",
            title: "حقوق خارج از باند طبقه",
            message: `حقوق پایه ${name} خارج از بازه سطح ${e.jobGrade.level} (${e.jobGrade.title}) است.`,
            employeeId: e.id,
            employeeName: name,
          });
        }
      }
    }

    const order = { high: 0, medium: 1, low: 2 };
    alerts.sort((a, b) => order[a.severity] - order[b.severity] || (a.daysLeft ?? 999) - (b.daysLeft ?? 999));
    return { alerts, today, counts: { high: alerts.filter((a) => a.severity === "high").length, medium: alerts.filter((a) => a.severity === "medium").length, low: alerts.filter((a) => a.severity === "low").length } };
  });
}

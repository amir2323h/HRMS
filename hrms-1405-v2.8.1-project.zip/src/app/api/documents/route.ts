import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializeDocument } from "@/lib/serializers";

const MAX_SIZE = 5 * 1024 * 1024; // ۵ مگابایت

/** بارگذاری سند کارمند (multipart/form-data) */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "employees:edit");
    const form = await req.formData();
    const employeeId = String(form.get("employeeId") || "");
    const type = String(form.get("type") || "OTHER");
    const title = String(form.get("title") || "").trim();
    const description = String(form.get("description") || "");
    const file = form.get("file") as File | null;

    if (!employeeId) return Response.json({ error: "کارمند الزامی است." }, { status: 400 });
    if (!file || !(file instanceof File)) return Response.json({ error: "فایل الزامی است." }, { status: 400 });
    if (file.size > MAX_SIZE) return Response.json({ error: "حجم فایل بیش از ۵ مگابایت است." }, { status: 400 });
    if (!title) return Response.json({ error: "عنوان سند الزامی است." }, { status: 400 });

    const emp = await db.employee.findUnique({ where: { id: employeeId } });
    if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });

    const buffer = Buffer.from(await file.arrayBuffer());
    const doc = await db.document.create({
      data: {
        employeeId,
        type,
        title,
        fileName: file.name || "file",
        mimeType: file.type || "application/octet-stream",
        size: buffer.length,
        data: buffer,
        description,
        uploadedBy: session.fullName,
      },
    });
    await audit(session, "CREATE", "DOCUMENT", doc.id, `بارگذاری سند «${title}» برای ${emp.firstName} ${emp.lastName}`);
    return { document: serializeDocument(doc as never) };
  });
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "employees:edit");
    const { searchParams } = new URL(req.url);
    const employeeId = searchParams.get("employeeId");
    const docs = await db.document.findMany({
      where: employeeId ? { employeeId } : {},
      orderBy: { createdAt: "desc" },
      include: { employee: { select: { firstName: true, lastName: true, personnelCode: true } } },
    });
    return {
      documents: docs.map((d) => ({
        ...serializeDocument(d as never),
        employeeName: `${d.employee.firstName} ${d.employee.lastName}`,
        personnelCode: d.employee.personnelCode,
      })),
    };
  });
}

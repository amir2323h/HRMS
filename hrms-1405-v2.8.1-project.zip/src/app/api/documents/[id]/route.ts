import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";

/** دانلود سند */
export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(req, "employees:view");
    const { id } = await ctx.params;
    const doc = await db.document.findUnique({ where: { id } });
    if (!doc || !doc.data) return Response.json({ error: "سند یافت نشد." }, { status: 404 });
    const buffer = Buffer.from(doc.data);
    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": doc.mimeType || "application/octet-stream",
        "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(doc.fileName)}`,
        "Content-Length": String(buffer.length),
      },
    });
  });
}

/** حذف سند */
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "employees:edit");
    const { id } = await ctx.params;
    const doc = await db.document.findUnique({ where: { id } });
    if (!doc) return Response.json({ error: "سند یافت نشد." }, { status: 404 });
    await db.document.delete({ where: { id } });
    await audit(session, "DELETE", "DOCUMENT", id, `حذف سند «${doc.title}»`);
    return { ok: true };
  });
}

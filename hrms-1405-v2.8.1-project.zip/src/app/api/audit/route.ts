import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { serializeAudit } from "@/lib/serializers";

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "audit:view");
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q")?.trim() || "";
    const action = searchParams.get("action") || "";
    const entity = searchParams.get("entity") || "";
    const page = Math.max(1, +(searchParams.get("page") || 0) || 1);
    const pageSize = 30;

    const where = {
      AND: [
        q ? { OR: [{ summary: { contains: q } }, { userName: { contains: q } }, { entityId: { contains: q } }] } : {},
        action ? { action } : {},
        entity ? { entity } : {},
      ],
    };
    const [logs, total] = await Promise.all([
      db.auditLog.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      db.auditLog.count({ where }),
    ]);
    return {
      logs: logs.map((l) => serializeAudit(l as never)),
      total,
      page,
      pageCount: Math.ceil(total / pageSize),
    };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm, hashPassword } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { ROLE_LABELS } from "@/lib/format";

// ============================================================
// ایمپورت گروهی کاربران از اکسل — فقط مدیر کل
// ستون‌ها: نام کاربری، نام و نام خانوادگی، رمز عبور، نقش، کد پرسنلی (اختیاری)، فعال
// ============================================================

const VALID_ROLES = ["SUPER_ADMIN", "HR_MANAGER", "PAYROLL_OFFICER", "DEPT_MANAGER", "EMPLOYEE"];

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "users:manage");
    const body = await req.json();
    const rows: { username: string; fullName: string; password: string; role: string; personnelCode: string; isActive: boolean }[] = body?.rows || [];

    if (!Array.isArray(rows) || rows.length === 0) {
      return Response.json({ error: "ردیفی برای ایمپورت ارسال نشده است." }, { status: 400 });
    }
    if (rows.length > 500) {
      return Response.json({ error: "حداکثر ۵۰۰ کاربر در هر نوبت." }, { status: 400 });
    }

    // کارکنان برای اتصال با کد پرسنلی
    const employees = await db.employee.findMany({ select: { id: true, personnelCode: true } });
    const empByCode = new Map(employees.map((e) => [e.personnelCode, e.id]));
    const linkedEmpIds = new Set(
      (await db.user.findMany({ where: { employeeId: { not: null } }, select: { employeeId: true } })).map((u) => u.employeeId as string)
    );

    let created = 0;
    let updated = 0;
    let failed = 0;
    const errors: string[] = [];
    const seenUsernames = new Set<string>();

    for (let i = 0; i < rows.length; i++) {
      const r = rows[i];
      try {
        const username = String(r.username || "").trim().toLowerCase();
        const fullName = String(r.fullName || "").trim();
        const password = String(r.password || "");
        const role = String(r.role || "");

        const rowErrors: string[] = [];
        if (!/^[a-z0-9._-]{3,30}$/.test(username)) rowErrors.push("نام کاربری نامعتبر (۳ تا ۳۰ کاراکتر لاتین).");
        if (!fullName) rowErrors.push("نام و نام خانوادگی خالی است.");
        if (password.length < 6) rowErrors.push("رمز عبور کمتر از ۶ کاراکتر است.");
        if (!VALID_ROLES.includes(role)) rowErrors.push("نقش نامعتبر است.");
        if (seenUsernames.has(username)) rowErrors.push("تکراری در همین فایل.");
        if (rowErrors.length) {
          failed++;
          errors.push(`ردیف ${i + 1} (${username || "؟"}): ${rowErrors.join(" ")}`);
          continue;
        }
        seenUsernames.add(username);

        // اتصال اختیاری به پرونده کارمند با کد پرسنلی
        let employeeId: string | null = null;
        const personnelCode = String(r.personnelCode || "").trim();
        if (personnelCode) {
          const empId = empByCode.get(personnelCode);
          if (!empId) {
            failed++;
            errors.push(`ردیف ${i + 1} (${username}): کارمندی با کد پرسنلی «${personnelCode}» یافت نشد.`);
            continue;
          }
          if (linkedEmpIds.has(empId)) {
            failed++;
            errors.push(`ردیف ${i + 1} (${username}): پرونده ${personnelCode} قبلاً به کاربر دیگری متصل است.`);
            continue;
          }
          employeeId = empId;
        }

        const existing = await db.user.findUnique({ where: { username } });
        if (existing) {
          // به‌روزرسانی کاربر موجود (بدون تغییر رمز در صورت خالی بودن)
          const data: Record<string, unknown> = { fullName, role, isActive: r.isActive !== false };
          if (password) data.passwordHash = hashPassword(password);
          if (employeeId) data.employeeId = employeeId;
          await db.user.update({ where: { id: existing.id }, data });
          if (employeeId) linkedEmpIds.add(employeeId);
          updated++;
        } else {
          const user = await db.user.create({
            data: {
              username,
              fullName,
              role,
              passwordHash: hashPassword(password),
              employeeId,
              isActive: r.isActive !== false,
            },
          });
          if (employeeId) linkedEmpIds.add(employeeId);
          created++;
          void user;
        }
      } catch (e) {
        failed++;
        errors.push(`ردیف ${i + 1}: ${e instanceof Error ? e.message : "خطای ناشناخته"}`);
      }
    }

    await audit(session, "CREATE", "USER", "import", `ایمپورت اکسل کاربران — ${created} جدید، ${updated} به‌روزرسانی، ${failed} ناموفق`);
    return { created, updated, failed, errors };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { getChangelog, isChangelogTarget, appVersion, type ChangelogItem } from "@/lib/changelog";

// ============================================================
// اطلاعیه تغییرات محصول — پاپ‌آپ «تازه‌های نسخه»
//  GET  : برای کاربر جاری — آیا نمایش داده شود + محتوا
//  POST : ثبت «دیده شد» (نسخه در User.changelogSeen)
// مدیریت محتوا و هدف‌گیری: تنظیمات (settings:manage — PUT /api/settings)
// ============================================================

export async function GET(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const cfg = await getChangelog();
    const user = await db.user.findUnique({ where: { id: session.uid }, select: { changelogSeen: true } });
    const target = isChangelogTarget(cfg, { role: session.role, username: session.username });
    const seen = (user?.changelogSeen || "") === cfg.version;
    const show = target && !seen;
    // محتوا فقط وقتی ارسال می‌شود که نمایش داده شود (اطلاعیه فعال + مخاطب + دیده‌نشده)
    const data = show
      ? {
          version: cfg.version,
          title: cfg.title || `تازه‌های نسخه ${cfg.version}`,
          items: cfg.items as ChangelogItem[],
          currentVersion: appVersion(),
        }
      : null;
    return { show, data };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req);
    const cfg = await getChangelog();
    // نسخه دیده‌شده = نسخه اطلاعیه فعال (اگر مخاطب نیست، تغییر وضعیت نمی‌دهد)
    if (cfg.version && isChangelogTarget(cfg, { role: session.role, username: session.username })) {
      await db.user.update({ where: { id: session.uid }, data: { changelogSeen: cfg.version } });
    }
    return { ok: true, seen: cfg.version };
  });
}

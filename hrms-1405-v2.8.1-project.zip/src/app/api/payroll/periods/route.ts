import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializePeriod, serializePayslip } from "@/lib/serializers";
import { getLegalParams } from "@/lib/settings";
import { computePaysheet, contextFromEmployee, shiftRateOf } from "@/lib/payroll/engine";
import { aggregateAttendance } from "@/lib/attendance";
import { todayJalaliStr, parseJalali } from "@/lib/jalali";
import { getWorkSchedule, monthDaysInfo, computeMonthStats, type HolidayMap } from "@/lib/holidays";

export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "payroll:view");
    const periods = await db.payrollPeriod.findMany({
      orderBy: [{ year: "desc" }, { month: "desc" }],
      include: { payslips: true },
    });

    // ساعت استاندارد هر دوره — با کسر پنجشنبه/جمعه (بر اساس نوع اشتغال) و تعطیلات رسمی
    const schedule = await getWorkSchedule();
    const holidayCache = new Map<number, HolidayMap>();
    const standardHours: Record<string, { totalDays: number; officialHolidays: number; daily: { workingDays: number; standardHours: number }; shift: { workingDays: number; standardHours: number } }> = {};
    for (const p of periods) {
      if (!holidayCache.has(p.year)) {
        const rows = await db.holiday.findMany({ where: { dateJ: { startsWith: `${p.year}/` } } });
        holidayCache.set(p.year, new Map(rows.map((r) => [r.dateJ, { title: r.title, kind: r.kind }])));
      }
      const stats = computeMonthStats(p.year, p.month, monthDaysInfo(p.year, p.month, holidayCache.get(p.year)!), schedule);
      standardHours[`${p.year}/${p.month}`] = {
        totalDays: stats.totalDays,
        officialHolidays: stats.officialHolidays,
        daily: stats.daily,
        shift: stats.shift,
      };
    }

    return { periods: periods.map((p) => serializePeriod(p as never)), standardHours };
  });
}

/** ایجاد دوره جدید و محاسبه خودکار لیست حقوق */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "payroll:manage");
    const b = await req.json();
    const year = +b.year;
    const month = +b.month;
    if (!year || !month || month < 1 || month > 12) {
      return Response.json({ error: "سال و ماه دوره نامعتبر است." }, { status: 400 });
    }
    const dup = await db.payrollPeriod.findUnique({ where: { year_month: { year, month } } });
    if (dup) return Response.json({ error: "دوره انتخابی قبلاً ایجاد شده است." }, { status: 400 });

    const params = await getLegalParams();
    const atDateJ = `${year}/${String(month).padStart(2, "0")}/${String(month <= 6 ? 31 : 30).padStart(2, "0")}`;

    // کارکنان فعال که تا پایان ماه استخدام شده‌اند
    const employees = await db.employee.findMany({
      where: { status: "ACTIVE" },
      include: { jobGrade: true, departments: { include: { department: true } } },
    });
    const eligible = employees.filter((e) => {
      const h = parseJalali(e.hireDateJ || "");
      if (!h) return true;
      return h.jy < year || (h.jy === year && h.jm <= month);
    });

    const period = await db.payrollPeriod.create({
      data: { year, month, status: "CALCULATED", notes: `محاسبه خودکار — ${atDateJ}` },
    });

    // کارکرد ماهانه از حضور و غیب — مبنای اضافه‌کاری/شب‌کاری/جمعه‌کاری/تعطیل‌کاری/غیبت/مأموریت
    const monthPrefix = `${year}/${String(month).padStart(2, "0")}/`;
    const attendanceRecords = await db.attendanceRecord.findMany({ where: { dateJ: { startsWith: monthPrefix } } });
    const attendanceByEmp = new Map<string, typeof attendanceRecords>();
    for (const r of attendanceRecords) {
      const list = attendanceByEmp.get(r.employeeId) || [];
      list.push(r);
      attendanceByEmp.set(r.employeeId, list);
    }
    let employeesWithAttendance = 0;

    for (const emp of eligible) {
      // شیفت/نوبتی‌کاری (تبصره ۱ ماده ۵۶) — از نوع اشتغال کارمند
      const shiftRate = shiftRateOf(emp.employmentType, emp.shiftPattern, params);
      const ctx = contextFromEmployee(
        {
          baseSalary: emp.baseSalary,
          childCount: emp.childCount,
          maritalStatus: emp.maritalStatus,
          overtimeHours: emp.overtimeHours,
          hireDateJ: emp.hireDateJ,
          employmentType: emp.employmentType,
          shiftPattern: emp.shiftPattern,
        },
        emp.jobGrade,
        atDateJ
      );
      // اگر کارکرد ماهانه ثبت شده باشد، مبنای محاسبه قرار می‌گیرد (جایگزین پیش‌فرض پرسنلی)
      const empRecords = attendanceByEmp.get(emp.id);
      if (empRecords && empRecords.length > 0) {
        employeesWithAttendance += 1;
        const agg = aggregateAttendance(
          empRecords.map((r) => ({
            employeeId: r.employeeId, status: r.status, workHours: r.workHours,
            overtimeHours: r.overtimeHours, nightHours: r.nightHours,
            fridayHours: r.fridayHours, holidayHours: r.holidayHours,
          }))
        );
        ctx.overtimeHours = agg.overtimeHours;
        ctx.nightHours = agg.nightHours;
        ctx.fridayHours = agg.fridayHours;
        ctx.holidayHours = agg.holidayHours;
        ctx.absentDays = agg.absentDays;
        ctx.missionDays = agg.missionDays;
      }
      ctx.shiftRate = shiftRate;
      const sheet = computePaysheet(Number(emp.baseSalary), ctx, params);
      await db.payslip.create({
        data: {
          periodId: period.id,
          employeeId: emp.id,
          baseSalary: BigInt(sheet.baseCore), // حقوق پایه — سهم تفکیک سطح
          responsibility: BigInt(sheet.responsibility), // حق مسولیت — سهم تفکیک سطح
          merit: BigInt(sheet.merit), // پاداش شایستگی — سهم تفکیک سطح
          seniority: BigInt(sheet.seniority),
          housing: BigInt(sheet.housing),
          grocery: BigInt(sheet.grocery),
          childAllowance: BigInt(sheet.childAllowance),
          attraction: BigInt(sheet.attraction),
          overtimeHours: ctx.overtimeHours || 0,
          overtimeAmount: BigInt(sheet.overtimeAmount),
          nightHours: sheet.nightHours,
          nightAmount: BigInt(sheet.nightAmount),
          fridayHours: sheet.fridayHours,
          fridayAmount: BigInt(sheet.fridayAmount),
          holidayHours: sheet.holidayHours,
          holidayAmount: BigInt(sheet.holidayAmount),
          shiftAllowance: BigInt(sheet.shiftAllowance),
          absentDays: sheet.absentDays,
          absenceDeduction: BigInt(sheet.absenceDeduction),
          missionDays: sheet.missionDays,
          missionAmount: BigInt(sheet.missionAmount),
          otherAllowance: BigInt(sheet.otherAllowance),
          gross: BigInt(sheet.gross),
          insurableBase: BigInt(sheet.insurableBase),
          employeeSso: BigInt(sheet.employeeSso),
          employerSso20: BigInt(sheet.employerSso20),
          unemploymentSso3: BigInt(sheet.unemploymentSso3),
          taxableIncome: BigInt(sheet.taxableIncome),
          incomeTax: BigInt(sheet.incomeTax),
          otherDeduction: BigInt(sheet.otherDeduction),
          netPay: BigInt(sheet.netPay),
          isReverse: false,
        },
      });
    }

    await audit(session, "CALC", "PERIOD", period.id, `محاسبه لیست حقوق دوره ${month}/${year} برای ${eligible.length} کارمند (${employeesWithAttendance} نفر با کارکرد ثبت‌شده حضور و غیب)`);
    const full = await db.payrollPeriod.findUnique({ where: { id: period.id }, include: { payslips: true } });
    return { period: serializePeriod(full as never) };
  });
}

export async function DELETE(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "payroll:manage");
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "شناسه الزامی است." }, { status: 400 });
    const period = await db.payrollPeriod.findUnique({ where: { id }, include: { payslips: true } });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });
    if (period.status === "PAID") return Response.json({ error: "دوره پرداخت‌شده قابل حذف نیست." }, { status: 400 });
    await db.payrollPeriod.delete({ where: { id } });
    await audit(session, "DELETE", "PERIOD", id, `حذف دوره ${period.month}/${period.year} و ${period.payslips.length} فیش`);
    return { ok: true };
  });
}

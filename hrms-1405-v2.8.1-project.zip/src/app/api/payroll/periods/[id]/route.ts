import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { serializePeriod, serializePayslip } from "@/lib/serializers";
import { getLegalParams } from "@/lib/settings";

export async function GET(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    requirePerm(req, "payroll:view");
    const { id } = await ctx.params;
    const period = await db.payrollPeriod.findUnique({
      where: { id },
      include: {
        payslips: {
          // واحدهای سازمانی هر کارمند برای محاسبه سهم هر واحد از هزینه‌های دوره
          include: { employee: { include: { departments: { include: { department: true } } } } },
          orderBy: { employeeId: "asc" },
        },
      },
    });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });
    const params = await getLegalParams();
    // جزئیات پله‌های مالیاتی برای نمایش
    const totalTaxable = period.payslips.reduce((acc, p) => acc + Number(p.taxableIncome), 0);
    return {
      period: serializePeriod(period as never),
      payslips: period.payslips.map((p) => serializePayslip(p as never)),
      legal: {
        year: params.year,
        employeeSsoRate: params.employeeSsoRate,
        employerSsoRate: params.employerSsoRate,
        unemploymentRate: params.unemploymentRate,
        taxBrackets: params.taxBrackets,
      },
      avgTaxable: period.payslips.length ? Math.round(totalTaxable / period.payslips.length) : 0,
    };
  });
}

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const session = requirePerm(req, "payroll:manage");
    const { id } = await ctx.params;
    const b = await req.json();
    const period = await db.payrollPeriod.findUnique({ where: { id } });
    if (!period) return Response.json({ error: "دوره یافت نشد." }, { status: 404 });
    if (!["CALCULATED", "APPROVED", "PAID"].includes(b.status)) {
      return Response.json({ error: "وضعیت نامعتبر است." }, { status: 400 });
    }
    await db.payrollPeriod.update({ where: { id }, data: { status: b.status } });
    await audit(session, b.status === "PAID" ? "APPROVE" : "UPDATE", "PERIOD", id, `تغییر وضعیت دوره ${period.month}/${period.year} به «${b.status === "PAID" ? "پرداخت شده" : b.status === "APPROVED" ? "تأیید شده" : "محاسبه شده"}»`, { status: period.status }, { status: b.status });
    const full = await db.payrollPeriod.findUnique({ where: { id }, include: { payslips: true } });
    return { period: serializePeriod(full as never) };
  });
}

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle } from "@/lib/api-helpers";
import { serializeLog } from "@/lib/salary";
import { isoToJalaliStr } from "@/lib/jalali";

/**
 * GET /api/salary/logs?employeeId=&source=&limit=
 * لاگ و آرشیو تغییرات حقوق — همیشه در دسترس (مجوز salary:view)
 * source: MANUAL | BULK | REVERSE | EDIT
 * stats: آمار جمعی کل آرشیو + سری ماهانه برای نمودار روند
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "salary:view");
    const employeeId = req.nextUrl.searchParams.get("employeeId") || "";
    const source = req.nextUrl.searchParams.get("source") || "";
    const limit = Math.min(1000, Math.max(1, +(req.nextUrl.searchParams.get("limit") || 300)));

    const where = {
      ...(employeeId ? { employeeId } : {}),
      ...(source ? { source } : {}),
    };
    const logs = await db.salaryChangeLog.findMany({
      where,
      orderBy: { performedAt: "desc" },
      take: limit,
    });

    // آمار کلی آرشیو + سری ماهانه (روند جمع تغییرات) — روی کل لاگ‌ها (حداکثر ۵۰۰۰ رکورد اخیر)
    const statRows = await db.salaryChangeLog.findMany({
      select: { deltaAmount: true, deltaPercent: true, oldNet: true, newNet: true, performedAt: true, employeeId: true },
      orderBy: { performedAt: "desc" },
      take: 5000,
    });
    let totalCount = statRows.length;
    let increaseCount = 0;
    let decreaseCount = 0;
    let sumIncrease = 0;
    let sumDecrease = 0;
    let netDelta = 0;
    let sumDelta = 0;
    let sumPercent = 0;
    let percentCount = 0;
    const employees = new Set<string>();
    // سری ماهانه: ۱۴۰۵/۰۷ → جمع Δپایه + جمع Δخالص + تعداد
    const monthly = new Map<string, { delta: number; netDelta: number; count: number; ts: number }>();
    for (const r of statRows) {
      const d = Number(r.deltaAmount || 0);
      const nd = Number(r.newNet || 0) - Number(r.oldNet || 0);
      if (d > 0) { increaseCount += 1; sumIncrease += d; }
      else if (d < 0) { decreaseCount += 1; sumDecrease += Math.abs(d); }
      sumDelta += d;
      netDelta += nd;
      employees.add(r.employeeId);
      const pct = Number(r.deltaPercent || 0);
      if (pct !== 0) { sumPercent += pct; percentCount += 1; }
      const j = isoToJalaliStr(r.performedAt); // 1405/07/13
      const key = j.slice(0, 7); // 1405/07
      const ts = r.performedAt.getTime();
      const cur = monthly.get(key) || { delta: 0, netDelta: 0, count: 0, ts };
      cur.delta += d;
      cur.netDelta += nd;
      cur.count += 1;
      cur.ts = Math.max(cur.ts, ts);
      monthly.set(key, cur);
    }
    const monthlySeries = [...monthly.entries()]
      .sort((a, b) => a[0].localeCompare(b[0])) // قدیمی → جدید
      .map(([key, v]) => ({
        key,
        label: `${key.slice(0, 4)}/${key.slice(5, 7)}`,
        delta: v.delta,
        netDelta: v.netDelta,
        count: v.count,
      }));

    return {
      logs: logs.map((l) => serializeLog(l as unknown as Record<string, unknown>)),
      stats: {
        totalCount,
        increaseCount,
        decreaseCount,
        sumDelta,
        // گزارش جمعی (v2.3.0)
        sumIncrease,
        sumDecrease,
        netDelta, // جمع اثر تغییرات بر خالص ماهانه (خالص جدید − خالص قبلی)
        uniqueEmployees: employees.size,
        avgPercent: percentCount > 0 ? sumPercent / percentCount : 0,
        monthly: monthlySeries,
      },
    };
  });
}

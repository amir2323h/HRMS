import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requirePerm } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import {
  applyDrafts,
  discardDrafts,
  serializeDraft,
  solveEmployeeBaseForNet,
  upsertDrafts,
  type DraftInput,
  type EmployeeSalaryLike,
} from "@/lib/salary";
import { getLegalParams } from "@/lib/settings";
import { todayJalaliStr } from "@/lib/jalali";

/**
 * GET /api/salary/drafts?status=PENDING|ALL&employeeId=...
 * فهرست پیش‌نویس‌های تغییر حقوق + شمارنده‌ها
 */
export async function GET(req: NextRequest) {
  return handle(async () => {
    requirePerm(req, "salary:view");
    const status = req.nextUrl.searchParams.get("status") || "PENDING";
    const employeeId = req.nextUrl.searchParams.get("employeeId") || "";

    const where = {
      ...(status === "ALL" ? {} : { status }),
      ...(employeeId ? { employeeId } : {}),
    };
    const drafts = await db.salaryDraft.findMany({
      where,
      include: { employee: { select: { firstName: true, lastName: true, personnelCode: true } } },
      orderBy: { createdAt: "desc" },
      take: status === "ALL" ? 500 : 200,
    });

    const pending = await db.salaryDraft.count({ where: { status: "PENDING" } });

    return {
      drafts: drafts.map((d) => serializeDraft(d as unknown as Record<string, unknown>)),
      counts: { pending },
    };
  });
}

/**
 * POST /api/salary/drafts — ثبت پیش‌نویس (ذخیره موقت)
 * حالت‌ها:
 *  single: { employeeId, newBaseSalary?, targetNet?, newOvertimeHours?, newJobGradeId?, reason? }
 *  bulk:   { employeeIds?: string[], filter?: { departmentId?, gradeId?, gradeNull? },
 *            operation: { type: PERCENT_BASE|SET_BASE|ADD_BASE|SET_OVERTIME, value }, reason? }
 *  reverse:{ items: [{ employeeId, targetNet }], reason? }
 */
export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "salary:manage");
    const b = await req.json();
    const mode = String(b.mode || "single");

    // ---------- حالت فردی ----------
    if (mode === "single") {
      const employeeId = String(b.employeeId || "");
      if (!employeeId) return Response.json({ error: "کارمند انتخاب نشده است." }, { status: 400 });
      const emp = await db.employee.findUnique({ where: { id: employeeId }, include: { jobGrade: true } });
      if (!emp) return Response.json({ error: "کارمند یافت نشد." }, { status: 404 });

      let newBase: number | null = null;
      let targetNet: number | null = null;

      const providedBase = b.newBaseSalary !== undefined && b.newBaseSalary !== null ? Math.round(+b.newBaseSalary) : null;
      const providedNet = b.targetNet !== undefined && b.targetNet !== null ? Math.round(+b.targetNet) : null;

      if (providedBase && providedBase > 0) {
        newBase = providedBase;
      } else if (providedNet && providedNet > 0) {
        // محاسبه معکوس: خالص هدف → حقوق پایه (با زمینه کامل کارمند)
        const params = await getLegalParams();
        const solved = solveEmployeeBaseForNet(emp as unknown as EmployeeSalaryLike, params, todayJalaliStr(), providedNet);
        if (!solved.ok) {
          return Response.json(
            { error: `خالص هدف کمتر از حداقل قابل‌تحقق (${solved.minAchievableNet.toLocaleString("en-US")} ریال) است.` },
            { status: 400 }
          );
        }
        newBase = solved.baseSalary;
        targetNet = providedNet;
      } else {
        return Response.json({ error: "حقوق پایه جدید یا خالص هدف را وارد کنید." }, { status: 400 });
      }

      const res = await upsertDrafts(session, [
        {
          employeeId,
          newBaseSalary: newBase,
          newOvertimeHours: b.newOvertimeHours !== undefined ? Math.max(0, +b.newOvertimeHours || 0) : emp.overtimeHours,
          newJobGradeId: b.newJobGradeId !== undefined ? b.newJobGradeId || null : null,
          targetNet,
          source: targetNet ? "REVERSE" : "MANUAL",
          reason: b.reason ? String(b.reason) : "",
        },
      ]);
      return { ...res, drafts: res.created + res.updated };
    }

    // ---------- حالت گروهی ----------
    if (mode === "bulk") {
      const op = b.operation || {};
      const type = String(op.type || "");
      const value = Number(op.value);
      if (!["PERCENT_BASE", "SET_BASE", "ADD_BASE", "SET_OVERTIME"].includes(type)) {
        return Response.json({ error: "نوع عملیات گروهی نامعتبر است." }, { status: 400 });
      }
      if (isNaN(value)) return Response.json({ error: "مقدار عملیات نامعتبر است." }, { status: 400 });
      if (type === "PERCENT_BASE" && (value <= -100 || value > 1000)) {
        return Response.json({ error: "درصد باید بین ۱۰۰- و ۱۰۰۰ باشد." }, { status: 400 });
      }
      if (type === "SET_BASE" && value <= 0) {
        return Response.json({ error: "مبلغ جدید حقوق پایه باید مثبت باشد." }, { status: 400 });
      }

      // انتخاب کارکنان: فهرست صریح یا همه فعال (فیلتر دپارتمان/طبقه پایین‌تر اعمال می‌شود)
      const ids: string[] = Array.isArray(b.employeeIds) ? b.employeeIds.map(String).filter(Boolean) : [];
      const f = b.filter || {};
      const employees = await db.employee.findMany({
        where: {
          status: "ACTIVE",
          ...(ids.length > 0 ? { id: { in: ids } } : {}),
        },
        include: { jobGrade: true, departments: { include: { department: true } } },
        orderBy: [{ lastName: "asc" }, { firstName: "asc" }],
      });

      // فیلتر دپارتمان/طبقه (بر اساس رابطه)
      let targets = employees;
      if (ids.length === 0) {
        if (f.departmentId) {
          const depEmps = await db.employeeDepartment.findMany({ where: { departmentId: f.departmentId }, select: { employeeId: true } });
          const depSet = new Set(depEmps.map((d) => d.employeeId));
          targets = targets.filter((e) => depSet.has(e.id));
        }
        if (f.gradeId !== undefined && f.gradeId !== null && f.gradeId !== "") {
          if (f.gradeId === "NONE") targets = targets.filter((e) => !e.jobGradeId);
          else targets = targets.filter((e) => e.jobGradeId === f.gradeId);
        }
      }

      if (targets.length === 0) return Response.json({ error: "کارمندی برای این عملیات انتخاب نشده است." }, { status: 400 });

      const inputs: DraftInput[] = [];
      const errors: string[] = [];
      for (const emp of targets) {
        const oldBase = Number(emp.baseSalary);
        let newBase = oldBase;
        let newOvertime = emp.overtimeHours;
        if (type === "PERCENT_BASE") newBase = Math.round(oldBase * (1 + value / 100));
        else if (type === "SET_BASE") newBase = Math.round(value);
        else if (type === "ADD_BASE") newBase = Math.round(oldBase + value);
        else if (type === "SET_OVERTIME") newOvertime = Math.max(0, Math.round(value));
        if (newBase <= 0) {
          errors.push(`${emp.firstName} ${emp.lastName}: پایه محاسبه‌شده نامعتبر`);
          continue;
        }
        inputs.push({
          employeeId: emp.id,
          newBaseSalary: newBase,
          newOvertimeHours: newOvertime,
          newJobGradeId: null,
          source: "BULK",
          reason: b.reason ? String(b.reason) : "",
        });
      }

      const res = await upsertDrafts(session, inputs);
      await audit(
        session,
        "CREATE",
        "SALARY_DRAFT",
        "BULK",
        `پیش‌نویس گروهی برای ${res.created + res.updated} کارمند — عملیات ${type} (${value})`,
        undefined,
        { type, value, ...res }
      );
      return { ...res, drafts: res.created + res.updated, errors };
    }

    // ---------- حالت معکوس گروهی ----------
    if (mode === "reverse") {
      const items = Array.isArray(b.items) ? b.items : [];
      if (items.length === 0) return Response.json({ error: "فهرست تغییرات خالی است." }, { status: 400 });
      const params = await getLegalParams();
      const atDateJ = todayJalaliStr();

      const inputs: DraftInput[] = [];
      const errors: string[] = [];
      for (const it of items.slice(0, 500)) {
        const employeeId = String(it.employeeId || "");
        const targetNet = Math.round(+it.targetNet || 0);
        if (!employeeId || targetNet <= 0) continue;
        const emp = await db.employee.findUnique({ where: { id: employeeId }, include: { jobGrade: true } });
        if (!emp) continue;
        const solved = solveEmployeeBaseForNet(emp as unknown as EmployeeSalaryLike, params, atDateJ, targetNet);
        if (!solved.ok) {
          errors.push(`${emp.firstName} ${emp.lastName}: خالص هدف کمتر از حداقل قابل‌تحقق`);
          continue;
        }
        if (solved.baseSalary <= 0) {
          errors.push(`${emp.firstName} ${emp.lastName}: پایه معکوس صفر شد`);
          continue;
        }
        inputs.push({
          employeeId,
          newBaseSalary: solved.baseSalary,
          newOvertimeHours: emp.overtimeHours,
          newJobGradeId: null,
          targetNet,
          source: "REVERSE",
          reason: b.reason ? String(b.reason) : "",
        });
      }

      if (inputs.length === 0) {
        return Response.json({ error: errors.length ? errors[0] : "تغییر معتبری برای ثبت وجود ندارد." }, { status: 400 });
      }
      const res = await upsertDrafts(session, inputs);
      return { ...res, drafts: res.created + res.updated, errors };
    }

    return Response.json({ error: "حالت نامعتبر است." }, { status: 400 });
  });
}

/**
 * PATCH /api/salary/drafts — تأیید و اعمال / رد پیش‌نویس‌ها
 * { action: "APPLY" | "APPLY_ALL" | "DISCARD" | "DISCARD_ALL", ids?: string[], note?: string }
 */
export async function PATCH(req: NextRequest) {
  return handle(async () => {
    const session = requirePerm(req, "salary:manage");
    const b = await req.json();
    const action = String(b.action || "");
    const ids: string[] = Array.isArray(b.ids) ? b.ids.map(String).filter(Boolean) : [];

    if (action === "APPLY" || action === "APPLY_ALL") {
      if (action === "APPLY" && ids.length === 0) {
        return Response.json({ error: "شناسه پیش‌نویس انتخاب نشده است." }, { status: 400 });
      }
      const res = await applyDrafts(session, action === "APPLY_ALL" ? "ALL" : ids, b.note ? String(b.note) : undefined);
      return { applied: res.applied, totalDelta: res.totalDelta };
    }

    if (action === "DISCARD" || action === "DISCARD_ALL") {
      if (action === "DISCARD" && ids.length === 0) {
        return Response.json({ error: "شناسه پیش‌نویس انتخاب نشده است." }, { status: 400 });
      }
      const count = await discardDrafts(session, action === "DISCARD_ALL" ? "ALL" : ids);
      return { discarded: count };
    }

    return Response.json({ error: "عملیات نامعتبر است." }, { status: 400 });
  });
}

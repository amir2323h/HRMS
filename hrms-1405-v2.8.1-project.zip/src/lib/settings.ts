// ============================================================
// تنظیمات و پارامترهای قانونی — بارگذاری از DB با کش در حافظه
// ============================================================
import { db } from "@/lib/db";
import { LEGAL_DEFAULTS_1405, type LegalParams, type TaxBracket } from "@/lib/payroll/engine";

let cache: { params: LegalParams; loadedAt: number } | null = null;
const TTL = 15_000; // ۱۵ ثانیه

export async function getLegalParams(force = false): Promise<LegalParams> {
  if (!force && cache && Date.now() - cache.loadedAt < TTL) return cache.params;

  const [settingRow, brackets] = await Promise.all([
    db.systemSetting.findUnique({ where: { key: "legal_params" } }),
    db.taxBracket.findMany({ where: { year: 1405 }, orderBy: { sortOrder: "asc" } }),
  ]);

  let params: LegalParams = { ...LEGAL_DEFAULTS_1405 };
  if (settingRow) {
    try {
      const stored = JSON.parse(settingRow.value) as Partial<LegalParams>;
      params = { ...params, ...stored, taxBrackets: params.taxBrackets };
    } catch { /* مقادیر پیش‌فرض */ }
  }
  if (brackets.length > 0) {
    params.taxBrackets = brackets.map((b) => ({
      sortOrder: b.sortOrder,
      lowerLimit: Number(b.lowerLimit),
      upperLimit: b.upperLimit === null ? null : Number(b.upperLimit),
      rate: b.rate,
    }));
  }
  cache = { params, loadedAt: Date.now() };
  return params;
}

export async function saveLegalParams(params: LegalParams): Promise<void> {
  const { taxBrackets, ...rest } = params;
  await db.systemSetting.upsert({
    where: { key: "legal_params" },
    update: { value: JSON.stringify(rest) },
    create: { key: "legal_params", value: JSON.stringify(rest) },
  });
  // بازنویسی پله‌ها
  await db.taxBracket.deleteMany({ where: { year: params.year } });
  for (const b of taxBrackets) {
    await db.taxBracket.create({
      data: {
        year: params.year,
        sortOrder: b.sortOrder,
        lowerLimit: BigInt(Math.round(b.lowerLimit)),
        upperLimit: b.upperLimit === null ? null : BigInt(Math.round(b.upperLimit)),
        rate: b.rate,
      },
    });
  }
  cache = null; // بی‌اعتبارسازی کش
}

export async function getDisplaySettings(): Promise<{ unit: "RIAL" | "TOMAN" }> {
  const row = await db.systemSetting.findUnique({ where: { key: "display" } });
  if (row) {
    try {
      return { unit: "TOMAN", ...(JSON.parse(row.value) as { unit?: "RIAL" | "TOMAN" }) };
    } catch { /* پیش‌فرض */ }
  }
  return { unit: "TOMAN" };
}

export interface CompanyInfo {
  name: string; nationalId: string; ssoCode: string; taxId: string; address: string;
  phone: string; mobile: string; website: string; email: string;
}

export async function getCompanyInfo(): Promise<CompanyInfo> {
  const row = await db.systemSetting.findUnique({ where: { key: "company" } });
  const defaults: CompanyInfo = {
    name: "شرکت فناوران داده پارس",
    nationalId: "10101234567",
    ssoCode: "22-104578-0",
    taxId: "41111234567890",
    address: "تهران، خیابان ولیعصر، برج فناوری، طبقه ۱۲",
    phone: "",
    mobile: "",
    website: "",
    email: "",
  };
  if (row) {
    try {
      return { ...defaults, ...(JSON.parse(row.value) as Record<string, string>) };
    } catch { /* پیش‌فرض */ }
  }
  return defaults;
}

// ============================ برندینگ (عنوان / لوگو / فاوآیکون) ============================
export interface Branding {
  title: string; // عنوان سامانه (title صفحه + سایدبار + لاگین)
  subtitle: string; // زیرعنوان
  logo: string; // data URL لوگو (خالی = لوگوی پیش‌فرض)
  favicon: string; // data URL فاوآیکون (خالی = بدون تغییر)
  footerText: string; // متن پابرگ (فوتر) — خالی = پیش‌فرض
}

/** برندینگ + نام شرکت (یکپارچه برای UI — نام شرکت از «اطلاعات شرکت» خوانده می‌شود) */
export type BrandingWithCompany = Branding & { companyName: string };

const BRANDING_DEFAULTS: Branding = {
  title: "سامانه جامع منابع انسانی",
  subtitle: "مدیریت کارکنان، حقوق و دستمزد و محاسبه معکوس — سال ۱۴۰۵",
  logo: "",
  favicon: "",
  footerText: "",
};

/** متن پیش‌فرض فوتر وقتی متن سفارشی تنظیم نشده است */
export function defaultFooterText(): string {
  return "سامانه جامع منابع انسانی و حقوق و دستمزد ۱۴۰۵ • مطابق ماده ۸۵ قانون بودجه ۱۴۰۵ و مقررات تأمین اجتماعی";
}

export async function getBranding(): Promise<BrandingWithCompany> {
  const [row, company] = await Promise.all([
    db.systemSetting.findUnique({ where: { key: "branding" } }),
    getCompanyInfo(),
  ]);
  const stored: Branding = row
    ? (() => {
        try {
          return { ...BRANDING_DEFAULTS, ...(JSON.parse(row.value) as Partial<Branding>) };
        } catch {
          return { ...BRANDING_DEFAULTS };
        }
      })()
    : { ...BRANDING_DEFAULTS };
  // نام شرکت از «اطلاعات شرکت» (تنظیمات قانونی) — یک منبع حقیقت برای فیش/نامه/سایدبار
  return { ...stored, companyName: company.name };
}

export async function saveBranding(b: Partial<Branding>): Promise<void> {
  const current = await getBranding();
  const next: Branding = {
    title: b.title ?? current.title,
    subtitle: b.subtitle ?? current.subtitle,
    logo: b.logo ?? current.logo,
    favicon: b.favicon ?? current.favicon,
    footerText: b.footerText ?? current.footerText,
  };
  await db.systemSetting.upsert({
    where: { key: "branding" },
    update: { value: JSON.stringify(next) },
    create: { key: "branding", value: JSON.stringify(next) },
  });
}

/** ذخیره نام شرکت — منبع حقیقت: SystemSetting «company» (قابل ویرایش از تب برندینگ و پارامترهای قانونی) */
export async function saveCompanyName(name: string): Promise<void> {
  const current = await getCompanyInfo();
  await db.systemSetting.upsert({
    where: { key: "company" },
    update: { value: JSON.stringify({ ...current, name }) },
    create: { key: "company", value: JSON.stringify({ ...current, name }) },
  });
}

// ============================ حالت دمو ============================
// کنترل نمایش حساب‌های نمونه در صفحه ورود — پیش‌فرض خاموش.
// فعال‌سازی فقط برای نمایش/آموزش؛ در محیط واقعی باید خاموش باشد.

export async function getDemoMode(): Promise<boolean> {
  const row = await db.systemSetting.findUnique({ where: { key: "demo_mode" } });
  if (row) {
    try {
      const v = JSON.parse(row.value) as { enabled?: boolean };
      return !!v.enabled;
    } catch {
      return false;
    }
  }
  return false;
}

export async function saveDemoMode(enabled: boolean): Promise<void> {
  await db.systemSetting.upsert({
    where: { key: "demo_mode" },
    update: { value: JSON.stringify({ enabled: !!enabled }) },
    create: { key: "demo_mode", value: JSON.stringify({ enabled: !!enabled }) },
  });
}

// ============================ ورود دو مرحله‌ای (2FA) ============================
// فعال‌سازی سراسری ورود دو مرحله‌ای (TOTP) برای لاگین با نام کاربری/رمز —
// کنترل از «تنظیمات ← ورود و امنیت». ورود یکپارچه OAuth (گوگل/Mattermost)
// از 2FA خود سرویس خارجی استفاده می‌کند و مشمول این تنظیم نیست.

export async function get2faEnabled(): Promise<boolean> {
  const row = await db.systemSetting.findUnique({ where: { key: "auth_2fa" } });
  if (row) {
    try {
      const v = JSON.parse(row.value) as { enabled?: boolean };
      return !!v.enabled;
    } catch {
      return false;
    }
  }
  return false;
}

export async function save2faEnabled(enabled: boolean): Promise<void> {
  await db.systemSetting.upsert({
    where: { key: "auth_2fa" },
    update: { value: JSON.stringify({ enabled: !!enabled }) },
    create: { key: "auth_2fa", value: JSON.stringify({ enabled: !!enabled }) },
  });
}

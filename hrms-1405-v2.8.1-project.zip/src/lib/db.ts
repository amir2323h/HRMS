import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

function createDbClient(): PrismaClient {
  return new PrismaClient({
    log: ['query'],
  })
}

// کلاینت جاری — پس از «بازیابی پشتیبان» با recreateDbClient جایگزین می‌شود
let current: PrismaClient = globalForPrisma.prisma ?? createDbClient()
globalForPrisma.prisma = current

/** بستن اتصال جاری (پیش از جایگزینی فایل دیتابیس در بازیابی پشتیبان) */
export async function closeDbClient(): Promise<void> {
  try {
    await current.$disconnect()
  } catch {
    /* اتصال از قبل بسته است */
  }
}

/**
 * ساخت کلاینت تازه روی همان DATABASE_URL — پس از سوئاپ فایل دیتابیس
 * (بازیابی پشتیبان) فراخوانی می‌شود؛ همه ماژول‌ها از طریق پروکسی `db`
 * خودکار به کلاینت جدید هدایت می‌شوند و نیازی به ری‌استارت سرویس نیست.
 */
export function recreateDbClient(): void {
  current = createDbClient()
  globalForPrisma.prisma = current
}

/**
 * پروکسی شفاف روی کلاینت جاری — سطح import همان `db` قبلی است؛
 * پس از بازیابی پشتیبان، درخواست‌های جدید بدون ری‌استارت به دیتابیس
 * بازیابی‌شده می‌روند.
 */
export const db: PrismaClient = new Proxy({} as PrismaClient, {
  get(_target, prop) {
    const value = Reflect.get(current as unknown as object, prop)
    if (typeof value === 'function') {
      return (value as (...args: unknown[]) => unknown).bind(current)
    }
    return value
  },
})

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = current

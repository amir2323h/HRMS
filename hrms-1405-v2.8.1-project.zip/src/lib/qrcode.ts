// ============================================================
// مولد کد QR بومی — بدون هیچ وابستگی خارجی (کاملاً آفلاین)
// حالت بایت (UTF-8) • نسخه‌های ۱ تا ۶ • سطح تصحیح L یا M
// انتخاب ماسک با قواعد جریمه استاندارد • خروجی SVG درون‌خطی
// کاربرد: QR راستی‌آزمایی امضای دیجیتال در سند چاپی نامه
// (مرجع الگوریتم: ISO/IEC 18004 — پیاده‌سازی مستقل فشرده)
// ============================================================

export type QrEcc = "L" | "M";

/** مشخصات بلوک رید–سولومون هر نسخه/سطح (v1–v6، بلوک‌های هم‌اندازه) */
interface VersionSpec {
  blocks: number; // تعداد بلوک‌های داده
  dataPerBlock: number; // کلمه‌های کد داده در هر بلوک
  eccPerBlock: number; // کلمه‌های کد تصحیح در هر بلوک
}

const VERSION_TABLE: Record<QrEcc, Record<number, VersionSpec>> = {
  // جمع کل کلمه‌های کد: v1=26, v2=44, v3=70, v4=100, v5=134, v6=172
  L: {
    1: { blocks: 1, dataPerBlock: 19, eccPerBlock: 7 },
    2: { blocks: 1, dataPerBlock: 34, eccPerBlock: 10 },
    3: { blocks: 1, dataPerBlock: 55, eccPerBlock: 15 },
    4: { blocks: 1, dataPerBlock: 80, eccPerBlock: 20 },
    5: { blocks: 1, dataPerBlock: 108, eccPerBlock: 26 },
    6: { blocks: 2, dataPerBlock: 68, eccPerBlock: 18 },
  },
  M: {
    1: { blocks: 1, dataPerBlock: 16, eccPerBlock: 10 },
    2: { blocks: 1, dataPerBlock: 28, eccPerBlock: 16 },
    3: { blocks: 1, dataPerBlock: 44, eccPerBlock: 26 },
    4: { blocks: 2, dataPerBlock: 32, eccPerBlock: 18 },
    5: { blocks: 2, dataPerBlock: 43, eccPerBlock: 24 },
    6: { blocks: 4, dataPerBlock: 27, eccPerBlock: 16 },
  },
};

/** مختصات الگوهای هم‌ترازی (نسخه ۱ ندارد؛ v2–v6 فقط تقاطع میانی) */
const ALIGN_POS: Record<number, number[]> = {
  2: [6, 18],
  3: [6, 22],
  4: [6, 26],
  5: [6, 30],
  6: [6, 34],
};

const MIN_VERSION = 1;
const MAX_VERSION = 6;

// ---------- میدان متناهی GF(256) — چندجمله‌ای اولیه 0x11D ----------

const GF_EXP = new Uint8Array(512);
const GF_LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) GF_EXP[i] = GF_EXP[i - 255];
})();

function gfMul(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return GF_EXP[GF_LOG[a] + GF_LOG[b]];
}

/** چندجمله‌ای مولد رید–سولومون با درجه مشخص */
function rsDivisor(degree: number): number[] {
  const poly = new Array<number>(degree).fill(0);
  poly[degree - 1] = 1; // x^0
  let root = 1;
  for (let i = 0; i < degree; i++) {
    // ضرب حاصل در (x - α^i)
    for (let j = 0; j < degree; j++) {
      poly[j] = gfMul(poly[j], root);
      if (j + 1 < degree) poly[j] ^= poly[j + 1];
    }
    root = gfMul(root, 0x02);
  }
  return poly;
}

/** باقیمانده تقسیم داده بر چندجمله‌ای مولد (کلمه‌های کد تصحیح) */
function rsRemainder(data: readonly number[], divisor: readonly number[]): number[] {
  const result = new Array<number>(divisor.length).fill(0);
  for (const b of data) {
    const factor = b ^ (result.shift() as number);
    result.push(0);
    for (let i = 0; i < divisor.length; i++) result[i] ^= gfMul(divisor[i], factor);
  }
  return result;
}

// ---------- ساخت ماتریس نماد ----------

interface Matrix {
  size: number;
  modules: boolean[][]; // [y][x] تیره؟
  isFunction: boolean[][]; // ماژول عملکردی (نشانگر/زمانبندی/قالب…) — از ماسک مستثنا
}

function getBit(x: number, i: number): boolean {
  return ((x >>> i) & 1) !== 0;
}

function makeMatrix(version: number, ecc: QrEcc, dataCodewords: number[], msk: number): Matrix {
  const size = version * 4 + 17;
  const modules: boolean[][] = Array.from({ length: size }, () => new Array<boolean>(size).fill(false));
  const isFunction: boolean[][] = Array.from({ length: size }, () => new Array<boolean>(size).fill(false));

  const set = (x: number, y: number, dark: boolean) => {
    modules[y][x] = dark;
    isFunction[y][x] = true;
  };

  // الگوهای زمانبندی (سطر/ستون ۶) — پیش از نشانگرها تا لبه نشانگرها بازنویسی شوند
  for (let i = 0; i < size; i++) {
    set(6, i, i % 2 === 0);
    set(i, 6, i % 2 === 0);
  }

  // نشانگرهای گوشه (۷×۷ + جداکننده)
  const drawFinder = (cx: number, cy: number) => {
    for (let dy = -4; dy <= 4; dy++) {
      for (let dx = -4; dx <= 4; dx++) {
        const x = cx + dx;
        const y = cy + dy;
        if (x < 0 || x >= size || y < 0 || y >= size) continue;
        const dist = Math.max(Math.abs(dx), Math.abs(dy));
        set(x, y, dist !== 2 && dist !== 4);
      }
    }
  };
  drawFinder(3, 3);
  drawFinder(size - 4, 3);
  drawFinder(3, size - 4);

  // الگوهای هم‌ترازی (v≥2 — فقط تقاطع‌های بدون هم‌پوشانی با نشانگر)
  const align = ALIGN_POS[version] || [];
  const numAlign = align.length;
  for (let i = 0; i < numAlign; i++) {
    for (let j = 0; j < numAlign; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === numAlign - 1) || (i === numAlign - 1 && j === 0)) continue;
      const cx = align[i];
      const cy = align[j];
      for (let dy = -2; dy <= 2; dy++) {
        for (let dx = -2; dx <= 2; dx++) {
          set(cx + dx, cy + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
        }
      }
    }
  }

  // بیت‌های قالب (سطح تصحیح + ماسک) — دو نسخه + ماژول تیره ثابت
  const formatBits = (() => {
    const eccBits = ecc === "L" ? 1 : 0; // L=01, M=00
    const data = (eccBits << 3) | msk;
    let rem = data;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    return ((data << 10) | rem) ^ 0x5412;
  })();
  const drawFormat = (x: number, y: number, dark: boolean) => set(x, y, dark);
  for (let i = 0; i <= 5; i++) drawFormat(8, i, getBit(formatBits, i));
  drawFormat(8, 7, getBit(formatBits, 6));
  drawFormat(8, 8, getBit(formatBits, 7));
  drawFormat(7, 8, getBit(formatBits, 8));
  for (let i = 9; i < 15; i++) drawFormat(14 - i, 8, getBit(formatBits, i));
  for (let i = 0; i < 8; i++) drawFormat(size - 1 - i, 8, getBit(formatBits, i));
  for (let i = 8; i < 15; i++) drawFormat(8, size - 15 + i, getBit(formatBits, i));
  drawFormat(8, size - 8, true); // ماژول همیشه‌تیره

  // جای‌گذاری داده زیگزاگی دوستونه (راست به چپ، پرهیز از ستون ۶)
  let i = 0;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) {
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? size - 1 - vert : vert;
        if (!isFunction[y][x] && i < dataCodewords.length * 8) {
          modules[y][x] = getBit(dataCodewords[i >>> 3], 7 - (i & 7));
          i++;
        }
      }
    }
  }

  // اعمال ماسک فقط روی ماژول‌های داده
  const mask = MASKS[msk];
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (isFunction[y][x]) continue;
      if (mask(x, y)) modules[y][x] = !modules[y][x];
    }
  }

  return { size, modules, isFunction };
}

/** توابع ماسک ۰ تا ۷ (استاندارد) */
const MASKS: ((x: number, y: number) => boolean)[] = [
  (x, y) => (x + y) % 2 === 0,
  (_x, y) => y % 2 === 0,
  (x) => x % 3 === 0,
  (x, y) => (x + y) % 3 === 0,
  (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0,
  (x, y) => ((x * y) % 2) + ((x * y) % 3) === 0,
  (x, y) => (((x * y) % 2) + ((x * y) % 3)) % 2 === 0,
  (x, y) => (((x + y) % 2) + ((x * y) % 3)) % 2 === 0,
];

// ---------- امتیاز جریمه (انتخاب بهترین ماسک) ----------

function penaltyScore(m: Matrix): number {
  const { size, modules } = m;
  let score = 0;

  const rowStr = (y: number) => modules[y].map((d) => (d ? "1" : "0")).join("");
  const colStr = (x: number) => modules.map((row) => (row[x] ? "1" : "0")).join("");

  // N1: دنباله‌های هم‌رنگ ≥۵ در سطر/ستون
  const runPenalty = (s: string) => {
    let pen = 0;
    let run = 1;
    for (let i = 1; i <= s.length; i++) {
      if (i < s.length && s[i] === s[i - 1]) run++;
      else {
        if (run >= 5) pen += 3 + (run - 5);
        run = 1;
      }
    }
    return pen;
  };
  for (let y = 0; y < size; y++) score += runPenalty(rowStr(y));
  for (let x = 0; x < size; x++) score += runPenalty(colStr(x));

  // N2: بلوک‌های ۲×۲ هم‌رنگ
  for (let y = 0; y < size - 1; y++) {
    for (let x = 0; x < size - 1; x++) {
      const c = modules[y][x];
      if (c === modules[y][x + 1] && c === modules[y + 1][x] && c === modules[y + 1][x + 1]) score += 3;
    }
  }

  // N3: الگوی نشانگرمانند 1011101 با ۴ ماژول روشن در یک طرف
  const finderPenalty = (s: string) => {
    let pen = 0;
    for (let i = 0; i + 11 <= s.length; i++) {
      const w = s.slice(i, i + 11);
      if (w === "00001011101" || w === "10111010000") pen += 40;
    }
    return pen;
  };
  for (let y = 0; y < size; y++) score += finderPenalty(rowStr(y));
  for (let x = 0; x < size; x++) score += finderPenalty(colStr(x));

  // N4: توازن تیره/روشن
  let dark = 0;
  for (const row of modules) for (const c of row) if (c) dark++;
  const total = size * size;
  score += Math.floor(Math.abs(dark * 20 - total * 10) / total) * 10;

  return score;
}

// ---------- کدگذاری ----------

function toUtf8Bytes(text: string): number[] {
  return Array.from(new TextEncoder().encode(text));
}

/** جریان بیت داده: حالت بایت + شمارنده + پایان‌بند + پرکننده */
function buildCodewords(text: string, version: number, ecc: QrEcc): number[] {
  const spec = VERSION_TABLE[ecc][version];
  const dataCount = spec.blocks * spec.dataPerBlock;
  const bytes = toUtf8Bytes(text);
  const bits: number[] = [];
  const push = (val: number, len: number) => {
    for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1);
  };
  push(0b0100, 4); // حالت بایت
  push(bytes.length, 8); // شمارنده (v1–v9)
  for (const b of bytes) push(b, 8);
  const cap = dataCount * 8;
  const terminator = Math.min(4, cap - bits.length);
  push(0, terminator);
  while (bits.length % 8 !== 0) bits.push(0);
  const data: number[] = [];
  for (let i = 0; i < bits.length; i += 8) {
    let v = 0;
    for (let j = 0; j < 8; j++) v = (v << 1) | bits[i + j];
    data.push(v);
  }
  // پرکننده استاندارد 0xEC / 0x11
  for (let pad = 0xec; data.length < dataCount; pad ^= 0xfd) data.push(pad);

  // رید–سولومون هر بلوک + درهم‌بافی
  const divisor = rsDivisor(spec.eccPerBlock);
  const blocksData: number[][] = [];
  const blocksEcc: number[][] = [];
  for (let b = 0; b < spec.blocks; b++) {
    const chunk = data.slice(b * spec.dataPerBlock, (b + 1) * spec.dataPerBlock);
    blocksData.push(chunk);
    blocksEcc.push(rsRemainder(chunk, divisor));
  }
  const out: number[] = [];
  for (let i = 0; i < spec.dataPerBlock; i++) for (const blk of blocksData) out.push(blk[i]);
  for (let i = 0; i < spec.eccPerBlock; i++) for (const blk of blocksEcc) out.push(blk[i]);
  return out;
}

/** انتخاب کوچک‌ترین نسخه‌ای که متن را در خود جای می‌دهد (ترجیح M، سپس L) */
function pickVersion(text: string): { version: number; ecc: QrEcc } {
  const len = toUtf8Bytes(text).length;
  for (const ecc of ["M", "L"] as QrEcc[]) {
    for (let v = MIN_VERSION; v <= MAX_VERSION; v++) {
      if (len <= VERSION_TABLE[ecc][v].blocks * VERSION_TABLE[ecc][v].dataPerBlock - 2) {
        return { version: v, ecc };
      }
    }
  }
  throw new Error("QR: متن برای نسخه‌های پشتیبانی‌شده بیش‌ازحد بلند است");
}

/** ساخت ماتریس QR کامل (انتخاب بهترین ماسک — یا ماسک اجباری برای تست) */
export function qrMatrix(
  text: string,
  opts?: { ecc?: QrEcc; mask?: number; version?: number }
): { size: number; modules: boolean[][]; version: number; ecc: QrEcc; mask: number } {
  const { version, ecc } = (() => {
    if (opts?.version && opts?.ecc) return { version: opts.version, ecc: opts.ecc };
    if (opts?.ecc) {
      const len = toUtf8Bytes(text).length;
      for (let v = MIN_VERSION; v <= MAX_VERSION; v++) {
        if (len <= VERSION_TABLE[opts.ecc][v].blocks * VERSION_TABLE[opts.ecc][v].dataPerBlock - 2) {
          return { version: v, ecc: opts.ecc };
        }
      }
      throw new Error("QR: متن برای سطح تصحیح خواسته‌شده جا نمی‌شود");
    }
    return pickVersion(text);
  })();
  const codewords = buildCodewords(text, version, ecc);
  let best: Matrix | null = null;
  let bestScore = Infinity;
  let bestMask = 0;
  const masks = opts?.mask !== undefined && opts.mask >= 0 ? [opts.mask] : [0, 1, 2, 3, 4, 5, 6, 7];
  for (const msk of masks) {
    const m = makeMatrix(version, ecc, codewords, msk);
    const s = penaltyScore(m);
    if (s < bestScore) {
      bestScore = s;
      best = m;
      bestMask = msk;
    }
  }
  const result = best as Matrix;
  return { size: result.size, modules: result.modules, version, ecc, mask: bestMask };
}

/** خروجی SVG درون‌خطی — حاشیه سکوت ۴ ماژول، پس‌زمینه سفید، مسیر ماژول‌های تیره
 *  width/height صریح (۴px بر ماژول) تا در ظرف بدون اندازه CSS هم رندر شود؛
 *  CSS ظرف (مثل .ds-qr svg) همیشه بر مقدار صفت اولویت دارد */
export function qrCodeSvg(
  text: string,
  opts?: { ecc?: QrEcc; dark?: string; light?: string; margin?: number; scale?: number }
): string {
  const { size, modules } = qrMatrix(text, { ecc: opts?.ecc });
  const quiet = opts?.margin ?? 4;
  const total = size + quiet * 2;
  const px = (opts?.scale ?? 4) * total;
  const dark = opts?.dark || "#0f172a";
  const light = opts?.light || "#ffffff";
  let path = "";
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (modules[y][x]) path += `M${x + quiet},${y + quiet}h1v1h-1z`;
    }
  }
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" width="${px}" height="${px}" viewBox="0 0 ${total} ${total}" shape-rendering="crispEdges" role="img" aria-label="QR">` +
    `<rect width="${total}" height="${total}" fill="${light}"/>` +
    `<path d="${path}" fill="${dark}"/>` +
    `</svg>`
  );
}

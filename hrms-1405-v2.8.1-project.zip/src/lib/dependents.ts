// ============================================================
// افراد تحت پوشش بیمه تکمیلی — اعتبارسنجی و نرمال‌سازی مشترک
// بین POST و PATCH کارکنان
// ============================================================
import { isValidNationalId } from "./format";
import { isValidJalali } from "./jalali";

export const DEPENDENT_RELATIONSHIPS = ["SPOUSE", "SON", "DAUGHTER", "FATHER", "MOTHER", "FATHER_IN_LAW", "MOTHER_IN_LAW", "OTHER"] as const;

export interface DependentInput {
  firstName: string;
  lastName: string;
  nationalId: string;
  relationship: string;
  birthDateJ: string;
}

/**
 * اعتبارسنجی آرایه افراد تحت پوشش بیمه تکمیلی
 * @returns لیست پاکشده + خطاها (خطا = رد یا کل درخواست)
 */
export function validateDependents(deps: unknown, suppInsurance: string): { list: DependentInput[]; errors: string[] } {
  const errors: string[] = [];
  const list: DependentInput[] = [];

  if (deps === undefined || deps === null) return { list, errors };
  if (!Array.isArray(deps)) {
    errors.push("ساختار «افراد تحت پوشش» نامعتبر است.");
    return { list, errors };
  }
  if (deps.length > 20) {
    errors.push("حداکثر ۲۰ فرد تحت پوشش قابل ثبت است.");
    return { list, errors };
  }
  if (deps.length > 0 && suppInsurance !== "FAMILY") {
    errors.push("برای ثبت مشخصات افراد تحت پوشش، وضعیت بیمه تکمیلی باید «خانوادگی» باشد.");
    return { list, errors };
  }

  for (let i = 0; i < deps.length; i++) {
    const d = deps[i] as Record<string, unknown>;
    const firstName = String(d?.firstName || "").trim();
    const lastName = String(d?.lastName || "").trim();
    const nationalId = String(d?.nationalId || "").replace(/\D/g, "");
    const relationship = String(d?.relationship || "").trim();
    const birthDateJ = String(d?.birthDateJ || "").trim();
    const label = `فرد تحت پوشش ${i + 1}`;

    if (!firstName) errors.push(`${label}: نام الزامی است.`);
    if (!DEPENDENT_RELATIONSHIPS.includes(relationship as never)) errors.push(`${label}: نسبت را انتخاب کنید.`);
    if (nationalId) {
      if (!/^\d{10}$/.test(nationalId)) errors.push(`${label}: کد ملی باید ۱۰ رقم باشد.`);
      else if (!isValidNationalId(nationalId)) errors.push(`${label}: رقم کنترل کد ملی نامعتبر است.`);
    }
    if (birthDateJ && !isValidJalali(birthDateJ)) errors.push(`${label}: تاریخ تولد نامعتبر است (مثال: 1405/01/15).`);

    list.push({ firstName, lastName, nationalId, relationship, birthDateJ });
  }

  return { list, errors };
}

/** تعداد کل افراد تحت پوشش: خود بیمه‌شده + بستگان */
export function coveredCountFrom(suppInsurance: string, dependentsCount: number): number {
  if (suppInsurance === "FAMILY") return 1 + dependentsCount;
  if (suppInsurance === "INDIVIDUAL") return 1;
  return 0;
}

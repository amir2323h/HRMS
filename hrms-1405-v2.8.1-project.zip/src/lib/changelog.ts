// ============================================================
// اطلاعیه تغییرات محصول («تازه‌های نسخه») — پاپ‌آپ برای کاربران هدف
// مدیریت از تنظیمات: عنوان + فهرست تغییرات + هدف‌گیری (همه / نقش‌ها / کاربران)
// هر کاربر نسخه دیده‌شده را در User.changelogSeen نگه می‌دارد
// ============================================================
import { db } from "@/lib/db";

export interface ChangelogItem {
  tag: "NEW" | "IMPROVED" | "FIXED";
  title: string;
  desc: string;
}

export interface ChangelogConfig {
  version: string; // نسخه مربوطه (مثلاً 2.7.0)
  title: string; // عنوان اطلاعیه
  items: ChangelogItem[]; // فهرست تغییرات
  enabled: boolean; // نمایش پاپ‌آپ
  targetAll: boolean; // نمایش برای همه کاربران
  roles: string[]; // نقش‌های هدف (وقتی targetAll=false)
  usernames: string[]; // کاربران خاص هدف (وقتی targetAll=false)
  updatedAt: string; // ISO
}

export const CHANGELOG_DEFAULTS: ChangelogConfig = {
  version: "",
  title: "",
  items: [],
  enabled: false,
  targetAll: true,
  roles: [],
  usernames: [],
  updatedAt: "",
};

export function appVersion(): string {
  return (process.env.APP_VERSION || "").trim();
}

const TAGS: ChangelogItem["tag"][] = ["NEW", "IMPROVED", "FIXED"];

/** نرمال‌سازی پیکربندی اطلاعیه — حداکثر ۱۵ آیتم با متن تمیز */
export function parseChangelog(v: unknown): ChangelogConfig {
  const c = (v ?? {}) as Partial<ChangelogConfig>;
  const items = Array.isArray(c.items)
    ? c.items
        .map((it) => {
          const item = (it ?? {}) as Partial<ChangelogItem>;
          return {
            tag: TAGS.includes(item.tag as ChangelogItem["tag"]) ? (item.tag as ChangelogItem["tag"]) : "NEW",
            title: String(item.title ?? "").trim().slice(0, 120),
            desc: String(item.desc ?? "").trim().slice(0, 500),
          };
        })
        .filter((it) => it.title)
        .slice(0, 15)
    : [];
  return {
    version: String(c.version ?? "").trim().slice(0, 20),
    title: String(c.title ?? "").trim().slice(0, 120),
    items,
    enabled: !!c.enabled,
    targetAll: c.targetAll !== false,
    roles: Array.isArray(c.roles) ? c.roles.map(String).map((r) => r.trim()).filter(Boolean).slice(0, 20) : [],
    usernames: Array.isArray(c.usernames) ? c.usernames.map(String).map((u) => u.trim()).filter(Boolean).slice(0, 50) : [],
    updatedAt: String(c.updatedAt ?? ""),
  };
}

export async function getChangelog(): Promise<ChangelogConfig> {
  const row = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!row) return { ...CHANGELOG_DEFAULTS };
  try {
    return parseChangelog(JSON.parse(row.value));
  } catch {
    return { ...CHANGELOG_DEFAULTS };
  }
}

export async function saveChangelog(patch: Partial<ChangelogConfig>): Promise<ChangelogConfig> {
  const current = await getChangelog();
  const next: ChangelogConfig = {
    version: (patch.version ?? current.version).trim().slice(0, 20),
    title: (patch.title ?? current.title).trim().slice(0, 120),
    items: patch.items !== undefined ? parseChangelog({ items: patch.items }).items : current.items,
    enabled: patch.enabled !== undefined ? !!patch.enabled : current.enabled,
    targetAll: patch.targetAll !== undefined ? !!patch.targetAll : current.targetAll,
    roles: patch.roles !== undefined ? parseChangelog({ roles: patch.roles }).roles : current.roles,
    usernames: patch.usernames !== undefined ? parseChangelog({ usernames: patch.usernames }).usernames : current.usernames,
    updatedAt: new Date().toISOString(),
  };
  await db.systemSetting.upsert({
    where: { key: "changelog" },
    update: { value: JSON.stringify(next) },
    create: { key: "changelog", value: JSON.stringify(next) },
  });
  return next;
}

/** آیا این کاربر جزو مخاطبان اطلاعیه است؟ */
export function isChangelogTarget(cfg: ChangelogConfig, user: { role: string; username: string }): boolean {
  if (!cfg.enabled || !cfg.version) return false;
  if (cfg.targetAll) return true;
  return cfg.roles.includes(user.role) || cfg.usernames.includes(user.username);
}

// ============================================================
// حضور و غیب و تردد — نرمال‌سازی رکورد روزانه + تجمیع ماهانه
// سطل‌های ساعت: عادی / اضافه‌کاری / شب‌کاری (۲۲–۶) / جمعه‌کاری / تعطیل‌کاری
// مبنای محاسبه فیش حقوقی (ماده ۵۶/۵۸/۵۹/۶۲ قانون کار)
// ============================================================
import { jalaliWeekdayIndex, parseJalali, daysInJalaliMonth, formatJStr } from "@/lib/jalali";

export const ATTENDANCE_STATUSES = ["PRESENT", "ABSENT", "LEAVE", "MISSION", "FRIDAY", "HOLIDAY"] as const;
export type AttendanceStatus = (typeof ATTENDANCE_STATUSES)[number];

export const ATTENDANCE_STATUS_LABELS: Record<string, string> = {
  PRESENT: "حضور",
  ABSENT: "غیبت",
  LEAVE: "مرخصی",
  MISSION: "مأموریت",
  FRIDAY: "جمعه‌کاری",
  HOLIDAY: "تعطیل‌کاری",
};

export const ATTENDANCE_STATUS_BADGE: Record<string, string> = {
  PRESENT: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  ABSENT: "bg-rose-100 text-rose-700 hover:bg-rose-100",
  LEAVE: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  MISSION: "bg-violet-100 text-violet-700 hover:bg-violet-100",
  FRIDAY: "bg-teal-100 text-teal-700 hover:bg-teal-100",
  HOLIDAY: "bg-amber-100 text-amber-700 hover:bg-amber-100",
};

/** وضعیت‌هایی که ساعت کارکرد دارند (ورود/خروج معنادار) */
export const WORKED_STATUSES: AttendanceStatus[] = ["PRESENT", "FRIDAY", "HOLIDAY"];
export function isWorkedStatus(s: string): boolean {
  return (WORKED_STATUSES as string[]).includes(s);
}

// --------------------------- ابزار زمان ---------------------------

/** «08:30» → دقیقه از نیمه‌شب ( tolerant: «۸:۳۰» فارسی/ «8:30») */
export function timeJToMinutes(t: string): number | null {
  const m = String(t || "").trim().replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
  if (!m) return null;
  const mm = m.match(/^(\d{1,2}):(\d{2})$/);
  if (!mm) return null;
  const h = +mm[1];
  const min = +mm[2];
  if (h > 23 || min > 59) return null;
  return h * 60 + min;
}

/** دقیقه از نیمه‌شب → «HH:MM» */
export function minutesToTimeJ(min: number): string {
  const m = Math.max(0, Math.round(min));
  return `${String(Math.floor(m / 60) % 24).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
}

/** هم‌پوشانی بازه [aStart,aEnd] با بازه شب [۲۲:۰۰، ۰۶:۰۰] (دقیقه، بازه ممکن است از نیمه‌شب بگذرد) */
function nightOverlapMinutes(start: number, end: number): number {
  // بازه شب به‌صورت دایره‌ای: [1320, 1440) + [0, 360)
  let total = 0;
  // بازه‌های شب مطلق روی محور ۰..۱۴۴۰×۲ (برای شیفت‌های عبوری از نیمه‌شب)
  const segs: [number, number][] = [
    [1320, 1440],
    [1440, 1800], // ۰ تا ۶ فردا
  ];
  for (const [s, e] of segs) {
    const from = Math.max(start, s);
    const to = Math.min(end, e);
    if (to > from) total += to - from;
  }
  return total;
}

/** روز جمعه؟ (شنبه=۰ … جمعه=۶) */
export function isFridayJ(dateJ: string): boolean {
  const p = parseJalali(dateJ);
  if (!p) return false;
  return jalaliWeekdayIndex(p.jy, p.jm, p.jd) === 6;
}

/** روز پنجشنبه؟ (شنبه=۰ … پنجشنبه=۵) */
export function isThursdayJ(dateJ: string): boolean {
  const p = parseJalali(dateJ);
  if (!p) return false;
  return jalaliWeekdayIndex(p.jy, p.jm, p.jd) === 5;
}

/** روز هفته (شنبه=۰ … جمعه=۶) */
export function weekdayIndexJ(dateJ: string): number {
  const p = parseJalali(dateJ);
  if (!p) return -1;
  return jalaliWeekdayIndex(p.jy, p.jm, p.jd);
}

/**
 * روز تعطیل هفتگی برای نوع اشتغال؟
 *  • روزکار (DAILY): پنجشنبه + جمعه
 *  • شیفتی (SHIFT): جمعه
 * weekdaySet = مجموعه ایندکس روزهای تعطیل (خروجی weekendDaysFor)
 */
export function isWeekendFor(dateJ: string, employmentType: string, weekendSet: number[]): boolean {
  const wd = weekdayIndexJ(dateJ);
  return wd >= 0 && weekendSet.includes(wd);
}

/** پیش‌فرض هوشمند وضعیت روز بر اساس تقویم و نوع اشتغال:
 *  • تعطیل رسمی → تعطیل‌کاری (اگر کار شود)
 *  • تعطیل هفتگی (پنجشنبه/جمعه بر اساس نوع اشتغال) → جمعه‌کاری
 *  • غیر آن → حضور */
export function defaultStatusForDate(dateJ: string, opts?: { employmentType?: string; weekendSet?: number[]; isHoliday?: boolean }): AttendanceStatus {
  if (opts?.isHoliday) return "HOLIDAY";
  const weekendSet = opts?.weekendSet || (opts?.employmentType === "SHIFT" ? [6] : [5, 6]);
  if (isWeekendFor(dateJ, opts?.employmentType || "DAILY", weekendSet)) return "FRIDAY";
  return "PRESENT";
}

// --------------------------- نرمال‌سازی رکورد ---------------------------

export interface AttendanceBuckets {
  workHours: number;
  overtimeHours: number;
  nightHours: number;
  fridayHours: number;
  holidayHours: number;
}

/** محاسبه سطل‌های ساعت از ورود/خروج + وضعیت
 *  - PRESENT: عادی تا سقف شیفت (پس از کسر استراحت/ناهار)، مازاد اضافه‌کاری + هم‌پوشانی شب (۲۲–۶)
 *  - FRIDAY/HOLIDAY: کل ساعت → جمعه‌کاری/تعطیل‌کاری (بدون اضافه‌کاری جدا — علاوه بر مزد روز)
 *  - ABSENT/LEAVE/MISSION: بدون ساعت
 *  - عبور از نیمه‌شب (شیفت شب) پشتیبانی می‌شود */
export function computeBuckets(input: {
  checkInJ: string;
  checkOutJ: string;
  status: string;
  dailyStandardHours: number; // مثلاً ۸ (روزکار ۰۸–۱۷ با ناهار)
  breakMinutes?: number; // استراحت/ناهار داخل شیفت (مثلاً ۶۰ دقیقه روزکار)
}): AttendanceBuckets {
  const empty: AttendanceBuckets = { workHours: 0, overtimeHours: 0, nightHours: 0, fridayHours: 0, holidayHours: 0 };
  if (!isWorkedStatus(input.status)) return empty;
  const inMin = timeJToMinutes(input.checkInJ);
  const outMin = timeJToMinutes(input.checkOutJ);
  if (inMin === null || outMin === null) return empty;
  // مدت کار — اگر خروج ≤ ورود، شیفت از نیمه‌شب گذشته (شیفت شب)
  let dur = outMin - inMin;
  if (dur <= 0) dur += 1440;
  if (dur > 20 * 60) dur = 20 * 60; // سقف منطقی ۲۰ ساعت
  // استراحت داخل شیفت (ناهار) — فقط برای حضور عادی کسر می‌شود
  const brk = Math.max(0, Math.min(input.breakMinutes || 0, dur));
  const netDur = input.status === "PRESENT" ? dur - brk : dur;
  const hours = netDur / 60;

  if (input.status === "FRIDAY") return { ...empty, fridayHours: Math.round(hours * 100) / 100 };
  if (input.status === "HOLIDAY") return { ...empty, holidayHours: Math.round(hours * 100) / 100 };

  // PRESENT — عادی + اضافه‌کاری + شب
  const std = Math.max(0, input.dailyStandardHours);
  const work = Math.min(hours, std);
  const over = Math.max(0, hours - std);
  const night = nightOverlapMinutes(inMin, inMin + dur) / 60;
  return {
    workHours: Math.round(work * 100) / 100,
    overtimeHours: Math.round(over * 100) / 100,
    nightHours: Math.round(night * 100) / 100,
    fridayHours: 0,
    holidayHours: 0,
  };
}

/** اعتبارسنجی + نرمال‌سازی مقدار رکورد برای ذخیره — خروجی آماده Prisma */
export function normalizeAttendanceInput(b: Record<string, unknown>): {
  ok: true;
  data: {
    employeeId: string;
    dateJ: string;
    checkInJ: string;
    checkOutJ: string;
    status: AttendanceStatus;
    workHours: number;
    overtimeHours: number;
    nightHours: number;
    fridayHours: number;
    holidayHours: number;
    note: string;
  };
} | { ok: false; error: string } {
  const employeeId = String(b.employeeId || "").trim();
  if (!employeeId) return { ok: false, error: "کارمند الزامی است." };
  const dateJ = String(b.dateJ || "").trim();
  if (!/^\d{4}\/\d{2}\/\d{2}$/.test(dateJ)) return { ok: false, error: "تاریخ باید به شکل ۱۴۰۵/۰۷/۱۳ باشد." };

  let status = String(b.status || "PRESENT").toUpperCase();
  if (!(ATTENDANCE_STATUSES as readonly string[]).includes(status)) return { ok: false, error: "وضعیت نامعتبر است." };

  const checkInJ = String(b.checkInJ || "").trim();
  const checkOutJ = String(b.checkOutJ || "").trim();
  if (checkInJ && timeJToMinutes(checkInJ) === null) return { ok: false, error: "ساعت ورود نامعتبر است (مثال ۰۸:۳۰)." };
  if (checkOutJ && timeJToMinutes(checkOutJ) === null) return { ok: false, error: "ساعت خروج نامعتبر است (مثال ۱۷:۰۰)." };

  const std = Number(b.dailyStandardHours) > 0 ? Number(b.dailyStandardHours) : 220 / 30;
  const brk = Math.max(0, Math.min(Number(b.breakMinutes) || 0, 240));
  const auto = computeBuckets({ checkInJ, checkOutJ, status, dailyStandardHours: std, breakMinutes: brk });
  const clamp = (v: unknown) => Math.max(0, Math.min(24, Math.round((Number(v) || 0) * 100) / 100));

  // دستی: اگر مقدار صریح ارسال شده باشد (بازنویسی سرانگشتی مدیر) استفاده می‌شود
  const manual = b.manualBuckets === true;
  const data = {
    employeeId,
    dateJ,
    checkInJ: checkInJ.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))),
    checkOutJ: checkOutJ.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))),
    status: status as AttendanceStatus,
    workHours: manual ? clamp(b.workHours) : auto.workHours,
    overtimeHours: manual ? clamp(b.overtimeHours) : auto.overtimeHours,
    nightHours: manual ? clamp(b.nightHours) : auto.nightHours,
    fridayHours: manual ? clamp(b.fridayHours) : auto.fridayHours,
    holidayHours: manual ? clamp(b.holidayHours) : auto.holidayHours,
    note: String(b.note || "").trim().slice(0, 300),
  };
  return { ok: true, data };
}

// --------------------------- تجمیع ماهانه ---------------------------

export interface AttendanceMonthlySummary {
  employeeId: string;
  records: number;
  presentDays: number;
  absentDays: number;
  leaveDays: number;
  missionDays: number;
  fridayWorkDays: number;
  holidayWorkDays: number;
  workHours: number;
  overtimeHours: number;
  nightHours: number;
  fridayHours: number;
  holidayHours: number;
}

export function emptySummary(employeeId: string): AttendanceMonthlySummary {
  return {
    employeeId,
    records: 0, presentDays: 0, absentDays: 0, leaveDays: 0, missionDays: 0,
    fridayWorkDays: 0, holidayWorkDays: 0,
    workHours: 0, overtimeHours: 0, nightHours: 0, fridayHours: 0, holidayHours: 0,
  };
}

/** تجمیع رکوردهای یک ماه برای یک کارمند → خروجی مبنای فیش حقوقی */
export function aggregateAttendance(records: { employeeId: string; status: string; workHours: number; overtimeHours: number; nightHours: number; fridayHours: number; holidayHours: number }[]): AttendanceMonthlySummary {
  const s = emptySummary(records[0]?.employeeId || "");
  for (const r of records) {
    s.employeeId = r.employeeId;
    s.records += 1;
    if (r.status === "PRESENT") s.presentDays += 1;
    else if (r.status === "ABSENT") s.absentDays += 1;
    else if (r.status === "LEAVE") s.leaveDays += 1;
    else if (r.status === "MISSION") s.missionDays += 1;
    else if (r.status === "FRIDAY") s.fridayWorkDays += 1;
    else if (r.status === "HOLIDAY") s.holidayWorkDays += 1;
    s.workHours += r.workHours || 0;
    s.overtimeHours += r.overtimeHours || 0;
    s.nightHours += r.nightHours || 0;
    s.fridayHours += r.fridayHours || 0;
    s.holidayHours += r.holidayHours || 0;
  }
  const r2 = (v: number) => Math.round(v * 100) / 100;
  s.workHours = r2(s.workHours);
  s.overtimeHours = r2(s.overtimeHours);
  s.nightHours = r2(s.nightHours);
  s.fridayHours = r2(s.fridayHours);
  s.holidayHours = r2(s.holidayHours);
  return s;
}

/** فهرست روزهای ماه جلالی — برای گرید تردد/کارکرد ماهانه */
export function monthDaysJ(year: number, month: number): { dateJ: string; isFriday: boolean; day: number }[] {
  const n = daysInJalaliMonth(year, month);
  const out: { dateJ: string; isFriday: boolean; day: number }[] = [];
  for (let d = 1; d <= n; d++) {
    const dateJ = formatJStr(year, month, d);
    out.push({ dateJ, isFriday: isFridayJ(dateJ), day: d });
  }
  return out;
}

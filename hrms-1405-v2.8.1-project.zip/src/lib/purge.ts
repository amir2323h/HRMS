// ============================================================
// پاک‌سازی داده نمونه — منطق مشترک بین API (دکمه تنظیمات) و CLI
//   حالت demo (پیش‌فرض): حذف داده‌های تراکنشی نمونه
//     کارکنان (+ فیش/قرارداد/نامه/بستگان/رفاهیات/اسناد)، دوره‌های حقوق،
//     درخواست‌ها، طرح‌های پاداش — اسنپ‌شات داده نمونه پاک می‌شود
//   حالت full: علاوه بر موارد بالا، ساختار نمونه هم پاک می‌شود
//     دپارتمان‌ها، عناوین شغلی، آیتم‌های رفاهی، قالب نامه/قرارداد،
//     کاربران غیر از مدیر کل باقی‌مانده، لاگ حسابرسی
//   همیشه حفظ می‌شود: SystemSetting (پارامترهای قانونی/برندینگ/پاداش/ماترموست)،
//     Role (نقش‌های سیستمی)، JobGrade (طبقه‌بندی ۷ سطحی)، TaxBracket (پله‌های مالیاتی)،
//     و حداقل یک کاربر مدیر کل
// ============================================================
import type { PrismaClient } from "@prisma/client";
import { db as defaultDb } from "./db";

export interface PurgeCounts {
  employees: number;
  payslips: number;
  periods: number;
  contracts: number;
  letters: number;
  leaveRequests: number;
  advanceRequests: number;
  bonusSchemes: number;
  bonusLines: number;
  dependents: number;
  documents: number;
  welfareAssignments: number;
  employeeDepartments: number;
  // فقط حالت full:
  departments?: number;
  jobTitles?: number;
  welfareItems?: number;
  letterTemplates?: number;
  contractTemplates?: number;
  users?: number;
  auditLogs?: number;
  mode: "demo" | "full";
  at: string;
}

export async function purgeDemoData(
  opts: { full?: boolean; keepAudit?: boolean; db?: PrismaClient } = {}
): Promise<PurgeCounts> {
  const full = !!opts.full;
  const db = opts.db ?? defaultDb;

  // ---------- شمارش قبل از حذف ----------
  const c: PurgeCounts = {
    employees: await db.employee.count(),
    payslips: await db.payslip.count(),
    periods: await db.payrollPeriod.count(),
    contracts: await db.contract.count(),
    letters: await db.letterRequest.count(),
    leaveRequests: await db.leaveRequest.count(),
    advanceRequests: await db.advanceRequest.count(),
    bonusSchemes: await db.bonusScheme.count(),
    bonusLines: await db.bonusLine.count(),
    dependents: await db.insuranceDependent.count(),
    documents: await db.document.count(),
    welfareAssignments: await db.employeeWelfare.count(),
    employeeDepartments: await db.employeeDepartment.count(),
    mode: full ? "full" : "demo",
    at: new Date().toISOString(),
  };

  // ---------- ۱. داده‌های تراکنشی وابسته به کارکنان ----------
  await db.bonusLine.deleteMany({});
  await db.bonusScheme.deleteMany({});
  await db.letterRequest.deleteMany({});
  await db.contract.deleteMany({});
  await db.leaveRequest.deleteMany({});
  await db.advanceRequest.deleteMany({});

  // ---------- ۲. حقوق و دستمزد ----------
  await db.payslip.deleteMany({});
  await db.payrollPeriod.deleteMany({});

  // ---------- ۳. اتصال کاربران به پرسنل (پیش از حذف پرسنل) ----------
  await db.user.updateMany({ data: { employeeId: null } });

  // ---------- ۴. کارکنان (Cascade: بستگان/رفاهیات/اسناد/دپارتمان‌ها) ----------
  await db.employee.deleteMany({});

  // ---------- ۵. حالت full: ساختار نمونه ----------
  if (full) {
    // دپارتمان‌ها (اول قطع درخت و مدیر، سپس حذف)
    c.departments = await db.department.count();
    await db.department.updateMany({ data: { parentId: null, managerEmployeeId: null } });
    await db.employeeDepartment.deleteMany({});
    await db.department.deleteMany({});

    c.jobTitles = await db.jobTitle.count();
    await db.jobTitle.updateMany({ data: { jobGradeId: null } });
    await db.jobTitle.deleteMany({});

    c.welfareItems = await db.welfareItem.count();
    await db.welfareItem.deleteMany({});

    c.letterTemplates = await db.letterTemplate.count();
    await db.letterTemplate.deleteMany({});

    c.contractTemplates = await db.contractTemplate.count();
    await db.contractTemplate.deleteMany({});

    // کاربران غیر مدیر کل — با حفاطت از حداقل یک مدیر کل فعال
    const admins = await db.user.findMany({
      where: { role: "SUPER_ADMIN", isActive: true },
      orderBy: { createdAt: "asc" },
    });
    if (admins.length === 0) {
      throw new Error("هیچ کاربر مدیر کل فعالی یافت نشد — برای ایمنی، حذف کاربران انجام نشد.");
    }
    const keepIds = admins.slice(0, 1).map((u) => u.id); // قدیمی‌ترین مدیر کل حفظ می‌شود
    c.users = await db.user.count({ where: { id: { notIn: keepIds } } });
    await db.user.deleteMany({ where: { id: { notIn: keepIds } } });

    // لاگ حسابرسی (نویز نمونه) — مگر اینکه صراحتاً حفظ شود
    if (!opts.keepAudit) {
      c.auditLogs = await db.auditLog.count();
      await db.auditLog.deleteMany({});
    }
  }

  return c;
}

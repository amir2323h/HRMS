// ============================================================
// ورود یکپارانه با Mattermost — OAuth 2.0 (Authorization Code)
// مطابق مستندات رسمی: docs.mattermost.com/configure/oauth-2-service-provider.html
// Mattermost به‌عنوان OAuth Provider سازگار با GitLab عمل می‌کند:
//   authorize:  {MM}/oauth/authorize
//   token:      {MM}/oauth/token      (POST form)
//   پروفایل:    {MM}/api/v4/users/me  (GET + Bearer)
// ============================================================
import { db } from "@/lib/db";

/** نام کوکی state ضد CSRF */
export const STATE_COOKIE = "hrms_mm_state";
export const STATE_TTL_SEC = 600; // ۱۰ دقیقه

export interface MattermostConfig {
  enabled: boolean;
  serverUrl: string; // مثلاً https://mattermost.example.com (بدون اسلش انتهایی)
  clientId: string;
  clientSecret: string;
  autoCreate: boolean; // ساخت خودکار کاربر جدید
  defaultRoleKey: string; // نقش کاربران جدید (کلید roles)
  buttonLabel: string; // متن دکمه در صفحه ورود
  callbackBaseUrl: string; // آدرس فال‌بک Callback — مسیر عمومی سامانه (مثلاً https://hr.example.com)
}

export const MATTERMOST_DEFAULTS: MattermostConfig = {
  enabled: false,
  serverUrl: "",
  clientId: "",
  clientSecret: "",
  autoCreate: true,
  defaultRoleKey: "EMPLOYEE",
  buttonLabel: "ورود با Mattermost",
  callbackBaseUrl: "",
};

export async function getMattermostConfig(): Promise<MattermostConfig> {
  const row = await db.systemSetting.findUnique({ where: { key: "mattermost" } });
  if (!row) return { ...MATTERMOST_DEFAULTS };
  try {
    const stored = JSON.parse(row.value) as Partial<MattermostConfig>;
    return {
      ...MATTERMOST_DEFAULTS,
      ...stored,
      serverUrl: String(stored.serverUrl || "").replace(/\/+$/, ""),
      callbackBaseUrl: String(stored.callbackBaseUrl || "").replace(/\/+$/, ""),
    };
  } catch {
    return { ...MATTERMOST_DEFAULTS };
  }
}

export async function saveMattermostConfig(cfg: Partial<MattermostConfig>): Promise<MattermostConfig> {
  const current = await getMattermostConfig();
  const next: MattermostConfig = { ...current, ...cfg };
  next.serverUrl = String(next.serverUrl || "").replace(/\/+$/, "");
  next.callbackBaseUrl = String(next.callbackBaseUrl || "").replace(/\/+$/, "");
  await db.systemSetting.upsert({
    where: { key: "mattermost" },
    update: { value: JSON.stringify(next) },
    create: { key: "mattermost", value: JSON.stringify(next) },
  });
  return next;
}

/** آیا پیکربندی کامل است؟ */
export function mattermostReady(cfg: MattermostConfig): boolean {
  return !!(cfg.enabled && cfg.serverUrl && cfg.clientId && cfg.clientSecret);
}

/** آدرس مجوز — مرحله ۱ */
export function buildAuthorizeUrl(cfg: MattermostConfig, redirectUri: string, state: string): string {
  const p = new URLSearchParams({
    client_id: cfg.clientId,
    response_type: "code",
    redirect_uri: redirectUri,
    state,
  });
  return `${cfg.serverUrl}/oauth/authorize?${p.toString()}`;
}

export interface MattermostTokenResponse {
  access_token: string;
  token_type?: string;
  expires_in?: number;
  refresh_token?: string;
  scope?: string;
}

export interface MattermostUser {
  id: string;
  username: string;
  email: string;
  first_name?: string;
  last_name?: string;
  nickname?: string;
  roles?: string;
}

/** تبادل کد با توکن — POST {MM}/oauth/token (application/x-www-form-urlencoded) */
export async function exchangeMattermostToken(
  cfg: MattermostConfig,
  code: string,
  redirectUri: string,
): Promise<MattermostTokenResponse> {
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    code,
    redirect_uri: redirectUri,
  });
  const res = await fetch(`${cfg.serverUrl}/oauth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
    body: body.toString(),
    cache: "no-store",
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Mattermost token error (${res.status}): ${text.slice(0, 200)}`);
  }
  return JSON.parse(text) as MattermostTokenResponse;
}

/** پروفایل کاربر — GET {MM}/api/v4/users/me */
export async function fetchMattermostUser(cfg: MattermostConfig, accessToken: string): Promise<MattermostUser> {
  const res = await fetch(`${cfg.serverUrl}/api/v4/users/me`, {
    headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
    cache: "no-store",
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Mattermost user error (${res.status}): ${text.slice(0, 200)}`);
  }
  return JSON.parse(text) as MattermostUser;
}

/**
 * ساخت آدرس callback — با مسیر فال‌بک:
 *  ۱) اگر «آدرس فال‌بک Callback» در تنظیمات تنظیم شده باشد، همیشه از آن استفاده می‌شود
 *     (سامانه پشت پراکسی/دامنه‌های متعدت — redirect_uri ثابت و منطبق بر ثبت Mattermost)
 *  ۲) در غیر این صورت از هدرهای درخواست (x-forwarded-* / host) استخراج می‌شود
 * توجه: این تابع در هر دو مرحله مجوز و تبادل توکن صدا زده می‌شود تا redirect_uri یکسان بماند.
 */
export function callbackUrlFromRequest(req: Request, cfg?: Pick<MattermostConfig, "callbackBaseUrl">): string {
  const base = (cfg?.callbackBaseUrl || "").trim().replace(/\/+$/, "");
  if (base) {
    // مسیر callback همیشه ثابت است — مسیر فال‌بک فقط آدرس پایه را تعیین می‌کند
    return `${base}/api/auth/mattermost/callback`;
  }
  const proto = (req.headers.get("x-forwarded-proto") || "http").split(",")[0].trim();
  const host = (req.headers.get("x-forwarded-host") || req.headers.get("host") || "localhost:3000").split(",")[0].trim();
  return `${proto}://${host}/api/auth/mattermost/callback`;
}

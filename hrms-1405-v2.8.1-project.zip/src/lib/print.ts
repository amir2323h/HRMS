"use client";

// ============================================================
// ابزار چاپ اسناد A4 — قراردادها: فونت B Nazanin سایز ۱۲ / فاصله سطر ۱.۱۵
//  • چاپ: پنجره جدید مستقل — فونت‌ها با آدرس مطلق همان سرور
//  • دانلود: فایل HTML خودکفا — فونت‌ها base64 داخل فایل (بدون نیاز به سرور)
//  • B Nazanin گلیف لاتین ندارد → حروف لاتین خودکار از LetterLatin
//    (جفت سریف B Nazanin) با size-adjust رندر می‌شوند — مطابق نامه‌ها
//  • هدرها (نام سازمان / عنوان سند) بولد
// ============================================================

export interface PrintSignature {
  title: string; // مثلاً «امضای کارفرما»
  name?: string; // نام زیر خط امضا
}

export interface PrintSection {
  docTitle: string; // عنوان سند (وسط صفحه اول هر سند)
  metaLtr?: string; // سطر شماره/تاریخ (چپ‌به‌راست)
  headerTitle?: string; // نام سازمان بالای سند
  body: string; // متن اصلی (whitespace-pre-wrap)
  signatures?: [PrintSignature, PrintSignature] | null;
  footerNote?: string;
}

export interface PrintDocOptions {
  baseUrl?: string; // آدرس مطلق سرور برای فونت‌ها (پنجره چاپ)
  embeddedFonts?: Record<string, string>; // نام فایل → data URL (فایل دانلودی خودکفا)
}

// فونت‌های سند — B Nazanin (متن فارسی) + LetterLatin (جفت لاتین) + وزیرمتن (پشتیبان رابط)
const FONT_SPEC: { file: string; family: string; weight: number; adjust?: number }[] = [
  { file: "BNazanin.woff2", family: "B Nazanin", weight: 400 },
  { file: "LetterLatin-Regular.woff2", family: "LetterLatin", weight: 400, adjust: 83.33 },
  { file: "LetterLatin-Bold.woff2", family: "LetterLatin", weight: 700, adjust: 83.33 },
  { file: "Vazirmatn-Regular.woff2", family: "Vazirmatn", weight: 400 },
  { file: "Vazirmatn-Bold.woff2", family: "Vazirmatn", weight: 700 },
];

const FONT_FILES = FONT_SPEC.map((f) => f.file);

/** خانواده متن قرارداد — فارسی B Nazanin ۱۲، لاتین LetterLatin (۱۰ با size-adjust) */
const CONTRACT_FONT = "'B Nazanin', 'LetterLatin', 'Vazirmatn', serif";

function fontFaces(baseUrl?: string, embedded?: Record<string, string>): string {
  return FONT_SPEC.map(({ file, family, weight, adjust }) => {
    const src = embedded && embedded[file]
      ? `url('${embedded[file]}')`
      : `url('${(baseUrl || "").replace(/\/$/, "")}/fonts/${file}')`;
    return `@font-face { font-family: '${family}'; src: ${src} format('woff2'); font-weight: ${weight};${adjust ? ` size-adjust: ${adjust}%;` : ""} font-display: block; }`;
  }).join("\n");
}

/** فونت‌های سرور را به data URL تبدیل می‌کند — برای فایل دانلودی خودکفا (بدون وابستگی به سرور) */
async function fetchEmbeddedFonts(baseUrl: string): Promise<Record<string, string> | undefined> {
  try {
    const out: Record<string, string> = {};
    await Promise.all(
      FONT_FILES.map(async (f) => {
        const res = await fetch(`${baseUrl.replace(/\/$/, "")}/fonts/${f}`);
        if (!res.ok) throw new Error(`font ${f}: ${res.status}`);
        const buf = await res.arrayBuffer();
        const bytes = new Uint8Array(buf);
        let bin = "";
        const CHUNK = 0x8000;
        for (let i = 0; i < bytes.length; i += CHUNK) {
          bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
        }
        out[f] = `data:font/woff2;base64,${btoa(bin)}`;
      })
    );
    return out;
  } catch {
    return undefined; // fallback: آدرس مطلق سرور
  }
}

function esc(s: string): string {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** ساخت سند HTML کامل RTL برای چاپ/دانلود — هر بخش یک صفحه A4 با شکست صفحه
 *  استایل قرارداد: متن B Nazanin ۱۲pt با فاصله سطر ۱.۱۵ + هدرهای بولد */
export function buildPrintDocument(sections: PrintSection[], docTitle: string, opts: PrintDocOptions = {}): string {
  const pages = sections
    .map((s) => {
      const sig = s.signatures
        ? `<div class="sigs">
            <div>
              <p class="sig-title">${esc(s.signatures[0].title)}</p>
              <p class="sig-name">${esc(s.signatures[0].name || "")}</p>
            </div>
            <div>
              <p class="sig-title">${esc(s.signatures[1].title)}</p>
              <p class="sig-name">${esc(s.signatures[1].name || "")}</p>
            </div>
          </div>`
        : "";
      return `<section class="page">
        ${s.headerTitle ? `<p class="org">${esc(s.headerTitle)}</p>` : ""}
        <h1 class="doc-title">${esc(s.docTitle)}</h1>
        ${s.metaLtr ? `<p class="meta" dir="ltr">${esc(s.metaLtr)}</p>` : ""}
        <div class="body-text">${esc(s.body)}</div>
        ${sig}
        ${s.footerNote ? `<p class="footnote">${esc(s.footerNote)}</p>` : ""}
      </section>`;
    })
    .join("\n");

  return `<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<title>${esc(docTitle)}</title>
<style>
${fontFaces(opts.baseUrl, opts.embeddedFonts)}
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { background: #eef2f5; }
/* متن سند: B Nazanin ۱۲ با فاصله سطر ۱.۱۵ — لاتین از LetterLatin */
body { font-family: ${CONTRACT_FONT}; direction: rtl; }
.page {
  background: #fff;
  width: 210mm;
  min-height: 297mm;
  margin: 8mm auto;
  padding: 18mm 16mm;
  box-shadow: 0 2px 14px rgba(0,0,0,.14);
  display: flex;
  flex-direction: column;
}
/* هدرها بولد */
.org { text-align: center; font-weight: 700; color: #0f766e; font-size: 12pt; padding-bottom: 4mm; border-bottom: 1.5pt solid #0f766e33; }
.doc-title { text-align: center; font-size: 13pt; font-weight: 700; color: #1e293b; margin-top: 7mm; }
.meta { text-align: center; font-size: 10pt; color: #64748b; margin-top: 2mm; font-variant-numeric: tabular-nums; }
.body-text { margin-top: 8mm; font-size: 12pt; line-height: 1.15; color: #334155; white-space: pre-wrap; text-align: justify; flex: 1; }
.sigs { margin-top: 14mm; padding-top: 6mm; border-top: 1pt dotted #94a3b8; display: grid; grid-template-columns: 1fr 1fr; gap: 10mm; text-align: center; }
.sig-title { font-size: 11pt; color: #64748b; margin-bottom: 22mm; font-weight: 700; }
.sig-name { font-size: 11pt; color: #334155; border-top: 1pt dotted #64748b; padding-top: 2mm; }
.footnote { margin-top: 6mm; font-size: 9pt; color: #94a3b8; text-align: center; }
.toolbar { position: fixed; top: 0; right: 0; left: 0; background: #0f172aee; color: #fff; display: flex; align-items: center; gap: 10px; padding: 8px 14px; font-family: 'Vazirmatn', sans-serif; z-index: 99; }
.toolbar button { font-family: inherit; font-size: 12px; padding: 6px 14px; border: 0; border-radius: 8px; cursor: pointer; }
.toolbar .btn-print { background: #14b8a6; color: #fff; }
.toolbar .btn-close { background: #475569; color: #fff; }
.toolbar .hint { font-size: 11px; opacity: .75; margin-right: auto; }
@media print {
  html, body { background: #fff; }
  .toolbar { display: none !important; }
  .page { width: auto; min-height: auto; margin: 0; box-shadow: none; padding: 12mm 10mm; }
  .page + .page { page-break-before: always; }
  .noprint { display: none; }
}
</style>
</head>
<body>
<div class="toolbar">
  <button class="btn-print" onclick="window.print()">🖨 چاپ / ذخیره PDF</button>
  <button class="btn-close" onclick="window.close()">بستن</button>
  <span class="hint">${esc(docTitle)} — برای PDF در پنجره چاپ گزینه «Save as PDF» را انتخاب کنید</span>
</div>
${pages}
</body>
</html>`;
}

/**
 * چاپ اسناد در پنجره جدید — هر سند یک صفحه A4.
 * فونت‌ها با آدرس مطلق همین سرور (پنجره about:blank آدرس نسبی را resolve نمی‌کند).
 * در محیط‌هایی که popup مسدود است، به‌صورت fallback در iframe مخفی چاپ می‌شود.
 */
export function printSections(sections: PrintSection[], docTitle: string): void {
  const html = buildPrintDocument(sections, docTitle, { baseUrl: window.location.origin });
  const w = window.open("", "_blank", "width=920,height=760");
  if (w) {
    w.document.open();
    w.document.write(html);
    w.document.close();
    w.focus();
    // چاپ پس از بارگذاری فونت‌ها
    w.addEventListener("load", () => setTimeout(() => { try { w.focus(); w.print(); } catch { /* کاربر خودش دکمه چاپ را می‌زند */ } }, 400));
    return;
  }
  // fallback: iframe مخفی
  const f = document.createElement("iframe");
  f.style.cssText = "position:fixed;left:200%;bottom:200%;width:0;height:0;border:0;visibility:hidden;";
  document.body.appendChild(f);
  f.onload = () => {
    setTimeout(() => {
      try {
        f.contentWindow?.focus();
        f.contentWindow?.print();
      } catch { /* noop */ }
      setTimeout(() => f.remove(), 60_000);
    }, 500);
  };
  f.srcdoc = html;
}

/** دانلود همان سند چاپی به‌صورت فایل HTML خودکفا — فونت‌ها base64 داخل فایل (بدون نیاز به سرور) */
export async function downloadPrintDocument(sections: PrintSection[], docTitle: string, fileName: string): Promise<void> {
  const baseUrl = window.location.origin;
  const embeddedFonts = await fetchEmbeddedFonts(baseUrl);
  const html = buildPrintDocument(sections, docTitle, { baseUrl, embeddedFonts });
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName.endsWith(".html") ? fileName : `${fileName}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

import { PrismaClient } from "@prisma/client";
import * as fs from "node:fs";
import * as path from "node:path";
import { db, closeDbClient, recreateDbClient } from "./db";
import { isoToJalaliStr, toFaDigits } from "./jalali";

// ============================================================
// پشتیبان‌گیری و بازیابی داده‌های پنل — SQLite
//  • ایجاد اسنپ‌شات سالم از دیتابیس زنده با VACUUM INTO
//    (بدون توقف سرویس — قفل خواندنی لحظه‌ای)
//  • نگهداشت حداکثر MAX_BACKUPS نسخه (قدیمی‌ها خودکار حذف می‌شوند)
//  • اعتبارسنجی فایل پشتیبان پیش از بازیابی (هدر SQLite + ساختار
//    جدول‌ها + وجود حداقل یک مدیر کل) با یک PrismaClient موقت
//  • بازیابی اتمی: پشتیبان ایمنی از وضعیت فعلی → بستن اتصال →
//    جایگزینی فایل (rename) → کلاینت تازه بدون ری‌استارت سرویس
// مسیر فایل‌ها: <پوشه دیتابیس>/backups/hrms-backup-<تاریخ شمسی>-<ساعت>.db
// ============================================================

/** حداکثر تعداد فایل پشتیبان که نگه داشته می‌شود */
export const MAX_BACKUPS = 10;

/** بیشینه حجم فایل بازیابی‌شونده (۵۰۰ مگابایت) */
export const MAX_RESTORE_SIZE = 500 * 1024 * 1024;

/** جدول‌هایی که یک فایل پشتیبان معتبر HRMS باید داشته باشد */
const REQUIRED_TABLES = ["users", "roles", "system_settings", "employees", "audit_logs", "payslips"];

export interface BackupFile {
  name: string;
  sizeBytes: number;
  createdAt: string; // ISO
  createdAtJ: string; // نمایش شمسی با ساعت
}

export interface ValidationInfo {
  tables: number;
  users: number;
  admins: number;
  employees: number;
}

// ---------- مسیرها ----------

/** مسیر مطلق فایل دیتابیس از DATABASE_URL */
export function dbFilePath(): string {
  const url = process.env.DATABASE_URL || "file:./db/custom.db";
  const p = url.replace(/^file:/i, "").split("?")[0].trim();
  return path.isAbsolute(p) ? p : path.resolve(process.cwd(), p);
}

/** پوشه فایل‌های پشتیبان — کنار دیتابیس (در بروزرسانی‌ها حفظ می‌شود) */
export function backupsDir(): string {
  return path.join(path.dirname(dbFilePath()), "backups");
}

/** نام فایل معتبر است؟ (جلوگیری از پیمایش مسیر) */
function isValidBackupName(name: string): boolean {
  return /^hrms-backup-[A-Za-z0-9._-]+\.db$/.test(name) && !name.includes("/") && !name.includes("\\") && !name.includes("..");
}

// ---------- ایجاد پشتیبان ----------

function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

function backupStat(file: string): BackupFile {
  const st = fs.statSync(file);
  const iso = st.mtime.toISOString();
  const j = isoToJalaliStr(st.mtime); // 1405/07/18
  const hh = st.mtime.getHours(), mm = st.mtime.getMinutes();
  return {
    name: path.basename(file),
    sizeBytes: st.size,
    createdAt: iso,
    createdAtJ: `${j} ساعت ${pad2(hh)}:${pad2(mm)}`,
  };
}

/**
 * ایجاد پشتیبان تازه از دیتابیس زنده.
 * tag برای تمایز هدف پشتیبان است (مثلاً pre-update / pre-restore).
 */
export async function createBackup(tag = ""): Promise<BackupFile> {
  const dir = backupsDir();
  fs.mkdirSync(dir, { recursive: true });

  const now = new Date();
  const datePart = isoToJalaliStr(now).replace(/\//g, ""); // 14050718
  const timePart = `${pad2(now.getHours())}${pad2(now.getMinutes())}${pad2(now.getSeconds())}`;
  const safeTag = tag ? `-${tag.replace(/[^A-Za-z0-9-]/g, "").slice(0, 24)}` : "";
  const base = `hrms-backup-${datePart}-${timePart}${safeTag}`;

  // VACUUM INTO روی فایل موجود خطا می‌دهد — نام یکتا بساز
  let target = path.join(dir, `${base}.db`);
  for (let i = 2; fs.existsSync(target); i++) target = path.join(dir, `${base}-${i}.db`);

  // مسیر داخل SQL — کوتیشن تکی دوبار می‌شود
  await db.$executeRawUnsafe(`VACUUM INTO '${target.replace(/'/g, "''")}'`);

  const info = backupStat(target);
  pruneBackups();
  return info;
}

/** حذف قدیمی‌ترین‌ها تا سقف MAX_BACKUPS */
function pruneBackups(): void {
  const files = listBackups();
  for (const old of files.slice(MAX_BACKUPS)) {
    try {
      fs.unlinkSync(path.join(backupsDir(), old.name));
    } catch {
      /* فایل شاید همزمان حذف شده باشد */
    }
  }
}

// ---------- فهرست / حذف / خواندن ----------

export function listBackups(): BackupFile[] {
  const dir = backupsDir();
  if (!fs.existsSync(dir)) return [];
  const out: BackupFile[] = [];
  for (const f of fs.readdirSync(dir)) {
    if (!isValidBackupName(f)) continue;
    const full = path.join(dir, f);
    try {
      if (fs.statSync(full).isFile()) out.push(backupStat(full));
    } catch {
      /* نادیده بگیر */
    }
  }
  return out.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

export function deleteBackup(name: string): BackupFile {
  if (!isValidBackupName(name)) throw new Error("نام فایل پشتیبان معتبر نیست.");
  const full = path.join(backupsDir(), name);
  if (!fs.existsSync(full)) throw new Error("فایل پشتیبان یافت نشد.");
  const info = backupStat(full);
  fs.unlinkSync(full);
  return info;
}

/** خواندن محتوای فایل پشتیبان برای دانلود */
export function readBackup(name: string): { bytes: Uint8Array; info: BackupFile } {
  if (!isValidBackupName(name)) throw new Error("نام فایل پشتیبان معتبر نیست.");
  const full = path.join(backupsDir(), name);
  if (!fs.existsSync(full)) throw new Error("فایل پشتیبان یافت نشد.");
  const buf = fs.readFileSync(full);
  return { bytes: Uint8Array.from(buf), info: backupStat(full) };
}

// ---------- اعتبارسنجی فایل بازیابی ----------

/**
 * اعتبارسنجی فایل پشتیبان پیش از بازیابی:
 *  ۱) هدر SQLite و محدوده حجم
 *  ۲) وجود جدول‌های اصلی HRMS
 *  ۳) وجود حداقل یک کاربر مدیر کل فعال (وگرنه ورود به پنل ناممکن می‌شود)
 */
export async function validateBackupFile(filePath: string): Promise<ValidationInfo> {
  const size = fs.statSync(filePath).size;
  if (size < 4096) {
    throw new Error("فایل پشتیبان خیلی کوچک است و ساختار معتبر ندارد.");
  }
  if (size > MAX_RESTORE_SIZE) {
    throw new Error(`حجم فایل پشتیبان بیش از حد مجاز است (بیش از ${toFaDigits(Math.round(MAX_RESTORE_SIZE / 1024 / 1024))} مگابایت).`);
  }

  // هدر استاندارد SQLite
  const fd = fs.openSync(filePath, "r");
  try {
    const head = Buffer.alloc(16);
    fs.readSync(fd, head, 0, 16, 0);
    if (head.toString("utf-8") !== "SQLite format 3\u0000") {
      throw new Error("فایل انتخاب‌شده یک دیتابیس SQLite معتبر نیست.");
    }
  } finally {
    fs.closeSync(fd);
  }

  // ساختار — با یک کلاینت موقت فقط روی همین فایل
  const probe = new PrismaClient({ datasourceUrl: `file:${filePath}` });
  try {
    const rows = (await probe.$queryRawUnsafe(
      "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
    )) as { name: string }[];
    const names = new Set(rows.map((r) => r.name));
    const missing = REQUIRED_TABLES.filter((t) => !names.has(t));
    if (missing.length > 0) {
      throw new Error(`فایل پشتیبان ساختار سامانه HRMS را ندارد (جدول‌های غایب: ${missing.join("، ")}).`);
    }

    const count = async (sql: string): Promise<number> => {
      const r = (await probe.$queryRawUnsafe(sql)) as { c: number | bigint }[];
      return Number(r[0]?.c ?? 0);
    };
    const users = await count("SELECT COUNT(*) AS c FROM users");
    const admins = await count("SELECT COUNT(*) AS c FROM users WHERE role = 'SUPER_ADMIN' AND isActive = 1");
    const employees = await count("SELECT COUNT(*) AS c FROM employees");
    if (admins < 1) {
      throw new Error("در فایل پشتیبان هیچ کاربر «مدیر کل» فعالی وجود ندارد — پس از بازیابی، امکان ورود به پنل از بین می‌رود.");
    }
    return { tables: names.size, users, admins, employees };
  } finally {
    await probe.$disconnect().catch(() => undefined);
  }
}

// ---------- بازیابی ----------

export interface RestoreResult {
  safety: BackupFile;
  validation: ValidationInfo;
}

/**
 * بازیابی کامل دیتابیس از فایل staging (یک کپی فیزیکی از پشتیبان).
 * ترتیب ایمن:
 *  ۱) پشتیبان ایمنی از وضعیت فعلی (VACUUM INTO — سرویس روشن)
 *  ۲) بستن اتصال جاری + پاک‌سازی فایل‌های journal جانبی (wal/shm)
 *  ۳) جایگزینی اتمی فایل دیتابیس (rename روی همان فایل‌سیستم)
 *  ۴) ساخت کلاینت تازه — بدون ری‌استارت سرویس
 */
export async function restoreFromStaging(stagingPath: string): Promise<RestoreResult> {
  // ۱) اعتبارسنجی پیش از هر تغییری
  const validation = await validateBackupFile(stagingPath);

  // ۲) پشتیبان ایمنی از وضعیت فعلی
  const safety = await createBackup("pre-restore");

  // ۳) بستن اتصال و جایگزینی فایل
  const dbPath = dbFilePath();
  await closeDbClient();
  for (const side of [`${dbPath}-wal`, `${dbPath}-shm`, `${dbPath}-journal`]) {
    try {
      fs.unlinkSync(side);
    } catch {
      /* فایل journal وجود ندارد */
    }
  }
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  fs.renameSync(stagingPath, dbPath);

  // ۴) کلاینت تازه روی فایل بازیابی‌شده
  recreateDbClient();

  return { safety, validation };
}

/** کپی یک پشتیبان موجود به staging برای بازیابی (فایل اصلی در فهرست می‌ماند) */
export function stageExistingBackup(name: string): string {
  if (!isValidBackupName(name)) throw new Error("نام فایل پشتیبان معتبر نیست.");
  const src = path.join(backupsDir(), name);
  if (!fs.existsSync(src)) throw new Error("فایل پشتیبان یافت نشد.");
  const staging = path.join(backupsDir(), `staging-restore-${Date.now()}.db`);
  fs.copyFileSync(src, staging);
  return staging;
}

/** نگهداری فایل آپلودی در staging */
export function stageUploadedBytes(bytes: Uint8Array): string {
  const dir = backupsDir();
  fs.mkdirSync(dir, { recursive: true });
  const staging = path.join(dir, `staging-restore-${Date.now()}.db`);
  fs.writeFileSync(staging, bytes);
  return staging;
}

/** پاک‌سازی فایل staging در صورت خطا */
export function cleanupStaging(stagingPath: string | null): void {
  if (!stagingPath) return;
  try {
    if (fs.existsSync(stagingPath) && path.basename(stagingPath).startsWith("staging-restore-")) {
      fs.unlinkSync(stagingPath);
    }
  } catch {
    /* نادیده بگیر */
  }
}

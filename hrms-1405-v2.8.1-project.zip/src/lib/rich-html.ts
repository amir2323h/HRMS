// ============================================================
// پاک‌سازی HTML متن غنی نامه — لیست سفید تگ/ویژگی
// برای «متن نامه دستی» که ادیتور غنی (جدول/قالب‌بندی) تولید
// می‌کند و برای چسباندن از اکسل/ورد/گوگل‌شیت.
//
// هم سمت کلاینت (پیش‌نمایش دیالوگ‌ها + پاک‌سازی لحظه‌ای paste)
// و هم سمت سرور (API ثبت نامه) استفاده می‌شود — بدون وابستگی
// به DOM: پارسر رشته‌ای مبتنی بر پیمایش تگ‌ها.
//
// اصول:
//  • فقط تگ‌های لیست سفید + ویژگی‌های مجاز (colspan/rowspan/dir) می‌مانند.
//  • محتوای script/style/iframe/object/embed/title و کامنت‌ها کامل حذف می‌شود.
//  • ساختار خروجی well-formed می‌شود (بستن خودکار تگ‌های باز).
//  • هرچیز ناشناخته = حذف تگ (متن داخل تگ نامجاز حفظ می‌شود، جز تگ‌های خطرناک).
// ============================================================

/** تگ‌های مجاز → ویژگی‌های مجاز هرکدام */
const ALLOWED_TAGS: Record<string, string[]> = {
  p: [],
  br: [],
  b: [],
  strong: [],
  i: [],
  em: [],
  u: [],
  s: [],
  ul: [],
  ol: [],
  li: [],
  table: ["dir"],
  thead: [],
  tbody: [],
  tfoot: [],
  tr: [],
  td: ["colspan", "rowspan"],
  th: ["colspan", "rowspan"],
  div: [],
  span: ["dir"],
  blockquote: [],
  h3: [],
  h4: [],
  sub: [],
  sup: [],
};

/** تگ‌هایی که کل محتوایشان باید حذف شود (نه فقط تگ) */
const DROP_CONTENT_TAGS = new Set(["script", "style", "iframe", "object", "embed", "title", "head", "svg", "math", "noscript", "template", "form", "input", "button", "textarea", "select", "option", "link", "meta", "base", "applet", "frame", "frameset", "xml", "o:p"]);

/** تگ‌های void (بدون بستن) */
const VOID_TAGS = new Set(["br"]);

const MAX_HTML_LENGTH = 200_000; // ~۵۰۰ ردیف جدول

interface OpenTag {
  name: string;
}

/** پاک‌سازی HTML نامه — خروجی فقط شامل تگ/ویژگی مجاز است */
export function sanitizeLetterHtml(input: string): string {
  if (!input) return "";
  if (input.length > MAX_HTML_LENGTH) input = input.slice(0, MAX_HTML_LENGTH);

  // حذف کل بلوک‌های خطرناک (تا تگ پایانی همان نام)
  for (const tag of DROP_CONTENT_TAGS) {
    input = input.replace(new RegExp(`<${tag}(\\s[^>]*)?>[\\s\\S]*?<\\/${tag}\\s*>`, "gi"), "");
    input = input.replace(new RegExp(`<${tag}(\\s[^>]*)?>`, "gi"), ""); // بازِ یتیم
    input = input.replace(new RegExp(`<\\/${tag}\\s*>`, "gi"), "");
  }
  // کامنت‌ها و CDATA
  input = input.replace(/<!--[\s\S]*?-->/g, "").replace(/<!\[CDATA\[[\s\S]*?\]\]>/g, "");
  // doctype و processing instruction
  input = input.replace(/<![^>]*>/g, "").replace(/<\?[\s\S]*?\?>/g, "");

  // نرمال‌سازی نام تگ‌های رایج آفیس: <o:p> → p؟ خیر — حذف (بالا). <b\> از ورد می‌ماند.
  const out: string[] = [];
  const stack: OpenTag[] = [];
  const tagRe = /<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = tagRe.exec(input))) {
    // متن قبل از تگ
    if (m.index > last) out.push(input.slice(last, m.index));
    last = m.index + m[0].length;

    const closing = m[1] === "/";
    const rawName = m[2].toLowerCase();
    const attrsRaw = m[3] || "";

    if (rawName.startsWith("o:")) continue; // تگ‌های آفیس (o:p و غیره) — رد
    const allowedAttrs = ALLOWED_TAGS[rawName];
    if (!allowedAttrs) continue; // تگ ناشناخته/غیرمجاز → حذف تگ، متن می‌ماند

    if (VOID_TAGS.has(rawName)) {
      if (!closing) out.push("<br />");
      continue;
    }

    if (closing) {
      // بستن تگ — فقط اگر در استک باشد (تا عمق درست)
      const idx = stack.map((s) => s.name).lastIndexOf(rawName);
      if (idx === -1) continue; // بسته‌ی یتیم → رد
      // بستن همه تگ‌های داخلی‌تر (well-formed نگه‌داشتن)
      while (stack.length > idx) out.push(`</${stack.pop()!.name}>`);
      continue;
    }

    // تگ باز — ویژگی‌های مجاز
    const attrs: string[] = [];
    for (const want of allowedAttrs) {
      const am = attrsRaw.match(new RegExp(`\\b${want}\\s*=\\s*("([^"]*)"|'([^']*)'|([^\\s"'>]+))`, "i"));
      if (!am) continue;
      let val = am[2] ?? am[3] ?? am[4] ?? "";
      val = val.replace(/[<>&"]/g, ""); // ویژگی امن
      if (want === "dir") {
        if (!["rtl", "ltr"].includes(val.toLowerCase())) continue;
        val = val.toLowerCase();
      } else {
        const n = parseInt(val, 10);
        if (isNaN(n) || n < 1 || n > 100) continue;
        val = String(n);
      }
      attrs.push(` ${want}="${val}"`);
    }
    out.push(`<${rawName}${attrs.join("")}>`);
    stack.push({ name: rawName });
  }
  if (last < input.length) out.push(input.slice(last));
  // بستن باقی‌مانده‌ها
  while (stack.length) out.push(`</${stack.pop()!.name}>`);
  return out.join("").trim();
}

/** استخراج متن ساده از HTML پاک‌سازی‌شده (برای body متنی/جستجو/لیست)
 *  سلول‌های جدول با Tab و ردیف‌ها با خط جدید جدا می‌شوند تا متن قابل‌خواندن بماند */
export function htmlToPlainText(html: string): string {
  return sanitizeLetterHtml(html)
    .replace(/<\/(p|div|li|blockquote|h3|h4)>/gi, "\n")
    .replace(/<\/(tr)>/gi, "\n")
    .replace(/<\/(td|th)>/gi, "\t")
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/\t+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

/** آیا HTML معنادار دارد (حداقل یک تگ جدول/قالب‌بندی یا متن غیرخالی)؟ */
export function hasRichContent(html: string): boolean {
  const clean = sanitizeLetterHtml(html);
  if (!clean) return false;
  if (/<(table|b>|strong|i>|em|u>|ul|ol|h3|h4|blockquote)/i.test(clean)) return true;
  return htmlToPlainText(clean).length > 0;
}

// ============================================================
// نقش‌ها و ماتریس دسترسی — ایمن برای کلاینت (بدون وابستگی سرور)
// ============================================================

export type Role = "SUPER_ADMIN" | "HR_MANAGER" | "PAYROLL_OFFICER" | "DEPT_MANAGER" | "EMPLOYEE";

export const ROLE_ACCESS: Record<Role, string[]> = {
  SUPER_ADMIN: ["*"],
  HR_MANAGER: [
    "dashboard", "employees", "departments", "grades", "alerts", "contracts",
    "requests", "audit", "settings", "docs", "portal",
  ],
  PAYROLL_OFFICER: [
    "dashboard", "payroll", "reverse", "reports", "audit", "contracts",
    "employees", "settings", "docs", "portal",
  ],
  DEPT_MANAGER: ["dashboard", "employees", "departments", "reports", "alerts", "docs", "portal"],
  EMPLOYEE: ["portal", "docs"],
};

export function canAccess(role: Role, view: string): boolean {
  const allowed = ROLE_ACCESS[role] || [];
  return allowed.includes("*") || allowed.includes(view);
}

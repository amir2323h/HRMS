// ============================================================
// ورود دو مرحله‌ای (2FA) — TOTP مطابق RFC 6238
// سازگار با Google Authenticator / Microsoft Authenticator و
// همه اپ‌های احرازکننده استاندارد. کاملاً بومی و آفلاین:
//   • راز: ۲۰ بایت تصادفی → کدگذاری base32 (RFC 4648)
//   • کد: ۶ رقم، SHA-1، پنجره ۳۰ ثانیه، تحمل ±۱ پنجره
//   • otpauth:// URL برای اسکن QR توسط اپ احرازکننده
// ============================================================
import { createHmac, randomBytes, timingSafeEqual } from "crypto";

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

/** تولید راز TOTP — ۲۰ بایت تصادفی (۱۶۰ بیت) به‌صورت base32 */
export function generateTotpSecret(): string {
  const bytes = randomBytes(20);
  let bits = "";
  for (const b of bytes) bits += b.toString(2).padStart(8, "0");
  let out = "";
  for (let i = 0; i + 5 <= bits.length; i += 5) out += BASE32_ALPHABET[parseInt(bits.slice(i, i + 5), 2)];
  return out; // 32 نویسه
}

/** رمزگشایی base32 (بدون پدینگ — اپ‌های احرازکننده پدینگ نمی‌سازند) */
function base32Decode(input: string): Buffer {
  const clean = input.toUpperCase().replace(/[^A-Z2-7]/g, "");
  let bits = "";
  for (const ch of clean) {
    const v = BASE32_ALPHABET.indexOf(ch);
    if (v < 0) continue;
    bits += v.toString(2).padStart(5, "0");
  }
  const bytes: number[] = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}

/** کد HOTP برای شمارنده معین — HMAC-SHA1، ۶ رقم (RFC 4226) */
function hotp(secret: Buffer, counter: number): string {
  const buf = Buffer.alloc(8);
  // شمارنده ۶۴بیتی big-endian
  buf.writeUInt32BE(Math.floor(counter / 0x100000000), 0);
  buf.writeUInt32BE(counter % 0x100000000, 4);
  const digest = createHmac("sha1", secret).update(buf).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const code = ((digest[offset] & 0x7f) << 24) | (digest[offset + 1] << 16) | (digest[offset + 2] << 8) | digest[offset + 3];
  return String(code % 1_000_000).padStart(6, "0");
}

/** پنجره زمانی فعلی (۳۰ ثانیه‌ای) */
function timeCounter(): number {
  return Math.floor(Date.now() / 1000 / 30);
}

/** آیا راز معتبر است؟ (کدگذاری base32 سالم و طول کافی) */
export function isValidTotpSecret(secret: string): boolean {
  const clean = String(secret || "").toUpperCase().replace(/[^A-Z2-7]/g, "");
  return clean.length >= 16 && clean.length <= 64;
}

/**
 * راستی‌آزمایی کد ۶رقمی — پنجره فعلی + یکی قبل + یکی بعد (تحمل اختلاف ساعت)
 * مقایسه timing-safe برای جلوگیری از حملات زمانی
 */
export function verifyTotp(secret: string, code: string): boolean {
  if (!isValidTotpSecret(secret)) return false;
  const clean = String(code || "").replace(/\D/g, "");
  if (clean.length !== 6) return false;
  const secretBuf = base32Decode(secret);
  if (secretBuf.length < 10) return false;
  const c = timeCounter();
  for (const counter of [c, c - 1, c + 1]) {
    const expected = hotp(secretBuf, counter);
    const a = Buffer.from(expected, "utf8");
    const b = Buffer.from(clean, "utf8");
    if (a.length === b.length && timingSafeEqual(a, b)) return true;
  }
  return false;
}

/** آدرس otpauth:// برای اسکن QR — مطابق قالب استاندارد اپ‌های احرازکننده */
export function otpauthUrl(secret: string, account: string, issuer: string): string {
  const enc = encodeURIComponent;
  return (
    `otpauth://totp/${enc(issuer)}:${enc(account)}` +
    `?secret=${enc(secret)}&issuer=${enc(issuer)}` +
    `&algorithm=SHA1&digits=6&period=30`
  );
}

// ============================================================
// ورود با حساب گوگل (Gmail) — OAuth 2.0 / OpenID Connect
// مطابق مستندات رسمی Google Identity:
//   authorize:  https://accounts.google.com/o/oauth2/v2/auth
//   token:      https://oauth2.googleapis.com/token (POST form)
//   پروفایل:    https://openidconnect.googleapis.com/v1/userinfo (GET + Bearer)
// دامنه‌ها: openid email profile — فقط خواندن ایمیل/نام (بدون دسترسی دیگر)
// ============================================================
import { db } from "@/lib/db";

/** نام کوکی state ضد CSRF */
export const GOOGLE_STATE_COOKIE = "hrms_google_state";
export const GOOGLE_STATE_TTL_SEC = 600; // ۱۰ دقیقه

export interface GoogleOAuthConfig {
  enabled: boolean;
  clientId: string;
  clientSecret: string;
  autoCreate: boolean; // ساخت خودکار کاربر جدید برای ایمیل‌های گوگل
  defaultRoleKey: string; // نقش کاربران جدید
  buttonLabel: string; // متن دکمه در صفحه ورود
  callbackBaseUrl: string; // آدرس فال‌بک Callback — مسیر عمومی سامانه
  allowedDomain: string; // محدودیت دامنه ایمیل (خالی = همه) — مثلاً company.com
}

export const GOOGLE_DEFAULTS: GoogleOAuthConfig = {
  enabled: false,
  clientId: "",
  clientSecret: "",
  autoCreate: true,
  defaultRoleKey: "EMPLOYEE",
  buttonLabel: "ورود با Gmail",
  callbackBaseUrl: "",
  allowedDomain: "",
};

export async function getGoogleConfig(): Promise<GoogleOAuthConfig> {
  const row = await db.systemSetting.findUnique({ where: { key: "google_oauth" } });
  if (!row) return { ...GOOGLE_DEFAULTS };
  try {
    const stored = JSON.parse(row.value) as Partial<GoogleOAuthConfig>;
    return {
      ...GOOGLE_DEFAULTS,
      ...stored,
      clientId: String(stored.clientId || "").trim(),
      clientSecret: String(stored.clientSecret || "").trim(),
      callbackBaseUrl: String(stored.callbackBaseUrl || "").replace(/\/+$/, ""),
      allowedDomain: String(stored.allowedDomain || "").trim().toLowerCase(),
    };
  } catch {
    return { ...GOOGLE_DEFAULTS };
  }
}

export async function saveGoogleConfig(cfg: Partial<GoogleOAuthConfig>): Promise<GoogleOAuthConfig> {
  const current = await getGoogleConfig();
  const next: GoogleOAuthConfig = { ...current, ...cfg };
  next.clientId = String(next.clientId || "").trim();
  next.clientSecret = String(next.clientSecret || "").trim();
  next.callbackBaseUrl = String(next.callbackBaseUrl || "").replace(/\/+$/, "");
  next.allowedDomain = String(next.allowedDomain || "").trim().toLowerCase();
  await db.systemSetting.upsert({
    where: { key: "google_oauth" },
    update: { value: JSON.stringify(next) },
    create: { key: "google_oauth", value: JSON.stringify(next) },
  });
  return next;
}

/** آیا پیکربندی کامل است؟ */
export function googleReady(cfg: GoogleOAuthConfig): boolean {
  return !!(cfg.enabled && cfg.clientId && cfg.clientSecret);
}

/** آدرس مجوز — مرحله ۱ (Authorization Code + state ضد CSRF) */
export function buildGoogleAuthorizeUrl(cfg: GoogleOAuthConfig, redirectUri: string, state: string): string {
  const p = new URLSearchParams({
    client_id: cfg.clientId,
    response_type: "code",
    redirect_uri: redirectUri,
    state,
    scope: "openid email profile",
    access_type: "online",
    prompt: "select_account",
  });
  return `https://accounts.google.com/o/oauth2/v2/auth?${p.toString()}`;
}

export interface GoogleTokenResponse {
  access_token: string;
  expires_in?: number;
  scope?: string;
  token_type?: string;
  id_token?: string;
}

/** تبادل کد با توکن — POST https://oauth2.googleapis.com/token */
export async function exchangeGoogleToken(
  cfg: GoogleOAuthConfig,
  code: string,
  redirectUri: string,
): Promise<GoogleTokenResponse> {
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    client_id: cfg.clientId,
    client_secret: cfg.clientSecret,
    code,
    redirect_uri: redirectUri,
  });
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" },
    body: body.toString(),
    cache: "no-store",
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Google token error (${res.status}): ${text.slice(0, 200)}`);
  }
  return JSON.parse(text) as GoogleTokenResponse;
}

export interface GoogleUserInfo {
  sub: string; // شناسه یکتا گوگل
  email: string;
  email_verified?: boolean;
  name?: string;
  given_name?: string;
  family_name?: string;
  picture?: string;
}

/** پروفایل کاربر — GET https://openidconnect.googleapis.com/v1/userinfo */
export async function fetchGoogleUser(accessToken: string): Promise<GoogleUserInfo> {
  const res = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
    headers: { Authorization: `Bearer ${accessToken}`, Accept: "application/json" },
    cache: "no-store",
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`Google userinfo error (${res.status}): ${text.slice(0, 200)}`);
  }
  return JSON.parse(text) as GoogleUserInfo;
}

/**
 * ساخت آدرس callback — با مسیر فال‌بک:
 *  ۱) اگر «آدرس فال‌بک Callback» در تنظیمات تنظیم شده باشد، همیشه از آن استفاده می‌شود
 *  ۲) در غیر این صورت از هدرهای درخواست (x-forwarded-* / host) استخراج می‌شود
 * توجه: در هر دو مرحله مجوز و تبادل توکن صدا زده می‌شود تا redirect_uri یکسان بماند.
 */
export function googleCallbackUrlFromRequest(req: Request, cfg?: Pick<GoogleOAuthConfig, "callbackBaseUrl">): string {
  const base = (cfg?.callbackBaseUrl || "").trim().replace(/\/+$/, "");
  if (base) return `${base}/api/auth/google/callback`;
  const proto = (req.headers.get("x-forwarded-proto") || "http").split(",")[0].trim();
  const host = (req.headers.get("x-forwarded-host") || req.headers.get("host") || "localhost:3000").split(",")[0].trim();
  return `${proto}://${host}/api/auth/google/callback`;
}

/** بررسی دامنه ایمیل مجاز (اگر در تنظیمات محدود شده باشد) */
export function googleEmailAllowed(email: string, cfg: GoogleOAuthConfig): boolean {
  if (!cfg.allowedDomain) return true;
  return email.toLowerCase().endsWith(`@${cfg.allowedDomain}`);
}

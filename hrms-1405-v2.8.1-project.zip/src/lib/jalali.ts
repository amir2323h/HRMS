// ============================================================
// تقویم جلالی (شمسی) — پیاده‌سازی کامل و لوکال
// الگوریتم تبدیل بر مبنای تقویم هجری شمسی (jalaali) — بدون هیچ وابستگی خارجی
// ============================================================

export const JALALI_MONTHS = [
  "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
  "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند",
];

export const JALALI_WEEKDAYS = [
  "شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه",
];
// ایندکس روز هفته با مبنای شنبه = 0
export const JALALI_WEEKDAYS_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

const div = (a: number, b: number) => ~~(a / b);
const mod = (a: number, b: number) => a - ~~(a / b) * b;

// نقاط گسست تقویم جلالی (۳۳ ساله)
const BREAKS = [
  -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635,
  2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178,
];

function jalCal(jy: number) {
  const bl = BREAKS.length;
  const gy = jy + 621;
  let leapJ = -14;
  let jp = BREAKS[0];
  let jm = 0;
  let jump = 0;

  if (jy < jp || jy >= BREAKS[bl - 1]) {
    throw new Error(`سال جلالی نامعتبر: ${jy}`);
  }

  for (let i = 1; i < bl; i += 1) {
    jm = BREAKS[i];
    jump = jm - jp;
    if (jy < jm) break;
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  let n = jy - jp;

  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) leapJ += 1;

  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  const march = 20 + leapJ - leapG;

  if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
  let leap = mod(mod(n + 1, 33) - 1, 4);
  if (leap === -1) leap = 4;

  return { leap, gy, march };
}

function g2d(gy: number, gm: number, gd: number): number {
  let d =
    div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
    div(153 * mod(gm + 9, 12) + 2, 5) +
    gd -
    34840408;
  d = d - div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) + 752;
  return d;
}

function d2g(jdn: number) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  const gy = div(j, 1461) - 100100 + div(8 - gm, 6);
  return { gy, gm, gd };
}

export function j2d(jy: number, jm: number, jd: number): number {
  const r = jalCal(jy);
  return g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1;
}

export function d2j(jdn: number) {
  const gy = d2g(jdn).gy;
  let jy = gy - 621;
  const r = jalCal(jy);
  const jdn1f = g2d(gy, 3, r.march);
  let k = jdn - jdn1f;

  if (k >= 0) {
    if (k <= 185) {
      const jm = 1 + div(k, 31);
      const jd = mod(k, 31) + 1;
      return { jy, jm, jd };
    }
    k -= 186;
  } else {
    jy -= 1;
    k += 179;
    if (r.leap === 1) k += 1;
  }
  const jm = 7 + div(k, 30);
  const jd = mod(k, 30) + 1;
  return { jy, jm, jd };
}

export function jalaliToGregorian(jy: number, jm: number, jd: number) {
  return d2g(j2d(jy, jm, jd));
}

export function gregorianToJalali(gy: number, gm: number, gd: number) {
  return d2j(g2d(gy, gm, gd));
}

export function isLeapJalaliYear(jy: number): boolean {
  return jalCal(jy).leap === 0;
}

export function daysInJalaliMonth(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isLeapJalaliYear(jy) ? 30 : 29;
}

// ---- تاریخ امروز (جلالی) ----
export function todayJalali(): { jy: number; jm: number; jd: number } {
  const now = new Date();
  return gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
}

export function todayJalaliStr(): string {
  const t = todayJalali();
  return formatJStr(t.jy, t.jm, t.jd);
}

// ---- قالب‌بندی ----
export function formatJStr(jy: number, jm: number, jd: number): string {
  return `${jy}/${String(jm).padStart(2, "0")}/${String(jd).padStart(2, "0")}`;
}

export function formatDateJ(dateStr: string | null | undefined, withWeekday = false): string {
  if (!dateStr) return "—";
  const parts = parseJalali(dateStr);
  if (!parts) return "—";
  const { jy, jm, jd } = parts;
  // قالب عددی یکدست در کل سامانه: ۱۴۰۵/۰۱/۱۵
  const s = toFaDigits(`${jy}/${String(jm).padStart(2, "0")}/${String(jd).padStart(2, "0")}`);
  if (!withWeekday) return s;
  const wd = JALALI_WEEKDAYS[jalaliWeekdayIndex(jy, jm, jd)];
  return `${wd} ${s}`;
}

/** قالب عددی کوتاه ماه/سال: ۱۴۰۵/۰۱ */
export function formatMonthJ(year: number, month: number): string {
  return toFaDigits(`${year}/${String(month).padStart(2, "0")}`);
}

export function parseJalali(dateStr: string): { jy: number; jm: number; jd: number } | null {
  if (!dateStr) return null;
  const m = dateStr.trim().match(/^(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})$/);
  if (!m) return null;
  const jy = +m[1];
  const jm = +m[2];
  const jd = +m[3];
  if (jm < 1 || jm > 12) return null;
  if (jd < 1 || jd > daysInJalaliMonth(jy, jm)) return null;
  return { jy, jm, jd };
}

export function isValidJalali(dateStr: string): boolean {
  return parseJalali(dateStr) !== null;
}

// ---- تبدیل رشته جلالی به تاریخ میلادی (برای ذخیره در Prisma DateTime) ----
export function jalaliStrToISO(dateStr: string): string | null {
  const p = parseJalali(dateStr);
  if (!p) return null;
  const g = jalaliToGregorian(p.jy, p.jm, p.jd);
  return `${g.gy}-${String(g.gm).padStart(2, "0")}-${String(g.gd).padStart(2, "0")}T00:00:00.000Z`;
}

export function isoToJalaliStr(iso: string | Date): string {
  const d = typeof iso === "string" ? new Date(iso) : iso;
  if (isNaN(d.getTime())) return "";
  const j = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return formatJStr(j.jy, j.jm, j.jd);
}

// ---- روز هفته (شنبه = 0) ----
export function jalaliWeekdayIndex(jy: number, jm: number, jd: number): number {
  const g = jalaliToGregorian(jy, jm, jd);
  const jsDay = new Date(g.gy, g.gm - 1, g.gd).getDay(); // 0=Sunday
  return (jsDay + 1) % 7; // شنبه=0
}

// ---- اختلاف روزها بین دو تاریخ جلالی ----
export function diffJalaliDays(from: string, to: string): number {
  const a = parseJalali(from);
  const b = parseJalali(to);
  if (!a || !b) return 0;
  return j2d(b.jy, b.jm, b.jd) - j2d(a.jy, a.jm, a.jd);
}

// ---- افزودن روز/ماه ----
export function addJalaliMonths(dateStr: string, months: number): string {
  const p = parseJalali(dateStr);
  if (!p) return dateStr;
  let total = p.jy * 12 + (p.jm - 1) + months;
  const jy = Math.floor(total / 12);
  const jm = total - jy * 12 + 1;
  const jd = Math.min(p.jd, daysInJalaliMonth(jy, jm));
  return formatJStr(jy, jm, jd);
}

// ---- سال خدمت (برای سنوات) ----
export function yearsOfService(hireDateJ: string, atDateJ?: string): number {
  const h = parseJalali(hireDateJ);
  const t = parseJalali(atDateJ || todayJalaliStr());
  if (!h || !t) return 0;
  const days = j2d(t.jy, t.jm, t.jd) - j2d(h.jy, h.jm, h.jd);
  return Math.max(0, days / 365.25);
}

// ---- نام دوره ماهانه (قالب عددی: ۱۴۰۵/۰۱) ----
export function periodTitle(year: number, month: number): string {
  return formatMonthJ(year, month);
}

export function periodTitleFa(year: number, month: number): string {
  return periodTitle(year, month);
}

// ---- ارقام فارسی ----
export function toFaDigits(input: string | number): string {
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  return String(input).replace(/[0-9]/g, (d) => fa[+d]);
}

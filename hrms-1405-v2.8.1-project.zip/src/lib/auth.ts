// ============================================================
// احراز هویت — نشست امضاشده HMAC-SHA256 + رمز scrypt (بدون وابستگی خارجی)
// ============================================================
import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { NextRequest } from "next/server";

const SECRET = process.env.AUTH_SECRET || "hrms-1405-local-secret-key-change-in-production";
export const SESSION_COOKIE = "hrms_sid";
const SESSION_TTL_MS = 1000 * 60 * 60 * 12; // ۱۲ ساعت

export type { Role } from "./roles";
import type { Role } from "./roles";
export { canAccess, ROLE_ACCESS } from "./roles";
import { canAccess as _canAccess, ROLE_ACCESS } from "./roles";
import { hasPerm } from "./permissions";

export interface SessionUser {
  uid: string;
  username: string;
  fullName: string;
  role: Role | string; // کلید نقش (نقش‌های سیستمی یا سفارشی)
  roleName?: string; // نام نمایشی نقش
  perms?: string[]; // مجوزها (از جدول roles)
  employeeId?: string | null;
  exp: number;
}

// ---------- رمز عبور ----------
export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [salt, hash] = stored.split(":");
    if (!salt || !hash) return false;
    const test = scryptSync(password, salt, 64);
    const ref = Buffer.from(hash, "hex");
    return test.length === ref.length && timingSafeEqual(test, ref);
  } catch {
    return false;
  }
}

// ---------- توکن نشست ----------
function b64url(buf: Buffer): string {
  return buf.toString("base64url");
}

export function signSession(user: Omit<SessionUser, "exp">): string {
  const payload: SessionUser = { ...user, exp: Date.now() + SESSION_TTL_MS };
  const body = b64url(Buffer.from(JSON.stringify(payload), "utf8"));
  const sig = createHmac("sha256", SECRET).update(body).digest("base64url");
  return `${body}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): SessionUser | null {
  if (!token) return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = createHmac("sha256", SECRET).update(body).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as SessionUser;
    if (!payload.exp || payload.exp < Date.now()) return null;
    // توکن‌های قدیمی فاقد perms — از ماتریس قدیمی نقش‌ها مشتق می‌شود (تا انقضا ۱۲ ساعته)
    if (!payload.perms) {
      payload.perms = ROLE_ACCESS[payload.role as Role] || ["portal:view", "docs:view"];
    }
    return payload;
  } catch {
    return null;
  }
}

// ---------- خواندن نشست ----------
export async function getSession(): Promise<SessionUser | null> {
  const store = await cookies();
  return verifySessionToken(store.get(SESSION_COOKIE)?.value);
}

export function getSessionFromRequest(req: NextRequest): SessionUser | null {
  // ۱) کوکی — حالت عادی همان‌مبدأ (مرورگر مستقیم)
  const fromCookie = verifySessionToken(req.cookies.get(SESSION_COOKIE)?.value);
  if (fromCookie) return fromCookie;
  // ۲) هدر Authorization: Bearer — حالت iframe/پیش‌نمایش که کوکی SameSite مسدود می‌شود
  const authHeader = req.headers.get("authorization");
  if (authHeader && authHeader.toLowerCase().startsWith("bearer ")) {
    return verifySessionToken(authHeader.slice(7).trim());
  }
  return null;
}

// ---------- ویژگی‌های کوکی نشست ----------
const IPV4_OR_V6 = /^[0-9a-f.:\[\]]+$/i;

/**
 * کوکی نشست باید در دو زمینه کار کند:
 *  - دسترسی لوکال (127.0.0.1/localhost): SameSite=Lax کافی است
 *  - دامنه عمومی HTTPS (پیش‌نمایش): SameSite=None + Secure (+ Partitioned)
 *    تا در iframe بین‌سایتی هم ذخیره شود
 */
export function sessionCookieOptions(req: NextRequest) {
  const host = (req.headers.get("host") || "").toLowerCase().split(":")[0];
  const proto = (req.headers.get("x-forwarded-proto") || "").toLowerCase();
  const isLocalHost = host === "localhost" || host === "0.0.0.0" || host === "[::1]" || host === "::1" || IPV4_OR_V6.test(host);
  const isPublicDomain = !isLocalHost && host.includes(".");
  const isHttps = proto.split(",")[0].trim() === "https";
  if (isPublicDomain || isHttps) {
    return {
      httpOnly: true,
      sameSite: "none" as const,
      secure: true,
      partitioned: true,
      path: "/",
      maxAge: 60 * 60 * 12,
    };
  }
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    path: "/",
    maxAge: 60 * 60 * 12,
  };
}

// ---------- کنترل دسترسی نقش‌ها ----------
export class ApiError extends Error {
  status: number;
  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export function requireAuth(req: NextRequest, allowedRoles?: (Role | string)[]): SessionUser {
  const session = getSessionFromRequest(req);
  if (!session) throw new ApiError("ابتدا وارد سامانه شوید.", 401);
  if (allowedRoles && !allowedRoles.includes(session.role)) {
    throw new ApiError("شما به این بخش دسترسی ندارید.", 403);
  }
  return session;
}

/** کنترل دسترسی بر اساس مجوز نقش (RBAC داینامیک) */
export function requirePerm(req: NextRequest, perm: string): SessionUser {
  const session = getSessionFromRequest(req);
  if (!session) throw new ApiError("ابتدا وارد سامانه شوید.", 401);
  if (!hasPerm(session.perms, perm)) {
    throw new ApiError("شما به این بخش دسترسی ندارید.", 403);
  }
  return session;
}

/** کنترل دسترسی — حداقل یکی از مجوزها */
export function requireAnyPerm(req: NextRequest, perms: string[]): SessionUser {
  const session = getSessionFromRequest(req);
  if (!session) throw new ApiError("ابتدا وارد سامانه شوید.", 401);
  if (!perms.some((p) => hasPerm(session.perms, p))) {
    throw new ApiError("شما به این بخش دسترسی ندارید.", 403);
  }
  return session;
}

/** آیا نشست دارای مجوز است؟ (بدون پرتاب) */
export function sessionHasPerm(session: SessionUser | null, perm: string): boolean {
  return hasPerm(session?.perms, perm);
}

// نقش‌ها و ماتریس دسترسی: src/lib/roles.ts (ایمن برای کلاینت)

// ---------- ساخت نشست از رکورد کاربر (با بارگذاری مجوزهای نقش) ----------
import { db } from "./db";

type DbUser = {
  id: string;
  username: string;
  fullName: string;
  role: string;
  roleId: string | null;
  employeeId: string | null;
};

export async function buildSessionForUser(user: DbUser): Promise<Omit<SessionUser, "exp">> {
  let perms: string[] = [];
  let roleName: string | undefined;
  if (user.roleId) {
    const role = await db.role.findUnique({ where: { id: user.roleId } });
    if (role) {
      try {
        perms = JSON.parse(role.permissions) as string[];
      } catch {
        perms = [];
      }
      roleName = role.name;
    }
  }
  if (perms.length === 0) {
    // سازگاری: نقش بدون رکورد — از ماتریس قدیمی
    perms = (ROLE_ACCESS as Record<string, string[]>)[user.role] || ["portal:view", "docs:view"];
    roleName = roleName || user.role;
  }
  return {
    uid: user.id,
    username: user.username,
    fullName: user.fullName,
    role: user.role,
    roleName,
    perms,
    employeeId: user.employeeId,
  };
}


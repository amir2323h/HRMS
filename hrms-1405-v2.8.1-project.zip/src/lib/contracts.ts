// ============================================================
// ماژول قراردادها — رندر قالب با متغیرها + شماره سیستمی
// استانداردها: اسنپ‌شات متن رندرشده، شماره ترتیبی یکتا در سال،
// کاتالوگ متغیرهای مستندشده، جایگزینی امن بدون eval
// ============================================================
import { db } from "@/lib/db";
import { toFaDigits, todayJalaliStr } from "@/lib/jalali";
import { groupFa, numToFaWords, SUPP_INSURANCE_LABELS, MARITAL_LABELS, DEPENDENT_RELATION_LABELS } from "@/lib/format";

export interface ContractVars {
  [key: string]: string;
}

/** استخراج نام متغیرهای استفاده‌شده در قالب: {{نام}} */
export function extractPlaceholders(body: string): string[] {
  const found = new Set<string>();
  const re = /\{\{\s*([\w\u0600-\u06FF.]+)\s*\}\}/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(body)) !== null) found.add(m[1]);
  return Array.from(found);
}

/** جایگزینی متغیرها — متغیر ناشناخته با «—» پر می‌شود تا {{}} در متن نهایی نماند */
export function renderTemplate(body: string, vars: ContractVars): string {
  return body.replace(/\{\{\s*([\w\u0600-\u06FF.]+)\s*\}\}/g, (_all, name: string) => {
    const v = vars[name];
    return v === undefined || v === null ? "—" : String(v);
  });
}

/** کاتالوگ متغیرهای قابل استفاده در قالب‌ها (برای نمایش در UI) */
export const VARIABLE_CATALOG: { group: string; vars: { name: string; desc: string }[] }[] = [
  {
    group: "کارفرما",
    vars: [
      { name: "company_name", desc: "نام شرکت" },
      { name: "company_national_id", desc: "شناسه ملی شرکت" },
      { name: "company_sso_code", desc: "کد کارگاه تأمین اجتماعی" },
      { name: "company_tax_id", desc: "شناسه مالیاتی شرکت" },
      { name: "company_address", desc: "نشانی شرکت" },
    ],
  },
  {
    group: "کارمند",
    vars: [
      { name: "employee_name", desc: "نام و نام خانوادگی" },
      { name: "employee_first_name", desc: "نام" },
      { name: "employee_last_name", desc: "نام خانوادگی" },
      { name: "employee_father_name", desc: "نام پدر" },
      { name: "employee_national_id", desc: "کد ملی" },
      { name: "employee_personnel_code", desc: "کد پرسنلی" },
      { name: "employee_sso_number", desc: "شماره بیمه تأمین اجتماعی" },
      { name: "employee_birth_date", desc: "تاریخ تولد" },
      { name: "employee_job_title", desc: "عنوان شغل" },
      { name: "employee_grade", desc: "طبقه شغلی (مثلاً سطح ۳ — کارشناس)" },
      { name: "employee_marital_status", desc: "وضعیت تأهل" },
      { name: "employee_child_count", desc: "تعداد فرزند" },
      { name: "employee_mobile", desc: "موبایل" },
      { name: "employee_address", desc: "نشانی محل سکونت" },
      { name: "employee_hire_date", desc: "تاریخ استخدام" },
    ],
  },
  {
    group: "حقوق و مزایا",
    vars: [
      { name: "base_salary_toman", desc: "حقوق پایه (تومان، با جداکننده)" },
      { name: "base_salary_toman_words", desc: "حقوق پایه به حروف (تومان)" },
      { name: "base_salary_rial", desc: "حقوق پایه (ریال، با جداکننده)" },
      { name: "base_salary_rial_words", desc: "حقوق پایه به حروف (ریال)" },
      { name: "overtime_hours", desc: "ساعت اضافه‌کاری پیش‌فرض ماهانه" },
    ],
  },
  {
    group: "بیمه",
    vars: [
      { name: "supp_insurance_type", desc: "نوع بیمه تکمیلی" },
      { name: "supp_insured_count", desc: "تعداد کل افراد تحت پوشش بیمه تکمیلی (خود + بستگان)" },
      { name: "supp_dependents_count", desc: "تعداد بستگان تحت پوشش بیمه تکمیلی" },
      { name: "supp_dependents_list", desc: "فهرست بستگان تحت پوشش با نسبت (هر مورد یک سطر)" },
    ],
  },
  {
    group: "قرارداد",
    vars: [
      { name: "contract_number", desc: "شماره سیستمی قرارداد" },
      { name: "contract_date", desc: "تاریخ صدور قرارداد" },
      { name: "contract_start_date", desc: "تاریخ شروع قرارداد" },
      { name: "contract_end_date", desc: "تاریخ پایان قرارداد (خالی = نامحدود)" },
      { name: "today_date", desc: "تاریخ امروز" },
    ],
  },
];

/** ساخت دیکشنری متغیرها از داده کارمند + شرکت + گزینه‌های صدور */
export function buildVariables(input: {
  employee: {
    firstName?: string; lastName?: string; fatherName?: string; nationalId?: string; personnelCode?: string;
    ssoNumber?: string; birthDateJ?: string; jobTitle?: string; maritalStatus?: string; childCount?: number;
    mobile?: string; address?: string; hireDateJ?: string; baseSalary?: bigint | number;
    jobGrade?: { level: number; title: string } | null;
    suppInsurance?: string; suppCoveredCount?: number;
    insuranceDependents?: { firstName?: string; lastName?: string; relationship?: string; birthDateJ?: string; nationalId?: string }[];
  };
  company: { name: string; nationalId: string; ssoCode: string; taxId: string; address: string };
  contractNumber?: string;
  issueDateJ?: string;
  startDateJ?: string;
  endDateJ?: string;
}): ContractVars {
  const e = input.employee;
  const baseRial = Number(e.baseSalary || 0);
  const baseToman = Math.round(baseRial / 10);
  return {
    // کارفرما
    company_name: input.company.name,
    company_national_id: toFaDigits(input.company.nationalId || ""),
    company_sso_code: input.company.ssoCode || "",
    company_tax_id: toFaDigits(input.company.taxId || ""),
    company_address: input.company.address || "",
    // کارمند
    employee_name: `${e.firstName || ""} ${e.lastName || ""}`.trim(),
    employee_first_name: e.firstName || "",
    employee_last_name: e.lastName || "",
    employee_father_name: e.fatherName || "",
    employee_national_id: toFaDigits(e.nationalId || ""),
    employee_personnel_code: e.personnelCode || "",
    employee_sso_number: toFaDigits(e.ssoNumber || ""),
    employee_birth_date: e.birthDateJ ? toFaDigits(e.birthDateJ) : "",
    employee_job_title: e.jobTitle || "",
    employee_grade: e.jobGrade ? `سطح ${toFaDigits(e.jobGrade.level)} — ${e.jobGrade.title}` : "",
    employee_marital_status: MARITAL_LABELS[e.maritalStatus || "SINGLE"] || "",
    employee_child_count: toFaDigits(e.childCount || 0),
    employee_mobile: toFaDigits(e.mobile || ""),
    employee_address: e.address || "",
    employee_hire_date: e.hireDateJ ? toFaDigits(e.hireDateJ) : "",
    // حقوق
    base_salary_toman: groupFa(baseToman),
    base_salary_toman_words: numToFaWords(baseToman) + " تومان",
    base_salary_rial: groupFa(baseRial),
    base_salary_rial_words: numToFaWords(baseRial) + " ریال",
    overtime_hours: "",
    // بیمه
    supp_insurance_type: SUPP_INSURANCE_LABELS[e.suppInsurance || "NONE"] || "",
    supp_insured_count: toFaDigits(e.suppCoveredCount || 0),
    supp_dependents_count: toFaDigits((e.insuranceDependents || []).length),
    supp_dependents_list: (e.insuranceDependents || [])
      .map((d) => {
        const rel = DEPENDENT_RELATION_LABELS[d.relationship || ""] || d.relationship || "";
        const name = `${d.firstName || ""} ${d.lastName || ""}`.trim();
        return `• ${name} (${rel})${d.birthDateJ ? ` — متولد ${toFaDigits(d.birthDateJ)}` : ""}`;
      })
      .join("\n"),
    // قرارداد
    contract_number: input.contractNumber || "",
    contract_date: toFaDigits(input.issueDateJ || todayJalaliStr()),
    contract_start_date: toFaDigits(input.startDateJ || ""),
    contract_end_date: input.endDateJ ? toFaDigits(input.endDateJ) : "نامحدود",
    today_date: toFaDigits(todayJalaliStr()),
  };
}

/** شماره سیستمی قرارداد — ترتیبی یکتا در سال جلالی: CT-1405-00001 */
export async function nextContractNumber(): Promise<string> {
  const year = todayJalaliStr().slice(0, 4);
  const prefix = `CT-${year}-`;
  const existing = await db.contract.findMany({
    where: { contractNumber: { startsWith: prefix } },
    select: { contractNumber: true },
  });
  let max = 0;
  for (const c of existing) {
    const n = parseInt(c.contractNumber.slice(prefix.length), 10);
    if (!isNaN(n) && n > max) max = n;
  }
  // در صورت تداخل نادر (صدور هم‌زمان) یک شماره بعدی آزاد پیدا کن
  for (let i = max + 1; ; i++) {
    const candidate = `${prefix}${String(i).padStart(5, "0")}`;
    const clash = await db.contract.findUnique({ where: { contractNumber: candidate } });
    if (!clash) return candidate;
  }
}

/** اعتبارسنجی وضعیت قرارداد */
export const CONTRACT_STATUSES = ["DRAFT", "ISSUED", "SIGNED", "ACTIVE", "EXPIRED", "TERMINATED", "VOIDED"] as const;
export type ContractStatus = (typeof CONTRACT_STATUSES)[number];

/** گذارهای مجاز چرخه وضعیت (استاندارد گردش کار) */
export const STATUS_TRANSITIONS: Record<string, string[]> = {
  DRAFT: ["ISSUED", "VOIDED"],
  ISSUED: ["SIGNED", "VOIDED"],
  SIGNED: ["ACTIVE", "VOIDED"],
  ACTIVE: ["TERMINATED", "EXPIRED"],
  EXPIRED: [],
  TERMINATED: [],
  VOIDED: [],
};

export function canTransition(from: string, to: string): boolean {
  return (STATUS_TRANSITIONS[from] || []).includes(to);
}

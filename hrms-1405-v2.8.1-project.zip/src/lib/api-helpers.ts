// ============================================================
// ابزارهای کمکی API — پاسخ JSON، تبدیل BigInt، لاگ حسابرسی
// ============================================================
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ApiError, type SessionUser } from "@/lib/auth";

/** تبدیل امن BigInt به Number برای JSON */
export function num(v: bigint | number | null | undefined): number {
  if (v === null || v === undefined) return 0;
  if (typeof v === "bigint") return Number(v);
  return v;
}

/** اجرای امن هندلر API با مدیریت خطا */
export async function handle<T>(fn: () => Promise<T>): Promise<NextResponse> {
  try {
    const data = await fn();
    // اگر هندلر خودش Response کامل (با کوکی/هدر/استاتوس) ساخته، مستقیم عبور بده
    if (data instanceof NextResponse || data instanceof Response) {
      return data as NextResponse;
    }
    return NextResponse.json(data as object);
  } catch (err) {
    if (err instanceof ApiError) {
      return NextResponse.json({ error: err.message }, { status: err.status });
    }
    const message = err instanceof Error ? err.message : "خطای داخلی سرور";
    console.error("[API ERROR]", err);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

/** لاگ حسابرسی */
export async function audit(
  user: SessionUser | null,
  action: string,
  entity: string,
  entityId: string,
  summary: string,
  before?: unknown,
  after?: unknown
): Promise<void> {
  try {
    await db.auditLog.create({
      data: {
        userId: user?.uid || null,
        userName: user?.fullName || "system",
        action,
        entity,
        entityId,
        summary,
        before: before === undefined ? null : JSON.stringify(before, jsonSafe),
        after: after === undefined ? null : JSON.stringify(after, jsonSafe),
      },
    });
  } catch (e) {
    console.error("[AUDIT ERROR]", e);
  }
}

function jsonSafe(_key: string, value: unknown) {
  if (typeof value === "bigint") return Number(value);
  if (value instanceof Uint8Array) return `[binary ${value.length} bytes]`;
  return value;
}

/** خواندن IP (برای لاگ) */
export function clientIp(req: NextRequest): string {
  return req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "";
}

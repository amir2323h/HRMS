// ============================================================
// لاگ تغییرات پرونده پرسنل — ثبت/نمایش/بازگردانی هر تغییری
// (سطح شغلی، پایه حقوق، شغل، قرارداد، اطلاعات فردی، دپارتمان، ...)
// هر رکورد: JSON فیلدهای تغییریافته + مقادیر قدیم/جدید (خامص + نمایشی)
// بازگردانی: مقدار «قدیم» هر فیلد دوباره روی پرونده اعمال می‌شود
// ============================================================
import { db } from "@/lib/db";
import type { SessionUser } from "@/lib/auth";
import { audit } from "@/lib/api-helpers";
import {
  CONTRACT_TYPE_LABELS,
  EMPLOYEE_STATUS_LABELS,
  EMPLOYMENT_TYPE_LABELS,
  SHIFT_PATTERN_LABELS,
  MARITAL_LABELS,
  SUPP_INSURANCE_LABELS,
  fmtToman,
} from "@/lib/format";
import { formatDateJ, toFaDigits, isoToJalaliStr } from "@/lib/jalali";

// ------------------- انواع -------------------

/** یک فیلد تغییریافته — خام برای بازگردانی + نمایشی برای UI */
export interface ChangeEntry {
  field: string; // نام فیلد (یا department)
  label: string; // برچسب فارسی
  kind: "text" | "money" | "number" | "date" | "enum" | "grade" | "department" | "jobTitle";
  from: string; // مقدار قدیم (serialized — برای بازگردانی)
  to: string; // مقدار جدید
  fromDisplay: string; // نمایش قدیم
  toDisplay: string; // نمایش جدید
  extra?: { fromId?: string; toId?: string }; // شناسه‌های مرجع (دپارتمان/عنوان شغل) برای بازگردانی
}

/** اسنپ‌شات پرونده برای مقایسه — از رکورد Prisma با روابط jobGrade/departments */
export interface EmpSnapshot {
  id: string;
  firstName: string;
  lastName: string;
  personnelCode: string;
  nationalId: string;
  ssoNumber: string;
  fatherName: string;
  birthDateJ: string;
  mobile: string;
  email: string;
  address: string;
  maritalStatus: string;
  childCount: number;
  hireDateJ: string;
  probationEndDateJ: string;
  contractType: string;
  contractStartJ: string;
  contractEndJ: string;
  employmentType: string;
  shiftPattern: string;
  status: string;
  jobGradeId: string | null;
  gradeLevel: number | null;
  gradeTitle: string;
  jobTitleId: string | null;
  jobTitle: string;
  baseSalary: number; // ریال
  overtimeHours: number;
  bankName: string;
  iban: string;
  notes: string;
  suppInsurance: string;
  suppCoveredCount: number;
  suppInsurerName: string;
  suppPolicyNumber: string;
  departmentId: string;
  departmentName: string;
}

export type ChangeSource = "CREATE" | "EDIT" | "IMPORT" | "REVERT" | "SALARY";

export const CHANGE_SOURCE_LABELS: Record<string, string> = {
  CREATE: "ثبت اولیه پرونده",
  EDIT: "ویرایش پرونده",
  IMPORT: "ایمپورت اکسل",
  REVERT: "بازگردانی تغییر",
  SALARY: "اعمال تغییر حقوق",
};

// ------------------- کاتالوگ فیلدهای ردیابی‌شده -------------------

interface FieldSpec {
  field: keyof EmpSnapshot | "department";
  label: string;
  kind: ChangeEntry["kind"];
  /** تبدیل مقدار خام → متن نمایشی */
  display?: (from: string, to: string) => { fromDisplay: string; toDisplay: string };
}

const ENUM_DISPLAY: Record<string, Record<string, string>> = {
  maritalStatus: MARITAL_LABELS,
  contractType: CONTRACT_TYPE_LABELS,
  status: EMPLOYEE_STATUS_LABELS,
  employmentType: EMPLOYMENT_TYPE_LABELS,
  shiftPattern: SHIFT_PATTERN_LABELS,
  suppInsurance: SUPP_INSURANCE_LABELS,
};

const TRACKED: FieldSpec[] = [
  // ——— اطلاعات فردی ———
  { field: "firstName", label: "نام", kind: "text" },
  { field: "lastName", label: "نام خانوادگی", kind: "text" },
  { field: "nationalId", label: "کد ملی", kind: "text" },
  { field: "fatherName", label: "نام پدر", kind: "text" },
  { field: "birthDateJ", label: "تاریخ تولد", kind: "date" },
  { field: "mobile", label: "موبایل", kind: "text" },
  { field: "email", label: "ایمیل", kind: "text" },
  { field: "address", label: "نشانی", kind: "text" },
  { field: "maritalStatus", label: "وضعیت تأهل", kind: "enum" },
  { field: "childCount", label: "تعداد فرزند", kind: "number" },
  { field: "ssoNumber", label: "شماره بیمه", kind: "text" },
  // ——— قرارداد و استخدام ———
  { field: "hireDateJ", label: "تاریخ استخدام", kind: "date" },
  { field: "probationEndDateJ", label: "پایان دوره آزمایشی", kind: "date" },
  { field: "contractType", label: "نوع قرارداد", kind: "enum" },
  { field: "contractStartJ", label: "شروع قرارداد", kind: "date" },
  { field: "contractEndJ", label: "پایان قرارداد", kind: "date" },
  { field: "employmentType", label: "نوع اشتغال", kind: "enum" },
  { field: "shiftPattern", label: "الگوی شیفت", kind: "enum" },
  { field: "status", label: "وضعیت اشتغال", kind: "enum" },
  // ——— شغل و حقوق ———
  { field: "jobGradeId", label: "طبقه/سطح شغلی", kind: "grade" },
  { field: "jobTitle", label: "عنوان شغل", kind: "jobTitle" },
  { field: "baseSalary", label: "حقوق پایه", kind: "money" },
  { field: "overtimeHours", label: "اضافه‌کاری پیش‌فرض", kind: "number" },
  { field: "department", label: "دپارتمان", kind: "department" },
  // ——— مالی و بیمه تکمیلی ———
  { field: "bankName", label: "بانک", kind: "text" },
  { field: "iban", label: "شماره شبا", kind: "text" },
  { field: "suppInsurance", label: "بیمه تکمیلی", kind: "enum" },
  { field: "suppCoveredCount", label: "افراد تحت پوشش بیمه تکمیلی", kind: "number" },
  { field: "suppInsurerName", label: "بیمه‌گر تکمیلی", kind: "text" },
  { field: "suppPolicyNumber", label: "شماره بیمه‌نامه تکمیلی", kind: "text" },
  { field: "notes", label: "یادداشت", kind: "text" },
];

// ------------------- اسنپ‌شات از رکورد Prisma -------------------

/** ساخت اسنپ‌شات مقایسه از رکورد کارمند (با روابط jobGrade و departments) */
export function snapshotFromEmployee(emp: Record<string, unknown>): EmpSnapshot {
  const grade = (emp.jobGrade || null) as { id: string; level: number; title: string } | null;
  const departments = (emp.departments || []) as { department?: { id: string; name: string } }[];
  const primaryDept = departments[0]?.department || null;
  return {
    id: String(emp.id || ""),
    firstName: String(emp.firstName || ""),
    lastName: String(emp.lastName || ""),
    personnelCode: String(emp.personnelCode || ""),
    nationalId: String(emp.nationalId || ""),
    ssoNumber: String(emp.ssoNumber || ""),
    fatherName: String(emp.fatherName || ""),
    birthDateJ: String(emp.birthDateJ || ""),
    mobile: String(emp.mobile || ""),
    email: String(emp.email || ""),
    address: String(emp.address || ""),
    maritalStatus: String(emp.maritalStatus || "SINGLE"),
    childCount: Number(emp.childCount || 0),
    hireDateJ: String(emp.hireDateJ || ""),
    probationEndDateJ: String(emp.probationEndDateJ || ""),
    contractType: String(emp.contractType || "PERMANENT"),
    contractStartJ: String(emp.contractStartJ || ""),
    contractEndJ: String(emp.contractEndJ || ""),
    employmentType: String(emp.employmentType || "DAILY"),
    shiftPattern: String(emp.shiftPattern || ""),
    status: String(emp.status || "ACTIVE"),
    jobGradeId: (emp.jobGradeId as string | null) || null,
    gradeLevel: grade ? Number(grade.level) : null,
    gradeTitle: grade ? String(grade.title) : "",
    jobTitleId: (emp.jobTitleId as string | null) || null,
    jobTitle: String(emp.jobTitle || ""),
    baseSalary: Number(emp.baseSalary || 0),
    overtimeHours: Number(emp.overtimeHours || 0),
    bankName: String(emp.bankName || ""),
    iban: String(emp.iban || ""),
    notes: String(emp.notes || ""),
    suppInsurance: String(emp.suppInsurance || "NONE"),
    suppCoveredCount: Number(emp.suppCoveredCount || 0),
    suppInsurerName: String(emp.suppInsurerName || ""),
    suppPolicyNumber: String(emp.suppPolicyNumber || ""),
    departmentId: primaryDept ? String(primaryDept.id) : "",
    departmentName: primaryDept ? String(primaryDept.name) : "",
  };
}

// ------------------- دیف -------------------

/** نمایش طبقه: «سطح ۳ — کارشناس» */
function gradeDisplay(level: number | null, title: string): string {
  if (level === null || level === undefined) return "بدون طبقه";
  return title ? `سطح ${toFaDigits(level)} — ${title}` : `سطح ${toFaDigits(level)}`;
}

function enumDisplay(field: string, value: string): string {
  if (!value) return "—";
  const map = ENUM_DISPLAY[field] || {};
  return map[value] || value;
}

/**
 * مقایسه دو اسنپ‌شات → فهرست فیلدهای تغییریافته.
 * خروجی هم برای نمایش (fromDisplay/toDisplay) و هم برای بازگردانی (from خام) کافی است.
 */
export function diffEmployee(a: EmpSnapshot, b: EmpSnapshot): ChangeEntry[] {
  const out: ChangeEntry[] = [];
  for (const spec of TRACKED) {
    let fromRaw: string;
    let toRaw: string;
    let fromDisplay: string;
    let toDisplay: string;
    let extra: ChangeEntry["extra"] | undefined;

    if (spec.field === "department") {
      fromRaw = a.departmentId;
      toRaw = b.departmentId;
      fromDisplay = a.departmentName || "بدون دپارتمان";
      toDisplay = b.departmentName || "بدون دپارتمان";
      if (fromRaw !== toRaw) extra = { fromId: fromRaw, toId: toRaw };
    } else if (spec.field === "jobGradeId") {
      fromRaw = a.jobGradeId || "";
      toRaw = b.jobGradeId || "";
      fromDisplay = gradeDisplay(a.gradeLevel, a.gradeTitle);
      toDisplay = gradeDisplay(b.gradeLevel, b.gradeTitle);
    } else if (spec.field === "jobTitle") {
      fromRaw = a.jobTitle;
      toRaw = b.jobTitle;
      fromDisplay = a.jobTitle || "—";
      toDisplay = b.jobTitle || "—";
      if (fromRaw !== toRaw) extra = { fromId: a.jobTitleId || "", toId: b.jobTitleId || "" };
    } else {
      const key = spec.field as keyof EmpSnapshot;
      const av = a[key];
      const bv = b[key];
      fromRaw = String(av ?? "");
      toRaw = String(bv ?? "");
      switch (spec.kind) {
        case "money":
          fromDisplay = fromRaw === "" ? "—" : fmtToman(Number(fromRaw) || 0);
          toDisplay = toRaw === "" ? "—" : fmtToman(Number(toRaw) || 0);
          break;
        case "date":
          fromDisplay = formatDateJ(fromRaw);
          toDisplay = formatDateJ(toRaw);
          break;
        case "enum":
          fromDisplay = enumDisplay(String(spec.field), fromRaw);
          toDisplay = enumDisplay(String(spec.field), toRaw);
          break;
        case "number":
          fromDisplay = fromRaw === "" ? "—" : toFaDigits(fromRaw);
          toDisplay = toRaw === "" ? "—" : toFaDigits(toRaw);
          break;
        default:
          fromDisplay = fromRaw || "—";
          toDisplay = toRaw || "—";
      }
    }

    if (fromRaw !== toRaw) {
      out.push({ field: String(spec.field), label: spec.label, kind: spec.kind, from: fromRaw, to: toRaw, fromDisplay, toDisplay, extra });
    }
  }
  return out;
}

// ------------------- ثبت لاگ -------------------

/**
 * فیلدهای کلیدی «ثبت اولیه» — from خالی، to مقدار اولیه
 * (رکوردهای CREATE قابل بازگردانی نیستند — فقط سند ثبت‌اند)
 */
export function initialChanges(s: EmpSnapshot): ChangeEntry[] {
  const CREATE_FIELDS = ["nationalId", "hireDateJ", "contractType", "employmentType", "jobTitle", "jobGradeId", "baseSalary", "overtimeHours", "department", "maritalStatus", "childCount"];
  const empty: EmpSnapshot = {
    ...s,
    nationalId: "", hireDateJ: "", contractType: "", employmentType: "", jobTitle: "",
    jobGradeId: null, gradeLevel: null, gradeTitle: "", baseSalary: 0, overtimeHours: 0,
    departmentId: "", departmentName: "", maritalStatus: "", childCount: 0,
  };
  const all = diffEmployee(empty, s);
  return all.filter((c) => CREATE_FIELDS.includes(c.field));
}

/** ثبت لاگ تغییر پرونده — هرگز عملیات اصلی را نمی‌شکند (خطا فقط لاگ می‌شود) */
export async function logEmployeeChange(
  session: SessionUser | null,
  employeeId: string,
  changes: ChangeEntry[],
  source: ChangeSource,
  reason = ""
): Promise<void> {
  if (changes.length === 0) return;
  try {
    const emp = await db.employee.findUnique({
      where: { id: employeeId },
      select: { firstName: true, lastName: true, personnelCode: true },
    });
    await db.employeeChangeLog.create({
      data: {
        employeeId,
        employeeName: emp ? `${emp.firstName} ${emp.lastName}` : "",
        personnelCode: emp?.personnelCode || "",
        changes: JSON.stringify(changes),
        changeCount: changes.length,
        source,
        reason: reason.slice(0, 500),
        performedBy: session?.uid || "",
        performedByName: session?.fullName || "system",
      },
    });
  } catch (e) {
    console.error("[EMPLOYEE CHANGELOG ERROR]", e);
  }
}

// ------------------- سریالایزر -------------------

export interface EmployeeChangeLogRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  personnelCode: string;
  changes: ChangeEntry[];
  changeCount: number;
  source: string;
  reason: string;
  performedBy: string;
  performedByName: string;
  performedAt: string;
  revertedAt: string | null;
  revertedByName: string;
  revertOfId: string;
}

export function serializeChangeLog(l: Record<string, unknown>): EmployeeChangeLogRecord {
  let changes: ChangeEntry[] = [];
  try {
    changes = JSON.parse(String(l.changes || "[]")) as ChangeEntry[];
  } catch {
    changes = [];
  }
  return {
    id: String(l.id || ""),
    employeeId: String(l.employeeId || ""),
    employeeName: String(l.employeeName || ""),
    personnelCode: String(l.personnelCode || ""),
    changes,
    changeCount: Number(l.changeCount || changes.length || 0),
    source: String(l.source || "EDIT"),
    reason: String(l.reason || ""),
    performedBy: String(l.performedBy || ""),
    performedByName: String(l.performedByName || ""),
    performedAt: (l.performedAt as Date)?.toISOString?.() || String(l.performedAt || ""),
    revertedAt: l.revertedAt ? (l.revertedAt as Date).toISOString() : null,
    revertedByName: String(l.revertedByName || ""),
    revertOfId: String(l.revertOfId || ""),
  };
}

// ------------------- بازگردانی -------------------

export interface RevertResult {
  ok: boolean;
  error?: string;
  before?: EmpSnapshot;
  employee?: EmpSnapshot;
  revertedChanges: ChangeEntry[];
  salaryTouched: boolean;
}

/**
 * بازگردانی یک تغییر: مقادیر «قدیم» فیلدها دوباره روی پرونده اعمال می‌شود.
 * - رکورد REVERT جدید ثبت می‌شود (تغییرات معکوس — بازگردانیِ بازگردانی هم ممکن است)
 * - رکورد اصلی مهر «بازگردانی‌شده» می‌خورد
 * - اگر حقوق/طبقه تغییر کرده باشد، در لاگ حقوق (SalaryChangeLog) هم ثبت می‌شود
 */
export async function revertEmployeeChange(session: SessionUser, logId: string): Promise<RevertResult> {
  const log = await db.employeeChangeLog.findUnique({ where: { id: logId } });
  if (!log) return { ok: false, error: "رکورد تغییر یافت نشد.", revertedChanges: [], salaryTouched: false };
  if (log.revertedAt) return { ok: false, error: "این تغییر قبلاً بازگردانی شده است. (برای بازگرداندن مجدد، رکورد «بازگردانی» مربوطه را بازگردانی کنید)", revertedChanges: [], salaryTouched: false };

  let changes: ChangeEntry[] = [];
  try {
    changes = JSON.parse(log.changes || "[]") as ChangeEntry[];
  } catch {
    changes = [];
  }
  if (changes.length === 0) return { ok: false, error: "جزئیات این تغییر قابل خواندن نیست.", revertedChanges: [], salaryTouched: false };

  const empBefore = await db.employee.findUnique({
    where: { id: log.employeeId },
    include: { jobGrade: true, departments: { include: { department: true } } },
  });
  if (!empBefore) return { ok: false, error: "کارمند این تغییر یافت نشد (احتمالاً حذف شده است).", revertedChanges: [], salaryTouched: false };

  // ——— اعمال مقادیر قدیم روی پرونده ———
  const data: Record<string, unknown> = {};
  let revertDeptId: string | null = null; // دپارتمانی که باید حذف/جایگزین شود
  let hadDepartment = false;
  for (const c of changes) {
    switch (c.field) {
      case "baseSalary": {
        const v = Math.round(Number(c.from));
        if (!v || v <= 0) return { ok: false, error: "مقدار قدیم حقوق پایه نامعتبر است — بازگردانی انجام نشد.", revertedChanges: [], salaryTouched: false };
        data.baseSalary = BigInt(v);
        break;
      }
      case "overtimeHours":
      case "childCount":
      case "suppCoveredCount":
        data[c.field] = Math.max(0, Number(c.from) || 0);
        break;
      case "jobGradeId":
        data.jobGradeId = c.from || null;
        break;
      case "jobTitle":
        data.jobTitle = c.from;
        data.jobTitleId = c.extra?.fromId || null;
        break;
      case "department":
        revertDeptId = c.extra?.fromId || null;
        hadDepartment = true;
        break;
      default:
        data[c.field] = c.from; // رشته‌ها/enumها
    }
  }

  if (Object.keys(data).length > 0) {
    await db.employee.update({ where: { id: log.employeeId }, data });
  }
  if (hadDepartment) {
    await db.employeeDepartment.deleteMany({ where: { employeeId: log.employeeId } });
    if (revertDeptId) {
      await db.employeeDepartment.create({
        data: { employeeId: log.employeeId, departmentId: revertDeptId, allocationPercent: 100 },
      });
    }
  }

  const empAfter = await db.employee.findUnique({
    where: { id: log.employeeId },
    include: { jobGrade: true, departments: { include: { department: true } } },
  });

  // ——— رکورد REVERT (تغییرات معکوس) ———
  const reversed: ChangeEntry[] = changes.map((c) => ({
    field: c.field,
    label: c.label,
    kind: c.kind,
    from: c.to,
    to: c.from,
    fromDisplay: c.toDisplay,
    toDisplay: c.fromDisplay,
    extra: c.extra ? { fromId: c.extra.toId || "", toId: c.extra.fromId || "" } : undefined,
  }));
  await db.employeeChangeLog.create({
    data: {
      employeeId: log.employeeId,
      employeeName: log.employeeName,
      personnelCode: log.personnelCode,
      changes: JSON.stringify(reversed),
      changeCount: reversed.length,
      source: "REVERT",
      reason: `بازگردانی تغییر ${formatDateJ(isoToJalaliStr(log.performedAt))}${log.reason ? ` (${log.reason})` : ""}`,
      performedBy: session.uid,
      performedByName: session.fullName,
      revertOfId: log.id,
    },
  });

  // ——— مهر رکورد اصلی ———
  await db.employeeChangeLog.update({
    where: { id: log.id },
    data: { revertedAt: new Date(), revertedBy: session.uid, revertedByName: session.fullName },
  });

  // بازگردانیِ «بازگردانی»: تغییر دوباره اعمال می‌شود — مهر رکورد اصلی پاک شود
  if (log.source === "REVERT" && log.revertOfId) {
    await db.employeeChangeLog.update({
      where: { id: log.revertOfId },
      data: { revertedAt: null, revertedBy: "", revertedByName: "" },
    }).catch(() => undefined);
  }

  const salaryTouched = changes.some((c) => ["baseSalary", "overtimeHours", "jobGradeId"].includes(c.field));
  await audit(
    session,
    "UPDATE",
    "EMPLOYEE",
    log.employeeId,
    `بازگردانی تغییر پرونده ${log.employeeName} (${log.personnelCode}) — ${changes.length} فیلد`,
    { revertedLogId: log.id, source: log.source },
    { revertedFields: changes.map((c) => c.label).join(", ") }
  );

  return {
    ok: true,
    before: snapshotFromEmployee(empBefore as unknown as Record<string, unknown>),
    employee: empAfter ? snapshotFromEmployee(empAfter as unknown as Record<string, unknown>) : undefined,
    revertedChanges: reversed,
    salaryTouched,
  };
}

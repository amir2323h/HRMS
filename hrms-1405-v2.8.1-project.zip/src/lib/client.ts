"use client";

// ============================================================
// لایه کلاینت — فراخوانی API + قلاب‌های داده + مدیریت توکن نشست
// نشست دولایه: کوکی (حالت عادی) + Bearer توکن در localStorage
// (حالت iframe/پیش‌نمایش که مرورگر کوکی SameSite را مسدود می‌کند)
// ============================================================
import { useCallback, useEffect, useRef, useState } from "react";

export class ApiClientError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

// ---------- توکن نشست سمت کلاینت ----------
const TOKEN_KEY = "hrms_token";
export const AUTH_EVENT = "hrms:auth";

export function getAuthToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(TOKEN_KEY);
  } catch {
    return null; // حالت private browsing و غیره
  }
}

export function setAuthToken(token: string): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(TOKEN_KEY, token);
  } catch {
    /* بدون localStorage — کوکی همچنان کار می‌کند */
  }
}

export function clearAuthToken(): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* نادیده بگیر */
  }
}

/** رویداد تغییر وضعیت نشست — AuthGate به آن گوش می‌دهد */
export function notifyAuthChanged(type: "login" | "logout"): void {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent(AUTH_EVENT, { detail: { type } }));
}

export async function api<T = unknown>(path: string, options?: RequestInit & { json?: unknown }): Promise<T> {
  const { json, ...rest } = options || {};
  const token = getAuthToken();
  const res = await fetch(path, {
    ...rest,
    headers: {
      ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(rest.headers || {}),
    },
    body: json !== undefined ? JSON.stringify(json) : rest.body,
    cache: "no-store",
  });
  let data: unknown = null;
  try {
    data = await res.json();
  } catch {
    /* بدون JSON */
  }
  if (!res.ok) {
    // نشست منقضی/ابطال‌شده — پاک‌سازی توکن و بازگشت به صفحه ورود
    if (res.status === 401 && token) {
      clearAuthToken();
      notifyAuthChanged("logout");
    }
    const message = (data as { error?: string })?.error || `خطای ${res.status}`;
    throw new ApiClientError(message, res.status);
  }
  return data as T;
}

/** قلاب داده با بارگذاری خودکار */
export function useApi<T = unknown>(path: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(!!path);
  const [error, setError] = useState<string | null>(null);
  const mounted = useRef(true);
  const pathRef = useRef(path);
  pathRef.current = path;

  const load = useCallback(async () => {
    const p = pathRef.current;
    if (!p) return;
    setLoading(true);
    setError(null);
    try {
      const d = await api<T>(p);
      if (mounted.current) setData(d);
    } catch (e) {
      if (mounted.current) setError(e instanceof Error ? e.message : "خطا در دریافت داده");
    } finally {
      if (mounted.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    mounted.current = true;
    load();
    return () => {
      mounted.current = false;
    };
  }, [path, ...deps]);

  return { data, loading, error, refetch: load, setData };
}

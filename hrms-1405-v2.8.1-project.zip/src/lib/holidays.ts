// ============================================================
// تعطیلات رسمی و شیفت‌های کاری — تقویم، ساعت استاندارد دوره
//  • کاتالوگ تعطیلات رسمی ۱۴۰۵ (تأییدشده از تقویم رسمی کشور/منابع وب)
//  • جدول شیفت‌ها: روزکار ۰۸–۱۷ (با ناهار) | شیفت صبح ۰۸–۱۶ | شیفت عصر/شب ۱۶–۲۴
//  • سیاست تعطیلی هفتگی: روزکار = پنجشنبه+جمعه | شیفتی = جمعه (قابل تنظیم)
//  • محاسبه ساعت استاندارد هر ماه/دوره با کسر پنجشنبه/جمعه/تعطیلات رسمی
// ============================================================
import { db } from "@/lib/db";
import { jalaliWeekdayIndex, parseJalali, daysInJalaliMonth, formatJStr, JALALI_WEEKDAYS } from "@/lib/jalali";

// --------------------------- تعطیلات رسمی ۱۴۰۵ ---------------------------

export interface HolidaySeed {
  dateJ: string;
  title: string;
}

/**
 * تعطیلات رسمی سال ۱۴۰۵ — ۲۶ روز (بر پایه تقویم رسمی کشور)
 * صحت‌سنجی: تطابق توزیع پنجشنبه (۶) و جمعه (۳) با گزارش رسمی سال ۱۴۰۵؛
 * تاریخ‌های قمری (اربعین ۱۳ مرداد، رحلت پیامبر ۲۱ مرداد و…) با گزارش‌های
 * خبری مهر/مرداد ۱۴۰۵ تطبیق داده شد.
 */
export const OFFICIAL_HOLIDAYS_1405: HolidaySeed[] = [
  // ---- فروردین ----
  { dateJ: "1405/01/01", title: "عید سعید فطر — آغاز نوروز" },
  { dateJ: "1405/01/02", title: "تعطیل به مناسبت عید سعید فطر" },
  { dateJ: "1405/01/03", title: "عید نوروز" },
  { dateJ: "1405/01/04", title: "عید نوروز" },
  { dateJ: "1405/01/12", title: "روز جمهوری اسلامی ایران" },
  { dateJ: "1405/01/13", title: "روز طبیعت (سیزده‌بدر)" },
  { dateJ: "1405/01/25", title: "شهادت امام جعفر صادق (ع)" },
  // ---- خرداد ----
  { dateJ: "1405/03/06", title: "عید سعید قربان" },
  { dateJ: "1405/03/14", title: "رحلت امام خمینی — عید سعید غدیر خم" },
  { dateJ: "1405/03/15", title: "قیام خونین ۱۵ خرداد" },
  // ---- تیر ----
  { dateJ: "1405/04/03", title: "تاسوعای حسینی" },
  { dateJ: "1405/04/04", title: "عاشورای حسینی" },
  // ---- مرداد ----
  { dateJ: "1405/05/13", title: "اربعین حسینی" },
  { dateJ: "1405/05/21", title: "رحلت حضرت رسول اکرم (ص) و شهادت امام حسن مجتبی (ع)" },
  { dateJ: "1405/05/22", title: "شهادت امام رضا (ع)" },
  { dateJ: "1405/05/30", title: "شهادت امام حسن عسکری (ع)" },
  // ---- شهریور ----
  { dateJ: "1405/06/08", title: "میلاد حضرت رسول اکرم (ص) و امام جعفر صادق (ع)" },
  // ---- آبان ----
  { dateJ: "1405/08/22", title: "شهادت حضرت فاطمه زهرا (س)" },
  // ---- دی ----
  { dateJ: "1405/10/02", title: "ولادت امام علی (ع) — روز پدر" },
  { dateJ: "1405/10/16", title: "مبعث حضرت رسول اکرم (ص)" },
  // ---- بهمن ----
  { dateJ: "1405/11/04", title: "ولادت حضرت قائم (عج) — نیمه شعبان" },
  { dateJ: "1405/11/22", title: "پیروزی انقلاب اسلامی ایران" },
  // ---- اسفند ----
  { dateJ: "1405/12/09", title: "شهادت امام علی (ع)" },
  { dateJ: "1405/12/19", title: "عید سعید فطر" },
  { dateJ: "1405/12/20", title: "تعطیل به مناسبت عید سعید فطر" },
  { dateJ: "1405/12/29", title: "روز ملی شدن صنعت نفت ایران" },
];

/** کاتالوگ داخلی بر اساس سال (در حال حاضر ۱۴۰۵) */
export function builtinHolidayCatalog(year: number): HolidaySeed[] {
  if (year === 1405) return OFFICIAL_HOLIDAYS_1405;
  return [];
}

// --------------------------- شیفت‌ها و ساعت کاری ---------------------------

export interface ShiftDef {
  code: string; // DAILY | MORNING | EVENING | NIGHT
  title: string;
  start: string; // "HH:MM"
  end: string; // "HH:MM"
  breakMinutes: number; // استراحت/ناهار داخل شیفت
}

export interface WorkSchedule {
  /** روزکار: ۰۸:۰۰–۱۷:۰۰ با ۶۰ دقیقه ناهار → ۸ ساعت مؤثر */
  daily: ShiftDef;
  /** شیفت صبح ۰۸:۰۰–۱۶:۰۰ */
  morning: ShiftDef;
  /** شیفت عصر/شب ۱۶:۰۰–۲۴:۰۰ */
  evening: ShiftDef;
  /** شیفت شب ۲۴:۰۰–۰۸:۰۰ (الگوی سه‌شیفت) */
  night: ShiftDef;
  /** روزهای تعطیل هفتگی به تفکیک نوع اشتغال — ایندکس روز هفته (شنبه=۰ … جمعه=۶) */
  weekend: { DAILY: number[]; SHIFT: number[] };
}

/** ایندکس روزهای هفته: شنبه=۰ … پنجشنبه=۵، جمعه=۶ */
export const WEEKDAY = { SAT: 0, SUN: 1, MON: 2, TUE: 3, WED: 4, THU: 5, FRI: 6 } as const;

export const WORK_SCHEDULE_DEFAULTS: WorkSchedule = {
  daily: { code: "DAILY", title: "روزکار (اداری)", start: "08:00", end: "17:00", breakMinutes: 60 },
  morning: { code: "MORNING", title: "شیفت صبح", start: "08:00", end: "16:00", breakMinutes: 0 },
  evening: { code: "EVENING", title: "شیفت عصر/شب", start: "16:00", end: "24:00", breakMinutes: 0 },
  night: { code: "NIGHT", title: "شیفت شب", start: "24:00", end: "08:00", breakMinutes: 0 },
  // روزکار: پنجشنبه و جمعه تعطیل | شیفتی: جمعه تعطیل
  weekend: { DAILY: [WEEKDAY.THU, WEEKDAY.FRI], SHIFT: [WEEKDAY.FRI] },
};

function normalizeSchedule(input: Partial<WorkSchedule> | null | undefined): WorkSchedule {
  const d = WORK_SCHEDULE_DEFAULTS;
  if (!input) return { ...d, weekend: { ...d.weekend } };
  const t = (v: unknown, fb: string) => (/^([01]\d|2[0-3]):[0-5]\d$/.test(String(v)) ? String(v) : fb);
  const bm = (v: unknown, fb: number) => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 0 && n <= 240 ? Math.round(n) : fb;
  };
  const wd = (v: unknown, fb: number[]): number[] => {
    if (!Array.isArray(v)) return [...fb];
    const arr = v.map(Number).filter((x) => Number.isInteger(x) && x >= 0 && x <= 6);
    return arr.length > 0 && arr.length <= 6 ? [...new Set(arr)] : [...fb];
  };
  return {
    daily: { code: "DAILY", title: String(input.daily?.title || d.daily.title), start: t(input.daily?.start, d.daily.start), end: t(input.daily?.end, d.daily.end), breakMinutes: bm(input.daily?.breakMinutes, d.daily.breakMinutes) },
    morning: { code: "MORNING", title: String(input.morning?.title || d.morning.title), start: t(input.morning?.start, d.morning.start), end: t(input.morning?.end, d.morning.end), breakMinutes: bm(input.morning?.breakMinutes, d.morning.breakMinutes) },
    evening: { code: "EVENING", title: String(input.evening?.title || d.evening.title), start: t(input.evening?.start, d.evening.start), end: t(input.evening?.end, d.evening.end), breakMinutes: bm(input.evening?.breakMinutes, d.evening.breakMinutes) },
    night: { code: "NIGHT", title: String(input.night?.title || d.night.title), start: t(input.night?.start, d.night.start), end: t(input.night?.end, d.night.end), breakMinutes: bm(input.night?.breakMinutes, d.night.breakMinutes) },
    weekend: { DAILY: wd(input.weekend?.DAILY, d.weekend.DAILY), SHIFT: wd(input.weekend?.SHIFT, d.weekend.SHIFT) },
  };
}

const SCHEDULE_KEY = "work_schedule";
let scheduleCache: { s: WorkSchedule; loadedAt: number } | null = null;

export async function getWorkSchedule(force = false): Promise<WorkSchedule> {
  if (!force && scheduleCache && Date.now() - scheduleCache.loadedAt < 15_000) return scheduleCache.s;
  const row = await db.systemSetting.findUnique({ where: { key: SCHEDULE_KEY } });
  let s = WORK_SCHEDULE_DEFAULTS;
  if (row) {
    try {
      s = normalizeSchedule(JSON.parse(row.value) as Partial<WorkSchedule>);
    } catch { /* پیش‌فرض */ }
  }
  scheduleCache = { s, loadedAt: Date.now() };
  return s;
}

export async function saveWorkSchedule(input: Partial<WorkSchedule>): Promise<WorkSchedule> {
  const current = await getWorkSchedule(true);
  const next = normalizeSchedule({ ...current, ...input, weekend: { ...current.weekend, ...(input.weekend || {}) } });
  await db.systemSetting.upsert({
    where: { key: SCHEDULE_KEY },
    update: { value: JSON.stringify(next) },
    create: { key: SCHEDULE_KEY, value: JSON.stringify(next) },
  });
  scheduleCache = null;
  return next;
}

/** ساعت مؤثر شیفت = (پایان − شروع) − استراحت (شیفت عبوری از نیمه‌شب پشتیبانی می‌شود) */
export function shiftEffectiveHours(sh: ShiftDef): number {
  const toMin = (t: string) => {
    const m = t.match(/^(\d{2}):(\d{2})$/);
    return m ? +m[1] * 60 + +m[2] : 0;
  };
  let dur = toMin(sh.end) - toMin(sh.start);
  if (dur <= 0) dur += 24 * 60; // شیفت شب (عبور از نیمه‌شب)
  return Math.max(0, (dur - sh.breakMinutes) / 60);
}

/** شیفت پیش‌فرض بر اساس نوع اشتغال/الگوی شیفت */
export function shiftForEmployee(employmentType: string, shiftPattern?: string): ShiftDef {
  const s = WORK_SCHEDULE_DEFAULTS;
  if (employmentType === "SHIFT") {
    return shiftPattern === "THREE_SHIFT" ? s.night : s.morning; // پیش‌فرض ثبت تردد: صبح (سه‌شیفت: نمای شب)
  }
  return s.daily;
}

/** روزهای تعطیل هفتگی برای نوع اشتغال (شنبه=۰ … جمعه=۶) */
export function weekendDaysFor(employmentType: string, schedule?: WorkSchedule): number[] {
  const wk = (schedule || WORK_SCHEDULE_DEFAULTS).weekend;
  return employmentType === "SHIFT" ? wk.SHIFT : wk.DAILY;
}

// --------------------------- تقویم و آمار ماه ---------------------------

export interface DayInfo {
  dateJ: string;
  day: number;
  weekday: number; // شنبه=۰ … جمعه=۶
  isThursday: boolean;
  isFriday: boolean;
  isHoliday: boolean;
  holidayTitle: string;
}

export interface MonthStats {
  year: number;
  month: number;
  totalDays: number;
  thursdays: number;
  fridays: number;
  officialHolidays: number; // تعطیلات رسمیِ خارج از پنجشنبه/جمعه
  customHolidays: number;
  holidayList: { dateJ: string; day: number; weekday: number; title: string; kind: string; onWeekend: boolean }[];
  daily: { weekendDays: number; workingDays: number; standardHours: number }; // روزکار: پنجشنبه+جمعه+تعطیلات
  shift: { weekendDays: number; workingDays: number; standardHours: number }; // شیفتی: جمعه+تعطیلات
}

/** نقشه تعطیلات یک ماه: dateJ → رکورد */
export type HolidayMap = Map<string, { title: string; kind: string }>;

export async function getHolidayMap(year: number, month: number): Promise<HolidayMap> {
  const prefix = `${year}/${String(month).padStart(2, "0")}/`;
  const rows = await db.holiday.findMany({ where: { dateJ: { startsWith: prefix } } });
  const map: HolidayMap = new Map();
  for (const r of rows) map.set(r.dateJ, { title: r.title, kind: r.kind });
  return map;
}

/** همه تعطیلات یک سال (برای جدول ۱۲ ماهه) */
export async function getHolidaysOfYear(year: number): Promise<{ id: string; dateJ: string; title: string; kind: string; source: string }[]> {
  const prefix = `${year}/`;
  const rows = await db.holiday.findMany({ where: { dateJ: { startsWith: prefix } }, orderBy: { dateJ: "asc" } });
  return rows.map((r) => ({ id: r.id, dateJ: r.dateJ, title: r.title, kind: r.kind, source: r.source }));
}

/** فهرست روزهای ماه با پرچم پنجشنبه/جمعه/تعطیل */
export function monthDaysInfo(year: number, month: number, holidays: HolidayMap): DayInfo[] {
  const n = daysInJalaliMonth(year, month);
  const out: DayInfo[] = [];
  for (let d = 1; d <= n; d++) {
    const dateJ = formatJStr(year, month, d);
    const wd = jalaliWeekdayIndex(year, month, d);
    const h = holidays.get(dateJ);
    out.push({
      dateJ,
      day: d,
      weekday: wd,
      isThursday: wd === WEEKDAY.THU,
      isFriday: wd === WEEKDAY.FRI,
      isHoliday: !!h,
      holidayTitle: h?.title || "",
    });
  }
  return out;
}

/** آمار ماه + ساعت استاندارد دوره به تفکیک نوع اشتغال */
export function computeMonthStats(year: number, month: number, days: DayInfo[], schedule: WorkSchedule, dailyHours?: number, shiftHours?: number): MonthStats {
  const dailyEff = dailyHours ?? shiftEffectiveHours(schedule.daily);
  const shiftEff = shiftHours ?? shiftEffectiveHours(schedule.morning); // هر دو شیفت ۸ ساعته
  const dailyWeekend = new Set(schedule.weekend.DAILY);
  const shiftWeekend = new Set(schedule.weekend.SHIFT);

  const holidayList: MonthStats["holidayList"] = [];
  let dailyWork = 0;
  let shiftWork = 0;
  let dailyWeekendCount = 0;
  let shiftWeekendCount = 0;
  for (const d of days) {
    const dailyWk = dailyWeekend.has(d.weekday);
    const shiftWk = shiftWeekend.has(d.weekday);
    if (dailyWk) dailyWeekendCount += 1;
    if (shiftWk) shiftWeekendCount += 1;
    const isDailyOff = dailyWk || d.isHoliday;
    const isShiftOff = shiftWk || d.isHoliday;
    if (!isDailyOff) dailyWork += 1;
    if (!isShiftOff) shiftWork += 1;
    if (d.isHoliday) {
      holidayList.push({
        dateJ: d.dateJ,
        day: d.day,
        weekday: d.weekday,
        title: d.holidayTitle,
        kind: "OFFICIAL",
        onWeekend: dailyWk || shiftWk,
      });
    }
  }

  const r2 = (v: number) => Math.round(v * 100) / 100;
  return {
    year,
    month,
    totalDays: days.length,
    thursdays: days.filter((d) => d.isThursday).length,
    fridays: days.filter((d) => d.isFriday).length,
    officialHolidays: holidayList.filter((h) => !h.onWeekend).length,
    customHolidays: 0,
    holidayList,
    daily: {
      weekendDays: dailyWeekendCount,
      workingDays: dailyWork,
      standardHours: r2(dailyWork * dailyEff),
    },
    shift: {
      weekendDays: shiftWeekendCount,
      workingDays: shiftWork,
      standardHours: r2(shiftWork * shiftEff),
    },
  };
}

/** عنوان روز هفته فارسی */
export function weekdayName(wd: number): string {
  return JALALI_WEEKDAYS[wd] || "";
}

// --------------------------- دریافت تعطیلات از وب‌سرویس ---------------------------

/**
 * دریافت تعطیلات از وب‌سرویس خارجی (سمت سرور)
 * قالب پاسخ مورد انتظار: آرایه JSON از { dateJ: "1405/01/01", title: "…" }
 * (همچنین date jalali/description پشتیبانی می‌شود)
 */
export async function fetchHolidaysFromWeb(url: string, timeoutMs = 15000): Promise<{ ok: true; holidays: HolidaySeed[]; raw: unknown } | { ok: false; error: string }> {
  let raw: unknown;
  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    const res = await fetch(url, { signal: ctrl.signal, headers: { Accept: "application/json" } });
    clearTimeout(timer);
    if (!res.ok) return { ok: false, error: `پاسخ وب‌سرویس: ${res.status}` };
    raw = await res.json();
  } catch (e) {
    return { ok: false, error: `اتصال به وب‌سرویس ناموفق بود (${e instanceof Error ? e.message : "خطای نامشخص"})` };
  }
  const arr = Array.isArray(raw)
    ? raw
    : Array.isArray((raw as { holidays?: unknown[] })?.holidays)
      ? (raw as { holidays: unknown[] }).holidays
      : Array.isArray((raw as { data?: unknown[] })?.data)
        ? (raw as { data: unknown[] }).data
        : null;
  if (!arr) return { ok: false, error: "قالب پاسخ وب‌سرویس شناسایی نشد (آرایه JSON لازم است)." };
  const holidays: HolidaySeed[] = [];
  for (const item of arr) {
    const o = (item || {}) as Record<string, unknown>;
    const dateJ = String(o.dateJ || o.jalali || o.date || "");
    const title = String(o.title || o.name || o.description || "تعطیل رسمی").trim();
    const p = parseJalali(dateJ);
    if (!p || !title) continue;
    holidays.push({ dateJ: formatJStr(p.jy, p.jm, p.jd), title: title.slice(0, 160) });
  }
  if (holidays.length === 0) return { ok: false, error: "هیچ تعطیل معتبری از وب‌سرویس دریافت نشد." };
  return { ok: true, holidays, raw };
}

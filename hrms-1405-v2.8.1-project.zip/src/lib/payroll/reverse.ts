// ============================================================
// موتور محاسبه معکوس حقوق ۱۴۰۵
// ورودی: خالص پرداختی هدف → خروجی: حقوق پایه و تمام اجزا
//
// الگوریتم: روش دو-بخشی (Bisection) روی حقوق پایه
// توجیه ریاضی: خالص(B) اکیداً صعودی و تکه‌ای-خطی است چون:
//   net(B) = gross(B) − 7٪×insurable(B) − Tax(0.93B + ثابت‌ها)
// شیب تکه‌ها بین 0.651 و 0.93 است ⇒ جواب یکتا ⇒ دودویی همگرا می‌شود
// دقت: ۱ ریال (با ~۴۰ تکرار روی بازه ۱۰^۱۱ ریال)
// ============================================================
import { computePaysheet, type LegalParams, type PayrollContext, type PaysheetResult } from "./engine";

export interface ReverseIteration {
  step: number;
  lower: number; // کران پایین حقوق پایه
  upper: number; // کران بالا حقوق پایه
  mid: number; // نقطه آزمایش
  netAtMid: number; // خالص محاسبه‌شده
  error: number; // اختلاف با هدف (netAtMid − target)
}

export interface ReverseResult {
  ok: boolean;
  targetNet: number;
  // راه‌حل
  baseSalary: number;
  paysheet: PaysheetResult;
  achievedNet: number;
  residual: number; // اختلاف باقی‌مانده (ریال)
  iterations: ReverseIteration[];
  iterationsCount: number;
  warnings: string[];
  notes: string[];
  // باند پیشنهادی طبقه (در صورت ارسال)
  gradeMin?: number;
  gradeMax?: number;
}

export interface ReverseOptions {
  targetNet: number; // خالص هدف — ریال
  context: PayrollContext; // مزایای ثابت (فرزند، مسکن، بن، سنوات، جذب...)
  params: LegalParams;
  gradeMin?: number;
  gradeMax?: number;
  rounding?: number | null; // گرد کردن حقوق پایه (مثلاً 100000 ریال) — پیش‌فرض بدون گرد کردن
  maxIterations?: number;
  includeOvertimeInSearch?: boolean; // اضافه‌کاری در حل معکوس لحاظ شود؟ (پیش‌فرض: خیر — ساعت صفر)
}

/** خالص در پایه B (با صفر کردن اضافه‌کاری چون متغیر حل نیست) */
function netAt(base: number, ctx: PayrollContext, params: LegalParams): number {
  const c: PayrollContext = { ...ctx, overtimeHours: 0 };
  return computePaysheet(base, c, params).netPay;
}

/**
 * حل معکوس: یافتن حقوق پایه به‌طوری که خالص پرداختی دقیقاً برابر هدف باشد.
 */
export function computeReversePaysheet(opts: ReverseOptions): ReverseResult {
  const { targetNet, context, params } = opts;
  const rounding = opts.rounding && opts.rounding > 0 ? opts.rounding : null;
  const maxIter = opts.maxIterations ?? 200;
  const warnings: string[] = [];
  const notes: string[] = [];

  // اگر اضافه‌کاری در context باشد، هشدار بده (در حل لحاظ نمی‌شود)
  if (context.overtimeHours > 0) {
    notes.push("اضافه‌کاری در معادله معکوس لحاظ نشد (۰ ساعت). خالص هدف باید از مسیر حقوق پایه تأمین شود.");
  }
  const ctx0: PayrollContext = { ...context, overtimeHours: 0 };

  const net0 = netAt(0, ctx0, params); // خالص در پایه صفر (فقط مزایای ثابت)
  if (targetNet < net0) {
    // هدف کمتر از حداقل قابل‌تحقق
    warnings.push(`حداقل خالص قابل‌تحقق با این مزایای ثابت ${net0.toLocaleString("en-US")} ریال است؛ هدف کمتر از آن است.`);
    const sheet = computePaysheet(0, ctx0, params);
    return {
      ok: false,
      targetNet,
      baseSalary: 0,
      paysheet: sheet,
      achievedNet: sheet.netPay,
      residual: sheet.netPay - targetNet,
      iterations: [],
      iterationsCount: 0,
      warnings,
      notes,
      gradeMin: opts.gradeMin,
      gradeMax: opts.gradeMax,
    };
  }

  // ----- یافتن کران بالای مناسب -----
  let lower = 0;
  let upper = Math.max(params.minWage * 12, targetNet * 4, 1_000_000_000);
  let guard = 0;
  while (netAt(upper, ctx0, params) < targetNet && guard < 60) {
    upper *= 2;
    guard += 1;
  }

  // ----- دو-بخشی -----
  const iterations: ReverseIteration[] = [];
  let mid = 0;
  let midNet = 0;
  for (let i = 0; i < maxIter; i++) {
    mid = Math.round((lower + upper) / 2);
    midNet = netAt(mid, ctx0, params);
    const error = midNet - targetNet;
    iterations.push({ step: i + 1, lower, upper, mid, netAtMid: midNet, error });
    if (error === 0) break;
    if (error < 0) lower = mid;
    else upper = mid;
    if (upper - lower <= 1) {
      // دقت ۱ ریال: انتخاب نزدیک‌ترین
      const netLower = netAt(lower, ctx0, params);
      const netUpper = netAt(upper, ctx0, params);
      mid = Math.abs(netLower - targetNet) <= Math.abs(netUpper - targetNet) ? lower : upper;
      midNet = netAt(mid, ctx0, params);
      iterations.push({ step: iterations.length + 1, lower, upper, mid, netAtMid: midNet, error: midNet - targetNet });
      break;
    }
  }

  // ----- گرد کردن اختیاری -----
  let finalBase = mid;
  if (rounding && finalBase > 0) {
    const rounded = Math.round(finalBase / rounding) * rounding;
    finalBase = Math.max(0, rounded);
    notes.push(`حقوق پایه به مضرب ${rounding.toLocaleString("en-US")} ریال گرد شد؛ خالص نهایی ممکن است چند ریال با هدف اختلاف داشته باشد.`);
  }

  // محاسبه نهایی با اضافه‌کاری اولیه کاربر (برای نمایش واقعی)
  const finalCtx: PayrollContext = { ...context, overtimeHours: 0 };
  const paysheet = computePaysheet(finalBase, finalCtx, params);

  // هشدارهای طبقه
  if (opts.gradeMin !== undefined && finalBase < opts.gradeMin) {
    warnings.push(`حقوق پایه معکوس‌شده کمتر از حداقل طبقه (${opts.gradeMin.toLocaleString("en-US")} ریال) است.`);
  }
  if (opts.gradeMax !== undefined && finalBase > opts.gradeMax) {
    warnings.push(`حقوق پایه معکوس‌شده بیشتر از سقف طبقه (${opts.gradeMax.toLocaleString("en-US")} ریال) است.`);
  }
  if (finalBase < params.minWage) {
    warnings.push("حقوق پایه کمتر از حداقل دستمزد ۱۴۰۵ است؛ در عمل باید به حداقل تعدیل شود.");
  }

  const residual = paysheet.netPay - targetNet;
  if (Math.abs(residual) > 0 && !rounding) {
    notes.push(`اختلاف باقی‌مانده ${residual.toLocaleString("en-US")} ریال است (ناشی از گرد کردن ریالی بیمه/مالیات).`);
  }

  return {
    ok: true,
    targetNet,
    baseSalary: finalBase,
    paysheet,
    achievedNet: paysheet.netPay,
    residual,
    iterations,
    iterationsCount: iterations.length,
    warnings,
    notes,
    gradeMin: opts.gradeMin,
    gradeMax: opts.gradeMax,
  };
}

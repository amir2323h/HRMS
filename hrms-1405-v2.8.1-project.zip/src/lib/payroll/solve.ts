// ============================================================
// حل معکوس حقوق پایه با زمینه کامل کارمند
// (شامل اضافه‌کاری پیش‌فرض، شیفت، فرزند، سنوات و ...)
//
// تفاوت با payroll/reverse.ts: آن موتور برای «فیش معکوس» است و
// اضافه‌کاری را در معادله صفر می‌کند؛ این حل‌کننده برای
// «مدیریت تغییرات حقوق» است و خالص هدف را با همان زمینه
// نمایشی کارمند (اعمال اضافه‌کاری پیش‌فرض) تأمین می‌کند تا
// خالص جاری فرم و خالص پس از اعمال، همیشه هم‌خوان باشد.
//
// الگوریتم: دو-بخشی روی حقوق پایه — خالص(B) اکیداً صعودی و
// تکه‌ای-خطی است ⇒ جواب یکتا؛ دقت ۱ ریال
// ============================================================
import { computePaysheet, type LegalParams, type PayrollContext } from "./engine";

export interface SolveResult {
  ok: boolean;
  baseSalary: number;
  achievedNet: number;
  residual: number; // achievedNet − targetNet (ریال)
  minAchievableNet: number; // خالص در پایه صفر (فقط مزایای ثابت)
  iterations: number;
}

/** خالص در پایه B با زمینه کامل */
function netAt(base: number, ctx: PayrollContext, params: LegalParams): number {
  return computePaysheet(base, ctx, params).netPay;
}

/**
 * یافتن حقوق پایه به‌طوری که خالص پرداختی (با زمینه کامل کارمند)
 * دقیقاً برابر هدف باشد — دقت ۱ ریال.
 */
export function solveBaseForNet(
  targetNet: number,
  ctx: PayrollContext,
  params: LegalParams,
  maxIterations = 200
): SolveResult {
  const target = Math.round(targetNet);
  const net0 = netAt(0, ctx, params);

  if (target < net0) {
    // هدف کمتر از حداقل قابل‌تحقق (مزایای ثابت حتی با پایه صفر)
    return { ok: false, baseSalary: 0, achievedNet: net0, residual: net0 - target, minAchievableNet: net0, iterations: 0 };
  }
  // پایه صفر خودش جواب است (خالص هدف = خالص مزایای ثابت)
  if (target === net0) {
    return { ok: true, baseSalary: 0, achievedNet: net0, residual: 0, minAchievableNet: net0, iterations: 0 };
  }

  // کران بالا: رشد نمایی تا پوشش هدف
  let lower = 0;
  let upper = Math.max(params.minWage * 12, target * 4, 1_000_000_000);
  let guard = 0;
  while (netAt(upper, ctx, params) < target && guard < 60) {
    upper *= 2;
    guard += 1;
  }

  // دو-بخشی — دقت ۱ ریال
  let mid = 0;
  let midNet = 0;
  let iterations = 0;
  for (let i = 0; i < maxIterations; i++) {
    iterations = i + 1;
    mid = Math.round((lower + upper) / 2);
    midNet = netAt(mid, ctx, params);
    if (midNet === target) break;
    if (midNet < target) lower = mid;
    else upper = mid;
    if (upper - lower <= 1) {
      const netLower = netAt(lower, ctx, params);
      const netUpper = netAt(upper, ctx, params);
      mid = Math.abs(netLower - target) <= Math.abs(netUpper - target) ? lower : upper;
      midNet = netAt(mid, ctx, params);
      break;
    }
  }

  return {
    ok: true,
    baseSalary: Math.max(0, mid),
    achievedNet: midNet,
    residual: midNet - target,
    minAchievableNet: net0,
    iterations,
  };
}

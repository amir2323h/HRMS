// ============================================================
// بک‌فیل نسخه ۵ — کاربر کارشناس اداری (edari) + پاک‌سازی تست‌ها
// اجرا:  DATABASE_URL=file:/home/z/my-project/db/custom.db bun scripts/backfill-v5.ts
// idempotent — اجرای مجدد بی‌ضرر است
// ============================================================
import { PrismaClient } from "@prisma/client";
import { randomBytes, scryptSync } from "crypto";

const db = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

async function main() {
  // ۱. اتصال roleId نقش ADMIN_EXPERT (نقش در backfill-v4 ساخته شده)
  const role = await db.role.findUnique({ where: { key: "ADMIN_EXPERT" } });
  if (!role) {
    console.error("نقش ADMIN_EXPERT یافت نشد — ابتدا backfill-v4 اجرا شود.");
    process.exit(1);
  }

  // ۲. کاربر نمونه کارشناس اداری
  const existing = await db.user.findUnique({ where: { username: "edari" } });
  if (!existing) {
    await db.user.create({
      data: {
        username: "edari",
        passwordHash: hashPassword("edari123"),
        fullName: "مریم اداری",
        role: "ADMIN_EXPERT",
        roleId: role.id,
      },
    });
    console.log("کاربر edari (کارشناس اداری) ساخته شد — رمز: edari123");
  } else {
    await db.user.update({ where: { id: existing.id }, data: { roleId: role.id, role: "ADMIN_EXPERT" } });
    console.log("کاربر edari موجود بود — roleId به ADMIN_EXPERT متصل شد");
  }

  // ۳. پاک‌سازی نامه‌های تست ساختگی (عنوان‌های تستی)
  const del = await db.letterRequest.deleteMany({ where: { source: "MANUAL", title: { in: ["HR دستی", "تست HR", "نامه دوم تست"] } } });
  console.log("حذف نامه‌های دستی تستی:", del.count);

  // ۴. تنظیمات نامه — پیش‌شماره مطابق الگو + امضاکننده پیش‌فرض خالی (کاربر خودش تنظیم می‌کند)
  const cur = await db.systemSetting.findUnique({ where: { key: "letters" } });
  const next = { numberingPrefix: "ZDX", signerName: "", signerTitle: "مدیر عامل" };
  await db.systemSetting.upsert({
    where: { key: "letters" },
    update: { value: JSON.stringify({ ...(cur ? JSON.parse(cur.value) : {}), ...next }) },
    create: { key: "letters", value: JSON.stringify(next) },
  });
  console.log("تنظیمات نامه: پیش‌شماره ZDX — امضاکننده پیش‌فرض خالی (مدیر عامل)");

  await db.$disconnect();
  console.log("بک‌فیل نسخه ۵ کامل شد.");
}
main();

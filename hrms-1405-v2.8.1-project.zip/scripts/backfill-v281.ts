// ============================================================
// Backfill v2.8.1 — پشتیبان‌گیری و بازیابی داده‌های پنل
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۸.۱
//  ۲) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v281.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_281 = {
  version: "2.8.1",
  title: "تازه‌های نسخه ۲.۸.۱",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    { tag: "NEW", title: "پشتیبان‌گیری و بازیابی داده‌ها", desc: "از «تنظیمات ← پشتیبان‌گیری» می‌توانید با یک کلیک از تمام داده‌های پنل (کارکنان، فیش‌ها، قراردادها، نامه‌ها و تنظیمات) اسنپ‌شات سالم بگیرید — بدون توقف سرویس؛ فایل‌ها قابل دانلود، انتقال به سرور دیگر و بازیابی هستند و حداکثر ۱۰ نسخه نگه داشته می‌شود." },
    { tag: "NEW", title: "بازیابی امن یک‌کلیکی", desc: "بازیابی از فهرست پشتیبان‌ها یا فایل خارجی؛ پیش از جایگزینی، به‌صورت خودکار از وضعیت فعلی پشتیبان ایمنی گرفته می‌شود، فایل اعتبارسنجی می‌شود (ساختار + وجود مدیر کل) و سرویس بدون ری‌استارت به داده‌های بازیابی‌شده سوئیچ می‌کند." },
    { tag: "SEC", title: "پشتیبان خودکار پیش از به‌روزرسانی", desc: "پیش از هر به‌روزرسانی سامانه (از پنل یا خط فرمان)، به‌صورت خودکار از داده‌ها پشتیبان گرفته می‌شود تا در صورت بروز مشکل، بازگشت به وضعیت قبل همیشه ممکن باشد." },
    { tag: "SEC", title: "دسترسی انحصاری مدیر کل", desc: "تب پشتیبان‌گیری، دانلود و بازیابی داده‌ها فقط برای «مدیر کل» در دسترس است و همه عملیات‌ها در لاگ حسابرسی ثبت می‌شوند." },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ۱) اطلاعیه نسخه
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_281) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۸.۱» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.8.1") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (["2.8.0", "2.7.3", "2.7.2", "2.7.1", "2.7.0"].includes(String(cfg.version || ""))) {
      // ارتقای اطلاعیه پیش‌فرض → ۲.۸.۱ (پاپ‌آپ یک‌باره برای کاربران)
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_281) } });
      console.log(`✓ اطلاعیه ${cfg.version} به «تازه‌های نسخه ۲.۸.۱» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ۲) کش چک آپدیت بی‌اعتبار است
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

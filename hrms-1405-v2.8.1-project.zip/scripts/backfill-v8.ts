// ============================================================
// بک‌فیل نسخه ۸ — قالب‌نامه‌های خودکار (معرفی به بانک، گواهی اشتغال)
// + مجوزهای حضور و غیب برای نقش‌های سیستمی
// اجرا:  DATABASE_URL=file:/home/z/my-project/db/custom.db bun scripts/backfill-v8.ts
// idempotent — اجرای مجدد بی‌ضرر است (upsert با کد قالب)
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

// قالب‌های جدید — داده‌های مورد نیاز از کارمند موقع درخواست گرفته می‌شود
// و پس از تأیید، نامه به‌صورت خودکار رندر و در پرتال قابل دانلود است.
const NEW_TEMPLATES = [
  {
    code: "LT-010",
    title: "گواهی اشتغال به کار",
    category: "HR",
    approverRole: "HR_MANAGER",
    description: "گواهی رسمی اشتغال با مشخصات کامل شغلی — برای ارائه به بانک/سازمان‌ها",
    fields: [
      { key: "purpose", label: "مرجع ارائه گواهی", type: "text", required: true, placeholder: "مثلاً: بانک ملی — شعبه مرکزی" },
    ],
    bodyTemplate: `مدیریت محترم {{field_purpose}}

با احترام، به استحضار می‌رساند جناب/خانم {{employee_name}} به کد پرسنلی {{employee_personnel_code}} و کد ملی {{employee_national_id}}، از تاریخ {{employee_hire_date}} در شرکت {{company_name}} در سمت «{{employee_job_title}}» مشغول به کار می‌باشد.
{{employee_grade}}
این گواهی جهت ارائه به {{field_purpose}} صادر شده و تا تاریخ {{today_date}} اعتبار دارد.

احتراماً
{{company_name}}
شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`,
  },
  {
    code: "LT-011",
    title: "معرفی‌نامه به بانک",
    category: "FINANCE",
    approverRole: "HR_MANAGER",
    description: "معرفی‌نامه رسمی برای افتتاح حساب حقوقی / دریافت تسهیلات — حقوق پایه درج می‌شود",
    fields: [
      { key: "bank_name", label: "نام بانک", type: "text", required: true, placeholder: "مثلاً: بانک ملت" },
      { key: "branch", label: "شعبه", type: "text", required: false, placeholder: "مثلاً: شعبه مرکزی تهران" },
      { key: "request_type", label: "نوع درخواست", type: "select", options: ["افتتاح حساب حقوقی", "دریافت تسهیلات", "واریز حقوق به حساب موجود"], required: true },
    ],
    bodyTemplate: `مدیریت محترم {{field_bank_name}}{{field_branch}}

با احترام، اینجانب {{employee_name}} به کد پرسنلی {{employee_personnel_code}}، همکار شرکت {{company_name}} در سمت «{{employee_job_title}}» با حقوق ماهانه {{base_salary_toman}} تومان، درخواست {{field_request_type}} در بانک محترم شما را دارم.

خواهشمند است دستور فرمایید نسبت به بررسی و انجام اقدامات لازم مبادرت ورزید. کد ملی: {{employee_national_id}} — تاریخ استخدام: {{employee_hire_date}}

با تشکر
{{company_name}}
شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`,
  },
  {
    code: "LT-012",
    title: "معرفی‌نامه به سازمان/اداره",
    category: "ADMIN",
    approverRole: "HR_MANAGER",
    description: "معرفی‌نامه رسمی کارمند برای پیگیری اداری/امور رسمی بیرون از سازمان",
    fields: [
      { key: "organization", label: "نام سازمان/اداره", type: "text", required: true },
      { key: "subject", label: "موضوع مأموریت", type: "text", required: true, placeholder: "مثلاً: پیگیری پرونده بیمه" },
      { key: "mission_date", label: "تاریخ مأموریت", type: "date", required: true },
    ],
    bodyTemplate: `مدیریت محترم {{field_organization}}

جناب/خانم {{employee_name}} به کد پرسنلی {{employee_personnel_code}} و سمت «{{employee_job_title}}» از کارکنان شرکت {{company_name}}، جهت {{field_subject}} در تاریخ {{field_mission_date}} به آن اداره معرفی می‌گردد.

خواهشمند است در حد صلاحیت، لازم‌الاجرایی نسبت مباحث ایشان اقدام فرمایید.

احتراماً
{{company_name}}
شماره نامه: {{letter_number}} — تاریخ: {{today_date}}`,
  },
] as const;

// مجوزهای حضور و غیب — به نقش‌های مرتبط اضافه می‌شود
const ROLE_ATTENDANCE_PERMS: Record<string, string[]> = {
  HR_MANAGER: ["attendance:view", "attendance:manage"],
  PAYROLL_OFFICER: ["attendance:view", "attendance:manage"],
  DEPT_MANAGER: ["attendance:view"],
};

async function main() {
  // ---------- ۱. قالب‌نامه‌های جدید ----------
  for (const t of NEW_TEMPLATES) {
    await db.letterTemplate.upsert({
      where: { code: t.code },
      update: {
        title: t.title,
        category: t.category,
        description: t.description,
        fieldsJson: JSON.stringify(t.fields),
        bodyTemplate: t.bodyTemplate,
        approverRole: t.approverRole,
      },
      create: {
        code: t.code,
        title: t.title,
        category: t.category,
        description: t.description,
        fieldsJson: JSON.stringify(t.fields),
        bodyTemplate: t.bodyTemplate,
        approverRole: t.approverRole,
        isActive: true,
        createdBy: "system",
      },
    });
    console.log(`قالب ${t.code} — «${t.title}» ✓`);
  }

  // ---------- ۲. مجوزهای حضور و غیب نقش‌های سیستمی ----------
  for (const [roleKey, perms] of Object.entries(ROLE_ATTENDANCE_PERMS)) {
    const role = await db.role.findUnique({ where: { key: roleKey } });
    if (!role) continue;
    let current: string[] = [];
    try {
      current = JSON.parse(role.permissions || "[]");
    } catch {
      current = [];
    }
    const merged = [...new Set([...current, ...perms])];
    if (merged.length !== current.length) {
      await db.role.update({ where: { id: role.id }, data: { permissions: JSON.stringify(merged) } });
      console.log(`نقش ${roleKey}: مجوزهای حضور و غیب اضافه شد ✓`);
    }
  }

  console.log("backfill-v8 کامل شد.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

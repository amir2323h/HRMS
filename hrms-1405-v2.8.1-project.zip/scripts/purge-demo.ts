// ============================================================
// پاک‌سازی داده نمونه — خط فرمان
//   اجرا:  bun scripts/purge-demo.ts           (حالت استاندارد)
//          npm run purge-demo
//          npx --yes tsx scripts/purge-demo.ts
//   پرچم‌ها:
//     --full        حالت کامل (+ دپارتمان‌ها/مشاغل/رفاهیات/قالب‌ها/کاربران غیر ادمین/لاگ)
//     --keep-audit  در حالت کامل، لاگ حسابرسی حفظ شود
//     --yes / -y    بدون تأیید تعاملی (برای اتوماسیون)
//   همیشه حفظ می‌شود: تنظیمات سامانه، نقش‌ها، طبقه ۷ سطحی،
//   پله‌های مالیاتی و حداقل یک کاربر مدیر کل
// ============================================================
import { readFileSync, existsSync } from "fs";
import { createInterface } from "readline";
import { PrismaClient } from "@prisma/client";

// ---------- بارگذاری .env اگر DATABASE_URL تنظیم نشده ----------
if (!process.env.DATABASE_URL && existsSync(".env")) {
  for (const line of readFileSync(".env", "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(.*)\s*$/);
    if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}
if (!process.env.DATABASE_URL) {
  console.error("✗ DATABASE_URL تنظیم نشده است — فایل .env را در ریشه پروژه بگذارید یا متغیر را صادر کنید.");
  process.exit(1);
}

const args = process.argv.slice(2);
const FULL = args.includes("--full");
const KEEP_AUDIT = args.includes("--keep-audit");
const YES = args.includes("--yes") || args.includes("-y");

const db = new PrismaClient();

function fa(n: number | undefined | null): string {
  return (n ?? 0).toLocaleString("fa-IR");
}

async function confirm(): Promise<boolean> {
  if (YES) return true;
  if (!process.stdin.isTTY) {
    console.error("✗ در محیط غیرتعاملی، پرچم --yes الزامی است.");
    return false;
  }
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  const answer = await new Promise<string>((resolve) =>
    rl.question("برای ادامه عبارت yes را تایپ کنید (هر چیز دیگر = لغو): ", resolve)
  );
  rl.close();
  return answer.trim().toLowerCase() === "yes";
}

async function main() {
  const [employees, payslips, periods, contracts, letters, leaves, advances, bonus] = await Promise.all([
    db.employee.count(),
    db.payslip.count(),
    db.payrollPeriod.count(),
    db.contract.count(),
    db.letterRequest.count(),
    db.leaveRequest.count(),
    db.advanceRequest.count(),
    db.bonusScheme.count(),
  ]);
  // موجودیت‌های اضافی حالت full — برای تشخیص «تمیز بودن» و نمایش دقیق
  const fullExtras = FULL
    ? {
        departments: await db.department.count(),
        jobTitles: await db.jobTitle.count(),
        welfareItems: await db.welfareItem.count(),
        letterTemplates: await db.letterTemplate.count(),
        contractTemplates: await db.contractTemplate.count(),
        nonAdminUsers: await db.user.count({ where: { role: { not: "SUPER_ADMIN" } } }),
        auditLogs: KEEP_AUDIT ? 0 : await db.auditLog.count(),
      }
    : { departments: 0, jobTitles: 0, welfareItems: 0, letterTemplates: 0, contractTemplates: 0, nonAdminUsers: 0, auditLogs: 0 };

  console.log(`
╔══════════════════════════════════════════════════════════════╗
║              پاک‌سازی داده نمونه — سامانه منابع انسانی        ║
╚══════════════════════════════════════════════════════════════╝
  حالت: ${FULL ? "کامل (FULL)" : "استاندارد (demo)"}
  دیتابیس: ${process.env.DATABASE_URL}

  داده‌هایی که حذف خواهند شد:
    • کارکنان: ${fa(employees)} (به‌همراه بستگان بیمه، اسناد، رفاهیات، اتصال دپارتمان)
    • فیش‌های حقوقی: ${fa(payslips)} در ${fa(periods)} دوره
    • قراردادهای صادرشده: ${fa(contracts)}
    • درخواست‌نامه‌ها: ${fa(letters)}
    • درخواست‌های مساعده/مرخصی: ${fa(leaves + advances)}
    • طرح‌های پاداش: ${fa(bonus)}
${FULL ? `    • دپارتمان‌ها (${fa(fullExtras.departments)})، عناوین شغلی (${fa(fullExtras.jobTitles)})، آیتم‌های رفاهی (${fa(fullExtras.welfareItems)})، قالب نامه (${fa(fullExtras.letterTemplates)})/قالب قرارداد (${fa(fullExtras.contractTemplates)})
    • کاربران غیر مدیر کل: ${fa(fullExtras.nonAdminUsers)} (قدیمی‌ترین مدیر کل حفظ می‌شود)${KEEP_AUDIT ? "" : `\n    • کل لاگ حسابرسی: ${fa(fullExtras.auditLogs)} رکورد (با --keep-audit حفظ می‌شود)`}` : `    (ساختار سازمانی، قالب‌ها، کاربران و لاگ‌ها حفظ می‌شوند — برای حذف آنها: --full)`}

  همیشه حفظ می‌شود: تنظیمات سامانه (پارامترهای قانونی/برندینگ/پاداش)،
  نقش‌ها و مجوزها، طبقه‌بندی ۷ سطحی مشاغل، پله‌های مالیاتی ۱۴۰۵
`);

  const demoEmpty = employees === 0 && payslips === 0 && letters === 0 && contracts === 0 && bonus === 0 && leaves + advances === 0;
  const fullEmpty =
    fullExtras.departments === 0 && fullExtras.jobTitles === 0 && fullExtras.welfareItems === 0 &&
    fullExtras.letterTemplates === 0 && fullExtras.contractTemplates === 0 &&
    fullExtras.nonAdminUsers === 0 && fullExtras.auditLogs === 0;
  if (demoEmpty && (!FULL || fullEmpty)) {
    console.log("✓ داده نمونه‌ای برای حذف وجود ندارد — دیتابیس از قبل تمیز است.");
    return;
  }

  const ok = await confirm();
  if (!ok) {
    console.log("لغو شد — هیچ داده‌ای حذف نشد.");
    return;
  }

  const { purgeDemoData } = await import("../src/lib/purge");
  const counts = await purgeDemoData({ full: FULL, keepAudit: KEEP_AUDIT, db });

  // ردپای عملیات در لاگ حسابرسی (حتی اگر لاگ‌ها پاک شده باشند)
  await db.auditLog.create({
    data: {
      userId: null,
      userName: "system (CLI)",
      action: "DELETE",
      entity: "SYSTEM",
      entityId: "demo-data",
      summary: `پاک‌سازی داده نمونه از خط فرمان (${counts.mode}) — ${counts.employees} کارمند، ${counts.payslips} فیش، ${counts.letters} نامه، ${counts.contracts} قرارداد`,
      before: null,
      after: JSON.stringify({ mode: counts.mode, at: counts.at }),
    },
  });

  console.log(`
✓ پاک‌سازی کامل شد (${counts.mode})
    کارکنان: ${fa(counts.employees)} | فیش: ${fa(counts.payslips)} | دوره: ${fa(counts.periods)}
    قرارداد: ${fa(counts.contracts)} | نامه: ${fa(counts.letters)} | درخواست: ${fa(counts.leaveRequests + counts.advanceRequests)}
    پاداش: ${fa(counts.bonusSchemes)} طرح / ${fa(counts.bonusLines)} ردیف${FULL ? ` | کاربران حذف‌شده: ${fa(counts.users)}` : ""}
  ردپای عملیات در لاگ حسابرسی ثبت شد.`);
}

main()
  .catch((e) => {
    console.error("✗ خطا در پاک‌سازی:", e instanceof Error ? e.message : e);
    process.exitCode = 1;
  })
  .finally(() => db.$disconnect());

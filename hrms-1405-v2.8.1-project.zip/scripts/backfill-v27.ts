// ============================================================
// Backfill v2.7.0 — اجرای خودکار نصب‌کننده پس از db push
//  ۱) اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۷.۰» (فقط اگر وجود نداشته باشد — idempotent)
//     کاربران فعلی changelogSeen قدیمی/خالی دارند → پاپ‌آپ پس از ارتقا یک بار نمایش داده می‌شود
// ۲) پاکسازی کش وضعیت آپدیت (برای چک تازه پس از ارتقا)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v27.ts
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_270 = {
  version: "2.7.0",
  title: "تازه‌های نسخه ۲.۷.۰",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    { tag: "NEW", title: "تفکیک حقوق هر سطح", desc: "در «طبقه‌بندی مشاغل» تعیین کنید چند درصد حقوق ماهانه هر سطح به حقوق پایه، حق مسولیت و شایستگی برود — اضافه‌کاری، مأموریت و فوق‌العاده‌ها فقط از حقوق پایه محاسبه می‌شوند." },
    { tag: "NEW", title: "امضای نامه در کارتابل امضاکننده", desc: "امضاکنندگان مجاز را از فهرست نفرات (کاربران) انتخاب کنید؛ نامه دستی پس از مراحل تأیید به کارتابل خود امضاکننده می‌رود و خودش امضای دیجیتال را صادر می‌کند." },
    { tag: "NEW", title: "پاپ‌آپ «تازه‌های نسخه»", desc: "همین پنجره! آخرین تغییرات محصول را از «تنظیمات ← اطلاعیه نسخه» مدیریت کنید و تعیین کنید کدام نقش‌ها/کاربران آن را ببینند." },
    { tag: "IMPROVED", title: "دکمه آپدیت در پنل", desc: "نشان وضعیت نسخه در نوار بالا — بررسی خودکار نسخه جدید از گیت‌هاب هر ۲ روز + ارتقای یک‌کلیکی با پایش لاگ زنده." },
    { tag: "IMPROVED", title: "نسخه نرم‌افزار در فوتر و صفحه ورود", desc: "نسخه نصب‌شده همیشه جلوی چشم است." },
  ],
};

async function main() {
  // اطلاعیه پیش‌فرض — فقط وقتی هنوز تنظیمی وجود ندارد (دست تنظیمات مدیر را نمی‌بندد)
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_270) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۷.۰» ساخته شد");
  } else {
    console.log("• اطلاعیه تغییرات موجود است — دست نخورد");
  }

  // کش چک آپدیت قبلی بی‌اعتبار است (نسخه جدید نصب شده) — پاک تا چک تازه انجام شود
  await db.systemSetting.deleteMany({ where: { key: "update_check" } });
  await db.systemSetting.deleteMany({ where: { key: "update_state" } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

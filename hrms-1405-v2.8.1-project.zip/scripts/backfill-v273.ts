// ============================================================
// Backfill v2.7.3 — اجرای خودکار نصب‌کننده پس از db push
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۷.۳ (دو رفع اشکال):
//     • اگر اطلاعیه‌ای نیست → نسخه ۲.۷.۳ ساخته می‌شود (نصب تمیز)
//     • اگر اطلاعیه = پیش‌فرض دست‌نخورده ۲.۷.۲ → جایگزین با ۲.۷.۳
//     • اگر مدیر خودش ویرایش کرده → دست نمی‌زنیم (احترام به ویرایش مدیر)
// ۲) پاکسازی کش وضعیت آپدیت + state به‌روزرسانی قفل‌شده (برای چک تازه پس از ارتقا)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v273.ts
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_273 = {
  version: "2.7.3",
  title: "تازه‌های نسخه ۲.۷.۳",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    { tag: "FIXED", title: "رفع شکست به‌روزرسانی از پنل", desc: "هنگام به‌روزرسانی با دکمه پنل، نصب بسته‌ها گاهی بسته‌های سازنده (devDependencies) را نصب نمی‌کرد و بیلد با خطای Tailwind/PostCSS شکست می‌خورد. اکنون نصب همیشه کامل انجام می‌شود و به‌روزرسانی از پنل مانند خط فرمان کار می‌کند." },
    { tag: "IMPROVED", title: "سایت پس از خطای به‌روزرسانی سالم می‌ماند", desc: "اگر به‌روزرسانی در مرحله بیلد با خطا مواجه شود، نسخه قبلی به‌صورت خودکار بازگردانی می‌شود تا سایت بدون وقفه (با همان فونت‌ها و استایل‌ها) به کار خود ادامه دهد؛ همچنین پیام خطای دقیق در پنجره به‌روزرسانی نمایش داده می‌شود." },
  ],
};

// نسخه پیش‌فرض ۲.۷.۲ (از seed / backfill-v272) — برای تشخیص «دست‌نخورده»
const DEFAULT_272_ITEMS = [
  { tag: "IMPROVED", title: "وضعیت نسخه و به‌روزرسانی فقط برای مدیر کل", desc: "نشان وضعیت نسخه و پنجره به‌روزرسانی سامانه در نوار بالا فقط برای مدیر کل سیستم نمایش داده می‌شود؛ سایر کاربران آن را نمی‌بینند." },
  { tag: "IMPROVED", title: "چاپ و دانلود قراردادها با فونت B Nazanin", desc: "اسناد قرارداد در چاپ و دانلود با فونت B Nazanin سایز ۱۲ و فاصله سطر ۱.۱۵ آماده می‌شوند؛ هدرها (نام شرکت و عنوان قرارداد) بولد هستند و فایل دانلودی فونت را داخل خود دارد." },
];

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    // نصب تمیز — اطلاعیه ۲.۷.۳
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_273) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۷.۳» ساخته شد");
  } else {
    let cfg: { version?: string; items?: unknown } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    const ver = String(cfg.version || "");
    if (cmpVersion(ver, "2.7.3") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else {
      const isDefault272 =
        ver === "2.7.2" &&
        JSON.stringify(cfg.items) === JSON.stringify(DEFAULT_272_ITEMS);
      if (isDefault272) {
        // پیش‌فرض دست‌نخورده → جایگزین با ۲.۷.۳ (کاربران یک بار پاپ‌آپ جدید می‌بینند)
        await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_273) } });
        console.log("✓ اطلاعیه پیش‌فرض ۲.۷.۲ به «تازه‌های نسخه ۲.۷.۳» ارتقا یافت");
      } else {
        console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
      }
    }
  }

  // کش چک آپدیت قبلی بی‌اعتبار است (نسخه جدید نصب شده) — پاک تا چک تازه انجام شود
  await db.systemSetting.deleteMany({ where: { key: "update_check" } });
  await db.systemSetting.deleteMany({ where: { key: "update_state" } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

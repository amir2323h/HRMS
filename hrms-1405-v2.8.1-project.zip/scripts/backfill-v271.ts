// ============================================================
// Backfill v2.7.1 — اجرای خودکار نصب‌کننده پس از db push
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۷.۱ (چهار رفع اشکال):
//     • اگر اطلاعیه‌ای نیست → نسخه ۲.۷.۱ ساخته می‌شود (نصب تمیز)
//     • اگر اطلاعیه = پیش‌فرض دست‌نخورده ۲.۷.۰ → جایگزین با ۲.۷.۱
//     • اگر مدیر خودش ویرایش کرده → دست نمی‌زنیم (احترام به ویرایش مدیر)
// ۲) پاکسازی کش وضعیت آپدیت (برای چک تازه پس از ارتقا)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v271.ts
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_271 = {
  version: "2.7.1",
  title: "تازه‌های نسخه ۲.۷.۱",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    { tag: "FIXED", title: "بررسی نسخه از گیت‌هاب همیشه جواب می‌دهد", desc: "سه منبع موازی (API گیت‌هاب، فید انتشارها، زیپ‌های مخزن) — حتی با محدودیت نرخ یا نبود release، آخرین نسخه درست پیدا می‌شود و پیام خطای قبلی دیگر نمایش داده نمی‌شود." },
    { tag: "FIXED", title: "نمایش QR در فعال‌سازی ورود دو مرحله‌ای", desc: "کد QR صفحه راه‌اندازی اپ احرازکننده (که برای برخی مرورگرها خالی می‌افتاد) همیشه با اندازه درست رندر می‌شود." },
    { tag: "IMPROVED", title: "تاریخ شمسی در وضعیت نسخه", desc: "تاریخ انتشار آخرین نسخه گیت‌هاب و زمان «آخرین بررسی» در پنجره وضعیت نسخه، با تقویم شمسی نمایش داده می‌شود." },
    { tag: "FIXED", title: "پاک‌سازی پاپ‌آپ تازه‌های نسخه", desc: "متن اضافی پایین پاپ‌آپ حذف شد — فقط دکمه «متوجه شدم» باقی است." },
  ],
};

// نسخه پیش‌فرض ۲.۷.۰ (از seed / backfill-v27) — برای تشخیص «دست‌نخورده»
const DEFAULT_270_ITEMS = [
  { tag: "NEW", title: "تفکیک حقوق هر سطح", desc: "در «طبقه‌بندی مشاغل» تعیین کنید چند درصد حقوق ماهانه هر سطح به حقوق پایه، حق مسولیت و شایستگی برود — اضافه‌کاری، مأموریت و فوق‌العاده‌ها فقط از حقوق پایه محاسبه می‌شوند." },
  { tag: "NEW", title: "امضای نامه در کارتابل امضاکننده", desc: "امضاکنندگان مجاز را از فهرست نفرات (کاربران) انتخاب کنید؛ نامه دستی پس از مراحل تأیید به کارتابل خود امضاکننده می‌رود و خودش امضای دیجیتال را صادر می‌کند." },
  { tag: "NEW", title: "پاپ‌آپ «تازه‌های نسخه»", desc: "همین پنجره! آخرین تغییرات محصول را از «تنظیمات ← اطلاعیه نسخه» مدیریت کنید و تعیین کنید کدام نقش‌ها/کاربران آن را ببینند." },
  { tag: "IMPROVED", title: "دکمه آپدیت در پنل", desc: "نشان وضعیت نسخه در نوار بالا — بررسی خودکار نسخه جدید از گیت‌هاب هر ۲ روز + ارتقای یک‌کلیکی با پایش لاگ زنده." },
  { tag: "IMPROVED", title: "نسخه نرم‌افزار در فوتر و صفحه ورود", desc: "نسخه نصب‌شده همیشه جلوی چشم است." },
];

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    // نصب تمیز — اطلاعیه ۲.۷.۱
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_271) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۷.۱» ساخته شد");
  } else {
    let cfg: { version?: string; items?: unknown } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    const ver = String(cfg.version || "");
    if (cmpVersion(ver, "2.7.1") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else {
      const isDefault270 =
        ver === "2.7.0" &&
        JSON.stringify(cfg.items) === JSON.stringify(DEFAULT_270_ITEMS);
      if (isDefault270) {
        // پیش‌فرض دست‌نخورده → جایگزین با ۲.۷.۱ (کاربران یک بار پاپ‌آپ جدید می‌بینند)
        await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_271) } });
        console.log("✓ اطلاعیه پیش‌فرض ۲.۷.۰ به «تازه‌های نسخه ۲.۷.۱» ارتقا یافت");
      } else {
        console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
      }
    }
  }

  // کش چک آپدیت قبلی بی‌اعتبار است (نسخه جدید نصب شده) — پاک تا چک تازه انجام شود
  await db.systemSetting.deleteMany({ where: { key: "update_check" } });
  await db.systemSetting.deleteMany({ where: { key: "update_state" } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

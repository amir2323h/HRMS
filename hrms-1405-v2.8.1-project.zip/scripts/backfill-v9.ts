// ============================================================
// بک‌فیل نسخه ۹ — مجوزهای «مدیریت تغییرات حقوق» برای نقش‌های سیستمی
// (پیش‌نویس/تأیید/تغییر گروهی/معکوس + تاریخچه و آرشیو)
// اجرا:  DATABASE_URL=file:/home/z/my-project/db/custom.db bun scripts/backfill-v9.ts
// idempotent — اجرای مجدد بی‌ضرر است
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const ROLE_SALARY_PERMS: Record<string, string[]> = {
  HR_MANAGER: ["salary:view", "salary:manage"],
  PAYROLL_OFFICER: ["salary:view", "salary:manage"],
};

async function main() {
  for (const [roleKey, perms] of Object.entries(ROLE_SALARY_PERMS)) {
    const role = await db.role.findUnique({ where: { key: roleKey } });
    if (!role) continue;
    let current: string[] = [];
    try {
      current = JSON.parse(role.permissions || "[]");
    } catch {
      current = [];
    }
    const merged = [...new Set([...current, ...perms])];
    if (merged.length !== current.length) {
      await db.role.update({ where: { id: role.id }, data: { permissions: JSON.stringify(merged) } });
      console.log(`نقش ${roleKey}: مجوزهای مدیریت تغییرات حقوق اضافه شد ✓`);
    } else {
      console.log(`نقش ${roleKey}: مجوزها از قبل موجود است`);
    }
  }
  console.log("backfill-v9 کامل شد.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

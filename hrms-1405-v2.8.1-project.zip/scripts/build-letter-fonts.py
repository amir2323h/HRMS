#!/usr/bin/env python3
# ساخت فونت‌های ماژول نامه:
#  ۱) BNazanin.woff2 — کپی مستقیم (نام داخلی خانواده: B Nazanin — پوشش کامل فارسی، بدون لاتین)
#  ۲) TinosLatin-Regular/Bold.woff2 — زیرمجموعه لاتین Tinos (جفت سریف B Nazanin)
#     برای رندر حروف لاتین با سایز کوچک‌تر (size-adjust در CSS @font-face)
import shutil
from pathlib import Path
from fontTools import subset
from fontTools.ttLib import TTFont

SRC_BNAZANIN = Path("/tmp/fonts/Nazanin.woff2")
# Tinos در این محیط فیک بود — Liberation Serif (هم‌عرض Times New Roman) جایگزین
TINOS_REG = Path("/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf")
TINOS_BOLD = Path("/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf")
OUT = Path("/home/z/my-project/public/fonts")

OUT.mkdir(parents=True, exist_ok=True)

# ۱) B Nazanin — از بسته npm @raha.group/persian-fonts (نام داخلی: B Nazanin)
dst = OUT / "BNazanin.woff2"
shutil.copy(SRC_BNAZANIN, dst)
f = TTFont(str(dst))
fam = next((r.toUnicode() for r in f["name"].names if r.nameID == 1), "?")
print(f"BNazanin.woff2: {dst.stat().st_size} bytes — family={fam}")

# ۲) Tinos لاتین — زیرمجموعه: حروف لاتین + ارقام + علائم رایج
#     unicodes پایه برای متن اداری لاتین
latin_unicodes = (
    list(range(0x20, 0x7F))          # ASCII چاپی (حروف/ارقام/علائم)
    + list(range(0xA0, 0x18F))        # Latin-1 Supplement + Extended-A
    + [0x2013, 0x2014, 0x2018, 0x2019, 0x201C, 0x201D, 0x2026, 0x00D7, 0x00F7, 0x00B0]
)
for src, name in [(TINOS_REG, "LetterLatin-Regular.woff2"), (TINOS_BOLD, "LetterLatin-Bold.woff2")]:
    opts = subset.Options()
    opts.flavor = "woff2"
    opts.layout_features = ["kern", "liga"]
    opts.hinting = True
    font = subset.load_font(str(src), opts)
    sub = subset.Subsetter(options=opts)
    sub.populate(unicodes=latin_unicodes)
    sub.subset(font)
    out_path = OUT / name
    font.save(str(out_path))
    print(f"{name}: {out_path.stat().st_size} bytes")

# راستی‌آزمایی: B Nazanin فاقد «حروف» لاتین و دارای فارسی کامل
# (ارقام لاتین 0-9 در B Nazanin موجودند — فقط حروف A-Z/a-z حذف‌اند؛
#  همین ویژگی باعث fallback طبیعی حروف لاتین به فونت ریزتر می‌شود)
f = TTFont(str(dst))
cmap = f.getBestCmap()
assert all(ord(c) not in cmap for c in "ABCDabcd"), "B Nazanin نباید حروف لاتین داشته باشد!"
assert all(ord(c) in cmap for c in "ابپچژکگنی۰۹"), "B Nazanin باید فارسی کامل داشته باشد!"
print("✓ راستی‌آزمایی پوشش گلیف‌ها OK")

// ============================================================
// backfill-v10 (v2.3.0) — پاداش اور تارگت: +۲ پایه (سیاست جدید)
// اگر bonus_config ذخیره‌شده extraMonths تیر OVER_120 = ۱ (پیش‌فرض قدیمی)
// داشته باشد، به ۲ ارتقا می‌یابد. مقدار سفارشی دیگر دست‌نخورده می‌ماند.
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v10.ts
// idempotent — اجرای مجدد بی‌ضرر است
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const row = await db.systemSetting.findUnique({ where: { key: "bonus_config" } });
  if (!row) {
    console.log("bonus_config ذخیره نشده — پیش‌فرض جدید (+۲ پایه اور تارگت) خودبه‌خود اعمال می‌شود.");
    return;
  }
  try {
    const cfg = JSON.parse(row.value) as { tiers?: { key: string; extraMonths?: number }[] };
    const over = (cfg.tiers || []).find((t) => t.key === "OVER_120");
    if (!over) {
      console.log("تیر OVER_120 یافت نشد — بدون تغییر.");
      return;
    }
    if (over.extraMonths === 1) {
      over.extraMonths = 2;
      await db.systemSetting.update({
        where: { key: "bonus_config" },
        data: { value: JSON.stringify(cfg) },
      });
      console.log("ارتقا انجام شد: اور تارگت از +۱ به +۲ پایه اضافه (قابل ویرایش از تنظیمات ← پاداش).");
    } else {
      console.log(`extraMonths فعلی تیر OVER_120 = ${over.extraMonths} (سفارشی) — دست‌نخورده.`);
    }
  } catch {
    console.log("خطا در خواندن bonus_config — بدون تغییر.");
  }
}

main().finally(() => db.$disconnect());

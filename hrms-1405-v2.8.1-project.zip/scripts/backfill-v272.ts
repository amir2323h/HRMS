// ============================================================
// Backfill v2.7.2 — اجرای خودکار نصب‌کننده پس از db push
//  ۱) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۷.۲ (دو بهبود):
//     • اگر اطلاعیه‌ای نیست → نسخه ۲.۷.۲ ساخته می‌شود (نصب تمیز)
//     • اگر اطلاعیه = پیش‌فرض دست‌نخورده ۲.۷.۱ → جایگزین با ۲.۷.۲
//     • اگر مدیر خودش ویرایش کرده → دست نمی‌زنیم (احترام به ویرایش مدیر)
// ۲) پاکسازی کش وضعیت آپدیت (برای چک تازه پس از ارتقا)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v272.ts
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_272 = {
  version: "2.7.2",
  title: "تازه‌های نسخه ۲.۷.۲",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    { tag: "IMPROVED", title: "وضعیت نسخه و به‌روزرسانی فقط برای مدیر کل", desc: "نشان وضعیت نسخه و پنجره به‌روزرسانی سامانه در نوار بالا فقط برای مدیر کل سیستم نمایش داده می‌شود؛ سایر کاربران آن را نمی‌بینند." },
    { tag: "IMPROVED", title: "چاپ و دانلود قراردادها با فونت B Nazanin", desc: "اسناد قرارداد در چاپ و دانلود با فونت B Nazanin سایز ۱۲ و فاصله سطر ۱.۱۵ آماده می‌شوند؛ هدرها (نام شرکت و عنوان قرارداد) بولد هستند و فایل دانلودی فونت را داخل خود دارد." },
  ],
};

// نسخه پیش‌فرض ۲.۷.۱ (از seed / backfill-v271) — برای تشخیص «دست‌نخورده»
const DEFAULT_271_ITEMS = [
  { tag: "FIXED", title: "بررسی نسخه از گیت‌هاب همیشه جواب می‌دهد", desc: "سه منبع موازی (API گیت‌هاب، فید انتشارها، زیپ‌های مخزن) — حتی با محدودیت نرخ یا نبود release، آخرین نسخه درست پیدا می‌شود و پیام خطای قبلی دیگر نمایش داده نمی‌شود." },
  { tag: "FIXED", title: "نمایش QR در فعال‌سازی ورود دو مرحله‌ای", desc: "کد QR صفحه راه‌اندازی اپ احرازکننده (که برای برخی مرورگرها خالی می‌افتاد) همیشه با اندازه درست رندر می‌شود." },
  { tag: "IMPROVED", title: "تاریخ شمسی در وضعیت نسخه", desc: "تاریخ انتشار آخرین نسخه گیت‌هاب و زمان «آخرین بررسی» در پنجره وضعیت نسخه، با تقویم شمسی نمایش داده می‌شود." },
  { tag: "FIXED", title: "پاک‌سازی پاپ‌آپ تازه‌های نسخه", desc: "متن اضافی پایین پاپ‌آپ حذف شد — فقط دکمه «متوجه شدم» باقی است." },
];

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    // نصب تمیز — اطلاعیه ۲.۷.۲
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_272) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۷.۲» ساخته شد");
  } else {
    let cfg: { version?: string; items?: unknown } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    const ver = String(cfg.version || "");
    if (cmpVersion(ver, "2.7.2") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else {
      const isDefault271 =
        ver === "2.7.1" &&
        JSON.stringify(cfg.items) === JSON.stringify(DEFAULT_271_ITEMS);
      if (isDefault271) {
        // پیش‌فرض دست‌نخورده → جایگزین با ۲.۷.۲ (کاربران یک بار پاپ‌آپ جدید می‌بینند)
        await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_272) } });
        console.log("✓ اطلاعیه پیش‌فرض ۲.۷.۱ به «تازه‌های نسخه ۲.۷.۲» ارتقا یافت");
      } else {
        console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
      }
    }
  }

  // کش چک آپدیت قبلی بی‌اعتبار است (نسخه جدید نصب شده) — پاک تا چک تازه انجام شود
  await db.systemSetting.deleteMany({ where: { key: "update_check" } });
  await db.systemSetting.deleteMany({ where: { key: "update_state" } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

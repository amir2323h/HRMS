// ============================================================
// Backfill v2.8.0 — تعطیلات رسمی، شیفت‌ها و ساعت استاندارد دوره
//  ۱) درون‌ریزی ۲۶ تعطیل رسمی سال ۱۴۰۵ (تأییدشده از تقویم رسمی کشور — idempotent)
//  ۲) ثبت جدول شیفت‌های پیش‌فرض (work_schedule) اگر نباشد:
//     روزکار ۰۸–۱۷ (۶۰ دقیقه ناهار → ۸ ساعت) | صبح ۰۸–۱۶ | عصر/شب ۱۶–۲۴ | شب ۲۴–۰۸
//     تعطیلی هفتگی: روزکار پنجشنبه+جمعه | شیفتی جمعه
//  ۳) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۸.۰
//  ۴) پاکسازی کش وضعیت آپدیت
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v28.ts
// ============================================================
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const CHANGELOG_28 = {
  version: "2.8.0",
  title: "تازه‌های نسخه ۲.۸.۰",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    { tag: "NEW", title: "تعطیلات رسمی و ساعت استاندارد دوره", desc: "۲۶ تعطیل رسمی سال ۱۴۰۵ (تأییدشده از تقویم رسمی کشور) در سامانه بارگذاری شد؛ ساعت استاندارد هر دوره با کسر پنجشنبه، جمعه و تعطیلات رسمی به تفکیک روزکار و شیفتی محاسبه و در نمای حضور و تنظیمات نمایش داده می‌شود." },
    { tag: "NEW", title: "شیفت‌های کاری استاندارد", desc: "روزکار ۰۸:۰۰ تا ۱۷:۰۰ (با یک ساعت ناهار)، شیفت صبح ۰۸:۰۰ تا ۱۶:۰۰ و شیفت عصر/شب ۱۶:۰۰ تا ۲۴:۰۰ — ساعت‌ها، زمان استراحت و روزهای تعطیل هفتگی هر نوع اشتغال از «تنظیمات ← تعطیلات و شیفت‌ها» قابل تنظیم است." },
    { tag: "NEW", title: "تعطیلی پنجشنبه و جمعه برای روزکار", desc: "برای کارکنان روزکار، پنجشنبه و جمعه تعطیل هفتگی است (ثبت گروهی کارکرد و ساعت استاندارد دوره بر همین مبنا)؛ برای کارکنان شیفتی، تعطیلی هفتگی جمعه است و پنجشنبه کاری محسوب می‌شود." },
    { tag: "NEW", title: "دریافت تعطیلات از وب‌سرویس", desc: "تعطیلات سال‌های بعد را می‌توان از «تنظیمات ← تعطیلات و شیفت‌ها» با نشانی وب‌سرویس دریافت کرد؛ تعطیلات دستی مدیر بازنویسی نمی‌شوند." },
  ],
};

const OFFICIAL_HOLIDAYS_1405: { dateJ: string; title: string }[] = [
  { dateJ: "1405/01/01", title: "عید سعید فطر — آغاز نوروز" },
  { dateJ: "1405/01/02", title: "تعطیل به مناسبت عید سعید فطر" },
  { dateJ: "1405/01/03", title: "عید نوروز" },
  { dateJ: "1405/01/04", title: "عید نوروز" },
  { dateJ: "1405/01/12", title: "روز جمهوری اسلامی ایران" },
  { dateJ: "1405/01/13", title: "روز طبیعت (سیزده‌بدر)" },
  { dateJ: "1405/01/25", title: "شهادت امام جعفر صادق (ع)" },
  { dateJ: "1405/03/06", title: "عید سعید قربان" },
  { dateJ: "1405/03/14", title: "رحلت امام خمینی — عید سعید غدیر خم" },
  { dateJ: "1405/03/15", title: "قیام خونین ۱۵ خرداد" },
  { dateJ: "1405/04/03", title: "تاسوعای حسینی" },
  { dateJ: "1405/04/04", title: "عاشورای حسینی" },
  { dateJ: "1405/05/13", title: "اربعین حسینی" },
  { dateJ: "1405/05/21", title: "رحلت حضرت رسول اکرم (ص) و شهادت امام حسن مجتبی (ع)" },
  { dateJ: "1405/05/22", title: "شهادت امام رضا (ع)" },
  { dateJ: "1405/05/30", title: "شهادت امام حسن عسکری (ع)" },
  { dateJ: "1405/06/08", title: "میلاد حضرت رسول اکرم (ص) و امام جعفر صادق (ع)" },
  { dateJ: "1405/08/22", title: "شهادت حضرت فاطمه زهرا (س)" },
  { dateJ: "1405/10/02", title: "ولادت امام علی (ع) — روز پدر" },
  { dateJ: "1405/10/16", title: "مبعث حضرت رسول اکرم (ص)" },
  { dateJ: "1405/11/04", title: "ولادت حضرت قائم (عج) — نیمه شعبان" },
  { dateJ: "1405/11/22", title: "پیروزی انقلاب اسلامی ایران" },
  { dateJ: "1405/12/09", title: "شهادت امام علی (ع)" },
  { dateJ: "1405/12/19", title: "عید سعید فطر" },
  { dateJ: "1405/12/20", title: "تعطیل به مناسبت عید سعید فطر" },
  { dateJ: "1405/12/29", title: "روز ملی شدن صنعت نفت ایران" },
];

const WORK_SCHEDULE_DEFAULTS = {
  daily: { code: "DAILY", title: "روزکار (اداری)", start: "08:00", end: "17:00", breakMinutes: 60 },
  morning: { code: "MORNING", title: "شیفت صبح", start: "08:00", end: "16:00", breakMinutes: 0 },
  evening: { code: "EVENING", title: "شیفت عصر/شب", start: "16:00", end: "24:00", breakMinutes: 0 },
  night: { code: "NIGHT", title: "شیفت شب", start: "24:00", end: "08:00", breakMinutes: 0 },
  weekend: { DAILY: [5, 6], SHIFT: [6] },
};

function cmpVersion(a: string, b: string): number {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ۱) تعطیلات رسمی ۱۴۰۵ — upsert (دستی‌های مدیر دست نمی‌خورند)
  let created = 0;
  let kept = 0;
  for (const h of OFFICIAL_HOLIDAYS_1405) {
    const existing = await db.holiday.findUnique({ where: { dateJ: h.dateJ } });
    if (!existing) {
      await db.holiday.create({ data: { dateJ: h.dateJ, title: h.title, kind: "OFFICIAL", source: "seed", createdBy: "backfill-v2.8.0" } });
      created += 1;
    } else {
      kept += 1;
      // عنوان seed قبلی را با نسخه تأییدشده هم‌تراز کن (دستی‌ها محفوظ)
      if (existing.source !== "manual" && existing.title !== h.title) {
        await db.holiday.update({ where: { dateJ: h.dateJ }, data: { title: h.title } });
      }
    }
  }
  console.log(`✓ تعطیلات ۱۴۰۵: ${created} روز جدید، ${kept} روز موجود`);

  // ۲) جدول شیفت‌ها — فقط اگر مدیر چیزی ذخیره نکرده باشد
  const scheduleRow = await db.systemSetting.findUnique({ where: { key: "work_schedule" } });
  if (!scheduleRow) {
    await db.systemSetting.create({ data: { key: "work_schedule", value: JSON.stringify(WORK_SCHEDULE_DEFAULTS) } });
    console.log("✓ جدول شیفت‌های پیش‌فرض (روزکار ۰۸–۱۷، صبح ۰۸–۱۶، عصر/شب ۱۶–۲۴) ثبت شد");
  } else {
    console.log("• جدول شیفت‌ها از قبل تنظیم شده — دست نخورد");
  }

  // ۳) اطلاعیه نسخه
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_28) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۸.۰» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.8.0") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (String(cfg.version || "") === "2.7.3") {
      // ارتقای اطلاعیه پیش‌فرض ۲.۷.۳ → ۲.۸.۰ (پاپ‌آپ یک‌باره برای کاربران)
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_28) } });
      console.log("✓ اطلاعیه ۲.۷.۳ به «تازه‌های نسخه ۲.۸.۰» ارتقا یافت");
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ۴) کش چک آپدیت بی‌اعتبار است
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

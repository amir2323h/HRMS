// ============================================================
// Seed — داده‌های پایه سامانه منابع انسانی ۱۴۰۵
// اجرا: bun prisma/seed.ts
//
// از نسخه ۲.۱.۰: **هیچ داده پرسنلی نمونه ایجاد نمی‌شود**
//   (کارمند، فیش حقوقی، قرارداد، نامه، درخواست، سند — هیچ‌کدام).
// آنچه ایجاد می‌شود فقط پایه قابل استفاده سامانه است:
//   • پارامترهای قانونی ۱۴۰۵ (پله‌های مالیاتی، بیمه، مزایا)
//   • دپارتمان‌های نمونه سازمانی (بدون مدیر/عضو)
//   • طبقه‌بندی ۷ سطحی مشاغل
//   • کاربران نقش‌محور برای آزمایش دسترسی‌ها (بدون پرونده پرسنلی)
//   • یک رکورد راه‌اندازی در لاگ حسابرسی
// کارکنان واقعی از «کارکنان ← افزودن» یا ایمپورت اکسل وارد می‌شوند.
// ============================================================
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";
import { LEGAL_DEFAULTS_1405 } from "../src/lib/payroll/engine";

const db = new PrismaClient();

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

const R = (toman: number) => BigInt(Math.round(toman * 10)); // تومان → ریال

async function main() {
  console.log("🚿 پاک‌سازی دیتابیس...");
  await db.auditLog.deleteMany();
  await db.payslip.deleteMany();
  await db.payrollPeriod.deleteMany();
  await db.document.deleteMany();
  await db.leaveRequest.deleteMany();
  await db.advanceRequest.deleteMany();
  await db.user.deleteMany();
  await db.employeeDepartment.deleteMany();
  await db.employee.deleteMany();
  await db.jobGrade.deleteMany();
  await db.department.deleteMany();
  await db.taxBracket.deleteMany();
  await db.systemSetting.deleteMany();

  // ================= پارامترهای قانونی =================
  console.log("⚙️ پارامترهای قانونی ۱۴۰۵...");
  for (const b of LEGAL_DEFAULTS_1405.taxBrackets) {
    await db.taxBracket.create({
      data: {
        year: 1405,
        sortOrder: b.sortOrder,
        lowerLimit: BigInt(b.lowerLimit),
        upperLimit: b.upperLimit === null ? null : BigInt(b.upperLimit),
        rate: b.rate,
      },
    });
  }
  const { taxBrackets: _tb, ...legalRest } = LEGAL_DEFAULTS_1405;
  await db.systemSetting.create({ data: { key: "legal_params", value: JSON.stringify(legalRest) } });
  await db.systemSetting.create({ data: { key: "display", value: JSON.stringify({ unit: "TOMAN" }) } });
  await db.systemSetting.create({
    data: {
      key: "company",
      value: JSON.stringify({
        name: "شرکت فناوران داده پارس",
        nationalId: "10101234567",
        ssoCode: "22-104578-0",
        taxId: "41111234567890",
        address: "تهران، خیابان ولیعصر، برج فناوری، طبقه ۱۲",
      }),
    },
  });

  // ================= دپارتمان‌ها =================
  console.log("🏢 دپارتمان‌های نمونه سازمانی...");
  const deptData = [
    { code: "D100", name: "مدیریت ارشد", costCenter: "CC-100", parent: null, desc: "هیئت‌مدیره و مدیرعامل" },
    { code: "D200", name: "منابع انسانی", costCenter: "CC-210", parent: null, desc: "جذب، آموزش و رفاه کارکنان" },
    { code: "D300", name: "مالی و حسابداری", costCenter: "CC-310", parent: null, desc: "حسابداری، خزانه و حقوق و دستمزد" },
    { code: "D400", name: "فناوری اطلاعات", costCenter: "CC-410", parent: null, desc: "توسعه محصول و زیرساخت فنی" },
    { code: "D410", name: "توسعه نرم‌افزار", costCenter: "CC-411", parent: "D400", desc: "تیم مهندسی نرم‌افزار" },
    { code: "D420", name: "زیرساخت و شبکه", costCenter: "CC-412", parent: "D400", desc: "عملیات و امنیت شبکه" },
    { code: "D500", name: "فروش و بازاریابی", costCenter: "CC-510", parent: null, desc: "توسعه بازار و فروش سازمانی" },
  ];
  const deptIds: Record<string, string> = {};
  for (const d of deptData) {
    const row = await db.department.create({
      data: {
        code: d.code,
        name: d.name,
        costCenterCode: d.costCenter,
        description: d.desc,
        parentId: d.parent ? deptIds[d.parent] : null,
      },
    });
    deptIds[d.code] = row.id;
  }

  // ================= طبقه‌بندی ۷ سطحی =================
  console.log("📊 طبقه‌بندی مشاغل (۷ سطح)...");
  const gradesData = [
    { level: 1, code: "L1", title: "تازه‌کار / کارآموز", min: R(17_000_000), max: R(25_000_000), sen: R(500_001), att: R(0), desc: "شروع مسیر حرفه‌ای — زیر نظر منتور" },
    { level: 2, code: "L2", title: "جونیور (کارشناس کمکی)", min: R(25_000_000), max: R(40_000_000), sen: R(600_000), att: R(2_000_000), desc: "اجرای مستقل کارهای استاندارد" },
    { level: 3, code: "L3", title: "میان‌رده (کارشناس)", min: R(40_000_000), max: R(60_000_000), sen: R(800_000), att: R(3_000_000), desc: "کارشناس تمام‌عیار با مالکیت وظایف" },
    { level: 4, code: "L4", title: "ارشد (کارشناس ارشد)", min: R(60_000_000), max: R(90_000_000), sen: R(1_000_000), att: R(4_000_000), desc: "راهبری فنی و منتورینگ" },
    { level: 5, code: "L5", title: "سرپرست / متخصص ارشد", min: R(90_000_000), max: R(130_000_000), sen: R(1_200_000), att: R(5_000_000), desc: "رهبری تیم کوچک / تخصص کمیاب" },
    { level: 6, code: "L6", title: "مدیر (دپارتمان)", min: R(130_000_000), max: R(200_000_000), sen: R(1_500_000), att: R(8_000_000), desc: "مدیریت دپارتمان و بودجه" },
    { level: 7, code: "L7", title: "مدیر ارشد سازمانی", min: R(200_000_000), max: R(400_000_000), sen: R(2_000_000), att: R(15_000_000), desc: "معاون / مدیرعامل" },
  ];
  for (const g of gradesData) {
    await db.jobGrade.create({
      data: {
        level: g.level, code: g.code, title: g.title,
        minBaseSalary: g.min, maxBaseSalary: g.max,
        seniorityBase: g.sen, attraction: g.att, description: g.desc,
      },
    });
  }

  // ================= کاربران نقش‌محور =================
  // حساب‌های آزمایشی برای بررسی دسترسی نقش‌ها — بدون پرونده پرسنلی.
  // نام‌ها عمومی‌اند تا هیچ اطلاعات پرسنلی وارد دیتابیس نشود.
  console.log("🔑 کاربران نقش‌محور (بدون پرونده پرسنلی)...");
  const usersData = [
    { username: "admin", password: "admin123", fullName: "مدیر کل سیستم", role: "SUPER_ADMIN" },
    { username: "hr", password: "hr123", fullName: "کارشناس منابع انسانی", role: "HR_MANAGER" },
    { username: "payroll", password: "pay123", fullName: "کارشناس حقوق و دستمزد", role: "PAYROLL_OFFICER" },
    { username: "dept", password: "dept123", fullName: "مدیر دپارتمان", role: "DEPT_MANAGER" },
    { username: "emp", password: "emp123", fullName: "کارمند پورتال", role: "EMPLOYEE" },
    { username: "edari", password: "edari123", fullName: "کارشناس اداری", role: "ADMIN_EXPERT" },
  ];
  for (const u of usersData) {
    await db.user.create({
      data: { username: u.username, passwordHash: hashPassword(u.password), fullName: u.fullName, role: u.role },
    });
  }

  // ================= اطلاعیه «تازه‌های نسخه» (پاپ‌آپ اولین ورود) =================
  // نسخه ۲.۸.۰ — برای همه کاربران فعال؛ هر کاربر پس از «متوجه شدم» دیگر نمی‌بیند
  await db.systemSetting.upsert({
    where: { key: "changelog" },
    update: {},
    create: {
      key: "changelog",
      value: JSON.stringify({
        version: "2.8.1",
        title: "تازه‌های نسخه ۲.۸.۱",
        enabled: true,
        targetAll: true,
        roles: [],
        usernames: [],
        updatedAt: new Date().toISOString(),
        items: [
          { tag: "NEW", title: "پشتیبان‌گیری و بازیابی داده‌ها", desc: "از «تنظیمات ← پشتیبان‌گیری» با یک کلیک از تمام داده‌های پنل اسنپ‌شات سالم بگیرید (بدون توقف سرویس)، فایل را دانلود یا به سرور دیگر منتقل کنید و در صورت نیاز با بازیابی امن یک‌کلیکی (پشتیبان خودکار از وضعیت فعلی + اعتبارسنجی کامل) بازگردانید — حداکثر ۱۰ نسخه نگه داشته می‌شود و پیش از هر به‌روزرسانی هم خودکار پشتیبان گرفته می‌شود." },
          { tag: "NEW", title: "تعطیلات رسمی و ساعت استاندارد دوره", desc: "۲۶ تعطیل رسمی سال ۱۴۰۵ (تأییدشده از تقویم رسمی کشور) در سامانه بارگذاری شد؛ ساعت استاندارد هر دوره با کسر پنجشنبه، جمعه و تعطیلات رسمی به تفکیک روزکار و شیفتی محاسبه و در نمای حضور و تنظیمات نمایش داده می‌شود." },
          { tag: "NEW", title: "شیفت‌های کاری استاندارد", desc: "روزکار ۰۸:۰۰ تا ۱۷:۰۰ (با یک ساعت ناهار)، شیفت صبح ۰۸:۰۰ تا ۱۶:۰۰ و شیفت عصر/شب ۱۶:۰۰ تا ۲۴:۰۰ — ساعت‌ها، زمان استراحت و روزهای تعطیل هفتگی هر نوع اشتغال از «تنظیمات ← تعطیلات و شیفت‌ها» قابل تنظیم است." },
          { tag: "NEW", title: "تعطیلی پنجشنبه و جمعه برای روزکار", desc: "برای کارکنان روزکار، پنجشنبه و جمعه تعطیل هفتگی است (ثبت گروهی کارکرد و ساعت استاندارد دوره بر همین مبنا)؛ برای کارکنان شیفتی، تعطیلی هفتگی جمعه است و پنجشنبه کاری محسوب می‌شود." },
          { tag: "NEW", title: "دریافت تعطیلات از وب‌سرویس", desc: "تعطیلات سال‌های بعد را می‌توان از «تنظیمات ← تعطیلات و شیفت‌ها» با نشانی وب‌سرویس دریافت کرد؛ تعطیلات دستی مدیر بازنویسی نمی‌شوند." },
        ],
      }),
    },
  });

  // ================= تعطیلات رسمی ۱۴۰۵ + جدول شیفت‌ها =================
  const HOLIDAYS_1405: { dateJ: string; title: string }[] = [
    { dateJ: "1405/01/01", title: "عید سعید فطر — آغاز نوروز" },
    { dateJ: "1405/01/02", title: "تعطیل به مناسبت عید سعید فطر" },
    { dateJ: "1405/01/03", title: "عید نوروز" },
    { dateJ: "1405/01/04", title: "عید نوروز" },
    { dateJ: "1405/01/12", title: "روز جمهوری اسلامی ایران" },
    { dateJ: "1405/01/13", title: "روز طبیعت (سیزده‌بدر)" },
    { dateJ: "1405/01/25", title: "شهادت امام جعفر صادق (ع)" },
    { dateJ: "1405/03/06", title: "عید سعید قربان" },
    { dateJ: "1405/03/14", title: "رحلت امام خمینی — عید سعید غدیر خم" },
    { dateJ: "1405/03/15", title: "قیام خونین ۱۵ خرداد" },
    { dateJ: "1405/04/03", title: "تاسوعای حسینی" },
    { dateJ: "1405/04/04", title: "عاشورای حسینی" },
    { dateJ: "1405/05/13", title: "اربعین حسینی" },
    { dateJ: "1405/05/21", title: "رحلت حضرت رسول اکرم (ص) و شهادت امام حسن مجتبی (ع)" },
    { dateJ: "1405/05/22", title: "شهادت امام رضا (ع)" },
    { dateJ: "1405/05/30", title: "شهادت امام حسن عسکری (ع)" },
    { dateJ: "1405/06/08", title: "میلاد حضرت رسول اکرم (ص) و امام جعفر صادق (ع)" },
    { dateJ: "1405/08/22", title: "شهادت حضرت فاطمه زهرا (س)" },
    { dateJ: "1405/10/02", title: "ولادت امام علی (ع) — روز پدر" },
    { dateJ: "1405/10/16", title: "مبعث حضرت رسول اکرم (ص)" },
    { dateJ: "1405/11/04", title: "ولادت حضرت قائم (عج) — نیمه شعبان" },
    { dateJ: "1405/11/22", title: "پیروزی انقلاب اسلامی ایران" },
    { dateJ: "1405/12/09", title: "شهادت امام علی (ع)" },
    { dateJ: "1405/12/19", title: "عید سعید فطر" },
    { dateJ: "1405/12/20", title: "تعطیل به مناسبت عید سعید فطر" },
    { dateJ: "1405/12/29", title: "روز ملی شدن صنعت نفت ایران" },
  ];
  for (const h of HOLIDAYS_1405) {
    await db.holiday.upsert({
      where: { dateJ: h.dateJ },
      update: {},
      create: { dateJ: h.dateJ, title: h.title, kind: "OFFICIAL", source: "seed", createdBy: "seed" },
    });
  }

  // جدول شیفت‌ها: روزکار ۰۸–۱۷ (ناهار ۶۰ دقیقه) | صبح ۰۸–۱۶ | عصر/شب ۱۶–۲۴ | شب ۲۴–۰۸
  // تعطیلی هفتگی: روزکار پنجشنبه+جمعه | شیفتی جمعه
  await db.systemSetting.upsert({
    where: { key: "work_schedule" },
    update: {},
    create: {
      key: "work_schedule",
      value: JSON.stringify({
        daily: { code: "DAILY", title: "روزکار (اداری)", start: "08:00", end: "17:00", breakMinutes: 60 },
        morning: { code: "MORNING", title: "شیفت صبح", start: "08:00", end: "16:00", breakMinutes: 0 },
        evening: { code: "EVENING", title: "شیفت عصر/شب", start: "16:00", end: "24:00", breakMinutes: 0 },
        night: { code: "NIGHT", title: "شیفت شب", start: "24:00", end: "08:00", breakMinutes: 0 },
        weekend: { DAILY: [5, 6], SHIFT: [6] },
      }),
    },
  });

  // ================= لاگ راه‌اندازی =================
  await db.auditLog.create({
    data: {
      userName: "system",
      action: "CREATE",
      entity: "SYSTEM",
      summary: "راه‌اندازی اولیه سامانه و پارامترهای قانونی ۱۴۰۵ — بدون داده پرسنلی",
      after: JSON.stringify({ version: "2.1.0", personnelFree: true }),
    },
  });

  const counts = {
    employees: await db.employee.count(),
    departments: await db.department.count(),
    grades: await db.jobGrade.count(),
    periods: await db.payrollPeriod.count(),
    payslips: await db.payslip.count(),
    documents: await db.document.count(),
    users: await db.user.count(),
    auditLogs: await db.auditLog.count(),
  };
  console.log("✅ Seed پایه کامل شد (بدون داده پرسنلی):", counts);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());

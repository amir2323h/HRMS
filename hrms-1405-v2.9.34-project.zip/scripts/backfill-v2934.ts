// ============================================================
// Backfill v2.9.34 — جانمایی ویژوال «هر عنصر مستقل» + وسط‌چین نام/سمت
//  ۱) مهر نسخه در دیتابیس (SystemSetting «app_version»)
//  ۲) ارتقای اطلاعیه «تازه‌های نسخه» به ۲.۹.۳۴
//  ۳) پاکسازی کش وضعیت آپدیت
// تغییر این نسخه در چاپ/دانلود نامه‌ها:
//  • ادیتور ویژوال تنظیمات ← قالب نامه‌ها: هر عنصر (امضای دست‌نویس،
//    مهر، باکس نام/سمت و مهر امضای دیجیتال) جداگانه با برچسب و رنگ
//    متمایز روی کاغذ A4/A5 کشیده می‌شود — نسبت و فاصلهٔ کنار-هم‌بودن
//    عناصر را کاربر خودش تعیین می‌کند (حذف جابه‌جایی یکجای گروهی)
//  • متن باکس نام/سمت («با تجدید احترام» + نام + سمت) وسط‌چین شد
//    (قبلاً راست‌چین بود)
//  • چیدمان‌های ذخیره‌شده نسخه قبل (گروهی) به‌طور خودکار به مختصات
//    تک‌تک عناصر مهاجرت می‌کنند (بدون تغییر اسکیما)
// اجرا: DATABASE_URL=file:... npx tsx scripts/backfill-v2934.ts
// idempotent — اطلاعیه ویرایش‌شده مدیر دست نمی‌خورد
// ============================================================
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkgVersion = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8")).version;

const db = new PrismaClient();

const CHANGELOG_2934 = {
  version: "2.9.34",
  title: "تازه‌های نسخه ۲.۹.۳۴",
  enabled: true,
  targetAll: true,
  roles: [] as string[],
  usernames: [] as string[],
  updatedAt: new Date().toISOString(),
  items: [
    {
      tag: "IMPROVED",
      title: "نامه‌ها: جانمایی ویژوال — هر عنصر امضا/مهر مستقل جابه‌جا می‌شود",
      desc: "در «تنظیمات ← قالب نامه‌ها ← جانمایی امضا و مهر (ویژوال)» دیگر همه عناصر در یک کادر یکجا جابه‌جا نمی‌شوند: هر عنصر — امضای دست‌نویس، مهر، باکس نام/سمت و مهر امضای دیجیتال — برچسب و رنگ متمایز خودش را دارد و جداگانه با ماوس کشیده می‌شود تا نسبت و فاصلهٔ کنار-هم-بودن‌شان را دقیقاً مطابق سلیقه خودتان روی کاغذ A4/A5 تنظیم کنید. مختصات میلی‌متری هر عنصر در فیلدهای جداگانه (رنگ‌هماهنگ با همان عنصر) نمایش داده می‌شود و همان مختصات عیناً در چاپ و دانلود نامه اعمال می‌شود. چیدمان‌های ذخیره‌شده نسخه قبل به‌طور خودکار به مختصات تک‌تک عناصر تبدیل می‌شوند و دکمه «بازنشانی» چیدمان پیش‌فرض را برمی‌گرداند.",
    },
    {
      tag: "IMPROVED",
      title: "نامه‌ها: متن نام و سمت امضاکننده وسط‌چین شد",
      desc: "در نسخه چاپی و دانلودی نامه‌ها، متن باکس نام/سمت امضاکننده — شامل عبارت «با تجدید احترام»، نام و سمت (مثل «مدیرعامل» و نام او) — اکنون به‌صورت «وسط‌چین» درج می‌شود (قبلاً راست‌چین بود). این حالت هم در چیدمان پیش‌فرض و هم در جانمایی ویژوال اعمال می‌شود.",
    },
  ],
};

function cmpVersion(a: string, b: string): number {
  const pa = a.split(".").map((x) => parseInt(x, 10) || 0);
  const pb = b.split(".").map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

async function main() {
  // ---------- ۱. مهر نسخه ----------
  await db.systemSetting.upsert({
    where: { key: "app_version" },
    update: { value: pkgVersion },
    create: { key: "app_version", value: pkgVersion },
  });
  console.log(`✓ مهر نسخه ${pkgVersion} در دیتابیس (app_version) ثبت شد`);

  // ---------- ۲. اطلاعیه نسخه ----------
  const existing = await db.systemSetting.findUnique({ where: { key: "changelog" } });
  if (!existing) {
    await db.systemSetting.create({ data: { key: "changelog", value: JSON.stringify(CHANGELOG_2934) } });
    console.log("✓ اطلاعیه پیش‌فرض «تازه‌های نسخه ۲.۹.۳۴» ساخته شد");
  } else {
    let cfg: { version?: string } = {};
    try { cfg = JSON.parse(existing.value); } catch { /* مقدار خراب */ }
    if (cmpVersion(String(cfg.version || ""), "2.9.34") >= 0) {
      console.log("• اطلاعیه تغییرات همین نسخه یا جدیدتر است — دست نخورد");
    } else if (cmpVersion(String(cfg.version || ""), "2.7.0") >= 0) {
      await db.systemSetting.update({ where: { key: "changelog" }, data: { value: JSON.stringify(CHANGELOG_2934) } });
      console.log(`✓ اطلاعیه ${cfg.version || "—"} به «تازه‌های نسخه ۲.۹.۳۴» ارتقا یافت`);
    } else {
      console.log("• اطلاعیه تغییرات توسط مدیر ویرایش شده — برای احترام به ویرایش، دست نخورد");
    }
  }

  // ---------- ۳. کش چک آپدیت بی‌اعتبار است ----------
  await db.systemSetting.deleteMany({ where: { key: { in: ["update_check", "update_state"] } } });
  console.log("✓ کش چک نسخه/وضعیت آپدیت پاک شد");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());

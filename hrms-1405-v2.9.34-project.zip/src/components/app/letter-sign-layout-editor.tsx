"use client";

// ============================================================
// ادیتور ویژوال جانمایی امضا و مهر روی کاغذ نامه (درگ‌اند‌دراپ)
// پیش‌نمایش واقعی کاغذ A4/A5 با تصویر «سربرگ رسمی شرکت» در پس‌زمینه؛
// «هر عنصر» — امضای دست‌نویس، مهر، باکس نام/سمت و مهر امضای دیجیتال —
// مستقل از بقیه با ماوس/لمس جابه‌جا می‌شود تا کاربر خودش نسبت و فاصلهٔ
// کنار-هم-بودن عناصر را تنظیم کند (بدون جابه‌جایی یکجا به‌صورت گروه).
//   • مختصات: X = فاصله از لبه چپ کاغذ (mm) — Y = فاصله از لبه پایین (mm)
//   • در چاپ/دانلود نامه همین مختصات مطلقاً روی کاغذ اعمال می‌شود
//     (هماهنگ با کاغذ پیش‌چاپ/تصویر سربرگ رسمی دارای محل امضا)
//   • متن باکس نام/سمت («با تجدید احترام» + نام + سمت) وسط‌چین است
//   • پیش‌فرض (custom=false): چیدمان جریان قدیمی (گروه امضا زیر متن نامه)
//     — با کشیدن هر عنصر، جانمایی سفارشی خودکار فعال می‌شود
//   • دکمه «بازنشانی» چیدمان پیش‌فرض را برمی‌گرداند و ذخیره می‌کند
// ذخیره: PUT /api/letters/letterhead → signLayoutA4 + signLayoutA5
// ============================================================

import { useEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { NativeSelect } from "@/components/app/native-select";
import { useToast } from "@/hooks/use-toast";
import { api, useApi } from "@/lib/client";
import { Move, RotateCcw, Save, MousePointerClick } from "lucide-react";
import { toFaDigits } from "@/lib/jalali";

/** کلید عناصر مستقل قابل جابه‌جایی */
type ElemKey = "sig" | "seal" | "name" | "digi";

interface SignLayout {
  custom: boolean;
  sigX: number;
  sigY: number;
  sealX: number;
  sealY: number;
  nameX: number;
  nameY: number;
  digiX: number;
  digiY: number;
}

interface SignerEntry {
  name: string;
  title: string;
  signature: string;
  seal: string;
}

interface LetterheadInfo {
  a4: string;
  a5: string;
  a4TopMm?: number;
  a4BottomMm?: number;
  a5TopMm?: number;
  a5BottomMm?: number;
  signatureSizeMm?: number;
  sealSizeMm?: number;
  signers?: SignerEntry[];
  showDigitalSignature?: boolean;
  signLayoutA4?: SignLayout;
  signLayoutA5?: SignLayout;
}

/** ابعاد کاغذ (mm) */
const PAPER: Record<"A4" | "A5", { w: number; h: number; side: number; besm: number }> = {
  A4: { w: 210, h: 297, side: 16, besm: 28.5 },
  A5: { w: 148, h: 210, side: 12, besm: 23.7 },
};

const LAYOUT_DEFAULTS: Record<"A4" | "A5", SignLayout> = {
  A4: { custom: false, nameX: 60, nameY: 24, sealX: 95, sealY: 24, sigX: 95, sigY: 39, digiX: 16, digiY: 24 },
  A5: { custom: false, nameX: 43, nameY: 18, sealX: 68, sealY: 18, sigX: 68, sigY: 30, digiX: 12, digiY: 18 },
};

/** مشخصات نمایشی هر عنصر — برچسب و رنگ متمایز */
const ELEM_META: Record<ElemKey, { label: string; chip: string; ring: string }> = {
  sig: { label: "امضا", chip: "bg-teal-600", ring: "#0d9488" },
  seal: { label: "مهر", chip: "bg-amber-500", ring: "#d97706" },
  name: { label: "نام و سمت", chip: "bg-violet-600", ring: "#7c3aed" },
  digi: { label: "امضای دیجیتال", chip: "bg-[#3050A0]", ring: "#3050A0" },
};

/** نگاشت کلید عنصر → نام فیلدهای X/Y در SignLayout */
const ELEM_XY: Record<ElemKey, { x: keyof Omit<SignLayout, "custom">; y: keyof Omit<SignLayout, "custom"> }> = {
  sig: { x: "sigX", y: "sigY" },
  seal: { x: "sealX", y: "sealY" },
  name: { x: "nameX", y: "nameY" },
  digi: { x: "digiX", y: "digiY" },
};

export function LetterSignLayoutCard({ canEdit }: { canEdit: boolean }) {
  const { data, refetch } = useApi<LetterheadInfo>("/api/letters/letterhead");
  const { toast } = useToast();

  const [paper, setPaper] = useState<"A4" | "A5">("A4");
  const [layA4, setLayA4] = useState<SignLayout>({ ...LAYOUT_DEFAULTS.A4 });
  const [layA5, setLayA5] = useState<SignLayout>({ ...LAYOUT_DEFAULTS.A5 });
  const [signerIdx, setSignerIdx] = useState(0);
  const [saving, setSaving] = useState(false);
  const [dragging, setDragging] = useState<ElemKey | null>(null);
  const [scale, setScale] = useState(1.5); // پیکسل به میلی‌متر

  const pageRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ key: ElemKey; px0: number; py0: number; x0: number; y0: number } | null>(null);
  const initialized = useRef(false);

  const geo = PAPER[paper];
  const layout = paper === "A4" ? layA4 : layA5;

  // مقداردهی اولیه از تنظیمات ذخیره‌شده (سرور چیدمان قدیمی را مهاجرت می‌دهد)
  useEffect(() => {
    if (data && !initialized.current) {
      initialized.current = true;
      setLayA4({ ...LAYOUT_DEFAULTS.A4, ...(data.signLayoutA4 || {}) });
      setLayA5({ ...LAYOUT_DEFAULTS.A5, ...(data.signLayoutA5 || {}) });
    }
  }, [data]);

  // مقیاس پیش‌نمایش (px/mm) — با تغییر اندازه کانتینر به‌روز می‌شود
  useEffect(() => {
    const el = pageRef.current;
    if (!el) return;
    const update = () => setScale(el.clientWidth / geo.w);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, [geo.w, paper, data?.a4, data?.a5]);

  function setLayout(patch: Partial<SignLayout>) {
    if (paper === "A4") setLayA4((p) => ({ ...p, ...patch }));
    else setLayA5((p) => ({ ...p, ...patch }));
  }

  /** مقدار X/Y عنصر */
  const posOf = (key: ElemKey) => ({
    x: layout[ELEM_XY[key].x] as number,
    y: layout[ELEM_XY[key].y] as number,
  });

  // ---------- درگ‌اند‌دراپ (هر عنصر مستقل) ----------
  function startDrag(e: React.PointerEvent<HTMLDivElement>, key: ElemKey) {
    if (!canEdit) return;
    e.preventDefault();
    e.stopPropagation();
    const p = posOf(key);
    dragRef.current = { key, px0: e.clientX, py0: e.clientY, x0: p.x, y0: p.y };
    setDragging(key);
    if (!layout.custom) setLayout({ custom: true }); // کشیدن = فعال‌شدن جانمایی سفارشی
    try {
      e.currentTarget.setPointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
  }

  function onDrag(e: React.PointerEvent<HTMLDivElement>) {
    const d = dragRef.current;
    if (!d || !pageRef.current) return;
    const rect = pageRef.current.getBoundingClientRect();
    const mmPerPx = geo.w / rect.width;
    const elemWmm = (e.currentTarget as HTMLElement).offsetWidth * mmPerPx;
    const elemHmm = (e.currentTarget as HTMLElement).offsetHeight * mmPerPx;
    let nx = d.x0 + (e.clientX - d.px0) * mmPerPx;
    let ny = d.y0 - (e.clientY - d.py0) * mmPerPx;
    nx = Math.round(Math.min(Math.max(0, nx), Math.max(0, geo.w - elemWmm)));
    ny = Math.round(Math.min(Math.max(0, ny), Math.max(0, geo.h - elemHmm)));
    setLayout({ [ELEM_XY[d.key].x]: nx, [ELEM_XY[d.key].y]: ny, custom: true } as Partial<SignLayout>);
  }

  function endDrag(e: React.PointerEvent<HTMLDivElement>) {
    dragRef.current = null;
    setDragging(null);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
  }

  // جابه‌جایی عنصر با کلیدهای جهت‌دار (عنصر متمرکز) — Shift = گام ۵mm
  function navKeys(key: ElemKey) {
    return {
      role: "button" as const,
      tabIndex: canEdit ? 0 : -1,
      "aria-label": `${ELEM_META[key].label} — قابل کشیدن`,
      onKeyDown: (e: React.KeyboardEvent<HTMLDivElement>) => {
        if (!canEdit) return;
        const step = e.shiftKey ? 5 : 1;
        const { x, y } = ELEM_XY[key];
        const p = posOf(key);
        const go = (dx: number, dy: number) => {
          e.preventDefault();
          setLayout({ [x]: Math.round(Math.min(Math.max(0, p.x + dx), geo.w)), [y]: Math.round(Math.min(Math.max(0, p.y + dy), geo.h)), custom: true } as Partial<SignLayout>);
        };
        if (e.key === "ArrowLeft") go(-step, 0);
        if (e.key === "ArrowRight") go(step, 0);
        if (e.key === "ArrowUp") go(0, step);
        if (e.key === "ArrowDown") go(0, -step);
      },
    };
  }

  // برچسب شناور کوچک روی هر عنصر (نام + رنگ متمایز)
  const chip = (key: ElemKey) => (
    <span
      className={`pointer-events-none absolute left-1/2 -translate-x-1/2 whitespace-nowrap rounded px-1.5 py-0.5 font-bold text-white shadow ${ELEM_META[key].chip} ${dragging === key ? "opacity-100" : canEdit ? "opacity-85" : "hidden"}`}
      style={{ top: mm(-4.6), fontSize: Math.max(7, mm(2.3)) }}
    >
      {ELEM_META[key].label}
    </span>
  );

  // قاب مشترک عنصر قابل کشیدن (موقعیت مطلق روی کاغذ + outline وضعیت)
  const elemStyle = (key: ElemKey): React.CSSProperties => {
    const p = posOf(key);
    return {
      position: "absolute",
      left: pct(p.x, geo.w),
      bottom: pct(p.y, geo.h),
      touchAction: "none",
      outline: dragging === key ? `1.5px dashed ${ELEM_META[key].ring}` : canEdit ? "1px dashed #94a3b8" : "none",
      outlineOffset: "2px",
    };
  };

  // ---------- ذخیره / بازنشانی ----------
  async function save() {
    setSaving(true);
    try {
      await api("/api/letters/letterhead", { method: "PUT", json: { signLayoutA4: layA4, signLayoutA5: layA5 } });
      await refetch();
      toast({
        title: "جانمایی امضا و مهر ذخیره شد",
        description: `${layA4.custom || layA5.custom ? "مختصات تک‌تک عناصر از این پس در چاپ/دانلود نامه‌ها اعمال می‌شود." : "چیدمان پیش‌فرض (زیر متن نامه) بازیافت شد."}`,
      });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  async function resetDefaults() {
    const a4 = { ...LAYOUT_DEFAULTS.A4 };
    const a5 = { ...LAYOUT_DEFAULTS.A5 };
    setLayA4(a4);
    setLayA5(a5);
    setSaving(true);
    try {
      await api("/api/letters/letterhead", { method: "PUT", json: { signLayoutA4: a4, signLayoutA5: a5 } });
      await refetch();
      toast({ title: "چیدمان پیش‌فرض بازیافت شد", description: "گروه امضا/مهر مثل قبل، زیر متن نامه چاپ می‌شود." });
    } catch (e) {
      toast({ title: "خطا در ذخیره", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  // ---------- داده‌های پیش‌نمایش ----------
  const bgImage = paper === "A4" ? data?.a4 || "" : data?.a5 || "";
  const topMm = (paper === "A4" ? data?.a4TopMm ?? 42 : data?.a5TopMm ?? 30);
  const signers = data?.signers || [];
  const signer = signers[Math.min(signerIdx, Math.max(0, signers.length - 1))];
  const sigMm = (data?.signatureSizeMm ?? 11) * (paper === "A5" ? 0.82 : 1);
  const sealMm = (data?.sealSizeMm ?? 13) * (paper === "A5" ? 0.82 : 1);
  const mm = (v: number) => v * scale; // mm → px پیش‌نمایش
  const showDigi = data?.showDigitalSignature !== false;

  const pct = (v: number, total: number) => `${(v / total) * 100}%`;

  // ---------- عناصر مستقل قابل کشیدن ----------
  // ۱) امضای دست‌نویس
  const sigElem = (
    <div
      className={`select-none ${canEdit ? "cursor-grab active:cursor-grabbing" : ""}`}
      style={{ ...elemStyle("sig"), direction: "rtl" }}
      onPointerDown={(e) => startDrag(e, "sig")}
      onPointerMove={onDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      {...navKeys("sig")}
    >
      {chip("sig")}
      {signer?.signature ? (
        <img src={signer.signature} alt="امضای دست‌نویس" style={{ height: mm(sigMm), maxWidth: mm(sigMm * 3.1), objectFit: "contain", display: "block" }} />
      ) : (
        <div className="flex items-center justify-center border border-dashed border-teal-400 text-teal-600" style={{ height: mm(sigMm), minWidth: mm(18), fontSize: Math.max(6, mm(2.2)) }}>
          امضا
        </div>
      )}
    </div>
  );

  // ۲) مهر
  const sealElem = (
    <div
      className={`select-none ${canEdit ? "cursor-grab active:cursor-grabbing" : ""}`}
      style={{ ...elemStyle("seal"), direction: "rtl" }}
      onPointerDown={(e) => startDrag(e, "seal")}
      onPointerMove={onDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      {...navKeys("seal")}
    >
      {chip("seal")}
      {signer?.seal ? (
        <img src={signer.seal} alt="مهر" style={{ height: mm(sealMm), maxWidth: mm(sealMm * 1.25), objectFit: "contain", display: "block" }} />
      ) : (
        <div className="flex items-center justify-center border border-dashed border-amber-400 text-amber-600" style={{ height: mm(sealMm), minWidth: mm(12), fontSize: Math.max(6, mm(2.2)) }}>
          مهر
        </div>
      )}
    </div>
  );

  // ۳) باکس نام/سمت — متن وسط‌چین («با تجدید احترام» + نام + سمت)
  const nameElem = (
    <div
      className={`select-none ${canEdit ? "cursor-grab active:cursor-grabbing" : ""}`}
      style={{ ...elemStyle("name"), direction: "rtl" }}
      onPointerDown={(e) => startDrag(e, "name")}
      onPointerMove={onDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      {...navKeys("name")}
    >
      {chip("name")}
      <div className="text-center leading-tight" style={{ minWidth: mm(24), fontFamily: "inherit" }}>
        <p className="font-bold text-slate-900" style={{ fontSize: Math.max(6, mm(3.9)) }}>با تجدید احترام</p>
        <p className="font-bold text-slate-800" style={{ fontSize: Math.max(6, mm(3.9)), marginTop: mm(0.6) }}>
          {signer?.name || "نام امضاکننده"}
        </p>
        {signer?.title ? (
          <p className="text-slate-500" style={{ fontSize: Math.max(5, mm(3.5)) }}>{signer.title}</p>
        ) : null}
      </div>
    </div>
  );

  // ۴) مهر امضای دیجیتال (QR + مشخصات) — نسخه کوچک چاپ
  const digiElem = showDigi ? (
    <div
      className={`select-none ${canEdit ? "cursor-grab active:cursor-grabbing" : ""}`}
      style={{ ...elemStyle("digi"), direction: "rtl", width: mm(paper === "A5" ? 36 : 42) }}
      onPointerDown={(e) => startDrag(e, "digi")}
      onPointerMove={onDrag}
      onPointerUp={endDrag}
      onPointerCancel={endDrag}
      {...navKeys("digi")}
    >
      {chip("digi")}
      <div
        style={{
          border: "1px double #3050A0",
          borderRadius: mm(1.6),
          background: "rgba(245,247,253,.6)",
          padding: mm(0.8),
        }}
      >
        <div className="flex flex-col items-center" style={{ gap: mm(0.5) }}>
          <div className="flex items-center font-bold text-[#3050A0]" style={{ fontSize: Math.max(5, mm(2.5)), gap: mm(1) }}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" style={{ width: mm(2.6), height: mm(2.6) }}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>
            <span>امضای دیجیتال</span>
          </div>
          <div className="flex items-center" style={{ gap: mm(1.6) }}>
            <div
              className="bg-white border border-slate-300"
              style={{ width: mm(paper === "A5" ? 13 : 17), height: mm(paper === "A5" ? 13 : 17), borderRadius: mm(0.6) }}
            >
              <div
                className="w-full h-full"
                style={{
                  backgroundImage: "repeating-conic-gradient(#0f172a 0% 25%, #ffffff 0% 50%)",
                  backgroundSize: "36% 36%",
                  borderRadius: mm(0.4),
                }}
              />
            </div>
            <div className="text-center" style={{ fontSize: Math.max(4, mm(2.2)), lineHeight: 1.5 }}>
              <p className="font-bold text-slate-900">{signer?.name || "نام تأییدکننده"}</p>
              <p className="text-slate-500">مرجع تأییدکننده</p>
              <p dir="ltr" className="font-mono font-bold text-[#3050A0]">A1B2-C3D4-E5F6-0713</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  ) : null;

  // پیش‌نمایش کاغذ — تصویر سربرگ رسمی (تنها منبع گرافیک) + متن نمونه + عناصر قابل کشیدن
  const page = (
    <div
      ref={pageRef}
      className="relative bg-white border border-slate-200 shadow-md overflow-hidden mx-auto"
      style={{ width: "100%", maxWidth: 340, aspectRatio: `${geo.w} / ${geo.h}`, direction: "rtl" }}
    >
      {/* تصویر سربرگ رسمی شرکت — پس‌زمینه */}
      {bgImage ? (
        <div
          className="absolute inset-0"
          style={{ backgroundImage: `url(${bgImage})`, backgroundSize: "100% 100%", backgroundPosition: "center" }}
          aria-hidden="true"
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-[10px] text-slate-300 text-center leading-5 px-4">
            تصویر سربرگ {paper} آپلود نشده — پیش‌نمایش کاغذ خالی
            <br />
            (در چاپ هیچ گرافیک سربرگی درج نمی‌شود)
          </span>
        </div>
      )}

      {/* بِسمِهِ تَعالی — وسط، زیر نوار سربرگ */}
      <p
        className="absolute left-1/2 -translate-x-1/2 text-slate-700 whitespace-nowrap"
        style={{ top: pct(geo.besm, geo.h), fontSize: Math.max(7, mm(5)) }}
        aria-hidden="true"
      >
        بِسمِهِ تَعالی
      </p>

      {/* تاریخ/شماره — بالا-چپ (مانند چاپ واقعی) */}
      <div className="absolute text-slate-800" style={{ left: pct(geo.side, geo.w), top: pct(6, geo.h), fontSize: Math.max(5, mm(4)) }}>
        <p className="leading-relaxed">تاریخ: {toFaDigits("1405/07/12")}</p>
        <p className="leading-relaxed" dir="ltr" style={{ textAlign: "right" }}>ZDX_AD_0507019</p>
      </div>

      {/* موضوع/گیرنده — راست‌چین زیر سربرگ */}
      <div className="absolute text-right text-slate-800 font-bold" style={{ right: pct(geo.side, geo.w), top: pct(topMm + 2, geo.h), left: pct(geo.side, geo.w), fontSize: Math.max(5, mm(4.2)) }}>
        <p className="leading-relaxed">موضوع: درخواست‌نامه اداری (نمونه)</p>
        <p className="leading-relaxed opacity-80">مدیریت محترم شرکت</p>
      </div>

      {/* متن نمونه بدنه — خاکستری کم‌رنگ */}
      <div
        className="absolute text-slate-400"
        style={{ right: pct(geo.side, geo.w), left: pct(geo.side, geo.w), top: pct(topMm + 22, geo.h), fontSize: Math.max(5, mm(4.2)), lineHeight: 2.05, textAlign: "justify" }}
        aria-hidden="true"
      >
        <p>با سلام و احترام،</p>
        <p>این متن صرفاً نمونه است تا جایگاه امضا و مهر نسبت به متن نامه روی کاغذ {paper} مشخص شود؛ هر عنصر را جداگانه بکشید و در جای دلخواه رها کنید.</p>
        <p>مختصات دقیق هر عنصر به میلی‌متر در پایین همین کارت نمایش داده می‌شود و در چاپ/دانلود نامه عیناً اعمال می‌گردد.</p>
      </div>

      {/* عناصر مستقل قابل کشیدن — روی همه لایه‌ها */}
      {sigElem}
      {sealElem}
      {nameElem}
      {digiElem}

      {/* نشان حالت درگ */}
      {dragging ? (
        <div className="absolute top-1.5 left-1.5 bg-teal-600 text-white text-[10px] rounded px-2 py-0.5 shadow">
          در حال جابه‌جایی «{ELEM_META[dragging].label}»…
        </div>
      ) : null}
    </div>
  );

  const numField = (label: string, value: number, set: (v: number) => void, max: number) => (
    <div className="space-y-1">
      <Label className="text-[10px]">{label}</Label>
      <Input
        dir="ltr"
        type="number"
        min={0}
        max={max}
        className="h-8 text-xs text-left"
        value={value}
        disabled={!canEdit}
        onChange={(e) => {
          const n = parseInt(e.target.value.replace(/\D/g, ""), 10);
          set(isNaN(n) ? 0 : Math.min(max, Math.max(0, n)));
        }}
      />
    </div>
  );

  /** گروه مختصات یک عنصر: دات رنگی + نام + دو فیلد X/Y (mm) */
  const coordGroup = (key: ElemKey) => {
    const p = posOf(key);
    const { x, y } = ELEM_XY[key];
    return (
      <div className="rounded-lg border border-slate-200 p-2 space-y-1.5">
        <div className="flex items-center gap-1.5">
          <span className={`inline-block w-2 h-2 rounded-full ${ELEM_META[key].chip}`} aria-hidden="true" />
          <span className="text-[11px] font-bold text-slate-700">{ELEM_META[key].label}</span>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          {numField("از لبه چپ (mm)", p.x, (v) => setLayout({ [x]: v, custom: true } as Partial<SignLayout>), geo.w)}
          {numField("از لبه پایین (mm)", p.y, (v) => setLayout({ [y]: v, custom: true } as Partial<SignLayout>), geo.h)}
        </div>
      </div>
    );
  };

  return (
    <Card className="rounded-2xl">
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2 flex-wrap">
          <Move className="w-4 h-4 text-teal-600" /> جانمایی امضا و مهر روی کاغذ (ویژوال)
          <span className="inline-flex items-center gap-1 rounded-md bg-teal-50 border border-teal-200 px-1.5 py-0.5 text-[10px] font-normal text-teal-700">
            <MousePointerClick className="w-3 h-3" /> هر عنصر جداگانه بکشید
          </span>
        </CardTitle>
        <p className="text-xs text-muted-foreground mt-1 leading-5">
          هر عنصر — <b className="text-teal-700">امضا</b>، <b className="text-amber-600">مهر</b>، <b className="text-violet-700">نام و سمت</b> و <b className="text-[#3050A0]">مهر امضای دیجیتال</b> — مستقل از بقیه جابه‌جا می‌شود؛
          بدین‌ترتیب نسبت و فاصلهٔ کنار-هم‌بودن‌شان را دقیقاً مطابق سلیقه خودتان روی کاغذ تنظیم کنید (بدون جابه‌جایی یکجا به‌صورت یک گروه).
          همان مختصات به میلی‌متر (فاصله از لبه چپ/پایین کاغذ) در چاپ و دانلود نامه اعمال می‌شود و با تصویر «سربرگ رسمی شرکت» هماهنگ می‌ماند.
          متن باکس نام و سمت نیز وسط‌چین است. پیش‌فرض، گروه امضا زیر متن نامه چاپ می‌شود؛ به‌محض کشیدن هر عنصر، جانمایی سفارشی فعال می‌شود.
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* انتخاب سایز کاغذ + امضاکننده نمونه + سوییچ جانمایی سفارشی */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex rounded-lg border border-slate-200 overflow-hidden">
            {(["A4", "A5"] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setPaper(s)}
                className={`px-3 py-1 text-[11px] font-bold transition-colors ${
                  paper === s ? "bg-teal-600 text-white" : "bg-white text-slate-600 hover:bg-slate-50"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
          <div className="w-48">
            <NativeSelect
              value={String(signerIdx)}
              onChange={(v) => setSignerIdx(parseInt(v, 10) || 0)}
              disabled={!canEdit}
              ariaLabel="امضاکننده نمونه پیش‌نمایش"
            >
              {signers.length > 0
                ? signers.map((s, i) => (
                    <option key={`${s.name}-${i}`} value={i}>
                      {s.name}
                    </option>
                  ))
                : <option value={0}>امضاکننده‌ای ثبت نشده</option>}
            </NativeSelect>
          </div>
          <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
            <Switch
              checked={layout.custom}
              onCheckedChange={(v) => canEdit && setLayout({ custom: v })}
              disabled={!canEdit}
              aria-label="جانمایی سفارشی امضا و مهر"
            />
            جانمایی سفارشی {layout.custom ? "(فعال)" : "(پیش‌فرض: زیر متن نامه)"}
          </label>
        </div>

        {/* پیش‌نمایش کاغذ */}
        <div className="max-w-[340px] mx-auto">{page}</div>

        {/* مختصات دقیق هر عنصر (mm) — گروه مجزا با رنگ متمایز */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 max-w-[760px]">
          {coordGroup("sig")}
          {coordGroup("seal")}
          {coordGroup("name")}
          {showDigi ? coordGroup("digi") : null}
        </div>
        <p className="text-[11px] text-muted-foreground leading-5">
          مختصات برای هر سایز کاغذ جداگانه ذخیره می‌شود — پیش‌نمایش و فیلدهای بالا را روی A4 و A5 جدا تنظیم و یک‌بار ذخیره کنید.
          {showDigi ? "" : " (مهر امضای دیجیتال طبق «اطلاعات پایه» خاموش است و چاپ نمی‌شود.)"}
        </p>

        {canEdit && (
          <div className="flex items-center gap-2 pt-2 border-t flex-wrap">
            <Button onClick={save} disabled={saving} className="bg-teal-600 hover:bg-teal-700 gap-1.5">
              <Save className="w-4 h-4" /> {saving ? "در حال ذخیره..." : "ذخیره جانمایی"}
            </Button>
            <Button variant="outline" onClick={resetDefaults} disabled={saving} className="gap-1.5">
              <RotateCcw className="w-4 h-4" /> بازنشانی به پیش‌فرض
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

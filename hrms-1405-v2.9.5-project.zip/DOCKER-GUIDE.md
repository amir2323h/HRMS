# 🐳 راهنمای نصب HRMS 1405 با Docker — نسخه ۲.۹.۴

سامانه جامع منابع انسانی، حقوق و دستمزد ۱۴۰۵ — فارسی/RTL کامل، بدون هیچ وابستگی آنلاین.

این راهنما برای ساده‌ترین حالت ممکن نوشته شده است: **فقط Docker** (یا Docker Compose) روی سرور لازم است — نه Node.js، نه PostgreSQL، نه هیچ ابزار دیگری. همه‌چیز (کد، فونت‌ها، دیتابیس SQLite، تنظیمات قانونی ۱۴۰۵) داخل کانتینر آماده است.

---

## ⚡ راه اندازه سریع (۳ فرمان)

اگر Docker و Docker Compose از قبل نصب است، کل کار این است:

```bash
# ۱) بسته را باز کنید
unzip hrms-1405-v2.9.4-project.zip -d hrms && cd hrms

# ۲) بسازید و اجرا کنید (اولین بار چند دقیقه طول می‌کشد)
docker compose up -d --build

# ۳) باز کنید
# http://IP-سرور:3000  →  ورود: admin / admin123
```

همین! سامانه بالا است و دیتابیس آن در والیوم `hrms-data` (بیرون از کانتینر) ذخیره می‌شود — با توقف یا حذف کانتینر چیزی از بین نمی‌رود.

> **رمز ورود پیش‌فرض:** `admin / admin123` — همان لحظه اول از «تنظیمات ← کاربران» رمز را عوض کنید.

---

## 📋 گام صفر — نصب Docker (اگر ندارید)

### اوبونتو/دبیان (رایج‌ترین)
```bash
curl -fsSL https://get.docker.com | sh
```
این اسکریپت رسمی، Docker و افزونه Compose را یکجا نصب می‌کند. پس از پایان:
```bash
docker --version && docker compose version   # هر دو باید نسخه نشان دهند
```

### سایر سیستم‌عامل‌ها
- ** rocky/AlmaLinux/CentOS:** `dnf install -y docker docker-compose-plugin && systemctl enable --now docker`
- ** ویندوز سرور / دسکتاپ:** Docker Desktop را از docker.com نصب کنید (WSL2)

---

## 🔀 مسیرهای نصب

### الف) از همین بسته (زیپ دانلودی) — پیشنهادی
```bash
unzip hrms-1405-v2.9.4-project.zip -d hrms
cd hrms
docker compose up -d --build
```
Dockerfile، docker-compose.yml و همه فایل‌های لازم داخل زیپ آماده است.

### ب) فقط با یک فایل (بدون باز کردن زیپ)
اگر فقط `Dockerfile` + `docker-compose.yml` + بسته زیپ را کنار هم دارید هم همین کار می‌کند — چون Dockerfile همه‌چیز را از پوشه جاری می‌خواند.

---

## ⚙️ تنظیمات اختیاری (قبل از اولین اجرا)

فایل `docker-compose.yml` را باز کنید و در بخش `environment` هر چیزی خواستید فعال کنید:

| متغیر | پیش‌فرض | توضیح |
|---|---|---|
| `HRMS_ADMIN_PASSWORD` | `admin123` | رمز مدیر در **اولین** اجرا با این مقدار ساخته می‌شود — رمز قوی بگذارید |
| `HRMS_DEMO` | `0` | `1` = ساخت کاربران نمونه (admin/hr/payroll/emp/…) برای آزمایش — فقط در اولین اجرا |
| پورت | `3000` | در بخش `ports` عدد سمت چپ را عوض کنید، مثلاً `"8080:3000"` یعنی روی 8080 میزبان |

مثال — رمز اختصاصی + حالت نمایشی + پورت 8080:

```yaml
    ports:
      - "8080:3000"
    environment:
      HRMS_DEMO: "1"
      HRMS_ADMIN_PASSWORD: "MyStr0ngPass!"
```

> ⚠️ این متغیرها فقط وقتی معنا دارند که **اولین اجرا** باشند (دیتابیس هنوز ساخته نشده). اگر دیتابیس از قبل موجود باشد، رد می‌شوند تا دست به داده‌های موجود نزنند.

---

## 🔄 کارهای روزمره

```bash
docker compose logs -f          # مشاهده زنده لاگ‌ها
docker compose restart          # ری‌استارت ساده
docker compose down             # توقف (داده‌ها می‌مانند)
docker compose up -d            # اجرای مجدد
```

**پشتیبان‌گیری:** از خود پنل — «تنظیمات ← پشتیبان‌گیری و بازیابی» ← دکمه پشتیبان. فایل‌ها در والیوم کنار دیتابیس (`/data/backups` داخل کانتینر) ذخیره و از پنل قابل دانلود هستند. یا کل والیوم:
```bash
docker run --rm -v hrms-data:/data -v $(pwd):/backup alpine \
  tar czf /backup/hrms-data-backup.tar.gz -C /data .
```

**بازیابی والیوم:**
```bash
docker run --rm -v hrms-data:/data -v $(pwd):/backup alpine \
  sh -c "rm -rf /data/* && tar xzf /backup/hrms-data-backup.tar.gz -C /data"
```

---

## ⬆️ به‌روزرسانی به نسخه‌های جدید

1. زیپ نسخه جدید را باز کنید و جای پوشه قبلی بگذارید (یا فقط فایل‌های `src/` را جایگزین کنید)
2. سپس:
```bash
docker compose up -d --build
```
کانتینر جدید بالا می‌آید، **دیتابیس موجود را می‌شناسد**، اسکیمای آن را بی‌دست‌زدن به داده‌ها همگام می‌کند و بک‌فیل‌های نسخه جدید را اعمال می‌کند — دقیقاً مثل به‌روزرسانی VPS. (به‌روزرسانی از خود پنل/`hrms update` مخصوص نصب بدون داکر است و در حالت داکر کاربرد ندارد.)

> پیش از آپدیت، از پنل پشتیبان بگیرید — همین یک کلیک.

---

## 🌐 پشت دامنه با HTTPS (اختیاری)

ساده‌ترین راه، اضافه کردن یک Caddy کنار سامانه است. به `docker-compose.yml` اضافه کنید:

```yaml
  caddy:
    image: caddy:2
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./Caddyfile:/etc/caddy/Caddyfile
      - caddy-data:/data
    depends_on:
      - hrms
```
و فایل `Caddyfile` (نمونه‌اش داخل بسته هست) با دامنه خودتان:
```
hrms.example.com {
    encode zstd gzip
    reverse_proxy hrms:3000
}
```
گواهی HTTPS خودکار صادر و تمدید می‌شود. (رکورد A دامنه را به IP سرور بدهید و پورت 80/443 را در فایروال باز کنید.)

---

## 🚫 خطای 403 یا timeout هنگام بیلد (محدودیت Docker Hub)

اگر هنگام `docker compose up -d --build` با این خطا مواجه شدید:

```
ERROR: failed to solve: unexpected status from HEAD request to
https://registry-1.docker.io/v2/library/node/manifests/22-bookworm-slim: 403 Forbidden
```

یعنی سرور شما (به دلیل محدودیت منطقه‌ای یا محدودیت نرخ) به Docker Hub دسترسی ندارد. راه‌حل — استفاده از آینه (mirror) جایگزین برای ایمیج پایه، **بدون دست‌کاری Dockerfile**:

**۱)** در پوشه‌ای که `docker-compose.yml` هست، فایلی به نام `.env` بسازید (می‌توانید از `.env.example` کپی بگیرید):

```bash
cp .env.example .env   # اگر نمونه موجود است؛ وگرنه:
echo 'NODE_IMAGE=mirror.gcr.io/library/node:22-bookworm-slim' > .env
```

**۲)** سپس دوباره بسازید:

```bash
docker compose up -d --build
```

آینه‌های قابل امتحان (به‌ترتیب پیشنهاد):

| آینه | مقدار NODE_IMAGE |
|---|---|
| گوگل — پایدار و رسمی | `mirror.gcr.io/library/node:22-bookworm-slim` |
| آینه‌های عمومی دیگر | هر registry جایگزین معتبری که ایمیج `node:22-bookworm-slim` را دارد |

> نکته: `mirror.gcr.io` آینه رسمی گوگل برای ایمیج‌های Docker Hub است و معمولاً بدون محدودیت منطقه‌ای در دسترس است. اگر آن هم مسدود بود، از سرویس‌های proxy داکر معتبر داخلی خودتان استفاده کنید — فقط باید بتوانند ایمیج `node:22-bookworm-slim` را بکشند.

> نکته ۲: اگر می‌خواهید یک‌باره و بدون فایل `.env` امتحان کنید:
> ```bash
> docker compose build --build-arg NODE_IMAGE=mirror.gcr.io/library/node:22-bookworm-slim
> docker compose up -d
> ```

---

## 🩺 رفع اشکال

| نشانه | راه‌حل |
|---|---|
| **403 Forbidden از registry-1.docker.io** | بخش «خطای 403» بالای همین جدول — فایل `.env` با `NODE_IMAGE=mirror.gcr.io/library/node:22-bookworm-slim` بسازید و `docker compose up -d --build` |
| پورت 3000 اشغال است | در `docker-compose.yml` بخش `ports` را مثلاً `"3001:3000"` کنید |
| `docker: permission denied` | کاربر را به گروه داکر اضافه کنید: `sudo usermod -aG docker $USER` و خروج/ورود مجدد |
| اولین بیلد کند است | طبیعی است — وابستگی‌ها و بیلد تولیدی داخل ایمیج ساخته می‌شود (فقط بار اول) |
| رمز admin را فراموش کردم | والیوم را نگه دارید و کانتینر را با `HRMS_ADMIN_PASSWORD` نو + یک دیتابیس تازه بالا بیاورید؛ سپس پشتیبان قبلی را از پنل بازیابی کنید |
| بیلد روی خطای شبکه گیر کرد | `docker compose build --no-cache` را دوباره اجرا کنید |
| تغییر داده‌ها اثر ندارد | مطمئن شوید والیوم `hrms-data` حذف نشده (`docker volume ls`) — `docker compose down` آن را نگه می‌دارد، `docker compose down -v` حذف می‌کند! |

**لاگ بوت کانتینر** (همان خروجی نصب‌کننده VPS را دارد — سه حالت نصب تازه/دمو/به‌روزرسانی):
```bash
docker compose logs hrms | head -20
```

---

## 🏗 چه چیزی داخل ایمیج است؟

- **گام بیلد:** وابستگی‌ها دقیقاً مطابق `package-lock.json` (بدون drift نسخه — درس نسخه‌های ۲.۹.۰/۲.۹.۱)، بیلد تولیدی Next.js standalone
- **گام آماده‌سازی:** دیتابیس تمیز با اسکیما + مدیر + تعطیلات رسمی ۱۴۰۵ + شیفت‌ها + قالب‌نامه‌ها — در دل بیلد ساخته می‌شود تا اولین اجرا سریع باشد
- **گام اجرا:** سرور + ابزار همگام‌سازی دیتابیس (prisma/tsx با نسخه قفل‌شده) — در هر بوت، اسکیما و بک‌فیل‌های idempotent اعمال می‌شوند؛ یعنی حتی اگر کانتینر ری‌استارت شود، هیچ چیز خراب نمی‌شود
- **داده‌ها:** دیتابیس SQLite + پشتیبان‌ها در والیوم `hrms-data` — کاملاً بیرون از چرخه حیات کانتینر
- **سلامت:** healthcheck داخلی هر ۳۰ ثانیه `/api/system/version` را می‌سنجد

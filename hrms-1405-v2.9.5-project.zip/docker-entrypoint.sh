#!/bin/sh
# ================================================================
# HRMS 1405 — نقطه ورود کانتینر (معادل نصب‌کننده VPS در سه حالت)
#  ۱) نصب تازه (بدون /data/custom.db) → کپی دیتابیس آماده + بک‌فیل‌ها
#  ۲) نصب تازه با HRMS_DEMO=1 → کاربران نمونه + داده پایه کامل
#  ۳) دیتابیس موجود (به‌روزرسانی) → همگام‌سازی اسکیما + بک‌فیل‌ها
# همه مراحل idempotent هستند — restart بی‌خطر است.
# ================================================================
set -e

# مسیر داده‌ها — در کانتینر /data است؛ برای اجرای لوکال/تست قابل تغییر
APP_DIR="${HRMS_APP_DIR:-/app}"
DATA_DIR="${HRMS_DATA_DIR:-/data}"
DB="$DATA_DIR/custom.db"
DB_URL="file:$DB"
FRESH=0
[ -f "$DB" ] || FRESH=1
mkdir -p "$DATA_DIR"

run_ts() { # اجرای بک‌فیل با tsx (خطا نمی‌ایستاند — idempotent)
  [ -f "$1" ] && DATABASE_URL="$DB_URL" tsx "$1" >/dev/null 2>&1 || true
}

if [ "$FRESH" = "1" ]; then
  echo "▪ نصب تازه — آماده‌سازی دیتابیس برای اولین اجرا…"
  if [ -f $APP_DIR/prepared/custom.db ]; then
    cp $APP_DIR/prepared/custom.db "$DB"
    echo "  ✓ دیتابیس آماده (اسکیما + مدیر + تنظیمات قانونی ۱۴۰۵) کپی شد"
  else
    # مسیر جایگزین اگر دیتابیس آماده در ایمیج نبود (نباید رخ دهد)
    DATABASE_URL="$DB_URL" prisma db push --accept-data-loss --schema $APP_DIR/prisma/schema.prisma --skip-generate
    DATABASE_URL="$DB_URL" node $APP_DIR/scripts/docker-bootstrap.mjs
  fi

  if [ "$HRMS_DEMO" = "1" ]; then
    echo "▪ حالت نمایشی — کاربران نمونه (admin/hr/payroll/emp/…) بارگذاری می‌شود…"
    DATABASE_URL="$DB_URL" tsx $APP_DIR/prisma/seed.ts >/dev/null 2>&1 || DATABASE_URL="$DB_URL" tsx $APP_DIR/prisma/seed.ts
    for v in v4 v5 v9 v10 v27 v271 v272 v273 v28 v281 v29 v291 v292 v293 v294 v295; do
      run_ts "$APP_DIR/scripts/backfill-$v.ts"
    done
  else
    # نصب تمیز — همان دنبله نصب‌کننده VPS (بدون کاربران نمونه)
    for v in v8 v28 v281 v29 v291 v292 v293 v294 v295; do
      run_ts "$APP_DIR/scripts/backfill-$v.ts"
    done
  fi

  if [ -n "$HRMS_ADMIN_PASSWORD" ]; then
    DATABASE_URL="$DB_URL" node $APP_DIR/scripts/docker-set-admin-password.mjs
    echo "  ✓ رمز مدیر از متغیر HRMS_ADMIN_PASSWORD اعمال شد"
  else
    echo "  ⚠ ورود پیش‌فرض: admin / admin123 — رمز را پس از اولین ورود تغییر دهید"
  fi
else
  echo "▪ دیتابیس موجود یافت شد — همگام‌سازی اسکیما و داده‌ها (بدون دست‌زدن به داده‌ها)…"
  DATABASE_URL="$DB_URL" prisma db push --accept-data-loss --schema $APP_DIR/prisma/schema.prisma --skip-generate \
    || echo "  ⚠ همگام‌سازی اسکیما رد شد — با همان اسکیمای فعلی ادامه می‌دهیم"
  # همان دنبله UPDATE_MODE نصب‌کننده VPS — idempotent
  for v in v8 v9 v10 v27 v271 v272 v273 v28 v281 v29 v291 v292 v293 v294 v295; do
    run_ts "$APP_DIR/scripts/backfill-$v.ts"
  done
  echo "  ✓ داده‌ها و کاربران موجود حفظ شدند"
fi

echo "▪ راه‌اندازی سرور HRMS روی پورت ${PORT:-3000}…"
cd $APP_DIR/.next/standalone
exec node server.js

// ============================================================
// nixpacks-prebuild — آماده‌سازی محیط برای بیلدرهای Nixpacks
// (داکپلوی / Coolify / Railway و…)
//
// اجرا در گام build (nixpacks.toml) — قبل از «npm run build»:
//  ۱) تعیین DATABASE_URL — اولویت: متغیر محیطی پنل > مسیر پیش‌فرض پروژه
//  ۲) نوشتن .env (برای اجرای runtime سرور standalone بدون تنظیم دستی)
//  ۳) ساخت/همگام‌سازی دیتابیس SQLite (prisma db push)
//  ۴) bootstrap مدیر اولیه (admin / admin123) — idempotent
//  ۵) AUTH_SECRET تصادفی در صورت نبود (ورود یکپارچه/امنیت)
//
// ⚠ داده‌های دیتابیس روی PaaS معمولاً «موقتی»اند — با هر دیپلوی جدید
//   دیتابیس از نو ساخته می‌شود. برای داده ماندگار از نصب VPS یا Docker+والیوم استفاده کنید.
// ============================================================
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "fs";
import { execSync } from "child_process";
import { randomBytes } from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dbDir = path.join(root, "db");
const dbFile = path.join(dbDir, "custom.db");

// ---------- ۱) DATABASE_URL ----------
let dbUrl = (process.env.DATABASE_URL || "").trim();
if (dbUrl.startsWith("file:") && !path.isAbsolute(dbUrl.slice(5).replace(/\?.*$/, ""))) {
  // مسیر نسبی SQLite نسبت به prisma/schema.prisma حل می‌شود → مطلق می‌کنیم
  dbUrl = "file:" + path.join(root, "prisma", dbUrl.slice(5));
}
if (!dbUrl.startsWith("file:")) {
  dbUrl = `file:${dbFile}`;
}
console.log(`▪ DATABASE_URL = ${dbUrl}`);
mkdirSync(dbDir, { recursive: true });

// ---------- ۲) .env برای runtime ----------
// متغیرهای واقعی محیط (پنل پلتفرم) همیشه بر .env اولویت دارند (dotenv بازنویسی نمی‌کند)
const pkg = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8"));
const authSecret = (process.env.AUTH_SECRET || "").trim() || randomBytes(32).toString("hex");
const envPath = path.join(root, ".env");
const existingEnv = existsSync(envPath) ? readFileSync(envPath, "utf8") : "";
const hasDbLine = /^DATABASE_URL=/m.test(existingEnv);
const envContent = (hasDbLine ? existingEnv.replace(/^DATABASE_URL=.*$/m, `DATABASE_URL=${dbUrl}`) : `${existingEnv}${existingEnv.endsWith("\n") || !existingEnv ? "" : "\n"}DATABASE_URL=${dbUrl}\n`)
  .replace(/^AUTH_SECRET=.*$/m, `AUTH_SECRET=${authSecret}`);
writeFileSync(envPath, envContent.includes("AUTH_SECRET=") ? envContent : `${envContent}AUTH_SECRET=${authSecret}\n`);
console.log("✓ .env آماده شد (DATABASE_URL + AUTH_SECRET)");

// ---------- ۳) دیتابیس ----------
try {
  execSync("npx prisma db push --skip-generate --accept-data-loss", {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, DATABASE_URL: dbUrl },
  });
  console.log(existsSync(dbFile) ? "✓ دیتابیس SQLite آماده شد" : "• دیتابیس خارجی (متغیر محیطی) استفاده می‌شود");
} catch (e) {
  console.error("✗ همگام‌سازی اسکیمای دیتابیس شکست خورد:", e.message);
  process.exit(1);
}

// ---------- ۴) bootstrap مدیر اولیه ----------
try {
  execSync("node scripts/docker-bootstrap.mjs", {
    cwd: root,
    stdio: "inherit",
    env: { ...process.env, DATABASE_URL: dbUrl },
  });
} catch (e) {
  console.error("✗ ساخت مدیر اولیه شکست خورد:", e.message);
  process.exit(1);
}

console.log(`▪ HRMS ${pkg.version} — آمادهٔ بیلد Nixpacks (ورود پیش‌فرض: admin / admin123)`);

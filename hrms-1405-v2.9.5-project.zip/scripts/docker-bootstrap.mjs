// ============================================================
// Docker bootstrap — نصب تمیز: ساخت مدیر اولیه + تنظیمات پایه
// معادل bootstrap.mjs داخل نصب‌کننده VPS (حالت نصب تمیز)
// اجرا: DATABASE_URL=file:/data/custom.db node scripts/docker-bootstrap.mjs
// idempotent — برای نصب تازه داکر
// ============================================================
import { PrismaClient } from "@prisma/client";
import { scryptSync, randomBytes } from "crypto";

const db = new PrismaClient();
const salt = randomBytes(16).toString("hex");
const hash = scryptSync(process.env.HRMS_ADMIN_PASSWORD || "admin123", salt, 64).toString("hex");
const role = await db.role.upsert({
  where: { key: "SUPER_ADMIN" },
  update: {},
  create: { key: "SUPER_ADMIN", name: "مدیر کل سیستم", description: "دسترسی کامل", permissions: "[\"*\"]" },
});
await db.user.upsert({
  where: { username: "admin" },
  update: { roleId: role.id },
  create: { username: "admin", passwordHash: `${salt}:${hash}`, fullName: "مدیر کل سیستم", role: "SUPER_ADMIN", roleId: role.id, isActive: true },
});
await db.systemSetting.upsert({
  where: { key: "display" },
  update: {},
  create: { key: "display", value: "{\"unit\":\"TOMAN\"}" },
});
await db.$disconnect();
console.log("bootstrap-ok: admin /", process.env.HRMS_ADMIN_PASSWORD ? "(از HRMS_ADMIN_PASSWORD)" : "admin123");

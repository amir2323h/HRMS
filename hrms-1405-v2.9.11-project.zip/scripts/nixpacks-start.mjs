// ============================================================
// nixpacks-start — نقطه ورود runtime برای بیلدهای Nixpacks
// (داکپلوی / Coolify / Railway و…)
//
// این اسکریپت مشکل اصلی PaaS را حل می‌کند: «با هر دیپلوی جدید
// دیتابیس موقتیِ داخل ایمیج از نو ساخته می‌شد و همه داده‌ها
// پاک می‌شدند». حالا دیتابیس روی والیوم ماندگار (مثلاً /data)
// نگه داشته می‌شود و این اسکریپت در «شروعِ» کانتینر تصمیم می‌گیرد:
//
//  ۱) تعیین مسیر دیتابیس — اولویت:
//     a) متغیر DATABASE_URL پنل (file:…)
//     b) پوشهٔ والیوم /data (اگر موجود باشد — Dokploy: Advanced →
//        Volumes/Mounts → Mount Path = /data) → /data/custom.db
//     c) مسیر موقتی داخل ایمیج (مثل قبل — با هشدار بلند)
//  ۲) اگر دیتابیس «وجود ندارد» → نصب تازه:
//     کپی دیتابیس آمادهٔ پخت‌شده در ایمیج (سریع، بدون نیاز به ابزار)
//     یا در نبودش: ساخت کامل با prisma + bootstrap + بک‌فیل‌ها
//  ۳) اگر دیتابیس «موجود» و نسخهٔ مهرشده != نسخهٔ ایمیج → به‌روزرسانی:
//     بکاپ خودکار (قابل مشاهده در تنظیمات ← پشتیبان‌گیری) →
//     همگام‌سازی اسکیما → زنجیرهٔ بک‌فیل‌ها (idempotent) → داده‌ها حفظ!
//  ۴) اگر نسخه مهر خورده == نسخهٔ ایمیج → شروع سریع (بدون هیچ کاری)
//  ۵) AUTH_SECRET پایدار: از والیوم خوانده/در آن ذخیره می‌شود تا
//     نشست‌های ورود با هر ری‌دیپلوی بی‌اعتبار نشوند
//  ۶) نوشتن .env نهایی (ریشه + standalone) و اجرای سرور standalone
//     با HOSTNAME=0.0.0.0 روی PORT پلتفرم + هدایت سیگنال‌ها
//
// همه مراحل fail-soft هستند — حتی اگر ابزار prisma/tsx در دسترس
// نباشد، سرور با دیتابیس موجود بالا می‌آید.
// اجرا (nixpacks.toml):  node scripts/nixpacks-start.mjs
// ============================================================
import { existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, statSync, readdirSync, unlinkSync } from "fs";
import { spawn } from "child_process";
import { randomBytes } from "crypto";
import path from "path";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pkg = JSON.parse(readFileSync(path.join(root, "package.json"), "utf8"));
const pkgVersion = pkg.version;

// همان دنبالهٔ نصب تمیز VPS/داکر — همیشه idempotent
const BACKFILLS = [
  "backfill-v8.ts", // قالب‌نامه‌های آماده
  "backfill-v28.ts", // تعطیلات رسمی ۱۴۰۵ + شیفت‌ها و ساعت استاندارد
  "backfill-v281.ts", // اطلاعیه ۲.۸.۱ (پشتیبان‌گیری/بازیابی)
  "backfill-v29.ts", // مجوز مدیریت کار + اطلاعیه ۲.۹.۰
  "backfill-v291.ts",
  "backfill-v292.ts",
  "backfill-v293.ts",
  "backfill-v294.ts",
  "backfill-v295.ts",
  "backfill-v296.ts",
  "backfill-v297.ts", // اطلاعیه ۲.۹.۷ + مهر نسخه در دیتابیس
  "backfill-v298.ts", // رفع کرش RoleEditor + اطلاعیه ۲.۹.۸
  "backfill-v299.ts", // مدل دوم پاداش (برآورد بودجه) + اطلاعیه ۲.۹.۹
  "backfill-v2910.ts", // لیست نفرات + سهم تیم‌ها در برآورد بودجه + اطلاعیه ۲.۹.۱۰
  "backfill-v2911.ts", // انتخاب چندتایی/حذف/ترک کار + خالص پرداختی طبقات + اطلاعیه ۲.۹.۱۱
];

const log = (m) => console.log(m);
const warn = (m) => console.warn(m);

// ------------------------------------------------------------
// ابزار کمکی
// ------------------------------------------------------------
function cmpVersion(a, b) {
  const pa = String(a || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const pb = String(b || "0").split(".").map((x) => parseInt(x, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const d = (pa[i] || 0) - (pb[i] || 0);
    if (d !== 0) return d;
  }
  return 0;
}

/** فایل‌بینی مسیر از file:… (مطلق‌سازی نسبت به ریشه) */
function fileFromUrl(url) {
  const p = String(url).replace(/^file:/i, "").split("?")[0].trim();
  return path.isAbsolute(p) ? p : path.resolve(root, p);
}

/** اجرای فرمان و انتظار برای پایان — خروجی به لاگ دیپلوی می‌رود */
function run(cmd, args, extraEnv = {}) {
  return new Promise((resolve) => {
    const child = spawn(cmd, args, {
      cwd: root,
      stdio: "inherit",
      env: { ...process.env, ...extraEnv },
    });
    child.on("error", () => resolve(false));
    child.on("exit", (code) => resolve(code === 0));
  });
}

/** اجرای backfill.ts — با tsx لوکال (node_modules) یا npx (دانلود) */
async function runTs(script, dbUrl) {
  const localTsx = path.join(root, "node_modules", ".bin", "tsx");
  if (existsSync(localTsx)) {
    return run("node", [localTsx, path.join("scripts", script)], { DATABASE_URL: dbUrl });
  }
  return run("npx", ["--yes", "tsx@4.19.2", path.join("scripts", script)], { DATABASE_URL: dbUrl });
}

/** prisma db push — بدون accept-data-loss؛ در صورت نیاز با هشدار تلاش مجدد */
async function dbPush(dbUrl, allowDataLoss = false) {
  const localPrisma = path.join(root, "node_modules", ".bin", "prisma");
  const base = ["db", "push", "--skip-generate"];
  let ok;
  if (existsSync(localPrisma)) {
    ok = await run("node", [localPrisma, ...base], { DATABASE_URL: dbUrl });
  } else {
    ok = await run("npx", ["--yes", "prisma@6.19.2", ...base], { DATABASE_URL: dbUrl });
  }
  if (!ok && !allowDataLoss) {
    // تغییر اسکیمای مخرب لازم است (نادر) — با هشدار بلند و اتکا به بکاپ
    warn("  ⚠ همگام‌سازی اسکیما نیازمند پذیرش تغییر مخرب بود — یک بار دیگر با پرچم مربوطه تلاش می‌شود (بکاپ قبلی گرفته شد)");
    return dbPush(dbUrl, true);
  }
  return ok;
}

/** خواندن مهر نسخه از دیتابیس — SystemSetting «app_version» */
async function readVersionStamp(dbUrl) {
  const { PrismaClient } = await import("@prisma/client");
  const db = new PrismaClient({ datasources: { db: { url: dbUrl } } });
  try {
    const row = await db.systemSetting.findUnique({ where: { key: "app_version" } });
    return row ? String(row.value) : "";
  } finally {
    await db.$disconnect();
  }
}

// ------------------------------------------------------------
// ۱) تعیین مسیر دیتابیس (runtime)
// ------------------------------------------------------------
const DATA_DIR = process.env.HRMS_DATA_DIR || "/data";
let dbUrl = (process.env.DATABASE_URL || "").trim();
let persistent = true; // آیا داده‌ها از ری‌دیپلوی جان سالم به در می‌برند؟
let volumeDetected = "";

if (dbUrl.startsWith("file:")) {
  const p = fileFromUrl(dbUrl);
  dbUrl = "file:" + p;
  volumeDetected = "متغیر DATABASE_URL پنل";
} else {
  if (dbUrl) {
    // دیتابیس غیر-SQLite — این سامانه SQLite است؛ مثل رفتار prebuild نادیده می‌گیریم
    warn(`⚠ DATABASE_URL پنل (${dbUrl.slice(0, 40)}…) پایگاه غیر-SQLite است — نادیده گرفته شد.`);
  }
  if (existsSync(DATA_DIR) && statSync(DATA_DIR).isDirectory()) {
    dbUrl = "file:" + path.join(DATA_DIR, "custom.db");
    volumeDetected = `والیوم ${DATA_DIR} (Dokploy → Advanced → Volumes)`;
  } else {
    dbUrl = "file:" + path.join(root, "db", "custom.db");
    persistent = false;
  }
}
const dbFile = fileFromUrl(dbUrl);
const dbDir = path.dirname(dbFile);
const preparedDb = path.join(root, "db", "custom.db"); // پخت‌شده در زمان بیلد

log(`▪ HRMS ${pkgVersion} — runtime Nixpacks`);
log(`▪ دیتابیس: ${dbFile}${volumeDetected ? ` (منبع: ${volumeDetected})` : ""}`);
if (!persistent) {
  warn("⚠⚠ والیوم ماندگار تشخیص داده نشد! داده‌ها فقط تا ری‌استارت بعدی زنده می‌مانند.");
  warn("   برای ماندگاری: در داکپلوی Advanced → Volumes/Mounts یک Volume با Mount Path=/data");
  warn("   بسازید و ری‌دیپلوی کنید (راهنما: DOCPLOY-GUIDE.md بخش والیوم).");
}

// ------------------------------------------------------------
// ۲) AUTH_SECRET پایدار (نشست‌ها با ری‌دیپلوی بی‌اعتبار نشوند)
// ------------------------------------------------------------
let authSecret = (process.env.AUTH_SECRET || "").trim();
if (!authSecret) {
  const secretFile = path.join(dbDir, ".auth-secret");
  try {
    if (existsSync(secretFile)) {
      authSecret = readFileSync(secretFile, "utf8").trim();
    } else {
      authSecret = randomBytes(32).toString("hex");
      try {
        mkdirSync(dbDir, { recursive: true });
        writeFileSync(secretFile, authSecret + "\n", { mode: 0o600 });
        if (persistent) log("✓ کلید امضای نشست‌ها ساخته و در والیوم ذخیره شد (برای ری‌دیپلویهای بعدی پایدار می‌ماند)");
      } catch {
        /* فقط best-effort — در حالت فقط-خواندنی نادیده می‌گیریم */
      }
    }
  } catch {
    authSecret = randomBytes(32).toString("hex");
  }
}

// ------------------------------------------------------------
// ۳) آماده‌سازی/به‌روزرسانی دیتابیس
// ------------------------------------------------------------
const dbExists = existsSync(dbFile) && statSync(dbFile).size > 0;

if (!dbExists) {
  // ---------- نصب تازه ----------
  log("▪ نصب تازه — دیتابیس والیوم برای اولین اجرا آماده می‌شود…");
  mkdirSync(dbDir, { recursive: true });
  let done = false;
  if (existsSync(preparedDb) && path.resolve(preparedDb) !== path.resolve(dbFile)) {
    try {
      copyFileSync(preparedDb, dbFile);
      log("  ✓ دیتابیس آمادهٔ بیلد (اسکیما + مدیر + تنظیمات قانونی ۱۴۰۵ + داده پایه) روی والیوم کپی شد");
      done = true;
    } catch (e) {
      warn(`  ⚠ کپی دیتابیس آماده ناموفق بود (${String(e.message || e).split("\n")[0]}) — ساخت از ابتدا…`);
    }
  }
  if (!done && !existsSync(dbFile)) {
    // ساخت کامل با ابزار (مسیر جایگزین — وقتی دیتابیس آماده در ایمیج نباشد)
    const okPush = await dbPush(dbUrl);
    if (okPush) {
      await run("node", [path.join("scripts", "docker-bootstrap.mjs")], { DATABASE_URL: dbUrl });
      for (const bf of BACKFILLS) await runTs(bf, dbUrl);
    } else {
      warn("  ⚠ ساخت دیتابیس از ابتدا ناموفق بود — سرور ممکن است خطا بدهد (لاگ بالا را ببینید)");
    }
  }
  if (process.env.HRMS_DEMO === "1") {
    log("▪ حالت نمایشی — کاربران نمونه بارگذاری می‌شود…");
    await runTs("../prisma/seed.ts", dbUrl);
  }
  if (process.env.HRMS_ADMIN_PASSWORD) {
    await run("node", [path.join("scripts", "docker-set-admin-password.mjs")], { DATABASE_URL: dbUrl });
    log("  ✓ رمز مدیر از متغیر HRMS_ADMIN_PASSWORD اعمال شد");
  } else if (done) {
    log("  ⚠ ورود پیش‌فرض: admin / admin123 — رمز را پس از اولین ورود تغییر دهید");
  }
} else {
  // ---------- دیتابیس موجود: مهر نسخه را بخوان ----------
  let stamp = "";
  let stampOk = true;
  try {
    stamp = await readVersionStamp(dbUrl);
  } catch (e) {
    stampOk = false;
    warn(`  ⚠ خواندن مهر نسخه ناموفق بود (${String(e.message || e).split("\n")[0]}) — مسیر به‌روزرسانی اجرا می‌شود`);
  }
  if (stampOk && stamp && cmpVersion(stamp, pkgVersion) === 0) {
    log("✓ دیتابیس موجود هم‌نسخهٔ ایمیج است — شروع سریع (بدون تغییر)");
  } else if (stampOk && stamp && cmpVersion(stamp, pkgVersion) > 0) {
    warn(`⚠ نسخهٔ دیتابیس (${stamp}) جدیدتر از نسخهٔ ایمیج (${pkgVersion}) است — احتمالاً rollback!`);
    warn("   اسکیما و داده‌ها دست نمی‌خورند؛ اسکریپت با همان دیتابیس فعلی ادامه می‌دهد.");
  } else {
    // ---------- به‌روزرسانی — قلب راه‌حل «آپدیت بدون پاک شدن داده‌ها» ----------
    log(`▪ به‌روزرسانی: دیتابیس موجود (نسخهٔ ${stamp || "نامشخص"}) → ${pkgVersion} — داده‌ها حفظ می‌شوند…`);
    // ۱) بکاپ خودکار — با الگوی نام‌گذاری خود سامانه تا در
    //    «تنظیمات ← پشتیبان‌گیری» دیده و قابل دانلود/بازیابی باشد
    try {
      const bdir = path.join(dbDir, "backups");
      mkdirSync(bdir, { recursive: true });
      const ts = new Date().toISOString().replace(/[:T]/g, "-").replace(/\..+$/, "");
      const bname = `hrms-backup-auto-preupdate-${ts}.db`;
      copyFileSync(dbFile, path.join(bdir, bname));
      // چرخش: حداکثر ۵ بکاپ خودکار نگه می‌داریم
      const autos = readdirSync(bdir)
        .filter((f) => /^hrms-backup-auto-preupdate-.*\.db$/.test(f))
        .sort()
        .slice(0, -5);
      for (const f of autos) { try { unlinkSync(path.join(bdir, f)); } catch { /* best-effort */ } }
      log(`  ✓ بکاپ خودکار پیش از به‌روزرسانی: ${bname} (در تنظیمات ← پشتیبان‌گیری قابل دانلود است)`);
    } catch (e) {
      warn(`  ⚠ بکاپ خودکار ناموفق بود (${String(e.message || e).split("\n")[0]}) — ادامه می‌دهیم`);
    }
    // ۲) همگام‌سازی اسکیما (غیرمخرب در حد امکان)
    const okPush = await dbPush(dbUrl);
    if (!okPush) warn("  ⚠ همگام‌سازی اسکیما رد شد — با همان اسکیمای فعلی ادامه می‌دهیم");
    // ۳) زنجیرهٔ بک‌فیل‌ها — idempotent، داده‌های کاربر دست نمی‌خورد
    let failed = 0;
    for (const bf of BACKFILLS) {
      const p = path.join(root, "scripts", bf);
      if (!existsSync(p)) continue;
      const ok = await runTs(bf, dbUrl);
      if (!ok) failed++;
    }
    if (failed > 0) warn(`  ⚠ ${failed} بک‌فیل ناموفق — در ری‌استارت بعدی دوباره تلاش می‌شود`);
    else log("  ✓ داده پایه و مهر نسخه به‌روزرسانی شد — کاربران و داده‌ها حفظ شدند");
  }
}

// ------------------------------------------------------------
// ۴) .env نهایی (ریشه + standalone) — سرور standalone همین را می‌خواند
// ------------------------------------------------------------
const setVar = (content, name, val) => {
  const re = new RegExp(`^${name}=.*$`, "m");
  if (re.test(content)) return content.replace(re, `${name}=${val}`);
  let c = content;
  if (c && !c.endsWith("\n")) c += "\n";
  return c + `${name}=${val}\n`;
};
const finalEnv = { DATABASE_URL: dbUrl, AUTH_SECRET: authSecret, APP_VERSION: pkgVersion };
for (const envPath of [path.join(root, ".env"), path.join(root, ".next", "standalone", ".env")]) {
  try {
    const cur = existsSync(envPath) ? readFileSync(envPath, "utf8") : "";
    let next = cur;
    for (const [k, v] of Object.entries(finalEnv)) next = setVar(next, k, v);
    if (next !== cur) writeFileSync(envPath, next);
  } catch { /* best-effort — متغیرهای spawn به‌هرحال اولویت دارند */ }
}

// ------------------------------------------------------------
// ۵) اجرای سرور standalone + هدایت سیگنال‌ها (stop/redeploy تمیز)
// ------------------------------------------------------------
const serverPath = path.join(root, ".next", "standalone", "server.js");
if (!existsSync(serverPath)) {
  console.error(`✗ سرور ساخته‌شده پیدا نشد: ${serverPath} — بیلد ناقص است`);
  process.exit(1);
}
log(`▪ راه‌اندازی سرور HRMS ${pkgVersion} روی پورت ${process.env.PORT || 3000}…`);
const child = spawn("node", [serverPath], {
  cwd: root,
  stdio: "inherit",
  env: {
    ...process.env, // PORT پلتفرم و بقیهٔ متغیرها
    ...finalEnv, // مقادیر نهایی‌شده (اولویت بر .env)
    HOSTNAME: "0.0.0.0",
  },
});
for (const sig of ["SIGTERM", "SIGINT"]) {
  process.on(sig, () => {
    try { child.kill(sig); } catch { /* فرزند احتمالاً بسته شده */ }
  });
}
child.on("error", (e) => {
  console.error("✗ اجرای سرور ناموفق بود:", e.message);
  process.exit(1);
});
child.on("exit", (code, signal) => {
  process.exit(code == null ? (signal ? 1 : 0) : code);
});

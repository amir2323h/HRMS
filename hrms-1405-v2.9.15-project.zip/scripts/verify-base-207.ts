// راستی‌آزمایی کارت طبقه‌بندی با پایه ۲۰,۷۰۰,۰۰۰ تومان (۲۰۷,۰۰۰,۰۰۰ ریال)
// حالت الف (پیش‌فرض v2.9.15): جدول با ارقام ۱۴۰۵ ثبت شده — بدون تبدیل
// حالت ب: تبدیل مبنای سال قبل به ۱۴۰۵ (افزایش قانونی فعال صریح — فقط برای جدول‌های ۱۴۰۴)
import { LEGAL_DEFAULTS_1405, applyLegalIncrease, gradeNetSimple } from "../src/lib/payroll/engine";

const T = (r: number) => (r / 10).toLocaleString("fa-IR"); // ریال → تومان
const P_ON = { ...LEGAL_DEFAULTS_1405, legalIncreaseEnabled: true };

function report(tag: string, baseRials: number, p = LEGAL_DEFAULTS_1405) {
  const b = gradeNetSimple(baseRials, p);
  console.log(`\n=== ${tag} ===`);
  console.log(`حقوق پایه:            ${T(b.base)} تومان`);
  console.log(`حق مسکن:              ${T(b.housing)} تومان`);
  console.log(`بن کارگری:            ${T(b.grocery)} تومان`);
  console.log(`جمع دریافتی (ناخالص): ${T(b.gross)} تومان`);
  console.log(`بیمه ۷٪ سهم کارگر:    ${T(b.sso)} تومان`);
  console.log(`مشمول مالیات:         ${T(b.taxable)} تومان  (سقف معافیت ماهانه: ${T(400_000_000)} تومان)`);
  console.log(`مالیات:               ${T(b.tax)} تومان`);
  console.log(`خالص پرداختی:         ${T(b.net)} تومان`);
}

// حالت الف: ۲۰.۷ میلیون تومان = حقوق پایهٔ ۱۴۰۵ — پیش‌فرض v2.9.15 (افزایش خاموش)
report("حالت الف — پایهٔ ۲۰,۷۰۰,۰۰۰ تومان مبنای ۱۴۰۵ (پیش‌فرض v2.9.15 — بدون افزایش قانونی)", 207_000_000);

// حالت ب: ۲۰.۷ میلیون تومان = جدول سال قبل → افزایش قانونی ۴۵٪ + ثابت ماهانه (فعال صریح)
const inc = applyLegalIncrease(207_000_000, P_ON);
console.log(`\n=== حالت ب — تبدیل پایهٔ سال قبل به ۱۴۰۵ ===`);
console.log(`فرمول: ۲۰۷,۰۰۰,۰۰۰ × ۱٫۴۵ + ۱۵,۵۸۶,۴۷۰ = ${T(inc.base)} ریال = ${T(inc.base)} تومان (پس از افزایش قانونی)`);
report("حالت ب — خالص با مبنای ۱۴۰۵", inc.base);

// مرجع: حداقل‌بگیر رسمی ۱۴۰۵ (کنترل صحت ثابت‌ها)
report("کنترل — حداقل‌بگیر رسمی ۱۴۰۵", 166_255_500);

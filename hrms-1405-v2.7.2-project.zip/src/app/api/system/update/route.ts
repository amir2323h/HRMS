import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireAuth } from "@/lib/auth";
import { handle, audit } from "@/lib/api-helpers";
import { readFile } from "fs/promises";
import { spawn } from "child_process";

// ============================================================
// اجرای به‌روزرسانی از پنل — POST (فقط مدیر کل سیستم SUPER_ADMIN)
//  فرمان «hrms update --latest --yes» به‌صورت جدا از سرویس اجرا می‌شود
//  (detached) چون به‌روزرسانی در پایان سرویس را ری‌استارت می‌کند.
//  GET: وضعیت جاری + دنباله لاگ برای نمایش زنده در پنل
// وضعیت در SystemSetting «update_state» نگه داشته می‌شود.
// ============================================================

const LOG_FILE = "/tmp/hrms-web-update.log";
const STATE_KEY = "update_state";

interface UpdateState {
  startedAt: string; // ISO
  targetVersion: string;
  startedBy: string;
  running: boolean;
  finishedAt?: string;
}

async function readState(): Promise<UpdateState | null> {
  const row = await db.systemSetting.findUnique({ where: { key: STATE_KEY } });
  if (!row) return null;
  try {
    return JSON.parse(row.value) as UpdateState;
  } catch {
    return null;
  }
}

async function writeState(s: UpdateState): Promise<void> {
  await db.systemSetting.upsert({
    where: { key: STATE_KEY },
    update: { value: JSON.stringify(s) },
    create: { key: STATE_KEY, value: JSON.stringify(s) },
  });
}

/** آیا فرمان hrms روی این سرور موجود است؟ */
async function hrmsAvailable(): Promise<boolean> {
  return new Promise((resolve) => {
    const p = spawn("bash", ["-lc", "command -v hrms >/dev/null 2>&1 && echo FOUND"], { timeout: 5000 });
    let out = "";
    p.stdout.on("data", (d) => (out += String(d)));
    p.on("error", () => resolve(false));
    p.on("close", (code) => resolve(code === 0 && out.includes("FOUND")));
  });
}

/** اجرای جدا از هم — خروجی به لاگ؛ سرویس در پایان توسط خود آپدیت ری‌استارت می‌شود */
function launchUpdate(targetVersion: string, by: string): void {
  const child = spawn(
    "bash",
    ["-lc", `hrms update --latest --yes >"${LOG_FILE}" 2>&1`],
    { detached: true, stdio: "ignore", env: { ...process.env, TERM: "dumb", HRMS_NO_SPIN: "1" } }
  );
  child.unref();
  void targetVersion;
  void by;
}

export async function GET(req: NextRequest) {
  return handle(async () => {
    requireAuth(req, ["SUPER_ADMIN"]); // فقط مدیر کل سیستم
    const state = await readState();
    let log = "";
    try {
      log = await readFile(LOG_FILE, "utf8");
    } catch {
      /* هنوز لاگی نیست */
    }
    const lines = log.split("\n").filter(Boolean).slice(-60);
    // وضعیت «running»: ساده — اگر لاگ در ۹۰ ثانیه اخیر نوشته شده باشد و finishedAt نزد
    return {
      state,
      log: lines.join("\n"),
      logFile: LOG_FILE,
    };
  });
}

export async function POST(req: NextRequest) {
  return handle(async () => {
    const session = requireAuth(req, ["SUPER_ADMIN"]); // فقط مدیر کل سیستم
    const b = await req.json().catch(() => ({}) as Record<string, unknown>);
    const targetVersion = String((b as { version?: string }).version || "").trim();

    const current = (process.env.APP_VERSION || "").trim();
    if (!current) {
      return Response.json(
        { error: "نسخه نصب‌شده قابل تشخیص نیست (APP_VERSION در env نیست) — به‌روزرسانی از پنل ممکن نیست؛ از ترمینال با hrms update انجام دهید." },
        { status: 400 }
      );
    }
    if (!(await hrmsAvailable())) {
      return Response.json(
        { error: "فرمان hrms روی این سرور یافت نشد — به‌روزرسانی از پنل فقط روی سرور با نصب استاندارد (hrms در PATH) کار می‌کند." },
        { status: 400 }
      );
    }
    const running = await readState();
    if (running?.running && Date.now() - new Date(running.startedAt).getTime() < 20 * 60 * 1000) {
      return Response.json({ error: "یک به‌روزرسانی هم‌اکنون در حال اجراست — چند دقیقه صبر کنید و وضعیت را دنبال کنید." }, { status: 400 });
    }

    await writeState({
      startedAt: new Date().toISOString(),
      targetVersion: targetVersion || "latest",
      startedBy: session.fullName,
      running: true,
    });
    launchUpdate(targetVersion, session.fullName);
    await audit(
      session,
      "UPDATE",
      "SYSTEM",
      "update",
      `شروع به‌روزرسانی سامانه از پنل به ${targetVersion || "آخرین نسخه گیت‌هاب"} (hrms update --latest --yes)`
    );
    return { started: true, targetVersion: targetVersion || "latest", note: "فرمان به‌روزرسانی اجرا شد — سرویس در پایان خودکار ری‌استارت می‌شود." };
  });
}

"use client";

import { useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollText, Search, ChevronLeft, ChevronRight, Eye } from "lucide-react";
import { useApi } from "@/lib/client";
import { toFaDigits, isoToJalaliStr, formatDateJ } from "@/lib/jalali";

interface AuditRow {
  id: string; userName: string; action: string; entity: string; entityId: string;
  summary: string; before: unknown; after: unknown; createdAt: string;
}

const ACTION_LABELS: Record<string, { label: string; cls: string }> = {
  CREATE: { label: "ایجاد", cls: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" },
  UPDATE: { label: "ویرایش", cls: "bg-amber-100 text-amber-700 hover:bg-amber-100" },
  DELETE: { label: "حذف", cls: "bg-rose-100 text-rose-700 hover:bg-rose-100" },
  LOGIN: { label: "ورود", cls: "bg-slate-100 text-slate-600 hover:bg-slate-100" },
  LOGOUT: { label: "خروج", cls: "bg-slate-100 text-slate-600 hover:bg-slate-100" },
  CALC: { label: "محاسبه", cls: "bg-teal-100 text-teal-700 hover:bg-teal-100" },
  REVERSE_CALC: { label: "محاسبه معکوس", cls: "bg-teal-100 text-teal-800 hover:bg-teal-100" },
  EXPORT: { label: "دریافت خروجی", cls: "bg-indigo-100 text-indigo-700 hover:bg-indigo-100" },
  APPROVE: { label: "تأیید", cls: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100" },
};

const ENTITY_LABELS: Record<string, string> = {
  EMPLOYEE: "کارمند", GRADE: "طبقه شغلی", DEPARTMENT: "دپارتمان", SETTINGS: "تنظیمات",
  PAYSLIP: "فیش حقوقی", PERIOD: "دوره حقوق", DOCUMENT: "سند", USER: "کاربر",
  SYSTEM: "سامانه", PAYROLL: "حقوق", LEAVE_REQUEST: "درخواست مرخصی", ADVANCE_REQUEST: "درخواست مساعده",
  SSO: "خروجی بیمه", TAX: "خروجی مالیاتی", BANK: "خروجی بانکی", COST_REPORT: "گزارش هزینه",
};

export function AuditView() {
  const [q, setQ] = useState("");
  const [action, setAction] = useState("all");
  const [page, setPage] = useState(1);
  const [detail, setDetail] = useState<AuditRow | null>(null);

  const query = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (action !== "all") p.set("action", action);
    p.set("page", String(page));
    return `/api/audit?${p.toString()}`;
  }, [q, action, page]);

  const { data, loading } = useApi<{ logs: AuditRow[]; total: number; page: number; pageCount: number }>(query, [q, action, page]);
  const logs = data?.logs || [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[220px]">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input className="pr-9" placeholder="جستجو در توضیحات، کاربر..." value={q} onChange={(e) => { setQ(e.target.value); setPage(1); }} />
        </div>
        <Select value={action} onValueChange={(v) => { setAction(v); setPage(1); }}>
          <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه اقدامات</SelectItem>
            {Object.entries(ACTION_LABELS).map(([v, a]) => <SelectItem key={v} value={v}>{a.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Badge variant="outline" className="tabular-nums h-9 px-3 flex items-center">{toFaDigits(data?.total || 0)} رکورد</Badge>
      </div>

      <Card className="rounded-2xl overflow-hidden">
        <CardContent className="p-0">
          {loading ? (
            <div className="p-4 space-y-2">{[0, 1, 2, 3, 4, 5].map((i) => <Skeleton key={i} className="h-10" />)}</div>
          ) : logs.length === 0 ? (
            <div className="py-16 text-center">
              <ScrollText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">رکوردی یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50/80">
                    <TableHead className="text-right">زمان</TableHead>
                    <TableHead className="text-right">کاربر</TableHead>
                    <TableHead className="text-right">اقدام</TableHead>
                    <TableHead className="text-right">موجودیت</TableHead>
                    <TableHead className="text-right">توضیحات</TableHead>
                    <TableHead className="text-center">جزئیات</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.map((l) => {
                    const a = ACTION_LABELS[l.action] || { label: l.action, cls: "bg-slate-100 text-slate-600 hover:bg-slate-100" };
                    return (
                      <TableRow key={l.id} className="hover:bg-teal-50/40">
                        <TableCell className="text-xs text-muted-foreground tabular-nums whitespace-nowrap">
                          {formatDateJ(isoToJalaliStr(l.createdAt))}
                        </TableCell>
                        <TableCell className="text-sm font-medium">{l.userName}</TableCell>
                        <TableCell><Badge className={a.cls}>{a.label}</Badge></TableCell>
                        <TableCell className="text-xs text-muted-foreground">{ENTITY_LABELS[l.entity] || l.entity}</TableCell>
                        <TableCell className="text-sm max-w-[380px] truncate" title={l.summary}>{l.summary}</TableCell>
                        <TableCell className="text-center">
                          {(l.before || l.after) ? (
                            <button className="p-1.5 rounded-lg hover:bg-teal-100 text-teal-600" onClick={() => setDetail(l)} title="مشاهده تغییرات">
                              <Eye className="w-4 h-4" />
                            </button>
                          ) : "—"}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* صفحه‌بندی */}
      {(data?.pageCount || 0) > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button
            className="p-2 rounded-lg border hover:bg-slate-50 disabled:opacity-40"
            disabled={page <= 1}
            onClick={() => setPage((p) => p - 1)}
            aria-label="صفحه قبل"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <span className="text-sm text-muted-foreground tabular-nums">
            صفحه {toFaDigits(page)} از {toFaDigits(data?.pageCount || 1)}
          </span>
          <button
            className="p-2 rounded-lg border hover:bg-slate-50 disabled:opacity-40"
            disabled={page >= (data?.pageCount || 1)}
            onClick={() => setPage((p) => p + 1)}
            aria-label="صفحه بعد"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* جزئیات تغییر */}
      <Dialog open={!!detail} onOpenChange={(v) => !v && setDetail(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-base">{detail?.summary}</DialogTitle>
          </DialogHeader>
          {detail && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-xs font-bold text-rose-700 mb-2 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-rose-500" /> وضعیت قبل
                </p>
                <pre className="text-[11px] bg-rose-50 border border-rose-100 rounded-xl p-3 overflow-x-auto leading-5" dir="ltr">
                  {detail.before ? JSON.stringify(detail.before, null, 2) : "—"}
                </pre>
              </div>
              <div>
                <p className="text-xs font-bold text-emerald-700 mb-2 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" /> وضعیت بعد
                </p>
                <pre className="text-[11px] bg-emerald-50 border border-emerald-100 rounded-xl p-3 overflow-x-auto leading-5" dir="ltr">
                  {detail.after ? JSON.stringify(detail.after, null, 2) : "—"}
                </pre>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

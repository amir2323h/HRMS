"use client";

// ============================================================
// درخواست‌ها و تأییدها — گردش دوسطحی مرخصی/مساعده + نامه‌ها
// مدیر واحد (مرحله ۱) ← مدیر منابع انسانی (مرحله ۲) + گزارش
// ============================================================
import { useEffect, useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { Inbox, CheckCircle2, XCircle, Clock, FileText, Printer, Search, Eye, PenLine, Plus, Table2, Trash2 } from "lucide-react";
import { api, useApi } from "@/lib/client";
import { groupFa, LEAVE_TYPE_LABELS, REQUEST_STATUS_LABELS, LETTER_STATUS_LABELS } from "@/lib/format";
import { toFaDigits, formatDateJ, todayJalaliStr } from "@/lib/jalali";
import { Money } from "../money-input";
import { JalaliDatePicker } from "../jalali-datepicker";
import { LetterPrintButtons, LetterSignatureBadge } from "../letter-print-buttons";
import { LetterRichEditor, LetterRichBodyPreview } from "../letter-rich-editor";

interface LeaveRow {
  id: string; employeeId: string; employeeName: string; personnelCode: string; department: string;
  type: string; startDateJ: string; endDateJ: string; days: number; reason: string; status: string;
  dmStatus: string; dmBy: string; dmAt: string | null; hrStatus: string; hrBy: string; hrAt: string | null;
  rejectReason: string; createdAt: string;
}
interface AdvanceRow {
  id: string; employeeId: string; employeeName: string; personnelCode: string; department: string;
  amount: number; installments: number; reason: string; status: string;
  dmStatus: string; dmBy: string; dmAt: string | null; hrStatus: string; hrBy: string; hrAt: string | null;
  rejectReason: string; createdAt: string;
}
interface LetterRow {
  id: string; number: string; source: string; category: string; templateTitle: string; employeeName: string; personnelCode: string;
  department: string; recipient: string; title: string; body: string; bodyHtml?: string | null; status: string; decidedBy: string;
  decidedAt?: string | null; decisionNote: string; signatureCode?: string | null; createdAt: string; createdBy?: string;
  signerName?: string; signerTitle?: string; items?: { title: string; code: string }[];
}

const LETTER_CATEGORY_LABELS: Record<string, string> = { GENERAL: "عمومی", HR: "منابع انسانی", FINANCE: "مالی", ADMIN: "اداری" };

/** عناوین پیش‌فرض گیرنده نامه — دراپ‌داون فرم ثبت نامه دستی + گزینه «سایر» تایپ دستی */
const RECIPIENT_TITLES = ["جناب آقای", "سرکار خانم", "مدیریت محترم", "سازمان محترم"];
const RECIPIENT_CUSTOM = "__CUSTOM__";
const SIGNER_CUSTOM = "__CUSTOM__";

const STATUS_BADGE: Record<string, string> = {
  PENDING_DM: "bg-amber-100 text-amber-700 hover:bg-amber-100",
  PENDING_HR: "bg-sky-100 text-sky-700 hover:bg-sky-100",
  APPROVED: "bg-emerald-100 text-emerald-700 hover:bg-emerald-100",
  REJECTED: "bg-rose-100 text-rose-700 hover:bg-rose-100",
};

export function ApprovalsView({
  canApproveDept,
  canApproveHr,
  canSeeLetters,
  canDecideLetters,
  canManualLetters,
}: {
  canApproveDept: boolean;
  canApproveHr: boolean;
  canSeeLetters: boolean; // letters:approve یا letters:manual — دسترسی به بخش نامه‌ها
  canDecideLetters: boolean; // letters:approve — صندوق تأیید نامه‌های در انتظار
  canManualLetters: boolean; // letters:manual — ثبت نامه دستی
}) {
  // تب پیش‌فرض: صندوق تأیید برای مدیران درخواست‌ها؛ بخش نامه‌ها برای نقش اداری صرف
  const [tab, setTab] = useState(canApproveDept || canApproveHr ? "inbox" : "letters");
  const [q, setQ] = useState("");
  const { toast } = useToast();
  const reqQuery = useMemo(() => {
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    return `/api/requests?${p.toString()}`;
  }, [q]);
  const canRequests = canApproveDept || canApproveHr;
  const requests = useApi<{ leaves: LeaveRow[]; advances: AdvanceRow[]; counts: { pendingDm: number; pendingHr: number; approved: number; rejected: number } }>(canRequests ? reqQuery : null, [q]);
  const letters = useApi<{ letters: LetterRow[] }>(canSeeLetters && canDecideLetters ? "/api/letters?status=PENDING" : null);
  // همه نامه‌ها برای گزارش (تأییدشده/ردشده/در انتظار)
  const allLetters = useApi<{ letters: LetterRow[] }>(canSeeLetters ? "/api/letters" : null);

  const leaves = requests.data?.leaves || [];
  const advances = requests.data?.advances || [];
  const pendingLetters = letters.data?.letters || [];
  const allLetterRows = allLetters.data?.letters || [];
  const counts = requests.data?.counts;

  // فیلتر بر اساس نقش: مدیر واحد فقط مرحله خودش را می‌بیند (سمت سرور محدود کرده)
  const myLeaves = leaves.filter((l) =>
    canApproveHr ? true : l.status === "PENDING_DM" || l.status === "REJECTED" || l.status === "APPROVED",
  );
  const myAdvances = advances.filter((a) =>
    canApproveHr ? true : a.status === "PENDING_DM" || a.status === "REJECTED" || a.status === "APPROVED",
  );

  return (
    <div className="space-y-4">
      {/* آمار — فقط برای نقش‌های تأیید درخواست */}
      {canRequests && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatBox icon={<Clock className="w-4 h-4 text-amber-600" />} label="در انتظار مدیر واحد" value={counts?.pendingDm || 0} tone="amber" />
          <StatBox icon={<Clock className="w-4 h-4 text-sky-600" />} label="در انتظار منابع انسانی" value={counts?.pendingHr || 0} tone="sky" />
          <StatBox icon={<CheckCircle2 className="w-4 h-4 text-emerald-600" />} label="تأییدشده" value={counts?.approved || 0} tone="emerald" />
          <StatBox icon={<XCircle className="w-4 h-4 text-rose-600" />} label="ردشده" value={counts?.rejected || 0} tone="rose" />
        </div>
      )}

      <Tabs value={tab} onValueChange={setTab} dir="rtl">
        <TabsList className="w-full max-w-2xl mb-4">
          {canRequests && (
            <TabsTrigger value="inbox" className="flex-1 gap-1.5"><Inbox className="w-4 h-4" /> صندوق تأیید</TabsTrigger>
          )}
          {(canSeeLetters) && (
            <TabsTrigger value="letters" className="flex-1 gap-1.5">
              <FileText className="w-4 h-4" /> نامه‌ها {canDecideLetters && pendingLetters.length > 0 && <Badge className="bg-rose-500 text-white hover:bg-rose-500 text-[10px] px-1.5">{toFaDigits(pendingLetters.length)}</Badge>}
            </TabsTrigger>
          )}
          <TabsTrigger value="report" className="flex-1 gap-1.5"><Printer className="w-4 h-4" /> گزارش درخواست‌ها</TabsTrigger>
        </TabsList>

        {canRequests && (
        <TabsContent value="inbox" className="space-y-4">
          <div className="relative max-w-md">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <Input className="pr-9" placeholder="جستجو: نام کارمند یا دلیل..." value={q} onChange={(e) => setQ(e.target.value)} />
          </div>

          {/* مرخصی‌ها */}
          <Card className="rounded-2xl overflow-hidden">
            <CardHeader className="pb-3"><CardTitle className="text-sm flex items-center gap-2">درخواست‌های مرخصی ({toFaDigits(myLeaves.length)})</CardTitle></CardHeader>
            <CardContent className="p-0">
              {requests.loading ? (
                <div className="p-4 space-y-2">{[0, 1].map((i) => <Skeleton key={i} className="h-16" />)}</div>
              ) : myLeaves.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted-foreground">درخواستی در صف شما نیست.</p>
              ) : (
                <div className="divide-y">
                  {myLeaves.map((l) => (
                    <div key={l.id} className="p-4 flex flex-wrap items-center gap-3 hover:bg-slate-50/60">
                      <div className="min-w-[180px] flex-1">
                        <p className="text-sm font-medium">{l.employeeName} <span className="text-[10px] text-muted-foreground tabular-nums" dir="ltr">{l.personnelCode}</span></p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          <Badge variant="outline" className="text-[10px] ml-1">{LEAVE_TYPE_LABELS[l.type]}</Badge>
                          {formatDateJ(l.startDateJ)} تا {formatDateJ(l.endDateJ)} ({toFaDigits(l.days)} روز)
                          {l.reason && <span className="block mt-1">{l.reason}</span>}
                        </p>
                      </div>
                      <ApprovalTrail row={l} />
                      <DecisionButtons
                        disabled={l.status !== "PENDING_DM" && l.status !== "PENDING_HR"}
                        stage={l.status}
                        canDept={canApproveDept}
                        canHr={canApproveHr}
                        onDecide={(action, note) => decide("LEAVE", l.id, action, note, requests.refetch)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* مساعده‌ها */}
          <Card className="rounded-2xl overflow-hidden">
            <CardHeader className="pb-3"><CardTitle className="text-sm flex items-center gap-2">درخواست‌های مساعده ({toFaDigits(myAdvances.length)})</CardTitle></CardHeader>
            <CardContent className="p-0">
              {requests.loading ? (
                <div className="p-4 space-y-2">{[0, 1].map((i) => <Skeleton key={i} className="h-16" />)}</div>
              ) : myAdvances.length === 0 ? (
                <p className="py-10 text-center text-sm text-muted-foreground">درخواستی در صف شما نیست.</p>
              ) : (
                <div className="divide-y">
                  {myAdvances.map((a) => (
                    <div key={a.id} className="p-4 flex flex-wrap items-center gap-3 hover:bg-slate-50/60">
                      <div className="min-w-[180px] flex-1">
                        <p className="text-sm font-medium">{a.employeeName} <span className="text-[10px] text-muted-foreground tabular-nums" dir="ltr">{a.personnelCode}</span></p>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          <span className="font-bold text-slate-700"><Money amount={a.amount} /></span> در {toFaDigits(a.installments)} قسط
                          {a.reason && <span className="block mt-1">{a.reason}</span>}
                        </p>
                      </div>
                      <ApprovalTrail row={a} />
                      <DecisionButtons
                        disabled={a.status !== "PENDING_DM" && a.status !== "PENDING_HR"}
                        stage={a.status}
                        canDept={canApproveDept}
                        canHr={canApproveHr}
                        onDecide={(action, note) => decide("ADVANCE", a.id, action, note, requests.refetch)}
                      />
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        )}

        {canSeeLetters && (
          <TabsContent value="letters" className="space-y-4">
            {canManualLetters && (
              <ManualLetterSection onChanged={() => { allLetters.refetch(); letters.refetch(); }} />
            )}
            {canDecideLetters && (
              <LettersApprovals letters={pendingLetters} onChanged={() => { letters.refetch(); allLetters.refetch(); }} />
            )}
            <DecidedLetters letters={allLetterRows.filter((l) => l.status !== "PENDING")} canManualLetters={canManualLetters} onChanged={() => allLetters.refetch()} />
          </TabsContent>
        )}

        <TabsContent value="report">
          <RequestsReport leaves={myLeaves} advances={myAdvances} letters={allLetterRows} />
        </TabsContent>
      </Tabs>
    </div>
  );

  async function decide(kind: "LEAVE" | "ADVANCE", id: string, action: "APPROVED" | "REJECTED", note: string, refetch: () => void) {
    try {
      const r = await api<{ status: string }>("/api/requests", { method: "PATCH", json: { kind, id, action, note } });
      refetch();
      toast({ title: action === "APPROVED" ? "تأیید شد" : "رد شد", description: `وضعیت جدید: ${REQUEST_STATUS_LABELS[r.status]}` });
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }
}

// دکمه‌های تصمیم + دیالوگ یادداشت رد
function DecisionButtons({ disabled, stage, canDept, canHr, onDecide }: {
  disabled: boolean; stage: string; canDept: boolean; canHr: boolean;
  onDecide: (action: "APPROVED" | "REJECTED", note: string) => void;
}) {
  const [rejectOpen, setRejectOpen] = useState(false);
  const [note, setNote] = useState("");
  const canActStage = stage === "PENDING_DM" ? canDept : stage === "PENDING_HR" ? canHr : false;

  if (disabled || !canActStage) return <span className="text-[10px] text-muted-foreground">—</span>;
  return (
    <div className="flex gap-1.5">
      <Button size="sm" className="h-8 gap-1 bg-emerald-600 hover:bg-emerald-700" onClick={() => onDecide("APPROVED", "")}>
        <CheckCircle2 className="w-3.5 h-3.5" /> تأیید
      </Button>
      <Button size="sm" variant="destructive" className="h-8 gap-1" onClick={() => setRejectOpen(true)}>
        <XCircle className="w-3.5 h-3.5" /> رد
      </Button>
      <Dialog open={rejectOpen} onOpenChange={(v) => !v && setRejectOpen(false)}>
        <DialogContent className="max-w-sm" dir="rtl">
          <DialogHeader><DialogTitle className="text-sm">دلیل رد درخواست</DialogTitle></DialogHeader>
          <div className="space-y-1.5">
            <Label className="text-xs">دلیل (برای اطلاع کارمند)</Label>
            <Textarea value={note} onChange={(e) => setNote(e.target.value)} className="min-h-20" placeholder="مثلاً: ظرفیت مرخصی واحد در این بازه تکمیل است." />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setRejectOpen(false)}>انصراف</Button>
            <Button variant="destructive" onClick={() => { onDecide("REJECTED", note); setRejectOpen(false); setNote(""); }}>ثبت رد</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// نمایش مراحل تأیید
function ApprovalTrail({ row }: { row: { dmStatus: string; dmBy: string; hrStatus: string; hrBy: string; status: string; rejectReason: string } }) {
  const step = (label: string, status: string, by: string) => (
    <div className="flex items-center gap-1 text-[10px]">
      {status === "APPROVED" && <CheckCircle2 className="w-3 h-3 text-emerald-600" />}
      {status === "REJECTED" && <XCircle className="w-3 h-3 text-rose-600" />}
      {status === "PENDING" && <Clock className="w-3 h-3 text-slate-400" />}
      <span className={status === "PENDING" ? "text-muted-foreground" : "text-slate-700"}>
        {label}{by ? ` (${by})` : ""}
      </span>
    </div>
  );
  return (
    <div className="rounded-lg bg-slate-50 border px-2.5 py-1.5 space-y-0.5 min-w-[170px]">
      {step("۱. مدیر واحد", row.dmStatus, row.dmBy)}
      {step("۲. منابع انسانی", row.hrStatus, row.hrBy)}
      {row.rejectReason && <p className="text-[10px] text-rose-600 leading-4">دلیل رد: {row.rejectReason}</p>}
    </div>
  );
}

// ثبت نامه دستی — کارشناس اداری (بدون قالب)
function ManualLetterSection({ onChanged }: { onChanged: () => void }) {
  const [open, setOpen] = useState(false);
  return (
    <Card className="rounded-2xl bg-gradient-to-l from-blue-50 to-white border-blue-200">
      <CardContent className="p-4 flex items-start gap-3 flex-wrap">
        <PenLine className="w-6 h-6 text-blue-600 shrink-0 mt-0.5" />
        <div className="flex-1 min-w-[220px]">
          <p className="font-bold text-sm text-slate-800">ثبت نامه دستی (بدون قالب)</p>
          <p className="text-xs text-muted-foreground mt-1 leading-5">
            نامه‌های اداری خارج از قالب‌های سیستمی را مستقیم ثبت و صادر کنید — با شماره سیستمی
            (الگوی <span className="font-mono text-[10px]" dir="ltr">ZDX_AD_0507019</span>) و امضای دیجیتال لحظه‌ای؛ قابل چاپ با/بدون سربرگ.
          </p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700 gap-1.5 shrink-0" onClick={() => setOpen(true)}>
          <Plus className="w-4 h-4" /> نامه جدید
        </Button>
      </CardContent>
      {open && <ManualLetterDialog onClose={() => setOpen(false)} onSaved={onChanged} />}
    </Card>
  );
}

function ManualLetterDialog({ onClose, onSaved }: { onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const [category, setCategory] = useState("ADMIN");
  const [title, setTitle] = useState("");
  // گیرنده: عنوان (سمت) از دراپ‌داون + نام/شرح — «سایر» = عنوان دلخواه با تایپ دستی
  const [recipientTitle, setRecipientTitle] = useState<string>(RECIPIENT_TITLES[0]);
  const [recipientTitleCustom, setRecipientTitleCustom] = useState("");
  const [recipientName, setRecipientName] = useState("");
  const [dateJ, setDateJ] = useState(todayJalaliStr());
  /** متن غنی نامه (HTML پاک‌سازی‌شده) — جدول/قالب‌بندی + متن ساده */
  const [bodyHtml, setBodyHtml] = useState("");
  const [bodyPlain, setBodyPlain] = useState("");
  // امضاکننده: انتخاب از امضاکنندگان مجاز (تنظیمات ← قالب نامه‌ها) یا ورود دستی
  const [signerChoice, setSignerChoice] = useState<string>("");
  const [signerName, setSignerName] = useState("");
  const [signerTitle, setSignerTitle] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState<LetterRow | null>(null);
  const settings = useApi<{ settings: { numberingPrefix: string; signerName: string; signerTitle: string; signers: { name: string; title: string }[] } }>("/api/letters/manual");

  const signers = settings.data?.settings?.signers || [];

  // پیش‌فرض دراپ‌داون امضاکننده: امضاکننده پیش‌فرض تنظیمات (اگر در فهرست باشد)، وگرنه اولین امضاکننده مجاز
  useEffect(() => {
    if (signerChoice === "" && signers.length > 0) {
      const defName = settings.data?.settings?.signerName || "";
      const idx = defName ? signers.findIndex((s) => s.name === defName) : -1;
      setSignerChoice(String(idx >= 0 ? idx : 0));
    }
  }, [signers, signerChoice, settings.data]);

  // نام/سمت نهایی امضاکننده: انتخاب دراپ‌داون → ورود دستی → پیش‌فرض تنظیمات
  const chosen = signerChoice !== "" && signerChoice !== SIGNER_CUSTOM ? signers[Number(signerChoice)] : undefined;
  const effSignerName = chosen ? chosen.name : signerName || settings.data?.settings?.signerName || "";
  const effSignerTitle = chosen ? chosen.title : signerTitle || settings.data?.settings?.signerTitle || "";

  // گیرنده نهایی = عنوان + نام (فقط اجزای پر شده)
  const recipient = [
    recipientTitle === RECIPIENT_CUSTOM ? recipientTitleCustom.trim() : recipientTitle,
    recipientName.trim(),
  ].filter(Boolean).join(" ");

  async function save() {
    if (!title.trim() || (!bodyPlain.trim() && !bodyHtml.trim())) {
      toast({ title: "موضوع و متن نامه الزامی است", variant: "destructive" });
      return;
    }
    if (recipientTitle === RECIPIENT_CUSTOM && !recipientTitleCustom.trim() && recipientName.trim()) {
      toast({ title: "عنوان دلخواه گیرنده را تایپ کنید یا یکی از عناوین پیش‌فرض را انتخاب کنید", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const r = await api<{ letter: LetterRow }>("/api/letters/manual", {
        method: "POST",
        json: {
          title, recipient, category, dateJ,
          body: bodyPlain,
          bodyHtml,
          signerName: effSignerName,
          signerTitle: effSignerTitle,
        },
      });
      setSaved(r.letter);
      onSaved();
      toast({
        title: `نامه ثبت شد — ${r.letter.number}`,
        description: "در انتظار تأیید مرجع مجاز؛ امضای دیجیتال پس از تأیید صادر می‌شود.",
      });
    } catch (e) {
      toast({ title: "خطا در ثبت نامه", description: e instanceof Error ? e.message : "", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PenLine className="w-5 h-5 text-blue-600" />
            {saved ? `نامه ثبت شد — ${saved.number}` : "ثبت نامه دستی (بدون قالب)"}
          </DialogTitle>
        </DialogHeader>

        {saved ? (
          <>
            <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-3 text-xs leading-6 text-amber-800 space-y-1">
              <p>
                نامه با شماره <span className="font-mono" dir="ltr">{saved.number}</span> ثبت شد و <b>در انتظار تأیید</b> است.
              </p>
              <p>
                پس از تأیید توسط مرجع مجاز (در همین بخش — صندوق نامه‌های در انتظار)، امضای دیجیتال روی محتوای نامه قفل می‌شود و
                نسخه رسمی (چاپ/دانلود با و بدون سربرگ) صادر خواهد شد.
              </p>
            </div>
            <LetterPrintButtons
              letter={{
                number: saved.number,
                title: saved.title,
                body: saved.body,
                bodyHtml: saved.bodyHtml,
                status: saved.status,
                source: saved.source,
                recipient: saved.recipient,
                decidedBy: saved.decidedBy,
                decidedAt: saved.decidedAt ?? null,
                decisionNote: saved.decisionNote,
                signatureCode: saved.signatureCode,
                employeeName: "",
                signerName: saved.signerName,
                signerTitle: saved.signerTitle,
                items: saved.items || [],
                createdAt: saved.createdAt,
              }}
            />
            <DialogFooter>
              <Button variant="outline" onClick={onClose}>بستن</Button>
              <Button className="gap-1.5" onClick={() => {
                setSaved(null);
                setTitle("");
                setRecipientTitle(RECIPIENT_TITLES[0]);
                setRecipientTitleCustom("");
                setRecipientName("");
                setBodyHtml("");
                setBodyPlain("");
                setDateJ(todayJalaliStr());
                setSignerChoice("");
                setSignerName("");
                setSignerTitle("");
              }}>ثبت نامه بعدی</Button>
            </DialogFooter>
          </>
        ) : (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">دسته نامه <span className="text-rose-500">*</span></Label>
                <select className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm" value={category} onChange={(e) => setCategory(e.target.value)} dir="rtl">
                  {Object.entries(LETTER_CATEGORY_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
                </select>
                <p className="text-[10px] text-muted-foreground">کد دسته در شماره نامه: {({ ADMIN: "AD", HR: "HR", FINANCE: "FN", GENERAL: "GN" } as Record<string, string>)[category]}</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">تاریخ نامه</Label>
                <JalaliDatePicker value={dateJ} onChange={setDateJ} />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label className="text-xs">موضوع <span className="text-rose-500">*</span></Label>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثال: استعلام وضعیت بدهی و تعیین تکلیف چک" />
              </div>
              {/* گیرنده — عنوان پیش‌فرض با دراپ‌داون + نام، و گزینه عنوان دلخواه */}
              <div className="space-y-1.5">
                <Label className="text-xs">عنوان گیرنده (سمت)</Label>
                <select
                  className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm"
                  value={recipientTitle}
                  onChange={(e) => setRecipientTitle(e.target.value)}
                  dir="rtl"
                >
                  {RECIPIENT_TITLES.map((t) => <option key={t} value={t}>{t}</option>)}
                  <option value={RECIPIENT_CUSTOM}>سایر (تایپ دستی)…</option>
                </select>
                <p className="text-[10px] text-muted-foreground">پیش‌فرض‌های مکاتبات رسمی — با «سایر» عنوان دلخواه تایپ کنید</p>
              </div>
              {recipientTitle === RECIPIENT_CUSTOM ? (
                <div className="space-y-1.5">
                  <Label className="text-xs">عنوان دلخواه گیرنده</Label>
                  <Input value={recipientTitleCustom} onChange={(e) => setRecipientTitleCustom(e.target.value)} placeholder="مثال: ریاست محترم اداره…" />
                </div>
              ) : (
                <div className="space-y-1.5">
                  <Label className="text-xs">نام / شرح گیرنده (اختیاری)</Label>
                  <Input value={recipientName} onChange={(e) => setRecipientName(e.target.value)} placeholder="مثال: محمد محمدی — شرکت نمونه" />
                </div>
              )}
              {recipientTitle === RECIPIENT_CUSTOM && (
                <div className="space-y-1.5 sm:col-span-2">
                  <Label className="text-xs">نام / شرح گیرنده (اختیاری)</Label>
                  <Input value={recipientName} onChange={(e) => setRecipientName(e.target.value)} placeholder="مثال: محمد محمدی — شرکت نمونه" />
                </div>
              )}
              <div className="sm:col-span-2 -mt-1">
                <p className="text-[10px] text-muted-foreground">گیرنده نهایی در نامه: <b className="text-slate-700">{recipient || "—"}</b></p>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs">متن نامه <span className="text-rose-500">*</span></Label>
              <LetterRichEditor
                value={bodyHtml}
                onChange={(html, plain) => { setBodyHtml(html); setBodyPlain(plain); }}
                placeholder="با سلام و احترام،… (جدول را از اکسل/ورد کپی-پیست کنید یا با دکمه «جدول» بسازید)"
              />
              <p className="text-[10px] text-muted-foreground leading-4 flex items-center gap-1">
                <Table2 className="w-3 h-3 shrink-0" />
                جدول درج‌شده در متن نامه راست‌به‌چپ است؛ تیتر ستون‌ها و تعدادشان قابل‌ویرایش — کپی-پیست از اکسل/ورد/گوگل‌شیت پشتیبانی می‌شود.
              </p>
            </div>

            {/* امضاکننده — انتخاب از امضاکنندگان مجاز (تنظیمات ← قالب نامه‌ها) یا ورود دستی */}
            {signers.length > 0 ? (
              <div className="space-y-1.5">
                <Label className="text-xs">امضاکننده نامه <span className="text-rose-500">*</span></Label>
                <select
                  className="w-full h-9 rounded-md border border-input bg-transparent px-3 text-sm"
                  value={signerChoice || "0"}
                  onChange={(e) => setSignerChoice(e.target.value)}
                  dir="rtl"
                >
                  {signers.map((s, i) => (
                    <option key={i} value={String(i)}>
                      {s.name}{s.title ? ` — ${s.title}` : ""}
                    </option>
                  ))}
                  <option value={SIGNER_CUSTOM}>سایر (ورود دستی)…</option>
                </select>
                <p className="text-[10px] text-muted-foreground leading-4">
                  فهرست امضاکنندگان مجاز از «تنظیمات ← قالب نامه‌ها ← امضاکنندگان مجاز» مدیریت می‌شود.
                  {chosen ? <> نام/سمت در بلوک امضا و مهر امضای دیجیتال چاپ می‌شود.</> : null}
                </p>
              </div>
            ) : (
              <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-2.5 leading-5">
                هنوز امضاکننده مجازی در تنظیمات تعریف نشده — نام/سمت دستی زیر ثبت می‌شود؛
                برای فهرست انتخابی، از «تنظیمات ← قالب نامه‌ها ← امضاکنندگان مجاز» اضافه کنید.
              </p>
            )}

            {signers.length === 0 || signerChoice === SIGNER_CUSTOM ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-xs">نام امضاکننده</Label>
                  <Input value={signerName} onChange={(e) => setSignerName(e.target.value)} placeholder={settings.data?.settings?.signerName || "نام کامل امضاکننده"} />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs">سمت امضاکننده</Label>
                  <Input value={signerTitle} onChange={(e) => setSignerTitle(e.target.value)} placeholder={settings.data?.settings?.signerTitle || "مدیر عامل"} />
                </div>
              </div>
            ) : (
              <p className="text-[10px] text-muted-foreground -mt-1">
                امضاکننده انتخاب‌شده: <b className="text-slate-700">{effSignerName}</b>{effSignerTitle ? <> — {effSignerTitle}</> : null}
              </p>
            )}

            <p className="text-[11px] text-muted-foreground leading-5">
              با ثبت، شماره سیستمی مطابق الگوی <span className="font-mono text-[10px]" dir="ltr">{settings.data?.settings?.numberingPrefix || "ZDX"}_{({ ADMIN: "AD", HR: "HR", FINANCE: "FN", GENERAL: "GN" } as Record<string, string>)[category]}_YYMMNNN</span> صادر
              می‌شود؛ نامه «در انتظار تأیید» می‌ماند و پس از تأیید مرجع مجاز، امضای دیجیتال روی محتوای آن قفل و نسخه رسمی قابل چاپ/دانلود خواهد شد.
            </p>

            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={onClose}>انصراف</Button>
              <Button onClick={save} disabled={saving} className="bg-blue-600 hover:bg-blue-700 gap-1.5">
                <PenLine className="w-4 h-4" /> {saving ? "در حال ثبت..." : "ثبت نامه (در انتظار تأیید)"}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

// نامه‌های در انتظار تأیید
function LettersApprovals({ letters, onChanged }: { letters: LetterRow[]; onChanged: () => void }) {
  const [viewing, setViewing] = useState<LetterRow | null>(null);
  const { toast } = useToast();

  async function decide(id: string, status: "APPROVED" | "REJECTED") {
    try {
      const r = await api<{ letter: LetterRow }>(`/api/letters/${id}`, { method: "PATCH", json: { status, note: "" } });
      onChanged();
      // دیالوگ باز می‌ماند: نامه تأییدشده با امضای دیجیتال و گزینه‌های چاپ/دانلود
      setViewing((prev) =>
        prev && prev.id === id
          ? { ...prev, status: r.letter.status, decidedBy: r.letter.decidedBy, decidedAt: r.letter.decidedAt ?? null, signatureCode: r.letter.signatureCode ?? null }
          : prev
      );
      if (status === "APPROVED" && r.letter.signatureCode) {
        toast({ title: "نامه تأیید و امضای دیجیتال صادر شد", description: `کد راستی‌آزمایی: ${r.letter.signatureCode}` });
      } else {
        toast({ title: status === "APPROVED" ? "نامه تأیید شد" : "نامه رد شد" });
      }
    } catch (e) {
      toast({ title: "خطا", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  // نکته: دیالوگ خارج از early-return می‌ماند — پس از تأیید و خالی شدن لیست،
  // دیالوگ با امضای دیجیتال و دکمه‌های چاپ/دانلود باز می‌ماند
  return (
    <>
      {letters.length === 0 ? (
        <Card className="rounded-2xl">
          <CardContent className="py-16 text-center">
            <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">نامه‌ای در انتظار تأیید نیست.</p>
          </CardContent>
        </Card>
      ) : (
        <Card className="rounded-2xl overflow-hidden">
          <CardContent className="p-0 divide-y">
            {letters.map((l) => (
              <div key={l.id} className="p-4 flex flex-wrap items-center gap-3 hover:bg-slate-50/60">
                <div className="flex-1 min-w-[200px]">
                  <p className="text-sm font-medium flex items-center gap-1.5 flex-wrap">
                    {l.title}
                    {l.source === "MANUAL" && <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-[10px] px-1.5">دستی</Badge>}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {l.source === "MANUAL" ? (l.recipient || l.signerName || "نامه دستی") : `${l.employeeName} — ${l.department}`} • <span className="font-mono text-[10px]" dir="ltr">{l.number}</span>
                  </p>
                </div>
                <Badge className={STATUS_BADGE[l.status]}>{LETTER_STATUS_LABELS[l.status]}</Badge>
                <Button size="sm" variant="outline" className="h-8 gap-1" onClick={() => setViewing(l)}>
                  <Eye className="w-3.5 h-3.5" /> مشاهده
                </Button>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Dialog open={!!viewing} onOpenChange={(v) => !v && setViewing(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
          {viewing && (
            <>
              <DialogHeader>
                <DialogTitle className="text-sm flex items-center gap-2 flex-wrap">
                  {viewing.title}
                  <span className="font-mono text-[10px] text-muted-foreground" dir="ltr">{viewing.number}</span>
                  <LetterSignatureBadge code={viewing.signatureCode} decidedAt={viewing.decidedAt} />
                </DialogTitle>
              </DialogHeader>
              <LetterRichBodyPreview html={viewing.bodyHtml} plain={viewing.body} />
              {viewing.status === "PENDING" ? (
                <div className="rounded-xl border border-amber-200 bg-amber-50/60 p-3 text-xs leading-6 text-amber-800">
                  با تأیید این {viewing.source === "MANUAL" ? "نامه دستی" : "نامه"}، امضای دیجیتال روی محتوای آن قفل می‌شود و نسخه‌های چاپی/دانلودی با سربرگ صادر خواهند شد.
                </div>
              ) : (
                <LetterPrintButtons
                  letter={{
                    number: viewing.number,
                    title: viewing.title,
                    body: viewing.body,
                    bodyHtml: viewing.bodyHtml,
                    status: viewing.status,
                    source: viewing.source,
                    recipient: viewing.recipient,
                    decidedBy: viewing.decidedBy,
                    decidedAt: viewing.decidedAt,
                    decisionNote: viewing.decisionNote,
                    signatureCode: viewing.signatureCode,
                    employeeName: viewing.employeeName,
                    personnelCode: viewing.personnelCode,
                    department: viewing.department,
                    signerName: viewing.signerName,
                    signerTitle: viewing.signerTitle,
                    items: viewing.items || [],
                    createdAt: viewing.createdAt,
                  }}
                />
              )}
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setViewing(null)}>بستن</Button>
                {viewing.status === "PENDING" && (
                  <>
                    <Button variant="destructive" className="gap-1.5" onClick={() => decide(viewing.id, "REJECTED")}><XCircle className="w-4 h-4" /> رد</Button>
                    <Button className="bg-emerald-600 hover:bg-emerald-700 gap-1.5" onClick={() => decide(viewing.id, "APPROVED")}><CheckCircle2 className="w-4 h-4" /> تأیید و صدور امضای دیجیتال</Button>
                  </>
                )}
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// نامه‌های صادرشده (تأییدشده/ردشده + دستی) — مشاهده/چاپ/دانلود با امضای دیجیتال
function DecidedLetters({ letters, canManualLetters, onChanged }: { letters: LetterRow[]; canManualLetters: boolean; onChanged: () => void }) {
  const [viewing, setViewing] = useState<LetterRow | null>(null);
  const { toast } = useToast();
  if (letters.length === 0) return null;

  async function removeManual(l: LetterRow) {
    if (!confirm(`حذف نامه دستی «${l.title}» (${l.number})؟\nامضای دیجیتال آن باطل می‌شود و راستی‌آزمایی «یافت نشد» برمی‌گرداند.`)) return;
    try {
      await api(`/api/letters/${l.id}`, { method: "DELETE" });
      setViewing(null);
      onChanged();
      toast({ title: "نامه دستی حذف شد", description: `${l.number} — امضای دیجیتال باطل شد` });
    } catch (e) {
      toast({ title: "خطا در حذف", description: e instanceof Error ? e.message : "", variant: "destructive" });
    }
  }

  return (
    <>
      <Card className="rounded-2xl overflow-hidden">
        <CardHeader className="py-3 px-4 bg-slate-50/70 border-b">
          <CardTitle className="text-xs flex items-center gap-1.5 text-muted-foreground">
            <FileText className="w-3.5 h-3.5" /> نامه‌های صادرشده ({toFaDigits(letters.length)})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0 divide-y">
          {letters.slice(0, 20).map((l) => (
            <div key={l.id} className="p-3.5 flex flex-wrap items-center gap-3 hover:bg-slate-50/60">
              <div className="flex-1 min-w-[220px]">
                <p className="text-sm font-medium flex items-center gap-1.5 flex-wrap">
                  {l.title}
                  {l.source === "MANUAL" && <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-[10px] px-1.5">دستی</Badge>}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {l.source === "MANUAL" ? (l.recipient || l.signerName || "—") : `${l.employeeName} — ${l.department}`} • <span className="font-mono text-[10px]" dir="ltr">{l.number}</span>
                </p>
              </div>
              <LetterSignatureBadge code={l.signatureCode} decidedAt={l.decidedAt} />
              <Badge className={STATUS_BADGE[l.status]}>{LETTER_STATUS_LABELS[l.status]}</Badge>
              <Button size="sm" variant="outline" className="h-8 gap-1" onClick={() => setViewing(l)}>
                <Eye className="w-3.5 h-3.5" /> مشاهده و چاپ
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      <Dialog open={!!viewing} onOpenChange={(v) => !v && setViewing(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto" dir="rtl">
          {viewing && (
            <>
              <DialogHeader>
                <DialogTitle className="text-sm flex items-center gap-2 flex-wrap">
                  {viewing.title}
                  {viewing.source === "MANUAL" && <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 text-[10px]">ثبت دستی</Badge>}
                  <span className="font-mono text-[10px] text-muted-foreground" dir="ltr">{viewing.number}</span>
                  <LetterSignatureBadge code={viewing.signatureCode} decidedAt={viewing.decidedAt} />
                </DialogTitle>
              </DialogHeader>
              {viewing.recipient && <p className="text-xs text-muted-foreground -mt-2">گیرنده: {viewing.recipient}</p>}
              <LetterRichBodyPreview html={viewing.bodyHtml} plain={viewing.body} />
              {(viewing.items || []).length > 0 && (
                <div className="rounded-xl border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-slate-50/80">
                        <TableHead className="text-center w-16">ردیف</TableHead>
                        <TableHead>شرح</TableHead>
                        <TableHead className="text-center">کد/شناسه</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(viewing.items || []).map((it, i) => (
                        <TableRow key={i}>
                          <TableCell className="text-center tabular-nums">{toFaDigits(i + 1)}</TableCell>
                          <TableCell className="text-sm">{it.title || "—"}</TableCell>
                          <TableCell className="text-center font-mono text-xs" dir="ltr">{it.code || "—"}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
              <LetterPrintButtons
                letter={{
                  number: viewing.number,
                  title: viewing.title,
                  body: viewing.body,
                  bodyHtml: viewing.bodyHtml,
                  status: viewing.status,
                  source: viewing.source,
                  recipient: viewing.recipient,
                  decidedBy: viewing.decidedBy,
                  decidedAt: viewing.decidedAt,
                  decisionNote: viewing.decisionNote,
                  signatureCode: viewing.signatureCode,
                  employeeName: viewing.employeeName,
                  personnelCode: viewing.personnelCode,
                  department: viewing.department,
                  signerName: viewing.signerName,
                  signerTitle: viewing.signerTitle,
                  items: viewing.items || [],
                  createdAt: viewing.createdAt,
                }}
              />
              <DialogFooter className="gap-2">
                {viewing.source === "MANUAL" && canManualLetters && (
                  <Button variant="destructive" className="gap-1.5" onClick={() => removeManual(viewing)}>
                    <Trash2 className="w-4 h-4" /> حذف نامه دستی
                  </Button>
                )}
                <Button variant="outline" onClick={() => setViewing(null)}>بستن</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// گزارش درخواست‌ها
function RequestsReport({ leaves, advances, letters }: { leaves: LeaveRow[]; advances: AdvanceRow[]; letters: LetterRow[] }) {
  const [statusFilter, setStatusFilter] = useState("all");
  const [kindFilter, setKindFilter] = useState("all");

  const rows = useMemo(() => {
    const all: { key: string; kind: string; employeeName: string; department: string; detail: string; status: string; date: string }[] = [];
    for (const l of leaves) all.push({ key: l.id, kind: "مرخصی", employeeName: l.employeeName, department: l.department, detail: `${LEAVE_TYPE_LABELS[l.type]} — ${toFaDigits(l.days)} روز (${formatDateJ(l.startDateJ)} تا ${formatDateJ(l.endDateJ)})`, status: l.status, date: l.createdAt });
    for (const a of advances) all.push({ key: a.id, kind: "مساعده", employeeName: a.employeeName, department: a.department, detail: `${groupFa(Math.round(a.amount / 10))} تومان — ${toFaDigits(a.installments)} قسط`, status: a.status, date: a.createdAt });
    for (const lt of letters) all.push({ key: lt.id, kind: lt.source === "MANUAL" ? "نامه دستی" : "درخواست‌نامه", employeeName: lt.source === "MANUAL" ? (lt.signerName || lt.recipient || lt.createdBy || "—") : lt.employeeName, department: lt.source === "MANUAL" ? "" : lt.department, detail: `${lt.title} (${lt.number})`, status: lt.status, date: lt.createdAt });
    return all
      .filter((r) => statusFilter === "all" || r.status === statusFilter)
      .filter((r) => kindFilter === "all" || r.kind === kindFilter)
      .sort((a, b) => b.date.localeCompare(a.date));
  }, [leaves, advances, letters, statusFilter, kindFilter]);

  function exportCsv() {
    const header = ["نوع", "کارمند", "واحد", "شرح", "وضعیت", "تاریخ ثبت"];
    const rows2 = rows.map((r) => [r.kind, r.employeeName, r.department, r.detail, REQUEST_STATUS_LABELS[r.status] || LETTER_STATUS_LABELS[r.status] || r.status, r.date.slice(0, 10)]);
    const csv = "\uFEFF" + [header, ...rows2].map((r) => r.map((c) => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "requests-report.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Card className="rounded-2xl overflow-hidden">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2 flex-wrap">
          <Printer className="w-4 h-4 text-teal-600" /> گزارش درخواست‌ها ({toFaDigits(rows.length)} مورد)
          <div className="mr-auto flex gap-1.5">
            <select className="h-8 rounded-md border bg-transparent px-2 text-xs" value={kindFilter} onChange={(e) => setKindFilter(e.target.value)} dir="rtl">
              <option value="all">همه انواع</option>
              <option value="مرخصی">مرخصی</option>
              <option value="مساعده">مساعده</option>
              <option value="درخواست‌نامه">درخواست‌نامه</option>
              <option value="نامه دستی">نامه دستی</option>
            </select>
            <select className="h-8 rounded-md border bg-transparent px-2 text-xs" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} dir="rtl">
              <option value="all">همه وضعیت‌ها</option>
              {Object.entries(REQUEST_STATUS_LABELS).map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
            <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={exportCsv}><Printer className="w-3 h-3" /> خروجی CSV</Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-slate-50/80">
                <TableHead className="text-right">نوع</TableHead>
                <TableHead className="text-right">کارمند</TableHead>
                <TableHead className="text-right">واحد</TableHead>
                <TableHead className="text-right">شرح</TableHead>
                <TableHead className="text-center">وضعیت</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.length === 0 && (
                <TableRow><TableCell colSpan={5} className="text-center text-sm text-muted-foreground py-10">موردی یافت نشد</TableCell></TableRow>
              )}
              {rows.map((r) => (
                <TableRow key={r.key} className="hover:bg-teal-50/40">
                  <TableCell className="text-xs">{r.kind}</TableCell>
                  <TableCell className="text-xs font-medium">{r.employeeName}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{r.department}</TableCell>
                  <TableCell className="text-xs">{r.detail}</TableCell>
                  <TableCell className="text-center">
                    <Badge className={STATUS_BADGE[r.status] || ""}>{REQUEST_STATUS_LABELS[r.status] || LETTER_STATUS_LABELS[r.status] || r.status}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}

function StatBox({ icon, label, value, tone }: { icon: React.ReactNode; label: string; value: number; tone: string }) {
  const tones: Record<string, string> = {
    amber: "bg-amber-50 border-amber-200",
    sky: "bg-sky-50 border-sky-200",
    emerald: "bg-emerald-50 border-emerald-200",
    rose: "bg-rose-50 border-rose-200",
  };
  return (
    <div className={`rounded-2xl border p-3 flex items-center gap-3 ${tones[tone]}`}>
      <div className="w-9 h-9 rounded-xl bg-white border flex items-center justify-center shrink-0">{icon}</div>
      <div>
        <p className="text-[11px] text-muted-foreground">{label}</p>
        <p className="text-lg font-black tabular-nums">{toFaDigits(value)}</p>
      </div>
    </div>
  );
}
